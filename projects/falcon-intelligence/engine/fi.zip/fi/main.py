"""Falcon Intelligence API + web app.

Run:  python -m uvicorn fi.main:app --app-dir backend --port 8600
"""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from . import __version__, api_care, api_core, api_platform, api_recovery, api_tracking, api_vision, config, reports
from .models import init_db

app = FastAPI(title="Falcon Intelligence", version=__version__,
              description="Falcon monitoring, telemetry, health observation and flight performance platform.")
init_db()
# api_platform first: its fixed paths (/flights/recent …) must win over parameterised ones (/flights/{id})
for r in (api_platform.router, api_recovery.router, api_core.router, api_tracking.router, api_care.router, api_vision.router, reports.router):
    app.include_router(r)


@app.get("/api/healthz")
def healthz():
    return {"ok": True, "version": __version__, "demo": config.DEMO_MODE}


@app.middleware("http")
async def security_headers(request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if request.url.path.startswith("/api/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    elif request.url.path.endswith((".js", ".css", ".html")) or request.url.path == "/":
        resp.headers["Cache-Control"] = "no-cache"
    return resp


if not config.BROWSER:                              # the browser edition is served as static files by the website
    @app.get("/")
    def index():
        return FileResponse(config.WEB_DIR / "index.html")

    app.mount("/", StaticFiles(directory=config.WEB_DIR), name="web")
