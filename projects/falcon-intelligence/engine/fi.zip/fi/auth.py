"""Authentication (opaque bearer tokens) and role-based access control."""
from __future__ import annotations

import hashlib
import hmac
import secrets
from datetime import timedelta

from fastapi import Depends, Header, HTTPException
from sqlalchemy.orm import Session

from . import config
from sqlalchemy import select

from .models import AuditLog, AuthSession, Falcon, FalconAccess, LocationAccessLog, User, get_db, now

# Permission matrix -------------------------------------------------------------------------
# identity   : ownership, ring / microchip / passport numbers, restricted documents, QR
# clinical   : veterinary-provenance records, target weight ranges, alert review
# telemetry.read                : live / historical positions and flights (sensitive location data)
# location.share / access.manage: owner-level control over who else can see a bird
_ALL = {"falcon.read", "falcon.write", "telemetry.read", "identity.read", "identity.write", "health.read", "health.write",
        "clinical.write", "feeding.write", "training.write", "breeding.read", "breeding.write",
        "device.read", "device.write", "device.review", "vision.use", "dataset.write", "report",
        "recovery.read", "recovery.write", "location.share", "access.manage", "settings.write"}
PERMS: dict[str, set[str]] = {
    "admin": _ALL | {"admin"},
    "facility_manager": _ALL,
    "owner": _ALL - {"clinical.write", "device.review"},
    "falconer": {"falcon.read", "falcon.write", "telemetry.read", "health.read", "health.write", "feeding.write",
                 "training.write", "device.read", "device.write", "vision.use", "dataset.write", "report",
                 "recovery.read", "recovery.write", "settings.write"},
    "trainer": {"falcon.read", "telemetry.read", "health.read", "health.write", "feeding.write", "training.write",
                "device.read", "vision.use", "report", "recovery.read"},
    "vet": {"falcon.read", "identity.read", "health.read", "health.write", "clinical.write", "feeding.write",
            "device.read", "device.review", "breeding.read", "vision.use", "report"},
    "hospital": {"falcon.read", "identity.read", "health.read", "health.write", "clinical.write", "feeding.write",
                 "vision.use", "report"},
    "breeder": {"falcon.read", "falcon.write", "identity.read", "health.read", "health.write", "feeding.write",
                "breeding.read", "breeding.write", "vision.use", "dataset.write", "report"},
    "recovery": {"recovery.read", "recovery.write"},      # only cases they are a named contact on
    "viewer": {"falcon.read", "telemetry.read", "device.read"},
}


def hash_pw(password: str, salt: str) -> str:
    pw, s, n = password.encode(), bytes.fromhex(salt), config.PBKDF2_ITERATIONS
    if hasattr(hashlib, "pbkdf2_hmac"):
        return hashlib.pbkdf2_hmac("sha256", pw, s, n).hex()
    # pure-Python PBKDF2-HMAC-SHA256 (one 32-byte block) for runtimes without the C implementation
    u = hmac.new(pw, s + b"\x00\x00\x00\x01", "sha256").digest()
    out = int.from_bytes(u, "big")
    for _ in range(n - 1):
        u = hmac.new(pw, u, "sha256").digest()
        out ^= int.from_bytes(u, "big")
    return out.to_bytes(32, "big").hex()


def new_salt() -> str:
    return secrets.token_hex(16)


def sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def verify_pw(user: User, password: str) -> bool:
    return hmac.compare_digest(hash_pw(password, user.salt), user.pw_hash)


def issue_token(db: Session, user: User) -> str:
    token = secrets.token_urlsafe(32)
    db.add(AuthSession(token_hash=sha(token), user_id=user.id, expires=now() + timedelta(hours=config.SESSION_HOURS)))
    db.commit()
    return token


def current_user(authorization: str | None = Header(None), db: Session = Depends(get_db)) -> User:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Not signed in")
    s = db.get(AuthSession, sha(authorization[7:].strip()))
    if not s or s.expires < now():
        raise HTTPException(401, "Session expired")
    user = db.get(User, s.user_id)
    if not user or not user.active:
        raise HTTPException(401, "Account disabled")
    return user


def can(user: User, perm: str) -> bool:
    return perm in PERMS.get(user.role, set())


def require(perm: str):
    def dep(user: User = Depends(current_user)) -> User:
        if not can(user, perm):
            raise HTTPException(403, f"Your role ({user.role}) is not permitted to do this ({perm})")
        return user
    return dep


def get_falcon(db: Session, user: User, falcon_id: int) -> Falcon:
    f = db.get(Falcon, falcon_id)
    if not f or (f.org_id != user.org_id and falcon_id not in granted_falcon_ids(db, user)):
        raise HTTPException(404, "Falcon not found")
    return f


def granted_falcon_ids(db: Session, user: User) -> set[int]:
    """Falcons outside the user's organisation that an owner has explicitly shared with them."""
    t = now()
    rows = db.scalars(select(FalconAccess).where(FalconAccess.user_id == user.id, FalconAccess.revoked_at.is_(None))).all()
    return {r.falcon_id for r in rows if r.expires is None or r.expires > t}


def log_location(db: Session, falcon_id: int, what: str, user: User | None = None, actor: str | None = None,
                 actor_name: str | None = None, case_id: int | None = None, ip: str | None = None) -> None:
    """Record access to sensitive location data (at most one row per actor / falcon / kind / hour)."""
    actor = actor or f"user:{user.id}"
    hour = now().replace(minute=0, second=0, microsecond=0)
    if db.scalar(select(LocationAccessLog.id).where(LocationAccessLog.falcon_id == falcon_id, LocationAccessLog.actor == actor,
                                                    LocationAccessLog.what == what, LocationAccessLog.ts >= hour)):
        return
    db.add(LocationAccessLog(falcon_id=falcon_id, actor=actor, actor_name=actor_name or (user.name if user else None),
                             what=what, case_id=case_id, ip=ip))
    db.commit()


IDENTITY_FIELDS = ("owner_name", "owner_user_id", "ring_number", "microchip", "passport_no", "qr_token", "breeder", "origin")


def falcon_view(f: Falcon, user: User) -> dict:
    """Serialise a falcon, redacting identity / ownership fields for roles without access."""
    d = f.as_dict()
    if not can(user, "identity.read"):
        for k in IDENTITY_FIELDS:
            d[k] = None
        d["identity_redacted"] = True
    d["shared_with_me"] = f.org_id != user.org_id
    return d


def audit(db: Session, user: User | None, action: str, entity: str | None = None, entity_id: int | None = None,
          detail: str | None = None) -> None:
    db.add(AuditLog(user_id=user.id if user else None, action=action, entity=entity, entity_id=entity_id, detail=detail))
