"""Telemetry ingest: quality scoring, storage, online flight detection, zone events, position status."""
from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .. import config
from ..analytics import flight as flight_engine
from ..analytics import health
from ..models import (Device, DeviceAssignment, Falcon, Flight, TelemetryPoint, TimelineEvent, TrainingSession,
                      WeightRecord, Zone, DERIVED, MEASURED, now)
from .adapters import Fix

AIRBORNE_SPEED = 3.0        # m/s ground speed treated as "in flight"
FLIGHT_GAP_S = 90           # no airborne fix for this long closes the flight
MIN_FLIGHT_S = 20
MAX_PLAUSIBLE_SPEED = 110.0  # m/s — above the fastest documented falcon stoops; flagged, not deleted


def score(fix: Fix, prev: TelemetryPoint | Fix | None) -> tuple[float, list[str]]:
    """Fix quality 0..1 and flags. Bad fixes are kept (and labelled), never silently dropped."""
    flags: list[str] = []
    if fix.ts > now() + timedelta(minutes=5):          # device clock ahead of server time: not trustworthy
        return 0.0, ["clock_in_future"]
    if fix.lat is None or fix.lon is None or fix.fix == "none":
        return 0.0, ["no_fix"]
    if not (-90 <= fix.lat <= 90 and -180 <= fix.lon <= 180) or (fix.lat == 0 and fix.lon == 0):
        return 0.0, ["invalid_position"]
    q = 1.0
    if fix.hdop is not None:
        q *= 1.0 if fix.hdop <= 1.5 else 0.8 if fix.hdop <= 3 else 0.5 if fix.hdop <= 6 else 0.25
        if fix.hdop > 3:
            flags.append("high_hdop")
    else:
        q *= 0.85
        flags.append("no_hdop")
    if fix.sats is not None and fix.sats < 5:
        q *= 0.6
        flags.append("few_sats")
    if fix.fix == "2d":
        q *= 0.7
        flags.append("2d_fix")
    if fix.speed_mps is not None and fix.speed_mps > MAX_PLAUSIBLE_SPEED:
        q *= 0.2
        flags.append("implausible_speed")
    if prev is not None and prev.lat is not None and prev.ts and fix.ts > prev.ts:
        dt = (fix.ts - prev.ts).total_seconds()
        d = float(flight_engine.haversine(prev.lat, prev.lon, fix.lat, fix.lon))
        if dt < 600 and d / dt > MAX_PLAUSIBLE_SPEED:
            q *= 0.2
            flags.append("position_jump")
    return round(q, 3), flags


def accuracy_m(hdop: float | None) -> float | None:
    """Rough horizontal accuracy estimate (HDOP × ~5 m UERE) — an estimate, not a device guarantee."""
    return None if hdop is None else round(hdop * 5.0, 1)


def active_assignment(db: Session, device_id: int, at: datetime | None = None) -> DeviceAssignment | None:
    q = select(DeviceAssignment).where(DeviceAssignment.device_id == device_id, DeviceAssignment.end.is_(None),
                                       DeviceAssignment.review_status != "rejected").order_by(DeviceAssignment.start.desc())
    return db.scalar(q)


def _to_point(fix: Fix, device: Device, falcon_id: int | None, q: float, flags: list[str], simulated: bool) -> TelemetryPoint:
    return TelemetryPoint(
        device_id=device.id, falcon_id=falcon_id, ts=fix.ts, lat=fix.lat, lon=fix.lon, alt_m=fix.alt_m,
        alt_source=fix.alt_source, speed_mps=fix.speed_mps, speed_source="gnss" if fix.speed_mps is not None else None,
        heading_deg=fix.heading_deg, hdop=fix.hdop, sats=fix.sats, fix=fix.fix, battery_pct=fix.battery_pct,
        temp_c=fix.temp_c, acc_g=fix.acc_g, gyro_dps=fix.gyro_dps, rssi=fix.rssi, link=fix.link, quality=q,
        flags=",".join(flags) or None, simulated=simulated)


def _pt_dict(p: TelemetryPoint) -> dict:
    return {"ts": p.ts, "lat": p.lat, "lon": p.lon, "alt_m": p.alt_m, "speed_mps": p.speed_mps,
            "heading_deg": p.heading_deg, "acc_g": p.acc_g, "quality": p.quality, "alt_source": p.alt_source}


def finalize_flight(db: Session, fl: Flight, evaluate: bool = True) -> Flight | None:
    """Close a flight: compute metrics, link a training session, write the timeline."""
    pts = db.scalars(select(TelemetryPoint).where(TelemetryPoint.flight_id == fl.id, TelemetryPoint.ts <= fl.end)
                     .order_by(TelemetryPoint.ts)).all()
    if (fl.end - fl.start).total_seconds() < MIN_FLIGHT_S or len(pts) < 5:
        db.execute(update(TelemetryPoint).where(TelemetryPoint.flight_id == fl.id).values(flight_id=None))
        db.delete(fl)
        db.flush()
        return None
    db.execute(update(TelemetryPoint).where(TelemetryPoint.flight_id == fl.id, TelemetryPoint.ts > fl.end).values(flight_id=None))
    res = flight_engine.compute([_pt_dict(p) for p in pts])
    fl.metrics = {**res["metrics"], "_phases": res["phases"], "_quality": res["quality"]}
    fl.events = res["events"]
    fl.data_quality = res["quality"]["score"]
    good = [p for p in pts if p.lat is not None and p.quality >= 0.3]
    if good:
        fl.launch_lat, fl.launch_lon = good[0].lat, good[0].lon
        fl.recovery_lat, fl.recovery_lon = good[-1].lat, good[-1].lon
    fl.open = False
    if fl.session_id is None:
        s = db.scalar(select(TrainingSession).where(
            TrainingSession.falcon_id == fl.falcon_id, TrainingSession.start >= fl.start - timedelta(minutes=45),
            TrainingSession.start <= fl.end + timedelta(minutes=10)).order_by(TrainingSession.start))
        if s:
            fl.session_id = s.id
    dur = res["metrics"].get("duration_s", {}).get("value", 0)
    db.add(TimelineEvent(falcon_id=fl.falcon_id, ts=fl.start, kind="flight", provenance=DERIVED, ref_type="flight",
                         ref_id=fl.id, title=f"Tracked flight — {dur / 60:.1f} min",
                         detail="Flight segment detected from tracker telemetry." + (" (simulated demo data)" if fl.simulated else "")))
    db.flush()
    if evaluate:
        f = db.get(Falcon, fl.falcon_id)
        if f:
            health.evaluate(db, f, at=max(fl.end, now()) if not fl.simulated else None)
    return fl


def _zone_events(db: Session, falcon: Falcon, prev: TelemetryPoint | None, cur: TelemetryPoint) -> None:
    if prev is None or prev.lat is None or cur.lat is None or cur.quality < 0.5:
        return
    for z in db.scalars(select(Zone).where(Zone.org_id == falcon.org_id, Zone.kind.in_(["notify_exit", "notify_enter", "home"]))).all():
        was = float(flight_engine.haversine(z.lat, z.lon, prev.lat, prev.lon)) <= z.radius_m
        isin = float(flight_engine.haversine(z.lat, z.lon, cur.lat, cur.lon)) <= z.radius_m
        if was and not isin and z.kind in ("notify_exit", "home"):
            health.notify(db, falcon.org_id, falcon.id, "zone", "notice", f"{falcon.name} left zone “{z.name}”",
                          f"Reported position at {cur.ts:%H:%M:%S} UTC is outside the zone boundary.",
                          key=f"zone:{falcon.id}:{z.id}:exit:{cur.ts:%Y%m%d%H}")
        if isin and not was and z.kind == "notify_enter":
            health.notify(db, falcon.org_id, falcon.id, "zone", "notice", f"{falcon.name} entered zone “{z.name}”",
                          f"Reported position at {cur.ts:%H:%M:%S} UTC.", key=f"zone:{falcon.id}:{z.id}:enter:{cur.ts:%Y%m%d%H}")


def ingest(db: Session, device: Device, fixes: list[Fix], simulated: bool = False) -> dict:
    """Store fixes from one device and update live flight state. Returns a small receipt."""
    if not fixes:
        return {"accepted": 0}
    fixes = sorted(fixes, key=lambda f: f.ts)
    asg = active_assignment(db, device.id)
    falcon = db.get(Falcon, asg.falcon_id) if asg else None
    prev = db.scalar(select(TelemetryPoint).where(TelemetryPoint.device_id == device.id).order_by(TelemetryPoint.ts.desc()))
    fl = db.scalar(select(Flight).where(Flight.falcon_id == falcon.id, Flight.open.is_(True))) if falcon else None
    flagged = 0
    closed = []
    for fx in fixes:
        q, flags = score(fx, prev)
        flagged += bool(flags)
        p = _to_point(fx, device, falcon.id if falcon else None, q, flags, simulated)
        db.add(p)
        if falcon:
            airborne = q >= 0.4 and (fx.speed_mps or 0) >= AIRBORNE_SPEED
            if fl and (fx.ts - fl.end).total_seconds() > FLIGHT_GAP_S:
                closed.append(fl)
                fl = None
            if fl is None and airborne:
                fl = Flight(falcon_id=falcon.id, device_id=device.id, start=fx.ts, end=fx.ts, open=True, simulated=simulated)
                db.add(fl)
                db.flush()
            if fl:
                p.flight_id = fl.id
                if airborne:
                    fl.end = fx.ts
            _zone_events(db, falcon, prev if isinstance(prev, TelemetryPoint) else None, p)
        prev = p
    last = fixes[-1]
    if device.last_seen is None or last.ts >= device.last_seen:
        device.last_seen = last.ts
        if last.battery_pct is not None:
            device.battery_pct = last.battery_pct
            if last.battery_pct <= 15 and falcon:
                health.notify(db, device.org_id, falcon.id, "battery", "warning",
                              f"Tracker battery low ({last.battery_pct:.0f}%) — {falcon.name}",
                              f"Device {device.serial}.", key=f"batt:{device.id}:{last.ts:%Y%m%d}")
        device.last_link, device.last_rssi = last.link or device.last_link, last.rssi
    db.flush()
    for c in closed:
        finalize_flight(db, c)
    db.commit()
    return {"accepted": len(fixes), "flagged": flagged, "falcon_id": falcon.id if falcon else None,
            "flight_open": bool(fl), "note": None if falcon else "Device is not assigned to a falcon; fixes stored unlinked."}


def sweep(db: Session) -> None:
    """Close flights whose last airborne fix is older than the gap (called lazily on reads)."""
    cutoff = now() - timedelta(seconds=FLIGHT_GAP_S)
    stale = db.scalars(select(Flight).where(Flight.open.is_(True), Flight.end < cutoff)).all()
    for fl in stale:
        finalize_flight(db, fl)
    if stale:
        db.commit()


def position_status(db: Session, falcon: Falcon) -> dict:
    """Current / last-known position with an honest freshness label.

    A missing or old fix is reported as exactly that. It is never presented as the bird being lost.
    """
    asg = db.scalar(select(DeviceAssignment).where(DeviceAssignment.falcon_id == falcon.id, DeviceAssignment.end.is_(None))
                    .order_by(DeviceAssignment.start.desc()))
    if not asg:
        return {"state": "no_device", "label": "No tracker assigned",
                "explain": "This falcon has no tracking device assigned, so no position is available."}
    dev = db.get(Device, asg.device_id)
    out: dict = {"device": {"id": dev.id, "serial": dev.serial, "model": dev.model, "battery_pct": dev.battery_pct,
                            "last_seen": dev.last_seen.isoformat() + "Z" if dev.last_seen else None,
                            "link": dev.last_link, "rssi": dev.last_rssi, "tx_interval_s": dev.tx_interval_s},
                 "assignment": {"id": asg.id, "review_status": asg.review_status, "mass_ratio": asg.mass_ratio}}
    last_any = db.scalar(select(TelemetryPoint).where(TelemetryPoint.falcon_id == falcon.id).order_by(TelemetryPoint.ts.desc()))
    last_fix = db.scalar(select(TelemetryPoint).where(TelemetryPoint.falcon_id == falcon.id, TelemetryPoint.lat.is_not(None),
                                                      TelemetryPoint.quality >= 0.3).order_by(TelemetryPoint.ts.desc()))
    if not last_fix:
        out.update(state="unavailable", label="No position received yet",
                   explain="The tracker has not reported a usable position. This says nothing about where the bird is.")
        return out
    t = now()
    age = (t - last_fix.ts).total_seconds()
    live_window = max(15.0, 3 * (dev.tx_interval_s or 5))
    connected = dev.last_seen is not None and (t - dev.last_seen).total_seconds() <= live_window
    if age <= live_window:
        state, label = "live", "Live"
        explain = "Position reported within the tracker's normal reporting interval."
    elif connected:
        state, label = "no_fix", "Tracker connected — no current GNSS fix"
        explain = ("The tracker is still reporting but without a usable position (e.g. sky view blocked). "
                   "Showing the last known position.")
    elif age <= 1800:
        state, label = "recent", "Last known position"
        explain = "No report within the normal interval. Showing the last reported position."
    else:
        state, label = "stale", "Stale — last known position"
        explain = ("No report for a long time. Common causes: tracker switched off or removed, battery empty, "
                   "no cellular / radio coverage, or the bird is indoors. A missing signal is not evidence that "
                   "the falcon is lost — check the tracker and the bird's known location first.")
    fl = db.scalar(select(Flight).where(Flight.falcon_id == falcon.id, Flight.open.is_(True)))
    out.update(
        state=state, label=label, explain=explain, age_s=round(age), in_flight=bool(fl) and state == "live",
        flight_id=fl.id if fl else None, simulated=last_fix.simulated,
        position={"lat": last_fix.lat, "lon": last_fix.lon, "ts": last_fix.ts.isoformat() + "Z",
                  "alt_m": last_fix.alt_m, "alt_source": last_fix.alt_source, "speed_mps": last_fix.speed_mps,
                  "heading_deg": last_fix.heading_deg, "hdop": last_fix.hdop, "sats": last_fix.sats,
                  "accuracy_m": accuracy_m(last_fix.hdop), "quality": last_fix.quality, "flags": last_fix.flags,
                  "provenance": MEASURED},
        last_report_ts=last_any.ts.isoformat() + "Z" if last_any else None)
    if fl and state == "live":
        pts = db.scalars(select(TelemetryPoint).where(TelemetryPoint.flight_id == fl.id).order_by(TelemetryPoint.ts)).all()
        good = [p for p in pts if p.lat is not None and p.quality >= 0.3]
        dist = sum(float(flight_engine.haversine(a.lat, a.lon, b.lat, b.lon)) for a, b in zip(good, good[1:]))
        out["live_flight"] = {"duration_s": round((fl.end - fl.start).total_seconds()), "distance_m": round(dist),
                              "start": fl.start.isoformat() + "Z", "track": [[p.lat, p.lon] for p in good[-600:]],
                              "provenance": DERIVED}
    return out


def welfare_check(db: Session, device: Device, falcon: Falcon) -> dict:
    """Mass-ratio screening for a device/bird pairing. Informational only — it can raise a
    warning or block, but it can never declare a device safe."""
    w = db.scalar(select(WeightRecord).where(WeightRecord.falcon_id == falcon.id).order_by(WeightRecord.ts.desc()))
    base = {"device_mass_g": device.mass_g, "bird_weight_g": w.weight_g if w else None, "ratio": None,
            "warn_ratio": config.DEVICE_MASS_WARN_RATIO, "block_ratio": config.DEVICE_MASS_BLOCK_RATIO,
            "disclaimer": "A mass ratio alone never shows that a tracker is safe. Weight, balance, attachment "
                          "method and aerodynamic effect must be reviewed for this individual bird by qualified "
                          "falconry and veterinary professionals before the device is fitted."}
    if device.mass_g is None or w is None:
        return {**base, "status": "unknown",
                "message": "Cannot screen: device mass or a recorded bird weight is missing. Record both before fitting."}
    r = device.mass_g / w.weight_g
    base["ratio"] = round(r, 4)
    if r > config.DEVICE_MASS_BLOCK_RATIO:
        return {**base, "status": "blocked",
                "message": f"Device is {r * 100:.1f}% of the bird's last recorded weight — above the "
                           f"{config.DEVICE_MASS_BLOCK_RATIO * 100:.0f}% limit configured for this platform. Assignment is not allowed."}
    if r > config.DEVICE_MASS_WARN_RATIO:
        return {**base, "status": "warning",
                "message": f"Device is {r * 100:.1f}% of the bird's last recorded weight — above the commonly cited "
                           f"{config.DEVICE_MASS_WARN_RATIO * 100:.0f}% guidance. Do not fit without explicit professional approval."}
    return {**base, "status": "review_required",
            "message": f"Device is {r * 100:.1f}% of the bird's last recorded weight. Professional review is still required."}
