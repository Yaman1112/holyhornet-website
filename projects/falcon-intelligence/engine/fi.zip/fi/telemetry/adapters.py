"""Device adapters: turn manufacturer-specific payloads into normalised telemetry fixes.

Adding a tracker manufacturer = adding one adapter class (or, for JSON webhooks, just a
field map on the device record — no code). Every adapter returns a list of ``Fix`` objects.

Supported out of the box
  generic_json    Falcon Intelligence reference JSON (cellular / gateway uplinks)
  nmea            Raw NMEA 0183 sentences (GGA + RMC) from GNSS modules
  lora_compact    20-byte binary frame for LoRa / LoRaWAN uplinks (hex or base64)
  vendor_webhook  Arbitrary vendor JSON, mapped through a per-device field map
"""
from __future__ import annotations

import base64
import struct
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import reduce
from typing import Any


@dataclass
class Fix:
    ts: datetime
    lat: float | None = None
    lon: float | None = None
    alt_m: float | None = None
    alt_source: str | None = None
    speed_mps: float | None = None
    heading_deg: float | None = None
    hdop: float | None = None
    sats: int | None = None
    fix: str | None = None
    battery_pct: float | None = None
    temp_c: float | None = None
    acc_g: float | None = None
    gyro_dps: float | None = None
    rssi: float | None = None
    link: str | None = None
    extra: dict = field(default_factory=dict)


class AdapterError(ValueError):
    pass


def _ts(v: Any) -> datetime:
    """Accept epoch seconds / milliseconds or ISO-8601; return naive UTC."""
    if v is None:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    if isinstance(v, (int, float)):
        if v > 1e11:
            v /= 1000.0
        return datetime.fromtimestamp(v, timezone.utc).replace(tzinfo=None)
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError as e:
        raise AdapterError(f"bad timestamp {v!r}") from e
    return d.astimezone(timezone.utc).replace(tzinfo=None) if d.tzinfo else d


def _f(v: Any) -> float | None:
    try:
        return None if v is None or v == "" else float(v)
    except (TypeError, ValueError):
        return None


def _mag(v: Any) -> float | None:
    if isinstance(v, (list, tuple)) and len(v) == 3:
        try:
            return float(sum(float(c) ** 2 for c in v) ** 0.5)
        except (TypeError, ValueError):
            return None
    return _f(v)


class GenericJSON:
    key = "generic_json"
    description = "Reference JSON uplink (single object or {'fixes': [...]})"
    example = {"ts": "2026-11-13T05:30:00Z", "lat": 24.8291, "lon": 55.3712, "alt": 148.2, "baro_alt": 146.9,
               "spd": 21.4, "hdg": 87, "hdop": 0.9, "sats": 14, "fix": "3d", "batt": 81, "temp": 31.5,
               "acc": [0.1, -0.2, 1.4], "gyro": [12, -40, 8], "rssi": -92, "link": "lte-m"}

    # Standard telemetry interface: long field names are accepted as aliases. Every field except the
    # timestamp is optional - devices differ, and a missing field is stored as "not reported".
    ALIASES = {"timestamp": "ts", "latitude": "lat", "longitude": "lon", "altitude": "alt", "speed": "spd", "heading": "hdg",
               "acceleration": "acc", "battery_level": "batt", "temperature": "temp", "signal_quality": "rssi",
               "positioning_accuracy": "hdop", "satellites": "sats"}

    def decode(self, payload: Any, device=None) -> list[Fix]:
        items = payload.get("fixes", [payload]) if isinstance(payload, dict) else payload
        if not isinstance(items, list):
            raise AdapterError("expected an object or a list of fixes")
        out = []
        for p in items:
            p = {self.ALIASES.get(k, k): v for k, v in p.items()}
            baro = _f(p.get("baro_alt"))
            out.append(Fix(
                ts=_ts(p.get("ts")), lat=_f(p.get("lat")), lon=_f(p.get("lon")),
                alt_m=baro if baro is not None else _f(p.get("alt")),
                alt_source="baro" if baro is not None else ("gnss" if p.get("alt") is not None else None),
                speed_mps=_f(p.get("spd")), heading_deg=_f(p.get("hdg")), hdop=_f(p.get("hdop")),
                sats=int(p["sats"]) if p.get("sats") is not None else None, fix=p.get("fix"),
                battery_pct=_f(p.get("batt")), temp_c=_f(p.get("temp")), acc_g=_mag(p.get("acc")),
                gyro_dps=_mag(p.get("gyro")), rssi=_f(p.get("rssi")), link=p.get("link")))
        return out


class NMEA:
    key = "nmea"
    description = "NMEA 0183 text (GGA for position/altitude, RMC for speed/course/date)"
    example = {"nmea": "$GNRMC,053000.00,A,2449.7460,N,05522.2720,E,41.6,87.0,131126,,,A*45\n"
                       "$GNGGA,053000.00,2449.7460,N,05522.2720,E,1,14,0.9,148.2,M,-30.1,M,,*51",
               "batt": 81}

    @staticmethod
    def _ok(sentence: str) -> bool:
        if "*" not in sentence:
            return False
        body, cs = sentence[1:].split("*", 1)
        try:
            return reduce(lambda a, c: a ^ ord(c), body, 0) == int(cs[:2], 16)
        except ValueError:
            return False

    @staticmethod
    def _deg(v: str, hemi: str) -> float | None:
        if not v:
            return None
        dot = v.index(".") if "." in v else len(v)
        d = float(v[:dot - 2]) + float(v[dot - 2:]) / 60.0
        return -d if hemi in ("S", "W") else d

    def decode(self, payload: Any, device=None) -> list[Fix]:
        text = payload.get("nmea", "") if isinstance(payload, dict) else str(payload)
        cur: dict[str, dict] = {}
        bad = 0
        for line in text.replace("\r", "").split("\n"):
            line = line.strip()
            if not line.startswith("$"):
                continue
            if not self._ok(line):
                bad += 1
                continue
            p = line.split("*")[0].split(",")
            typ, t = p[0][3:], p[1]
            rec = cur.setdefault(t, {})
            if typ == "GGA" and len(p) > 9:
                rec.update(lat=self._deg(p[2], p[3]), lon=self._deg(p[4], p[5]),
                           fix="none" if p[6] in ("", "0") else "3d", sats=int(p[7] or 0),
                           hdop=_f(p[8]), alt=_f(p[9]))
            elif typ == "RMC" and len(p) > 9:
                rec.update(valid=p[2] == "A", lat=self._deg(p[3], p[4]), lon=self._deg(p[5], p[6]),
                           spd=(_f(p[7]) or 0.0) * 0.514444, hdg=_f(p[8]), date=p[9])
        out = []
        for t, r in cur.items():
            if not r.get("date"):
                ts = datetime.now(timezone.utc).replace(tzinfo=None)
            else:
                d = r["date"]
                ts = datetime(2000 + int(d[4:6]), int(d[2:4]), int(d[0:2]), int(t[0:2]), int(t[2:4]), int(float(t[4:])))
            out.append(Fix(ts=ts, lat=r.get("lat"), lon=r.get("lon"), alt_m=r.get("alt"),
                           alt_source="gnss" if r.get("alt") is not None else None, speed_mps=r.get("spd"),
                           heading_deg=r.get("hdg"), hdop=r.get("hdop"), sats=r.get("sats"), fix=r.get("fix"),
                           battery_pct=_f(payload.get("batt")) if isinstance(payload, dict) else None,
                           link=payload.get("link") if isinstance(payload, dict) else None))
        if not out and bad:
            raise AdapterError("all NMEA sentences failed checksum")
        return sorted(out, key=lambda f: f.ts)


class LoRaCompact:
    """20-byte little-endian frame, sized for LoRa SF7–SF9 payload budgets.

      off size field
        0  4   unix time (s)
        4  4   latitude  * 1e7  (int32)
        8  4   longitude * 1e7  (int32)
       12  2   barometric altitude, decimetres above -500 m (uint16)
       14  2   ground speed, cm/s (uint16)
       16  1   heading / 2 (uint8, degrees)
       17  1   battery % (uint8)
       18  1   bits 0-4 HDOP*5 (0.0–6.2) · bits 5-7 fix quality (0 none, 1 2D, 2+ 3D)
       19  1   |acceleration| * 16 (uint8, g)
    """
    key = "lora_compact"
    description = "20-byte binary frame (hex or base64) for LoRa / LoRaWAN uplinks"
    FMT = "<IiiHHBBBB"
    example = {"frame": "<40 hex chars>", "rssi": -108}

    @classmethod
    def encode(cls, f: Fix) -> str:
        hd = min(31, int(round((f.hdop or 0) * 5)))
        fq = {"none": 0, "2d": 1}.get(f.fix or "3d", 2)
        return struct.pack(
            cls.FMT, int(f.ts.replace(tzinfo=timezone.utc).timestamp()), int(round(f.lat * 1e7)),
            int(round(f.lon * 1e7)), max(0, min(65535, int(round(((f.alt_m or 0) + 500) * 10)))),
            max(0, min(65535, int(round((f.speed_mps or 0) * 100)))), int((f.heading_deg or 0) % 360 / 2),
            max(0, min(100, int(f.battery_pct or 0))), hd | (fq << 5), max(0, min(255, int((f.acc_g or 0) * 16)))).hex()

    def decode(self, payload: Any, device=None) -> list[Fix]:
        frames = payload.get("frames") or [payload.get("frame")] if isinstance(payload, dict) else [payload]
        out = []
        for fr in frames:
            if not fr:
                raise AdapterError("missing frame")
            try:
                raw = bytes.fromhex(fr) if len(fr) == 40 else base64.b64decode(fr)
                t, la, lo, alt, spd, hdg, batt, q, acc = struct.unpack(self.FMT, raw)
            except (ValueError, struct.error) as e:
                raise AdapterError(f"bad LoRa frame: {e}") from e
            fq = q >> 5
            out.append(Fix(ts=_ts(t), lat=la / 1e7, lon=lo / 1e7, alt_m=alt / 10 - 500, alt_source="baro",
                           speed_mps=spd / 100, heading_deg=hdg * 2.0, hdop=(q & 31) / 5,
                           fix=["none", "2d"][fq] if fq < 2 else "3d", battery_pct=float(batt), acc_g=acc / 16,
                           rssi=_f(payload.get("rssi")) if isinstance(payload, dict) else None, link="lora"))
        return out


class VendorWebhook:
    """Maps any vendor JSON through ``device.field_map`` — e.g.
    {"ts": "data.time", "lat": "data.position.latitude", "spd": "data.speedKmh", "spd_scale": 0.27778}.
    Dotted paths walk nested objects; ``<field>_scale`` multiplies a value into SI units.
    """
    key = "vendor_webhook"
    description = "Vendor / proprietary JSON mapped by a per-device field map (no code needed)"
    example = {"data": {"time": 1794547800, "position": {"latitude": 24.8291, "longitude": 55.3712}, "speedKmh": 77}}

    @staticmethod
    def _get(obj: Any, path: str) -> Any:
        for part in path.split("."):
            if isinstance(obj, dict):
                obj = obj.get(part)
            elif isinstance(obj, list) and part.isdigit() and int(part) < len(obj):
                obj = obj[int(part)]
            else:
                return None
        return obj

    def decode(self, payload: Any, device=None) -> list[Fix]:
        fmap = (getattr(device, "field_map", None) or {})
        if not fmap:
            raise AdapterError("device has no field_map configured for vendor_webhook")
        norm = {}
        for k, path in fmap.items():
            if k.endswith("_scale"):
                continue
            v = self._get(payload, path)
            scale = fmap.get(f"{k}_scale")
            if scale is not None and _f(v) is not None:
                v = _f(v) * float(scale)
            norm[k] = v
        return GenericJSON().decode(norm)


ADAPTERS = {a.key: a for a in (GenericJSON(), NMEA(), LoRaCompact(), VendorWebhook())}


def describe() -> list[dict]:
    return [{"key": a.key, "description": a.description, "example": a.example,
             "doc": (a.__class__.__doc__ or "").strip()} for a in ADAPTERS.values()]
