"""Track file import: GPX, KML / KMZ and CSV exported from any tracker app.

The file is parsed into the same normalised ``Fix`` objects the live adapters produce, then scored,
stored and split into flights by the same rules. Imported data is labelled as imported — it is a
record of a past flight, never a live position.

Every assumption made while reading a file (time zone, speed units, derived speed) is returned in
the receipt so the user can see how their file was interpreted.
"""
from __future__ import annotations

import csv
import io
import re
import zipfile
from datetime import datetime, timedelta, timezone
from statistics import median
from xml.etree import ElementTree as ET

from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from ..analytics import flight as flight_engine
from ..analytics import health
from ..models import Device, Falcon, Flight, TelemetryPoint, User
from . import ingest
from .adapters import Fix

MAX_BYTES = 20 * 1024 * 1024
MAX_POINTS = 200_000


class ImportError_(ValueError):
    """A file that cannot be imported; the message is shown to the user."""


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def _num(v) -> float | None:
    try:
        return float(str(v).strip().replace(",", ".")) if v not in (None, "") else None
    except ValueError:
        return None


def _time(v: str, offset_h: float, notes: set[str]) -> datetime | None:
    """Parse a timestamp to naive UTC. Naive inputs are taken as local time at the given UTC offset."""
    s = str(v).strip()
    if not s:
        return None
    if re.fullmatch(r"\d{9,13}(\.\d+)?", s):
        x = float(s)
        return datetime.fromtimestamp(x / 1000 if x > 1e11 else x, timezone.utc).replace(tzinfo=None)
    d = None
    try:
        d = datetime.fromisoformat(s.replace("Z", "+00:00").replace(" UTC", "+00:00"))
    except ValueError:
        for fmt in ("%d/%m/%Y %H:%M:%S", "%m/%d/%Y %H:%M:%S", "%d.%m.%Y %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%d-%m-%Y %H:%M:%S"):
            try:
                d = datetime.strptime(s, fmt)
                if fmt.startswith(("%d/", "%m/")):
                    notes.add("Dates written with slashes are ambiguous; they were read as day/month/year first.")
                break
            except ValueError:
                continue
    if d is None:
        return None
    if d.tzinfo:
        return d.astimezone(timezone.utc).replace(tzinfo=None)
    notes.add(f"Timestamps had no time zone and were read as UTC{offset_h:+g} h." if offset_h else
              "Timestamps had no time zone and were read as UTC.")
    return d - timedelta(hours=offset_h)


# --- GPX ------------------------------------------------------------------------------------------
def parse_gpx(root: ET.Element, offset_h: float, notes: set[str]) -> list[Fix]:
    out, untimed = [], 0
    for pt in root.iter():
        if _local(pt.tag) != "trkpt":
            continue
        f = {"lat": _num(pt.get("lat")), "lon": _num(pt.get("lon"))}
        for el in pt.iter():
            k = _local(el.tag)
            if k in ("ele", "time", "speed", "course", "hdop", "sat", "bearing", "heading") and el.text:
                f.setdefault(k, el.text.strip())
        ts = _time(f.get("time", ""), offset_h, notes)
        if ts is None:
            untimed += 1
            continue
        out.append(Fix(ts=ts, lat=f["lat"], lon=f["lon"], alt_m=_num(f.get("ele")), alt_source="gnss" if f.get("ele") else None,
                       speed_mps=_num(f.get("speed")), heading_deg=_num(f.get("course") or f.get("bearing") or f.get("heading")),
                       hdop=_num(f.get("hdop")), sats=int(_num(f.get("sat"))) if _num(f.get("sat")) is not None else None))
    if untimed and not out:
        raise ImportError_("This GPX file has track points but no timestamps. Flight metrics need the time of each point — "
                           "export the track with times, or as a different format.")
    if untimed:
        notes.add(f"{untimed} track points without a timestamp were skipped.")
    if not out and any(_local(e.tag) in ("rtept", "wpt") for e in root.iter()):
        raise ImportError_("This GPX file contains a route or waypoints, not a recorded track.")
    return out


# --- KML ------------------------------------------------------------------------------------------
def parse_kml(root: ET.Element, offset_h: float, notes: set[str]) -> list[Fix]:
    out: list[Fix] = []
    for tr in root.iter():
        if _local(tr.tag) != "track":
            continue
        whens = [e.text for e in tr if _local(e.tag) == "when"]
        coords = [e.text for e in tr if _local(e.tag) == "coord"]
        for w, c in zip(whens, coords):
            p = (c or "").replace(",", " ").split()
            ts = _time(w or "", offset_h, notes)
            if ts and len(p) >= 2:
                out.append(Fix(ts=ts, lat=_num(p[1]), lon=_num(p[0]), alt_m=_num(p[2]) if len(p) > 2 else None,
                               alt_source="gnss" if len(p) > 2 else None))
    if not out:          # placemarks that each carry a time and a point
        for pm in root.iter():
            if _local(pm.tag) != "placemark":
                continue
            when = next((e.text for e in pm.iter() if _local(e.tag) == "when"), None)
            point = next((e for e in pm.iter() if _local(e.tag) == "point"), None)
            c = next((e.text for e in point.iter() if _local(e.tag) == "coordinates"), None) if point is not None else None
            ts = _time(when or "", offset_h, notes) if when else None
            if ts and c:
                p = c.strip().split(",")
                if len(p) >= 2:
                    out.append(Fix(ts=ts, lat=_num(p[1]), lon=_num(p[0]), alt_m=_num(p[2]) if len(p) > 2 else None,
                                   alt_source="gnss" if len(p) > 2 else None))
    if not out:
        if any(_local(e.tag) == "linestring" for e in root.iter()):
            raise ImportError_("This KML file contains a drawn path without timestamps. Flight metrics need the time of each "
                               "point — export the flight as a timed track (KML gx:Track), GPX or CSV instead.")
        raise ImportError_("No timed track was found in this KML file.")
    return out


# --- CSV ------------------------------------------------------------------------------------------
COLS = {
    "ts": ["timestamp", "time", "datetime", "date_time", "utc", "utc_time", "date/time", "gps_time", "ts", "date time"],
    "date": ["date"], "clock": ["time_of_day", "clock"],
    "lat": ["latitude", "lat", "y"], "lon": ["longitude", "lon", "lng", "long", "x"],
    "alt": ["altitude", "alt", "ele", "elevation", "height", "altitude_m", "alt_m", "gps_altitude"],
    "spd": ["speed", "spd", "ground_speed", "groundspeed", "velocity"],
    "hdg": ["heading", "course", "bearing", "hdg", "direction"],
    "hdop": ["hdop", "positioning_accuracy"], "sats": ["satellites", "sats", "sat", "num_sats"],
    "batt": ["battery", "battery_level", "batt", "battery_pct"], "temp": ["temperature", "temp"],
}
SPEED_UNITS = [(r"km/?h|kph|kmh", 1 / 3.6, "km/h"), (r"mph", 0.44704, "mph"), (r"knot|kts?\b|kn\b", 0.514444, "knots"), (r"m/?s|mps", 1.0, "m/s")]


def parse_csv(text: str, offset_h: float, notes: set[str]) -> list[Fix]:
    sample = text[:4000]
    delim = max(",;\t|", key=lambda d: sample.count(d))
    rows = list(csv.reader(io.StringIO(text), delimiter=delim))
    rows = [r for r in rows if any(c.strip() for c in r)]
    if len(rows) < 2:
        raise ImportError_("This CSV file has no data rows.")
    head = [h.strip().lower().lstrip("﻿") for h in rows[0]]
    idx: dict[str, int] = {}
    spd_scale, spd_unit = 1.0, None
    for i, h in enumerate(head):
        base = re.sub(r"[\s\-]+", "_", re.sub(r"[\(\[].*?[\)\]]", "", h)).strip("_")
        for key, names in COLS.items():
            if key not in idx and (base in names or h in names):
                idx[key] = i
                if key == "spd":
                    for pat, scale, name in SPEED_UNITS:
                        if re.search(pat, h):
                            spd_scale, spd_unit = scale, name
                            break
    if "date" in idx and "ts" in idx and head[idx["ts"]] == "time":        # separate date and time columns
        idx["clock"] = idx.pop("ts")
    if "lat" not in idx or "lon" not in idx or not ("ts" in idx or ("date" in idx and "clock" in idx)):
        raise ImportError_("Could not find the needed columns. A CSV needs a header row with a time column "
                           "(timestamp / time / datetime, or date + time) and latitude and longitude columns. "
                           f"Columns found: {', '.join(h for h in head if h) or 'none'}.")
    if "spd" in idx:
        notes.add(f"Speed column read as {spd_unit}." if spd_unit else "Speed column has no unit in its header and was read as metres per second.")

    def cell(r, k):
        i = idx.get(k)
        return r[i].strip() if i is not None and i < len(r) else ""
    out, bad = [], 0
    for r in rows[1:]:
        raw = cell(r, "ts") if "ts" in idx else f"{cell(r, 'date')} {cell(r, 'clock')}"
        ts, lat, lon = _time(raw, offset_h, notes), _num(cell(r, "lat")), _num(cell(r, "lon"))
        if ts is None or lat is None or lon is None:
            bad += 1
            continue
        spd = _num(cell(r, "spd"))
        sats = _num(cell(r, "sats"))
        out.append(Fix(ts=ts, lat=lat, lon=lon, alt_m=_num(cell(r, "alt")), alt_source="gnss" if cell(r, "alt") else None,
                       speed_mps=spd * spd_scale if spd is not None else None, heading_deg=_num(cell(r, "hdg")),
                       hdop=_num(cell(r, "hdop")), sats=int(sats) if sats is not None else None,
                       battery_pct=_num(cell(r, "batt")), temp_c=_num(cell(r, "temp"))))
    if bad:
        notes.add(f"{bad} rows without a readable time or position were skipped.")
    if not out:
        raise ImportError_("No row in this CSV had a readable time and position.")
    return out


def parse(filename: str, data: bytes, offset_h: float = 0.0) -> tuple[str, list[Fix], set[str]]:
    """Detect the format and return (format, fixes sorted by time, notes)."""
    if len(data) > MAX_BYTES:
        raise ImportError_("File is larger than 20 MB.")
    notes: set[str] = set()
    fmt = None
    if data[:2] == b"PK":                                   # KMZ = zipped KML
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                name = next((n for n in z.namelist() if n.lower().endswith(".kml")), None)
                if not name or z.getinfo(name).file_size > MAX_BYTES:
                    raise ImportError_("This archive does not contain a usable KML file.")
                data, fmt = z.read(name), "KMZ"
        except zipfile.BadZipFile as e:
            raise ImportError_("This file looks like a zip archive but could not be opened.") from e
    text = data.decode("utf-8-sig", errors="replace")
    head = text[:2000].lower()
    if "<gpx" in head or "<kml" in head or head.lstrip().startswith("<?xml"):
        if "<!doctype" in text.lower() or "<!entity" in text.lower():
            raise ImportError_("This file contains XML document-type declarations, which are not accepted.")
        try:
            root = ET.fromstring(text)
        except ET.ParseError as e:
            raise ImportError_(f"The file is not valid XML ({e}).") from e
        if _local(root.tag) == "gpx":
            fmt, fixes = "GPX", parse_gpx(root, offset_h, notes)
        elif _local(root.tag) == "kml":
            fmt, fixes = fmt or "KML", parse_kml(root, offset_h, notes)
        else:
            raise ImportError_("This XML file is neither GPX nor KML.")
    else:
        fmt, fixes = "CSV", parse_csv(text, offset_h, notes)
    fixes = [f for f in fixes if f.lat is not None and f.lon is not None]
    if not fixes:
        raise ImportError_("No timed positions were found in this file.")
    if len(fixes) > MAX_POINTS:
        raise ImportError_(f"The file has {len(fixes):,} points; the limit is {MAX_POINTS:,}. Split it into smaller files.")
    fixes.sort(key=lambda f: f.ts)
    return fmt, fixes, notes


def import_track(db: Session, falcon: Falcon, user: User, filename: str, data: bytes, source_label: str,
                 offset_h: float = 0.0) -> dict:
    fmt, fixes, notes = parse(filename, data, offset_h)
    # one hidden "device" per organisation holds imported points, so they are never mixed with a live tracker's reports
    dev = db.scalar(select(Device).where(Device.org_id == falcon.org_id, Device.protocol == "file_import"))
    if not dev:
        dev = Device(org_id=falcon.org_id, serial=f"FILE-IMPORT-{falcon.org_id}", model="Imported track files",
                     protocol="file_import", status="import-only", notes="Holds positions imported from files. Not a physical tracker.")
        db.add(dev)
        db.flush()
    existing = set(db.scalars(select(TelemetryPoint.ts).where(TelemetryPoint.falcon_id == falcon.id, TelemetryPoint.ts >= fixes[0].ts,
                                                              TelemetryPoint.ts <= fixes[-1].ts)).all())
    fresh = [f for f in fixes if f.ts not in existing]
    dup = len(fixes) - len(fresh)
    receipt = {"format": fmt, "filename": filename, "points_in_file": len(fixes), "duplicates_skipped": dup, "accepted": len(fresh),
               "from": fixes[0].ts.isoformat() + "Z", "to": fixes[-1].ts.isoformat() + "Z", "flights": [], "flagged": 0}
    if not fresh:
        receipt["notes"] = sorted(notes | {"Every point in this file is already stored for this falcon; nothing was imported."})
        return receipt
    intervals = [(b.ts - a.ts).total_seconds() for a, b in zip(fresh, fresh[1:]) if b.ts > a.ts]
    step = median(intervals) if intervals else 1.0
    gap = max(ingest.FLIGHT_GAP_S, 4 * step)
    if not any(f.speed_mps is not None for f in fresh):
        notes.add("The file has no speed values; speed was derived from the distance between points.")
    if step > 30:
        notes.add(f"Points are about {step:.0f} s apart. Speeds, turns and climb rates from sparse tracks are rough.")
    prev: Fix | None = None
    cur: list[TelemetryPoint] = []
    segments: list[list[TelemetryPoint]] = []
    last_air: datetime | None = None
    pts = []
    for fx in fresh:
        q, flags = ingest.score(fx, prev)
        receipt["flagged"] += bool(flags)
        p = ingest._to_point(fx, dev, falcon.id, q, flags + ["imported"], False)
        p.link = "file_import"
        spd = fx.speed_mps
        if spd is None and prev is not None and fx.ts > prev.ts:
            spd = float(flight_engine.haversine(prev.lat, prev.lon, fx.lat, fx.lon)) / (fx.ts - prev.ts).total_seconds()
        air = q >= 0.4 and (spd or 0) >= ingest.AIRBORNE_SPEED
        if cur and last_air and (fx.ts - last_air).total_seconds() > gap:
            segments.append((cur, last_air))
            cur, last_air = [], None
        if air or cur:
            cur.append(p)
            if air:
                last_air = fx.ts
        pts.append(p)
        prev = fx
    if cur:
        segments.append((cur, last_air))
    db.add_all(pts)
    db.flush()
    src = {"type": "file_import", "format": fmt, "filename": filename, "label": source_label or "not stated",
           "uploaded_by": user.name, "notes": sorted(notes)}
    for seg, end in segments:          # a flight runs from its first to its last airborne point
        fl = Flight(falcon_id=falcon.id, device_id=dev.id, start=seg[0].ts, end=end, open=True, simulated=False)
        db.add(fl)
        db.flush()
        for p in seg:
            p.flight_id = fl.id
        db.flush()
        done = ingest.finalize_flight(db, fl, evaluate=False)
        if done:
            done.metrics = {**(done.metrics or {}), "_source": src}
            flag_modified(done, "metrics")
            receipt["flights"].append({"id": done.id, "start": done.start.isoformat() + "Z",
                                       "duration_s": (done.metrics.get("duration_s") or {}).get("value")})
    if not receipt["flights"]:
        notes.add("No flight was detected: the track never reached flight speed for long enough. The positions were stored without a flight.")
    health.evaluate(db, falcon)
    receipt["notes"] = sorted(notes)
    return receipt
