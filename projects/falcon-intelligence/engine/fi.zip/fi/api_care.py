"""Health & wellness, feeding & weight, training, breeding."""
from __future__ import annotations

import csv
import io
import secrets
from datetime import timedelta
from statistics import mean, median

from fastapi import APIRouter, Body, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from .analytics import baseline, health
from .api_core import need, parse_dt, pick, prov_for
from .auth import audit, can, get_falcon, require
from .models import (DERIVED, USER, VET, Alert, Attachment, BreedingPair, Egg, Falcon, FeedingPlan, FeedingRecord, Flight, HealthRecord,
                     TargetRange, TimelineEvent, TrainingSession, User, WeightRecord, get_db, now)

router = APIRouter(prefix="/api")
VET_ONLY_KINDS = {"exam", "medication", "vaccination", "lab", "treatment", "recommendation"}
HEALTH_KINDS = VET_ONLY_KINDS | {"injury", "recovery", "followup", "observation", "development"}


def _alert_out(a: Alert, f: Falcon | None = None) -> dict:
    d = a.as_dict()
    d["level_name"] = health.LEVELS[a.level]
    if f:
        d["falcon_name"] = f.name
    return d


# --- health -------------------------------------------------------------------------------------
@router.get("/falcons/{fid}/health")
def health_view(fid: int, user: User = Depends(require("health.read")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    recs = db.scalars(select(HealthRecord).where(HealthRecord.falcon_id == fid).order_by(HealthRecord.ts.desc())).all()
    alerts = db.scalars(select(Alert).where(Alert.falcon_id == fid).order_by(Alert.status != "open", Alert.level.desc(), Alert.updated.desc()).limit(60)).all()
    return {"records": [r.as_dict() for r in recs], "alerts": [_alert_out(a) for a in alerts],
            "levels": health.LEVELS, "disclaimer": health.NOT_A_DIAGNOSIS,
            "can_clinical": can(user, "clinical.write"), "falcon": {"id": f.id, "name": f.name}}


@router.post("/falcons/{fid}/health-records")
def add_health(fid: int, body: dict = Body(...), user: User = Depends(require("health.write")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    need(body, "kind", "title")
    if body["kind"] not in HEALTH_KINDS:
        raise HTTPException(422, f"kind must be one of {sorted(HEALTH_KINDS)}")
    if body["kind"] in VET_ONLY_KINDS and not can(user, "clinical.write"):
        raise HTTPException(403, "Only veterinary professionals can enter examinations, medication, vaccination, "
                                 "laboratory, treatment and recommendation records. Upload the clinic's document instead.")
    r = HealthRecord(falcon_id=fid, ts=parse_dt(body.get("ts")), provenance=prov_for(user), recorded_by=user.id,
                     recorder_name=user.name, **pick(body, ["kind", "title", "detail", "data", "severity", "due_date"]))
    db.add(r)
    db.add(TimelineEvent(falcon_id=fid, ts=r.ts, kind="health", title=r.title, provenance=r.provenance))
    db.flush()
    health.evaluate(db, f)
    audit(db, user, "health.add", "health_record", r.id, r.kind)
    db.commit()
    return r.as_dict()


@router.patch("/health-records/{rid}")
def patch_health(rid: int, body: dict = Body(...), user: User = Depends(require("health.write")), db: Session = Depends(get_db)):
    r = db.get(HealthRecord, rid)
    if not r:
        raise HTTPException(404, "Record not found")
    f = get_falcon(db, user, r.falcon_id)
    if r.provenance == VET and not can(user, "clinical.write"):
        raise HTTPException(403, "Veterinary records can only be changed by veterinary professionals")
    if "done" in body:
        r.done = bool(body["done"])
    db.flush()
    health.evaluate(db, f)
    db.commit()
    return r.as_dict()


@router.get("/alerts")
def alerts(status: str = "active", user: User = Depends(require("health.read")), db: Session = Depends(get_db)):
    q = select(Alert, Falcon).join(Falcon, Falcon.id == Alert.falcon_id).where(Falcon.org_id == user.org_id)
    if status == "active":
        q = q.where(Alert.status.in_(["open", "acknowledged", "reviewed"]))
    rows = db.execute(q.order_by(Alert.level.desc(), Alert.updated.desc()).limit(200)).all()
    return [_alert_out(a, f) for a, f in rows]


@router.post("/alerts/{aid}/status")
def alert_status(aid: int, body: dict = Body(...), user: User = Depends(require("health.write")), db: Session = Depends(get_db)):
    a = db.get(Alert, aid)
    if not a:
        raise HTTPException(404, "Alert not found")
    get_falcon(db, user, a.falcon_id)
    st = body.get("status")
    if st not in ("open", "acknowledged", "reviewed", "dismissed"):
        raise HTTPException(422, "Invalid status")
    if st in ("reviewed", "dismissed") and a.level >= 3 and not can(user, "clinical.write"):
        raise HTTPException(403, "Alerts at level 3 or above can only be marked reviewed or dismissed by a veterinary professional")
    a.status, a.updated = st, now()
    audit(db, user, "alert.status", "alert", aid, st)
    db.commit()
    return _alert_out(a)


@router.post("/alerts/{aid}/annotate")
def annotate(aid: int, body: dict = Body(...), user: User = Depends(require("health.write")), db: Session = Depends(get_db)):
    a = db.get(Alert, aid)
    if not a:
        raise HTTPException(404, "Alert not found")
    get_falcon(db, user, a.falcon_id)
    need(body, "note")
    a.annotations = (a.annotations or []) + [{"user": user.name, "role": user.role, "ts": now().isoformat() + "Z",
                                             "note": body["note"], "provenance": prov_for(user)}]
    db.commit()
    return _alert_out(a)


@router.post("/falcons/{fid}/evaluate")
def evaluate(fid: int, user: User = Depends(require("health.read")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    out = health.evaluate(db, f)
    health.followups_due(db, f)
    db.commit()
    return [_alert_out(a) for a in out]


# --- feeding & weight ---------------------------------------------------------------------------
@router.get("/falcons/{fid}/feeding")
def feeding_view(fid: int, days: int = 60, user: User = Depends(require("health.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    since = now() - timedelta(days=days)
    ws = db.scalars(select(WeightRecord).where(WeightRecord.falcon_id == fid, WeightRecord.ts >= since).order_by(WeightRecord.ts)).all()
    fs = db.scalars(select(FeedingRecord).where(FeedingRecord.falcon_id == fid, FeedingRecord.ts >= since).order_by(FeedingRecord.ts.desc())).all()
    tr = db.scalar(select(TargetRange).where(TargetRange.falcon_id == fid, TargetRange.active.is_(True)).order_by(TargetRange.set_at.desc()))
    plans = db.scalars(select(FeedingPlan).where(FeedingPlan.falcon_id == fid).order_by(FeedingPlan.created.desc())).all()
    stats = None
    if len(ws) >= 3:
        vals = [w.weight_g for w in ws]
        last7 = [w.weight_g for w in ws if w.ts >= now() - timedelta(days=7)]
        stats = {"n": len(vals), "median_g": round(median(vals), 1), "min_g": min(vals), "max_g": max(vals),
                 "last7_mean_g": round(mean(last7), 1) if last7 else None, "provenance": DERIVED,
                 "daily_change_pct": [None] + [round(100 * (b - a) / a, 2) for a, b in zip(vals, vals[1:])]}
    return {"weights": [w.as_dict() for w in ws], "feedings": [f.as_dict() for f in fs],
            "target": tr.as_dict() if tr else None, "plans": [p.as_dict() for p in plans], "stats": stats,
            "can_set_target": can(user, "clinical.write"), "can_write": can(user, "feeding.write"),
            "policy": "Feeding plans and weight targets are written by people. The platform records, charts and "
                      "flags unusual changes; it never generates or alters a feeding plan."}


@router.post("/falcons/{fid}/weights")
def add_weight(fid: int, body: dict = Body(...), user: User = Depends(require("feeding.write")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    need(body, "weight_g")
    g = float(body["weight_g"])
    if not 20 <= g <= 5000:
        raise HTTPException(422, "Weight must be between 20 g and 5000 g")
    w = WeightRecord(falcon_id=fid, ts=parse_dt(body.get("ts")), weight_g=g, context=body.get("context"),
                     provenance=prov_for(user), recorded_by=user.id, note=body.get("note"))
    db.add(w)
    db.flush()
    health.evaluate(db, f)
    db.commit()
    return w.as_dict()


@router.post("/falcons/{fid}/feedings")
def add_feeding(fid: int, body: dict = Body(...), user: User = Depends(require("feeding.write")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    need(body, "food_type")
    r = FeedingRecord(falcon_id=fid, ts=parse_dt(body.get("ts")), food_type=body["food_type"],
                      quantity_g=float(body["quantity_g"]) if body.get("quantity_g") not in (None, "") else None,
                      observations=body.get("observations"), recorded_by=user.id)
    db.add(r)
    db.commit()
    return r.as_dict()


@router.post("/falcons/{fid}/feeding-plans")
def add_plan(fid: int, body: dict = Body(...), user: User = Depends(require("feeding.write")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    need(body, "title")
    for p in db.scalars(select(FeedingPlan).where(FeedingPlan.falcon_id == fid, FeedingPlan.active.is_(True))).all():
        p.active = False
    p = FeedingPlan(falcon_id=fid, created_by=user.id, author_role=user.role,
                    vet_approved_by=user.id if user.role == "vet" else None,
                    **pick(body, ["title", "schedule", "start_date", "end_date", "notes"]))
    db.add(p)
    db.add(TimelineEvent(falcon_id=fid, kind="feeding", title=f"Feeding plan recorded by {user.name}", provenance=prov_for(user)))
    audit(db, user, "feeding_plan.create", "falcon", fid)
    db.commit()
    return p.as_dict()


@router.post("/feeding-plans/{pid}/approve")
def approve_plan(pid: int, user: User = Depends(require("clinical.write")), db: Session = Depends(get_db)):
    p = db.get(FeedingPlan, pid)
    if not p:
        raise HTTPException(404, "Plan not found")
    get_falcon(db, user, p.falcon_id)
    p.vet_approved_by = user.id
    db.commit()
    return p.as_dict()


@router.post("/falcons/{fid}/target-range")
def set_target(fid: int, body: dict = Body(...), user: User = Depends(require("clinical.write")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    need(body, "min_g", "max_g")
    lo, hi = float(body["min_g"]), float(body["max_g"])
    if not 20 <= lo < hi <= 5000:
        raise HTTPException(422, "Range must satisfy 20 ≤ min < max ≤ 5000 g")
    for t in db.scalars(select(TargetRange).where(TargetRange.falcon_id == fid, TargetRange.active.is_(True))).all():
        t.active = False
    t = TargetRange(falcon_id=fid, min_g=lo, max_g=hi, context=body.get("context"), note=body.get("note"), set_by=user.id)
    db.add(t)
    db.add(TimelineEvent(falcon_id=fid, kind="health", provenance=VET, title=f"Target weight range set: {lo:.0f}–{hi:.0f} g"))
    db.flush()
    health.evaluate(db, f)
    audit(db, user, "target_range.set", "falcon", fid)
    db.commit()
    return t.as_dict()


# --- training -----------------------------------------------------------------------------------
SESSION_FIELDS = ["trainer_name", "duration_min", "location", "zone_id", "type", "conditions", "observations",
                  "recovery_observation", "notes", "outcome"]


def _session_out(db: Session, s: TrainingSession) -> dict:
    d = s.as_dict()
    fl = db.scalar(select(Flight).where(Flight.session_id == s.id))
    d["flight"] = ({"id": fl.id, "duration_s": baseline._val(fl.metrics, "duration_s"),
                    "distance_m": baseline._val(fl.metrics, "distance_m"),
                    "max_height_m": baseline._val(fl.metrics, "max_height_m")} if fl and not fl.open else None)
    return d


def _training_analytics(sessions: list[dict]) -> dict:
    """Consistency and trend summaries for one falcon (oldest → newest)."""
    if not sessions:
        return {}
    by_week: dict[str, list] = {}
    for s in sessions:
        y, w, _ = parse_dt(s["start"]).isocalendar()
        by_week.setdefault(f"{y}-W{w:02d}", []).append(s)
    weeks = [{"week": k, "sessions": len(v), "completed": sum(x["outcome"] == "completed" for x in v),
              "total_min": round(sum(x["duration_min"] or 0 for x in v), 1),
              "median_flight_s": (median([x["flight"]["duration_s"] for x in v if x["flight"] and x["flight"]["duration_s"]])
                                  if any(x["flight"] for x in v) else None)} for k, v in sorted(by_week.items())]
    outcomes: dict[str, int] = {}
    types: dict[str, int] = {}
    for s in sessions:
        outcomes[s["outcome"] or "not recorded"] = outcomes.get(s["outcome"] or "not recorded", 0) + 1
        types[s["type"]] = types.get(s["type"], 0) + 1
    days = sorted({parse_dt(s["start"]).date() for s in sessions})
    span = (days[-1] - days[0]).days + 1
    return {"weeks": weeks, "outcomes": outcomes, "types": types,
            "consistency": {"days_with_session": len(days), "span_days": span, "share": round(len(days) / span, 2),
                            "longest_gap_days": max([(b - a).days for a, b in zip(days, days[1:])], default=0),
                            "provenance": DERIVED}}


@router.get("/falcons/{fid}/training")
def training_view(fid: int, user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    ss = db.scalars(select(TrainingSession).where(TrainingSession.falcon_id == fid).order_by(TrainingSession.start)).all()
    rows = [_session_out(db, s) for s in ss]
    return {"sessions": list(reversed(rows)), "analytics": _training_analytics(rows)}


@router.get("/falcons/{fid}/training/compare")
def training_compare(fid: int, a_from: str, a_to: str, b_from: str, b_to: str,
                     user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    """Compare the same falcon across two training periods."""
    get_falcon(db, user, fid)

    def period(start, end):
        s0, s1 = parse_dt(start), parse_dt(end) + timedelta(days=1)
        ss = db.scalars(select(TrainingSession).where(TrainingSession.falcon_id == fid, TrainingSession.start >= s0,
                                                      TrainingSession.start < s1)).all()
        fl = db.scalars(select(Flight).where(Flight.falcon_id == fid, Flight.open.is_(False), Flight.start >= s0, Flight.start < s1)).all()
        out = {"from": start, "to": end, "sessions": len(ss), "completed": sum(s.outcome == "completed" for s in ss), "flights": len(fl)}
        for k in ("duration_s", "distance_m", "max_height_m", "avg_speed_mps", "max_speed_mps", "climb_rate_mps"):
            v = [baseline._val(x.metrics, k) for x in fl]
            v = [x for x in v if x is not None]
            out[k] = round(median(v), 1) if v else None
        return out

    a, b = period(a_from, a_to), period(b_from, b_to)
    rows = []
    for k in ("duration_s", "distance_m", "max_height_m", "avg_speed_mps", "max_speed_mps", "climb_rate_mps"):
        rows.append({"metric": k, "label": baseline.LABELS[k], "a": a[k], "b": b[k],
                     "change_pct": round(100 * (b[k] - a[k]) / a[k], 1) if a[k] and b[k] is not None else None})
    return {"a": a, "b": b, "rows": rows, "note": "Medians of tracked flights in each period, same falcon only. "
            "Small periods (few flights) give unreliable comparisons."}


@router.post("/falcons/{fid}/training")
def add_session(fid: int, body: dict = Body(...), user: User = Depends(require("training.write")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    need(body, "type")
    s = TrainingSession(falcon_id=fid, trainer_id=user.id, start=parse_dt(body.get("start")), **pick(body, SESSION_FIELDS))
    s.trainer_name = s.trainer_name or user.name
    entered = {k: v for k, v in (s.conditions or {}).items() if v not in (None, "")}
    if not entered and abs((now() - s.start).total_seconds()) < 3 * 3600:      # only for sessions logged close to real time
        from . import weather
        from .models import Org, Zone
        z = db.get(Zone, s.zone_id) if s.zone_id else db.scalar(select(Zone).where(Zone.org_id == f.org_id, Zone.kind == "training"))
        snap = weather.session_conditions(db, db.get(Org, f.org_id), z.lat, z.lon) if z else None
        s.conditions = snap or None
    else:
        s.conditions = {**entered, "source": "entered by trainer"} if entered else None
    db.add(s)
    db.flush()
    # link a tracked flight that overlaps this session, if one exists and is unlinked
    fl = db.scalar(select(Flight).where(Flight.falcon_id == fid, Flight.session_id.is_(None),
                                        Flight.start >= s.start - timedelta(minutes=10),
                                        Flight.start <= s.start + timedelta(minutes=max(45, s.duration_min or 0))))
    if fl:
        fl.session_id = s.id
    db.add(TimelineEvent(falcon_id=fid, ts=s.start, kind="training", title=f"Training: {s.type}" + (f" — {s.outcome}" if s.outcome else ""),
                         ref_type="training_session", ref_id=s.id))
    health.evaluate(db, f)
    db.commit()
    return _session_out(db, s)


@router.get("/falcons/{fid}/training.csv")
def training_csv(fid: int, user: User = Depends(require("report")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["falcon_id", "falcon", "start_utc", "type", "trainer", "location", "duration_min", "outcome", "temp_c", "wind_kph",
                "sky", "tracked_flight_s", "tracked_distance_m", "max_height_above_launch_m", "observations", "recovery", "notes", "simulated"])
    for s in db.scalars(select(TrainingSession).where(TrainingSession.falcon_id == fid).order_by(TrainingSession.start)).all():
        o = _session_out(db, s)
        c, fl = s.conditions or {}, o["flight"] or {}
        w.writerow([f.code, f.name, s.start.isoformat() + "Z", s.type, s.trainer_name, s.location, s.duration_min, s.outcome,
                    c.get("temp_c"), c.get("wind_kph"), c.get("sky"), fl.get("duration_s"), fl.get("distance_m"),
                    fl.get("max_height_m"), s.observations, s.recovery_observation, s.notes, s.simulated])
    return Response(buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="training_{f.code}.csv"'})


# --- breeding -----------------------------------------------------------------------------------
def _mini(db: Session, fid: int | None) -> dict | None:
    f = db.get(Falcon, fid) if fid else None
    return {"id": f.id, "name": f.name, "code": f.code} if f else None


@router.get("/breeding")
def breeding(user: User = Depends(require("breeding.read")), db: Session = Depends(get_db)):
    out = []
    for p in db.scalars(select(BreedingPair).where(BreedingPair.org_id == user.org_id).order_by(BreedingPair.season.desc())).all():
        eggs = db.scalars(select(Egg).where(Egg.pair_id == p.id).order_by(Egg.label)).all()
        vname = db.get(User, p.verified_by).name if p.verified_by else None
        docs = db.scalars(select(Attachment).where(Attachment.linked_type == "breeding_pair", Attachment.linked_id == p.id)).all()
        out.append({**p.as_dict(), "sire": _mini(db, p.sire_id), "dam": _mini(db, p.dam_id), "verified_by_name": vname,
                    "documents": [{"id": a.id, "filename": a.filename} for a in docs],
                    "eggs": [{**e.as_dict(), "chick": _mini(db, e.chick_falcon_id)} for e in eggs],
                    "summary": {"eggs": len(eggs), "hatched": sum(e.status == "hatched" for e in eggs),
                                "infertile": sum(e.status == "infertile" for e in eggs)}})
    return out


@router.post("/breeding/pairs")
def add_pair(body: dict = Body(...), user: User = Depends(require("breeding.write")), db: Session = Depends(get_db)):
    need(body, "season")
    for k in ("sire_id", "dam_id"):
        if body.get(k):
            get_falcon(db, user, int(body[k]))
    p = BreedingPair(org_id=user.org_id, created_by=user.id, **pick(body, ["sire_id", "dam_id", "season", "facility", "method", "notes"]))
    db.add(p)
    db.commit()
    return p.as_dict()


@router.post("/breeding/pairs/{pid}/verify")
def verify_pair(pid: int, body: dict = Body(...), user: User = Depends(require("breeding.read")), db: Session = Depends(get_db)):
    """Record verification: a second person (vet, admin or facility manager) confirms the breeding record."""
    p = _pair(db, user, pid)
    if user.role not in ("vet", "admin", "facility_manager"):
        raise HTTPException(403, "Breeding records are verified by a veterinarian, administrator or facility manager")
    if p.created_by == user.id:
        raise HTTPException(422, "A record must be verified by someone other than the person who created it")
    need(body, "note")
    p.verified_by, p.verified_at, p.verification_note = user.id, now(), body["note"]
    audit(db, user, "breeding.verify", "breeding_pair", pid)
    db.commit()
    return p.as_dict()


def _pair(db: Session, user: User, pid: int) -> BreedingPair:
    p = db.get(BreedingPair, pid)
    if not p or p.org_id != user.org_id:
        raise HTTPException(404, "Pair not found")
    return p


@router.post("/breeding/pairs/{pid}/eggs")
def add_egg(pid: int, body: dict = Body(...), user: User = Depends(require("breeding.write")), db: Session = Depends(get_db)):
    _pair(db, user, pid)
    need(body, "label")
    e = Egg(pair_id=pid, label=body["label"], laid_date=body.get("laid_date"), incubation_log=[])
    db.add(e)
    db.commit()
    return e.as_dict()


@router.patch("/eggs/{eid}")
def patch_egg(eid: int, body: dict = Body(...), user: User = Depends(require("breeding.write")), db: Session = Depends(get_db)):
    e = db.get(Egg, eid)
    if not e:
        raise HTTPException(404, "Egg not found")
    p = _pair(db, user, e.pair_id)
    if body.get("log_note"):
        e.incubation_log = (e.incubation_log or []) + [{"date": body.get("log_date") or now().date().isoformat(),
                                                        "note": body["log_note"], "mass_g": body.get("mass_g"), "by": user.name}]
    if body.get("status"):
        if body["status"] not in ("incubating", "fertile", "infertile", "hatched", "failed"):
            raise HTTPException(422, "Invalid status")
        e.status = body["status"]
        if e.status == "hatched" and not e.chick_falcon_id:
            e.hatch_date = body.get("hatch_date") or now().date().isoformat()
            dam = db.get(Falcon, p.dam_id) if p.dam_id else None
            n = (db.scalar(select(Falcon.id).order_by(Falcon.id.desc())) or 0) + 1
            chick = Falcon(org_id=user.org_id, code=f"FI-AE-{e.hatch_date[:4]}{n:03d}", name=body.get("chick_name") or f"Chick {e.label}",
                           species_id=dam.species_id if dam else None, sex="unknown", hatch_date=e.hatch_date, category="juvenile",
                           sire_id=p.sire_id, dam_id=p.dam_id, current_location=p.facility, qr_token=secrets.token_urlsafe(16),
                           owner_name=dam.owner_name if dam else None, owner_user_id=dam.owner_user_id if dam else None)
            db.add(chick)
            db.flush()
            e.chick_falcon_id = chick.id
            db.add(TimelineEvent(falcon_id=chick.id, ts=parse_dt(e.hatch_date), kind="hatch", title=f"Hatched (egg {e.label})"))
    db.commit()
    return {**e.as_dict(), "chick": _mini(db, e.chick_falcon_id)}


@router.get("/falcons/{fid}/lineage")
def lineage(fid: int, depth: int = 3, user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)

    def node(i: int | None, d: int):
        f = db.get(Falcon, i) if i else None
        if not f or f.org_id != user.org_id:
            return None
        n = {"id": f.id, "name": f.name, "code": f.code, "sex": f.sex, "hatch_date": f.hatch_date}
        if d > 0:
            n["sire"], n["dam"] = node(f.sire_id, d - 1), node(f.dam_id, d - 1)
        return n

    def ancestors(i: int | None, d: int, acc: dict, gen: int = 1):
        f = db.get(Falcon, i) if i else None
        if not f or d == 0:
            return
        for pid in (f.sire_id, f.dam_id):
            if pid:
                acc.setdefault(pid, []).append(gen)
                ancestors(pid, d - 1, acc, gen + 1)

    f = db.get(Falcon, fid)
    sa, da = {}, {}
    ancestors(f.sire_id, 5, sa)
    ancestors(f.dam_id, 5, da)
    if f.sire_id:
        sa.setdefault(f.sire_id, []).append(0)
    if f.dam_id:
        da.setdefault(f.dam_id, []).append(0)
    common = sorted(set(sa) & set(da))
    return {"tree": node(fid, min(depth, 4)),
            "common_ancestors": [_mini(db, c) for c in common],
            "note": ("Recorded sire and dam lines share an ancestor — review the pairing with a qualified breeding advisor."
                     if common else "No shared ancestor found in the recorded pedigree (records may be incomplete).")
            + " This is a record check only: no genetic health assessment is made without validated genetic data.",
            "provenance": DERIVED}
