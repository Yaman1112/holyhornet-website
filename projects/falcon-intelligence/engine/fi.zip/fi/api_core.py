"""Auth, metadata, falcon identity, attachments, notifications, administration."""
from __future__ import annotations

import io
import re
import secrets
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import config, vision
from .analytics import health
from .auth import (PERMS, audit, can, current_user, falcon_view, get_falcon, granted_falcon_ids, hash_pw, issue_token,
                   new_salt, require, verify_pw)
from .models import (PROVENANCES, ROLES, USER, VET, Alert, Attachment, AuditLog, Falcon, Notification, OwnershipTransfer,
                     SpeciesProfile, TimelineEvent, User, WeightRecord, Zone, get_db, now)
from .telemetry import adapters, ingest

router = APIRouter(prefix="/api")


def parse_dt(v, default: datetime | None = None) -> datetime:
    if not v:
        return default or now()
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        raise HTTPException(422, f"Invalid date/time: {v!r}")
    return d.astimezone(timezone.utc).replace(tzinfo=None) if d.tzinfo else d


def pick(body: dict, fields: list[str]) -> dict:
    return {k: (body[k] if body[k] != "" else None) for k in fields if k in body}


def need(body: dict, *fields: str) -> None:
    missing = [f for f in fields if body.get(f) in (None, "")]
    if missing:
        raise HTTPException(422, f"Missing required field(s): {', '.join(missing)}")


def prov_for(user: User) -> str:
    return VET if user.role == "vet" else USER


# --- auth ---------------------------------------------------------------------------------------
def _user_out(u: User) -> dict:
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role, "title": u.title,
            "permissions": sorted(PERMS.get(u.role, []))}


@router.post("/auth/login")
def login(request: Request, body: dict = Body(...), db: Session = Depends(get_db)):
    from .api_recovery import rate_limit
    rate_limit(request, "login", limit=10)          # slows password guessing
    u = db.scalar(select(User).where(User.email == str(body.get("email", "")).strip().lower()))
    if not u or not u.active or not verify_pw(u, str(body.get("password", ""))):
        raise HTTPException(401, "Incorrect email or password")
    audit(db, u, "login")
    return {"token": issue_token(db, u), "user": _user_out(u)}


@router.get("/auth/demo-accounts")
def demo_accounts(db: Session = Depends(get_db)):
    if not config.DEMO_MODE:
        return {"demo": False, "accounts": []}
    return {"demo": True, "accounts": [{"id": u.id, "name": u.name, "role": u.role, "title": u.title}
                                       for u in db.scalars(select(User).where(User.active.is_(True)).order_by(User.id)).all()]}


@router.post("/auth/demo-login")
def demo_login(body: dict = Body(...), db: Session = Depends(get_db)):
    if not config.DEMO_MODE:
        raise HTTPException(404, "Demo mode is disabled")
    u = db.get(User, int(body.get("user_id", 0)))
    if not u or not u.active:
        raise HTTPException(404, "Unknown demo account")
    audit(db, u, "demo_login")
    return {"token": issue_token(db, u), "user": _user_out(u)}


@router.get("/me")
def me(user: User = Depends(current_user)):
    return _user_out(user)


@router.get("/meta")
def meta(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return {
        "demo": config.DEMO_MODE, "provenances": PROVENANCES, "alert_levels": health.LEVELS, "roles": ROLES,
        "species": [s.as_dict() for s in db.scalars(select(SpeciesProfile).where(SpeciesProfile.org_id == user.org_id)).all()],
        "zones": [z.as_dict() for z in db.scalars(select(Zone).where(Zone.org_id == user.org_id)).all()],
        "users": [{"id": u.id, "name": u.name, "role": u.role} for u in db.scalars(select(User).where(User.org_id == user.org_id)).all()],
        "adapters": adapters.describe(), "physical_checklist": vision.PHYSICAL_CHECKLIST,
        "mass_guidance": {"warn": config.DEVICE_MASS_WARN_RATIO, "block": config.DEVICE_MASS_BLOCK_RATIO},
    }


# --- falcons ------------------------------------------------------------------------------------
FALCON_FIELDS = ["name", "species_id", "subspecies", "strain", "sex", "hatch_date", "age_is_estimate", "origin", "breeder",
                 "current_location", "wingspan_cm", "status", "category", "sire_id", "dam_id", "notes"]
IDENTITY_WRITE = ["owner_name", "owner_user_id", "ring_number", "microchip", "passport_no"]


def falcon_summary(db: Session, f: Falcon, user: User) -> dict:
    d = falcon_view(f, user)
    w = db.scalar(select(WeightRecord).where(WeightRecord.falcon_id == f.id).order_by(WeightRecord.ts.desc()))
    d["latest_weight"] = {"weight_g": w.weight_g, "ts": w.ts.isoformat() + "Z", "provenance": w.provenance} if w else None
    top = db.scalar(select(Alert).where(Alert.falcon_id == f.id, Alert.status.in_(["open", "acknowledged", "reviewed"]))
                    .order_by(Alert.level.desc()))
    d["alert_level"] = top.level if top else None
    d["alert_title"] = top.title if top else None
    if can(user, "telemetry.read"):
        pos = ingest.position_status(db, f)
        d["position_state"], d["position_label"] = pos["state"], pos["label"]
    else:
        d["position_state"], d["position_label"] = "restricted", "Location restricted for your role"
    sp = db.get(SpeciesProfile, f.species_id) if f.species_id else None
    d["species"] = sp.common_name if sp else None
    ph = db.scalar(select(Attachment.id).where(Attachment.falcon_id == f.id, Attachment.kind == "photo").order_by(Attachment.id))
    d["photo_id"] = ph
    return d


@router.get("/falcons")
def list_falcons(user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    ingest.sweep(db)
    fs = db.scalars(select(Falcon).where((Falcon.org_id == user.org_id) | Falcon.id.in_(granted_falcon_ids(db, user)))
                    .order_by(Falcon.id)).all()
    return [falcon_summary(db, f, user) for f in fs]


@router.post("/falcons")
def create_falcon(body: dict = Body(...), user: User = Depends(require("falcon.write")), db: Session = Depends(get_db)):
    need(body, "name")
    data = pick(body, FALCON_FIELDS)
    if can(user, "identity.write"):
        data.update(pick(body, IDENTITY_WRITE))
    n = (db.scalar(select(func.max(Falcon.id))) or 0) + 1
    f = Falcon(org_id=user.org_id, code=f"FI-AE-{datetime.now().year}{n:03d}", qr_token=secrets.token_urlsafe(16), **data)
    db.add(f)
    db.flush()
    db.add(TimelineEvent(falcon_id=f.id, kind="registration", title="Registered on Falcon Intelligence", provenance=USER))
    audit(db, user, "falcon.create", "falcon", f.id)
    db.commit()
    return falcon_summary(db, f, user)


@router.get("/falcons/{fid}")
def get_one(fid: int, user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    d = falcon_summary(db, f, user)
    d["transfers"] = ([t.as_dict() for t in db.scalars(select(OwnershipTransfer).where(OwnershipTransfer.falcon_id == fid)
                                                       .order_by(OwnershipTransfer.date)).all()] if can(user, "identity.read") else None)
    for k in ("sire_id", "dam_id"):
        p = db.get(Falcon, getattr(f, k)) if getattr(f, k) else None
        d[k.replace("_id", "")] = {"id": p.id, "name": p.name, "code": p.code} if p else None
    d["offspring"] = [{"id": c.id, "name": c.name, "code": c.code} for c in
                      db.scalars(select(Falcon).where((Falcon.sire_id == fid) | (Falcon.dam_id == fid))).all()]
    return d


@router.patch("/falcons/{fid}")
def update_falcon(fid: int, body: dict = Body(...), user: User = Depends(require("falcon.write")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    data = pick(body, FALCON_FIELDS)
    ident = pick(body, IDENTITY_WRITE)
    if ident and not can(user, "identity.write"):
        raise HTTPException(403, "Your role cannot edit ownership or identification details")
    for k, v in {**data, **ident}.items():
        setattr(f, k, v)
    audit(db, user, "falcon.update", "falcon", fid, ",".join({**data, **ident}))
    db.commit()
    return falcon_summary(db, f, user)


@router.get("/falcons/{fid}/timeline")
def timeline(fid: int, user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    ev = db.scalars(select(TimelineEvent).where(TimelineEvent.falcon_id == fid).order_by(TimelineEvent.ts.desc()).limit(400)).all()
    hide = set() if can(user, "identity.read") else {"ownership"}
    return [e.as_dict() for e in ev if e.kind not in hide and (e.kind != "health" or can(user, "health.read"))]


@router.post("/falcons/{fid}/timeline")
def add_timeline(fid: int, body: dict = Body(...), user: User = Depends(require("falcon.write")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    need(body, "title")
    e = TimelineEvent(falcon_id=fid, ts=parse_dt(body.get("ts")), kind=body.get("kind") or "note", title=body["title"],
                      detail=body.get("detail"), provenance=prov_for(user))
    db.add(e)
    db.commit()
    return e.as_dict()


@router.post("/falcons/{fid}/transfers")
def add_transfer(fid: int, body: dict = Body(...), user: User = Depends(require("identity.write")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    need(body, "to_owner", "date")
    t = OwnershipTransfer(falcon_id=fid, date=body["date"], from_owner=f.owner_name, to_owner=body["to_owner"],
                          document_ref=body.get("document_ref"), notes=body.get("notes"), recorded_by=user.id)
    f.owner_name, f.owner_user_id = body["to_owner"], None
    db.add(t)
    db.add(TimelineEvent(falcon_id=fid, ts=parse_dt(body["date"]), kind="ownership", title=f"Ownership transferred to {body['to_owner']}"))
    audit(db, user, "falcon.transfer", "falcon", fid)
    db.commit()
    return t.as_dict()


@router.get("/falcons/{fid}/qr.svg")
def qr(fid: int, request: Request, user: User = Depends(require("identity.read")), db: Session = Depends(get_db)):
    import qrcode
    import qrcode.image.svg
    f = get_falcon(db, user, fid)
    url = f"{str(request.base_url).rstrip('/')}/#/id/{f.qr_token}"
    img = qrcode.make(url, image_factory=qrcode.image.svg.SvgPathImage, box_size=12, border=2)
    buf = io.BytesIO()
    img.save(buf)
    return Response(buf.getvalue(), media_type="image/svg+xml", headers={"X-QR-URL": url})


@router.get("/id/{token}")
def qr_lookup(token: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """QR scan target. The QR only carries an opaque token; details need a signed-in, authorised user."""
    f = db.scalar(select(Falcon).where(Falcon.qr_token == token))
    if not f or f.org_id != user.org_id:
        raise HTTPException(404, "No record for this code in your organisation")
    audit(db, user, "qr.lookup", "falcon", f.id)
    db.commit()
    return {"falcon_id": f.id, "name": f.name, "code": f.code}


# --- attachments --------------------------------------------------------------------------------
SAFE = re.compile(r"[^A-Za-z0-9._-]+")
ALLOWED = {"photo": {"image/jpeg", "image/png", "image/webp"},
           "video": {"video/mp4", "video/quicktime", "video/webm", "video/x-msvideo", "video/x-matroska"},
           "document": {"application/pdf", "image/jpeg", "image/png", "text/plain", "text/csv"}}
RESTRICTED_CATS = {"passport", "ownership", "identification", "cites"}


@router.post("/falcons/{fid}/attachments")
async def upload(fid: int, file: UploadFile = File(...), kind: str = Form("photo"), category: str = Form("gallery"),
                 note: str = Form(""), linked_type: str = Form(""), linked_id: int = Form(0),
                 user: User = Depends(require("falcon.write")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    if kind not in ALLOWED:
        raise HTTPException(422, "kind must be photo, video or document")
    if (file.content_type or "") not in ALLOWED[kind]:
        raise HTTPException(415, f"File type {file.content_type!r} is not accepted for {kind} uploads")
    restricted = category in RESTRICTED_CATS
    if restricted and not can(user, "identity.write"):
        raise HTTPException(403, "Your role cannot upload identity or ownership documents")
    name = SAFE.sub("_", Path(file.filename or "upload").name)[-120:]
    dest = config.UPLOAD_DIR / f"{secrets.token_hex(8)}_{name}"
    size = 0
    with dest.open("wb") as out:
        while chunk := await file.read(1 << 20):
            size += len(chunk)
            if size > config.MAX_UPLOAD_MB << 20:
                out.close()
                dest.unlink(missing_ok=True)
                raise HTTPException(413, f"File is larger than {config.MAX_UPLOAD_MB} MB")
            out.write(chunk)
    a = Attachment(org_id=user.org_id, falcon_id=fid, kind=kind, category=category, filename=name, path=str(dest),
                   mime=file.content_type, size=size, restricted=restricted, note=note or None,
                   linked_type=linked_type or None, linked_id=linked_id or None, uploaded_by=user.id)
    db.add(a)
    db.flush()
    db.add(TimelineEvent(falcon_id=fid, kind="attachment", title=f"{kind.capitalize()} added: {name}", ref_type="attachment", ref_id=a.id))
    audit(db, user, "attachment.upload", "attachment", a.id)
    db.commit()
    return a.as_dict(exclude=("path",))


@router.get("/falcons/{fid}/attachments")
def attachments(fid: int, user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    q = select(Attachment).where(Attachment.falcon_id == fid).order_by(Attachment.created.desc())
    return [a.as_dict(exclude=("path",)) for a in db.scalars(q).all() if not a.restricted or can(user, "identity.read")]


@router.get("/attachments/{aid}/file")
def attachment_file(aid: int, user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    a = db.get(Attachment, aid)
    if not a or a.org_id != user.org_id or (a.restricted and not can(user, "identity.read")):
        raise HTTPException(404, "Not found")
    if not Path(a.path).exists():
        raise HTTPException(410, "File is no longer stored")
    return FileResponse(a.path, media_type=a.mime or "application/octet-stream", filename=a.filename,
                        content_disposition_type="inline")


# --- notifications ------------------------------------------------------------------------------
@router.get("/notifications")
def notifications(user: User = Depends(current_user), db: Session = Depends(get_db)):
    ns = db.scalars(select(Notification).where(Notification.org_id == user.org_id,
                                               (Notification.user_id.is_(None)) | (Notification.user_id == user.id)).order_by(Notification.ts.desc()).limit(100)).all()
    if not can(user, "health.read"):
        ns = [n for n in ns if n.kind not in ("health_alert", "followup_due")]
    return [n.as_dict() for n in ns]


@router.post("/notifications/read")
def read_notifications(body: dict = Body(default={}), user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Notification).where(Notification.org_id == user.org_id, Notification.read.is_(False))
    if body.get("id"):
        q = q.where(Notification.id == int(body["id"]))
    for n in db.scalars(q).all():
        n.read = True
    db.commit()
    return {"ok": True}


# --- administration -----------------------------------------------------------------------------
@router.post("/species")
def add_species(body: dict = Body(...), user: User = Depends(require("admin")), db: Session = Depends(get_db)):
    need(body, "common_name")
    s = SpeciesProfile(org_id=user.org_id, **pick(body, ["common_name", "scientific_name", "category", "ref_mass_min_g", "ref_mass_max_g", "notes"]))
    db.add(s)
    db.commit()
    return s.as_dict()


@router.post("/zones")
def add_zone(body: dict = Body(...), user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    need(body, "name", "lat", "lon", "radius_m")
    if not (-90 <= float(body["lat"]) <= 90 and -180 <= float(body["lon"]) <= 180 and float(body["radius_m"]) > 0):
        raise HTTPException(422, "Invalid zone geometry")
    z = Zone(org_id=user.org_id, **pick(body, ["name", "kind", "lat", "lon", "radius_m", "notes"]))
    db.add(z)
    db.commit()
    return z.as_dict()


@router.delete("/zones/{zid}")
def del_zone(zid: int, user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    z = db.get(Zone, zid)
    if not z or z.org_id != user.org_id:
        raise HTTPException(404, "Not found")
    db.delete(z)
    db.commit()
    return {"ok": True}


@router.get("/users")
def users(user: User = Depends(require("admin")), db: Session = Depends(get_db)):
    return [u.as_dict(exclude=("pw_hash", "salt")) for u in db.scalars(select(User).where(User.org_id == user.org_id)).all()]


@router.post("/users")
def add_user(body: dict = Body(...), user: User = Depends(require("admin")), db: Session = Depends(get_db)):
    need(body, "email", "name", "role", "password")
    if body["role"] not in ROLES:
        raise HTTPException(422, "Unknown role")
    if len(str(body["password"])) < 10:
        raise HTTPException(422, "Password must be at least 10 characters")
    email = str(body["email"]).strip().lower()
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(409, "A user with this email already exists")
    salt = new_salt()
    u = User(org_id=user.org_id, email=email, name=body["name"], role=body["role"], title=body.get("title"), salt=salt,
             pw_hash=hash_pw(str(body["password"]), salt))
    db.add(u)
    audit(db, user, "user.create", "user", None, email)
    db.commit()
    return u.as_dict(exclude=("pw_hash", "salt"))


@router.get("/audit")
def audit_log(user: User = Depends(require("admin")), db: Session = Depends(get_db)):
    names = {u.id: u.name for u in db.scalars(select(User)).all()}
    return [{**a.as_dict(), "user": names.get(a.user_id)} for a in
            db.scalars(select(AuditLog).order_by(AuditLog.ts.desc()).limit(200)).all()]
