"""Overview dashboard, cross-falcon lists, organisations & access grants, settings, weather,
AI assistant + service registry, simulator scenarios, live WebSocket."""
from __future__ import annotations

import asyncio
import json
from datetime import timedelta
from statistics import median

from fastapi import APIRouter, Body, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from . import assistant, config, simulator, weather
from .analytics import baseline, health
from .analytics import flight as flight_engine
from .api_core import need, parse_dt
from .api_tracking import overview_data
from .auth import PERMS, audit, can, current_user, get_falcon, granted_falcon_ids, require, sha
from .models import (ROLES, USER, Alert, AuthSession, Device, DeviceAssignment, Falcon, FalconAccess, FeedingRecord, Flight,
                     HealthRecord, Org, RecoveryAction, RecoveryCase, SessionLocal, SimRun, TargetRange, TelemetryPoint,
                     TimelineEvent, TrainingSession, User, WeightRecord, Zone, get_db, now)
from .telemetry import ingest

router = APIRouter(prefix="/api")


def _org_falcons(db: Session, user: User) -> list[Falcon]:
    return db.scalars(select(Falcon).where((Falcon.org_id == user.org_id) | Falcon.id.in_(granted_falcon_ids(db, user)))
                      .order_by(Falcon.id)).all()


# --- overview (every number comes from a query; nothing decorative) ------------------------------
@router.get("/overview")
def overview(user: User = Depends(current_user), db: Session = Depends(get_db)):
    ingest.sweep(db)
    fs = _org_falcons(db, user)
    ids = [f.id for f in fs]
    names = {f.id: f.name for f in fs}
    t = now()
    out: dict = {"falcons": len(fs), "generated": t.isoformat() + "Z"}
    if can(user, "telemetry.read"):
        st = [dict(ingest.position_status(db, f), falcon_id=f.id, name=f.name) for f in fs]
        out["tracking"] = {"with_tracker": sum(s["state"] != "no_device" for s in st), "live": sum(s["state"] == "live" for s in st),
                           "stale": sum(s["state"] == "stale" for s in st)}
        out["latest_locations"] = [{"falcon_id": s["falcon_id"], "name": s["name"], "state": s["state"], "label": s["label"],
                                    "age_s": s.get("age_s"), "position": s.get("position")} for s in st if s["state"] != "no_device"]
        fl = db.scalars(select(Flight).where(Flight.falcon_id.in_(ids), Flight.open.is_(False)).order_by(Flight.start.desc()).limit(8)).all()
        out["recent_flights"] = [{"id": x.id, "falcon_id": x.falcon_id, "name": names[x.falcon_id], "start": x.start.isoformat() + "Z",
                                  "duration_s": baseline._val(x.metrics, "duration_s"), "max_height_m": baseline._val(x.metrics, "max_height_m"),
                                  "simulated": x.simulated} for x in fl]
        out["flights_7d"] = db.scalar(select(func.count(Flight.id)).where(Flight.falcon_id.in_(ids), Flight.start >= t - timedelta(days=7)))
    if can(user, "device.read"):
        ds = db.scalars(select(Device).where(Device.org_id == user.org_id, Device.protocol != "file_import")).all()
        asg = {a.device_id: a for a in db.scalars(select(DeviceAssignment).where(DeviceAssignment.end.is_(None))).all()}
        out["devices"] = [{"id": d.id, "serial": d.serial, "battery_pct": d.battery_pct,
                           "last_seen": d.last_seen.isoformat() + "Z" if d.last_seen else None,
                           "falcon": names.get(asg[d.id].falcon_id) if d.id in asg else None,
                           "review_status": asg[d.id].review_status if d.id in asg else None} for d in ds]
        out["pending_fit_reviews"] = sum(1 for d in out["devices"] if d["review_status"] == "pending")
    if can(user, "health.read"):
        al = db.scalars(select(Alert).where(Alert.falcon_id.in_(ids), Alert.status.in_(["open", "acknowledged", "reviewed"]), Alert.level >= 2)
                        .order_by(Alert.level.desc(), Alert.updated.desc())).all()
        out["alerts"] = [{**a.as_dict(), "level_name": health.LEVELS[a.level], "falcon_name": names[a.falcon_id]} for a in al]
    ss = db.scalars(select(TrainingSession).where(TrainingSession.falcon_id.in_(ids), TrainingSession.start >= t - timedelta(days=7))).all()
    out["training_7d"] = {"sessions": len(ss), "completed": sum(s.outcome == "completed" for s in ss),
                          "birds_trained": len({s.falcon_id for s in ss})}
    if can(user, "recovery.read"):
        cs = db.scalars(select(RecoveryCase).where(RecoveryCase.org_id == user.org_id, RecoveryCase.status == "open")).all()
        if user.role == "recovery":
            cs = [c for c in cs if user.id in (c.contacts or [])]
        out["open_recovery_cases"] = [{"id": c.id, "falcon_id": c.falcon_id, "name": names.get(c.falcon_id, "?"),
                                       "opened_at": c.opened_at.isoformat() + "Z"} for c in cs]
    return out


@router.get("/flights/recent")
def recent_flights(days: int = 14, user: User = Depends(require("telemetry.read")), db: Session = Depends(get_db)):
    fs = _org_falcons(db, user)
    names = {f.id: f.name for f in fs}
    fl = db.scalars(select(Flight).where(Flight.falcon_id.in_(list(names)), Flight.open.is_(False),
                                         Flight.start >= now() - timedelta(days=min(days, 90))).order_by(Flight.start.desc()).limit(300)).all()
    per = []
    for f in fs:
        mine = db.scalars(select(Flight).where(Flight.falcon_id == f.id, Flight.open.is_(False)).order_by(Flight.start)).all()
        if not mine:
            continue
        dev = 0
        hist = [x.metrics for x in mine]
        for i in range(max(baseline.MIN_FLIGHTS, len(mine) - 5), len(mine)):
            b = baseline.build(baseline.same_pattern(hist[:i], hist[i])[0])
            dev += any(c["status"] != "typical" for c in baseline.compare(mine[i].metrics or {}, b))
        per.append({"falcon_id": f.id, "name": f.name, "flights": len(mine), "last_flight": mine[-1].start.isoformat() + "Z",
                    "baseline_ready": len(mine) > baseline.MIN_FLIGHTS, "recent_flights_with_deviation": dev})
    return {"per_falcon": per,
            "flights": [{"id": x.id, "falcon_id": x.falcon_id, "name": names[x.falcon_id], "start": x.start.isoformat() + "Z",
                         "duration_s": baseline._val(x.metrics, "duration_s"), "distance_m": baseline._val(x.metrics, "distance_m"),
                         "max_height_m": baseline._val(x.metrics, "max_height_m"), "max_speed_mps": baseline._val(x.metrics, "max_speed_mps"),
                         "pattern": baseline.classify_pattern(x.metrics or {}, (x.metrics or {}).get("_phases"))["label"],
                         "data_quality": x.data_quality, "simulated": x.simulated,
                         "imported": bool((x.metrics or {}).get("_source"))} for x in fl],
            "note": "Deviation counts compare each bird with its own baseline only. Birds are not ranked against each other."}


@router.get("/training/recent")
def recent_training(days: int = 14, user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    names = {f.id: f.name for f in _org_falcons(db, user)}
    ss = db.scalars(select(TrainingSession).where(TrainingSession.falcon_id.in_(list(names)),
                                                  TrainingSession.start >= now() - timedelta(days=min(days, 90)))
                    .order_by(TrainingSession.start.desc()).limit(300)).all()
    per: dict[int, dict] = {}
    for s in ss:
        p = per.setdefault(s.falcon_id, {"falcon_id": s.falcon_id, "name": names[s.falcon_id], "sessions": 0, "completed": 0, "minutes": 0.0,
                                         "last": s.start.isoformat() + "Z"})
        p["sessions"] += 1
        p["completed"] += s.outcome == "completed"
        p["minutes"] = round(p["minutes"] + (s.duration_min or 0), 1)
    return {"per_falcon": list(per.values()), "sessions": [{**s.as_dict(), "name": names[s.falcon_id]} for s in ss]}


@router.get("/feeding/summary")
def feeding_summary(user: User = Depends(require("health.read")), db: Session = Depends(get_db)):
    out = []
    t = now()
    for f in _org_falcons(db, user):
        ws = db.scalars(select(WeightRecord).where(WeightRecord.falcon_id == f.id, WeightRecord.ts >= t - timedelta(days=14)).order_by(WeightRecord.ts)).all()
        tr = db.scalar(select(TargetRange).where(TargetRange.falcon_id == f.id, TargetRange.active.is_(True)).order_by(TargetRange.set_at.desc()))
        lf = db.scalar(select(FeedingRecord).where(FeedingRecord.falcon_id == f.id).order_by(FeedingRecord.ts.desc()))
        last = ws[-1] if ws else None
        pos = None
        if last and tr:
            pos = "below range" if last.weight_g < tr.min_g else "above range" if last.weight_g > tr.max_g else "within range"
        out.append({"falcon_id": f.id, "name": f.name, "latest_g": last.weight_g if last else None,
                    "latest_ts": last.ts.isoformat() + "Z" if last else None, "weighings_14d": len(ws),
                    "median_14d_g": round(median(w.weight_g for w in ws), 1) if ws else None,
                    "target": [tr.min_g, tr.max_g] if tr else None, "against_target": pos,
                    "spark": [w.weight_g for w in ws],
                    "last_feeding": {"ts": lf.ts.isoformat() + "Z", "food_type": lf.food_type, "quantity_g": lf.quantity_g} if lf else None})
    return out


# --- organisations & owner-controlled access ------------------------------------------------------
@router.get("/organization")
def organization(user: User = Depends(current_user), db: Session = Depends(get_db)):
    org = db.get(Org, user.org_id)
    members = db.scalars(select(User).where(User.org_id == org.id, User.active.is_(True)).order_by(User.id)).all()
    grants = []
    if can(user, "access.manage"):
        for g, f, u in db.execute(select(FalconAccess, Falcon, User).join(Falcon, Falcon.id == FalconAccess.falcon_id)
                                  .join(User, User.id == FalconAccess.user_id).where(Falcon.org_id == org.id)
                                  .order_by(FalconAccess.granted_at.desc())).all():
            o = db.get(Org, u.org_id)
            state = "revoked" if g.revoked_at else "expired" if g.expires and g.expires < now() else "active"
            grants.append({**g.as_dict(), "falcon_name": f.name, "user_name": u.name, "user_role": u.role, "user_org": o.name, "state": state})
    shared_in = [{"id": f.id, "name": f.name, "code": f.code, "owner_org": db.get(Org, f.org_id).name}
                 for f in db.scalars(select(Falcon).where(Falcon.id.in_(granted_falcon_ids(db, user)))).all()]
    return {"org": {"id": org.id, "name": org.name, "country": org.country, "kind": org.kind, "plan": (org.settings or {}).get("plan")},
            "members": [{"id": m.id, "name": m.name, "role": m.role, "title": m.title, "permissions": sorted(PERMS.get(m.role, []))} for m in members],
            "roles": {r: sorted(PERMS.get(r, [])) for r in ROLES}, "grants": grants, "shared_with_me": shared_in,
            "plans": config.PLANS, "can_manage": can(user, "access.manage")}


@router.post("/falcons/{fid}/access")
def grant_access(fid: int, body: dict = Body(...), user: User = Depends(require("access.manage")), db: Session = Depends(get_db)):
    """Owner-side grant: let a named professional (any organisation) work on this falcon. Revocable at any time."""
    f = get_falcon(db, user, fid)
    if f.org_id != user.org_id:
        raise HTTPException(403, "Only the owner's organisation can share a falcon")
    need(body, "email")
    u = db.scalar(select(User).where(User.email == str(body["email"]).strip().lower(), User.active.is_(True)))
    if not u:
        raise HTTPException(404, "No active platform user has this email address")
    if u.org_id == f.org_id:
        raise HTTPException(422, "This person is already a member of your organisation")
    days = body.get("days")
    g = FalconAccess(falcon_id=fid, user_id=u.id, purpose=body.get("purpose"), granted_by=user.id,
                     expires=now() + timedelta(days=float(days)) if days else None)
    db.add(g)
    db.add(TimelineEvent(falcon_id=fid, kind="access", title=f"Record shared with {u.name} ({u.role})", detail=body.get("purpose")))
    audit(db, user, "access.grant", "falcon", fid, u.email)
    db.commit()
    return g.as_dict()


@router.post("/access/{gid}/revoke")
def revoke_access(gid: int, user: User = Depends(require("access.manage")), db: Session = Depends(get_db)):
    g = db.get(FalconAccess, gid)
    f = db.get(Falcon, g.falcon_id) if g else None
    if not g or not f or f.org_id != user.org_id:
        raise HTTPException(404, "Grant not found")
    if not g.revoked_at:
        g.revoked_at = now()
        db.add(TimelineEvent(falcon_id=f.id, kind="access", title="Shared access revoked"))
        audit(db, user, "access.revoke", "falcon", f.id)
        db.commit()
    return {"ok": True}


# --- settings & weather ---------------------------------------------------------------------------
@router.get("/settings")
def get_settings(user: User = Depends(current_user), db: Session = Depends(get_db)):
    org = db.get(Org, user.org_id)
    return {"weather": weather.settings(org), "weather_providers": ["none", *weather.PROVIDERS], "threshold_fields": weather.THRESHOLD_FIELDS,
            "can_write": can(user, "settings.write"), "demo": config.DEMO_MODE,
            "privacy": "When a weather provider is enabled, zone coordinates are rounded to about 5 km before they are sent to it."}


@router.post("/settings/weather")
def set_weather(body: dict = Body(...), user: User = Depends(require("settings.write")), db: Session = Depends(get_db)):
    org = db.get(Org, user.org_id)
    s = dict(org.settings or {})
    w = dict(s.get("weather") or {})
    if "provider" in body:
        if body["provider"] not in ("none", *weather.PROVIDERS):
            raise HTTPException(422, "Unknown weather provider")
        w["provider"] = body["provider"]
    if "thresholds" in body:
        th = {}
        for k, v in (body["thresholds"] or {}).items():
            if k in weather.THRESHOLD_FIELDS and v not in (None, ""):
                th[k] = float(v)
        w["thresholds"], w["thresholds_set_by"], w["thresholds_note"] = th, user.name, body.get("note")
    s["weather"] = w
    org.settings = s
    flag_modified(org, "settings")
    audit(db, user, "settings.weather", "org", org.id)
    db.commit()
    return weather.settings(org)


@router.get("/weather")
def get_weather(zone_id: int | None = None, user: User = Depends(require("falcon.read")), db: Session = Depends(get_db)):
    q = select(Zone).where(Zone.org_id == user.org_id)
    z = db.get(Zone, zone_id) if zone_id else db.scalar(q.where(Zone.kind == "training")) or db.scalar(q)
    if not z or z.org_id != user.org_id:
        return {"status": "no_zone", "message": "Add a training zone in Settings to get conditions for it."}
    return {**weather.get(db, db.get(Org, user.org_id), z.lat, z.lon), "zone": {"id": z.id, "name": z.name}}


# --- assistant & AI service registry --------------------------------------------------------------
@router.post("/assistant")
def ask_assistant(body: dict = Body(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    need(body, "question")
    out = assistant.ask(db, user, str(body["question"]), body.get("falcon_id"))
    audit(db, user, "assistant.ask", detail=out.get("tool") or "unmatched")
    db.commit()
    return out


@router.get("/assistant/examples")
def assistant_examples(user: User = Depends(current_user)):
    return {"examples": [t[4] for t in assistant.TOOLS], "engine": assistant.ENGINE}


AI_SERVICES = [
    ("Falcon Detection AI", "fi.vision.detect", "not installed", False, "Pluggable detector backend; no falcon model trained yet."),
    ("Falcon Identification Assistance AI", "fi.vision.identity_candidates", "running", False, "Appearance-similarity ranking; a person confirms every match."),
    ("Flight Performance AI", "fi.analytics.flight + fi.analytics.baseline", "running", True, "Deterministic metrics; individual baselines (median/MAD)."),
    ("Behaviour Analysis AI", "fi.analytics.baseline (patterns, deviations, trends)", "running", False, "Rule-based pattern labels and robust statistics; not validated against expert labels."),
    ("Health Observation AI", "fi.analytics.health", "running", False, "Transparent rules producing observations for human follow-up; never a diagnosis."),
    ("Training Analytics AI", "fi.api_care (training analytics)", "running", True, "Counts, medians and period comparisons of recorded sessions."),
    ("Lost Falcon Assistance AI", "fi.api_recovery (_assist)", "running", True, "Derived facts about the last valid fix; makes no prediction of current position."),
    ("Environmental Intelligence AI", "fi.weather", "running", True, "Provider data compared with organisation-set thresholds; never a safety verdict."),
    ("Reporting AI", "fi.reports + fi.assistant", "running", True, "Templated reports and retrieval-only answers with record references; no generated facts."),
]


@router.get("/ai/services")
def ai_services(user: User = Depends(current_user)):
    return [{"name": n, "module": m, "status": s, "deterministic": d, "note": note,
             "validated": "n/a — deterministic calculation" if d else "not validated"} for n, m, s, d, note in AI_SERVICES]


# --- simulator scenarios --------------------------------------------------------------------------
SCENARIOS = {
    "normal_flight": ("Normal flight session", "waiting_on", {}),
    "long_distance": ("Long-distance flight", "pursuit", {"leg_scale": 3.5}),
    "high_altitude": ("High-altitude telemetry record", "waiting_on", {"pitch_scale": 2.2}),
    "unusual_movement": ("Unusual movement pattern", "lure", {"erratic": True}),
    "signal_loss": ("Sudden loss of tracking signal", "pursuit", {"leg_scale": 2.0, "stop_after_s": 35}),
    "low_battery": ("Low device battery", "lure", {"batt": 14.0}),
    "missing_falcon": ("Missing falcon recovery case", "pursuit", {"leg_scale": 2.5, "stop_after_s": 40}),
}
STATIC_SCENARIOS = {
    "activity_change": ("Change in activity over time", "Seeded: Najm's last five days (weight, sessions and flights decline).", "#/falcon/3/health"),
    "session_comparison": ("Comparison between training sessions", "Seeded: 30 days of sessions per bird — use Training → Compare two periods.", "#/falcon/1/training"),
    "vet_workflow": ("Veterinary observation workflow", "Seeded: sign in as the vet and annotate / review Najm's level 4 observation.", "#/falcon/3/health"),
}


@router.get("/simulator")
def simulator_info(user: User = Depends(current_user), db: Session = Depends(get_db)):
    runs = db.scalars(select(SimRun).where(SimRun.org_id == user.org_id).order_by(SimRun.started.desc()).limit(15)).all()
    names = {f.id: f.name for f in _org_falcons(db, user)}
    return {"enabled": config.DEMO_MODE,
            "live": [{"key": k, "label": v[0], "params": v[2]} for k, v in SCENARIOS.items()],
            "static": [{"key": k, "label": v[0], "how": v[1], "link": v[2]} for k, v in STATIC_SCENARIOS.items()],
            "runs": [{"id": r.id, "scenario": r.scenario, "falcon": names.get(r.falcon_id), "falcon_id": r.falcon_id,
                      "started": r.started.isoformat() + "Z", "running": simulator.live_running(r.falcon_id) and r is runs[0]} for r in runs],
            "note": "All simulator output is stored with simulated = true and labelled in the interface. Ground truth is kept in "
                    "sim_runs, separate from the telemetry the simulated device reported."}


@router.post("/simulator/run")
def simulator_run(body: dict = Body(...), user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    if not config.DEMO_MODE:
        raise HTTPException(404, "The simulator is disabled outside demo mode")
    key = body.get("scenario")
    if key not in SCENARIOS:
        raise HTTPException(422, f"Unknown scenario. Live scenarios: {', '.join(SCENARIOS)}")
    f = get_falcon(db, user, int(body.get("falcon_id", 0)))
    a = db.scalar(select(DeviceAssignment).where(DeviceAssignment.falcon_id == f.id, DeviceAssignment.end.is_(None)))
    if not a:
        raise HTTPException(422, "This falcon has no tracker assigned")
    if simulator.live_running(f.id):
        raise HTTPException(409, "A simulated flight is already running for this falcon")
    label, kind, opts = SCENARIOS[key]
    z = db.scalar(select(Zone).where(Zone.org_id == f.org_id, Zone.kind == "training"))
    lat, lon = (z.lat, z.lon) if z else (24.805, 55.385)
    run = SimRun(org_id=user.org_id, falcon_id=f.id, scenario=key, params=opts)
    db.add(run)
    db.commit()
    after = None
    if key == "missing_falcon":
        fid, uid, org_id = f.id, user.id, f.org_id

        def after():                      # the owner reports the bird missing once the signal has gone
            with SessionLocal() as s:
                if s.scalar(select(RecoveryCase.id).where(RecoveryCase.falcon_id == fid, RecoveryCase.status == "open")):
                    return
                fal = s.get(Falcon, fid)
                pos = ingest.position_status(s, fal)
                c = RecoveryCase(org_id=org_id, falcon_id=fid, opened_by=uid, circumstances="SIMULATED scenario: tracker stopped reporting during a pursuit flight.",
                                 contacts=[u.id for u in s.scalars(select(User).where(User.org_id == org_id, User.role == "recovery")).all()],
                                 snapshot={"state": pos["state"], "label": pos["label"], "explain": pos["explain"], "position": pos.get("position"),
                                           "device": pos.get("device"), "taken": now().isoformat() + "Z"})
                s.add(c)
                s.flush()
                s.add(RecoveryAction(case_id=c.id, user_name="Simulator", text="Recovery case opened by the simulated scenario."))
                health.notify(s, org_id, fid, "recovery", "urgent", f"{fal.name} reported missing (simulated scenario)", "A recovery case is open.", key=f"recovery:{c.id}")
                s.commit()
    simulator.start_live(f.id, a.device_id, kind, lat, lon, opts=opts, run_id=run.id, after=after)
    audit(db, user, "simulator.run", "falcon", f.id, key)
    db.commit()
    return {"run_id": run.id, "label": label, "note": "Simulated telemetry is streaming through the LoRa adapter and the normal ingest path."}


@router.get("/simulator/runs/{rid}")
def simulator_validation(rid: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Telemetry validation: compare what the simulated device reported with stored ground truth."""
    r = db.get(SimRun, rid)
    if not r or r.org_id != user.org_id:
        raise HTTPException(404, "Run not found")
    if not r.truth:
        return {"status": "no_truth_yet"}
    truth = {t[0][:19]: t[1:] for t in r.truth}
    t0, t1 = parse_dt(r.truth[0][0]), parse_dt(r.truth[-1][0])
    pts = db.scalars(select(TelemetryPoint).where(TelemetryPoint.falcon_id == r.falcon_id, TelemetryPoint.simulated.is_(True),
                                                  TelemetryPoint.ts >= t0, TelemetryPoint.ts <= t1)).all()
    herr, verr, flagged_err = [], [], []
    for p in pts:
        tr = truth.get(p.ts.isoformat()[:19])
        if not tr or p.lat is None:
            continue
        e = float(flight_engine.haversine(tr[0], tr[1], p.lat, p.lon))
        (herr if p.quality >= 0.5 else flagged_err).append(e)
        if p.alt_m is not None and p.quality >= 0.5:
            verr.append(abs(p.alt_m - tr[2]))
    herr.sort()
    return {"status": "ok", "scenario": r.scenario, "truth_points": len(r.truth), "reported_points": len(pts),
            "delivery_ratio": round(len(pts) / len(r.truth), 3),
            "horizontal_error_m": {"median": round(median(herr), 2), "p95": round(herr[int(0.95 * (len(herr) - 1))], 2)} if herr else None,
            "vertical_error_m": {"median": round(median(verr), 2)} if verr else None,
            "low_quality_fixes": {"count": len(flagged_err), "median_error_m": round(median(flagged_err), 1) if flagged_err else None},
            "note": "Error of simulated device reports against simulated truth. It validates the ingest and quality-flag pipeline, "
                    "not the accuracy of any real tracker."}


# --- live WebSocket -------------------------------------------------------------------------------
@router.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    """Pushes the tracking overview every 2 s. Authenticated with the same bearer token (?token=)."""
    await ws.accept()
    token = ws.query_params.get("token", "")
    with SessionLocal() as db:
        s = db.get(AuthSession, sha(token))
        user = db.get(User, s.user_id) if s and s.expires > now() else None
    if not user or not can(user, "telemetry.read"):
        await ws.close(code=4401)
        return
    try:
        while True:
            def snap():
                with SessionLocal() as db:
                    return json.dumps(overview_data(db, user))
            await ws.send_text(await asyncio.to_thread(snap))
            await asyncio.sleep(2)
    except (WebSocketDisconnect, RuntimeError):
        return
