"""Runtime configuration (environment driven)."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = Path(os.environ.get("FI_DATA_DIR", ROOT / "data"))
UPLOAD_DIR = DATA_DIR / "uploads"
DB_URL = os.environ.get("FI_DB_URL", f"sqlite:///{(DATA_DIR / 'fi.db').as_posix()}")
WEB_DIR = ROOT / "web"

# Browser edition: the same backend running inside the visitor's browser (Pyodide / WebAssembly).
# There are no threads and no sockets there, so a few components switch implementation.
BROWSER = os.environ.get("FI_BROWSER") == "1"
PBKDF2_ITERATIONS = int(os.environ.get("FI_PBKDF2_ITERATIONS", "2000" if BROWSER else "200000"))

# Demo mode enables one-click demo sign-in and the telemetry simulator endpoints.
# It must be OFF in production (FI_DEMO=0).
DEMO_MODE = os.environ.get("FI_DEMO", "1") == "1"

SESSION_HOURS = int(os.environ.get("FI_SESSION_HOURS", "72"))
MAX_UPLOAD_MB = int(os.environ.get("FI_MAX_UPLOAD_MB", "200"))

# Device-mass guidance used ONLY to raise warnings for professional review.
# Commonly cited avian-telemetry guidance keeps total attached mass at or below ~3% of body
# mass (some literature discusses up to 5%). The platform never treats a ratio as proof of safety.
DEVICE_MASS_WARN_RATIO = float(os.environ.get("FI_DEVICE_MASS_WARN_RATIO", "0.03"))
DEVICE_MASS_BLOCK_RATIO = float(os.environ.get("FI_DEVICE_MASS_BLOCK_RATIO", "0.05"))

DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Subscription packages — a configurable catalogue only. No prices and no payment provider are
# assumed; billing is a future module that reads this structure.
PLANS = [
    {"key": "owner", "name": "Falcon Owner", "audience": "Individual owners",
     "features": ["Individual falcon profiles", "Tracking integration", "Training records", "Basic analytics"]},
    {"key": "professional", "name": "Professional Falconer", "audience": "Falconers and trainers",
     "features": ["Multiple falcons", "Advanced telemetry", "Training comparisons", "AI observations", "Recovery assistance"]},
    {"key": "breeding", "name": "Breeding Facility", "audience": "Breeding centres",
     "features": ["Multiple users", "Breeding records", "Falcon lineage", "Veterinary documentation", "Facility analytics"]},
    {"key": "hospital", "name": "Falcon Hospital / Veterinary", "audience": "Clinics and hospitals",
     "features": ["Veterinary records", "Health observations", "Authorised owner access", "Medical documentation", "Professional reporting"]},
    {"key": "enterprise", "name": "Enterprise", "audience": "Multi-facility organisations",
     "features": ["Multi-facility management", "API integration", "Custom analytics", "Organisation administration", "Advanced reporting"]},
]
