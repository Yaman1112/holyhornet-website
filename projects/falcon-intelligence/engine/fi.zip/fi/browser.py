"""Browser edition bridge: runs the unmodified FastAPI application inside Pyodide (CPython on WebAssembly).

The web worker calls ``boot()`` once, then ``request(method, path, headers_json, body)`` for every API call.
Requests go through the full ASGI stack — authentication, role checks, validation, analytics, SQLite — exactly
as on a server. Only the transport differs: postMessage instead of TCP.
"""
from __future__ import annotations

import json
import os

_app = None
_host = ("falcon.local", 80, "http", "")


def boot(host: str = "falcon.local", scheme: str = "http", root_path: str = "") -> dict:
    """Create the in-memory deployment and seed the synthetic demo data."""
    global _app, _host
    import time
    t = time.time()
    os.environ["FI_BROWSER"] = "1"
    os.environ["FI_DEMO"] = "1"
    os.environ.setdefault("FI_DATA_DIR", "/home/pyodide/fi_data")

    # Pyodide has no threads. FastAPI runs plain `def` endpoints and dependencies in a thread pool,
    # so run them inline instead; everything is single-threaded here anyway.
    import anyio.to_thread

    async def _inline(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):
        return func(*args)
    anyio.to_thread.run_sync = _inline

    from . import seed
    from .main import app
    seed.seed(reset=False)
    _app = app
    _host = (host, 443 if scheme == "https" else 80, scheme, root_path.rstrip("/"))
    return {"ok": True, "boot_s": round(time.time() - t, 1)}


async def request(method: str, path: str, headers_json: str = "{}", body=None) -> dict:
    if _app is None:
        raise RuntimeError("call boot() first")
    headers = json.loads(headers_json or "{}")
    p, _, qs = path.partition("?")
    # JS null arrives as JsNull (not None) in recent Pyodide versions
    raw = bytes(body) if body is not None and type(body).__name__ != "JsNull" else b""
    host, port, scheme, root = _host
    hdrs = [(k.lower().encode(), str(v).encode()) for k, v in headers.items()]
    hdrs.append((b"host", host.encode()))
    if raw:
        hdrs.append((b"content-length", str(len(raw)).encode()))
    from urllib.parse import unquote
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(), "scheme": scheme,
             "path": unquote(p), "raw_path": p.encode(), "query_string": qs.encode(), "root_path": root, "headers": hdrs,
             "client": ("browser", 0), "server": (host, port)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": raw, "more_body": False}
        return {"type": "http.disconnect"}

    out = {"status": 500, "headers": {}, "body": b""}
    chunks = []

    async def send(msg):
        if msg["type"] == "http.response.start":
            out["status"] = msg["status"]
            out["headers"] = {k.decode(): v.decode() for k, v in msg.get("headers", [])}
        elif msg["type"] == "http.response.body":
            chunks.append(msg.get("body", b""))

    await _app(scope, receive, send)
    out["body"] = b"".join(chunks)
    return out
