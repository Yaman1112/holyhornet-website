"""Platform assistant — retrieval only.

The assistant never generates facts. It maps a question to one of a fixed set of retrieval
functions ("tools"), runs it with the asking user's permissions, and returns the records it
found with references to them. If it cannot map the question, or the user is not allowed to see
the data, it says so.

The intent router here is rule-based. It is deliberately the replaceable part: an LLM can be put
in front of the same tools (as function-calling tools) without changing the tools or permissions.
"""
from __future__ import annotations

import re
from datetime import timedelta
from statistics import median

from sqlalchemy import select
from sqlalchemy.orm import Session

from .analytics import baseline
from .auth import can, granted_falcon_ids
from .models import (Alert, Device, DeviceAssignment, Falcon, Flight, HealthRecord, RecoveryCase, TrainingSession, User,
                     WeightRecord, now)
from .telemetry import ingest

ENGINE = "rule-based intent router + permission-checked retrieval (no generative model)"


def _ref(kind: str, label: str, link: str) -> dict:
    return {"type": kind, "label": label, "link": link}


def _falcons(db: Session, user: User) -> list[Falcon]:
    return db.scalars(select(Falcon).where((Falcon.org_id == user.org_id) | Falcon.id.in_(granted_falcon_ids(db, user)))).all()


def _resolve(db: Session, user: User, q: str, falcon_id: int | None) -> Falcon | None:
    fs = _falcons(db, user)
    hits = [f for f in fs if re.search(rf"\b{re.escape(f.name.lower())}\b", q) or f.code.lower() in q]
    if len(hits) == 1:
        return hits[0]
    if falcon_id:
        return next((f for f in fs if f.id == falcon_id), None)
    return fs[0] if len(fs) == 1 else None


def _deny(perm: str) -> dict:
    return {"answer": f"Your role does not have access to this information (requires “{perm}”).", "references": [], "denied": True}


def _need_falcon(db: Session, user: User) -> dict:
    names = ", ".join(f.name for f in _falcons(db, user)[:12])
    return {"answer": f"Which falcon do you mean? Name it in your question. Falcons you can see: {names or 'none'}.", "references": []}


# --- tools --------------------------------------------------------------------------------------
def last_location(db, user, f, q):
    if not can(user, "telemetry.read"):
        return _deny("telemetry.read")
    p = ingest.position_status(db, f)
    pos = p.get("position")
    if not pos:
        return {"answer": f"{f.name}: {p['label']}. {p['explain']}", "references": [_ref("falcon", f"{f.name} — tracking", f"#/falcon/{f.id}/tracking")]}
    age = p["age_s"]
    ago = f"{age // 60} min ago" if age < 5400 else f"{age // 3600} h ago" if age < 172800 else f"{age // 86400} days ago"
    return {"answer": f"{f.name} — {p['label']}. Last valid fix {pos['lat']:.5f}, {pos['lon']:.5f} at {pos['ts'][:16].replace('T', ' ')} UTC ({ago})"
                      + (f", estimated accuracy ±{pos['accuracy_m']} m" if pos.get("accuracy_m") else "") + f". {p['explain']}"
                      + (" This position comes from simulated telemetry." if p.get("simulated") else ""),
            "references": [_ref("telemetry", f"{f.name} — tracker status and map", f"#/falcon/{f.id}/tracking")]}


def compare_weeks(db, user, f, q):
    if not can(user, "telemetry.read"):
        return _deny("telemetry.read")
    t = now()
    rows, refs = [], [_ref("flights", f"{f.name} — flights and performance", f"#/falcon/{f.id}/flights")]
    periods = {"this week (last 7 days)": (t - timedelta(days=7), t), "previous week": (t - timedelta(days=14), t - timedelta(days=7))}
    stats = {}
    for name, (a, b) in periods.items():
        fl = db.scalars(select(Flight).where(Flight.falcon_id == f.id, Flight.open.is_(False), Flight.start >= a, Flight.start < b)).all()
        ss = db.scalars(select(TrainingSession).where(TrainingSession.falcon_id == f.id, TrainingSession.start >= a, TrainingSession.start < b)).all()
        st = {"flights": len(fl), "sessions": len(ss)}
        for k in ("duration_s", "distance_m", "max_height_m", "max_speed_mps"):
            v = [x for x in (baseline._val(m.metrics, k) for m in fl) if x is not None]
            st[k] = round(median(v), 1) if v else None
        stats[name] = st
    (n1, a), (n2, b) = stats.items()
    for k, lab in [("sessions", "Training sessions"), ("flights", "Tracked flights"), ("duration_s", "Median flight duration (s)"),
                   ("distance_m", "Median distance (m)"), ("max_height_m", "Median max height above launch (m)"),
                   ("max_speed_mps", "Median peak speed (m/s)")]:
        rows.append([lab, a[k] if a[k] is not None else "—", b[k] if b[k] is not None else "—"])
    note = "Few flights in a week make medians unreliable." if min(a["flights"], b["flights"]) < 4 else ""
    return {"answer": f"{f.name}: {a['flights']} tracked flights this week against {b['flights']} the week before. "
                      f"Figures are medians of recorded flights for this bird only. {note}".strip(),
            "table": {"head": ["Metric", n1, n2], "rows": rows}, "references": refs}


def unusual_activity(db, user, f, q):
    if not can(user, "telemetry.read"):
        return _deny("telemetry.read")
    fl = db.scalars(select(Flight).where(Flight.falcon_id == f.id, Flight.open.is_(False)).order_by(Flight.start)).all()
    hist = [x.metrics for x in fl]
    rows, refs = [], []
    for i in range(max(baseline.MIN_FLIGHTS, len(fl) - 10), len(fl)):
        b = baseline.build(baseline.same_pattern(hist[:i], hist[i])[0])
        for c in baseline.compare(fl[i].metrics or {}, b):
            if c["status"] != "typical":
                rows.append([fl[i].start.strftime("%d %b %H:%M"), c["label"], f"{c['value']} {c['unit']}",
                             f"{c['typical_low']}–{c['typical_high']}", f"{c['status']}, {c['direction']}"])
                refs.append(_ref("flight", f"Flight {fl[i].start:%d %b %H:%M}", f"#/flight/{fl[i].id}"))
    if len(fl) < baseline.MIN_FLIGHTS + 1:
        return {"answer": f"{f.name} has {len(fl)} tracked flights — not enough for an individual baseline (needs {baseline.MIN_FLIGHTS}).",
                "references": [_ref("flights", f"{f.name} — flights", f"#/falcon/{f.id}/flights")]}
    if not rows:
        return {"answer": f"No deviations from {f.name}'s own baseline in the last 10 tracked flights.",
                "references": [_ref("flights", f"{f.name} — flights and performance", f"#/falcon/{f.id}/flights")]}
    uniq = list({r["link"]: r for r in refs}.values())
    return {"answer": f"{len(rows)} deviation(s) from {f.name}'s own baseline in the last 10 tracked flights. These are statistical "
                      "observations about recorded data, compared like-for-like by flight pattern; they do not explain the cause.",
            "table": {"head": ["Flight", "Metric", "Value", "Own typical range", "Status"], "rows": rows[:20]}, "references": uniq[:8]}


def vet_summary(db, user, f, q):
    if not can(user, "health.read"):
        return _deny("health.read")
    r = db.scalar(select(HealthRecord).where(HealthRecord.falcon_id == f.id, HealthRecord.kind == "exam").order_by(HealthRecord.ts.desc()))
    if not r:
        return {"answer": f"No veterinary examination is recorded for {f.name}.", "references": [_ref("health", f"{f.name} — health", f"#/falcon/{f.id}/health")]}
    near = db.scalars(select(HealthRecord).where(HealthRecord.falcon_id == f.id, HealthRecord.id != r.id,
                                                 HealthRecord.ts >= r.ts - timedelta(days=1), HealthRecord.ts <= r.ts + timedelta(days=3),
                                                 HealthRecord.kind.in_(["lab", "medication", "treatment", "recommendation", "followup", "vaccination"]))).all()
    txt = (f"Last veterinary examination for {f.name}: “{r.title}” on {r.ts:%d %b %Y}, recorded by {r.recorder_name or 'unknown'}. "
           + (f"Recorded detail: {r.detail} " if r.detail else "No detail was recorded. ")
           + (f"Records from the same visit: " + "; ".join(f"{x.kind} — {x.title}" for x in near) + "." if near else ""))
    return {"answer": txt + " This repeats what was entered in the record; the assistant adds no clinical interpretation.",
            "references": [_ref("health_record", f"{r.kind}: {r.title} ({r.ts:%d %b %Y})", f"#/falcon/{f.id}/health")]
            + [_ref("health_record", f"{x.kind}: {x.title}", f"#/falcon/{f.id}/health") for x in near]}


def weight_history(db, user, f, q):
    if not can(user, "health.read"):
        return _deny("health.read")
    ws = db.scalars(select(WeightRecord).where(WeightRecord.falcon_id == f.id).order_by(WeightRecord.ts.desc()).limit(14)).all()
    if not ws:
        return {"answer": f"No weights are recorded for {f.name}.", "references": [_ref("weights", f"{f.name} — feeding and weight", f"#/falcon/{f.id}/feeding")]}
    vals = [w.weight_g for w in ws]
    return {"answer": f"{f.name}: latest recorded weight {ws[0].weight_g:.0f} g on {ws[0].ts:%d %b}. Over the last {len(ws)} weighings: "
                      f"range {min(vals):.0f}–{max(vals):.0f} g, median {median(vals):.0f} g.",
            "table": {"head": ["Date (UTC)", "Weight (g)", "Context"], "rows": [[w.ts.strftime("%d %b %H:%M"), f"{w.weight_g:.0f}", w.context or ""] for w in ws]},
            "references": [_ref("weights", f"{f.name} — weight chart and records", f"#/falcon/{f.id}/feeding")]}


def training_report(db, user, f, q):
    if not can(user, "report"):
        return _deny("report")
    n = len(db.scalars(select(TrainingSession.id).where(TrainingSession.falcon_id == f.id, TrainingSession.start >= now() - timedelta(days=30))).all())
    return {"answer": f"Training report for {f.name} is ready: {n} sessions in the last 30 days. Open it from the reference below "
                      "(printable; every figure carries its source label).",
            "references": [_ref("report", f"{f.name} — performance and training report (30 days)", f"report:/reports/falcon/{f.id}?kind=performance&days=30"),
                           _ref("training", f"{f.name} — training sessions", f"#/falcon/{f.id}/training")]}


def devices_charging(db, user, f, q):
    if not can(user, "device.read"):
        return _deny("device.read")
    rows = []
    for d in db.scalars(select(Device).where(Device.org_id == user.org_id).order_by(Device.battery_pct)).all():
        a = db.scalar(select(DeviceAssignment).where(DeviceAssignment.device_id == d.id, DeviceAssignment.end.is_(None)))
        fal = db.get(Falcon, a.falcon_id) if a else None
        if d.battery_pct is not None and d.battery_pct <= 30:
            rows.append([d.serial, f"{d.battery_pct:.0f}%", fal.name if fal else "unassigned", d.last_seen.strftime("%d %b %H:%M") if d.last_seen else "never"])
    unknown = len(db.scalars(select(Device.id).where(Device.org_id == user.org_id, Device.battery_pct.is_(None))).all())
    ans = (f"{len(rows)} tracker(s) reported 30% battery or less at their last report." if rows else "No tracker reported 30% battery or less at its last report.")
    ans += " Battery values are the last value each device reported and may be old." + (f" {unknown} device(s) have never reported a battery level." if unknown else "")
    out = {"answer": ans, "references": [_ref("devices", "Devices", "#/devices")]}
    if rows:
        out["table"] = {"head": ["Tracker", "Battery at last report", "Assigned to", "Last report (UTC)"], "rows": rows}
    return out


def recovery_cases(db, user, f, q):
    if not can(user, "recovery.read"):
        return _deny("recovery.read")
    cs = db.scalars(select(RecoveryCase).where(RecoveryCase.org_id == user.org_id, RecoveryCase.status == "open")).all()
    if user.role == "recovery":
        cs = [c for c in cs if user.id in (c.contacts or [])]
    if not cs:
        return {"answer": "There are no open recovery cases.", "references": [_ref("recovery", "Recovery Center", "#/recovery")]}
    rows = [[db.get(Falcon, c.falcon_id).name, c.opened_at.strftime("%d %b %H:%M"), (c.snapshot or {}).get("label", "—")] for c in cs]
    return {"answer": f"{len(cs)} open recovery case(s).", "table": {"head": ["Falcon", "Opened (UTC)", "Tracker status when opened"], "rows": rows},
            "references": [_ref("recovery_case", f"Case {c.id} — {db.get(Falcon, c.falcon_id).name}", f"#/recovery/{c.id}") for c in cs]}


def health_observations(db, user, f, q):
    if not can(user, "health.read"):
        return _deny("health.read")
    al = db.scalars(select(Alert).where(Alert.falcon_id == f.id, Alert.status.in_(["open", "acknowledged", "reviewed"])).order_by(Alert.level.desc())).all()
    from .analytics.health import LEVELS
    rows = [[a.level, LEVELS[a.level], a.title, f"{a.confidence:.0%}"] for a in al]
    return {"answer": f"{f.name} has {sum(a.level > 1 for a in al)} open observation(s) above level 1. These are observations for human "
                      "follow-up, not diagnoses; open the record for supporting data, limitations and recommended follow-up.",
            "table": {"head": ["Level", "Category", "Observation", "Confidence"], "rows": rows},
            "references": [_ref("health", f"{f.name} — health observations", f"#/falcon/{f.id}/health")]}


# (name, needs a falcon, keyword pattern, function, example)
TOOLS = [
    ("open_recovery_cases", False, r"recover|missing|lost", recovery_cases, "Show all open recovery cases"),
    ("devices_needing_charge", False, r"charg|batter", devices_charging, "Find falcons whose tracking devices need charging"),
    ("last_location", True, r"locat|where|position|last (seen|known)", last_location, "Show Shaheen's last recorded location"),
    ("compare_weeks", True, r"compar.*week|this week|last week|week.*compar", compare_weeks, "Compare this week's flight sessions with last week for Najm"),
    ("unusual_flight_activity", True, r"unusual|anomal|deviat|chang.*(flight|activ)|abnormal", unusual_activity, "Show unusual changes in Najm's flight activity"),
    ("last_vet_exam", True, r"vet|examin|clinic", vet_summary, "Summarize Najm's last veterinary examination"),
    ("weight_history", True, r"weight|weigh", weight_history, "Show Najm's weight history"),
    ("training_report", True, r"report|training summary", training_report, "Generate a training report for Barq"),
    ("health_observations", True, r"health|alert|observation|wellness", health_observations, "Show health observations for Najm"),
]


def ask(db: Session, user: User, question: str, falcon_id: int | None = None) -> dict:
    q = " ".join(question.lower().split())[:500]
    for name, needs, pat, fn, _ in TOOLS:
        if re.search(pat, q):
            f = _resolve(db, user, q, falcon_id) if needs else None
            if needs and not f:
                out = _need_falcon(db, user)
            else:
                out = fn(db, user, f, q)
            return {**out, "tool": name, "engine": ENGINE, "falcon_id": f.id if f else None}
    return {"answer": "I can only answer from platform records, and I could not match your question to one of the things I can look up. "
                      "Try one of the examples below.", "references": [], "tool": None, "engine": ENGINE,
            "examples": [t[4] for t in TOOLS]}
