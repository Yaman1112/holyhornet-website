"""Environmental & weather intelligence.

Providers are pluggable. The bundled provider is Open-Meteo (public forecast API, no key).
Privacy: coordinates are rounded to 0.05° (~5 km) before they leave the platform, so a training
ground or mews is never sent to a third party at full precision. The integration is off unless an
organisation enables it in Settings.

Weather values are model output for a grid cell, not a measurement at the falconer's position, and
they are labelled that way. Acceptable weather is never presented as "safe to fly".
"""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import Org, WeatherObservation, now

DISCLAIMER = ("Forecast-model data for the surrounding area, not a measurement at your position. Conditions at the "
              "flying ground can differ. Weather data alone never shows that a flight is safe — the decision "
              "belongs to the falconer.")
WMO = {0: "clear", 1: "mainly clear", 2: "partly cloudy", 3: "overcast", 45: "fog", 48: "fog", 51: "light drizzle",
       53: "drizzle", 55: "dense drizzle", 61: "light rain", 63: "rain", 65: "heavy rain", 80: "rain showers",
       81: "rain showers", 82: "violent showers", 95: "thunderstorm", 96: "thunderstorm with hail", 99: "thunderstorm with hail"}
DIRS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
THRESHOLD_FIELDS = {"max_temp_c": "Air temperature above", "max_wind_kph": "Wind speed above", "max_gust_kph": "Gusts above",
                    "min_visibility_km": "Visibility below", "max_humidity_pct": "Humidity above"}


class OpenMeteo:
    key = "open-meteo"
    url = "https://api.open-meteo.com/v1/forecast"

    def fetch(self, lat: float, lon: float) -> tuple[dict, list]:
        fields = "temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m,weather_code,visibility"
        params = {"latitude": lat, "longitude": lon, "current": fields, "hourly": fields,
                  "forecast_days": 2, "wind_speed_unit": "kmh", "timezone": "UTC"}
        from . import config
        if config.BROWSER:                          # in the browser edition the visitor's browser makes the request
            import json
            from urllib.parse import urlencode

            from pyodide.http import open_url
            j = json.loads(open_url(f"{self.url}?{urlencode(params)}").read())
        else:
            import httpx
            r = httpx.get(self.url, timeout=10, params=params)
            r.raise_for_status()
            j = r.json()

        def norm(c: dict) -> dict:
            wd = c.get("wind_direction_10m")
            return {"temp_c": c.get("temperature_2m"), "humidity_pct": c.get("relative_humidity_2m"),
                    "wind_kph": c.get("wind_speed_10m"), "gust_kph": c.get("wind_gusts_10m"), "wind_deg": wd,
                    "wind_dir": DIRS[int((wd + 22.5) % 360 // 45)] if wd is not None else None,
                    "visibility_km": round(c["visibility"] / 1000, 1) if c.get("visibility") is not None else None,
                    "sky": WMO.get(c.get("weather_code"), "unknown"), "time": c.get("time")}
        h = j.get("hourly", {})
        hourly = [norm({k: h[k][i] for k in h}) for i in range(len(h.get("time", [])))]
        return norm(j.get("current", {})), hourly


PROVIDERS = {"open-meteo": OpenMeteo()}


def settings(org: Org) -> dict:
    s = (org.settings or {}).get("weather") or {}
    return {"provider": s.get("provider") or "none", "thresholds": s.get("thresholds") or {},
            "thresholds_set_by": s.get("thresholds_set_by"), "thresholds_note": s.get("thresholds_note")}


def evaluate(cur: dict, thresholds: dict) -> list[dict]:
    """Compare conditions with the organisation's own thresholds. Returns exceedances only."""
    out = []
    checks = [("max_temp_c", "temp_c", ">", "°C"), ("max_wind_kph", "wind_kph", ">", "km/h"), ("max_gust_kph", "gust_kph", ">", "km/h"),
              ("min_visibility_km", "visibility_km", "<", "km"), ("max_humidity_pct", "humidity_pct", ">", "%")]
    for tk, ck, op, unit in checks:
        lim, v = thresholds.get(tk), cur.get(ck)
        if lim is None or v is None:
            continue
        if (op == ">" and v > lim) or (op == "<" and v < lim):
            out.append({"threshold": tk, "label": THRESHOLD_FIELDS[tk], "limit": lim, "value": v, "unit": unit})
    return out


def get(db: Session, org: Org, lat: float, lon: float, max_age_min: int = 20) -> dict:
    cfg = settings(org)
    if cfg["provider"] not in PROVIDERS:
        return {"status": "not_configured", "provider": "none",
                "message": "No weather provider is enabled for this organisation. Enable one in Settings, or enter conditions by hand."}
    rlat, rlon = round(lat * 20) / 20, round(lon * 20) / 20
    obs = db.scalar(select(WeatherObservation).where(
        WeatherObservation.org_id == org.id, WeatherObservation.lat == rlat, WeatherObservation.lon == rlon,
        WeatherObservation.fetched >= now() - timedelta(minutes=max_age_min)).order_by(WeatherObservation.fetched.desc()))
    if not obs:
        try:
            cur, hourly = PROVIDERS[cfg["provider"]].fetch(rlat, rlon)
        except Exception as e:  # network / provider failure is reported, never papered over
            return {"status": "unavailable", "provider": cfg["provider"], "message": f"Weather provider could not be reached ({type(e).__name__})."}
        obs = WeatherObservation(org_id=org.id, lat=rlat, lon=rlon, provider=cfg["provider"], current=cur, hourly=hourly)
        db.add(obs)
        db.commit()
    t = now().strftime("%Y-%m-%dT%H")
    nxt = [h for h in obs.hourly or [] if (h.get("time") or "") >= t][:12]
    return {"status": "ok", "provider": obs.provider, "fetched": obs.fetched.isoformat() + "Z", "grid": [rlat, rlon],
            "current": obs.current, "next_hours": nxt, "provenance": "estimated",
            "thresholds": cfg["thresholds"], "exceeded": evaluate(obs.current, cfg["thresholds"]),
            "forecast_exceeded": [{"time": h["time"], "items": ex} for h in nxt if (ex := evaluate(h, cfg["thresholds"]))][:6],
            "disclaimer": DISCLAIMER}


def session_conditions(db: Session, org: Org, lat: float, lon: float) -> dict | None:
    """Conditions snapshot to attach to a training record (None when no provider / no data)."""
    w = get(db, org, lat, lon)
    if w["status"] != "ok":
        return None
    c = w["current"]
    return {"temp_c": c["temp_c"], "wind_kph": c["wind_kph"], "gust_kph": c["gust_kph"], "wind_dir": c["wind_dir"],
            "humidity_pct": c["humidity_pct"], "visibility_km": c["visibility_km"], "sky": c["sky"],
            "source": f"{w['provider']} forecast model (area value, not measured on site)"}
