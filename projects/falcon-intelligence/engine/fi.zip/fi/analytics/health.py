"""Health & wellness observation engine.

This module produces *observations for human follow-up*. It never names a disease, never
prescribes treatment and never changes a feeding plan or weight target. Each alert carries its
supporting observations (with provenance), time period, confidence, data limitations and a
recommended human follow-up.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from statistics import median

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import (AI, DERIVED, USER, VET, Alert, Falcon, Flight, HealthRecord, Notification, TargetRange,
                      TrainingSession, WeightRecord, now)
from . import baseline

LEVELS = {1: "Normal observations", 2: "Behavioural change detected", 3: "Potential health concern",
          4: "Veterinary assessment recommended", 5: "Urgent professional attention recommended"}
SEVERITY = {1: "info", 2: "notice", 3: "warning", 4: "warning", 5: "urgent"}

NOT_A_DIAGNOSIS = ("This is an automated observation, not a diagnosis. It cannot identify a cause and "
                   "may be explained by weather, moult, training changes, device issues or recording errors.")


def notify(db: Session, org_id: int, falcon_id: int | None, kind: str, severity: str, title: str,
           body: str | None = None, key: str | None = None) -> None:
    if key and db.scalar(select(Notification.id).where(Notification.org_id == org_id, Notification.key == key,
                                                       Notification.read.is_(False))):
        return
    db.add(Notification(org_id=org_id, falcon_id=falcon_id, kind=kind, severity=severity, title=title, body=body, key=key))


def _obs(text: str, provenance: str) -> dict:
    return {"text": text, "provenance": provenance}


def _weight_rules(db: Session, f: Falcon, t: datetime) -> list[dict]:
    out = []
    ws = db.scalars(select(WeightRecord).where(WeightRecord.falcon_id == f.id, WeightRecord.ts >= t - timedelta(days=21))
                    .order_by(WeightRecord.ts)).all()
    if not ws:
        return out
    latest = ws[-1]
    age_d = (t - latest.ts).total_seconds() / 86400
    tr = db.scalar(select(TargetRange).where(TargetRange.falcon_id == f.id, TargetRange.active.is_(True))
                   .order_by(TargetRange.set_at.desc()))
    if tr and age_d <= 7:
        over = (latest.weight_g - tr.max_g) / tr.max_g if latest.weight_g > tr.max_g else \
               (tr.min_g - latest.weight_g) / tr.min_g if latest.weight_g < tr.min_g else 0.0
        if over > 0:
            side = "above" if latest.weight_g > tr.max_g else "below"
            out.append(dict(
                key="weight_range", category="weight", level=4 if over >= 0.05 else 3, side=side,
                title=f"Recorded weight is {side} the veterinary target range",
                observations=[
                    _obs(f"Latest recorded weight {latest.weight_g:.0f} g on {latest.ts:%d %b %H:%M}"
                         f"{' (' + latest.context + ')' if latest.context else ''}.", latest.provenance),
                    _obs(f"Target range {tr.min_g:.0f}–{tr.max_g:.0f} g set by a veterinary professional on "
                         f"{tr.set_at:%d %b %Y}.", VET),
                    _obs(f"Weight is {over * 100:.1f}% {side} the range limit.", DERIVED)],
                period=(latest.ts, latest.ts), confidence=0.85,
                limitations="Single weighing; depends on scale accuracy, time of day and crop contents. "
                            "The target range may be out of date for the current season or training stage.",
                follow_up="Re-weigh under the usual conditions. If confirmed, the responsible falconer should "
                          "consult the veterinary professional who set the range. Do not change the feeding plan "
                          "on the basis of this alert alone."))
    recent = [w.weight_g for w in ws if w.ts >= t - timedelta(days=3)]
    prior = [w.weight_g for w in ws if t - timedelta(days=17) <= w.ts < t - timedelta(days=3)]
    if len(recent) >= 2 and len(prior) >= 4:
        r, p = median(recent), median(prior)
        ch = (r - p) / p
        if abs(ch) >= 0.05:
            word = "fallen" if ch < 0 else "risen"
            out.append(dict(
                key="weight_change", category="weight", level=4 if abs(ch) >= 0.10 else 3,
                side="below" if ch < 0 else "above",
                title=f"Recorded weight has {word} {abs(ch) * 100:.1f}% against this bird's recent baseline",
                observations=[
                    _obs(f"Median of the last {len(recent)} weighings (3 days): {r:.0f} g.", DERIVED),
                    _obs(f"Median of the previous {len(prior)} weighings (14 days): {p:.0f} g.", DERIVED),
                    _obs("Weights were entered manually by platform users.", USER)],
                period=(t - timedelta(days=17), t), confidence=round(min(0.85, 0.5 + 0.04 * (len(recent) + len(prior))), 2),
                limitations="Based on manually recorded weights; changes in weighing time, scale or crop contents "
                            "can produce the same pattern. Intentional weight management is not known to the system.",
                follow_up="Confirm with a repeat weighing. If the change was not intended, a veterinary assessment "
                          "is recommended."))
    return out


def _flight_rules(db: Session, f: Falcon, t: datetime) -> list[dict]:
    out = []
    flights = db.scalars(select(Flight).where(Flight.falcon_id == f.id, Flight.open.is_(False)).order_by(Flight.start)).all()
    recent = [fl for fl in flights if fl.start >= t - timedelta(days=5)][-4:]
    hist = [fl for fl in flights if fl.start < t - timedelta(days=5)]
    if len(recent) >= 2 and len(hist) >= baseline.MIN_FLIGHTS:
        findings = []
        for k in ("duration_s", "distance_m", "max_height_m", "activity_index"):
            zs, vals, used = [], [], None
            for fl in recent:                      # each recent flight against like-for-like history
                b = baseline.build(baseline.same_pattern([h.metrics for h in hist], fl.metrics)[0]).get(k)
                v = baseline._val(fl.metrics, k)
                if b and v is not None:
                    zs.append(baseline.zscore(v, b))
                    vals.append(v)
                    used = b
            if len(zs) >= 2 and median(zs) <= -baseline.NOTABLE_Z:
                findings.append((k, median(vals), used, median(zs)))
        if findings:
            n = min(b["n"] for _, _, b, _ in findings)
            unit = {"duration_s": "s", "distance_m": "m", "max_height_m": "m", "activity_index": "g"}
            out.append(dict(
                key="flight_activity", category="activity", level=2,
                title="Recent flights are shorter or less active than this bird's own baseline",
                observations=[_obs(
                    f"{baseline.LABELS[k]}: recent median {v:.1f} {unit[k]} vs baseline median {b['median']:.1f} {unit[k]} "
                    f"(typical {b['p10']:.1f}–{b['p90']:.1f}); modified z-score {z:.1f}.", AI) for k, v, b, z in findings]
                + [_obs(f"Compared {len(recent)} flights in the last 5 days with earlier flights of the same bird "
                         f"(same flight pattern where enough history exists; {n} flights in the smallest baseline).", DERIVED)],
                period=(recent[0].start, recent[-1].end), confidence=round(baseline.confidence(n) * 0.85, 2),
                limitations="Weather, heat, wind, training type, moult and tracker data gaps all change flight metrics. "
                            "Only flights recorded by a tracker are included. " + NOT_A_DIAGNOSIS,
                follow_up="The falconer should review these sessions (conditions, training type, bird's response) "
                          "and keep observing. If the change persists or other changes appear, discuss with a "
                          "veterinary professional."))
    # unusual inactivity: bird flew regularly, tracker still active, but no flights for several days
    before = [fl for fl in flights if t - timedelta(days=24) <= fl.start < t - timedelta(days=3)]
    last3 = [fl for fl in flights if fl.start >= t - timedelta(days=3)]
    days_flown = len({fl.start.date() for fl in before})
    if not last3 and days_flown >= 12:
        rest = db.scalar(select(TrainingSession.id).where(
            TrainingSession.falcon_id == f.id, TrainingSession.start >= t - timedelta(days=3),
            TrainingSession.type.in_(["rest day", "moult rest"])))
        if not rest:
            out.append(dict(
                key="inactivity", category="activity", level=2,
                title="No recorded flights for 3 days — unusual for this bird",
                observations=[_obs(f"Flights were recorded on {days_flown} of the previous 21 days.", DERIVED),
                              _obs("No flight segments were detected in tracker data for the last 3 days.", DERIVED)],
                period=(t - timedelta(days=3), t), confidence=0.45,
                limitations="A missing flight record may simply mean the tracker was not fitted, was switched off, "
                            "or had no coverage. Planned rest days that were not logged look identical.",
                follow_up="Confirm whether the bird was flown. If it was rested on purpose, log a rest day."))
    return out


def _training_rules(db: Session, f: Falcon, t: datetime) -> list[dict]:
    ss = db.scalars(select(TrainingSession).where(TrainingSession.falcon_id == f.id,
                                                  TrainingSession.start >= t - timedelta(days=28))).all()
    bad = ("declined", "shortened")
    recent = [s for s in ss if s.start >= t - timedelta(days=7) and s.outcome]
    prior = [s for s in ss if s.start < t - timedelta(days=7) and s.outcome]
    rb = [s for s in recent if s.outcome in bad]
    if len(rb) >= 2 and len(rb) / len(recent) >= 0.5 and len(prior) >= 5 and \
            sum(s.outcome in bad for s in prior) / len(prior) < 0.25:
        return [dict(
            key="training_participation", category="training", level=2,
            title="Training participation has changed in the last 7 days",
            observations=[
                _obs(f"{len(rb)} of {len(recent)} sessions in the last 7 days were recorded as declined or shortened.", USER),
                _obs(f"In the previous 3 weeks it was {sum(s.outcome in bad for s in prior)} of {len(prior)}.", USER)],
            period=(t - timedelta(days=7), t), confidence=0.55,
            limitations="Session outcomes are trainer judgements entered by hand and depend on conditions and "
                        "training plan. " + NOT_A_DIAGNOSIS,
            follow_up="The trainer should review notes and conditions for these sessions and continue to observe.")]
    return []


def _injury_rules(db: Session, f: Falcon, t: datetime) -> list[dict]:
    out = []
    recs = db.scalars(select(HealthRecord).where(HealthRecord.falcon_id == f.id, HealthRecord.kind == "injury",
                                                 HealthRecord.done.is_(False), HealthRecord.ts >= t - timedelta(days=21))).all()
    for r in recs:
        lvl = {"severe": 5, "moderate": 4}.get(r.severity or "", 3)
        out.append(dict(
            key=f"injury_{r.id}", category="injury", level=lvl,
            title=f"Open injury record: {r.title}",
            observations=[_obs(f"Injury recorded {r.ts:%d %b %Y} by {r.recorder_name or 'a user'}"
                               f" — severity entered as “{r.severity or 'not stated'}”.", r.provenance),
                          _obs("The record has not been marked as resolved.", DERIVED)],
            period=(r.ts, t), confidence=0.9,
            limitations="This alert repeats a human-entered record; the system has not assessed the injury itself.",
            follow_up=("Contact a veterinary professional now." if lvl == 5 else
                       "Arrange a veterinary assessment." if lvl == 4 else
                       "Monitor closely and consult a veterinary professional if it does not improve.")))
    return out


def evaluate(db: Session, f: Falcon, at: datetime | None = None) -> list[Alert]:
    """Run all rules for one falcon and synchronise its alerts."""
    t = at or now()
    found = _weight_rules(db, f, t) + _flight_rules(db, f, t) + _training_rules(db, f, t) + _injury_rules(db, f, t)

    keys = {a["key"] for a in found}
    weight_low = any(a["category"] == "weight" and a.get("side") == "below" for a in found)
    behaviour = keys & {"flight_activity", "inactivity", "training_participation"}
    if weight_low and behaviour:
        parts = [a for a in found if a["key"] in behaviour or (a["category"] == "weight" and a.get("side") == "below")]
        found.append(dict(
            key="combined", category="combined", level=4,
            title="Weight loss and reduced activity observed together",
            observations=[_obs(a["title"] + ".", AI) for a in parts],
            period=(min(a["period"][0] for a in parts), t),
            confidence=round(min(0.8, max(a["confidence"] for a in parts) + 0.1), 2),
            limitations="Two independent data sources changed in the same period, which makes a chance finding "
                        "less likely — but the cause is unknown. " + NOT_A_DIAGNOSIS,
            follow_up="A veterinary assessment is recommended. Share this bird's weight chart and recent flight "
                      "summaries with the veterinary professional."))
    if not found:
        found.append(dict(
            key="summary", category="summary", level=1, title="No changes from this bird's baseline detected",
            observations=[_obs("Recorded weights, tracker flights, training outcomes and open injury records were checked.", DERIVED)],
            period=(t - timedelta(days=21), t), confidence=0.5,
            limitations="Absence of an alert is not evidence of good health. The system only sees what is recorded.",
            follow_up="Continue routine observation and scheduled veterinary checks."))

    existing = {a.key: a for a in db.scalars(select(Alert).where(
        Alert.falcon_id == f.id, Alert.status.in_(["open", "acknowledged", "reviewed"]))).all()}
    result = []
    for a in found:
        cur = existing.pop(a["key"], None)
        is_new = cur is None
        escalated = not is_new and a["level"] > cur.level
        if is_new:
            cur = Alert(falcon_id=f.id, key=a["key"], created=t)
        if escalated:
            cur.status = "open"
        cur.level, cur.category, cur.title = a["level"], a["category"], a["title"]
        cur.observations, cur.confidence = a["observations"], a["confidence"]
        cur.period_start, cur.period_end = a["period"]
        cur.limitations, cur.follow_up, cur.updated = a["limitations"], a["follow_up"], t
        if is_new:
            db.add(cur)
        if (is_new and a["level"] >= 2) or escalated:
            head = f"{f.name}: escalated to “{LEVELS[a['level']]}”" if escalated else f"{f.name}: {LEVELS[a['level']]}"
            notify(db, f.org_id, f.id, "health_alert", SEVERITY[a["level"]], head, a["title"],
                   key=f"alert:{f.id}:{a['key']}:{a['level']}")
        result.append(cur)
    for stale in existing.values():      # condition no longer present
        stale.status, stale.updated = "resolved", t
    db.flush()
    return result


def followups_due(db: Session, f: Falcon, t: datetime | None = None) -> None:
    today = (t or now()).date().isoformat()
    for r in db.scalars(select(HealthRecord).where(HealthRecord.falcon_id == f.id, HealthRecord.due_date.is_not(None),
                                                   HealthRecord.done.is_(False), HealthRecord.due_date <= today)).all():
        notify(db, f.org_id, f.id, "followup_due", "notice", f"{f.name}: follow-up due — {r.title}",
               f"Due {r.due_date}.", key=f"followup:{r.id}")
