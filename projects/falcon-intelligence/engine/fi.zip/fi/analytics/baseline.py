"""Individual baselines.

A falcon is only ever compared with *its own* history. There is deliberately no universal
performance score and no cross-bird / cross-species ranking: species, age, sex, training stage
and weather make such comparisons scientifically unjustified.

Method: robust statistics (median and MAD) over the bird's previous flights. The modified
z-score 0.6745·(x − median)/MAD is used because flight metrics are skewed and outlier-prone.
Trend: Theil–Sen slope (median of pairwise slopes), which tolerates outliers.
"""
from __future__ import annotations

import numpy as np

from ..models import AI

BASELINE_METRICS = ["duration_s", "distance_m", "max_height_m", "avg_speed_mps", "max_speed_mps",
                    "climb_rate_mps", "descent_rate_mps", "turn_total_deg", "activity_index", "rest_time_s"]
MIN_FLIGHTS = 6          # below this, no baseline is reported
NOTABLE_Z, UNUSUAL_Z = 2.5, 3.5

LABELS = {"duration_s": "Flight duration", "distance_m": "Distance", "max_height_m": "Max height above launch",
          "avg_speed_mps": "Average speed", "max_speed_mps": "Peak speed", "climb_rate_mps": "Climb rate",
          "descent_rate_mps": "Descent rate", "turn_total_deg": "Total turning", "activity_index": "Activity index",
          "rest_time_s": "Rest time"}


def _val(metrics: dict | None, key: str) -> float | None:
    m = (metrics or {}).get(key)
    return m["value"] if isinstance(m, dict) else None


def robust(values: list[float]) -> dict | None:
    x = np.array([v for v in values if v is not None], float)
    if len(x) < MIN_FLIGHTS:
        return None
    med = float(np.median(x))
    mad = float(np.median(np.abs(x - med)))
    # floor the spread so near-constant histories do not produce absurd z-scores
    mad = max(mad, 0.05 * abs(med), 1e-6)
    return {"n": int(len(x)), "median": med, "mad": mad, "p10": float(np.percentile(x, 10)),
            "p90": float(np.percentile(x, 90))}


def zscore(x: float, base: dict) -> float:
    return 0.6745 * (x - base["median"]) / base["mad"]


def theil_sen(y: list[float]) -> float | None:
    y_ = np.array(y, float)
    n = len(y_)
    if n < 5:
        return None
    i, j = np.triu_indices(n, 1)
    return float(np.median((y_[j] - y_[i]) / (j - i)))


def build(history: list[dict | None]) -> dict:
    """history: metrics dicts of the bird's earlier flights, oldest first."""
    out = {}
    for k in BASELINE_METRICS:
        b = robust([_val(m, k) for m in history])
        if b:
            out[k] = b
    return out


def confidence(n: int) -> float:
    """How much weight a baseline deserves: grows with the number of flights behind it."""
    return round(float(min(0.9, 0.35 + 0.55 * (1 - np.exp(-(n - MIN_FLIGHTS + 1) / 12)))), 2)


def compare(metrics: dict, base: dict) -> list[dict]:
    """Compare one flight with the bird's own baseline."""
    rows = []
    for k, b in base.items():
        x = _val(metrics, k)
        if x is None:
            continue
        z = zscore(x, b)
        status = "unusual" if abs(z) >= UNUSUAL_Z else "notable" if abs(z) >= NOTABLE_Z else "typical"
        rows.append({"metric": k, "label": LABELS[k], "value": x, "unit": metrics[k]["unit"],
                     "baseline_median": round(b["median"], 2), "typical_low": round(b["p10"], 2),
                     "typical_high": round(b["p90"], 2), "z": round(z, 2), "status": status, "n": b["n"],
                     "direction": "above" if z > 0 else "below", "confidence": confidence(b["n"]),
                     "provenance": AI})
    return rows


def mann_kendall_z(y: list[float]) -> float:
    """Mann–Kendall trend statistic (normal approximation). |z| > 1.96 ≈ a monotonic trend at the 5% level."""
    y_ = np.array(y, float)
    n = len(y_)
    i, j = np.triu_indices(n, 1)
    s = float(np.sign(y_[j] - y_[i]).sum())
    var = n * (n - 1) * (2 * n + 5) / 18.0
    return 0.0 if s == 0 else (s - np.sign(s)) / np.sqrt(var)


def same_pattern(history: list[dict | None], target: dict | None) -> tuple[list[dict | None], str]:
    """Like-for-like history: earlier flights with the same flight pattern as `target`, if there are enough.

    A lure session and a waiting-on flight are different exercises; comparing one with a baseline
    built from the other would flag ordinary training variety as a deviation.
    """
    key = classify_pattern(target or {}, (target or {}).get("_phases"))["key"]
    same = [m for m in history if m and classify_pattern(m, m.get("_phases"))["key"] == key]
    if len(same) >= MIN_FLIGHTS:
        return same, f"earlier flights with the same pattern ({PATTERN_NAMES[key].lower()})"
    return history, "all earlier flights (too few of the same pattern for a like-for-like baseline)"


def trends(history: list[dict | None], window: int = 14) -> list[dict]:
    """Recent trend per flight pattern and metric. A direction is only reported when the
    Mann–Kendall test finds a monotonic trend; otherwise the result is 'no clear trend'."""
    out = []
    groups: dict[str, list] = {}
    for m in history:
        if m:
            groups.setdefault(classify_pattern(m, m.get("_phases"))["key"], []).append(m)
    for key, ms in groups.items():
        recent = ms[-window:]
        for k in BASELINE_METRICS:
            y = [v for v in (_val(m, k) for m in recent) if v is not None]
            slope = theil_sen(y)
            if slope is None or len(y) < 8:
                continue
            med = float(np.median(y)) or 1e-9
            pct = 100.0 * slope * (len(y) - 1) / abs(med)   # estimated change across the window
            z = mann_kendall_z(y)
            sig = abs(z) >= 1.96 and abs(pct) >= 8
            out.append({"metric": k, "label": LABELS[k], "pattern": PATTERN_NAMES[key], "flights": len(y),
                        "change_pct": round(pct, 1), "z": round(float(z), 2),
                        "direction": ("rising" if pct > 0 else "falling") if sig else "no clear trend", "provenance": AI})
    return out


def pattern_signature(metrics: dict, phases: dict | None) -> list[float]:
    """Compact shape descriptor of a flight used to find repeated flight patterns."""
    ph = phases or {}
    d = _val(metrics, "distance_m") or 0.0
    dur = _val(metrics, "duration_s") or 1.0
    return [ph.get("climb", 0), ph.get("level", 0), ph.get("descent", 0), ph.get("stoop", 0) * 5,
            ph.get("rest", 0), min(1.0, (_val(metrics, "circles") or 0) / 10),
            min(1.0, (_val(metrics, "max_height_m") or 0) / 400), min(1.0, d / dur / 25)]


PATTERN_NAMES = {
    "high_circling": "High circling flight (ringing up / waiting on)",
    "low_direct": "Low direct flight (pursuit / lure passes)",
    "mixed": "Mixed flight",
    "short_hop": "Short low hop",
}


def classify_pattern(metrics: dict, phases: dict | None) -> dict:
    """Rule-based flight-pattern label. An interpretation, not a measurement."""
    h = _val(metrics, "max_height_m") or 0
    circles = _val(metrics, "circles") or 0
    dur = _val(metrics, "duration_s") or 0
    if dur < 90 and h < 30:
        k = "short_hop"
    elif h >= 120 and circles >= 3:
        k = "high_circling"
    elif h < 60:
        k = "low_direct"
    else:
        k = "mixed"
    return {"key": k, "label": PATTERN_NAMES[k], "provenance": AI,
            "basis": f"max height {h:.0f} m, net rotations {circles:.1f}, duration {dur:.0f} s"}


def similar_flights(target: list[float], others: list[tuple[int, list[float]]], top: int = 5) -> list[dict]:
    t = np.array(target)
    scored = [(fid, float(np.linalg.norm(t - np.array(sig)))) for fid, sig in others]
    scored.sort(key=lambda s: s[1])
    return [{"flight_id": fid, "similarity": round(max(0.0, 1 - d / 1.2), 2)} for fid, d in scored[:top]]
