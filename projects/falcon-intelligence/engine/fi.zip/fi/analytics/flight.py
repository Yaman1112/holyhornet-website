"""Flight metric engine.

Every metric is returned as {"value", "unit", "provenance", "note"} so the UI can always show
whether a number was measured by a sensor, derived mathematically, or estimated.
"""
from __future__ import annotations

import math
from datetime import datetime

import numpy as np

from ..models import DERIVED, ESTIMATED, MEASURED

R_EARTH = 6_371_008.8


def haversine(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dp, dl = p2 - p1, np.radians(lon2) - np.radians(lon1)
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * R_EARTH * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def bearing(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dl = np.radians(lon2) - np.radians(lon1)
    y = np.sin(dl) * np.cos(p2)
    x = np.cos(p1) * np.sin(p2) - np.sin(p1) * np.cos(p2) * np.cos(dl)
    return (np.degrees(np.arctan2(y, x)) + 360) % 360


def _m(value, unit, provenance, note=""):
    if value is None or (isinstance(value, float) and (math.isnan(value) or math.isinf(value))):
        return None
    return {"value": round(float(value), 2), "unit": unit, "provenance": provenance, "note": note}


def _smooth(x: np.ndarray, t: np.ndarray, window_s: float = 5.0) -> np.ndarray:
    if len(x) < 3:
        return x
    dt = float(np.median(np.diff(t))) or 1.0
    k = max(1, int(round(window_s / dt)))
    if k <= 1:
        return x
    pad = np.pad(x, (k // 2, k - 1 - k // 2), mode="edge")
    return np.convolve(pad, np.ones(k) / k, mode="valid")


def _runs(mask: np.ndarray):
    """Yield (start_idx, end_idx_inclusive) for each True run."""
    if not mask.any():
        return
    d = np.diff(np.concatenate(([0], mask.astype(int), [0])))
    for s, e in zip(np.where(d == 1)[0], np.where(d == -1)[0]):
        yield int(s), int(e - 1)


def compute(points: list[dict]) -> dict:
    """points: dicts with ts (datetime), lat, lon, alt_m, speed_mps, heading_deg, acc_g, quality, alt_source.

    Returns {"metrics": {...}, "phases": {...}, "events": [...], "quality": {...}, "series": {...}}
    """
    pts = [p for p in points if p.get("lat") is not None and p.get("lon") is not None and (p.get("quality") or 0) >= 0.3]
    n_all = len(points)
    if len(pts) < 5:
        return {"metrics": {}, "phases": {}, "events": [], "series": {},
                "quality": {"usable_points": len(pts), "total_points": n_all, "score": 0.0,
                            "note": "Too few usable position fixes to compute flight metrics."}}

    t0: datetime = pts[0]["ts"]
    t = np.array([(p["ts"] - t0).total_seconds() for p in pts])
    lat = np.array([p["lat"] for p in pts], float)
    lon = np.array([p["lon"] for p in pts], float)
    dt = np.diff(t)
    dt[dt <= 0] = np.nan
    seg = haversine(lat[:-1], lon[:-1], lat[1:], lon[1:])
    med_dt = float(np.nanmedian(dt))

    # --- speed -----------------------------------------------------------------------------
    spd_raw = np.array([p["speed_mps"] if p.get("speed_mps") is not None else np.nan for p in pts], float)
    have_spd = np.isfinite(spd_raw).mean() >= 0.8
    spd_der = np.concatenate(([np.nan], seg / dt))
    spd = np.where(np.isfinite(spd_raw), spd_raw, spd_der) if have_spd else spd_der
    spd = np.nan_to_num(spd, nan=0.0)
    spd_prov = MEASURED if have_spd else DERIVED
    spd_note = ("Ground speed reported by the GNSS receiver." if have_spd
                else "No device speed — computed from distance between consecutive fixes.")

    # --- altitude --------------------------------------------------------------------------
    alt_raw = np.array([p["alt_m"] if p.get("alt_m") is not None else np.nan for p in pts], float)
    have_alt = np.isfinite(alt_raw).mean() >= 0.6
    alt_src = next((p.get("alt_source") for p in pts if p.get("alt_source")), None)
    metrics: dict = {}
    events: list[dict] = []

    def ev(i: int, kind: str, label: str, prov: str):
        events.append({"kind": kind, "label": label, "t": round(float(t[i]), 1),
                       "ts": pts[i]["ts"].isoformat() + "Z", "lat": float(lat[i]), "lon": float(lon[i]),
                       "provenance": prov})

    duration = float(t[-1] - t[0])
    distance = float(np.nansum(seg))
    metrics["duration_s"] = _m(duration, "s", DERIVED, "Last fix time minus first fix time of the flight segment.")
    metrics["distance_m"] = _m(distance, "m", DERIVED,
                               "Sum of great-circle distances between fixes; under-estimates tight turns between fixes.")
    metrics["max_speed_mps"] = _m(float(np.max(spd)), "m/s", spd_prov, spd_note)
    moving = spd > 1.5
    metrics["avg_speed_mps"] = _m(float(np.mean(spd[moving])) if moving.any() else 0.0, "m/s", DERIVED,
                                  "Mean ground speed while moving (> 1.5 m/s).")
    ev(0, "launch", "Launch (first airborne fix)", DERIVED)
    ev(int(np.argmax(spd)), "max_speed", f"Peak ground speed {np.max(spd):.1f} m/s", spd_prov)

    vs = np.zeros_like(t)
    hgt = np.full_like(t, np.nan)
    if have_alt:
        idx = np.where(np.isfinite(alt_raw))[0]
        alt = np.interp(np.arange(len(t)), idx, alt_raw[idx])
        ground = float(np.median(alt[:3]))
        hgt = alt - ground
        alt_s = _smooth(alt, t)
        vs = np.gradient(alt_s, t)
        a_note = f"Reported by the {'barometric sensor' if alt_src == 'baro' else 'GNSS receiver'} (MSL / pressure altitude)."
        metrics["max_altitude_m"] = _m(float(np.max(alt)), "m", MEASURED, a_note)
        metrics["avg_altitude_m"] = _m(float(np.mean(alt)), "m", DERIVED, "Mean of reported altitude over the flight.")
        metrics["max_height_m"] = _m(float(np.max(hgt)), "m", ESTIMATED,
                                     "Height above the launch point; assumes terrain stays at launch elevation.")
        up, down = vs[vs > 0.3], vs[vs < -0.3]
        metrics["climb_rate_mps"] = _m(float(np.percentile(up, 95)) if len(up) else 0.0, "m/s", DERIVED,
                                       "95th percentile of 5-s smoothed vertical speed while climbing.")
        metrics["avg_climb_rate_mps"] = _m(float(np.mean(up)) if len(up) else 0.0, "m/s", DERIVED,
                                           "Mean smoothed vertical speed while climbing.")
        metrics["descent_rate_mps"] = _m(float(-np.percentile(down, 5)) if len(down) else 0.0, "m/s", DERIVED,
                                         "95th percentile of 5-s smoothed vertical speed while descending.")
        ev(int(np.argmax(alt)), "max_altitude", f"Highest point {np.max(hgt):.0f} m above launch", ESTIMATED)

    # --- turning ---------------------------------------------------------------------------
    hdg_raw = np.array([p["heading_deg"] if p.get("heading_deg") is not None else np.nan for p in pts], float)
    if np.isfinite(hdg_raw).mean() >= 0.8:
        hdg, h_prov = hdg_raw, MEASURED
    else:
        hdg = np.concatenate((bearing(lat[:-1], lon[:-1], lat[1:], lon[1:]), [np.nan]))
        h_prov = DERIVED
    ok = np.isfinite(hdg) & moving
    if ok.sum() > 5:
        h = np.unwrap(np.radians(hdg[ok]))
        dh = np.degrees(np.diff(h))
        tt = np.diff(t[ok])
        valid = tt < 4 * med_dt
        dh, tt = dh[valid], tt[valid]
        if len(dh):
            total = float(np.sum(np.abs(dh)))
            right = float(np.sum(dh[dh > 0]))
            left = float(-np.sum(dh[dh < 0]))
            metrics["turn_total_deg"] = _m(total, "deg", DERIVED,
                                           f"Cumulative heading change while moving (heading {h_prov}).")
            metrics["turn_rate_dps"] = _m(float(np.percentile(np.abs(dh / tt), 95)), "deg/s", DERIVED,
                                          "95th percentile turn rate.")
            metrics["turn_right_share"] = _m(right / (right + left) if right + left else 0.5, "ratio", DERIVED,
                                             "Share of turning that was clockwise (0.5 = balanced).")
            metrics["circles"] = _m(abs(right - left) / 360.0, "turns", DERIVED,
                                    "Net full rotations — indicates sustained circling / ringing up.")

    # --- acceleration ----------------------------------------------------------------------
    acc = np.array([p["acc_g"] if p.get("acc_g") is not None else np.nan for p in pts], float)
    if np.isfinite(acc).mean() >= 0.5:
        metrics["peak_accel_g"] = _m(float(np.nanmax(acc)), "g", MEASURED, "Peak accelerometer magnitude.")
        metrics["activity_index"] = _m(float(np.nanmean(np.abs(acc - 1.0))), "g", DERIVED,
                                       "Mean dynamic acceleration (|a| − 1 g) — a movement-intensity proxy.")
    lon_acc = np.gradient(_smooth(spd, t, 3.0), t)
    metrics["peak_speed_gain_mps2"] = _m(float(np.percentile(lon_acc, 98)), "m/s²", DERIVED,
                                         "98th percentile rate of ground-speed increase (3-s smoothed).")

    # --- rest periods ----------------------------------------------------------------------
    still = spd < 1.5
    if have_alt:
        still &= np.abs(vs) < 0.7
    rests = [(s, e) for s, e in _runs(still) if t[e] - t[s] >= 20]
    metrics["rest_periods"] = _m(float(len(rests)), "count", DERIVED,
                                 "Stretches ≥ 20 s with ground speed < 1.5 m/s and no altitude change.")
    metrics["rest_time_s"] = _m(float(sum(t[e] - t[s] for s, e in rests)), "s", DERIVED, "Total time in rest periods.")
    for s, e in rests:
        ev(s, "rest", f"Rest period {t[e] - t[s]:.0f} s", DERIVED)

    # --- phases (rule-based interpretation) ------------------------------------------------
    phase = np.full(len(t), "level", dtype=object)
    if have_alt:
        phase[vs > 1.0] = "climb"
        phase[vs < -1.0] = "descent"
        stoop = (vs < -8.0) & (spd > 20.0)
        phase[stoop] = "stoop"
        for s, e in _runs(stoop):
            if t[e] - t[s] >= 2:
                ev(s, "stoop", f"Steep fast descent ({-vs[s:e + 1].min():.0f} m/s down)", ESTIMATED)
    phase[still] = "rest"
    w = np.concatenate((np.diff(t), [med_dt]))
    w = np.minimum(w, 4 * med_dt)
    phases = {k: round(float(w[phase == k].sum() / w.sum()), 3) for k in ("climb", "level", "descent", "stoop", "rest")}
    ev(len(t) - 1, "recovery", "Last fix of flight segment", DERIVED)
    events.sort(key=lambda e: e["t"])

    # --- data quality ----------------------------------------------------------------------
    q = np.array([p.get("quality") or 0 for p in pts], float)
    gaps = int(np.nansum(dt > 3 * med_dt))
    expected = duration / med_dt + 1 if med_dt else len(pts)
    coverage = min(1.0, len(pts) / expected) if expected else 1.0
    score = float(np.clip(0.6 * q.mean() + 0.4 * coverage - 0.03 * gaps, 0, 1))
    quality = {"usable_points": len(pts), "total_points": n_all, "median_interval_s": round(med_dt, 2), "gaps": gaps,
               "coverage": round(coverage, 3), "mean_fix_quality": round(float(q.mean()), 3), "score": round(score, 3),
               "altitude_source": alt_src, "speed_source": "device" if have_spd else "derived"}

    series = {"t": [round(float(x), 1) for x in t], "lat": lat.round(6).tolist(), "lon": lon.round(6).tolist(),
              "speed": spd.round(2).tolist(), "height": [None if math.isnan(x) else round(float(x), 1) for x in hgt],
              "vs": vs.round(2).tolist(), "phase": phase.tolist(),
              "cum_dist": np.concatenate(([0.0], np.nancumsum(seg))).round(1).tolist()}
    return {"metrics": {k: v for k, v in metrics.items() if v is not None}, "phases": phases, "events": events,
            "quality": quality, "series": series}


PHASE_NOTE = ("Flight phases are a rule-based interpretation of vertical speed and ground speed "
              "(estimated, not a measured behaviour).")
