"""Falcon Intelligence — falcon monitoring, telemetry, health observation and flight performance platform."""

__version__ = "0.1.0"
