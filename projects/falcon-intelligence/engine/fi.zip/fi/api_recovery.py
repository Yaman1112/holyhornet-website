"""Recovery Center: lost-falcon cases, sightings, actions, expiring share links, location-access log.

Security model
  * A falcon's location is never public. A case is visible to organisation members with
    recovery.read, and to users with the `recovery` role only when they are a named contact.
  * Outside helpers get an expiring, revocable link (opaque token, stored hashed). The link shows
    the minimum needed to search — no ownership or identification details.
  * Every view of case location data, by a user or through a link, is written to the access log.
"""
from __future__ import annotations

import secrets
import time
from collections import defaultdict, deque
from datetime import timedelta

from fastapi import APIRouter, Body, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from .analytics import flight as flight_engine
from .analytics import health
from .api_core import need, parse_dt
from .auth import audit, can, current_user, get_falcon, log_location, require, sha
from .models import (DERIVED, Falcon, LocationAccessLog, RecoveryAction, RecoveryCase, ShareLink, Sighting, SpeciesProfile,
                     TelemetryPoint, TimelineEvent, User, Zone, get_db, now)
from .telemetry import ingest

router = APIRouter(prefix="/api")

# --- small in-memory rate limiter (per client address) ------------------------------------------
_hits: dict[str, deque] = defaultdict(deque)


def rate_limit(request: Request, bucket: str, limit: int = 30, window: float = 60.0) -> None:
    key = f"{bucket}:{request.client.host if request.client else 'unknown'}"
    q, t = _hits[key], time.monotonic()
    while q and t - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(429, "Too many requests — try again in a minute")
    q.append(t)


def _case(db: Session, user: User, cid: int) -> RecoveryCase:
    c = db.get(RecoveryCase, cid)
    if not c or c.org_id != user.org_id:
        raise HTTPException(404, "Recovery case not found")
    if user.role == "recovery" and user.id not in (c.contacts or []):
        raise HTTPException(404, "Recovery case not found")
    return c


def _track(db: Session, falcon_id: int, hours: float = 12) -> list[dict]:
    """Recorded path leading up to the last valid fix."""
    last = db.scalar(select(TelemetryPoint).where(TelemetryPoint.falcon_id == falcon_id, TelemetryPoint.lat.is_not(None),
                                                  TelemetryPoint.quality >= 0.3).order_by(TelemetryPoint.ts.desc()))
    if not last:
        return []
    pts = db.scalars(select(TelemetryPoint).where(
        TelemetryPoint.falcon_id == falcon_id, TelemetryPoint.lat.is_not(None), TelemetryPoint.quality >= 0.3,
        TelemetryPoint.ts >= last.ts - timedelta(hours=hours)).order_by(TelemetryPoint.ts)).all()
    step = max(1, len(pts) // 1500)
    return [{"ts": p.ts.isoformat() + "Z", "lat": p.lat, "lon": p.lon, "alt_m": p.alt_m, "speed_mps": p.speed_mps} for p in pts[::step]]


def _assist(db: Session, f: Falcon, pos: dict) -> dict:
    """Lost-falcon assistance: derived facts about the last valid fix. No prediction of where the bird is."""
    p = pos.get("position")
    if not p:
        return {"facts": [], "note": "No valid tracker position exists for this falcon, so there is nothing to derive."}
    facts = []
    spd, hdg = p.get("speed_mps"), p.get("heading_deg")
    if spd is not None:
        moving = spd >= ingest.AIRBORNE_SPEED
        facts.append({"text": f"At the last valid fix the bird was {'moving at ' + format(spd * 3.6, '.0f') + ' km/h' if moving else 'stationary or slow'}"
                              + (f", heading {hdg:.0f}°" if moving and hdg is not None else "") + ".", "provenance": "measured"})
    for z in db.scalars(select(Zone).where(Zone.org_id == f.org_id)).all():
        d = float(flight_engine.haversine(z.lat, z.lon, p["lat"], p["lon"]))
        b = float(flight_engine.bearing(z.lat, z.lon, p["lat"], p["lon"]))
        if z.kind in ("home", "training"):
            facts.append({"text": f"Last valid fix is {d / 1000:.2f} km from “{z.name}” (bearing {b:.0f}° from the zone centre)"
                                  f"{' — inside the zone' if d <= z.radius_m else ''}.", "provenance": DERIVED})
    dev = pos.get("device") or {}
    if dev.get("battery_pct") is not None:
        facts.append({"text": f"Tracker battery was {dev['battery_pct']:.0f}% at its last report.", "provenance": "measured"})
    if p.get("accuracy_m") is not None:
        facts.append({"text": f"Estimated horizontal accuracy of the last fix: ±{p['accuracy_m']} m.", "provenance": "estimated"})
    return {"facts": facts,
            "note": "These are facts about the last recorded data. The platform does not predict where the falcon is now: "
                    "a bird can travel many kilometres after the last fix. Start from the last valid fix and confirmed sightings."}


def _case_out(db: Session, c: RecoveryCase, full: bool = False) -> dict:
    f = db.get(Falcon, c.falcon_id)
    d = c.as_dict()
    d["falcon"] = {"id": f.id, "name": f.name, "code": f.code}
    names = {u.id: u.name for u in db.scalars(select(User).where(User.id.in_((c.contacts or []) + [c.opened_by]))).all()}
    d["opened_by_name"] = names.get(c.opened_by)
    d["contact_names"] = [{"id": i, "name": names.get(i, "?")} for i in c.contacts or []]
    d["sightings_count"] = len(db.scalars(select(Sighting.id).where(Sighting.case_id == c.id)).all())
    if full:
        pos = ingest.position_status(db, f)
        d["current"] = pos
        d["track"] = _track(db, f.id)
        d["assist"] = _assist(db, f, pos)
        d["sightings"] = [s.as_dict() for s in db.scalars(select(Sighting).where(Sighting.case_id == c.id).order_by(Sighting.ts.desc())).all()]
        d["actions"] = [a.as_dict() for a in db.scalars(select(RecoveryAction).where(RecoveryAction.case_id == c.id).order_by(RecoveryAction.ts.desc())).all()]
        t = now()
        d["links"] = [{**l.as_dict(exclude=("token_hash",)),
                       "state": "revoked" if l.revoked_at else "expired" if l.expires < t else "active"}
                      for l in db.scalars(select(ShareLink).where(ShareLink.case_id == c.id).order_by(ShareLink.created_at.desc())).all()]
        d["access_log"] = [a.as_dict() for a in db.scalars(select(LocationAccessLog).where(LocationAccessLog.case_id == c.id)
                                                            .order_by(LocationAccessLog.ts.desc()).limit(60)).all()]
    return d


@router.get("/recovery")
def list_cases(status: str = "all", user: User = Depends(require("recovery.read")), db: Session = Depends(get_db)):
    q = select(RecoveryCase).where(RecoveryCase.org_id == user.org_id)
    if status in ("open", "closed"):
        q = q.where(RecoveryCase.status == status)
    cases = db.scalars(q.order_by(RecoveryCase.status.desc(), RecoveryCase.opened_at.desc())).all()
    if user.role == "recovery":
        cases = [c for c in cases if user.id in (c.contacts or [])]
    return [_case_out(db, c) for c in cases]


@router.get("/recovery/contacts")
def contacts(user: User = Depends(require("recovery.write")), db: Session = Depends(get_db)):
    us = db.scalars(select(User).where(User.org_id == user.org_id, User.active.is_(True))).all()
    return [{"id": u.id, "name": u.name, "role": u.role} for u in us if can(u, "recovery.read")]


@router.post("/falcons/{fid}/recovery")
def open_case(fid: int, body: dict = Body(...), user: User = Depends(require("recovery.write")), db: Session = Depends(get_db)):
    if user.role == "recovery":
        raise HTTPException(403, "Recovery contacts cannot open cases")
    f = get_falcon(db, user, fid)
    if db.scalar(select(RecoveryCase.id).where(RecoveryCase.falcon_id == fid, RecoveryCase.status == "open")):
        raise HTTPException(409, "This falcon already has an open recovery case")
    pos = ingest.position_status(db, f)
    valid = {u.id for u in db.scalars(select(User).where(User.org_id == f.org_id)).all()}
    contact_ids = [int(i) for i in body.get("contacts") or [] if int(i) in valid]
    c = RecoveryCase(org_id=f.org_id, falcon_id=fid, opened_by=user.id, circumstances=body.get("circumstances"),
                     last_confirmed_ts=parse_dt(body["last_confirmed_ts"]) if body.get("last_confirmed_ts") else None,
                     last_confirmed_note=body.get("last_confirmed_note"),
                     last_confirmed_lat=body.get("last_confirmed_lat"), last_confirmed_lon=body.get("last_confirmed_lon"),
                     contacts=contact_ids,
                     snapshot={"state": pos["state"], "label": pos["label"], "explain": pos["explain"],
                               "position": pos.get("position"), "device": pos.get("device"), "taken": now().isoformat() + "Z"})
    db.add(c)
    db.flush()
    db.add(RecoveryAction(case_id=c.id, user_name=user.name, text="Recovery case opened."))
    db.add(TimelineEvent(falcon_id=fid, kind="recovery", title="Reported missing — recovery case opened", ref_type="recovery_case", ref_id=c.id))
    for uid in contact_ids:
        health.notify(db, f.org_id, fid, "recovery", "urgent", f"Recovery case opened: {f.name}",
                      "You are an authorised recovery contact for this case.", key=f"recovery:{c.id}:{uid}")
        db.flush()
        from .models import Notification
        n = db.scalar(select(Notification).where(Notification.key == f"recovery:{c.id}:{uid}"))
        if n:
            n.user_id = uid
    health.notify(db, f.org_id, fid, "recovery", "urgent", f"{f.name} reported missing", "A recovery case is open.", key=f"recovery:{c.id}")
    audit(db, user, "recovery.open", "recovery_case", c.id)
    db.commit()
    return _case_out(db, c, full=True)


@router.get("/recovery/{cid}")
def get_case(cid: int, request: Request, user: User = Depends(require("recovery.read")), db: Session = Depends(get_db)):
    ingest.sweep(db)
    c = _case(db, user, cid)
    log_location(db, c.falcon_id, "recovery_case", user, case_id=c.id, ip=request.client.host if request.client else None)
    return _case_out(db, c, full=True)


@router.post("/recovery/{cid}/sightings")
def add_sighting(cid: int, body: dict = Body(...), user: User = Depends(require("recovery.write")), db: Session = Depends(get_db)):
    c = _case(db, user, cid)
    need(body, "description")
    s = Sighting(case_id=cid, ts=parse_dt(body.get("ts")), lat=body.get("lat"), lon=body.get("lon"), description=body["description"],
                 certainty="confirmed" if body.get("certainty") == "confirmed" else "possible", reporter_name=body.get("reporter_name") or user.name,
                 reported_by=user.id)
    db.add(s)
    f = db.get(Falcon, c.falcon_id)
    health.notify(db, c.org_id, c.falcon_id, "recovery", "warning", f"New sighting reported — {f.name}", body["description"][:200])
    db.commit()
    return s.as_dict()


@router.post("/recovery/{cid}/actions")
def add_action(cid: int, body: dict = Body(...), user: User = Depends(require("recovery.write")), db: Session = Depends(get_db)):
    _case(db, user, cid)
    need(body, "text")
    a = RecoveryAction(case_id=cid, user_name=user.name, text=body["text"])
    db.add(a)
    db.commit()
    return a.as_dict()


@router.post("/recovery/{cid}/close")
def close_case(cid: int, body: dict = Body(...), user: User = Depends(require("recovery.write")), db: Session = Depends(get_db)):
    c = _case(db, user, cid)
    if user.role == "recovery":
        raise HTTPException(403, "Only the owner's organisation can close a case")
    if body.get("outcome") not in ("recovered", "not recovered", "false alarm"):
        raise HTTPException(422, "outcome must be recovered, not recovered or false alarm")
    t = now()
    c.status, c.closed_at, c.closed_by, c.outcome, c.close_note = "closed", t, user.id, body["outcome"], body.get("note")
    for l in db.scalars(select(ShareLink).where(ShareLink.case_id == cid, ShareLink.revoked_at.is_(None))).all():
        l.revoked_at = t                                   # sharing ends with the case
    db.add(RecoveryAction(case_id=cid, user_name=user.name, text=f"Case closed — {body['outcome']}. All share links revoked."))
    db.add(TimelineEvent(falcon_id=c.falcon_id, kind="recovery", title=f"Recovery case closed — {body['outcome']}", ref_type="recovery_case", ref_id=cid))
    audit(db, user, "recovery.close", "recovery_case", cid, body["outcome"])
    db.commit()
    return _case_out(db, c, full=True)


# --- sharing ------------------------------------------------------------------------------------
@router.post("/recovery/{cid}/links")
def create_link(cid: int, request: Request, body: dict = Body(...), user: User = Depends(require("location.share")), db: Session = Depends(get_db)):
    c = _case(db, user, cid)
    if c.status != "open":
        raise HTTPException(422, "Location can only be shared while the case is open")
    need(body, "label")
    hours = float(body.get("hours") or 24)
    if not 0.25 <= hours <= 168:
        raise HTTPException(422, "A link can last between 15 minutes and 7 days")
    token = secrets.token_urlsafe(24)
    l = ShareLink(case_id=cid, token_hash=sha(token), label=body["label"], created_by=user.id, expires=now() + timedelta(hours=hours))
    db.add(l)
    db.add(RecoveryAction(case_id=cid, user_name=user.name, text=f"Location shared with “{body['label']}” for {hours:g} h."))
    audit(db, user, "recovery.share", "recovery_case", cid, body["label"])
    db.commit()
    return {"id": l.id, "expires": l.expires.isoformat() + "Z", "url": f"{str(request.base_url).rstrip('/')}/#/share/{token}",
            "note": "Shown once. Anyone with this link can see this falcon's last known position until it expires or is revoked."}


@router.post("/share-links/{lid}/revoke")
def revoke_link(lid: int, user: User = Depends(require("location.share")), db: Session = Depends(get_db)):
    l = db.get(ShareLink, lid)
    if not l:
        raise HTTPException(404, "Link not found")
    c = _case(db, user, l.case_id)
    if not l.revoked_at:
        l.revoked_at = now()
        db.add(RecoveryAction(case_id=c.id, user_name=user.name, text=f"Share link for “{l.label}” revoked."))
        audit(db, user, "recovery.revoke_link", "share_link", lid)
        db.commit()
    return {"ok": True}


def _link(db: Session, token: str) -> tuple[ShareLink, RecoveryCase]:
    l = db.scalar(select(ShareLink).where(ShareLink.token_hash == sha(token)))
    c = db.get(RecoveryCase, l.case_id) if l else None
    if not l or l.revoked_at or l.expires < now() or not c or c.status != "open":
        raise HTTPException(404, "This link is not valid, has expired or was revoked")   # one message for all cases
    return l, c


@router.get("/share/{token}")
def shared_view(token: str, request: Request, db: Session = Depends(get_db)):
    """Public endpoint reached only with a valid link token. Minimal data; fully logged."""
    rate_limit(request, "share")
    l, c = _link(db, token)
    f = db.get(Falcon, c.falcon_id)
    l.access_count, l.last_access = l.access_count + 1, now()
    db.commit()
    log_location(db, f.id, "shared_link", actor=f"link:{l.id}", actor_name=l.label, case_id=c.id,
                 ip=request.client.host if request.client else None)
    pos = ingest.position_status(db, f)
    sp = db.get(SpeciesProfile, f.species_id) if f.species_id else None
    return {"falcon": {"name": f.name, "species": sp.common_name if sp else None, "sex": f.sex},     # no owner / ring / chip
            "case": {"opened_at": c.opened_at.isoformat() + "Z", "circumstances": c.circumstances,
                     "last_confirmed_ts": c.last_confirmed_ts.isoformat() + "Z" if c.last_confirmed_ts else None,
                     "last_confirmed_note": c.last_confirmed_note,
                     "last_confirmed": [c.last_confirmed_lat, c.last_confirmed_lon] if c.last_confirmed_lat is not None else None},
            "position": {k: pos.get(k) for k in ("state", "label", "explain", "age_s", "position")},
            "battery_pct": (pos.get("device") or {}).get("battery_pct"),
            "track": _track(db, f.id, hours=6),
            "sightings": [s.as_dict(exclude=("reported_by", "via_link_id")) for s in
                          db.scalars(select(Sighting).where(Sighting.case_id == c.id).order_by(Sighting.ts.desc())).all()],
            "link": {"label": l.label, "expires": l.expires.isoformat() + "Z"},
            "notice": "Shared in confidence for the recovery of this falcon only. Do not forward. Access is logged."}


@router.post("/share/{token}/sightings")
def shared_sighting(token: str, request: Request, body: dict = Body(...), db: Session = Depends(get_db)):
    rate_limit(request, "share-write", limit=10)
    l, c = _link(db, token)
    need(body, "description")
    lat, lon = body.get("lat"), body.get("lon")
    if lat is not None and not (-90 <= float(lat) <= 90 and -180 <= float(lon or 0) <= 180):
        raise HTTPException(422, "Invalid coordinates")
    s = Sighting(case_id=c.id, lat=lat, lon=lon, description=str(body["description"])[:2000], certainty="possible",
                 reporter_name=(str(body.get("reporter_name") or "")[:120] or l.label), via_link_id=l.id)
    db.add(s)
    f = db.get(Falcon, c.falcon_id)
    health.notify(db, c.org_id, c.falcon_id, "recovery", "warning", f"New sighting via shared link — {f.name}", s.description[:200])
    db.commit()
    return {"ok": True}


@router.get("/falcons/{fid}/location-access")
def location_access(fid: int, user: User = Depends(require("access.manage")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    return [a.as_dict() for a in db.scalars(select(LocationAccessLog).where(LocationAccessLog.falcon_id == fid)
                                            .order_by(LocationAccessLog.ts.desc()).limit(200)).all()]
