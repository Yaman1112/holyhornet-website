"""Computer-vision observation tools.

What ships here is deliberately modest and honest:

* image_quality        classical image statistics — tells the user whether a photo is usable.
* identity_candidates  ranks registered falcons by appearance similarity (colour + gradient
                       descriptor). It is an UNVALIDATED retrieval aid: it proposes candidates
                       for a human to confirm and never asserts an identity.
* detection            pluggable detector backend. No falcon-specific model ships with the
                       platform, because none has been trained and benchmarked yet. If an
                       Ultralytics model is configured (FI_DETECTOR_WEIGHTS) it is used and its
                       validation status is reported from FI_DETECTOR_VALIDATED.
* video_motion         classical motion analysis (background subtraction): activity timeline,
                       movement direction, motion onsets / offsets as *possible* take-off /
                       landing events, and a periodicity estimate of wing movement.

Every result carries `validated`, a confidence and explicit limitations.
See docs/CV_MODEL_PLAN.md for the model benchmark and dataset plan.
"""
from __future__ import annotations

import os
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

try:  # optional
    import cv2
except Exception:  # pragma: no cover
    cv2 = None

OBSERVATION_ONLY = "Observation aid only — not a veterinary diagnostic tool."


def _load(path: str | Path, size: int | None = None) -> np.ndarray:
    im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
    if size:
        im = im.resize((size, size), Image.BILINEAR)
    return np.asarray(im, dtype=np.float32)


def image_quality(path: str | Path) -> dict:
    im = ImageOps.exif_transpose(Image.open(path)).convert("RGB")
    w, h = im.size
    g = np.asarray(im.convert("L").resize((min(w, 640), max(1, int(min(w, 640) * h / w)))), dtype=np.float32)
    lap = (-4 * g[1:-1, 1:-1] + g[:-2, 1:-1] + g[2:, 1:-1] + g[1:-1, :-2] + g[1:-1, 2:])
    sharp = float(lap.var())
    bright, contrast = float(g.mean()), float(g.std())
    issues = []
    if min(w, h) < 480:
        issues.append("low resolution (shorter side under 480 px)")
    if sharp < 60:
        issues.append("blurred or out of focus")
    if bright < 50:
        issues.append("under-exposed")
    if bright > 205:
        issues.append("over-exposed")
    if contrast < 25:
        issues.append("very low contrast")
    score = float(np.clip(1.0 - 0.25 * len(issues), 0, 1))
    return {"task": "image_quality", "backend": "classical-statistics", "validated": True,
            "result": {"width": w, "height": h, "sharpness": round(sharp, 1), "brightness": round(bright, 1),
                       "contrast": round(contrast, 1), "issues": issues,
                       "usable_for_observation": len(issues) <= 1},
            "confidence": round(score, 2),
            "limitations": "Measures the picture, not the bird. A sharp, well-exposed image can still hide the "
                           "features that matter (angle, distance, occlusion)."}


def descriptor(path: str | Path) -> np.ndarray:
    """256-D appearance descriptor: HSV colour histogram + coarse gradient-orientation histogram."""
    rgb = _load(path, 128) / 255.0
    mx, mn = rgb.max(-1), rgb.min(-1)
    v, d = mx, mx - mn
    s = np.where(mx > 0, d / np.maximum(mx, 1e-6), 0)
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    hh = np.zeros_like(v)
    m = d > 1e-6
    rm, gm = m & (mx == r), m & (mx == g) & (mx != r)
    bm = m & ~rm & ~gm
    hh[rm] = ((g - b)[rm] / d[rm]) % 6
    hh[gm] = (b - r)[gm] / d[gm] + 2
    hh[bm] = (r - g)[bm] / d[bm] + 4
    hh /= 6.0
    # weight the centre: the subject is usually centred, the background is not
    yy, xx = np.mgrid[0:128, 0:128]
    wgt = np.exp(-(((yy - 64) / 48.0) ** 2 + ((xx - 64) / 48.0) ** 2))
    hist, _ = np.histogramdd(np.stack([hh.ravel(), s.ravel(), v.ravel()], 1), bins=(8, 4, 4),
                             range=((0, 1), (0, 1), (0, 1)), weights=wgt.ravel())
    col = hist.ravel()
    col /= np.linalg.norm(col) + 1e-9
    gray = rgb.mean(-1)
    gy, gx = np.gradient(gray)
    mag, ang = np.hypot(gx, gy), (np.arctan2(gy, gx) % np.pi) / np.pi
    hog = []
    for i in range(4):
        for j in range(4):
            sl = (slice(i * 32, i * 32 + 32), slice(j * 32, j * 32 + 32))
            hcell, _ = np.histogram(ang[sl], bins=8, range=(0, 1), weights=mag[sl])
            hog.append(hcell)
    hog = np.concatenate(hog)
    hog /= np.linalg.norm(hog) + 1e-9
    return np.concatenate([col, hog]).astype(np.float32) / np.sqrt(2)


def identity_candidates(path: str | Path, gallery: list[tuple[int, str, str]], top: int = 5) -> dict:
    """gallery: (falcon_id, falcon_name, photo_path). Returns ranked candidates for human verification."""
    q = descriptor(path)
    best: dict[int, dict] = {}
    for fid, name, p in gallery:
        try:
            sim = float(np.dot(q, descriptor(p)))
        except Exception:
            continue
        if fid not in best or sim > best[fid]["similarity"]:
            best[fid] = {"falcon_id": fid, "name": name, "similarity": round(sim, 3), "reference_photo": os.path.basename(p)}
    ranked = sorted(best.values(), key=lambda c: -c["similarity"])[:top]
    margin = ranked[0]["similarity"] - ranked[1]["similarity"] if len(ranked) > 1 else 0.0
    return {"task": "identity_candidates", "backend": "appearance-descriptor-v0 (colour + gradient)", "validated": False,
            "result": {"candidates": ranked, "gallery_photos": len(gallery), "requires_human_verification": True,
                       "top_margin": round(margin, 3)},
            "confidence": None,
            "limitations": "UNVALIDATED. Similarity reflects overall colour and texture of the picture, including "
                           "background and lighting — not biometric identity. No accuracy has been measured for "
                           "individual falcon identification. Treat the list as suggestions to check against ring / "
                           "microchip records; a human must confirm or reject every match."}


def detect(path: str | Path) -> dict:
    """Run the configured detector backend, if any."""
    weights = os.environ.get("FI_DETECTOR_WEIGHTS")
    if not weights:
        return {"task": "detection", "backend": "none", "validated": False,
                "result": {"status": "no_model_installed", "detections": []}, "confidence": None,
                "limitations": "No falcon detection / species model is installed. A falcon-specific model must be "
                               "trained on the platform's annotated dataset and benchmarked before it is enabled "
                               "(see docs/CV_MODEL_PLAN.md). General-purpose animal models are not assumed to be "
                               "accurate enough for falcons."}
    try:  # pragma: no cover - optional heavy dependency
        from ultralytics import YOLO
        res = YOLO(weights)(str(path), verbose=False)[0]
        dets = [{"label": res.names[int(b.cls)], "confidence": round(float(b.conf), 3),
                 "box": [round(float(x), 4) for x in b.xyxyn[0].tolist()]} for b in res.boxes]
        validated = os.environ.get("FI_DETECTOR_VALIDATED") == "1"
        return {"task": "detection", "backend": f"ultralytics:{os.path.basename(weights)}", "validated": validated,
                "result": {"status": "ok", "detections": dets},
                "confidence": max((d["confidence"] for d in dets), default=None),
                "limitations": ("Model benchmark recorded for this deployment." if validated else
                                "This model has NOT been benchmarked on falcon imagery in this deployment; "
                                "labels and confidences are unverified.")}
    except Exception as e:  # pragma: no cover
        return {"task": "detection", "backend": "error", "validated": False,
                "result": {"status": "backend_error", "error": str(e)[:200], "detections": []}, "confidence": None,
                "limitations": "Detector backend failed to run."}


def video_motion(path: str | Path, max_seconds: float = 180.0) -> dict:
    lim = ("Classical motion analysis: it measures moving pixels, not the bird. Camera shake, panning, wind-blown "
           "vegetation, people and other animals all register as motion. Take-off / landing entries are motion "
           "onsets and offsets that a human must check. " + OBSERVATION_ONLY)
    if cv2 is None:
        return {"task": "video_motion", "backend": "none", "validated": False,
                "result": {"status": "opencv_not_installed"}, "confidence": None, "limitations": lim}
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        return {"task": "video_motion", "backend": "opencv", "validated": False,
                "result": {"status": "unreadable_video"}, "confidence": None, "limitations": lim}
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    if not 1 <= fps <= 240:
        fps = 25.0
    step = max(1, int(round(fps / 30.0)))
    eff = fps / step
    bg = cv2.createBackgroundSubtractorMOG2(history=int(eff * 4), varThreshold=28, detectShadows=False)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    frac, cx, cy, tt = [], [], [], []
    i = 0
    while True:
        ok, frame = cap.read()
        if not ok or i / fps > max_seconds:
            break
        if i % step == 0:
            h, w = frame.shape[:2]
            small = cv2.resize(frame, (320, max(1, int(320 * h / w))))
            mask = cv2.morphologyEx(bg.apply(cv2.GaussianBlur(small, (5, 5), 0)), cv2.MORPH_OPEN, kernel)
            f = float((mask > 0).mean())
            frac.append(f)
            tt.append(i / fps)
            if f > 0.0015:
                ys, xs = np.nonzero(mask)
                cx.append(float(xs.mean() / mask.shape[1]))
                cy.append(float(ys.mean() / mask.shape[0]))
            else:
                cx.append(np.nan)
                cy.append(np.nan)
        i += 1
    cap.release()
    if len(frac) < int(eff):
        return {"task": "video_motion", "backend": "opencv-mog2", "validated": False,
                "result": {"status": "too_short"}, "confidence": None, "limitations": lim}
    warm = int(eff)                      # background model warm-up
    fr, t = np.array(frac[warm:]), np.array(tt[warm:])
    x, y = np.array(cx[warm:]), np.array(cy[warm:])
    k = max(1, int(eff * 0.4))
    sm = np.convolve(fr, np.ones(k) / k, mode="same")
    active = sm > 0.003
    camera_motion = float((fr > 0.35).mean())
    segs, events = [], []
    d = np.diff(np.concatenate(([0], active.astype(int), [0])))
    for s, e in zip(np.where(d == 1)[0], np.where(d == -1)[0] - 1):
        if t[e] - t[s] < 0.5:
            continue
        seg = {"start_s": round(float(t[s]), 2), "end_s": round(float(t[e]), 2)}
        xs_, ys_ = x[s:e + 1], y[s:e + 1]
        okm = np.isfinite(xs_)
        if okm.sum() >= 4:
            dx, dy = float(xs_[okm][-1] - xs_[okm][0]), float(ys_[okm][-1] - ys_[okm][0])
            if max(abs(dx), abs(dy)) < 0.08:
                seg["direction"] = "mostly in place"
            else:
                seg["direction"] = (("right" if dx > 0 else "left") if abs(dx) >= abs(dy) else ("down" if dy > 0 else "up")) + " in frame"
        segs.append(seg)
        if s > eff:
            events.append({"t_s": seg["start_s"], "kind": "motion_onset", "label": "Motion begins after stillness — possible take-off"})
        if e < len(t) - eff:
            events.append({"t_s": seg["end_s"], "kind": "motion_offset", "label": "Motion stops — possible landing"})
    wing = None
    if active.sum() > eff * 2 and eff >= 20:
        sig = fr[active] - sm[active]
        sig = sig - sig.mean()
        spec = np.abs(np.fft.rfft(sig * np.hanning(len(sig)))) ** 2
        freqs = np.fft.rfftfreq(len(sig), 1 / eff)
        band = (freqs >= 2.0) & (freqs <= min(12.0, eff / 2 - 0.5))
        if band.sum() > 3:
            pk = int(np.argmax(spec[band]))
            prominence = float(spec[band][pk] / (np.median(spec[band]) + 1e-12))
            if prominence >= 8:
                wing = {"estimated_hz": round(float(freqs[band][pk]), 1), "spectral_prominence": round(prominence, 1),
                        "provenance": "estimated",
                        "note": "Dominant periodicity of the moving area between 2 and 12 Hz; may be wingbeat."}
    conf = float(np.clip(0.6 - 0.8 * camera_motion, 0.1, 0.6))
    return {"task": "video_motion", "backend": "opencv-mog2", "validated": False,
            "result": {"status": "ok", "analysed_seconds": round(float(tt[-1]), 1), "sample_fps": round(eff, 1),
                       "active_seconds": round(float(active.sum() / eff), 1),
                       "active_share": round(float(active.mean()), 3), "segments": segs[:60], "events": events[:60],
                       "wing_movement": wing, "camera_motion_share": round(camera_motion, 3),
                       "timeline": {"t": [round(float(v), 2) for v in t[::max(1, len(t) // 400)]],
                                    "motion": [round(float(v), 4) for v in sm[::max(1, len(t) // 400)]]}},
            "confidence": round(conf, 2), "limitations": lim}


PHYSICAL_CHECKLIST = [
    {"key": "feathers", "label": "Visible feather condition", "options": ["no visible issue", "broken / bent feathers", "missing feathers", "fret marks / stress bars", "cannot tell"]},
    {"key": "plumage", "label": "Plumage change", "options": ["no change noted", "moult in progress", "soiled plumage", "cannot tell"]},
    {"key": "posture", "label": "Posture", "options": ["upright, alert", "fluffed", "drooped wing(s)", "leaning / unsteady", "cannot tell"]},
    {"key": "body", "label": "Body condition impression", "options": ["as usual", "appears thin", "appears heavy", "cannot tell"]},
    {"key": "injury", "label": "Visible injury or abnormality", "options": ["none visible", "feet / talons", "cere / beak", "eye", "wing", "other", "cannot tell"]},
]
