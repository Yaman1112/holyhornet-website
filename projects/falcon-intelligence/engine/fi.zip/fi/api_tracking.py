"""Tracking, flights & performance, devices, telemetry ingest."""
from __future__ import annotations

import hmac
import secrets
from collections import Counter
from datetime import timedelta

from fastapi import APIRouter, Body, Depends, File, Form, Header, HTTPException, UploadFile
from sqlalchemy import delete
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import config, simulator
from .analytics import baseline
from .analytics import flight as flight_engine
from .api_core import need, parse_dt, pick
from .auth import audit, get_falcon, log_location, require, sha
from .models import (Device, DeviceAssignment, Falcon, Flight, TelemetryPoint, TimelineEvent, TrainingSession, User, Zone,
                     get_db, now)
from .telemetry import adapters, importer, ingest

router = APIRouter(prefix="/api")


# --- live tracking ------------------------------------------------------------------------------
@router.get("/tracking/overview")
def overview(user: User = Depends(require("telemetry.read")), db: Session = Depends(get_db)):
    return overview_data(db, user)


def overview_data(db: Session, user: User) -> dict:
    ingest.sweep(db)
    out = []
    for f in db.scalars(select(Falcon).where(Falcon.org_id == user.org_id, Falcon.status == "active")).all():
        st = ingest.position_status(db, f)
        st.update(falcon_id=f.id, name=f.name, code=f.code, live_sim=simulator.live_running(f.id))
        out.append(st)
    recent = db.scalars(select(Flight).join(Falcon, Falcon.id == Flight.falcon_id).where(
        Falcon.org_id == user.org_id, Flight.open.is_(False), Flight.start >= now() - timedelta(days=7))
        .order_by(Flight.start.desc()).limit(40)).all()
    return {"falcons": out, "zones": [z.as_dict() for z in db.scalars(select(Zone).where(Zone.org_id == user.org_id)).all()],
            "recent_flights": [{"id": fl.id, "falcon_id": fl.falcon_id, "start": fl.start.isoformat() + "Z",
                                "launch": [fl.launch_lat, fl.launch_lon], "recovery": [fl.recovery_lat, fl.recovery_lon]}
                               for fl in recent if fl.launch_lat is not None]}


@router.get("/falcons/{fid}/position")
def position(fid: int, user: User = Depends(require("telemetry.read")), db: Session = Depends(get_db)):
    ingest.sweep(db)
    f = get_falcon(db, user, fid)
    st = ingest.position_status(db, f)
    st["live_sim"] = simulator.live_running(fid)
    log_location(db, fid, "position", user)
    return st


@router.get("/falcons/{fid}/track")
def track(fid: int, hours: float = 24, user: User = Depends(require("telemetry.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    log_location(db, fid, "track", user)
    pts = db.scalars(select(TelemetryPoint).where(TelemetryPoint.falcon_id == fid, TelemetryPoint.lat.is_not(None),
                                                  TelemetryPoint.ts >= now() - timedelta(hours=min(hours, 24 * 14)))
                     .order_by(TelemetryPoint.ts)).all()
    step = max(1, len(pts) // 3000)
    return [{"ts": p.ts.isoformat() + "Z", "lat": p.lat, "lon": p.lon, "q": p.quality, "flight_id": p.flight_id} for p in pts[::step]]


# --- flights & performance ----------------------------------------------------------------------
def _flight_row(fl: Flight) -> dict:
    m = fl.metrics or {}
    return {"id": fl.id, "falcon_id": fl.falcon_id, "start": fl.start.isoformat() + "Z", "end": fl.end.isoformat() + "Z",
            "session_id": fl.session_id, "simulated": fl.simulated, "data_quality": fl.data_quality, "source": m.get("_source"),
            "metrics": {k: v for k, v in m.items() if not k.startswith("_")}, "phases": m.get("_phases"),
            "pattern": baseline.classify_pattern(m, m.get("_phases")),
            "launch": [fl.launch_lat, fl.launch_lon], "recovery": [fl.recovery_lat, fl.recovery_lon]}


def _closed(db: Session, fid: int) -> list[Flight]:
    return db.scalars(select(Flight).where(Flight.falcon_id == fid, Flight.open.is_(False)).order_by(Flight.start)).all()


@router.get("/falcons/{fid}/flights")
def flights(fid: int, user: User = Depends(require("telemetry.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    return [_flight_row(fl) for fl in reversed(_closed(db, fid))]


@router.get("/flights/{flid}")
def flight_detail(flid: int, user: User = Depends(require("telemetry.read")), db: Session = Depends(get_db)):
    fl = db.get(Flight, flid)
    if not fl:
        raise HTTPException(404, "Flight not found")
    get_falcon(db, user, fl.falcon_id)
    pts = db.scalars(select(TelemetryPoint).where(TelemetryPoint.flight_id == flid).order_by(TelemetryPoint.ts)).all()
    res = flight_engine.compute([ingest._pt_dict(p) for p in pts])
    row = _flight_row(fl)
    allf = _closed(db, fl.falcon_id)
    earlier = [x for x in allf if x.start < fl.start]
    hist, scope = baseline.same_pattern([x.metrics for x in earlier], fl.metrics)
    base = baseline.build(hist)
    sig = baseline.pattern_signature(fl.metrics or {}, (fl.metrics or {}).get("_phases"))
    others = [(x.id, baseline.pattern_signature(x.metrics or {}, (x.metrics or {}).get("_phases"))) for x in allf if x.id != fl.id]
    sess = db.get(TrainingSession, fl.session_id) if fl.session_id else None
    flagged = Counter(fl_ for p in pts if p.flags for fl_ in p.flags.split(","))
    row.update(
        series=res["series"], events=res["events"], quality={**res["quality"], "flag_counts": dict(flagged)},
        phase_note=flight_engine.PHASE_NOTE,
        baseline={"available": bool(base), "flights_used": len(hist), "scope": scope, "min_flights": baseline.MIN_FLIGHTS,
                  "comparison": baseline.compare(fl.metrics or {}, base) if base else [],
                  "note": "Compared only with this bird's own earlier flights. No cross-bird or cross-species score is produced."},
        similar=baseline.similar_flights(sig, others) if others else [],
        session=sess.as_dict() if sess else None)
    return row


@router.get("/falcons/{fid}/performance")
def performance(fid: int, user: User = Depends(require("telemetry.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    fl = _closed(db, fid)
    hist = [x.metrics for x in fl]
    base = baseline.build(hist)
    pats = Counter(baseline.classify_pattern(x.metrics or {}, (x.metrics or {}).get("_phases"))["key"] for x in fl)
    series = [{"id": x.id, "start": x.start.isoformat() + "Z",
               **{k: baseline._val(x.metrics, k) for k in baseline.BASELINE_METRICS}} for x in fl]
    # deviations of the latest flights from the individual baseline built on everything before them
    recent_dev = []
    for i in range(max(baseline.MIN_FLIGHTS, len(fl) - 8), len(fl)):
        b = baseline.build(baseline.same_pattern(hist[:i], hist[i])[0])
        dev = [c for c in baseline.compare(fl[i].metrics or {}, b) if c["status"] != "typical"]
        if dev:
            recent_dev.append({"flight_id": fl[i].id, "start": fl[i].start.isoformat() + "Z", "deviations": dev})
    return {"flights": len(fl), "baseline_available": bool(base), "min_flights": baseline.MIN_FLIGHTS,
            "baseline": {k: {**v, "label": baseline.LABELS[k]} for k, v in base.items()},
            "baseline_confidence": baseline.confidence(len(fl)) if base else None,
            "trends": baseline.trends(hist), "series": series, "labels": baseline.LABELS,
            "patterns": [{"key": k, "label": baseline.PATTERN_NAMES[k], "count": n} for k, n in pats.most_common()],
            "recent_deviations": recent_dev,
            "note": "Baselines are individual. This platform does not rank falcons against each other or against a "
                    "universal score: species, age, sex, training stage and conditions make such comparisons unsound."}


@router.get("/flights/compare/{a}/{b}")
def compare(a: int, b: int, user: User = Depends(require("telemetry.read")), db: Session = Depends(get_db)):
    fa, fb = db.get(Flight, a), db.get(Flight, b)
    if not fa or not fb:
        raise HTTPException(404, "Flight not found")
    get_falcon(db, user, fa.falcon_id)
    if fa.falcon_id != fb.falcon_id:
        raise HTTPException(422, "Flights can only be compared for the same falcon")
    out = []
    for k in baseline.BASELINE_METRICS:
        va, vb = baseline._val(fa.metrics, k), baseline._val(fb.metrics, k)
        if va is None or vb is None:
            continue
        out.append({"metric": k, "label": baseline.LABELS[k], "a": va, "b": vb, "unit": fa.metrics[k]["unit"],
                    "change_pct": round(100 * (vb - va) / va, 1) if va else None, "provenance": fa.metrics[k]["provenance"]})
    return {"a": _flight_row(fa), "b": _flight_row(fb), "rows": out}


# --- track file import ----------------------------------------------------------------------------
@router.post("/falcons/{fid}/import-track")
async def import_track(fid: int, file: UploadFile = File(...), source: str = Form(""), utc_offset_hours: float = Form(0.0),
                       user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    """Import a recorded flight from a GPX, KML / KMZ or CSV file exported by any tracker app."""
    f = get_falcon(db, user, fid)
    if not -14 <= utc_offset_hours <= 14:
        raise HTTPException(422, "UTC offset must be between -14 and +14 hours")
    data = await file.read(importer.MAX_BYTES + 1)
    try:
        receipt = importer.import_track(db, f, user, (file.filename or "track")[-120:], data, source.strip()[:120], utc_offset_hours)
    except importer.ImportError_ as e:
        db.rollback()
        raise HTTPException(422, str(e))
    if receipt["accepted"]:
        db.add(TimelineEvent(falcon_id=fid, kind="import", title=f"Track file imported: {receipt['filename']} ({receipt['format']}, "
                                                               f"{receipt['accepted']} points, {len(receipt['flights'])} flight(s))"))
        audit(db, user, "track.import", "falcon", fid, receipt["filename"])
    db.commit()
    return receipt


@router.delete("/flights/{flid}")
def delete_imported_flight(flid: int, user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    """Remove a flight that came from a file import (for example one imported onto the wrong bird)."""
    fl = db.get(Flight, flid)
    if not fl:
        raise HTTPException(404, "Flight not found")
    f = get_falcon(db, user, fl.falcon_id)
    if ((fl.metrics or {}).get("_source") or {}).get("type") != "file_import":
        raise HTTPException(422, "Only flights imported from a file can be deleted. Flights recorded from a tracker are kept as the record.")
    db.execute(delete(TelemetryPoint).where(TelemetryPoint.flight_id == flid))
    db.execute(delete(TimelineEvent).where(TimelineEvent.ref_type == "flight", TimelineEvent.ref_id == flid))
    db.delete(fl)
    db.add(TimelineEvent(falcon_id=f.id, kind="import", title=f"Imported flight of {fl.start:%d %b %Y %H:%M} UTC deleted by {user.name}"))
    audit(db, user, "track.delete", "flight", flid)
    db.flush()
    from .analytics import health
    health.evaluate(db, f)
    db.commit()
    return {"ok": True}


# --- devices ------------------------------------------------------------------------------------
DEVICE_FIELDS = ["serial", "manufacturer", "model", "protocol", "field_map", "mass_g", "dims_mm", "battery_mah", "battery_life_h",
                 "radios", "gnss", "sensors", "antenna", "ip_rating", "range_km", "tx_interval_s", "status", "notes", "capabilities"]


def _device_out(db: Session, d: Device) -> dict:
    out = d.as_dict(exclude=("ingest_key_hash",))
    out["has_ingest_key"] = bool(d.ingest_key_hash)
    last = db.scalars(select(TelemetryPoint).where(TelemetryPoint.device_id == d.id).order_by(TelemetryPoint.ts.desc()).limit(50)).all()
    fields = {"position": "lat", "altitude": "alt_m", "speed": "speed_mps", "heading": "heading_deg", "accuracy (HDOP)": "hdop",
              "satellites": "sats", "battery": "battery_pct", "temperature": "temp_c", "acceleration": "acc_g",
              "gyroscope": "gyro_dps", "signal quality": "rssi"}
    out["observed_capabilities"] = sorted(k for k, a in fields.items() if any(getattr(p, a) is not None for p in last)) if last else None
    a = db.scalar(select(DeviceAssignment).where(DeviceAssignment.device_id == d.id, DeviceAssignment.end.is_(None)))
    if a:
        f = db.get(Falcon, a.falcon_id)
        out["assignment"] = {**a.as_dict(), "falcon_name": f.name if f else None}
    else:
        out["assignment"] = None
    if d.last_seen:
        age = (now() - d.last_seen).total_seconds()
        out["connectivity"] = "online" if age <= max(15, 3 * d.tx_interval_s) else "recent" if age <= 1800 else "offline"
    else:
        out["connectivity"] = "never_reported"
    return out


@router.get("/devices")
def devices(user: User = Depends(require("device.read")), db: Session = Depends(get_db)):
    return [_device_out(db, d) for d in db.scalars(select(Device).where(Device.org_id == user.org_id, Device.protocol != "file_import")
                                                     .order_by(Device.id)).all()]


@router.post("/devices")
def add_device(body: dict = Body(...), user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    need(body, "serial")
    if body.get("protocol", "generic_json") not in adapters.ADAPTERS:
        raise HTTPException(422, f"Unknown protocol. Supported: {', '.join(adapters.ADAPTERS)}")
    if db.scalar(select(Device.id).where(Device.serial == body["serial"])):
        raise HTTPException(409, "A device with this serial already exists")
    key = secrets.token_urlsafe(24)
    d = Device(org_id=user.org_id, ingest_key_hash=sha(key), **pick(body, DEVICE_FIELDS))
    db.add(d)
    db.flush()
    audit(db, user, "device.create", "device", d.id)
    db.commit()
    return {**_device_out(db, d), "ingest_key": key,
            "ingest_key_note": "Shown once. Configure it in the tracker / gateway as the X-Device-Key header."}


@router.post("/devices/{did}/rotate-key")
def rotate(did: int, user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    d = db.get(Device, did)
    if not d or d.org_id != user.org_id:
        raise HTTPException(404, "Device not found")
    key = secrets.token_urlsafe(24)
    d.ingest_key_hash = sha(key)
    audit(db, user, "device.rotate_key", "device", did)
    db.commit()
    return {"ingest_key": key, "ingest_key_note": "Shown once."}


@router.get("/devices/{did}/welfare/{fid}")
def welfare(did: int, fid: int, user: User = Depends(require("device.read")), db: Session = Depends(get_db)):
    d = db.get(Device, did)
    if not d or d.org_id != user.org_id:
        raise HTTPException(404, "Device not found")
    return ingest.welfare_check(db, d, get_falcon(db, user, fid))


@router.post("/devices/{did}/assign")
def assign(did: int, body: dict = Body(...), user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    d = db.get(Device, did)
    if not d or d.org_id != user.org_id:
        raise HTTPException(404, "Device not found")
    need(body, "falcon_id", "attachment_method")
    f = get_falcon(db, user, int(body["falcon_id"]))
    w = ingest.welfare_check(db, d, f)
    if w["status"] in ("blocked", "unknown"):
        raise HTTPException(422, w["message"])
    if not body.get("acknowledge_review"):
        raise HTTPException(422, "You must acknowledge that a qualified professional will review fit, balance and "
                                 "attachment for this bird before the device is flown.")
    for old in db.scalars(select(DeviceAssignment).where(
            ((DeviceAssignment.device_id == did) | (DeviceAssignment.falcon_id == f.id)) & DeviceAssignment.end.is_(None))).all():
        old.end = now()
    a = DeviceAssignment(device_id=did, falcon_id=f.id, attachment_method=body["attachment_method"],
                         bird_weight_g=w["bird_weight_g"], mass_ratio=w["ratio"], review_status="pending", created_by=user.id)
    db.add(a)
    db.add(TimelineEvent(falcon_id=f.id, kind="equipment", title=f"Tracker {d.serial} assigned — awaiting professional review"))
    audit(db, user, "device.assign", "device", did, f"falcon {f.id}")
    db.commit()
    return {"assignment": a.as_dict(), "welfare": w}


@router.post("/assignments/{aid}/review")
def review(aid: int, body: dict = Body(...), user: User = Depends(require("device.review")), db: Session = Depends(get_db)):
    a = db.get(DeviceAssignment, aid)
    if not a:
        raise HTTPException(404, "Assignment not found")
    f = get_falcon(db, user, a.falcon_id)
    if body.get("decision") not in ("approved", "rejected"):
        raise HTTPException(422, "decision must be approved or rejected")
    need(body, "notes")
    a.review_status, a.reviewed_by, a.reviewed_at, a.review_notes = body["decision"], user.id, now(), body["notes"]
    if body["decision"] == "rejected":
        a.end = now()
    db.add(TimelineEvent(falcon_id=f.id, kind="equipment", provenance="vet_assessment" if user.role == "vet" else "user_observation",
                         title=f"Tracker fit review: {body['decision']} by {user.name}", detail=body["notes"]))
    audit(db, user, "device.review", "assignment", aid, body["decision"])
    db.commit()
    return a.as_dict()


@router.post("/assignments/{aid}/end")
def end_assignment(aid: int, user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    a = db.get(DeviceAssignment, aid)
    if not a:
        raise HTTPException(404, "Assignment not found")
    f = get_falcon(db, user, a.falcon_id)
    a.end = now()
    db.add(TimelineEvent(falcon_id=f.id, kind="equipment", title="Tracker removed"))
    db.commit()
    return a.as_dict()


@router.get("/falcons/{fid}/equipment")
def equipment(fid: int, user: User = Depends(require("device.read")), db: Session = Depends(get_db)):
    get_falcon(db, user, fid)
    out = []
    for a in db.scalars(select(DeviceAssignment).where(DeviceAssignment.falcon_id == fid).order_by(DeviceAssignment.start.desc())).all():
        d = db.get(Device, a.device_id)
        out.append({**a.as_dict(), "serial": d.serial, "model": d.model, "mass_g": d.mass_g})
    return out


# --- telemetry ingest (devices / gateways, not users) -------------------------------------------
@router.post("/ingest/{serial}")
def ingest_endpoint(serial: str, payload: dict | list = Body(...), x_device_key: str | None = Header(None),
                    db: Session = Depends(get_db)):
    d = db.scalar(select(Device).where(Device.serial == serial))
    if not d or not d.ingest_key_hash or not x_device_key or not hmac.compare_digest(sha(x_device_key), d.ingest_key_hash):
        raise HTTPException(401, "Unknown device or invalid device key")
    if d.status != "active":
        raise HTTPException(403, "Device is not active")
    try:
        fixes = adapters.ADAPTERS[d.protocol].decode(payload, d)
    except adapters.AdapterError as e:
        raise HTTPException(422, f"{d.protocol}: {e}")
    return ingest.ingest(db, d, fixes)


# --- demo ---------------------------------------------------------------------------------------
@router.post("/demo/live-flight")
def live_flight(body: dict = Body(...), user: User = Depends(require("device.write")), db: Session = Depends(get_db)):
    if not config.DEMO_MODE:
        raise HTTPException(404, "Demo mode is disabled")
    f = get_falcon(db, user, int(body.get("falcon_id", 0)))
    a = db.scalar(select(DeviceAssignment).where(DeviceAssignment.falcon_id == f.id, DeviceAssignment.end.is_(None)))
    if not a:
        raise HTTPException(422, "This falcon has no tracker assigned")
    kind = body.get("kind") if body.get("kind") in ("waiting_on", "lure", "pursuit") else "waiting_on"
    z = db.scalar(select(Zone).where(Zone.org_id == user.org_id, Zone.kind == "training"))
    lat, lon = (z.lat, z.lon) if z else (24.805, 55.385)
    if not simulator.start_live(f.id, a.device_id, kind, lat, lon):
        raise HTTPException(409, "A simulated flight is already running for this falcon")
    return {"ok": True, "note": "Simulated flight started. Frames pass through the LoRa adapter and normal ingest path."}
