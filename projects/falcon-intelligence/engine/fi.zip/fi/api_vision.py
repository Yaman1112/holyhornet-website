"""Computer-vision endpoints, human verification, dataset collection & annotation workflow."""
from __future__ import annotations

from collections import Counter
from pathlib import Path

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import vision
from .analytics import health
from .api_core import need
from .auth import audit, get_falcon, require
from .models import (USER, Attachment, DatasetItem, Falcon, HealthRecord, TimelineEvent, User, VisionAnalysis, get_db, now)

router = APIRouter(prefix="/api")
IMAGE_TASKS = {"image_quality", "identity_candidates", "detection"}


def _att(db: Session, user: User, aid: int) -> Attachment:
    a = db.get(Attachment, aid)
    if not a or a.org_id != user.org_id or not Path(a.path).exists():
        raise HTTPException(404, "Attachment not found")
    return a


@router.post("/vision/analyze")
def analyze(body: dict = Body(...), user: User = Depends(require("vision.use")), db: Session = Depends(get_db)):
    need(body, "attachment_id", "task")
    a = _att(db, user, int(body["attachment_id"]))
    task = body["task"]
    if task in IMAGE_TASKS and a.kind != "photo":
        raise HTTPException(422, "This analysis needs a photo")
    if task == "video_motion" and a.kind != "video":
        raise HTTPException(422, "This analysis needs a video")
    try:
        if task == "image_quality":
            res = vision.image_quality(a.path)
        elif task == "detection":
            res = vision.detect(a.path)
        elif task == "identity_candidates":
            gal = db.execute(select(Attachment, Falcon).join(Falcon, Falcon.id == Attachment.falcon_id).where(
                Attachment.org_id == user.org_id, Attachment.kind == "photo", Attachment.id != a.id,
                Attachment.category.in_(["gallery", "reference"]))).all()
            gallery = [(f.id, f.name, g.path) for g, f in gal if Path(g.path).exists()]
            if not gallery:
                raise HTTPException(422, "No registered profile photos to compare against")
            res = vision.identity_candidates(a.path, gallery)
        elif task == "video_motion":
            res = vision.video_motion(a.path)
        else:
            raise HTTPException(422, "Unknown task")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(422, f"Could not analyse this file: {str(e)[:160]}")
    v = VisionAnalysis(org_id=user.org_id, attachment_id=a.id, falcon_id=a.falcon_id, task=task, backend=res["backend"],
                       validated=res["validated"], result=res["result"], confidence=res["confidence"], limitations=res["limitations"])
    db.add(v)
    db.commit()
    return v.as_dict()


@router.get("/vision/analyses")
def analyses(falcon_id: int | None = None, attachment_id: int | None = None,
             user: User = Depends(require("vision.use")), db: Session = Depends(get_db)):
    q = select(VisionAnalysis).where(VisionAnalysis.org_id == user.org_id)
    if falcon_id:
        q = q.where(VisionAnalysis.falcon_id == falcon_id)
    if attachment_id:
        q = q.where(VisionAnalysis.attachment_id == attachment_id)
    return [v.as_dict() for v in db.scalars(q.order_by(VisionAnalysis.created.desc()).limit(100)).all()]


@router.post("/vision/analyses/{vid}/verdict")
def verdict(vid: int, body: dict = Body(...), user: User = Depends(require("vision.use")), db: Session = Depends(get_db)):
    """Human verification of an AI suggestion (e.g. confirm / reject a possible identity match)."""
    v = db.get(VisionAnalysis, vid)
    if not v or v.org_id != user.org_id:
        raise HTTPException(404, "Analysis not found")
    if body.get("verdict") not in ("confirmed", "rejected", "unsure"):
        raise HTTPException(422, "verdict must be confirmed, rejected or unsure")
    v.human_verdict, v.verified_by, v.verdict_note = body["verdict"], user.id, body.get("note")
    if v.task == "identity_candidates":
        v.result = {**v.result, "confirmed_falcon_id": body.get("falcon_id") if body["verdict"] == "confirmed" else None}
    audit(db, user, "vision.verdict", "vision_analysis", vid, body["verdict"])
    db.commit()
    return v.as_dict()


@router.post("/falcons/{fid}/physical-observation")
def physical_observation(fid: int, body: dict = Body(...), user: User = Depends(require("health.write")), db: Session = Depends(get_db)):
    """Structured *human* observation from a photo. Stored as a user / vet observation, never as an AI finding."""
    f = get_falcon(db, user, fid)
    answers = body.get("answers") or {}
    valid = {c["key"]: c for c in vision.PHYSICAL_CHECKLIST}
    clean = {k: v for k, v in answers.items() if k in valid and v in valid[k]["options"]}
    if not clean:
        raise HTTPException(422, "No valid observation answers")
    prov = "vet_assessment" if user.role == "vet" else USER
    summary = "; ".join(f"{valid[k]['label']}: {v}" for k, v in clean.items())
    r = HealthRecord(falcon_id=fid, ts=now(), kind="observation", title="Physical observation from photograph", detail=summary +
                     (f"\nNote: {body['note']}" if body.get("note") else ""),
                     data={"answers": clean, "attachment_id": body.get("attachment_id")}, provenance=prov,
                     recorded_by=user.id, recorder_name=user.name)
    db.add(r)
    db.add(TimelineEvent(falcon_id=fid, kind="health", title=r.title, provenance=prov))
    db.flush()
    health.evaluate(db, f)
    db.commit()
    return r.as_dict()


# --- dataset workflow ---------------------------------------------------------------------------
def _item(db: Session, i: DatasetItem) -> dict:
    a = db.get(Attachment, i.attachment_id)
    return {**i.as_dict(), "filename": a.filename if a else None, "falcon_id": a.falcon_id if a else None, "kind": a.kind if a else None}


@router.get("/dataset")
def dataset(user: User = Depends(require("vision.use")), db: Session = Depends(get_db)):
    items = db.scalars(select(DatasetItem).where(DatasetItem.org_id == user.org_id).order_by(DatasetItem.id.desc())).all()
    st = Counter(i.status for i in items)
    sp = Counter((i.labels or {}).get("species") or "unlabelled" for i in items)
    per_bird = Counter((i.labels or {}).get("falcon_id") for i in items if (i.labels or {}).get("falcon_id"))
    return {"items": [_item(db, i) for i in items],
            "stats": {"total": len(items), "by_status": dict(st), "by_species": dict(sp), "with_consent": sum(i.consent for i in items),
                      "birds_with_10_plus_images": sum(n >= 10 for n in per_bird.values()), "splits": dict(Counter(i.split or "unassigned" for i in items))},
            "readiness": {"detection_min_images": 1500, "species_min_per_class": 300, "identity_min_per_bird": 30,
                          "note": "Planning thresholds from docs/CV_MODEL_PLAN.md. A model is only enabled after it is "
                                  "benchmarked on a held-out test split that shares no individual birds with training."}}


@router.post("/dataset")
def dataset_add(body: dict = Body(...), user: User = Depends(require("dataset.write")), db: Session = Depends(get_db)):
    need(body, "attachment_id")
    a = _att(db, user, int(body["attachment_id"]))
    if a.kind != "photo":
        raise HTTPException(422, "Only photos can be added to the image dataset")
    if db.scalar(select(DatasetItem.id).where(DatasetItem.attachment_id == a.id)):
        raise HTTPException(409, "Already in the dataset")
    if not body.get("consent"):
        raise HTTPException(422, "Owner consent is required before an image is used for model training")
    i = DatasetItem(org_id=user.org_id, attachment_id=a.id, consent=True, labels={"falcon_id": a.falcon_id} if a.falcon_id else {})
    db.add(i)
    db.commit()
    return _item(db, i)


@router.patch("/dataset/{iid}")
def dataset_patch(iid: int, body: dict = Body(...), user: User = Depends(require("dataset.write")), db: Session = Depends(get_db)):
    i = db.get(DatasetItem, iid)
    if not i or i.org_id != user.org_id:
        raise HTTPException(404, "Item not found")
    if "labels" in body:
        i.labels = {**(i.labels or {}), **(body["labels"] or {})}
    if "boxes" in body:
        boxes = body["boxes"] or []
        for b in boxes:
            if not all(0 <= float(b.get(k, -1)) <= 1 for k in ("x", "y", "w", "h")):
                raise HTTPException(422, "Boxes must use normalised 0..1 coordinates")
        i.boxes = boxes
    if body.get("status") in ("unlabelled", "labelled", "reviewed", "rejected"):
        if body["status"] == "reviewed":
            if i.annotator == user.id:
                raise HTTPException(422, "An annotation must be reviewed by a different person than the annotator")
            i.reviewer = user.id
        i.status = body["status"]
    if ("labels" in body or "boxes" in body) and i.status == "unlabelled":
        i.status = "labelled"
    if "labels" in body or "boxes" in body:
        i.annotator = user.id
    if body.get("split") in ("train", "val", "test"):
        i.split = body["split"]
    i.updated = now()
    db.commit()
    return _item(db, i)


@router.get("/dataset/export")
def dataset_export(user: User = Depends(require("dataset.write")), db: Session = Depends(get_db)):
    """COCO-style export of reviewed, consented items."""
    items = db.scalars(select(DatasetItem).where(DatasetItem.org_id == user.org_id, DatasetItem.status == "reviewed",
                                                 DatasetItem.consent.is_(True))).all()
    cats: dict[str, int] = {}
    images, anns = [], []
    for i in items:
        a = db.get(Attachment, i.attachment_id)
        images.append({"id": i.id, "file_name": a.filename, "split": i.split, "labels": i.labels})
        for b in i.boxes or []:
            cid = cats.setdefault(b.get("label") or "falcon", len(cats) + 1)
            anns.append({"id": len(anns) + 1, "image_id": i.id, "category_id": cid, "bbox_norm": [b["x"], b["y"], b["w"], b["h"]]})
    return {"info": {"description": "Falcon Intelligence dataset export", "exported": now().isoformat() + "Z"},
            "images": images, "annotations": anns, "categories": [{"id": v, "name": k} for k, v in cats.items()]}
