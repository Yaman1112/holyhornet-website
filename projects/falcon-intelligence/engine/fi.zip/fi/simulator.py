"""Synthetic telemetry generator — for demos and tests only.

Everything produced here is stored with simulated=True and labelled as simulated in the UI.
The live simulator pushes frames through the real LoRa adapter and ingest path, so it also
exercises the same code a physical tracker would.
"""
from __future__ import annotations

import math
import threading
import time
from datetime import datetime, timedelta

import numpy as np

from .telemetry.adapters import Fix

M_PER_DEG = 111_320.0


def sim_flight(rng: np.random.Generator, kind: str, start: datetime, lat0: float, lon0: float, ground: float = 120.0,
               vigor: float = 1.0, dt: float = 2.0, batt: float = 90.0, turn_sign: int = 1, ambient: float = 27.0,
               leg_scale: float = 1.0, pitch_scale: float = 1.0, erratic: bool = False) -> list[Fix]:
    """Generate one flight. kind: waiting_on | lure | pursuit.

    Each Fix carries the noise-free ground-truth position in ``extra["truth"]`` so that truth can be
    stored separately from what the simulated device reported."""
    x = y = 0.0
    h = 0.0
    v = 0.0
    hdg = float(rng.uniform(0, 360))
    plan: list[tuple[float, float, float, float]] = []   # (duration s, target speed, turn rate deg/s, climb m/s)

    if kind == "waiting_on":
        pitch = float(rng.uniform(170, 330)) * (0.45 + 0.55 * vigor) * pitch_scale
        climb = float(rng.uniform(2.2, 3.4)) * (0.6 + 0.4 * vigor)
        r = float(rng.uniform(60, 110))
        sp = float(rng.uniform(14, 18))
        om = math.degrees(sp / r) * turn_sign
        plan += [(6, sp, 0, 1.5), (pitch / climb, sp, om, climb),
                 (float(rng.uniform(35, 90)) * vigor, sp * 0.9, om * 0.8, 0.0)]
        stoop_v = float(rng.uniform(28, 40)) * (0.7 + 0.3 * vigor)
        plan += [(max(2.0, (pitch - 12) / stoop_v), float(rng.uniform(42, 62)) * (0.7 + 0.3 * vigor), 0, -stoop_v),
                 (6, 18, om * 1.5, 0.5), (14, 9, om, -0.6), (8, 0, 0, -0.5)]
    elif kind == "lure":
        passes = max(2, int(rng.integers(6, 14) * vigor))
        sp = float(rng.uniform(15, 23)) * (0.75 + 0.25 * vigor)
        plan.append((5, sp, 0, 2.5))
        for i in range(passes):
            sgn = 1 if i % 2 == 0 else -1
            plan += [(float(rng.uniform(7, 11)), sp, 0, float(rng.uniform(-0.6, 0.6))),
                     (float(rng.uniform(7, 10)), sp * 0.8, sgn * float(rng.uniform(22, 30)), float(rng.uniform(-0.3, 1.0)))]
        plan += [(8, 8, turn_sign * 12, -1.2), (6, 0, 0, -0.8)]
    else:  # pursuit
        sp = float(rng.uniform(20, 28)) * (0.75 + 0.25 * vigor)
        leg = float(rng.uniform(600, 1500)) * (0.5 + 0.5 * vigor) * leg_scale
        plan += [(6, sp, 0, 3.0), (leg / sp, sp, float(rng.uniform(-1.5, 1.5)), 0.6),
                 (9, sp * 0.8, turn_sign * 20, 0.4), (leg / sp * 0.9, sp, float(rng.uniform(-1.0, 1.0)), -0.5),
                 (10, 10, turn_sign * 14, -1.5), (8, 0, 0, -1.0)]
        if rng.random() < 0.5 * vigor:   # second chase
            plan = plan[:-2] + plan[1:]

    fixes: list[Fix] = []
    t = 0.0
    prev_v, prev_vs = 0.0, 0.0
    for dur, tv, om, vs in plan:
        steps = max(1, int(round(dur / dt)))
        for _ in range(steps):
            v += (tv - v) * min(1.0, dt / 3.0)
            hdg = (hdg + om * dt + rng.normal(0, 1.5)) % 360
            if erratic and rng.random() < 0.12:          # abrupt, irregular direction changes
                hdg = (hdg + rng.uniform(-150, 150)) % 360
                v *= float(rng.uniform(0.3, 1.0))
            if kind == "waiting_on" and vs < -10:           # stoop: head back toward the falconer
                hdg = (math.degrees(math.atan2(-x, -y)) + rng.normal(0, 4)) % 360
            h = max(0.0, h + vs * dt)
            if h <= 0.0 and tv == 0:
                v *= 0.4
            x += v * math.sin(math.radians(hdg)) * dt
            y += v * math.cos(math.radians(hdg)) * dt
            centripetal = v * math.radians(abs(om)) / 9.81
            pull = abs(vs - prev_vs) / dt / 9.81
            acc = math.sqrt(1 + centripetal ** 2) + pull + abs(v - prev_v) / dt / 9.81 + abs(rng.normal(0, 0.12 * (0.4 + vigor)))
            prev_v, prev_vs = v, vs
            bad = rng.random() < 0.012
            noise = 28.0 if bad else 1.4
            fixes.append(Fix(
                ts=start + timedelta(seconds=t),
                lat=lat0 + (y + rng.normal(0, noise)) / M_PER_DEG,
                lon=lon0 + (x + rng.normal(0, noise)) / (M_PER_DEG * math.cos(math.radians(lat0))),
                alt_m=round(ground + h + rng.normal(0, 0.6), 1), alt_source="baro",
                speed_mps=round(max(0.0, v + rng.normal(0, 0.3)), 2), heading_deg=round(hdg, 1),
                hdop=round(float(rng.uniform(4.5, 7.0) if bad else rng.uniform(0.7, 1.3)), 1),
                sats=int(rng.integers(4, 6) if bad else rng.integers(11, 17)), fix="3d",
                battery_pct=round(max(1.0, batt - t * 0.004), 1), temp_c=round(ambient + rng.normal(0, 0.3), 1),
                acc_g=round(acc, 2), gyro_dps=round(abs(om) + abs(rng.normal(0, 6)), 1),
                rssi=round(-70 - math.hypot(x, y) / 40 + rng.normal(0, 2), 0), link="lora",
                extra={"truth": [lat0 + y / M_PER_DEG, lon0 + x / (M_PER_DEG * math.cos(math.radians(lat0))), ground + h]}))
            t += dt
    return fixes


# Live simulator ------------------------------------------------------------------------------
_live: dict[int, object] = {}          # falcon id -> Thread (server) or asyncio.Task (browser edition)


def _alive(h) -> bool:
    return h is not None and (h.is_alive() if hasattr(h, "is_alive") else not h.done())


def _prepare(kind, lat0, lon0, seed, opts, run_id):
    """Build the list of fixes to stream and store the ground truth."""
    from .models import SessionLocal, SimRun, now
    rng = np.random.default_rng(seed)
    fixes = sim_flight(rng, kind, now() + timedelta(seconds=5), lat0, lon0, dt=1.0, turn_sign=int(rng.choice([-1, 1])), **opts)
    if run_id:
        with SessionLocal() as db:
            run = db.get(SimRun, run_id)
            if run:
                run.truth = [[f.ts.isoformat() + "Z", *[round(v, 6) for v in f.extra["truth"]]] for f in fixes]
                db.commit()
    batt0 = opts.get("batt", 90.0)
    # a short stationary lead-in so the launch is visible
    lead = [Fix(ts=fixes[0].ts - timedelta(seconds=5 - i), lat=lat0, lon=lon0, alt_m=120.0, alt_source="baro",
                speed_mps=0.0, heading_deg=0.0, hdop=0.9, sats=14, fix="3d", battery_pct=batt0, acc_g=1.0) for i in range(5)]
    return lead, fixes


def _emit(device_id: int, fx: Fix) -> bool:
    """Send one fix through the real LoRa adapter and ingest path."""
    from .models import Device, SessionLocal
    from .telemetry.adapters import ADAPTERS, LoRaCompact
    from .telemetry.ingest import ingest
    with SessionLocal() as db:
        dev = db.get(Device, device_id)
        if dev is None:
            return False
        ingest(db, dev, ADAPTERS["lora_compact"].decode({"frame": LoRaCompact.encode(fx), "rssi": fx.rssi}), simulated=True)
    return True


def start_live(falcon_id: int, device_id: int, kind: str, lat0: float, lon0: float, seed: int | None = None,
               opts: dict | None = None, run_id: int | None = None, after=None) -> bool:
    """Stream one simulated flight in real time through the LoRa adapter + ingest pipeline.

    opts: vigor, batt, leg_scale, pitch_scale, erratic, stop_after_s (simulated loss of signal).
    after: callable run when the stream ends (used by scenarios that continue with a workflow)."""
    from . import config
    opts = dict(opts or {})
    stop_after = opts.pop("stop_after_s", None)
    if _alive(_live.get(falcon_id)):
        return False

    def steps():
        lead, fixes = _prepare(kind, lat0, lon0, seed, opts, run_id)
        base = lead[0].ts
        for fx in lead + fixes:
            if stop_after is not None and (fx.ts - fixes[0].ts).total_seconds() > stop_after:
                return                                  # simulated loss of signal: the device simply stops reporting
            yield (fx.ts - base).total_seconds(), fx

    if config.BROWSER:
        import asyncio

        async def run_async():
            t0 = time.time()
            for due, fx in steps():
                delay = due - (time.time() - t0)
                await asyncio.sleep(max(delay, 0))      # always yield, so page requests are served between fixes
                if not _emit(device_id, fx):
                    return
            if after:
                after()
        _live[falcon_id] = asyncio.ensure_future(run_async())
        return True

    def run():
        t0 = time.time()
        for due, fx in steps():
            delay = due - (time.time() - t0)
            if delay > 0:
                time.sleep(delay)
            if not _emit(device_id, fx):
                return
        if after:
            after()

    th = threading.Thread(target=run, daemon=True, name=f"live-sim-{falcon_id}")
    _live[falcon_id] = th
    th.start()
    return True


def live_running(falcon_id: int) -> bool:
    return _alive(_live.get(falcon_id))
