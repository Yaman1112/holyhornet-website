"""Demo dataset. Every record created here is synthetic and the telemetry is flagged simulated.

Run:  python -m fi.seed [--reset]
"""
from __future__ import annotations

import secrets
import sys
from datetime import datetime, timedelta

import numpy as np
from PIL import Image, ImageDraw
from sqlalchemy import select

from . import config
from .analytics import health
from .auth import hash_pw, new_salt
from .models import (USER, VET, Attachment, Base, BreedingPair, Device, DeviceAssignment, Egg, Falcon, FalconAccess, FeedingPlan,
                     FeedingRecord, Flight, HealthRecord, Org, OwnershipTransfer, SessionLocal, SpeciesProfile,
                     TargetRange, TelemetryPoint, TimelineEvent, TrainingSession, User, WeightRecord, Zone, engine,
                     init_db, now)
from .simulator import sim_flight
from .telemetry import ingest

GROUND = (24.8050, 55.3850)      # demo training ground (open desert south of Dubai)
MEWS = (24.8420, 55.4010)
DAYS = 30


def _photo(path, name: str, tone: tuple[int, int, int], rng) -> None:
    """Abstract placeholder picture (not a real bird photo)."""
    w, h = 800, 600
    yy, xx = np.mgrid[0:h, 0:w]
    base = np.zeros((h, w, 3), np.float32)
    sky = np.array([205, 190, 160], np.float32)
    for c in range(3):
        base[..., c] = sky[c] - 40 * yy / h + rng.normal(0, 6, (h, w))
    body = (((xx - 400) / 150.0) ** 2 + ((yy - 320) / 210.0) ** 2) < 1
    head = (((xx - 400) / 80.0) ** 2 + ((yy - 120) / 75.0) ** 2) < 1
    for c in range(3):
        tex = tone[c] + 30 * np.sin(yy / (6 + 3 * c) + xx / 40.0) + rng.normal(0, 10, (h, w))
        base[..., c] = np.where(body | head, tex, base[..., c])
    im = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8))
    d = ImageDraw.Draw(im)
    d.rectangle([0, h - 44, w, h], fill=(20, 20, 20))
    d.text((14, h - 32), f"PLACEHOLDER IMAGE - {name} - synthetic demo asset, not a photograph", fill=(240, 220, 160))
    im.save(path, quality=88)


def seed(reset: bool = False) -> None:
    if reset:
        Base.metadata.drop_all(engine)
    init_db()
    db = SessionLocal()
    if db.scalar(select(Org.id)):
        print("Database already seeded (use --reset to rebuild).")
        return
    rng = np.random.default_rng(20261113)
    t_now = now()
    today = t_now.replace(hour=0, minute=0, second=0, microsecond=0)

    org = Org(name="Desert Wind Falconry (Demo)", country="AE")
    db.add(org)
    db.flush()

    def user(email, name, role, title, org_id=None):
        salt = new_salt()
        u = User(org_id=org_id or org.id, email=email, name=name, role=role, title=title, salt=salt,
                 pw_hash=hash_pw(secrets.token_urlsafe(18), salt))   # random; demo sign-in is one-click
        db.add(u)
        db.flush()
        return u

    admin = user("admin@demo.falcon-intelligence.test", "Platform Admin", "admin", "Facility administrator")
    owner = user("owner@demo.falcon-intelligence.test", "Khalid A. (demo owner)", "owner", "Falcon owner")
    falconer = user("falconer@demo.falcon-intelligence.test", "Salem R. (demo falconer)", "falconer", "Head falconer")
    vet = user("vet@demo.falcon-intelligence.test", "Dr. Mariam H. (demo vet)", "vet", "Avian veterinarian")
    breeder = user("breeder@demo.falcon-intelligence.test", "Omar S. (demo breeder)", "breeder", "Breeding manager")
    user("viewer@demo.falcon-intelligence.test", "Guest Viewer", "viewer", "Read-only guest")
    user("trainer@demo.falcon-intelligence.test", "Hamad K. (demo trainer)", "trainer", "Trainer")
    user("manager@demo.falcon-intelligence.test", "Noura A. (demo facility manager)", "facility_manager", "Facility manager")
    recovery_user = user("recovery@demo.falcon-intelligence.test", "Recovery Team (demo)", "recovery", "Authorised recovery contact")
    # a second organisation: a falcon hospital whose vet is given access to one bird by the owner
    hospital = Org(name="Demo Falcon Hospital", country="AE", kind="falcon hospital")
    db.add(hospital)
    db.flush()
    hospital_vet = user("clinic@demo-hospital.falcon-intelligence.test", "Dr. Yousef M. (demo hospital vet)", "hospital",
                        "Hospital veterinarian", org_id=hospital.id)
    org.settings = {"plan": "professional", "weather": {
        "provider": "open-meteo", "thresholds": {"max_temp_c": 34, "max_wind_kph": 30, "max_gust_kph": 45, "min_visibility_km": 3},
        "thresholds_set_by": "Demo seed", "thresholds_note": "Example values only — set your own with professional guidance."}}

    note = "Approximate reference range only — verify against authoritative sources; not a target weight."
    sp = {}
    for cn, sn, cat, lo, hi in [
        ("Peregrine Falcon", "Falco peregrinus", "falcon", 550, 1500), ("Saker Falcon", "Falco cherrug", "falcon", 730, 1300),
        ("Gyrfalcon", "Falco rusticolus", "falcon", 800, 2100), ("Lanner Falcon", "Falco biarmicus", "falcon", 500, 900),
        ("Gyr × Peregrine", "F. rusticolus × F. peregrinus", "hybrid", 700, 1700),
        ("Gyr × Saker", "F. rusticolus × F. cherrug", "hybrid", 800, 1800)]:
        s = SpeciesProfile(org_id=org.id, common_name=cn, scientific_name=sn, category=cat, ref_mass_min_g=lo,
                           ref_mass_max_g=hi, notes=note)
        db.add(s)
        db.flush()
        sp[cn] = s

    zt = Zone(org_id=org.id, name="Training ground A", kind="training", lat=GROUND[0], lon=GROUND[1], radius_m=2500)
    zm = Zone(org_id=org.id, name="Mews (home)", kind="home", lat=MEWS[0], lon=MEWS[1], radius_m=300)
    zx = Zone(org_id=org.id, name="6 km notification boundary", kind="notify_exit", lat=GROUND[0], lon=GROUND[1], radius_m=6000,
              notes="Sends a notice when a reported position crosses outward.")
    db.add_all([zt, zm, zx])

    def falcon(i, name, species, sex, hatch, weight, category, **kw):
        f = Falcon(org_id=org.id, code=f"FI-AE-{2026000 + i}", name=name, species_id=sp[species].id, sex=sex,
                   hatch_date=hatch, owner_name=owner.name, owner_user_id=owner.id, current_location="Mews (home)",
                   ring_number=f"DEMO-RING-{1000 + i}", microchip=f"DEMO-CHIP-{784000100 + i}",
                   passport_no=f"DEMO-PASS-{5500 + i}", category=category, qr_token=secrets.token_urlsafe(16), **kw)
        db.add(f)
        db.flush()
        db.add(TimelineEvent(falcon_id=f.id, ts=datetime.fromisoformat(hatch), kind="hatch", title="Hatched", provenance=USER))
        db.add(TimelineEvent(falcon_id=f.id, ts=today - timedelta(days=DAYS + 20), kind="registration",
                             title="Registered on Falcon Intelligence", provenance=USER))
        f._w = weight
        return f

    shaheen = falcon(1, "Shaheen", "Peregrine Falcon", "female", "2023-04-18", 985, "hunting", wingspan_cm=104,
                     origin="Captive bred — UAE", breeder="Demo Breeding Centre", subspecies="F. p. peregrinus")
    barq = falcon(2, "Barq", "Gyr × Peregrine", "male", "2024-05-02", 1040, "racing", wingspan_cm=108,
                  origin="Captive bred — UAE", breeder="Demo Breeding Centre", strain="7/8 Gyr")
    najm = falcon(3, "Najm", "Saker Falcon", "female", "2022-04-27", 1125, "hunting", wingspan_cm=118,
                  origin="Captive bred — imported", breeder="Demo European Breeder", age_is_estimate=False)
    ghazal = falcon(4, "Ghazal", "Gyrfalcon", "female", "2023-05-11", 1660, "hunting", wingspan_cm=128,
                    origin="Captive bred — UAE", breeder="Demo Breeding Centre")
    reem = falcon(5, "Reem", "Peregrine Falcon", "female", "2019-04-09", 1010, "breeding", origin="Captive bred — UAE")
    saif = falcon(6, "Saif", "Peregrine Falcon", "male", "2018-04-21", 680, "breeding", origin="Captive bred — UAE")
    shaheen.sire_id, shaheen.dam_id = saif.id, reem.id
    db.add(OwnershipTransfer(falcon_id=najm.id, date="2023-09-14", from_owner="Demo European Breeder", to_owner=owner.name,
                             document_ref="DEMO-CITES-0042", notes="Import and transfer (demo record).", recorded_by=admin.id))
    db.add(TimelineEvent(falcon_id=najm.id, ts=datetime(2023, 9, 14), kind="ownership", title=f"Ownership transferred to {owner.name}"))

    # --- devices -------------------------------------------------------------------------------
    def device(serial, model, mass, **kw):
        d = Device(org_id=org.id, serial=serial, manufacturer="HolyHornet (reference design)", model=model, mass_g=mass,
                   protocol="lora_compact", gnss="GPS + Galileo, 1 Hz", sensors=["accelerometer", "gyroscope", "barometer", "temperature"],
                   radios=["LoRa 868 MHz", "LTE-M fallback"], antenna="Flexible whip, tail-aligned", ip_rating="IP67",
                   dims_mm="38 × 16 × 11", battery_mah=150, battery_life_h=18, range_km=12, tx_interval_s=2,
                   capabilities=["position", "altitude", "speed", "heading", "accuracy (HDOP)", "battery", "acceleration"], **kw)
        db.add(d)
        db.flush()
        return d

    devs = [device("HH-S1-0001", "Tag S1", 9.5), device("HH-S1-0002", "Tag S1", 9.5), device("HH-S1-0003", "Tag S1", 9.5),
            device("HH-S1-0004", "Tag S1", 9.5),
            device("HH-L2-0009", "Tag L2 (long endurance)", 41.0, notes="Demo unit used to show mass screening.")]
    flyers = [(shaheen, devs[0], 1.0, 1), (barq, devs[1], 1.0, -1), (najm, devs[2], 1.0, 1), (ghazal, devs[3], 1.0, -1)]
    for f, d, _, _ in flyers:
        pending = f is barq
        db.add(DeviceAssignment(device_id=d.id, falcon_id=f.id, start=today - timedelta(days=DAYS + 2),
                                attachment_method="Tail mount (deck feather clip)", bird_weight_g=f._w,
                                mass_ratio=round(d.mass_g / f._w, 4), review_status="pending" if pending else "approved",
                                reviewed_by=None if pending else vet.id, reviewed_at=None if pending else today - timedelta(days=DAYS + 2),
                                review_notes=None if pending else "Fit, balance and feather condition checked in hand (demo record).",
                                created_by=falconer.id))
        db.add(TimelineEvent(falcon_id=f.id, ts=today - timedelta(days=DAYS + 2), kind="equipment",
                             title=f"Tracker {d.serial} assigned"))
        db.add(TargetRange(falcon_id=f.id, min_g=round(f._w * 0.965), max_g=round(f._w * 1.035), set_by=vet.id,
                           set_at=today - timedelta(days=DAYS + 5), context="Flying season", note="Demo range."))

    # --- 30 days of history --------------------------------------------------------------------
    kinds = {shaheen.id: ["waiting_on", "waiting_on", "lure"], barq.id: ["pursuit", "lure", "pursuit"],
             najm.id: ["waiting_on", "lure", "pursuit"], ghazal.id: ["waiting_on", "pursuit", "lure"]}
    foods = ["quail", "pigeon", "day-old chick", "quail"]
    n_flights = 0
    for f, d, _, sign in flyers:
        prev = None
        for day in range(DAYS, 0, -1):
            date = today - timedelta(days=day)
            decline = f is najm and day <= 5
            stale = f is ghazal and day <= 3          # tracker stops reporting 3 days ago
            vigor = 1.0 + rng.normal(0, 0.07)
            if decline:
                vigor = 0.5 - 0.04 * (5 - day) + rng.normal(0, 0.03)
            w = f._w * (1 + rng.normal(0, 0.006))
            if decline:
                w = f._w * (1 - 0.016 * (6 - day)) + rng.normal(0, 3)
            wt = date + timedelta(hours=1, minutes=int(rng.integers(0, 25)))
            db.add(WeightRecord(falcon_id=f.id, ts=wt, weight_g=round(w), context="pre-flight", recorded_by=falconer.id))
            fed = date + timedelta(hours=4, minutes=int(rng.integers(0, 40)))
            db.add(FeedingRecord(falcon_id=f.id, ts=fed, food_type=foods[day % 4], recorded_by=falconer.id,
                                 quantity_g=round(float(rng.uniform(70, 110)) * (0.6 if decline else 1.0)),
                                 observations="Left part of the meal." if decline and day <= 3 else None))
            if rng.random() < 0.12 and not decline:
                continue                              # rest day
            kind = kinds[f.id][int(rng.integers(0, 3))]
            start = date + timedelta(hours=1, minutes=45 + int(rng.integers(0, 60)))   # ~05:45–06:45 local (UTC+4)
            outcome = "completed"
            if decline:
                outcome = ["shortened", "completed", "shortened", "declined", "shortened"][5 - day]
            ts = TrainingSession(
                falcon_id=f.id, trainer_id=falconer.id, trainer_name=falconer.name, start=start, location="Training ground A",
                zone_id=zt.id, type={"waiting_on": "waiting-on / stoop to lure", "lure": "lure flying", "pursuit": "drone-lure pursuit"}[kind],
                conditions={"temp_c": round(float(rng.uniform(21, 30)), 1), "wind_kph": round(float(rng.uniform(3, 22)), 0),
                            "wind_dir": str(rng.choice(["N", "NE", "E", "SE", "S", "SW", "W", "NW"])),
                            "humidity_pct": int(rng.integers(35, 75)), "sky": str(rng.choice(["clear", "clear", "haze", "scattered cloud"]))},
                observations=("Low drive, came down early." if decline else "Good response to the lure."),
                recovery_observation=("Breathing settled slowly." if decline else "Recovered quickly."),
                outcome=outcome, simulated=True, notes="Synthetic demo session.")
            db.add(ts)
            db.flush()
            if stale or outcome == "declined":
                ts.duration_min = 0 if outcome == "declined" else round(float(rng.uniform(6, 12)), 1)
                continue
            lat0 = GROUND[0] + rng.normal(0, 0.002)
            lon0 = GROUND[1] + rng.normal(0, 0.002)
            fixes = sim_flight(rng, kind, start + timedelta(minutes=3), lat0, lon0, vigor=max(0.3, vigor),
                               batt=float(rng.uniform(70, 98)), turn_sign=sign if rng.random() < 0.8 else -sign,
                               ambient=ts.conditions["temp_c"])
            fl = Flight(falcon_id=f.id, device_id=d.id, session_id=ts.id, start=fixes[0].ts, end=fixes[-1].ts, simulated=True, open=True)
            db.add(fl)
            db.flush()
            pts = []
            for fx in fixes:
                q, flags = ingest.score(fx, prev)
                p = ingest._to_point(fx, d, f.id, q, flags, True)
                p.flight_id = fl.id
                pts.append(p)
                prev = fx
            airborne = [p.ts for p in pts if (p.speed_mps or 0) >= ingest.AIRBORNE_SPEED]
            fl.start, fl.end = airborne[0], airborne[-1]
            db.add_all(pts)
            db.flush()
            ingest.finalize_flight(db, fl, evaluate=False)
            ts.duration_min = round((fl.end - fl.start).total_seconds() / 60 + 4, 1)
            d.last_seen, d.battery_pct, d.last_link, d.last_rssi = fixes[-1].ts, fixes[-1].battery_pct, "lora", fixes[-1].rssi
            n_flights += 1
        db.commit()
    # non-flying birds: weekly weights
    for f in (reem, saif):
        for day in range(DAYS, 0, -3):
            db.add(WeightRecord(falcon_id=f.id, ts=today - timedelta(days=day, hours=-2), weight_g=round(f._w * (1 + rng.normal(0, 0.008))),
                                context="morning", recorded_by=breeder.id))

    # --- veterinary & health records -----------------------------------------------------------
    def hr(f, days_ago, kind, title, detail=None, prov=VET, by=vet, **kw):
        r = HealthRecord(falcon_id=f.id, ts=today - timedelta(days=days_ago, hours=-6), kind=kind, title=title, detail=detail,
                         provenance=prov, recorded_by=by.id, recorder_name=by.name, **kw)
        db.add(r)
        db.add(TimelineEvent(falcon_id=f.id, ts=r.ts, kind="health", title=title, provenance=prov))
        return r

    for f in (shaheen, barq, najm, ghazal):
        hr(f, 34, "exam", "Pre-season veterinary examination", "Physical examination and endoscopy recorded by the clinic (demo record).",
           data={"clinic": "Demo Falcon Clinic"})
        hr(f, 34, "lab", "Laboratory report — haematology and faecal screen", "Report attached by clinic (demo record).",
           data={"result_summary": "Entered by veterinary professional"})
    hr(shaheen, 33, "vaccination", "Vaccination recorded", "Product and batch entered by the clinic (demo record).")
    hr(najm, 20, "medication", "Medication course recorded", "Course prescribed and recorded by the veterinarian (demo record).",
       data={"course_days": 5})
    hr(najm, 20, "followup", "Re-check after medication course", due_date=(today - timedelta(days=2)).date().isoformat())
    hr(shaheen, 34, "followup", "Routine mid-season check", due_date=(today + timedelta(days=12)).date().isoformat())
    hr(barq, 2, "injury", "Small abrasion on left middle toe", "Noticed after landing on rough ground.", prov=USER, by=falconer, severity="minor")
    hr(ghazal, 9, "recommendation", "Keep flights short above 32 °C", "Veterinary recommendation recorded after examination (demo record).")
    hr(najm, 1, "observation", "Quieter than usual on the fist", "Less responsive this morning.", prov=USER, by=falconer)

    db.add(FeedingPlan(falcon_id=shaheen.id, title="Flying-season plan", created_by=falconer.id, author_role="falconer",
                       vet_approved_by=vet.id, start_date=(today - timedelta(days=DAYS)).date().isoformat(),
                       schedule=[{"time": "08:00", "food_type": "quail", "quantity_g": 90, "note": "after flight"}],
                       notes="Written by the head falconer; reviewed by the veterinarian (demo record)."))

    # --- breeding ------------------------------------------------------------------------------
    db.add(FalconAccess(falcon_id=najm.id, user_id=hospital_vet.id, granted_by=owner.id,
                        purpose="Follow-up after medication course (demo grant)", expires=today + timedelta(days=30)))
    pair = BreedingPair(org_id=org.id, sire_id=saif.id, dam_id=reem.id, season="2026", facility="Breeding chamber 2",
                        method="natural", notes="Demo pair.", created_by=breeder.id)
    db.add(pair)
    db.flush()
    chick = Falcon(org_id=org.id, code="FI-AE-2026007", name="Chick 26-01", species_id=sp["Peregrine Falcon"].id, sex="unknown",
                   hatch_date="2026-04-06", owner_name=owner.name, owner_user_id=owner.id, current_location="Breeding chamber 2",
                   category="juvenile", qr_token=secrets.token_urlsafe(16), sire_id=saif.id, dam_id=reem.id,
                   breeder="Desert Wind Falconry (Demo)", origin="Captive bred — UAE")
    db.add(chick)
    db.flush()
    db.add(TimelineEvent(falcon_id=chick.id, ts=datetime(2026, 4, 6), kind="hatch", title="Hatched (egg 26-A)"))
    for i, (g, d_) in enumerate([(38, 0), (120, 7), (330, 14), (560, 21), (700, 28), (760, 35)]):
        db.add(WeightRecord(falcon_id=chick.id, ts=datetime(2026, 4, 6) + timedelta(days=d_), weight_g=g, context="development",
                            recorded_by=breeder.id))
    db.add(HealthRecord(falcon_id=chick.id, ts=datetime(2026, 4, 20), kind="development", title="Pin feathers emerging",
                        provenance=USER, recorded_by=breeder.id, recorder_name=breeder.name))
    db.add_all([
        Egg(pair_id=pair.id, label="26-A", laid_date="2026-03-04", status="hatched", hatch_date="2026-04-06", chick_falcon_id=chick.id,
            incubation_log=[{"date": "2026-03-11", "note": "Candled — development visible", "mass_g": 46.1, "by": breeder.name},
                            {"date": "2026-03-25", "note": "Mass loss on track", "mass_g": 42.9, "by": breeder.name}]),
        Egg(pair_id=pair.id, label="26-B", laid_date="2026-03-06", status="infertile",
            incubation_log=[{"date": "2026-03-13", "note": "Candled — clear", "mass_g": 45.0, "by": breeder.name}]),
        Egg(pair_id=pair.id, label="26-C", laid_date="2026-03-08", status="failed",
            incubation_log=[{"date": "2026-03-15", "note": "Candled — development visible", "mass_g": 47.2, "by": breeder.name},
                            {"date": "2026-03-29", "note": "No movement at candling", "mass_g": 44.8, "by": breeder.name}])])

    # --- placeholder gallery -------------------------------------------------------------------
    tones = {shaheen.id: (70, 80, 100), barq.id: (215, 210, 205), najm.id: (150, 105, 60), ghazal.id: (235, 235, 240),
             reem.id: (60, 70, 95), saif.id: (85, 95, 120)}
    for f in (shaheen, barq, najm, ghazal, reem, saif):
        for k in range(2):
            fn = f"demo_{f.code}_{k + 1}.jpg"
            p = config.UPLOAD_DIR / fn
            _photo(p, f.name, tuple(int(c + rng.normal(0, 6)) for c in tones[f.id]), rng)
            db.add(Attachment(org_id=org.id, falcon_id=f.id, kind="photo", category="gallery", filename=fn, path=str(p),
                              mime="image/jpeg", size=p.stat().st_size, uploaded_by=falconer.id,
                              note="Synthetic placeholder image (demo)."))
    db.commit()

    for f in db.scalars(select(Falcon)).all():
        health.evaluate(db, f)
        health.followups_due(db, f)
    db.commit()
    n_pts = db.query(TelemetryPoint).count()
    print(f"Seeded: {db.query(Falcon).count()} falcons, {n_flights} flights, {n_pts} telemetry points.")
    db.close()


if __name__ == "__main__":
    seed(reset="--reset" in sys.argv)
