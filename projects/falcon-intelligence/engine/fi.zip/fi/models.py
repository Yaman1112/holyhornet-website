"""Database schema (SQLAlchemy 2.x).

Every record that carries information about a bird also carries a *provenance* so the UI and
reports can always distinguish measured data, derived values, estimates, AI interpretations,
user observations and veterinary assessments.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (JSON, Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text,
                        create_engine, event)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from . import config

# Provenance vocabulary -------------------------------------------------------------------
MEASURED = "measured"            # reported directly by a sensor / device
DERIVED = "derived"              # computed mathematically from measured values
ESTIMATED = "estimated"          # heuristic estimate with stated assumptions
AI = "ai_interpretation"         # model / algorithm interpretation — never a diagnosis
USER = "user_observation"        # entered by an owner / falconer / breeder
VET = "vet_assessment"           # entered or confirmed by a veterinary professional
PROVENANCES = [MEASURED, DERIVED, ESTIMATED, AI, USER, VET]

ROLES = ["admin", "owner", "falconer", "trainer", "vet", "breeder", "hospital", "facility_manager", "recovery", "viewer"]


def now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    def as_dict(self, exclude: tuple[str, ...] = ()) -> dict:
        out = {}
        for c in self.__table__.columns:
            if c.name in exclude:
                continue
            v = getattr(self, c.name)
            out[c.name] = v.isoformat() + "Z" if isinstance(v, datetime) else v
        return out


def pk() -> Mapped[int]:
    return mapped_column(Integer, primary_key=True, autoincrement=True)


class Org(Base):
    __tablename__ = "orgs"
    id: Mapped[int] = pk()
    name: Mapped[str] = mapped_column(String(200))
    country: Mapped[str] = mapped_column(String(2), default="AE")
    kind: Mapped[str] = mapped_column(String(40), default="falconry facility")
    settings: Mapped[dict | None] = mapped_column(JSON, nullable=True)   # weather provider, thresholds, plan


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    email: Mapped[str] = mapped_column(String(200), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    role: Mapped[str] = mapped_column(String(20))
    title: Mapped[str | None] = mapped_column(String(200), nullable=True)
    pw_hash: Mapped[str] = mapped_column(String(200))
    salt: Mapped[str] = mapped_column(String(64))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class AuthSession(Base):
    __tablename__ = "sessions"
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    expires: Mapped[datetime] = mapped_column(DateTime)


class SpeciesProfile(Base):
    """Configurable species profile. Mass ranges are reference notes only, not targets."""
    __tablename__ = "species"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    common_name: Mapped[str] = mapped_column(String(120))
    scientific_name: Mapped[str | None] = mapped_column(String(160), nullable=True)
    category: Mapped[str] = mapped_column(String(60), default="falcon")  # falcon / hybrid / hawk / eagle / other
    ref_mass_min_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    ref_mass_max_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class Falcon(Base):
    __tablename__ = "falcons"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"), index=True)
    code: Mapped[str] = mapped_column(String(40), unique=True)       # Unique Falcon ID
    name: Mapped[str] = mapped_column(String(120))
    species_id: Mapped[int | None] = mapped_column(ForeignKey("species.id"), nullable=True)
    subspecies: Mapped[str | None] = mapped_column(String(120), nullable=True)
    strain: Mapped[str | None] = mapped_column(String(120), nullable=True)
    sex: Mapped[str] = mapped_column(String(10), default="unknown")
    hatch_date: Mapped[str | None] = mapped_column(String(10), nullable=True)
    age_is_estimate: Mapped[bool] = mapped_column(Boolean, default=False)
    origin: Mapped[str | None] = mapped_column(String(200), nullable=True)
    breeder: Mapped[str | None] = mapped_column(String(200), nullable=True)
    owner_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    owner_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    current_location: Mapped[str | None] = mapped_column(String(200), nullable=True)
    ring_number: Mapped[str | None] = mapped_column(String(80), nullable=True)
    microchip: Mapped[str | None] = mapped_column(String(80), nullable=True)
    passport_no: Mapped[str | None] = mapped_column(String(80), nullable=True)
    wingspan_cm: Mapped[float | None] = mapped_column(Float, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="active")
    category: Mapped[str] = mapped_column(String(40), default="hunting")  # hunting / racing / breeding / display / juvenile
    qr_token: Mapped[str] = mapped_column(String(64), unique=True)
    sire_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), nullable=True)
    dam_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=now)


class OwnershipTransfer(Base):
    __tablename__ = "ownership_transfers"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    date: Mapped[str] = mapped_column(String(10))
    from_owner: Mapped[str | None] = mapped_column(String(200), nullable=True)
    to_owner: Mapped[str] = mapped_column(String(200))
    document_ref: Mapped[str | None] = mapped_column(String(200), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    recorded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)


class Attachment(Base):
    __tablename__ = "attachments"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    falcon_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), index=True, nullable=True)
    kind: Mapped[str] = mapped_column(String(20))            # photo / video / document
    category: Mapped[str | None] = mapped_column(String(60), nullable=True)  # passport / lab_report / gallery ...
    filename: Mapped[str] = mapped_column(String(300))
    path: Mapped[str] = mapped_column(String(500))
    mime: Mapped[str | None] = mapped_column(String(100), nullable=True)
    size: Mapped[int] = mapped_column(Integer, default=0)
    linked_type: Mapped[str | None] = mapped_column(String(40), nullable=True)   # training_session / health_record
    linked_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    restricted: Mapped[bool] = mapped_column(Boolean, default=False)  # identity / ownership documents
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    uploaded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=now)


class TimelineEvent(Base):
    __tablename__ = "timeline"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=now, index=True)
    kind: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(300))
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    provenance: Mapped[str] = mapped_column(String(30), default=USER)
    ref_type: Mapped[str | None] = mapped_column(String(40), nullable=True)
    ref_id: Mapped[int | None] = mapped_column(Integer, nullable=True)


class Device(Base):
    __tablename__ = "devices"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    serial: Mapped[str] = mapped_column(String(80), unique=True)
    manufacturer: Mapped[str | None] = mapped_column(String(120), nullable=True)
    model: Mapped[str | None] = mapped_column(String(120), nullable=True)
    protocol: Mapped[str] = mapped_column(String(40), default="generic_json")   # adapter key
    field_map: Mapped[dict | None] = mapped_column(JSON, nullable=True)         # for vendor_webhook adapter
    mass_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    dims_mm: Mapped[str | None] = mapped_column(String(60), nullable=True)
    battery_mah: Mapped[float | None] = mapped_column(Float, nullable=True)
    battery_life_h: Mapped[float | None] = mapped_column(Float, nullable=True)
    radios: Mapped[list | None] = mapped_column(JSON, nullable=True)            # ["LTE-M", "LoRa 868"]
    gnss: Mapped[str | None] = mapped_column(String(80), nullable=True)
    sensors: Mapped[list | None] = mapped_column(JSON, nullable=True)
    antenna: Mapped[str | None] = mapped_column(String(120), nullable=True)
    ip_rating: Mapped[str | None] = mapped_column(String(20), nullable=True)
    range_km: Mapped[float | None] = mapped_column(Float, nullable=True)
    tx_interval_s: Mapped[float] = mapped_column(Float, default=5.0)
    capabilities: Mapped[list | None] = mapped_column(JSON, nullable=True)      # declared fields this model reports
    ingest_key_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active")
    last_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    battery_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    last_link: Mapped[str | None] = mapped_column(String(30), nullable=True)
    last_rssi: Mapped[float | None] = mapped_column(Float, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class DeviceAssignment(Base):
    """A device fitted to a specific bird. Suitability is reviewed per bird, never per model."""
    __tablename__ = "device_assignments"
    id: Mapped[int] = pk()
    device_id: Mapped[int] = mapped_column(ForeignKey("devices.id"), index=True)
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    start: Mapped[datetime] = mapped_column(DateTime, default=now)
    end: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    attachment_method: Mapped[str | None] = mapped_column(String(80), nullable=True)
    bird_weight_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    mass_ratio: Mapped[float | None] = mapped_column(Float, nullable=True)
    review_status: Mapped[str] = mapped_column(String(20), default="pending")  # pending / approved / rejected
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    review_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)


class TelemetryPoint(Base):
    __tablename__ = "telemetry"
    id: Mapped[int] = pk()
    device_id: Mapped[int] = mapped_column(ForeignKey("devices.id"))
    falcon_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), nullable=True)
    flight_id: Mapped[int | None] = mapped_column(ForeignKey("flights.id"), nullable=True, index=True)
    ts: Mapped[datetime] = mapped_column(DateTime)
    lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    alt_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    alt_source: Mapped[str | None] = mapped_column(String(10), nullable=True)  # gnss / baro
    speed_mps: Mapped[float | None] = mapped_column(Float, nullable=True)
    speed_source: Mapped[str | None] = mapped_column(String(10), nullable=True)  # gnss / derived
    heading_deg: Mapped[float | None] = mapped_column(Float, nullable=True)
    hdop: Mapped[float | None] = mapped_column(Float, nullable=True)
    sats: Mapped[int | None] = mapped_column(Integer, nullable=True)
    fix: Mapped[str | None] = mapped_column(String(10), nullable=True)          # none / 2d / 3d
    battery_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    temp_c: Mapped[float | None] = mapped_column(Float, nullable=True)
    acc_g: Mapped[float | None] = mapped_column(Float, nullable=True)           # |a| in g
    gyro_dps: Mapped[float | None] = mapped_column(Float, nullable=True)        # |w| in deg/s
    rssi: Mapped[float | None] = mapped_column(Float, nullable=True)
    link: Mapped[str | None] = mapped_column(String(20), nullable=True)
    quality: Mapped[float] = mapped_column(Float, default=1.0)                  # 0..1
    flags: Mapped[str | None] = mapped_column(String(120), nullable=True)
    simulated: Mapped[bool] = mapped_column(Boolean, default=False)

    __table_args__ = (Index("ix_tel_falcon_ts", "falcon_id", "ts"), Index("ix_tel_device_ts", "device_id", "ts"))


class Flight(Base):
    __tablename__ = "flights"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    device_id: Mapped[int | None] = mapped_column(ForeignKey("devices.id"), nullable=True)
    session_id: Mapped[int | None] = mapped_column(ForeignKey("training_sessions.id"), nullable=True)
    start: Mapped[datetime] = mapped_column(DateTime, index=True)
    end: Mapped[datetime] = mapped_column(DateTime)
    launch_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    launch_lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    recovery_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    recovery_lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    metrics: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    events: Mapped[list | None] = mapped_column(JSON, nullable=True)
    data_quality: Mapped[float | None] = mapped_column(Float, nullable=True)
    simulated: Mapped[bool] = mapped_column(Boolean, default=False)
    open: Mapped[bool] = mapped_column(Boolean, default=False)


class Zone(Base):
    __tablename__ = "zones"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    name: Mapped[str] = mapped_column(String(120))
    kind: Mapped[str] = mapped_column(String(30), default="training")  # training / home / notify_exit / notify_enter
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    radius_m: Mapped[float] = mapped_column(Float, default=1000)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class TrainingSession(Base):
    __tablename__ = "training_sessions"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    trainer_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    trainer_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    start: Mapped[datetime] = mapped_column(DateTime, index=True)
    duration_min: Mapped[float | None] = mapped_column(Float, nullable=True)
    location: Mapped[str | None] = mapped_column(String(200), nullable=True)
    zone_id: Mapped[int | None] = mapped_column(ForeignKey("zones.id"), nullable=True)
    type: Mapped[str] = mapped_column(String(60))
    conditions: Mapped[dict | None] = mapped_column(JSON, nullable=True)   # temp_c, wind_kph, wind_dir, humidity, sky
    observations: Mapped[str | None] = mapped_column(Text, nullable=True)
    recovery_observation: Mapped[str | None] = mapped_column(Text, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    outcome: Mapped[str | None] = mapped_column(String(40), nullable=True)  # completed / shortened / declined / cancelled
    simulated: Mapped[bool] = mapped_column(Boolean, default=False)


class WeightRecord(Base):
    __tablename__ = "weights"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    weight_g: Mapped[float] = mapped_column(Float)
    context: Mapped[str | None] = mapped_column(String(60), nullable=True)   # pre-flight / post-feed / morning
    provenance: Mapped[str] = mapped_column(String(30), default=USER)
    recorded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)


class TargetRange(Base):
    """Weight range set by a veterinary professional. AI never creates or edits these."""
    __tablename__ = "target_ranges"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    min_g: Mapped[float] = mapped_column(Float)
    max_g: Mapped[float] = mapped_column(Float)
    context: Mapped[str | None] = mapped_column(String(120), nullable=True)
    set_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    set_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)


class FeedingRecord(Base):
    __tablename__ = "feedings"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    food_type: Mapped[str] = mapped_column(String(80))
    quantity_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    observations: Mapped[str | None] = mapped_column(Text, nullable=True)
    recorded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)


class FeedingPlan(Base):
    """Human-authored feeding plan. Never generated or altered by analytics."""
    __tablename__ = "feeding_plans"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    schedule: Mapped[list | None] = mapped_column(JSON, nullable=True)   # [{time, food_type, quantity_g, note}]
    start_date: Mapped[str | None] = mapped_column(String(10), nullable=True)
    end_date: Mapped[str | None] = mapped_column(String(10), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    author_role: Mapped[str] = mapped_column(String(20))
    vet_approved_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=now)


class HealthRecord(Base):
    __tablename__ = "health_records"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)
    # exam / medication / vaccination / lab / treatment / injury / recovery / recommendation / followup / observation / development
    kind: Mapped[str] = mapped_column(String(30))
    title: Mapped[str] = mapped_column(String(300))
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    data: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    severity: Mapped[str | None] = mapped_column(String(20), nullable=True)   # for injuries: minor / moderate / severe
    due_date: Mapped[str | None] = mapped_column(String(10), nullable=True)   # follow-ups
    done: Mapped[bool] = mapped_column(Boolean, default=False)
    provenance: Mapped[str] = mapped_column(String(30), default=USER)
    recorded_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    recorder_name: Mapped[str | None] = mapped_column(String(200), nullable=True)


class Alert(Base):
    __tablename__ = "alerts"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    key: Mapped[str] = mapped_column(String(80))            # dedupe key, e.g. "weight_trend"
    level: Mapped[int] = mapped_column(Integer)             # 1..5
    category: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(300))
    observations: Mapped[list] = mapped_column(JSON)        # [{text, provenance}]
    period_start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    period_end: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    confidence: Mapped[float] = mapped_column(Float)
    limitations: Mapped[str] = mapped_column(Text)
    follow_up: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="open")  # open / acknowledged / reviewed / dismissed / resolved
    created: Mapped[datetime] = mapped_column(DateTime, default=now)
    updated: Mapped[datetime] = mapped_column(DateTime, default=now)
    annotations: Mapped[list | None] = mapped_column(JSON, nullable=True)  # [{user, role, ts, note, provenance}]


class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"), index=True)
    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)   # None = whole organisation
    falcon_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), nullable=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=now)
    kind: Mapped[str] = mapped_column(String(40))
    severity: Mapped[str] = mapped_column(String(20), default="info")   # info / notice / warning / urgent
    title: Mapped[str] = mapped_column(String(300))
    body: Mapped[str | None] = mapped_column(Text, nullable=True)
    key: Mapped[str | None] = mapped_column(String(120), nullable=True)
    read: Mapped[bool] = mapped_column(Boolean, default=False)


class BreedingPair(Base):
    __tablename__ = "breeding_pairs"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    sire_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), nullable=True)
    dam_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), nullable=True)
    season: Mapped[str] = mapped_column(String(20))
    facility: Mapped[str | None] = mapped_column(String(200), nullable=True)
    method: Mapped[str | None] = mapped_column(String(60), nullable=True)   # natural / artificial insemination
    created_by: Mapped[int | None] = mapped_column(Integer, nullable=True)
    verified_by: Mapped[int | None] = mapped_column(Integer, nullable=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    verification_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)


class Egg(Base):
    __tablename__ = "eggs"
    id: Mapped[int] = pk()
    pair_id: Mapped[int] = mapped_column(ForeignKey("breeding_pairs.id"), index=True)
    label: Mapped[str] = mapped_column(String(40))
    laid_date: Mapped[str | None] = mapped_column(String(10), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="incubating")  # incubating / fertile / infertile / hatched / failed
    incubation_log: Mapped[list | None] = mapped_column(JSON, nullable=True)  # [{date, note, mass_g, by}]
    hatch_date: Mapped[str | None] = mapped_column(String(10), nullable=True)
    chick_falcon_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), nullable=True)


class VisionAnalysis(Base):
    __tablename__ = "vision_analyses"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    attachment_id: Mapped[int] = mapped_column(ForeignKey("attachments.id"), index=True)
    falcon_id: Mapped[int | None] = mapped_column(ForeignKey("falcons.id"), nullable=True)
    task: Mapped[str] = mapped_column(String(40))   # image_quality / identity_candidates / detection / video_motion / physical_observation
    backend: Mapped[str] = mapped_column(String(80))
    validated: Mapped[bool] = mapped_column(Boolean, default=False)
    result: Mapped[dict] = mapped_column(JSON)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    limitations: Mapped[str] = mapped_column(Text)
    human_verdict: Mapped[str | None] = mapped_column(String(30), nullable=True)   # confirmed / rejected / unsure
    verified_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    verdict_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created: Mapped[datetime] = mapped_column(DateTime, default=now)


class DatasetItem(Base):
    """Dataset collection + annotation workflow for falcon-specific model training."""
    __tablename__ = "dataset_items"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    attachment_id: Mapped[int] = mapped_column(ForeignKey("attachments.id"), unique=True)
    consent: Mapped[bool] = mapped_column(Boolean, default=False)      # owner consent to use for training
    labels: Mapped[dict | None] = mapped_column(JSON, nullable=True)   # species, falcon_id, pose, condition tags
    boxes: Mapped[list | None] = mapped_column(JSON, nullable=True)    # [{x,y,w,h,label}] normalised 0..1
    split: Mapped[str | None] = mapped_column(String(10), nullable=True)   # train / val / test
    status: Mapped[str] = mapped_column(String(20), default="unlabelled")  # unlabelled / labelled / reviewed / rejected
    annotator: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    reviewer: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    updated: Mapped[datetime] = mapped_column(DateTime, default=now)


class AuditLog(Base):
    __tablename__ = "audit"
    id: Mapped[int] = pk()
    ts: Mapped[datetime] = mapped_column(DateTime, default=now)
    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    action: Mapped[str] = mapped_column(String(80))
    entity: Mapped[str | None] = mapped_column(String(60), nullable=True)
    entity_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)


class FalconAccess(Base):
    """Owner-controlled grant letting a professional (possibly in another organisation) work on one falcon."""
    __tablename__ = "falcon_access"
    id: Mapped[int] = pk()
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    purpose: Mapped[str | None] = mapped_column(String(200), nullable=True)
    granted_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    granted_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    expires: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class RecoveryCase(Base):
    __tablename__ = "recovery_cases"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"), index=True)
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    status: Mapped[str] = mapped_column(String(20), default="open")      # open / closed
    opened_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    opened_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    circumstances: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_confirmed_ts: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)   # last time a person saw the bird
    last_confirmed_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_confirmed_lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    last_confirmed_lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    snapshot: Mapped[dict | None] = mapped_column(JSON, nullable=True)   # tracker status when the case was opened
    contacts: Mapped[list | None] = mapped_column(JSON, nullable=True)   # user ids of authorised recovery contacts
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    closed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    outcome: Mapped[str | None] = mapped_column(String(40), nullable=True)   # recovered / not recovered / false alarm
    close_note: Mapped[str | None] = mapped_column(Text, nullable=True)


class Sighting(Base):
    __tablename__ = "sightings"
    id: Mapped[int] = pk()
    case_id: Mapped[int] = mapped_column(ForeignKey("recovery_cases.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=now)
    lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    lon: Mapped[float | None] = mapped_column(Float, nullable=True)
    description: Mapped[str] = mapped_column(Text)
    certainty: Mapped[str] = mapped_column(String(20), default="possible")   # confirmed / possible
    reporter_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    reported_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    via_link_id: Mapped[int | None] = mapped_column(Integer, nullable=True)


class RecoveryAction(Base):
    __tablename__ = "recovery_actions"
    id: Mapped[int] = pk()
    case_id: Mapped[int] = mapped_column(ForeignKey("recovery_cases.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=now)
    user_name: Mapped[str] = mapped_column(String(200))
    text: Mapped[str] = mapped_column(Text)


class ShareLink(Base):
    """Expiring, revocable link giving a recovery helper limited access to one case's location data."""
    __tablename__ = "share_links"
    id: Mapped[int] = pk()
    case_id: Mapped[int] = mapped_column(ForeignKey("recovery_cases.id"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    label: Mapped[str] = mapped_column(String(200))          # who it was given to
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    expires: Mapped[datetime] = mapped_column(DateTime)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    access_count: Mapped[int] = mapped_column(Integer, default=0)
    last_access: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class LocationAccessLog(Base):
    __tablename__ = "location_access"
    id: Mapped[int] = pk()
    ts: Mapped[datetime] = mapped_column(DateTime, default=now, index=True)
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"), index=True)
    actor: Mapped[str] = mapped_column(String(120))        # "user:<id>" or "link:<id>"
    actor_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    what: Mapped[str] = mapped_column(String(60))          # position / track / recovery_case / shared_link
    case_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)


class WeatherObservation(Base):
    __tablename__ = "weather"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    lat: Mapped[float] = mapped_column(Float)              # rounded before it is sent to a provider
    lon: Mapped[float] = mapped_column(Float)
    fetched: Mapped[datetime] = mapped_column(DateTime, default=now, index=True)
    provider: Mapped[str] = mapped_column(String(40))
    current: Mapped[dict] = mapped_column(JSON)
    hourly: Mapped[list | None] = mapped_column(JSON, nullable=True)


class SimRun(Base):
    """Simulator run. Ground truth is stored here, separate from the telemetry the simulated device reported."""
    __tablename__ = "sim_runs"
    id: Mapped[int] = pk()
    org_id: Mapped[int] = mapped_column(ForeignKey("orgs.id"))
    falcon_id: Mapped[int] = mapped_column(ForeignKey("falcons.id"))
    scenario: Mapped[str] = mapped_column(String(40))
    started: Mapped[datetime] = mapped_column(DateTime, default=now)
    params: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    truth: Mapped[list | None] = mapped_column(JSON, nullable=True)     # [[iso ts, lat, lon, alt]]


# Engine ------------------------------------------------------------------------------------
engine = create_engine(config.DB_URL, connect_args={"check_same_thread": False, "timeout": 30}
                       if config.DB_URL.startswith("sqlite") else {})


@event.listens_for(engine, "connect")
def _sqlite_pragmas(dbapi_conn, _):
    if config.DB_URL.startswith("sqlite"):
        cur = dbapi_conn.cursor()
        if not config.BROWSER:                      # WAL needs shared memory, which the in-browser file system lacks
            cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()


SessionLocal = sessionmaker(engine, expire_on_commit=False)


def init_db() -> None:
    Base.metadata.create_all(engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
