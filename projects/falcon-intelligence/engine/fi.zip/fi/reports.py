"""Printable HTML reports (use the browser's Print → Save as PDF)."""
from __future__ import annotations

from datetime import timedelta
from html import escape as e

from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from .analytics import baseline, health
from .auth import can, get_falcon, require
from .models import (Alert, Flight, HealthRecord, SpeciesProfile, TargetRange, TrainingSession, User, WeightRecord, get_db, now)

router = APIRouter(prefix="/api")

PROV_LABEL = {"measured": "Measured", "derived": "Derived", "estimated": "Estimated", "ai_interpretation": "AI interpretation",
              "user_observation": "User observation", "vet_assessment": "Veterinary assessment"}
CSS = """
body{font:14px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;color:#1c1b19;max-width:860px;margin:32px auto;padding:0 20px}
h1{font-size:24px;margin:0}h2{font-size:16px;margin:28px 0 8px;border-bottom:2px solid #b8893b;padding-bottom:4px}
.sub{color:#666;margin:4px 0 0}table{border-collapse:collapse;width:100%;margin:6px 0}
th,td{text-align:left;padding:5px 8px;border-bottom:1px solid #e3ded4;vertical-align:top}th{font-size:12px;color:#666;font-weight:600}
.p{display:inline-block;font-size:11px;padding:1px 7px;border-radius:9px;border:1px solid #999;color:#444;white-space:nowrap}
.note{background:#f6f2e9;border-left:3px solid #b8893b;padding:8px 12px;margin:10px 0;font-size:13px}
.lvl{font-weight:600}.foot{margin-top:36px;color:#777;font-size:12px}.sim{background:#fff3cd;padding:6px 10px;border:1px solid #e0c060}
@media print{body{margin:0}.noprint{display:none}}
"""


def _p(prov: str) -> str:
    return f'<span class="p">{e(PROV_LABEL.get(prov, prov))}</span>'


def _table(head: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return "<p><em>No records in this period.</em></p>"
    return ("<table><tr>" + "".join(f"<th>{e(h)}</th>" for h in head) + "</tr>" +
            "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows) + "</table>")


@router.get("/reports/falcon/{fid}", response_class=HTMLResponse)
def falcon_report(fid: int, kind: str = "full", days: int = 30, user: User = Depends(require("report")), db: Session = Depends(get_db)):
    f = get_falcon(db, user, fid)
    t = now()
    since = t - timedelta(days=max(1, min(days, 365)))
    sp = db.get(SpeciesProfile, f.species_id) if f.species_id else None
    out = [f"<style>{CSS}</style>",
           f"<h1>{e(f.name)} — {'Performance' if kind == 'performance' else 'Health observation' if kind == 'health' else 'Falcon'} report</h1>",
           f'<p class="sub">Falcon ID {e(f.code)} · {e(sp.common_name if sp else "Species not recorded")} · {e(f.sex)} · '
           f'period {since:%d %b %Y} – {t:%d %b %Y} · generated {t:%d %b %Y %H:%M} UTC by {e(user.name)}</p>',
           '<p class="noprint"><button onclick="print()">Print / save as PDF</button></p>',
           '<div class="note"><b>How to read this report.</b> Every figure is labelled by source: '
           + " ".join(_p(k) for k in PROV_LABEL) +
           ". AI interpretations are observations for human follow-up — never a diagnosis.</div>"]

    flights = db.scalars(select(Flight).where(Flight.falcon_id == fid, Flight.open.is_(False)).order_by(Flight.start)).all()
    period_fl = [x for x in flights if x.start >= since]
    if any(x.simulated for x in period_fl):
        out.append('<p class="sim">This report contains simulated demo telemetry.</p>')

    if kind in ("full", "performance"):
        out.append("<h2>Flight performance</h2>")
        if period_fl:
            last = period_fl[-1]
            rows = [[e(baseline.LABELS.get(k, k.replace("_", " "))), f"{v['value']:g} {e(v['unit'])}", _p(v["provenance"]), e(v["note"])]
                    for k, v in (last.metrics or {}).items() if not k.startswith("_")]
            out.append(f"<p>Tracked flights in period: <b>{len(period_fl)}</b>. Most recent flight: {last.start:%d %b %Y %H:%M} UTC "
                       f"(data quality {100 * (last.data_quality or 0):.0f}%).</p>")
            out.append(_table(["Metric (latest flight)", "Value", "Source", "How it was obtained"], rows))
            like, scope = baseline.same_pattern([x.metrics for x in flights[:-1]], last.metrics)
            base = baseline.build(like)
            if base:
                cmp_ = baseline.compare(last.metrics or {}, base)
                out.append("<h2>Latest flight against this bird's own baseline</h2>")
                out.append(_table(["Metric", "Latest", "Own median", "Typical range", "Status", "Source"],
                                  [[e(c["label"]), f"{c['value']:g} {e(c['unit'])}", f"{c['baseline_median']:g}",
                                    f"{c['typical_low']:g} – {c['typical_high']:g}", e(c["status"]), _p(c["provenance"])] for c in cmp_]))
                out.append(f'<div class="note">Baseline built from {len(like)} flights of this bird only — {e(scope)} '
                           f'(confidence {baseline.confidence(len(like)):.0%}). No comparison with other birds or species is made.</div>')
            else:
                out.append(f'<div class="note">Fewer than {baseline.MIN_FLIGHTS} earlier flights — no individual baseline yet.</div>')
            tr = baseline.trends([x.metrics for x in flights])
            out.append("<h2>Trend over the most recent flights</h2>")
            out.append(_table(["Flight pattern", "Metric", "Flights", "Estimated change", "Direction", "Source"],
                              [[e(x["pattern"]), e(x["label"]), str(x["flights"]), f"{x['change_pct']:+.1f}%", e(x["direction"]), _p(x["provenance"])] for x in tr]))
        else:
            out.append("<p><em>No tracked flights in this period.</em></p>")
        ss = db.scalars(select(TrainingSession).where(TrainingSession.falcon_id == fid, TrainingSession.start >= since)
                        .order_by(TrainingSession.start.desc())).all()
        out.append("<h2>Training sessions</h2>")
        out.append(_table(["Date (UTC)", "Type", "Trainer", "Duration", "Outcome", "Observations"],
                          [[f"{s.start:%d %b %H:%M}", e(s.type), e(s.trainer_name or ""), f"{s.duration_min or 0:g} min",
                            e(s.outcome or "—"), e(s.observations or "")] for s in ss[:40]]))

    if kind in ("full", "health") and can(user, "health.read"):
        out.append("<h2>Health observations</h2>")
        al = db.scalars(select(Alert).where(Alert.falcon_id == fid, Alert.status.in_(["open", "acknowledged", "reviewed"]))
                        .order_by(Alert.level.desc())).all()
        for a in al:
            out.append(f'<p class="lvl">Level {a.level} — {e(health.LEVELS[a.level])}: {e(a.title)}</p><ul>' +
                       "".join(f"<li>{e(o['text'])} {_p(o['provenance'])}</li>" for o in a.observations) + "</ul>" +
                       f"<p>Period: {a.period_start:%d %b} – {a.period_end:%d %b %Y} · Confidence: {a.confidence:.0%} · Status: {e(a.status)}</p>"
                       f'<div class="note"><b>Data limitations.</b> {e(a.limitations)}<br><b>Recommended human follow-up.</b> {e(a.follow_up)}</div>' +
                       "".join(f"<p>↳ {e(n['user'])} ({e(n['role'])}): {e(n['note'])} {_p(n['provenance'])}</p>" for n in a.annotations or []))
        ws = db.scalars(select(WeightRecord).where(WeightRecord.falcon_id == fid, WeightRecord.ts >= since).order_by(WeightRecord.ts.desc())).all()
        tr = db.scalar(select(TargetRange).where(TargetRange.falcon_id == fid, TargetRange.active.is_(True)))
        out.append("<h2>Weight records</h2>")
        if tr:
            out.append(f"<p>Target range {tr.min_g:.0f} – {tr.max_g:.0f} g {_p('vet_assessment')}</p>")
        out.append(_table(["Date (UTC)", "Weight", "Context", "Source"],
                          [[f"{w.ts:%d %b %H:%M}", f"{w.weight_g:.0f} g", e(w.context or ""), _p(w.provenance)] for w in ws[:45]]))
        hr = db.scalars(select(HealthRecord).where(HealthRecord.falcon_id == fid, HealthRecord.ts >= since - timedelta(days=30))
                        .order_by(HealthRecord.ts.desc())).all()
        out.append("<h2>Health and veterinary records</h2>")
        out.append(_table(["Date", "Type", "Record", "Recorded by", "Source"],
                          [[f"{r.ts:%d %b %Y}", e(r.kind), e(r.title) + (f"<br><small>{e(r.detail)}</small>" if r.detail else ""),
                            e(r.recorder_name or ""), _p(r.provenance)] for r in hr]))
    out.append('<p class="foot">Falcon Intelligence — Powered by HolyHornet. This report supports, and does not replace, '
               "the judgement of qualified falconers and veterinary professionals.</p>")
    return HTMLResponse("<!doctype html><meta charset='utf-8'><title>Falcon report</title>" + "".join(out))
