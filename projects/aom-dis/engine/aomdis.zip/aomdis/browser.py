"""Browser edition bridge: the unmodified AOM-DIS FastAPI application inside Pyodide (CPython on WebAssembly).

The Web Worker (frontend/public/engine/worker.js) writes the prepared warehouse to ``db_path`` and calls
``boot()`` once, then ``request(method, path, headers_json, body)`` for every API call. Requests go through
the full ASGI stack (security middleware, validation, auth, RBAC, services, SQLite) exactly as on a server;
only the transport differs (postMessage instead of TCP).

Differences from the server, all deliberate:
* no threads: sync endpoints run inline (anyio.to_thread is patched) and background jobs answer 501;
* the legacy /prediction and /prototype mounts are not included;
* the database lives in the visitor's tab: changes are kept until the tab is reloaded, never sent anywhere.
"""
from __future__ import annotations

import json
import os

_app = None


def _no_threads() -> None:
    """Pyodide cannot start threads. Starlette/FastAPI run sync endpoints via anyio.to_thread.run_sync;
    run them inline instead (one request at a time, like a single-worker server)."""
    import anyio.to_thread

    async def run_sync(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):  # noqa: ARG001
        return func(*args)

    anyio.to_thread.run_sync = run_sync


def boot(db_path: str, secret: str) -> dict:
    """Configure the environment and import the application. Returns timing and dataset info."""
    global _app
    import time
    t = time.time()
    os.environ.update({
        "AOMDIS_BROWSER": "1",
        "AOMDIS_DATABASE_URL": f"sqlite:///{db_path}",
        "AOMDIS_SECRET_KEY": secret,
        "AOMDIS_PBKDF2_ITERATIONS": "2000",       # demo accounts only; the database never leaves the tab
        "AOMDIS_API_DOCS": "0",
        "AOMDIS_LOG_LEVEL": "WARNING",
        "AOMDIS_REPORTS": os.path.join(os.getcwd(), "reports"),   # stored reports shipped in the zip
    })
    _no_threads()
    from .api.app import app
    from .ingest.pipeline import latest_dataset_version
    _app = app
    return {"ok": True, "boot_s": round(time.time() - t, 2), "dataset_version": latest_dataset_version()}


async def request(method: str, path: str, headers_json: str = "{}", body: bytes | None = None) -> dict:
    if _app is None:
        raise RuntimeError("call boot() first")
    headers = json.loads(headers_json or "{}")
    p, _, qs = path.partition("?")
    raw_body = bytes(body) if body is not None and type(body).__name__ != "JsNull" else b""   # JS null -> JsNull
    hdrs = [(k.lower().encode(), str(v).encode()) for k, v in headers.items()]
    hdrs.append((b"host", b"aomdis.local"))
    if raw_body:
        hdrs.append((b"content-length", str(len(raw_body)).encode()))
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(), "scheme": "http",
             "path": p, "raw_path": p.encode(), "query_string": qs.encode(), "root_path": "", "headers": hdrs,
             "client": ("browser", 0), "server": ("aomdis.local", 80)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": raw_body, "more_body": False}
        return {"type": "http.disconnect"}

    out = {"status": 500, "headers": [], "body": b""}
    chunks: list[bytes] = []

    async def send(msg):
        if msg["type"] == "http.response.start":
            out["status"] = msg["status"]
            out["headers"] = [[k.decode(), v.decode()] for k, v in msg.get("headers", [])]   # keep repeated headers
        elif msg["type"] == "http.response.body":
            chunks.append(msg.get("body", b""))

    await _app(scope, receive, send)
    out["body"] = b"".join(chunks)
    return out
