"""Adapter: run the original D-7 calibrated model (``fpred.forecast``) for every schedule list and
store its forecasts in the warehouse (``model_version`` / ``forecast_run`` / ``forecast``).

The model itself is untouched. For list L published on day P it is trained on fpred
evaluations of *earlier* lists restricted to flights before P (exactly as in fpred's own
backtest), then applied to every entry of L:

    E[arrivals or departures in local hour h of day d] = Σ p_operate(operator, direction)
                                                         + added_mean(weekday, direction) · share(h)

``share(h)`` is the local-hour profile of unscheduled ('added') traffic in the training data.
Cutoff = publication date 00:00 Europe/Amsterdam; horizon = target local date − publication date.
The first list has no earlier history, so it gets no calibrated forecast (shown as unavailable).
"""
from __future__ import annotations

import hashlib
import inspect
import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from sqlalchemy import delete, select, text

import fpred
from fpred import forecast as fforecast
from fpred import pipeline as fpipeline

from ..core.timeutil import local_day_bounds_utc, local_fields
from ..db import models as M
from ..db.session import engine, session_scope
from ..ingest.pipeline import latest_dataset_version

MODEL_NAME = "fpred-calibrated"


def model_version_id() -> tuple[str, dict]:
    code = inspect.getsource(fforecast).encode()
    sha = hashlib.sha256(code).hexdigest()
    params = {"k": 20.0, "half_life": "inf", "training": "earlier lists, flights before publication"}
    return f"{MODEL_NAME}@{fpred.__version__}#{sha[:8]}", {"sha": sha, "params": params}


def run(url: str | None = None, dsv: str | None = None) -> dict:
    dsv = dsv or latest_dataset_version(url)
    if dsv is None:
        raise LookupError("no dataset version; run ingest first")
    mv_id, meta = model_version_id()
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    with session_scope(url) as s:
        if s.get(M.ModelVersion, mv_id) is None:
            s.add(M.ModelVersion(id=mv_id, name=MODEL_NAME, version=fpred.__version__, family="calibrated-schedule",
                                 params_json=json.dumps(meta["params"]), code_sha256=meta["sha"], created_utc=now))
        old = [r[0] for r in s.execute(select(M.ForecastRun.id).where(
            (M.ForecastRun.model_version_id == mv_id) & (M.ForecastRun.dataset_version_id == dsv)))]
        if old:
            s.execute(delete(M.Forecast).where(M.Forecast.run_id.in_(old)))
            s.execute(delete(M.ForecastRun).where(M.ForecastRun.id.in_(old)))

    ctx = fpipeline.Context()
    evals = sorted(fpipeline.run_all(ctx, write=False), key=lambda e: e.info.published)
    with engine(url).connect() as c:
        lists = pd.read_sql(text("select id, name, published_date from schedule_list where dataset_version_id=:d"), c, params={"d": dsv})
    out = {}
    for _, L in lists.iterrows():
        pub = pd.Timestamp(L["published_date"]).date()
        earlier = [e for e in evals if e.info.published < pub]
        cutoff_utc, _ = local_day_bounds_utc(pub)
        if not earlier:
            out[L["name"]] = "no earlier history: no calibrated forecast"
            continue
        train = pd.concat([e.flights[e.flights["time"] < cutoff_utc].assign(source=e.info.name) for e in earlier], ignore_index=True)
        model = fforecast.fit(train, cutoff=cutoff_utc)
        added = train[train["state"] == "added"]
        ah = local_fields(added["time"])["local_hour"].astype(int)
        share = added.groupby([ah.values, added["direction"].values]).size().unstack(fill_value=0)
        share = share.reindex(range(24), fill_value=0).reindex(columns=["ARR", "DEP"], fill_value=0)
        share = share / share.sum().replace(0, 1)

        with engine(url).connect() as c:
            ent = pd.read_sql(text("select operator_icao, direction, local_date, local_hour from schedule_entry where schedule_list_id=:l"),
                              c, params={"l": int(L["id"])})
        ent["p"] = [model.p_operate(o, d) for o, d in zip(ent["operator_icao"], ent["direction"])]
        hourly = ent.groupby(["local_date", "local_hour", "direction"])["p"].sum().unstack(fill_value=0.0)
        hourly = hourly.reindex(columns=["ARR", "DEP"], fill_value=0.0)
        days = sorted(ent["local_date"].unique())
        idx = pd.MultiIndex.from_product([days, range(24)], names=["local_date", "local_hour"])
        hourly = hourly.reindex(idx, fill_value=0.0)
        wd = pd.to_datetime(hourly.index.get_level_values(0)).day_of_week
        hrs = hourly.index.get_level_values(1)
        for dr in ("ARR", "DEP"):
            add = np.array([model.added_mean.get((int(w), dr), 0.0) for w in wd]) * share[dr].to_numpy()[hrs]
            hourly[dr] = hourly[dr].to_numpy() + add
        hourly = hourly.reset_index()
        hourly["horizon_days"] = (pd.to_datetime(hourly["local_date"]) - pd.Timestamp(pub)).dt.days

        with session_scope(url) as s:
            r = M.ForecastRun(model_version_id=mv_id, dataset_version_id=dsv, cutoff_utc=cutoff_utc.to_pydatetime(),
                              created_utc=now, purpose="backtest", schedule_list_id=int(L["id"]))
            s.add(r)
            s.flush()
            run_id = r.id
        rows = []
        for metric, col in (("arrivals", "ARR"), ("departures", "DEP")):
            rows.append(pd.DataFrame({"run_id": run_id, "target_local_date": hourly["local_date"], "target_local_hour": hourly["local_hour"],
                                      "horizon_days": hourly["horizon_days"], "metric": metric, "value": hourly[col].round(3),
                                      "lower": None, "upper": None, "interval_level": None}))
        daily = hourly.groupby("local_date").agg(ARR=("ARR", "sum"), DEP=("DEP", "sum"), horizon_days=("horizon_days", "first")).reset_index()
        daily["MOV"] = daily["ARR"] + daily["DEP"]
        for metric, col in (("arrivals", "ARR"), ("departures", "DEP"), ("movements", "MOV")):
            rows.append(pd.DataFrame({"run_id": run_id, "target_local_date": daily["local_date"], "target_local_hour": None,
                                      "horizon_days": daily["horizon_days"], "metric": metric, "value": daily[col].round(3),
                                      "lower": None, "upper": None, "interval_level": None}))
        df = pd.concat(rows, ignore_index=True)
        with engine(url).begin() as c:
            df.to_sql("forecast", c, if_exists="append", index=False, chunksize=5000)
        out[L["name"]] = {"run_id": run_id, "rows": len(df), "days": len(days), "cutoff_utc": str(cutoff_utc)}
    return {"model_version": mv_id, "dataset_version": dsv, "lists": out}
