"""Post-operations reports built on the daily performance store and the warehouse.

Deviation identity for a day d against its plan of record P (fpred matching, inferred):
    plan     = matched + canceled                (every plan entry is matched or not flown)
    actual   = matched + added + boundary        (boundary = flights matched to plan entries of the
                                                  neighbouring day across local midnight)
 => actual − plan = added − canceled + boundary
"""
from __future__ import annotations

import io
from datetime import date

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..db.session import engine
from ..ingest.pipeline import latest_dataset_version
from ..tactical import state as ST
from .metrics import load_daily

LAYERS = [
    ("strategic_mov", "Strategic plan (earliest list)", "scheduled"),
    ("plan_mov", "Plan of record (latest list)", "scheduled"),
    ("fc_d7_fpred", "D-7 original engine", "predicted"),
    ("fc_d7_ensemble", "D-7 ensemble", "predicted"),
    ("fc_d1_ensemble", "D-1 ensemble", "predicted"),
    ("fc_d0_ensemble", "D-0 ensemble (00:00)", "predicted"),
    ("nowcast_12", "Intraday nowcast (12:00)", "predicted"),
]
SEASON_SWITCH = date(2022, 3, 27)   # IATA summer season starts on the last Sunday of March


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


def _f(x, digits=2):
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return None
    return round(float(x), digits)


def _err(a: pd.Series, f: pd.Series) -> dict:
    ok = a.notna() & f.notna()
    a, f = a[ok], f[ok]
    if not len(a):
        return {"n": 0}
    e = a - f
    return {"n": int(len(a)), "mae": _f(e.abs().mean(), 1), "rmse": _f(np.sqrt((e ** 2).mean()), 1), "bias": _f(e.mean(), 1),
            "mape_pct": _f((e.abs() / a).mean() * 100, 2)}


# ----------------------------------------------------------------------------------------- summaries
def summaries(period: str, start: date, end: date) -> dict:
    W = load_daily(start, end)
    if W.empty:
        raise LookupError("no stored daily metrics in this range: generate them first (Post-Operations → Generate)")
    d = pd.to_datetime(W["local_date"])
    key = {"day": d.dt.strftime("%Y-%m-%d"), "week": d.dt.strftime("%G-W%V"), "month": d.dt.strftime("%Y-%m"),
           "season": np.where(W["local_date"] >= SEASON_SWITCH, "S22 (from 27 Mar)", "W21 (to 26 Mar)")}[period]
    W = W.assign(key=key)
    rows = []
    for k, g in sorted(W.groupby("key"), key=lambda kv: kv[1]["local_date"].min()):
        r = {"period": k, "days": int(len(g)), "first": str(g["local_date"].min()), "last": str(g["local_date"].max()),
             "actual": _f(g["actual_mov"].sum(), 0), "actual_per_day": _f(g["actual_mov"].mean(), 1),
             "plan": _f(g["plan_mov"].sum(min_count=1), 0), "deviation_vs_plan_pct": None,
             "canceled_inferred": _f(g.get("canceled", pd.Series(dtype=float)).sum(min_count=1), 0),
             "added": _f(g.get("added", pd.Series(dtype=float)).sum(min_count=1), 0),
             "peak_util_max": _f(g.get("peak_util", pd.Series(dtype=float)).max(), 3),
             "hours_ge_90": _f(g.get("hours_ge_90", pd.Series(dtype=float)).sum(min_count=1), 0),
             "share_dev_gt_15": _f(g.get("share_dev_gt_15", pd.Series(dtype=float)).mean(), 3),
             "alert_days_high": int((g.get("alerts_high", pd.Series(0, index=g.index)).fillna(0) > 0).sum()),
             "events": _f(g.get("events", pd.Series(dtype=float)).sum(min_count=1), 0)}
        both = g[g["plan_mov"].notna()]
        if len(both):
            r["deviation_vs_plan_pct"] = _f((both["actual_mov"].sum() - both["plan_mov"].sum()) / both["plan_mov"].sum() * 100, 2)
            sch = both["canceled"].sum() + both["matched"].sum() if "matched" in both else None
            r["inferred_cancel_rate"] = _f(both["canceled"].sum() / sch, 4) if sch else None
        for col, _, _ in LAYERS[2:]:
            if col in g:
                r[f"mape_{col}"] = _err(g["actual_mov"], g[col]).get("mape_pct")
        rows.append(r)
    return {"period": period, "range": [str(start), str(end)], "rows": rows,
            "kinds": {"actual": "actual", "plan": "scheduled", "canceled_inferred": "inferred", "added": "inferred",
                      "peak_util_max": "derived", "share_dev_gt_15": "derived (actual − predicted runway time)", "mape_*": "derived"}}


# ----------------------------------------------------------------------------------------- accuracy waterfall
def accuracy(start: date, end: date) -> dict:
    W = load_daily(start, end)
    if W.empty:
        raise LookupError("no stored daily metrics in this range")
    # layers with no data at all in the range (e.g. no backtest run) do not block the like-for-like comparison
    cols = [c for c, _, _ in LAYERS if c in W and W[c].notna().any()]
    common = W.dropna(subset=cols + ["actual_mov"])
    layers = []
    for col, label, kind in LAYERS:
        if col not in W:
            continue
        lead = {"strategic_mov": W.get("strategic_lead_days"), "plan_mov": W.get("plan_lead_days")}.get(col)
        layers.append({"layer": col, "label": label, "kind": kind,
                       "all_days": _err(W["actual_mov"], W[col]),
                       "common_days": _err(common["actual_mov"], common[col]),
                       "mean_lead_days": _f(lead.mean(), 1) if lead is not None else {"fc_d7_fpred": 7, "fc_d7_ensemble": 7, "fc_d1_ensemble": 1,
                                                                                    "fc_d0_ensemble": 0, "nowcast_12": 0}.get(col)})
    by_wd = []
    Wd = W.assign(wd=pd.to_datetime(W["local_date"]).dt.day_of_week)
    for wd, g in Wd.groupby("wd"):
        by_wd.append({"weekday": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][int(wd)],
                      **{col: _err(g["actual_mov"], g[col]).get("bias") for col, _, _ in LAYERS if col in g}})
    daily = W[["local_date", "actual_mov"] + cols].copy()
    daily["local_date"] = daily["local_date"].astype(str)
    return {"range": [str(start), str(end)], "common_days": int(len(common)), "common_layers": cols, "layers": layers, "bias_by_weekday": by_wd,
            "daily": daily.astype(object).where(daily.notna(), None).to_dict("records"),
            "note": "Error = actual − layer. 'Common days' compares every layer on the same days (fair); 'all days' uses each layer's own coverage."}


# ----------------------------------------------------------------------------------------- deviations
def _por_pairs(start: date, end: date) -> list[tuple[str, int]]:
    out = []
    for d in pd.date_range(start, end).date:
        p = ST.tactical_plan(d)
        if p is not None:
            out.append((str(d), int(p["id"])))
    return out


def deviations(start: date, end: date, by: str = "operator", top: int = 25) -> dict:
    pairs = _por_pairs(start, end)
    if not pairs:
        raise LookupError("no plan of record covers this range")
    cond = " or ".join(f"(mm.local_date='{d}' and mm.schedule_list_id={l})" for d, l in pairs)
    expr = {"operator": "coalesce(m.operator_icao, e.operator_icao, '—')",
            "country": "substr(coalesce(m.other_airport, e.other_airport), 1, 2)",
            "hour": "mm.local_hour", "direction": "mm.direction"}[by]
    df = _q(f"select {expr} k, mm.state, count(*) n from movement_match mm left join schedule_entry e on e.id=mm.schedule_entry_id "
            f"left join movement m on m.id=mm.movement_id where ({cond}) group by 1, 2")
    p = df.pivot_table(index="k", columns="state", values="n", aggfunc="sum", fill_value=0)
    for c in ("matched", "canceled", "confirmed_canceled", "added"):
        if c not in p:
            p[c] = 0
    p["canceled_all"] = p["canceled"] + p["confirmed_canceled"]
    p["planned"] = p["matched"] + p["canceled_all"]
    p["flown"] = p["matched"] + p["added"]
    p["net"] = p["flown"] - p["planned"]
    p["cancel_rate"] = (p["canceled_all"] / p["planned"].replace(0, np.nan)).round(4)
    p["unscheduled_share"] = (p["added"] / p["flown"].replace(0, np.nan)).round(4)
    p = p.reset_index().rename(columns={"k": by})
    if by == "hour":
        p = p.sort_values(by)
    else:
        p = p.reindex(p["net"].abs().sort_values(ascending=False).index).head(top)
    cols = [by, "planned", "flown", "matched", "canceled_all", "added", "net", "cancel_rate", "unscheduled_share"]
    return {"by": by, "range": [str(start), str(end)], "days": len(pairs), "kind": "inferred (fpred matching of the plan of record)",
            "rows": p[cols].astype(object).where(p[cols].notna(), None).to_dict("records")}


# ----------------------------------------------------------------------------------------- root cause for a day
def root_cause(d: date, with_alerts: bool = True) -> dict:
    W = load_daily(d, d)
    if W.empty:
        raise LookupError(f"no stored metrics for {d}")
    r = W.iloc[0]
    g = lambda k: None if k not in r or pd.isna(r[k]) else float(r[k])  # noqa: E731
    plan, actual, added, canceled, matched = g("plan_mov"), g("actual_mov"), g("added"), g("canceled"), g("matched")
    decomp = None
    if plan is not None:
        boundary = actual - matched - added
        decomp = {"actual": actual, "plan": plan, "deviation": actual - plan, "added": added, "canceled_inferred": canceled,
                  "boundary": boundary, "check": round((added - canceled + boundary) - (actual - plan), 6)}
    contributors = {by: deviations(d, d, by, top=10)["rows"] for by in ("operator", "country")} if plan is not None else {}
    hours = deviations(d, d, "hour")["rows"] if plan is not None else []
    s = ST.snap()
    same = [x for x in s.days if x < d and x.weekday() == d.weekday()][-4:]
    typical = float(s.daily.loc[same].sum(axis=1).mean()) if same else None
    fc = {col: g(col) for col, _, _ in LAYERS}
    errors = {col: None if v is None else round(actual - v, 1) for col, v in fc.items()}
    from ..tactical import alerts as AL
    tl = AL.timeline_of_alerts(d) if with_alerts else []
    ev = ST.events_records(ST.events_on(d))
    findings = []
    if decomp:
        if canceled and canceled > 1.5 * (added or 0) and decomp["deviation"] < 0:
            top = contributors["operator"][0] if contributors.get("operator") else None
            findings.append({"finding": "Shortfall driven by inferred cancellations", "kind": "inferred",
                             "evidence": f"{canceled:.0f} plan entries not flown vs {added:.0f} unscheduled flights"
                                         + (f"; largest net change: {top['operator']} ({top['net']:+d})" if top else ""),
                             "confidence": "medium", "limit": "cancellations are inferred by matching, not recorded"})
        elif added and added > (canceled or 0) and decomp["deviation"] > 0:
            findings.append({"finding": "Surplus driven by unscheduled traffic", "kind": "inferred",
                             "evidence": f"{added:.0f} unscheduled vs {canceled:.0f} not flown", "confidence": "medium", "limit": "inferred"})
    if typical:
        dev_t = (actual - typical) / typical
        if abs(dev_t) > 0.15:
            findings.append({"finding": f"Day {'far above' if dev_t > 0 else 'far below'} the usual level for a {d.strftime('%A')}",
                             "kind": "derived", "evidence": f"{actual:.0f} vs {typical:.0f} on the previous 4 {d.strftime('%A')}s ({dev_t:+.0%})",
                             "confidence": "high", "limit": "cause not in the data (weather, airline decisions, events)"})
    if errors.get("fc_d1_ensemble") is not None and abs(errors["fc_d1_ensemble"]) > 80:
        findings.append({"finding": "D-1 forecast missed by more than 80 movements", "kind": "derived",
                         "evidence": f"actual − D-1 ensemble = {errors['fc_d1_ensemble']:+.0f}; nowcast at 12:00 error {errors.get('nowcast_12')}",
                         "confidence": "high", "limit": "information not available at D-1 (same-day disruption) is the usual cause"})
    if not ev:
        findings.append({"finding": "No operational event recorded for this day", "kind": "actual",
                         "evidence": "event log empty for the day", "confidence": "high",
                         "limit": "recording events during operations makes later root-cause analysis possible"})
    return {"day": str(d), "weekday": d.strftime("%A"), "decomposition": decomp, "typical_same_weekday": typical,
            "layers": fc, "errors": errors, "contributors": contributors, "hours": hours, "alerts": tl, "events": ev,
            "findings": findings,
            "identity": "actual − plan = added − canceled + boundary (boundary: flights matched to plan entries of the adjacent day)"}


# ----------------------------------------------------------------------------------------- patterns & recommendations
def patterns(start: date, end: date) -> dict:
    W = load_daily(start, end)
    if W.empty:
        raise LookupError("no stored daily metrics in this range")
    acc = accuracy(start, end)
    ops = deviations(start, end, "operator", top=200)["rows"]
    hours = deviations(start, end, "hour")["rows"]
    O = pd.DataFrame(ops)
    PLACEHOLDERS = {"—", "ZZZ"}          # no operator / ICAO 'no designator' placeholder: not an airline
    O = O[~O["operator"].isin(PLACEHOLDERS)]
    mean_rate = float(O["canceled_all"].sum() / O["planned"].sum()) if len(O) and O["planned"].sum() else None
    unreliable = O[(O["planned"] >= 50) & (O["cancel_rate"] >= 2 * (mean_rate or 1))].sort_values("cancel_rate", ascending=False)
    unscheduled = O[(O["flown"] >= 30) & (O["unscheduled_share"] >= 0.5)].sort_values("added", ascending=False)
    Hh = pd.DataFrame(hours)
    Hh["gap"] = Hh["flown"] - Hh["planned"]
    weekday_bias = [{"weekday": r["weekday"], "bias_d1": r.get("fc_d1_ensemble"), "bias_plan": r.get("plan_mov")} for r in acc["bias_by_weekday"]]
    return {"range": [str(start), str(end)], "mean_cancel_rate": mean_rate,
            "unreliable_operators": unreliable.head(10).to_dict("records"),
            "unscheduled_operators": unscheduled.head(10).to_dict("records"),
            "hour_gaps": Hh[["hour", "planned", "flown", "gap"]].to_dict("records"),
            "weekday_bias": weekday_bias, "accuracy": acc["layers"],
            "capacity": {"days": int(len(W)), "days_with_high_hours": int((W.get("hours_ge_90", pd.Series(0)).fillna(0) > 0).sum()),
                         "hours_ge_90": _f(W.get("hours_ge_90", pd.Series(dtype=float)).sum(), 0),
                         "binding_arrivals_hours": _f(W.get("binding_arrivals_hours", pd.Series(dtype=float)).sum(), 0)}}


def recommendations(start: date, end: date) -> list[dict]:
    P = patterns(start, end)
    recs = []
    L = {x["layer"]: x for x in P["accuracy"]}

    def conf(n, consistent=True):
        return "high" if n >= 30 and consistent else "medium" if n >= 10 else "low"

    # 1. which forecast to use per horizon (model evaluation store)
    ev = _q("select mv.name, e.horizon_days k, e.mae from model_evaluation e join model_version mv on mv.id=e.model_version_id "
            "where e.dataset_version_id=:d and e.granularity='day' and e.metric='movements' and mv.name in ('ensemble','fpred_calibrated')",
            d=latest_dataset_version())
    if len(ev):
        piv = ev.pivot_table(index="k", columns="name", values="mae")
        if {"ensemble", "fpred_calibrated"} <= set(piv.columns):
            fp_better = [int(k) for k, r in piv.iterrows() if r["fpred_calibrated"] < r["ensemble"]]
            en_better = [int(k) for k, r in piv.iterrows() if r["ensemble"] <= r["fpred_calibrated"]]
            recs.append({"area": "Forecasting", "recommendation": f"Use the original D-7 engine for horizons D-{min(fp_better)}…D-{max(fp_better)} and the ensemble for D-{min(en_better)}…D-{max(en_better)}"
                         if fp_better and en_better else "Keep the best-performing model per horizon",
                         "evidence": "; ".join(f"D-{int(k)}: ensemble {r['ensemble']:.1f} vs D-7 engine {r['fpred_calibrated']:.1f} MAE" for k, r in piv.iterrows()),
                         "confidence": conf(50), "kind": "derived", "limit": "7-week backtest window; re-evaluate after new data"})
    # 2. systematic plan bias
    plan = L.get("plan_mov", {}).get("all_days", {})
    if plan.get("n", 0) and plan.get("bias") is not None and abs(plan["bias"]) > 20:
        recs.append({"area": "Planning", "recommendation": f"Correct the plan of record for a systematic {'over' if plan['bias'] < 0 else 'under'}-statement of ~{abs(plan['bias']):.0f} movements/day "
                     "(use the calibrated forecast rather than the raw schedule for resource planning)",
                     "evidence": f"actual − plan bias {plan['bias']:+.1f}/day over {plan['n']} days (MAPE {plan.get('mape_pct')}%)",
                     "confidence": conf(plan["n"]), "kind": "derived", "limit": "bias is inferred against the newest list; driven by inferred cancellations"})
    # 3. weekday-specific forecast bias
    wb = [w for w in P["weekday_bias"] if w["bias_d1"] is not None and abs(w["bias_d1"]) > 25]
    if wb:
        recs.append({"area": "Forecasting", "recommendation": "Add a weekday bias correction to the D-1 forecast for " + ", ".join(w["weekday"] for w in wb),
                     "evidence": "; ".join(f"{w['weekday']} bias {w['bias_d1']:+.0f}" for w in wb),
                     "confidence": "low", "kind": "derived", "limit": "few days per weekday in the window; confirm on more data before applying"})
    # 4. unreliable operators — unless the pattern looks like an identity mismatch (many 'not flown' AND many
    #    'unscheduled' for the same operator: flights listed under one identity and flown under another)
    identity = [o for o in P["unreliable_operators"] if o["added"] >= 0.5 * o["canceled_all"] and (o["unscheduled_share"] or 0) >= 0.5]
    for o in identity[:3]:
        recs.append({"area": "Data", "recommendation": f"Fix flight-identity matching for {o['operator']}: its listed flights are not recognised when flown",
                     "evidence": f"{o['canceled_all']} listed movements 'not flown' while {o['added']} of its {o['flown']} flown movements were 'unscheduled'",
                     "confidence": "medium", "kind": "inferred",
                     "limit": "typical for business aviation (callsign ≠ listed flight number); not a reliability problem"})
    for o in [x for x in P["unreliable_operators"] if x not in identity][:3]:
        recs.append({"area": "Schedule reliability", "recommendation": f"Review the schedule reliability of {o['operator']} before planning resources on it",
                     "evidence": f"{o['canceled_all']} of {o['planned']} planned movements not flown ({o['cancel_rate']:.0%} vs {P['mean_cancel_rate']:.0%} overall)",
                     "confidence": conf(o["planned"]), "kind": "inferred", "limit": "cancellations inferred; could also be identity mismatches"})
    # 5. unscheduled traffic
    if P["unscheduled_operators"]:
        top = P["unscheduled_operators"][:3]
        recs.append({"area": "Planning", "recommendation": "Plan explicitly for unscheduled traffic (business aviation, ad-hoc operators) in hourly resource planning",
                     "evidence": "; ".join(f"{o['operator']}: {o['added']} unscheduled ({o['unscheduled_share']:.0%} of its flights)" for o in top),
                     "confidence": "medium", "kind": "inferred", "limit": "unscheduled = not in the published list"})
    # 6. hourly timing of the plan
    hg = pd.DataFrame(P["hour_gaps"])
    if len(hg):
        worst = hg.reindex(hg["gap"].abs().sort_values(ascending=False).index).head(3)
        recs.append({"area": "Planning", "recommendation": "Plan hourly resources on runway-time profiles: the published lists time arrivals at FIR entry, shifting demand into earlier hours",
                     "evidence": "; ".join(f"{int(r.hour):02d}:00 flown − planned = {int(r.gap):+d}" for r in worst.itertuples()),
                     "confidence": "medium", "kind": "derived", "limit": "lists contain no scheduled in-block times"})
    # 7. capacity
    c = P["capacity"]
    if c["hours_ge_90"]:
        recs.append({"area": "Capacity", "recommendation": "Review arrival capacity and the spread of arrival waves at recurring peaks (see Capacity Management → bottlenecks)",
                     "evidence": f"{c['hours_ge_90']:.0f} hours ≥ 90 % utilisation on {c['days_with_high_hours']} of {c['days']} days; arrivals binding in {c['binding_arrivals_hours']:.0f}",
                     "confidence": "medium", "kind": "derived", "limit": "capacity values are configured assumptions"})
    # 8. data gaps
    recs.append({"area": "Data", "recommendation": "Connect weather (METAR/TAF), runway-in-use and block-time data and record operational events during the day",
                 "evidence": "root-cause analysis cannot attribute deviations to weather or infrastructure without them; event log is mostly empty",
                 "confidence": "high", "kind": "unavailable", "limit": "—"})
    return recs


# ----------------------------------------------------------------------------------------- export
def export_xlsx(start: date, end: date) -> bytes:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf) as xw:
        pd.DataFrame({"generated_from": ["AOM-DIS post-operations"], "range": [f"{start} … {end}"], "dataset_version": [latest_dataset_version()],
                      "note": ["Historical EHAM 2022 data. Cancellations inferred; delays derived; capacity values are configured assumptions."]}).to_excel(xw, sheet_name="About", index=False)
        load_daily(start, end).to_excel(xw, sheet_name="Daily metrics", index=False)
        for period in ("week", "month", "season"):
            pd.DataFrame(summaries(period, start, end)["rows"]).to_excel(xw, sheet_name=f"{period.title()} summary", index=False)
        acc = accuracy(start, end)
        pd.DataFrame([{"layer": l["label"], **{f"all_{k}": v for k, v in l["all_days"].items()}, **{f"common_{k}": v for k, v in l["common_days"].items()}}
                      for l in acc["layers"]]).to_excel(xw, sheet_name="Forecast accuracy", index=False)
        pd.DataFrame(deviations(start, end, "operator", top=100)["rows"]).to_excel(xw, sheet_name="Deviations by operator", index=False)
        pd.DataFrame(recommendations(start, end)).to_excel(xw, sheet_name="Recommendations", index=False)
    return buf.getvalue()

