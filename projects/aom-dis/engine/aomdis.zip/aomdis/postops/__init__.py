"""Post-operations performance analysis: daily performance store, period summaries, forecast-accuracy
waterfall across the planning lifecycle, deviation and root-cause analysis, recurring patterns and
evidence-based recommendations."""
