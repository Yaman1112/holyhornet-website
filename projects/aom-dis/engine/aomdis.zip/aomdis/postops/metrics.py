"""Daily performance store (``performance_metric``, period = 'day').

Planning layers per operational day d (all movements = arrivals + departures):
  strategic_mov      earliest-published schedule list covering d                     scheduled
  plan_mov           plan of record: newest list published before d whose matching covers d   scheduled
  fc_d7_fpred        original D-7 engine forecast issued 00:00 on d−7                 predicted
  fc_d7_ensemble     Phase 4 ensemble at D-7                                          predicted
  fc_d1_ensemble     Phase 4 ensemble at D-1                                          predicted
  fc_d0_ensemble     Phase 4 ensemble at D-0 (00:00 on d)                             predicted
  nowcast_12         tactical intraday nowcast of the day total at 12:00              predicted
  actual_mov         realised movements                                               actual
Outcome metrics: matched / inferred canceled / added (fpred matching of the plan of record; inferred),
peak hours, capacity utilisation against the active profile (derived), a punctuality proxy
(actual − predicted runway time of flown scheduled flights; derived), alerts at 23:30 and recorded events.
"""
from __future__ import annotations

import logging
from datetime import date

import numpy as np
import pandas as pd
from sqlalchemy import delete, text

from ..db import models as M
from ..db.session import engine, session_scope
from ..forecasting import models as MD
from ..ingest.pipeline import latest_dataset_version
from ..services.demand import hourly_capacity
from ..tactical import alerts as AL
from ..tactical import flights as FL
from ..tactical import state as ST

log = logging.getLogger("aomdis.postops")

KIND = {
    "actual_mov": "actual", "actual_arr": "actual", "actual_dep": "actual", "strategic_mov": "scheduled", "strategic_lead_days": "derived",
    "plan_mov": "scheduled", "plan_lead_days": "derived", "fc_d7_fpred": "predicted", "fc_d7_ensemble": "predicted", "fc_d1_ensemble": "predicted",
    "fc_d0_ensemble": "predicted", "nowcast_12": "predicted", "matched": "inferred", "canceled": "inferred", "added": "inferred",
    "peak_actual": "actual", "peak_hour_actual": "actual", "peak_plan": "scheduled", "peak_hour_plan": "scheduled",
    "peak_util": "derived", "hours_ge_90": "derived", "binding_arrivals_hours": "derived",
    "median_runway_dev_min": "derived", "share_dev_gt_15": "derived", "alerts_high": "derived", "alerts_medium": "derived", "events": "actual",
}


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


def _forecasts() -> pd.DataFrame:
    ids = {m: MD.model_version_id(m) for m in ("ensemble", "fpred_calibrated")}
    f = _q("select mv.name model, f.target_local_date d, f.horizon_days k, f.value from forecast f join forecast_run r on r.id=f.run_id "
           "join model_version mv on mv.id=r.model_version_id where r.dataset_version_id=:dsv and f.metric='movements' "
           "and f.target_local_hour is null and r.model_version_id in (:a, :b) and f.horizon_days in (0, 1, 7)",
           dsv=latest_dataset_version(), a=ids["ensemble"], b=ids["fpred_calibrated"])
    f["d"] = pd.to_datetime(f["d"]).dt.date
    return f


def day_metrics(d: date, fc: pd.DataFrame, lists: pd.DataFrame, sched_daily: dict) -> dict:
    s = ST.snap()
    m: dict[str, float | None] = {}
    a = s.daily.loc[d]
    m["actual_arr"], m["actual_dep"] = float(a["arrivals"]), float(a["departures"])
    m["actual_mov"] = m["actual_arr"] + m["actual_dep"]
    cov = lists[(lists["start"] <= d) & (lists["end"] >= d)].sort_values("published_date")
    if len(cov):
        L = cov.iloc[0]
        m["strategic_mov"] = sched_daily.get((int(L["id"]), d))
        m["strategic_lead_days"] = float((d - L["published_date"]).days)
    por = ST.tactical_plan(d)
    if por is not None:
        lid = int(por["id"])
        m["plan_mov"] = sched_daily.get((lid, d))
        m["plan_lead_days"] = float((d - por["published_date"]).days)
        st = _q("select state, count(*) n from movement_match where schedule_list_id=:l and local_date=:t group by 1", l=lid, t=str(d))
        st = dict(zip(st["state"], st["n"]))
        m["matched"] = float(st.get("matched", 0))
        m["canceled"] = float(st.get("canceled", 0) + st.get("confirmed_canceled", 0))
        m["added"] = float(st.get("added", 0))
        ph = _q("select local_hour h, count(*) n from schedule_entry where schedule_list_id=:l and local_date=:t group by 1", l=lid, t=str(d))
        if len(ph):
            i = ph["n"].idxmax()
            m["peak_plan"], m["peak_hour_plan"] = float(ph.at[i, "n"]), float(ph.at[i, "h"])
    g = fc[fc["d"] == d]
    for model, k, key in (("fpred_calibrated", 7, "fc_d7_fpred"), ("ensemble", 7, "fc_d7_ensemble"), ("ensemble", 1, "fc_d1_ensemble"), ("ensemble", 0, "fc_d0_ensemble")):
        v = g[(g["model"] == model) & (g["k"] == k)]["value"]
        m[key] = float(v.iloc[0]) if len(v) else None
    if m.get("fc_d0_ensemble") is not None:
        m["nowcast_12"] = ST.hourly_state(d, "12:00")["kpis"]["nowcast_total"]
    # hourly actuals vs active-profile capacity
    h = s.hourly[s.hourly["local_date"] == d]
    if len(h):
        mov = (h["arrivals"] + h["departures"]).to_numpy(float)
        wd = [d.weekday()] * len(h)
        ut, ua = mov / hourly_capacity("total", wd, h["local_hour"]), h["arrivals"].to_numpy(float) / hourly_capacity("arr", wd, h["local_hour"])
        ud = h["departures"].to_numpy(float) / hourly_capacity("dep", wd, h["local_hour"])
        umax = np.maximum.reduce([ut, ua, ud])
        i = int(mov.argmax())
        m["peak_actual"], m["peak_hour_actual"] = float(mov[i]), float(h["local_hour"].iloc[i])
        m["peak_util"], m["hours_ge_90"] = float(umax.max()), float((umax >= 0.9).sum())
        m["binding_arrivals_hours"] = float(((umax >= 0.9) & (ua >= np.maximum(ut, ud))).sum())
    T = FL.timeline(d, "23:59")
    if len(T):
        fl = T[(T["status"] == "flown") & T["dev_vs_predicted_min"].notna()]
        if len(fl):
            m["median_runway_dev_min"] = float(fl["dev_vs_predicted_min"].median())
            m["share_dev_gt_15"] = float((fl["dev_vs_predicted_min"] > 15).mean())
    al = AL.evaluate(d, "23:30", timeline=T)
    m["alerts_high"] = float(sum(a["severity"] in ("high", "critical") for a in al))
    m["alerts_medium"] = float(sum(a["severity"] == "medium" for a in al))
    m["events"] = float(len(ST.events_on(d)))
    return m


def compute(start: date | None = None, end: date | None = None, progress=None, persist: bool = True) -> pd.DataFrame:
    s = ST.snap()
    days = [d for d in s.days if (start is None or d >= start) and (end is None or d <= end)]
    lists = s.lists
    sched_daily = {(lid, d): float(v.loc[d].sum()) for lid, v in s.sched.items() for d in v.index}
    fc = _forecasts()
    rows = []
    for i, d in enumerate(days):
        for k, v in day_metrics(d, fc, lists, sched_daily).items():
            rows.append({"period": "day", "period_start": d, "metric": k, "value": None if v is None or (isinstance(v, float) and np.isnan(v)) else float(v),
                         "kind": KIND.get(k, "derived")})
        if progress:
            progress((i + 1) / len(days))
    D = pd.DataFrame(rows)
    if persist and len(D):
        dsv = s.dataset_version
        with session_scope() as ss:
            ss.execute(delete(M.PerformanceMetric).where((M.PerformanceMetric.dataset_version_id == dsv) & (M.PerformanceMetric.period == "day")
                                                         & (M.PerformanceMetric.period_start >= min(days)) & (M.PerformanceMetric.period_start <= max(days))))
        with engine().begin() as c:
            D.assign(dataset_version_id=dsv).to_sql("performance_metric", c, if_exists="append", index=False, chunksize=5000)
    return D


def load_daily(start: date | None = None, end: date | None = None) -> pd.DataFrame:
    """Wide table: one row per day, one column per metric (from the store)."""
    p = _q("select period_start d, metric, value from performance_metric where dataset_version_id=:dsv and period='day'"
           + (" and period_start >= :a" if start else "") + (" and period_start <= :b" if end else ""),
           dsv=latest_dataset_version(), a=str(start) if start else None, b=str(end) if end else None)
    if p.empty:
        return p
    p["d"] = pd.to_datetime(p["d"]).dt.date
    W = p.pivot_table(index="d", columns="metric", values="value", aggfunc="first", dropna=False).sort_index()
    W.index.name = "local_date"
    return W.reset_index()


def coverage() -> dict:
    r = _q("select min(period_start) a, max(period_start) b, count(distinct period_start) n from performance_metric "
           "where dataset_version_id=:dsv and period='day'", dsv=latest_dataset_version()).iloc[0]
    return {"first": None if r["a"] is None else str(r["a"]), "last": None if r["b"] is None else str(r["b"]), "days": int(r["n"] or 0)}

