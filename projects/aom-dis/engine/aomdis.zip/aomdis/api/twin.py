"""Digital Twin API (Phase 7)."""
from __future__ import annotations

import json
from datetime import date, datetime, timezone
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select

from ..auth.security import CurrentUser, audit, require
from ..core import reproducibility as RP
from ..db import models as M
from ..db.session import session_scope
from ..ingest.pipeline import latest_dataset_version
from ..tactical import state as ST
from ..twin import model as TM
from ..twin import scenarios as S

router = APIRouter(prefix="/api/v1/twin", tags=["digital twin"], dependencies=[Depends(require("view:twin"))])
HHMM = r"^(([01]\d|2[0-3]):[0-5]\d|24:00)$"


class Intervention(BaseModel):
    type: Literal["capacity", "runway_limit", "demand_surge", "delay_wave", "cancel"]
    start: str = Field(pattern=HHMM)
    end: str = Field(pattern=HHMM)
    flow: Literal["total", "arr", "dep", "all", "ARR", "DEP"] = "all"
    factor: float | None = Field(default=None, ge=0, le=3)
    max_runways: int | None = Field(default=None, ge=0, le=6)
    shift_min: float | None = Field(default=None, gt=0, le=720)
    share: float | None = Field(default=None, gt=0, le=1)
    cause: Literal["runway", "weather", "other"] | None = None
    label: str | None = Field(default=None, max_length=120)


class TwinSpec(BaseModel):
    name: str = Field(default="Twin scenario", min_length=1, max_length=120)
    day: date
    basis: Literal["observed", "planned"] = "observed"
    interventions: list[Intervention] = Field(default_factory=list, max_length=20)
    import_events: bool = False
    seed: int = Field(default=42, ge=0, le=10**6)

    def to_spec(self) -> dict:
        d = self.model_dump(mode="json")
        d["interventions"] = [{k: v for k, v in iv.items() if v is not None} for iv in d["interventions"]]
        return d


def _day(d: date) -> date:
    s = ST.snap()
    if not s.days[0] <= d <= s.days[-1]:
        raise HTTPException(404, f"no complete operational data for {d}; available {s.days[0]} … {s.days[-1]}")
    return d


def _run(spec: dict) -> dict:
    try:
        return S.run(spec)
    except LookupError as e:
        raise HTTPException(404, str(e))
    except (ValueError, KeyError) as e:
        raise HTTPException(400, f"invalid scenario: {e}")


@router.get("/presets")
def presets():
    return S.PRESETS


@router.get("/day")
def day_info(day: date, basis: Literal["observed", "planned"] = "observed"):
    inp = TM.load(_day(day), basis)
    F = inp.flights.assign(h=(inp.flights["demand_min"] // 60).astype(int))
    prof = F.groupby(["h", "direction"]).size().unstack(fill_value=0).reindex(columns=["ARR", "DEP"], fill_value=0)
    return {"day": str(day), "weekday": day.strftime("%A"), "basis": basis, "flights": int(len(F)),
            "basis_kind": "actual" if basis == "observed" else "scheduled",
            "profile": inp.profile, "runway_configs": inp.runway_configs, "events": inp.events,
            "demand_by_slot": [{"slot": int(h), "arr": int(r.ARR), "dep": int(r.DEP)} for h, r in prof.iterrows()],
            "weather": "unavailable — weather restrictions can only be entered as simulated capacity interventions"}


@router.post("/run")
def run(body: TwinSpec):
    _day(body.day)
    return _run(body.to_spec())


@router.post("/scenarios", status_code=201)
def save(body: TwinSpec, user: CurrentUser = Depends(require("manage:scenarios"))):
    _day(body.day)
    res = _run(body.to_spec())
    res["module"] = "twin"
    res["dataset_version"] = latest_dataset_version()
    with session_scope() as s:
        row = M.SimulationScenario(name=body.name, base_local_date=body.day, assumptions_json=json.dumps(res["spec"]),
                                   result_json=json.dumps(res, default=str), created_by=user.username,
                                   created_utc=datetime.now(timezone.utc).replace(tzinfo=None))
        s.add(row)
        s.flush()
        sid = row.id
    audit(user.username, "twin_scenario_saved", f"scenario:{sid}", name=body.name, day=str(body.day), fingerprint=res["fingerprint"])
    return {"id": sid, **res}


def _load(sid: int) -> dict:
    with session_scope() as s:
        r = s.get(M.SimulationScenario, sid)
        if r is None:
            raise HTTPException(404, "no such scenario")
        res = json.loads(r.result_json or "{}")
        if res.get("module") != "twin":
            raise HTTPException(404, "not a digital-twin scenario")
        return {"id": r.id, "name": r.name, "created_by": r.created_by, "created_utc": str(r.created_utc), **res}


@router.get("/scenarios")
def list_scenarios():
    with session_scope() as s:
        out = []
        for r in s.execute(select(M.SimulationScenario).order_by(M.SimulationScenario.id.desc())).scalars():
            res = json.loads(r.result_json or "{}")
            if res.get("module") != "twin":
                continue
            out.append({"id": r.id, "name": r.name, "day": res["inputs"]["day"], "basis": res["inputs"]["basis"], "created_by": r.created_by,
                        "created_utc": str(r.created_utc), "interventions": len(res["spec"]["interventions"]), "fingerprint": res["fingerprint"],
                        "scenario": res["scenario"], "delta": res["delta_vs_baseline"]})
        return out


@router.get("/scenarios/{sid}")
def get_scenario(sid: int):
    return _load(sid)


@router.post("/scenarios/{sid}/reproduce")
def reproduce(sid: int):
    """Re-run a saved twin scenario from its stored spec and compare outputs (reproducibility check, SIM-2)."""
    sc = _load(sid)
    rerun = _run(sc["spec"])
    return {"id": sid, "name": sc["name"], **RP.compare(sc, rerun)}


@router.delete("/scenarios/{sid}")
def delete_scenario(sid: int, user: CurrentUser = Depends(require("manage:scenarios"))):
    sc = _load(sid)
    with session_scope() as s:
        s.delete(s.get(M.SimulationScenario, sid))
    audit(user.username, "twin_scenario_deleted", f"scenario:{sid}", name=sc["name"])
    return {"ok": True}


@router.get("/compare")
def compare(ids: str = Query(..., pattern=r"^\d+(,\d+){0,5}$")):
    items = [_load(int(i)) for i in ids.split(",")]
    return [{"id": x["id"], "name": x["name"], "day": x["inputs"]["day"], "basis": x["inputs"]["basis"], "scenario": x["scenario"],
             "baseline": x["baseline"], "delta": x["delta_vs_baseline"], "queue": x["queue"], "hourly": x["hourly"]} for x in items]
