"""Data Management API (Phase 1): dataset versions, sources, quality, capacity parameters,
and the common movement-demand series every module builds on."""
from __future__ import annotations

import json
from datetime import date

import pandas as pd
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import text

from ..core.provenance import Kind
from ..db.session import engine
from ..ingest import quality, validation
from ..ingest.pipeline import latest_dataset_version

router = APIRouter(prefix="/api/v1/data", tags=["data management"])


def _dsv(dsv: str | None) -> str:
    v = dsv or latest_dataset_version()
    if v is None:
        raise HTTPException(503, "warehouse empty: run `python -m aomdis ingest`")
    return v


def _q(sql: str, **params) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=params)


@router.get("/versions")
def versions():
    return _q("select id, created_utc, status, config_sha256, code_version from dataset_version order by created_utc desc")\
        .astype(str).to_dict("records")


@router.get("/sources")
def sources(dataset_version: str | None = None):
    d = _dsv(dataset_version)
    return _q("select id, file_name, kind, sha256, bytes, rows_raw, rows_loaded, timezone_assumed, description "
              "from data_source where dataset_version_id=:d order by kind, file_name", d=d).to_dict("records")


@router.get("/quality")
def quality_report(dataset_version: str | None = None):
    rep = quality.report(dsv=_dsv(dataset_version))
    return json.loads(json.dumps(rep, default=str))


@router.get("/validation")
def validation_report(dataset_version: str | None = None):
    """Flight-data validation suite DQ-1…DQ-9 (required fields, domains, duplicates, UTC/local consistency,
    future timestamps, referential integrity, one-to-one matching, match-state consistency, hourly outliers)."""
    try:
        return validation.run(_dsv(dataset_version))
    except LookupError as e:
        raise HTTPException(404, str(e))


@router.get("/capacity-parameters")
def capacity_parameters():
    df = _q("select key, value_json, unit, status, source, config_sha256 from capacity_parameter order by key")
    df["value"] = df.pop("value_json").map(json.loads)
    df["kind"] = df["status"].map(lambda s: str(Kind.ASSUMPTION) if s == "assumption" else "configured")
    return df.to_dict("records")


@router.get("/demand")
def demand(start: date, end: date, granularity: str = Query("hour", pattern="^(hour|day)$"),
           dataset_version: str | None = None):
    """Actual movement demand M(t) = A(t) + D(t) per local hour or day (kind = actual)."""
    if (end - start).days > 120:
        raise HTTPException(400, "range limited to 120 days")
    d = _dsv(dataset_version)
    cols = "local_date, local_hour" if granularity == "hour" else "local_date"
    df = _q(f"select {cols}, sum(case when direction='ARR' then 1 else 0 end) arrivals, sum(case when direction='DEP' then 1 else 0 end) departures from movement "
            f"where dataset_version_id=:d and local_date between :a and :b group by {cols} order by {cols}",
            d=d, a=start.isoformat(), b=end.isoformat())
    df["movements"] = df["arrivals"] + df["departures"]
    df["local_date"] = df["local_date"].astype(str)
    return {"dataset_version": d, "kind": str(Kind.ACTUAL), "timezone": "Europe/Amsterdam", "rows": df.to_dict("records")}
