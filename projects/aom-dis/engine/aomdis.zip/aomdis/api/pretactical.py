"""Pre-Tactical Planning and Model Management API (Phase 4)."""
from __future__ import annotations

import json
import math
from datetime import date, timedelta
from functools import lru_cache

import numpy as np
import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text

from ..auth.security import CurrentUser, audit, current_user, require
from ..core.settings import settings
from ..db.session import engine
from ..forecasting import backtest as B
from ..forecasting import models as MD
from ..forecasting.data import hourly_shape, load
from ..ingest.pipeline import latest_dataset_version
from ..services import jobs

router = APIRouter(tags=["pre-tactical & models"])
view_pre = Depends(require("view:pretactical"))


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


def _n(x):
    if x is None:
        return None
    if isinstance(x, (np.floating, float)):
        return None if math.isnan(float(x)) else round(float(x), 3)
    if isinstance(x, np.integer):
        return int(x)
    return x


def _clean(o):
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_clean(v) for v in o]
    return _n(o)


@lru_cache(maxsize=2)
def _snap(dsv: str):
    return load()


def report() -> dict | None:
    p = settings().reports_dir / "pretactical_backtest.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


def _model_ids() -> dict[str, str]:
    return {name: MD.model_version_id(name) for name in MD.MODELS}


# ----------------------------------------------------------------------------------- pre-tactical
@router.get("/api/v1/pretactical/summary", dependencies=[view_pre])
def summary():
    rep = report()
    if rep is None:
        raise HTTPException(404, "no backtest yet: run it from Model Management or `python -m aomdis backtest`")
    rep.pop("_frames", None)
    return _clean({**rep, "models": {k: {"label": v["label"], "family": v["family"], "version_id": MD.model_version_id(k)} for k, v in MD.MODELS.items()},
                   "information_set": "Forecast issued 00:00 local on day D−k: realised days ≤ D−k−1, lists published < D−k.",
                   "horizons": B.HORIZONS})


@router.get("/api/v1/pretactical/forecast", dependencies=[view_pre])
def forecast(target: date, horizon: int = Query(1, ge=0, le=7)):
    dsv = latest_dataset_version()
    ids = _model_ids()
    cutoff = target - timedelta(days=horizon)
    f = _q("select mv.name model, f.metric, f.target_local_hour hour, f.value, f.lower, f.upper from forecast f "
           "join forecast_run r on r.id=f.run_id join model_version mv on mv.id=r.model_version_id "
           "where r.dataset_version_id=:d and r.purpose='backtest' and f.target_local_date=:t and f.horizon_days=:k "
           "and r.model_version_id in (" + ",".join(f"'{v}'" for v in ids.values()) + ")",
           d=dsv, t=target.isoformat(), k=horizon)
    if f.empty:
        raise HTTPException(404, f"no stored forecasts for {target} at D-{horizon} (backtest window or no run yet)")
    snap = _snap(dsv)
    daily = []
    for model in MD.ORDER:
        g = f[(f["model"] == model) & f["hour"].isna()]
        if g.empty:
            daily.append({"model": model, "label": MD.MODELS[model]["label"], "family": MD.MODELS[model]["family"], "available": False})
            continue
        row = {"model": model, "label": MD.MODELS[model]["label"], "family": MD.MODELS[model]["family"], "available": True}
        for r in g.itertuples():
            row[r.metric] = {"value": _n(r.value), "lower": _n(r.lower), "upper": _n(r.upper)}
        daily.append(row)
    hourly = f[f["hour"].notna()].pivot_table(index="hour", columns="model", values="value").reset_index()
    act = {m: snap.actual(m, target) for m in ("arrivals", "departures", "movements")}
    ah = snap.hourly[snap.hourly["local_date"] == target]
    ah = dict(zip(ah["local_hour"], ah["arrivals"] + ah["departures"]))
    por = snap.plan_of_record(cutoff, target)
    sched = None
    if por is not None:
        s = snap.sched.get(int(por["id"]))
        if s is not None and target in s.index:
            sched = {"list": por["name"], "published": str(por["published_date"]), "arrivals": float(s.at[target, "arrivals"]),
                     "departures": float(s.at[target, "departures"])}
    # expected inferred cancellations (same rule as the backtest)
    cancel = None
    C = B._cancellations(snap, pd.DataFrame([{"target": target, "horizon": horizon}]))
    if len(C):
        cancel = {"expected": float(C.iloc[0]["pred"]), "rate14": float(C.iloc[0]["rate"]), "actual_inferred": _n(C.iloc[0]["actual"]), "kind": "predicted"}
    return _clean({
        "target": str(target), "horizon": horizon, "cutoff": str(cutoff), "weekday": target.strftime("%A"),
        "information": {"realised_through": str(cutoff - timedelta(days=1)), "lists_published_before": str(cutoff)},
        "scheduled": sched, "actual": {**act, "kind": "actual", "note": "hindsight — not known at the cutoff"},
        "models": daily,
        "hourly": [{"hour": int(r["hour"]), **{m: _n(r[m]) for m in MD.ORDER if m in r}, "actual": _n(ah.get(int(r["hour"])))}
                   for _, r in hourly.iterrows()],
        "expected_cancellations": cancel,
    })


@router.get("/api/v1/pretactical/evolution", dependencies=[view_pre])
def evolution(target: date):
    """How each model's daily movements forecast for one target changed from D-7 to D-0."""
    dsv = latest_dataset_version()
    ids = _model_ids()
    f = _q("select mv.name model, f.horizon_days k, f.value, f.lower, f.upper from forecast f join forecast_run r on r.id=f.run_id "
           "join model_version mv on mv.id=r.model_version_id where r.dataset_version_id=:d and f.target_local_date=:t "
           "and f.metric='movements' and f.target_local_hour is null and r.model_version_id in ("
           + ",".join(f"'{v}'" for v in ids.values()) + ")", d=dsv, t=target.isoformat())
    if f.empty:
        raise HTTPException(404, "no stored forecasts for this target")
    snap = _snap(dsv)
    rows = []
    for k in range(7, -1, -1):
        g = f[f["k"] == k]
        rows.append({"horizon": f"D-{k}", **{m: _n(v) for m, v in zip(g["model"], g["value"])}})
    return {"target": str(target), "actual": snap.actual("movements", target), "rows": rows}


@router.post("/api/v1/pretactical/backtest", status_code=202)
def start_backtest(user: CurrentUser = Depends(require("manage:models"))):
    def fn(progress):
        r = B.run(progress=progress)
        _snap.cache_clear()
        ov = [o for o in r["evaluation"]["overall"] if o["metric"] == "movements"]
        return _clean({"window": r["window"], "cutoffs": r["cutoffs"], "predictions": r["predictions"], "overall_movements": ov})
    try:
        jid = jobs.start("pretactical_backtest", {"by": user.username}, fn)
    except jobs.NotInBrowser as e:
        raise HTTPException(501, str(e))
    except RuntimeError as e:
        raise HTTPException(409, str(e))
    audit(user.username, "backtest_started", f"job:{jid}")
    return {"job_id": jid}


@router.get("/api/v1/jobs/{jid}")
def job(jid: int, user: CurrentUser = Depends(current_user)):
    if not ({"view:models", "view:pretactical"} & user.perms):
        raise HTTPException(403, "no access")
    j = jobs.get(jid)
    if j is None:
        raise HTTPException(404, "no such job")
    return j


# ----------------------------------------------------------------------------------- model management
@router.get("/api/v1/models", dependencies=[Depends(require("view:models"))])
def models():
    dsv = latest_dataset_version()
    mv = _q("select id, name, version, family, params_json, code_sha256, created_utc from model_version order by name, created_utc desc")
    ev = _q("select model_version_id, granularity, metric, horizon_days, n, mae, rmse, mape, wape, mase, bias, coverage from model_evaluation where dataset_version_id=:d", d=dsv)
    runs = _q("select model_version_id, count(*) n_runs, min(cutoff_utc) first_cutoff, max(cutoff_utc) last_cutoff, purpose from forecast_run "
              "where dataset_version_id=:d group by 1, 5", d=dsv)
    current = set(_model_ids().values())
    out = []
    for r in mv.itertuples():
        e = ev[(ev["model_version_id"] == r.id) & (ev["granularity"] == "day") & (ev["metric"] == "movements")]
        rr = runs[runs["model_version_id"] == r.id]
        out.append({"id": r.id, "name": r.name, "version": r.version, "family": r.family, "params": json.loads(r.params_json),
                    "code_sha256": r.code_sha256, "created_utc": str(r.created_utc),
                    "status": "current" if r.id in current or r.name == "fpred-calibrated" else "superseded",
                    "label": MD.MODELS.get(r.name, {}).get("label", "Original D-7 engine (fpred) — stored per-list forecasts"),
                    "runs": int(rr["n_runs"].sum()) if len(rr) else 0,
                    "purposes": sorted(set(rr["purpose"])) if len(rr) else [],
                    "mae_by_horizon": {int(x.horizon_days): _n(x.mae) for x in e.itertuples()},
                    "wape_by_horizon": {int(x.horizon_days): _n(x.wape) for x in e.itertuples()},
                    "mase_by_horizon": {int(x.horizon_days): _n(x.mase) for x in e.itertuples()},
                    "coverage_mean": _n(e["coverage"].mean()) if len(e) else None})
    return {"dataset_version": dsv, "models": out}


@router.get("/api/v1/models/{model_id}/evaluation", dependencies=[Depends(require("view:models"))])
def model_evaluation(model_id: str):
    ev = _q("select granularity, metric, horizon_days, n, mae, rmse, wape, mase, mape, bias, coverage, created_utc from model_evaluation "
            "where model_version_id=:m and dataset_version_id=:d order by granularity, metric, horizon_days", m=model_id, d=latest_dataset_version())
    if ev.empty:
        raise HTTPException(404, "no evaluation stored for this model version")
    ev["created_utc"] = ev["created_utc"].astype(str)
    return _clean(ev.to_dict("records"))
