"""Strategic Planning API (Phase 3)."""
from __future__ import annotations

import json
from datetime import date, datetime, timezone
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select

from ..auth.security import CurrentUser, audit, require
from ..db import models as M
from ..db.session import session_scope
from ..ingest.pipeline import latest_dataset_version
from ..strategic import analysis as A
from ..strategic import profiles as P
from ..strategic import scenarios as S

router = APIRouter(prefix="/api/v1/strategic", tags=["strategic planning"], dependencies=[Depends(require("view:strategic"))])


class BasisIn(BaseModel):
    kind: Literal["realised", "schedule", "calibrated"]
    list_name: str | None = Field(default=None, max_length=128)
    start: date | None = None
    end: date | None = None


class OverrideIn(BaseModel):
    weekdays: list[int] = Field(min_length=1, max_length=7)
    start_hour: int = Field(ge=0, le=23)
    hours: int = Field(ge=1, le=168)
    factor: float = Field(ge=0, le=2)
    label: str = Field(default="", max_length=120)


class ScenarioIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    preset: Literal["baseline", "low_demand", "high_demand", "traffic_growth", "capacity_reduction", "disruption", "custom"]
    basis: BasisIn
    demand_factor: float = Field(1.0, gt=0, le=3)
    growth_rate_pct: float = Field(0.0, ge=-50, le=50)
    growth_years: float = Field(0.0, ge=0, le=30)
    capacity_factor: float = Field(1.0, gt=0, le=2)
    overrides: list[OverrideIn] = Field(default_factory=list, max_length=20)
    description: str = Field(default="", max_length=500)

    def spec(self) -> S.ScenarioSpec:
        d = self.model_dump(mode="json")
        d["basis"] = {k: v for k, v in d["basis"].items() if v is not None}
        return S.ScenarioSpec.from_dict(d)


def _wrap(fn, *a, **k):
    try:
        return A._clean(fn(*a, **k))
    except (LookupError, ValueError) as e:
        raise HTTPException(400, str(e))


@router.get("/bases")
def bases():
    return P.bases()


@router.get("/overview")
def overview(basis: Literal["realised", "schedule", "calibrated"] = "schedule", list_name: str | None = "S22 23mar22",
             start: date | None = None, end: date | None = None):
    return _wrap(A.overview, basis, list_name if basis != "realised" else None, start, end)


@router.get("/trend")
def trend(start: date | None = None, end: date | None = None):
    return _wrap(A.trend_and_seasonality, start, end)


@router.get("/seasons")
def seasons():
    return _wrap(A.season_comparison)


@router.get("/capacity-evidence")
def capacity_evidence():
    return _wrap(A.capacity_evidence)


@router.get("/presets")
def presets():
    return {k: S.preset(k).to_dict() for k in S.PRESETS}


@router.post("/scenarios/run")
def run_scenario(body: ScenarioIn):
    """Preview a scenario without saving it."""
    return _wrap(S.run, body.spec())


@router.post("/scenarios", status_code=201)
def save_scenario(body: ScenarioIn, user: CurrentUser = Depends(require("manage:scenarios"))):
    res = _wrap(S.run, body.spec())
    res["dataset_version"] = latest_dataset_version()
    with session_scope() as s:
        row = M.SimulationScenario(name=body.name, base_local_date=None, assumptions_json=json.dumps(res["spec"]),
                                   result_json=json.dumps(res), created_by=user.username,
                                   created_utc=datetime.now(timezone.utc).replace(tzinfo=None))
        s.add(row)
        s.flush()
        sid = row.id
    audit(user.username, "scenario_saved", f"scenario:{sid}", name=body.name, preset=body.preset, fingerprint=res["fingerprint"])
    return {"id": sid, **res}


@router.get("/scenarios")
def list_scenarios():
    with session_scope() as s:
        rows = s.execute(select(M.SimulationScenario).order_by(M.SimulationScenario.id.desc())).scalars().all()
        out = []
        for r in rows:
            res = json.loads(r.result_json or "{}")
            if res.get("spec", {}).get("preset") is None:
                continue
            out.append({"id": r.id, "name": r.name, "preset": res["spec"]["preset"], "created_by": r.created_by,
                        "created_utc": str(r.created_utc), "basis": res.get("basis", {}).get("label"),
                        "fingerprint": res.get("fingerprint"), "dataset_version": res.get("dataset_version"),
                        "summary": res.get("summary")})
        return out


@router.get("/scenarios/{sid}")
def get_scenario(sid: int):
    with session_scope() as s:
        r = s.get(M.SimulationScenario, sid)
        if r is None:
            raise HTTPException(404, "no such scenario")
        return {"id": r.id, "name": r.name, "created_by": r.created_by, "created_utc": str(r.created_utc), **json.loads(r.result_json)}


@router.delete("/scenarios/{sid}")
def delete_scenario(sid: int, user: CurrentUser = Depends(require("manage:scenarios"))):
    with session_scope() as s:
        r = s.get(M.SimulationScenario, sid)
        if r is None:
            raise HTTPException(404, "no such scenario")
        name = r.name
        s.delete(r)
    audit(user.username, "scenario_deleted", f"scenario:{sid}", name=name)
    return {"ok": True}


@router.get("/compare")
def compare(ids: str = Query(..., pattern=r"^\d+(,\d+){0,7}$")):
    out = []
    for sid in [int(x) for x in ids.split(",")]:
        sc = get_scenario(sid)
        out.append({"id": sid, "name": sc["name"], "preset": sc["spec"]["preset"], "basis": sc["basis"]["label"],
                    "summary": sc["summary"], "hourly": [{"demand": h["demand"], "capacity": h["capacity"], "backlog": h["backlog"]}
                                                          for h in sc["hourly"]]})
    return out
