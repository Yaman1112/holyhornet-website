"""Auth and System Administration endpoints."""
from __future__ import annotations

import json

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import select, text

from ..auth import security as S
from ..db import models as M
from ..db.session import engine, session_scope

router = APIRouter(tags=["auth & administration"])


class Login(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


@router.post("/api/v1/auth/login")
def login(body: Login, request: Request, response: Response):
    ip = request.client.host if request.client else None
    if S.throttled(body.username, ip):
        S.audit(body.username, "login_throttled", ip=ip)
        raise HTTPException(429, "too many failed attempts; try again later")
    u = S.authenticate(body.username, body.password)
    if u is None:
        S.record_failure(body.username, ip)
        S.audit(body.username, "login_failed", ip=ip)
        raise HTTPException(401, "invalid username or password")
    token = S.issue_token(u)
    user = S.CurrentUser(u.username, u.role, u.display_name)
    S.clear_failures(body.username)
    response.set_cookie(S.COOKIE, token, httponly=True, samesite="lax", max_age=S.TOKEN_HOURS * 3600,
                        secure=S.cookie_secure(), path="/")
    S.audit(user.username, "login", ip=ip)
    return user.to_dict()


@router.post("/api/v1/auth/logout")
def logout(response: Response, user: S.CurrentUser = Depends(S.current_user)):
    response.delete_cookie(S.COOKIE, path="/", secure=S.cookie_secure(), httponly=True, samesite="lax")
    S.audit(user.username, "logout")
    return {"ok": True}


@router.post("/api/v1/auth/logout-everywhere")
def logout_everywhere(response: Response, user: S.CurrentUser = Depends(S.current_user)):
    """End every session of your own account, on every device (including this one)."""
    S.revoke_sessions(user.username)
    response.delete_cookie(S.COOKIE, path="/", secure=S.cookie_secure(), httponly=True, samesite="lax")
    S.audit(user.username, "sessions_revoked", user.username)
    return {"ok": True}


@router.get("/api/v1/auth/me")
def me(user: S.CurrentUser = Depends(S.current_user)):
    return user.to_dict()


@router.get("/api/v1/auth/roles")
def roles(user: S.CurrentUser = Depends(S.current_user)):
    return {k: {"label": v["label"], "modules": v["view"], "manage": v["manage"]} for k, v in S.ROLES.items()}


# --------------------------------------------------------------------------- administration
class NewUser(BaseModel):
    username: str = Field(pattern=r"^[a-z0-9._-]{3,64}$")
    display_name: str = Field(min_length=1, max_length=128)
    role: str
    password: str = Field(min_length=12, max_length=256)


class PatchUser(BaseModel):
    role: str | None = None
    active: bool | None = None
    password: str | None = Field(default=None, min_length=12, max_length=256)


@router.get("/api/v1/admin/users")
def list_users(user: S.CurrentUser = Depends(S.require("manage:users"))):
    with engine().connect() as c:
        df = pd.read_sql(text("select id, username, display_name, role, active, created_utc from app_user order by username"), c)
    df["created_utc"] = df["created_utc"].astype(str)
    df["active"] = df["active"].astype(bool)
    return df.astype(object).where(df.notna(), None).to_dict("records")


@router.post("/api/v1/admin/users", status_code=201)
def add_user(body: NewUser, user: S.CurrentUser = Depends(S.require("manage:users"))):
    try:
        S.create_user(body.username, body.password, body.role, body.display_name)
    except ValueError as e:
        raise HTTPException(400, str(e))
    S.audit(user.username, "user_created", body.username, role=body.role)
    return {"ok": True}


@router.patch("/api/v1/admin/users/{username}")
def patch_user(username: str, body: PatchUser, user: S.CurrentUser = Depends(S.require("manage:users"))):
    if body.role is not None and body.role not in S.ROLES:
        raise HTTPException(400, "unknown role")
    if username == user.username and (body.active is False or (body.role and body.role != "admin")):
        raise HTTPException(400, "administrators cannot disable or demote themselves")
    with session_scope() as s:
        u = s.execute(select(M.User).where(M.User.username == username)).scalar_one_or_none()
        if u is None:
            raise HTTPException(404, "no such user")
        changes = {}
        if body.role is not None:
            changes["role"] = [u.role, body.role]
            u.role = body.role
        if body.active is not None:
            changes["active"] = [u.active, body.active]
            u.active = body.active
        if body.password is not None:
            u.password_hash = S.hash_password(body.password)
            changes["password"] = "reset"
    S.audit(user.username, "user_updated", username, **changes)
    return {"ok": True}


@router.post("/api/v1/admin/users/{username}/revoke-sessions")
def admin_revoke_sessions(username: str, user: S.CurrentUser = Depends(S.require("manage:users"))):
    """End every session of another account (for example a lost device)."""
    if not S.revoke_sessions(username):
        raise HTTPException(404, "no such user")
    S.audit(user.username, "sessions_revoked", username)
    return {"ok": True}


@router.get("/api/v1/admin/audit")
def audit_log(limit: int = 200, user: S.CurrentUser = Depends(S.require("manage:users"))):
    with engine().connect() as c:
        df = pd.read_sql(text("select at_utc, actor, action, target, detail_json from audit_log order by id desc limit :n"),
                         c, params={"n": min(limit, 1000)})
    df["at_utc"] = df["at_utc"].astype(str)
    df["detail"] = df.pop("detail_json").map(lambda x: json.loads(x) if isinstance(x, str) else None)
    return df.astype(object).where(df.notna(), None).to_dict("records")
