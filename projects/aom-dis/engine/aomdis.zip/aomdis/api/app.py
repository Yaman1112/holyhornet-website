"""AOM-DIS API application.

Run:  .venv/Scripts/python -m uvicorn aomdis.api.app:app --port 8810
Interactive API docs: /api/docs (OpenAPI at /api/openapi.json).

Mounted legacy modules (unchanged, still independently runnable):
  /prediction/  the original D-7 prediction engine and dashboard (fpred)
  /prototype/   the earlier aops prototype (being migrated phase by phase)
"""
from __future__ import annotations

import logging
import os
import secrets
import time
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from starlette.responses import JSONResponse as _StarletteJSON

from .. import __version__
from ..auth.security import COOKIE, check_production_settings, is_production, require, user_from_token
from ..ingest.pipeline import latest_dataset_version
from . import auth, capacity, command, data, intel, postops, pretactical, strategic, tactical, twin

logging.basicConfig(level=os.environ.get("AOMDIS_LOG_LEVEL", "INFO").upper(),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("aomdis.api")

if is_production():
    _problems = check_production_settings()
    if _problems:
        raise RuntimeError("AOMDIS_ENV=production but the configuration is unsafe: " + "; ".join(_problems))

def _finite(x):
    """NaN / ±inf -> None, recursively (rule: an unavailable value is null, never a fake number)."""
    if isinstance(x, float):
        return x if x == x and x not in (float("inf"), float("-inf")) else None
    if isinstance(x, dict):
        return {k: _finite(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_finite(v) for v in x]
    return x


class SafeJSONResponse(_StarletteJSON):
    """Strict JSON, but a stray NaN/inf (e.g. from a pandas version that keeps NaN where another gives None)
    becomes null instead of a 500."""

    def render(self, content) -> bytes:
        try:
            return super().render(content)
        except ValueError:
            return super().render(_finite(content))


_DOCS = os.environ.get("AOMDIS_API_DOCS", "0" if is_production() else "1") == "1"
app = FastAPI(title="AOM-DIS — Airport Operations Management & Decision Intelligence System (EHAM)",
              version=__version__, docs_url="/api/docs" if _DOCS else None,
              openapi_url="/api/openapi.json" if _DOCS else None, redoc_url=None, default_response_class=SafeJSONResponse,
              description="Decision support only: not an air traffic control system. Data is historical (EHAM 2022).")

app.include_router(auth.router)
app.include_router(data.router, dependencies=[Depends(require("view:data"))])
app.include_router(command.router)
app.include_router(strategic.router)
app.include_router(pretactical.router)
app.include_router(tactical.router)
app.include_router(capacity.router)
app.include_router(twin.router)
app.include_router(postops.router)
app.include_router(intel.router)


@app.get("/api/v1/health", tags=["system"])
def health():
    return {"ok": True, "version": __version__, "dataset_version": latest_dataset_version(), "data_status": "historical"}


# Legacy apps have no auth of their own: guard them with the platform session.
_GUARD = {"/prediction": ("view:pretactical", "manage:data"), "/prototype": ("view:tactical", "manage:data")}
_SAFE = ("GET", "HEAD", "OPTIONS")


def _same_origin(request: Request) -> bool:
    """Defence in depth for the legacy UIs, which cannot send the CSRF header: a state-changing request
    must come from this origin (Origin, else Referer). SameSite=Lax already withholds the cookie cross-site."""
    src = request.headers.get("origin") or request.headers.get("referer")
    if not src:
        return False
    host = request.headers.get("x-forwarded-host") or request.headers.get("host", "")
    return urlsplit(src).netloc == host


@app.middleware("http")
async def guard_legacy(request: Request, call_next):
    for prefix, (read_perm, write_perm) in _GUARD.items():
        if request.url.path == prefix or request.url.path.startswith(prefix + "/"):
            user = user_from_token(request.cookies.get(COOKIE))   # active account, role from the database
            if user is None:
                if request.method == "GET" and "text/html" in request.headers.get("accept", ""):
                    return RedirectResponse("/login?next=" + request.url.path)
                return JSONResponse({"detail": "not authenticated"}, 401)
            need = read_perm if request.method in _SAFE else write_perm
            if need not in user.perms:
                return JSONResponse({"detail": f"role '{user.role}' lacks permission '{need}'"}, 403)
            if request.method not in _SAFE and not _same_origin(request):
                return JSONResponse({"detail": "cross-origin request refused"}, 403)
    return await call_next(request)


_API_CSP = "default-src 'none'; frame-ancestors 'none'"


@app.middleware("http")
async def security_headers_and_access_log(request: Request, call_next):
    """Request id, security headers and one structured access-log line per request.
    Unhandled errors are logged with the request id; the client only sees a generic 500."""
    rid = request.headers.get("x-request-id", "")[:64] or secrets.token_hex(8)
    t0 = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception:
        log.exception("unhandled error rid=%s %s %s", rid, request.method, request.url.path)
        response = JSONResponse({"detail": "internal error", "request_id": rid}, 500)
    h = response.headers
    h["X-Request-ID"] = rid
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("Referrer-Policy", "same-origin")
    h.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    path = request.url.path
    if path.startswith("/api/") and not path.startswith("/api/docs"):
        h.setdefault("Content-Security-Policy", _API_CSP)
        h.setdefault("Cache-Control", "no-store")
    if is_production():
        h.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    log.info("access rid=%s method=%s path=%s status=%s ms=%.0f", rid, request.method, path,
             response.status_code, (time.perf_counter() - t0) * 1000)
    return response


def _mount_legacy() -> None:
    from fpred.api import app as prediction_app
    from aops.api import app as prototype_app
    app.mount("/prediction", prediction_app)
    app.mount("/prototype", prototype_app)


from ..core.settings import browser_mode  # noqa: E402

if not browser_mode():   # the legacy apps serve static folders that the browser edition does not ship
    _mount_legacy()
