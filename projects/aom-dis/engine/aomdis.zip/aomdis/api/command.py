"""Command Center API: /api/v1/command/{executive|operations|capacity|predictive|historical|flights}."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query

from ..auth.security import require
from ..services import command as C

router = APIRouter(prefix="/api/v1/command", tags=["command center"], dependencies=[Depends(require("view:command"))])

MAX_DAYS = {"executive": 120, "operations": 120, "capacity": 120, "predictive": 120, "historical": 120, "flights": 31}


def _check(view: str, start: date, end: date, direction: str | None):
    if end < start:
        raise HTTPException(400, "end before start")
    if (end - start).days + 1 > MAX_DAYS[view]:
        raise HTTPException(400, f"{view}: range limited to {MAX_DAYS[view]} days")
    if direction not in (None, "ARR", "DEP"):
        raise HTTPException(400, "direction must be ARR or DEP")


def _view(name, fn):
    def handler(start: date, end: date, direction: str | None = Query(None, pattern="^(ARR|DEP)$")):
        _check(name, start, end, direction)
        try:
            return fn(start, end, direction)
        except LookupError as e:
            raise HTTPException(503, str(e))
    handler.__name__ = f"command_{name}"
    router.add_api_route(f"/{name}", handler, methods=["GET"], name=f"command_{name}")


for _name, _fn in (("executive", C.executive), ("operations", C.operations), ("capacity", C.capacity),
                   ("predictive", C.predictive), ("historical", C.historical)):
    _view(_name, _fn)


@router.get("/flights")
def flights(start: date, end: date, direction: str | None = Query(None, pattern="^(ARR|DEP)$"),
            state: str | None = Query(None, pattern="^(matched|added|canceled|confirmed_canceled)$"),
            q: str | None = Query(None, max_length=32), limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0)):
    _check("flights", start, end, direction)
    return C.flights(start, end, direction, state, q, limit, offset)
