"""Capacity Management API (Phase 6)."""
from __future__ import annotations

from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from ..auth.security import CurrentUser, audit, require
from ..capacity import analysis as A
from ..capacity import profile as PR
from ..strategic import analysis as SA

router = APIRouter(prefix="/api/v1/capacity", tags=["capacity management"], dependencies=[Depends(require("view:capacity"))])
manage = require("manage:capacity")


def _range(start: date, end: date, max_days: int = 92):
    if end < start:
        raise HTTPException(400, "end before start")
    if (end - start).days + 1 > max_days:
        raise HTTPException(400, f"range limited to {max_days} days")


def _err(fn, *a, **k):
    try:
        return fn(*a, **k)
    except LookupError as e:
        raise HTTPException(404, f"not found: {e}")
    except PermissionError as e:
        raise HTTPException(409, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/profiles")
def profiles():
    return PR.list_profiles()


@router.get("/profiles/{pid}")
def profile(pid: int):
    p = PR.get_profile(pid)
    if p is None:
        raise HTTPException(404, "no such profile")
    return p


class CopyIn(BaseModel):
    source_id: int
    name: str = Field(min_length=3, max_length=120)
    description: str | None = Field(default=None, max_length=1000)


@router.post("/profiles", status_code=201)
def copy_profile(body: CopyIn, user: CurrentUser = Depends(manage)):
    pid = _err(PR.copy_profile, body.source_id, body.name, user.username, body.description)
    audit(user.username, "capacity_profile_created", f"capacity_profile:{pid}", copied_from=body.source_id, name=body.name)
    return PR.get_profile(pid)


class RuleIn(BaseModel):
    flow: Literal["total", "arr", "dep"]
    weekdays: list[int] = Field(min_length=1, max_length=7)
    start_hour: int = Field(ge=0, le=23)
    end_hour: int = Field(ge=1, le=24)
    value: float = Field(ge=0, le=300)
    status: Literal["public-reference", "assumption", "derived"]
    source: str = Field(min_length=3, max_length=1000)
    label: str | None = Field(default=None, max_length=120)


@router.post("/profiles/{pid}/rules", status_code=201)
def add_rule(pid: int, body: RuleIn, user: CurrentUser = Depends(manage)):
    rid = _err(PR.add_rule, pid, body.model_dump())
    audit(user.username, "capacity_rule_added", f"capacity_profile:{pid}", rule_id=rid, **body.model_dump())
    return PR.get_profile(pid)


@router.delete("/profiles/{pid}/rules/{rid}")
def delete_rule(pid: int, rid: int, user: CurrentUser = Depends(manage)):
    snap = _err(PR.delete_rule, pid, rid)
    audit(user.username, "capacity_rule_deleted", f"capacity_profile:{pid}", rule_id=rid, **snap)
    return PR.get_profile(pid)


class RunwayIn(BaseModel):
    name: str = Field(min_length=3, max_length=60)
    n_arr: int = Field(ge=0, le=4)
    n_dep: int = Field(ge=0, le=4)
    arr_capacity: float = Field(ge=0, le=200)
    dep_capacity: float = Field(ge=0, le=200)
    status: Literal["public-reference", "assumption", "derived"]
    source: str = Field(min_length=3, max_length=1000)


@router.post("/profiles/{pid}/runway-configs", status_code=201)
def add_runway_config(pid: int, body: RunwayIn, user: CurrentUser = Depends(manage)):
    cid = _err(PR.upsert_runway_config, pid, body.model_dump())
    audit(user.username, "runway_config_added", f"capacity_profile:{pid}", config_id=cid, **body.model_dump())
    return PR.get_profile(pid)


@router.post("/profiles/{pid}/activate")
def activate(pid: int, user: CurrentUser = Depends(manage)):
    before = PR.active_id()
    _err(PR.activate, pid)
    audit(user.username, "capacity_profile_activated", f"capacity_profile:{pid}", previous=before)
    return {"active": pid, "previous": before,
            "note": "All modules (Command Center, Strategic, Tactical, Capacity) now use this profile."}


@router.get("/analysis")
def analysis(source: Literal["actual", "scheduled", "predicted"] = "actual", start: date = Query(...), end: date = Query(...)):
    _range(start, end)
    return _err(A.analyse, source, start, end)


@router.get("/runway-scenarios")
def runway_scenarios(source: Literal["actual", "scheduled", "predicted"] = "scheduled", start: date = Query(...), end: date = Query(...)):
    _range(start, end, 62)
    return _err(A.availability_scenarios, source, start, end)


@router.get("/evidence")
def evidence():
    return SA._clean(SA.capacity_evidence())


@router.get("/resources")
def resources():
    return A.other_resources()
