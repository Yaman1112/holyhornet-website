"""Tactical Operations API (Phase 5): replay state, flight timeline, alerts, events."""
from __future__ import annotations

from datetime import date, datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from ..auth.security import CurrentUser, audit, require
from ..core.timeutil import local_day_bounds_utc, local_to_utc
from ..forecasting import models as MD
from ..tactical import alerts as A
from ..tactical import events as EV
from ..tactical import flights as FL
from ..tactical import state as ST

router = APIRouter(tags=["tactical operations"])
view = Depends(require("view:tactical"))
HHMM = r"^([01]\d|2[0-3]):[0-5]\d$"


def _day(d: date) -> date:
    s = ST.snap()
    if not s.days[0] <= d <= s.days[-1]:
        raise HTTPException(404, f"no complete operational data for {d}; available {s.days[0]} … {s.days[-1]}")
    return d


@router.get("/api/v1/tactical/days", dependencies=[view])
def days():
    return ST.available_days()


@router.get("/api/v1/tactical/state", dependencies=[view])
def state(day: date, now: str = Query("12:00", pattern=HHMM), model: str = Query("ensemble")):
    if model not in MD.MODELS:
        raise HTTPException(400, f"unknown model {model}")
    d = _day(day)
    st = ST.hourly_state(d, now, model)
    T = FL.timeline(d, now)
    alerts = A.evaluate(d, now, model, state=st, timeline=T)
    counts = T["status"].value_counts().to_dict() if len(T) else {}
    return {
        "day": str(d), "weekday": d.strftime("%A"), "now": now, "model": model, "model_label": MD.MODELS[model]["label"],
        "data_status": "historical replay — only information known at the replay clock is shown",
        "plan_of_record": st["plan_of_record"],
        "kpis": {**st["kpis"], "flights": {k: int(v) for k, v in counts.items()}},
        "ratios": st["ratios"], "capacity_base": st["capacity_base"], "capacity_status": st["capacity_status"],
        "weather": {"kind": "unavailable", "note": "no authorised weather source connected"},
        "estimated_times": {"kind": "unavailable", "note": "the source data has no estimated (EOBT/ELDT) times"},
        "hourly": ST.frame_records(st["frame"]),
        "alerts": alerts,
        "events": ST.events_records(st["events"]),
        "rules": A.RULES,
    }


@router.get("/api/v1/tactical/alert-timeline", dependencies=[view])
def alert_timeline(day: date, model: str = "ensemble"):
    return {"day": str(_day(day)), "items": A.timeline_of_alerts(day, model)}


@router.get("/api/v1/tactical/flights", dependencies=[view])
def flights(day: date, now: str = Query("12:00", pattern=HHMM), direction: Literal["ARR", "DEP"] | None = None,
            status: Literal["flown", "expected", "overdue", "unscheduled"] | None = None, q: str | None = Query(None, max_length=24),
            limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0)):
    T = FL.timeline(_day(day), now)
    if len(T):
        if direction:
            T = T[T["direction"] == direction]
        if status:
            T = T[T["status"] == status]
        if q:
            qq = q.upper()
            T = T[T[["flight", "callsign", "other", "operator", "type"]].fillna("").astype(str).apply(lambda c: c.str.upper().str.contains(qq, regex=False)).any(axis=1)]
    return {"total": int(len(T)), "rows": FL.records(T.iloc[offset:offset + limit]) if len(T) else []}


# ----------------------------------------------------------------------------------- events
class EventIn(BaseModel):
    category: Literal["weather_disruption", "runway_restriction", "reduced_capacity", "movement_disruption", "demand_surge", "system_failure"]
    title: str = Field(min_length=3, max_length=200)
    day: date
    start_local: str = Field(pattern=HHMM)
    end_local: str | None = Field(default=None, pattern=r"^(([01]\d|2[0-3]):[0-5]\d|24:00)$")
    severity: Literal["low", "medium", "high", "critical"]
    impact: str | None = Field(default=None, max_length=2000)
    capacity_factor: float | None = Field(default=None, ge=0, le=1.5)
    status: Literal["draft", "active", "closed", "cancelled"] = "active"
    kind: Literal["actual", "simulated"] = "simulated"
    source: str = Field(default="user", max_length=64)

    def to_record(self) -> dict:
        start = local_to_utc(self.day, self.start_local).to_pydatetime()
        end = None
        if self.end_local:
            end = (local_day_bounds_utc(self.day)[1] if self.end_local == "24:00" else local_to_utc(self.day, self.end_local)).to_pydatetime()
        return {"category": self.category, "title": self.title, "start_utc": start, "end_utc": end, "severity": self.severity,
                "impact": self.impact, "capacity_factor": self.capacity_factor, "status": self.status, "kind": self.kind, "source": self.source}


class EventPatch(BaseModel):
    title: str | None = Field(default=None, min_length=3, max_length=200)
    severity: Literal["low", "medium", "high", "critical"] | None = None
    impact: str | None = Field(default=None, max_length=2000)
    capacity_factor: float | None = Field(default=None, ge=0, le=1.5)
    status: Literal["draft", "active", "closed", "cancelled"] | None = None
    end_utc: datetime | None = None


@router.get("/api/v1/events", dependencies=[view])
def list_events(start: date, end: date):
    a = local_day_bounds_utc(start)[0]
    b = local_day_bounds_utc(end)[1]
    return EV.list_between(a, b)


@router.get("/api/v1/events/categories", dependencies=[view])
def categories():
    return {"categories": EV.CATEGORIES, "severities": EV.SEVERITIES, "statuses": EV.STATUSES, "kinds": EV.KINDS,
            "transitions": {k: sorted(v) for k, v in EV.TRANSITIONS.items()}}


@router.get("/api/v1/events/{eid}", dependencies=[view])
def get_event(eid: str):
    e = EV.get(eid)
    if e is None:
        raise HTTPException(404, "no such event")
    return e


@router.post("/api/v1/events", status_code=201)
def create_event(body: EventIn, user: CurrentUser = Depends(require("manage:events"))):
    try:
        eid = EV.create(body.to_record(), user.username)
    except ValueError as e:
        raise HTTPException(400, str(e))
    audit(user.username, "event_created", eid, category=body.category, kind=body.kind)
    return EV.get(eid)


@router.patch("/api/v1/events/{eid}")
def patch_event(eid: str, body: EventPatch, user: CurrentUser = Depends(require("manage:events"))):
    patch = {k: v for k, v in body.model_dump(exclude_unset=True).items()}
    try:
        diff = EV.update(eid, patch, user.username)
    except LookupError:
        raise HTTPException(404, "no such event")
    except ValueError as e:
        raise HTTPException(400, str(e))
    if diff:
        audit(user.username, "event_updated", eid, **{k: v[1] for k, v in diff.items()})
    return EV.get(eid)
