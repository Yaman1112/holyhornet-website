"""System Health and KPI definitions (assurance & monitoring layer).

GET /api/v1/system/status          application, database, data freshness, validation, model registry
                                   consistency and accuracy, jobs, capacity profile, feature availability
GET /api/v1/system/kpis            KPI definitions (formula, unit, provenance, caveats) — aomdis.core.kpis
GET /api/v1/system/kpis/evaluate   the core KPIs evaluated for a date range, each with its definition id
"""
from __future__ import annotations

import json
import platform
import time
from datetime import date, datetime, timezone
from functools import lru_cache

import numpy as np
import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text

from .. import __version__
from ..auth.security import current_user, require
from ..capacity import analysis as CA
from ..capacity import profile as PR
from ..core import kpis as K
from ..core.settings import ROOT, browser_mode, settings
from ..db.session import engine
from ..forecasting import models as MD
from ..ingest import validation
from ..ingest.pipeline import latest_dataset_version
from ..services import demand

router = APIRouter(prefix="/api/v1/system", tags=["system health"])
STARTED = time.time()
TABLES = ["movement", "schedule_entry", "movement_match", "forecast", "forecast_run", "model_evaluation", "performance_metric",
          "simulation_scenario", "operational_event", "capacity_profile", "app_user", "audit_log", "job"]


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


@lru_cache(maxsize=4)
def _validation(dsv: str) -> dict:
    return validation.run(dsv)


def _alembic() -> dict:
    cur = _q("select version_num from alembic_version")["version_num"].tolist()
    head = None
    try:
        from alembic.config import Config
        from alembic.script import ScriptDirectory
        cfg = Config(str(ROOT / "alembic.ini"))
        cfg.set_main_option("script_location", str(ROOT / "migrations"))
        head = ScriptDirectory.from_config(cfg).get_current_head()
    except Exception:  # noqa: BLE001 — the browser edition ships no migration scripts
        head = None
    return {"current": cur[0] if cur else None, "head": head,
            "status": "unknown (migration scripts not shipped)" if head is None else "up to date" if cur and cur[0] == head else "behind"}


def _models(dsv: str) -> dict:
    current = {name: MD.model_version_id(name) for name in MD.MODELS}
    stored = set(_q("select distinct r.model_version_id m from forecast_run r where r.dataset_version_id=:d and r.purpose='backtest'", d=dsv)["m"])
    consistency = [{"model": n, "current_version": mid, "backtest_stored": mid in stored} for n, mid in current.items()]
    ev = _q("select v.name, e.horizon_days h, e.n, e.mae, e.wape, e.mase, e.bias, e.coverage from model_evaluation e "
            "join model_version v on v.id=e.model_version_id where e.dataset_version_id=:d and e.granularity='day' and e.metric='movements'", d=dsv)
    best = []
    for h, g in ev.groupby("h"):
        g = g.sort_values("mae")
        best.append({"horizon": int(h), "model": g.iloc[0]["name"], "mae": float(g.iloc[0]["mae"]),
                     "wape": None if pd.isna(g.iloc[0]["wape"]) else float(g.iloc[0]["wape"])})
    stale = [c["model"] for c in consistency if not c["backtest_stored"]]
    return {"registry_consistent": not stale,
            "status": "consistent" if not stale else f"stale: {', '.join(stale)} changed since the stored backtest — re-run `python -m aomdis backtest`",
            "models": consistency, "best_by_horizon": best,
            "wape_available": bool(len(ev)) and bool(ev["wape"].notna().any()),
            "evaluation": ev.astype(object).where(ev.notna(), None).to_dict("records")}


@router.get("/status", dependencies=[Depends(require("view:system"))])
def status():
    import numpy
    import pandas
    dsv = latest_dataset_version()
    if dsv is None:
        raise HTTPException(404, "no dataset ingested")
    counts = {t: int(_q(f"select count(*) n from {t}")["n"].iloc[0]) for t in TABLES}
    ver = _q("select * from dataset_version where id=:d", d=dsv).iloc[0]
    span = _q("select min(local_date) a, max(local_date) b, max(actual_utc) last_utc from movement where dataset_version_id=:d", d=dsv).iloc[0]
    last = pd.Timestamp(span["last_utc"])
    age = (datetime.now(timezone.utc).replace(tzinfo=None) - last.to_pydatetime()).days
    jobs = _q("select id, kind, status, progress, created_utc, finished_utc, substr(coalesce(error, ''), 1, 160) error from job order by id desc limit 8")
    pid = PR.active_id()
    prof = PR.get_profile(pid)
    val = _validation(dsv)
    browser = browser_mode()
    return {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "application": {"version": __version__, "edition": "browser (Pyodide)" if browser else "server",
                        "python": platform.python_version(), "numpy": numpy.__version__, "pandas": pandas.__version__,
                        "uptime_s": round(time.time() - STARTED)},
        "database": {"dialect": engine().dialect.name, "migrations": _alembic(), "rows": counts},
        "data": {"dataset_version": dsv, "created_utc": str(ver.get("created_utc")), "movement_days": [str(span["a"]), str(span["b"])],
                 "latest_movement_utc": str(last), "age_days": age,
                 "freshness": "historical — this is a fixed 2022 dataset, not a live feed",
                 "validation": {"ok": val["ok"], "summary": val["summary"], "checked_utc": val["checked_utc"]}},
        "models": _models(dsv),
        "jobs": {"recent": jobs.astype(object).where(jobs.notna(), None).to_dict("records"),
                 "running": int((jobs["status"] == "running").sum()) if len(jobs) else 0},
        "capacity": {"active_profile": {"id": pid, "name": prof["name"], "digest": PR._stamp(pid)},
                     "statuses": sorted({r["status"] for r in prof["rules"]}),
                     "note": "all values with status 'assumption' are modelled, not declared capacity"},
        "features": [
            {"feature": "Analytics, forecasts (stored), replay, capacity, twin, post-ops, intelligence", "available": True},
            {"feature": "Background jobs: backtest re-run, post-ops store rebuild", "available": not browser,
             "note": "server edition only (needs threads)" if browser else None},
            {"feature": "Original D-7 tool (/prediction) and prototype (/prototype)", "available": not browser,
             "note": "server edition only" if browser else None},
            {"feature": "Live data feeds", "available": False, "note": "not connected: historical dataset only"},
        ],
    }


@router.get("/kpis", dependencies=[Depends(current_user)])
def kpi_definitions():
    return {"notation": K.__doc__.split("Notation:")[1].strip() if "Notation:" in (K.__doc__ or "") else "", "kpis": K.KPIS}


@router.get("/kpis/evaluate", dependencies=[Depends(require("view:command"))])
def kpi_evaluate(start: date = Query(...), end: date = Query(...)):
    """Core KPIs over a local date range (complete days only), each tagged with its definition id."""
    if (end - start).days > 120 or end < start:
        raise HTTPException(400, "range must be 0–120 days")
    F = demand.build(start, end)
    D = F.daily[F.daily["actual_complete"]]
    H = F.hourly[F.hourly["actual_complete"]]
    if D.empty:
        raise HTTPException(404, "no complete day with actual data in this range")
    mov = D["actual_mov"].astype(float)
    peak = H.loc[H["actual_mov"].idxmax()]
    can = D[D["canceled"].notna() & D["scheduled_mov"].notna()]
    obs = CA.observed_throughput(start, end)

    def k(kpi_id, value, **extra):
        d = K.get(kpi_id)
        return {"id": kpi_id, "name": d["name"], "value": value, "unit": d["unit"], "kind": d["kind"], "formula": d["formula"], **extra}

    return {"range": [str(start), str(end)], "complete_days": int(len(D)), "kpis": [
        k("movements", int(mov.sum())),
        k("arrivals", int(D["actual_arr"].sum())),
        k("departures", int(D["actual_dep"].sum())),
        k("daily_movements", round(float(mov.mean()), 1), detail="mean over complete days"),
        k("peak_hour", int(peak["actual_mov"]), at=f"{peak['local_date']} {int(peak['local_hour']):02d}:00"),
        k("demand_cv", round(float(mov.std(ddof=1) / mov.mean()), 4) if len(mov) > 1 else None),
        k("cancel_rate", round(float(can["canceled"].sum() / can["scheduled_mov"].sum()), 4) if len(can) and can["scheduled_mov"].sum() else None),
        k("pressure_hours", int(((H["actual_util"] >= 0.9) | (H["scheduled_util"] >= 0.9)).sum())),
        k("observed_throughput", obs["total"]["p95"] if obs.get("total") else None, max=obs["total"]["max"] if obs.get("total") else None),
    ]}
