"""AI Intelligence API (Phase 9). Deterministic, traceable insights — no external AI service."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse

from ..auth.security import CurrentUser, audit, require
from ..intel import anomalies as AN
from ..intel import briefing as BR
from ..intel import peaks as PK

router = APIRouter(prefix="/api/v1/intel", tags=["ai intelligence"], dependencies=[Depends(require("view:intel"))])


def _wrap(fn, *a):
    try:
        return BR._json_safe(fn(*a))
    except LookupError as e:
        raise HTTPException(404, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/briefing")
def briefing(start: date = Query(...), end: date = Query(...)):
    if end < start:
        raise HTTPException(400, "end before start")
    return _wrap(BR.briefing, start, end)


@router.get("/briefing.md", response_class=PlainTextResponse)
def briefing_md(start: date = Query(...), end: date = Query(...), user: CurrentUser = Depends(require("view:intel"))):
    b = _wrap(BR.briefing, start, end)
    audit(user.username, "intel_briefing_exported", f"{start}..{end}")
    return PlainTextResponse(BR.markdown(b), headers={"Content-Disposition": f'attachment; filename="aomdis_briefing_{start}_{end}.md"'})


@router.get("/anomalies")
def anomalies(start: date | None = None, end: date | None = None):
    d = _wrap(AN.daily, start, end)
    if start and end:
        d["hourly"] = _wrap(AN.hourly, start, end)
    d["operator_shifts"] = _wrap(AN.operator_shifts)
    return d


@router.get("/peaks")
def peaks(horizon: int = Query(1, ge=0, le=7), day: date | None = None):
    out = {"evaluation": _wrap(PK.evaluate, horizon)}
    if day:
        out["prediction"] = _wrap(PK.predict, day, horizon)
    return out


@router.get("/explain")
def explain(day: date, layer: str = Query("fc_d1_ensemble", pattern="^(fc_d7_fpred|fc_d7_ensemble|fc_d1_ensemble|fc_d0_ensemble|nowcast_12|plan_mov)$")):
    return _wrap(BR.explain, day, layer)


@router.get("/investigate")
def investigate(start: date = Query(...), end: date = Query(...)):
    return _wrap(BR.investigate, start, end)
