"""Post-Operations API (Phase 8)."""
from __future__ import annotations

from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response

from ..auth.security import CurrentUser, audit, require
from ..postops import metrics as PM
from ..postops import reports as R
from ..services import jobs

router = APIRouter(prefix="/api/v1/postops", tags=["post-operations"], dependencies=[Depends(require("view:postops"))])


def _wrap(fn, *a):
    try:
        return fn(*a)
    except LookupError as e:
        raise HTTPException(404, str(e))
    except ValueError as e:
        raise HTTPException(400, str(e))


def _range(start: date, end: date):
    if end < start:
        raise HTTPException(400, "end before start")


@router.get("/coverage")
def coverage():
    return PM.coverage()


@router.post("/generate", status_code=202)
def generate(user: CurrentUser = Depends(require("manage:data"))):
    """(Re)compute the daily performance store for every complete day (background job)."""
    def fn(progress):
        D = PM.compute(progress=progress)
        return {"days": int(D["period_start"].nunique()), "rows": int(len(D))}
    try:
        jid = jobs.start("postops_metrics", {"by": user.username}, fn)
    except jobs.NotInBrowser as e:
        raise HTTPException(501, str(e))
    except RuntimeError as e:
        raise HTTPException(409, str(e))
    audit(user.username, "postops_metrics_started", f"job:{jid}")
    return {"job_id": jid}


@router.get("/summaries")
def summaries(period: Literal["day", "week", "month", "season"] = "week", start: date = Query(...), end: date = Query(...)):
    _range(start, end)
    return _wrap(R.summaries, period, start, end)


@router.get("/accuracy")
def accuracy(start: date = Query(...), end: date = Query(...)):
    _range(start, end)
    return _wrap(R.accuracy, start, end)


@router.get("/deviations")
def deviations(by: Literal["operator", "country", "hour", "direction"] = "operator", start: date = Query(...), end: date = Query(...),
               top: int = Query(25, ge=1, le=200)):
    _range(start, end)
    if (end - start).days > 120:
        raise HTTPException(400, "range limited to 120 days")
    return _wrap(R.deviations, start, end, by, top)


@router.get("/root-cause")
def root_cause(day: date):
    return _wrap(R.root_cause, day)


@router.get("/patterns")
def patterns(start: date = Query(...), end: date = Query(...)):
    _range(start, end)
    return _wrap(R.patterns, start, end)


@router.get("/recommendations")
def recommendations(start: date = Query(...), end: date = Query(...)):
    _range(start, end)
    return {"range": [str(start), str(end)], "items": _wrap(R.recommendations, start, end),
            "note": "Recommendations are analytical suggestions with evidence and confidence; they are not operational decisions."}


@router.get("/export.xlsx")
def export(start: date = Query(...), end: date = Query(...), user: CurrentUser = Depends(require("view:postops"))):
    _range(start, end)
    data = _wrap(R.export_xlsx, start, end)
    audit(user.username, "postops_report_exported", f"{start}..{end}")
    return Response(data, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="aomdis_postops_{start}_{end}.xlsx"'})
