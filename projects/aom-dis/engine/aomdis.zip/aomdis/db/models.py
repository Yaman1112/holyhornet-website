"""Normalized operational data model (SQLAlchemy 2, Postgres/SQLite compatible).

Time columns: ``*_utc`` are naive UTC; ``local_date`` / ``local_hour`` are Europe/Amsterdam.
Every fact table points at the ``dataset_version`` (and through it the ``data_source`` files)
it was loaded from, so any number can be traced back to raw-file checksums.
"""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (JSON, Boolean, Date, DateTime, Float, ForeignKey, Index, Integer, String, Text,
                        UniqueConstraint)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


# --------------------------------------------------------------------------- provenance
class DatasetVersion(Base):
    """One ingestion of the full set of raw files. id = hash of all file checksums + config."""
    __tablename__ = "dataset_version"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    created_utc: Mapped[datetime] = mapped_column(DateTime)
    config_sha256: Mapped[str] = mapped_column(String(64))
    code_version: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16))  # loading | complete | failed
    notes: Mapped[str | None] = mapped_column(Text)
    sources: Mapped[list["DataSource"]] = relationship(back_populates="dataset_version")


class DataSource(Base):
    __tablename__ = "data_source"
    id: Mapped[int] = mapped_column(primary_key=True)
    dataset_version_id: Mapped[str] = mapped_column(ForeignKey("dataset_version.id"))
    file_name: Mapped[str] = mapped_column(String(256))
    kind: Mapped[str] = mapped_column(String(32))  # realisation | schedule_list | cdm | airline_map | reference
    sha256: Mapped[str] = mapped_column(String(64))
    bytes: Mapped[int] = mapped_column(Integer)
    rows_raw: Mapped[int] = mapped_column(Integer)
    rows_loaded: Mapped[int] = mapped_column(Integer)
    timezone_assumed: Mapped[str] = mapped_column(String(64))
    description: Mapped[str | None] = mapped_column(Text)
    dataset_version: Mapped[DatasetVersion] = relationship(back_populates="sources")


class DataQualityIssue(Base):
    __tablename__ = "data_quality_issue"
    id: Mapped[int] = mapped_column(primary_key=True)
    dataset_version_id: Mapped[str] = mapped_column(ForeignKey("dataset_version.id"))
    data_source_id: Mapped[int | None] = mapped_column(ForeignKey("data_source.id"))
    check_name: Mapped[str] = mapped_column(String(64))
    severity: Mapped[str] = mapped_column(String(8))  # info | warn | error
    affected_rows: Mapped[int] = mapped_column(Integer)
    message: Mapped[str] = mapped_column(Text)
    handling: Mapped[str] = mapped_column(Text)


# --------------------------------------------------------------------------- reference
class Airport(Base):
    __tablename__ = "airport"
    icao: Mapped[str] = mapped_column(String(4), primary_key=True)
    iata: Mapped[str | None] = mapped_column(String(3))
    name: Mapped[str | None] = mapped_column(String(128))
    timezone: Mapped[str | None] = mapped_column(String(64))
    country_prefix: Mapped[str] = mapped_column(String(2))
    schengen_2022: Mapped[bool | None] = mapped_column(Boolean)


class Runway(Base):
    __tablename__ = "runway"
    id: Mapped[str] = mapped_column(String(16), primary_key=True)
    airport_icao: Mapped[str] = mapped_column(ForeignKey("airport.icao"))
    name: Mapped[str | None] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(24))
    source: Mapped[str] = mapped_column(Text)


class Operator(Base):
    """Aircraft operator (ICAO 3-letter) with optional IATA code."""
    __tablename__ = "operator"
    icao: Mapped[str] = mapped_column(String(3), primary_key=True)
    iata: Mapped[str | None] = mapped_column(String(2))
    name: Mapped[str | None] = mapped_column(String(128))
    source: Mapped[str] = mapped_column(String(32))  # handmade | openflights | observed


class AircraftType(Base):
    __tablename__ = "aircraft_type"
    icao: Mapped[str] = mapped_column(String(8), primary_key=True)
    code_letter: Mapped[str] = mapped_column(String(1))
    wake: Mapped[str] = mapped_column(String(1))
    classification_source: Mapped[str] = mapped_column(String(32))  # table | default


class CallsignMap(Base):
    """IATA flight number -> callsign observed in the A-CDM extract."""
    __tablename__ = "callsign_map"
    id: Mapped[int] = mapped_column(primary_key=True)
    flight_key: Mapped[str] = mapped_column(String(16), index=True)
    callsign: Mapped[str] = mapped_column(String(16))
    occurrences: Mapped[int] = mapped_column(Integer)
    dataset_version_id: Mapped[str] = mapped_column(ForeignKey("dataset_version.id"))


# --------------------------------------------------------------------------- operations
class Movement(Base):
    """Realised aircraft movement at EHAM (actual runway time)."""
    __tablename__ = "movement"
    id: Mapped[int] = mapped_column(primary_key=True)
    source_flight_id: Mapped[int] = mapped_column(Integer, index=True)
    callsign: Mapped[str] = mapped_column(String(16), index=True)
    operator_icao: Mapped[str | None] = mapped_column(String(3), index=True)
    aircraft_type: Mapped[str | None] = mapped_column(String(8))
    direction: Mapped[str] = mapped_column(String(3))  # ARR | DEP
    adep: Mapped[str] = mapped_column(String(4))
    dest: Mapped[str] = mapped_column(String(4))
    other_airport: Mapped[str] = mapped_column(String(4))
    actual_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    local_date: Mapped[date] = mapped_column(Date, index=True)
    local_hour: Mapped[int] = mapped_column(Integer)
    utc_offset_min: Mapped[int] = mapped_column(Integer)
    source_time_raw: Mapped[str] = mapped_column(String(32))
    data_source_id: Mapped[int] = mapped_column(ForeignKey("data_source.id"))
    dataset_version_id: Mapped[str] = mapped_column(ForeignKey("dataset_version.id"), index=True)


class ScheduleList(Base):
    """A published traffic forecast list (e.g. 'S22 23mar22')."""
    __tablename__ = "schedule_list"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(32))
    season: Mapped[str] = mapped_column(String(4))
    published_date: Mapped[date] = mapped_column(Date)
    coverage_start_local: Mapped[date] = mapped_column(Date)
    coverage_end_local: Mapped[date] = mapped_column(Date)
    data_source_id: Mapped[int] = mapped_column(ForeignKey("data_source.id"))
    dataset_version_id: Mapped[str] = mapped_column(ForeignKey("dataset_version.id"), index=True)
    __table_args__ = (UniqueConstraint("dataset_version_id", "name"),)


class ScheduleEntry(Base):
    """One planned EHAM movement in a schedule list (sector rows collapsed)."""
    __tablename__ = "schedule_entry"
    id: Mapped[int] = mapped_column(primary_key=True)
    schedule_list_id: Mapped[int] = mapped_column(ForeignKey("schedule_list.id"), index=True)
    flight_id: Mapped[str] = mapped_column(String(16), index=True)
    id_kind: Mapped[str] = mapped_column(String(8))  # iata | icao | other
    operator_icao: Mapped[str | None] = mapped_column(String(3))
    aircraft_type: Mapped[str | None] = mapped_column(String(8))
    direction: Mapped[str] = mapped_column(String(3))
    adep: Mapped[str] = mapped_column(String(4))
    dest: Mapped[str] = mapped_column(String(4))
    other_airport: Mapped[str] = mapped_column(String(4))
    planned_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    planned_reference: Mapped[str] = mapped_column(String(16))  # SOBT | ETO_EHFIRAM
    local_date: Mapped[date] = mapped_column(Date, index=True)
    local_hour: Mapped[int] = mapped_column(Integer)
    utc_offset_min: Mapped[int] = mapped_column(Integer)
    sector_rows: Mapped[int] = mapped_column(Integer)
    source_time_raw: Mapped[str] = mapped_column(String(32))


class MovementMatch(Base):
    """fpred matching outcome per schedule list: links planned and actual, or marks inferred states."""
    __tablename__ = "movement_match"
    id: Mapped[int] = mapped_column(primary_key=True)
    schedule_list_id: Mapped[int] = mapped_column(ForeignKey("schedule_list.id"), index=True)
    schedule_entry_id: Mapped[int | None] = mapped_column(ForeignKey("schedule_entry.id"), index=True)
    movement_id: Mapped[int | None] = mapped_column(ForeignKey("movement.id"), index=True)
    state: Mapped[str] = mapped_column(String(24))  # matched | canceled | confirmed_canceled | added
    stage: Mapped[str | None] = mapped_column(String(16))
    offset_min: Mapped[float | None] = mapped_column(Float)
    local_date: Mapped[date] = mapped_column(Date, index=True)
    local_hour: Mapped[int] = mapped_column(Integer)
    direction: Mapped[str] = mapped_column(String(3))
    engine: Mapped[str] = mapped_column(String(32))  # e.g. fpred-1.0.0
    __table_args__ = (Index("ix_match_list_date", "schedule_list_id", "local_date"), Index("ix_match_date_state", "local_date", "state"))


# --------------------------------------------------------------------------- capacity & events
class CapacityParameter(Base):
    __tablename__ = "capacity_parameter"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(64), index=True)
    value_json: Mapped[str] = mapped_column(Text)
    unit: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(24))
    source: Mapped[str] = mapped_column(Text)
    valid_from_utc: Mapped[datetime | None] = mapped_column(DateTime)
    valid_to_utc: Mapped[datetime | None] = mapped_column(DateTime)
    config_sha256: Mapped[str] = mapped_column(String(64))


class OperationalEvent(Base):
    __tablename__ = "operational_event"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)  # e.g. EVT-20220218-0001
    category: Mapped[str] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(200))
    start_utc: Mapped[datetime] = mapped_column(DateTime)
    end_utc: Mapped[datetime | None] = mapped_column(DateTime)
    severity: Mapped[str] = mapped_column(String(16))
    impact: Mapped[str | None] = mapped_column(Text)
    capacity_factor: Mapped[float | None] = mapped_column(Float)  # e.g. 0.7 = 30 % capacity reduction
    status: Mapped[str] = mapped_column(String(16))  # draft | active | closed | cancelled
    source: Mapped[str] = mapped_column(String(64))  # user | alert-engine | ...
    kind: Mapped[str] = mapped_column(String(16))  # actual (recorded) | simulated
    created_by: Mapped[str] = mapped_column(String(64))
    created_utc: Mapped[datetime] = mapped_column(DateTime)


class EventAudit(Base):
    __tablename__ = "event_audit"
    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[str] = mapped_column(ForeignKey("operational_event.id"), index=True)
    at_utc: Mapped[datetime] = mapped_column(DateTime)
    actor: Mapped[str] = mapped_column(String(64))
    action: Mapped[str] = mapped_column(String(32))
    changes_json: Mapped[str] = mapped_column(Text)


class WeatherObservation(Base):
    """Empty until an authorised weather source is connected (never fabricated)."""
    __tablename__ = "weather_observation"
    id: Mapped[int] = mapped_column(primary_key=True)
    station: Mapped[str] = mapped_column(String(8))
    observed_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    raw_report: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(64))


# --------------------------------------------------------------------------- models & forecasts
class ModelVersion(Base):
    __tablename__ = "model_version"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)  # name@version#hash
    name: Mapped[str] = mapped_column(String(64))
    version: Mapped[str] = mapped_column(String(32))
    family: Mapped[str] = mapped_column(String(32))
    params_json: Mapped[str] = mapped_column(Text)
    code_sha256: Mapped[str] = mapped_column(String(64))
    created_utc: Mapped[datetime] = mapped_column(DateTime)


class ForecastRun(Base):
    __tablename__ = "forecast_run"
    id: Mapped[int] = mapped_column(primary_key=True)
    model_version_id: Mapped[str] = mapped_column(ForeignKey("model_version.id"))
    dataset_version_id: Mapped[str] = mapped_column(ForeignKey("dataset_version.id"))
    cutoff_utc: Mapped[datetime] = mapped_column(DateTime)
    created_utc: Mapped[datetime] = mapped_column(DateTime)
    purpose: Mapped[str] = mapped_column(String(16))  # backtest | operational
    schedule_list_id: Mapped[int | None] = mapped_column(ForeignKey("schedule_list.id"), index=True)


class Forecast(Base):
    __tablename__ = "forecast"
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("forecast_run.id"), index=True)
    target_local_date: Mapped[date] = mapped_column(Date, index=True)
    target_local_hour: Mapped[int | None] = mapped_column(Integer)  # None = whole day
    horizon_days: Mapped[int] = mapped_column(Integer)
    metric: Mapped[str] = mapped_column(String(16))  # arrivals | departures | movements
    value: Mapped[float] = mapped_column(Float)
    lower: Mapped[float | None] = mapped_column(Float)
    upper: Mapped[float | None] = mapped_column(Float)
    interval_level: Mapped[float | None] = mapped_column(Float)


class ModelEvaluation(Base):
    __tablename__ = "model_evaluation"
    id: Mapped[int] = mapped_column(primary_key=True)
    model_version_id: Mapped[str] = mapped_column(ForeignKey("model_version.id"))
    dataset_version_id: Mapped[str] = mapped_column(ForeignKey("dataset_version.id"))
    horizon_days: Mapped[int] = mapped_column(Integer)
    granularity: Mapped[str] = mapped_column(String(8))
    metric: Mapped[str] = mapped_column(String(16))
    n: Mapped[int] = mapped_column(Integer)
    mae: Mapped[float] = mapped_column(Float)
    rmse: Mapped[float] = mapped_column(Float)
    mape: Mapped[float | None] = mapped_column(Float)
    bias: Mapped[float] = mapped_column(Float)
    coverage: Mapped[float | None] = mapped_column(Float)
    created_utc: Mapped[datetime] = mapped_column(DateTime)


class SimulationScenario(Base):
    __tablename__ = "simulation_scenario"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    base_local_date: Mapped[date | None] = mapped_column(Date)
    assumptions_json: Mapped[str] = mapped_column(Text)
    result_json: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[str] = mapped_column(String(64))
    created_utc: Mapped[datetime] = mapped_column(DateTime)


class PerformanceMetric(Base):
    __tablename__ = "performance_metric"
    id: Mapped[int] = mapped_column(primary_key=True)
    period: Mapped[str] = mapped_column(String(8))  # day | week | month | season
    period_start: Mapped[date] = mapped_column(Date, index=True)
    metric: Mapped[str] = mapped_column(String(48))
    value: Mapped[float | None] = mapped_column(Float)
    kind: Mapped[str] = mapped_column(String(16))
    dataset_version_id: Mapped[str] = mapped_column(ForeignKey("dataset_version.id"))
    __table_args__ = (UniqueConstraint("dataset_version_id", "period", "period_start", "metric"),)


# --------------------------------------------------------------------------- security
class User(Base):
    __tablename__ = "app_user"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True)
    display_name: Mapped[str] = mapped_column(String(128))
    role: Mapped[str] = mapped_column(String(32))
    password_hash: Mapped[str] = mapped_column(String(256))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_utc: Mapped[datetime] = mapped_column(DateTime)
    session_version: Mapped[int] = mapped_column(Integer, default=0, server_default="0")  # bump = log out everywhere


class LoginFailure(Base):
    """Failed login attempts, shared by all API workers (key = 'u:<username>' or 'c:<client address>')."""
    __tablename__ = "login_failure"
    __table_args__ = (Index("ix_login_failure_key_at", "key", "at_utc"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(200))
    at_utc: Mapped[datetime] = mapped_column(DateTime, index=True)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    at_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    actor: Mapped[str] = mapped_column(String(64))
    action: Mapped[str] = mapped_column(String(64))
    target: Mapped[str | None] = mapped_column(String(128))
    detail_json: Mapped[str | None] = mapped_column(Text)


class Job(Base):
    __tablename__ = "job"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16))  # queued | running | done | failed
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    params_json: Mapped[str] = mapped_column(Text)
    result_json: Mapped[str | None] = mapped_column(JSON)
    error: Mapped[str | None] = mapped_column(Text)
    created_utc: Mapped[datetime] = mapped_column(DateTime)
    finished_utc: Mapped[datetime | None] = mapped_column(DateTime)
    heartbeat_utc: Mapped[datetime | None] = mapped_column(DateTime)


# --------------------------------------------------------------------------- capacity management (Phase 6)
class CapacityProfile(Base):
    """A versioned set of hourly capacity rules and runway configurations. Exactly one is active."""
    __tablename__ = "capacity_profile"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    description: Mapped[str | None] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=False)
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("capacity_profile.id"))
    created_by: Mapped[str] = mapped_column(String(64))
    created_utc: Mapped[datetime] = mapped_column(DateTime)


class CapacityRule(Base):
    """Hourly capacity for one flow on a set of weekdays and a local-hour window.
    Rules are applied in ``position`` order; a later matching rule overrides an earlier one."""
    __tablename__ = "capacity_rule"
    id: Mapped[int] = mapped_column(primary_key=True)
    profile_id: Mapped[int] = mapped_column(ForeignKey("capacity_profile.id"), index=True)
    position: Mapped[int] = mapped_column(Integer)
    flow: Mapped[str] = mapped_column(String(8))            # total | arr | dep
    weekdays_json: Mapped[str] = mapped_column(String(32))  # e.g. [0,1,2,3,4,5,6]
    start_hour: Mapped[int] = mapped_column(Integer)        # local, inclusive
    end_hour: Mapped[int] = mapped_column(Integer)          # local, exclusive (24 = end of day)
    value: Mapped[float] = mapped_column(Float)             # movements per hour
    status: Mapped[str] = mapped_column(String(24))         # public-reference | assumption | derived
    source: Mapped[str] = mapped_column(Text)
    label: Mapped[str | None] = mapped_column(String(120))


class RunwayConfig(Base):
    """A runway-use configuration expressed as runway counts per flow and its hourly rates.
    Runway designators are not assigned: the data contains no runway-in-use information."""
    __tablename__ = "runway_config"
    id: Mapped[int] = mapped_column(primary_key=True)
    profile_id: Mapped[int] = mapped_column(ForeignKey("capacity_profile.id"), index=True)
    name: Mapped[str] = mapped_column(String(60))
    n_arr: Mapped[int] = mapped_column(Integer)
    n_dep: Mapped[int] = mapped_column(Integer)
    arr_capacity: Mapped[float] = mapped_column(Float)
    dep_capacity: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(24))
    source: Mapped[str] = mapped_column(Text)
