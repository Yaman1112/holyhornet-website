"""Engine / session factory. Schema changes go through Alembic (``migrations/``)."""
from __future__ import annotations

from contextlib import contextmanager
from functools import lru_cache
from pathlib import Path

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from ..core.settings import ROOT, browser_mode, settings


@lru_cache(maxsize=4)
def engine(url: str | None = None) -> Engine:
    url = url or settings().database_url
    if url.startswith("sqlite:///"):
        Path(url.removeprefix("sqlite:///")).parent.mkdir(parents=True, exist_ok=True)
    eng = create_engine(url, future=True)
    if url.startswith("sqlite"):
        @event.listens_for(eng, "connect")
        def _pragmas(conn, _):
            cur = conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            if not browser_mode():   # Pyodide's in-memory file system: keep the default rollback journal
                cur.execute("PRAGMA journal_mode=WAL")
            cur.close()
    return eng


@contextmanager
def session_scope(url: str | None = None):
    s: Session = sessionmaker(bind=engine(url), future=True)()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def migrate(url: str | None = None) -> None:
    """Upgrade the database to the latest Alembic revision."""
    from alembic import command
    from alembic.config import Config

    cfg = Config(str(ROOT / "alembic.ini"))
    cfg.set_main_option("script_location", str(ROOT / "migrations"))
    cfg.set_main_option("sqlalchemy.url", url or settings().database_url)
    command.upgrade(cfg, "head")
