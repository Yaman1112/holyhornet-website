"""Airport Operations Command Center: six views over the common demand frame.

Every number is returned as {"value", "kind", ...} or in tables whose columns are documented
with their kind in ``columns``. Nothing is shown as live: the data is historical (2022).
"""
from __future__ import annotations

import math
from datetime import date

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..core.provenance import Kind, value
from ..core import metrics as KM
from ..db.session import engine
from . import demand

PRESSURE = 0.9  # utilisation threshold for capacity-pressure indicators (configurable later)


def _n(x):
    if x is None:
        return None
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (float, np.floating)):
        return None if math.isnan(x) else round(float(x), 3)
    return x


def _records(df: pd.DataFrame) -> list[dict]:
    out = []
    for r in df.to_dict("records"):
        out.append({k: (str(v) if isinstance(v, date) else _n(v)) for k, v in r.items()})
    return out


def _sum(s: pd.Series):
    return None if s.isna().all() else float(s.sum())


def _meta(F: demand.DemandFrame, start: date, end: date, direction: str | None) -> dict:
    return {
        "range": [start.isoformat(), end.isoformat()], "direction": direction or "ALL", "timezone": "Europe/Amsterdam",
        "dataset_version": F.dataset_version, "model_version": F.model_version, "data_status": "historical (2022) — not live",
        "capacity": {**F.capacity, "kind": str(Kind.ASSUMPTION) if F.capacity["status"] == "assumption" else "configured"},
        "columns": {"actual_*": "actual", "scheduled_*": "scheduled (plan of record)", "predicted_*": "predicted (fpred calibrated)",
                    "canceled": "inferred", "capacity": F.capacity["status"], "*_util / *_gap": "derived"},
    }


# --------------------------------------------------------------------------- executive
def executive(start: date, end: date, direction: str | None = None) -> dict:
    F = demand.build(start, end, direction)
    H, D = F.hourly, F.daily
    complete = D[D["actual_complete"]]
    tot = lambda col, df=D: _sum(df[col])  # noqa: E731
    both = complete[complete["scheduled_mov"].notna()]
    pred = complete[complete["predicted_mov"].notna()]
    dev_s = (both["actual_mov"] - both["scheduled_mov"]).sum() if len(both) else None
    dev_p = (pred["actual_mov"] - pred["predicted_mov"]).sum() if len(pred) else None
    ep = KM.errors(pred["actual_mov"].to_numpy(float), pred["predicted_mov"].to_numpy(float))
    es = KM.errors(both["actual_mov"].to_numpy(float), both["scheduled_mov"].to_numpy(float))
    mape_p, mape_s = ep["mape"], es["mape"]
    hc = H[H["actual_mov"].notna()]
    peak = hc.sort_values("actual_mov").iloc[-1] if len(hc) else None
    pressure = H[(H["actual_util"] >= PRESSURE) | (H["scheduled_util"] >= PRESSURE)]
    can_days = D[D["canceled"].notna()]
    can_rate = float(can_days["canceled"].sum() / can_days["scheduled_mov"].sum()) if len(can_days) and can_days["scheduled_mov"].sum() else None
    with engine().connect() as c:
        n_events = pd.read_sql(text("select count(*) n from operational_event where start_utc <= :b and (end_utc is null or end_utc >= :a)"),
                               c, params={"a": f"{start} 00:00", "b": f"{end} 23:59"}).iloc[0]["n"]
    risks = _risks(D, H, mape_p)
    return {
        "meta": _meta(F, start, end, direction),
        "kpis": {
            "scheduled_arrivals": value(tot("scheduled_arr"), Kind.SCHEDULED),
            "scheduled_departures": value(tot("scheduled_dep"), Kind.SCHEDULED),
            "actual_arrivals": value(tot("actual_arr", complete), Kind.ACTUAL, days=int(len(complete))),
            "actual_departures": value(tot("actual_dep", complete), Kind.ACTUAL, days=int(len(complete))),
            "predicted_movements": value(tot("predicted_mov"), Kind.PREDICTED, model=F.model_version),
            "deviation_vs_schedule": value(_n(dev_s), Kind.DERIVED, formula="Σ actual − Σ scheduled (days with both)"),
            "deviation_vs_prediction": value(_n(dev_p), Kind.DERIVED, formula="Σ actual − Σ predicted (days with both)"),
            "peak_hour": value(None if peak is None else int(peak["actual_mov"]), Kind.ACTUAL,
                               at=None if peak is None else f"{peak['local_date']} {int(peak['local_hour']):02d}:00"),
            "peak_utilisation": value(None if peak is None else _n(peak["actual_util"]), Kind.DERIVED,
                                      formula="U = M/C with C = configured capacity (assumption)"),
            "capacity_pressure_hours": value(int(len(pressure)), Kind.DERIVED, threshold=PRESSURE),
            "inferred_cancellation_rate": value(_n(can_rate), Kind.INFERRED, note="no cancellation field in source data"),
            "forecast_error_wape_pct": value(_n(ep["wape"]), Kind.DERIVED, note="hindsight WAPE = Σ|actual − forecast| / Σ actual, fpred calibrated, days in range"),
            "schedule_error_wape_pct": value(_n(es["wape"]), Kind.DERIVED, note="hindsight WAPE of the raw schedule, days in range"),
            "forecast_error_mape_pct": value(_n(mape_p), Kind.DERIVED, note="hindsight daily MAPE of fpred calibrated forecast in range"),
            "schedule_error_mape_pct": value(_n(mape_s), Kind.DERIVED, note="hindsight daily MAPE of the raw schedule in range"),
            "operational_events": value(int(n_events), Kind.ACTUAL, note="events recorded in the event log"),
            "weather_impact": value(None, Kind.UNAVAILABLE, note="no authorised weather source connected"),
        },
        "daily": _records(D[["local_date", "list_name", "lead_days", "actual_complete", "actual_mov", "scheduled_mov",
                             "predicted_mov", "canceled", "peak_actual", "peak_actual_util"]]),
        "risks": risks,
    }


def _risks(D: pd.DataFrame, H: pd.DataFrame, mape_p) -> list[dict]:
    """Rule-based indicators; every item carries its evidence and the rule that fired."""
    out = []
    for r in H[H["actual_util"] >= PRESSURE].itertuples():
        out.append({"type": "capacity_pressure", "severity": "high" if r.actual_util >= 1 else "medium", "kind": "derived",
                    "when": f"{r.local_date} {r.local_hour:02d}:00", "evidence": {"actual_movements": int(r.actual_mov),
                    "capacity": r.capacity, "utilisation": round(r.actual_util, 3)}, "rule": f"U(t) ≥ {PRESSURE}"})
    for r in H[(H["scheduled_util"] >= PRESSURE) & H["actual_util"].isna()].itertuples():
        out.append({"type": "planned_capacity_pressure", "severity": "medium", "kind": "derived",
                    "when": f"{r.local_date} {r.local_hour:02d}:00", "evidence": {"scheduled_movements": int(r.scheduled_mov),
                    "capacity": r.capacity}, "rule": f"scheduled U(t) ≥ {PRESSURE} (no actuals yet)"})
    c = D[D["actual_complete"] & D["scheduled_mov"].notna()]
    for r in c.itertuples():
        dev = (r.actual_mov - r.scheduled_mov) / r.scheduled_mov
        if abs(dev) > 0.10:
            out.append({"type": "schedule_deviation", "severity": "medium", "kind": "derived", "when": str(r.local_date),
                        "evidence": {"actual": int(r.actual_mov), "scheduled": int(r.scheduled_mov), "deviation_pct": round(dev * 100, 1),
                                     "list": r.list_name}, "rule": "|actual − scheduled| / scheduled > 10 %"})
    p = D[D["actual_complete"] & D["predicted_mov"].notna()]
    if mape_p and len(p):
        for r in p.itertuples():
            err = abs(r.actual_mov - r.predicted_mov) / r.actual_mov * 100
            if err > 2 * mape_p and err > 5:
                out.append({"type": "forecast_miss", "severity": "low", "kind": "derived", "when": str(r.local_date),
                            "evidence": {"actual": int(r.actual_mov), "predicted": round(r.predicted_mov, 1), "error_pct": round(err, 1)},
                            "rule": "daily error > 2 × range MAPE and > 5 %"})
    order = {"high": 0, "medium": 1, "low": 2}
    return sorted(out, key=lambda x: (order[x["severity"]], x["when"]))[:200]


# --------------------------------------------------------------------------- operations
def operations(start: date, end: date, direction: str | None = None) -> dict:
    F = demand.build(start, end, direction)
    H = F.hourly
    prof = H.groupby("local_hour").agg(
        actual_arr=("actual_arr", "mean"), actual_dep=("actual_dep", "mean"),
        scheduled_arr=("scheduled_arr", "mean"), scheduled_dep=("scheduled_dep", "mean"),
        predicted_arr=("predicted_arr", "mean"), predicted_dep=("predicted_dep", "mean")).reset_index()
    prof["imbalance"] = prof["actual_arr"] - prof["actual_dep"]
    peaks = H[H["actual_mov"].notna()].sort_values("actual_mov", ascending=False).head(15)
    return {
        "meta": _meta(F, start, end, direction),
        "hourly_profile": _records(prof),
        "peaks": _records(peaks[["local_date", "local_hour", "actual_arr", "actual_dep", "actual_mov", "scheduled_mov", "actual_util"]]),
        "hourly": _records(H[["local_date", "local_hour", "actual_arr", "actual_dep", "scheduled_arr", "scheduled_dep",
                              "predicted_arr", "predicted_dep", "canceled"]]) if (end - start).days <= 6 else None,
    }


# --------------------------------------------------------------------------- capacity
def capacity(start: date, end: date, direction: str | None = None) -> dict:
    F = demand.build(start, end, direction)
    H = F.hourly
    bins = [0, 0.5, 0.7, 0.8, 0.9, 1.0, 10]
    labels = ["<50%", "50–70%", "70–80%", "80–90%", "90–100%", "≥100%"]
    dist = {}
    for k in ("actual", "scheduled", "predicted"):
        u = H[f"{k}_util"].dropna()
        dist[k] = dict(zip(labels, pd.cut(u, bins, labels=labels, right=False).value_counts().reindex(labels, fill_value=0).astype(int).tolist()))
    top = H[H["actual_util"].notna()].sort_values("actual_util", ascending=False).head(20)
    return {
        "meta": _meta(F, start, end, direction),
        "formulas": {"M(t)": "A(t) + D(t)", "U(t)": "M(t) / C(t)", "G(t)": "M(t) − C(t)"},
        "distribution": dist,
        "top_hours": _records(top[["local_date", "local_hour", "actual_mov", "scheduled_mov", "predicted_mov", "capacity", "actual_util", "actual_gap"]]),
        "hourly": _records(H[["local_date", "local_hour", "actual_mov", "scheduled_mov", "predicted_mov", "capacity",
                              "actual_util", "scheduled_util", "predicted_util", "actual_gap"]]) if (end - start).days <= 13 else None,
        "daily_peak_util": _records(F.daily[["local_date", "peak_actual", "peak_actual_util", "peak_scheduled"]]),
    }


# --------------------------------------------------------------------------- predictive
def predictive(start: date, end: date, direction: str | None = None) -> dict:
    F = demand.build(start, end, direction)
    D = F.daily
    d = D[D["predicted_mov"].notna()].copy()
    d["error"] = d["actual_mov"] - d["predicted_mov"]
    d["sched_error"] = d["actual_mov"] - d["scheduled_mov"]
    ok = d[d["actual_mov"].notna()]
    def stats(e, a):
        if not len(e):
            return None
        m = KM.errors(a.to_numpy(float), (a - e).to_numpy(float))
        return {"mae": m["mae"], "rmse": m["rmse"], "bias": m["bias"], "wape_pct": m["wape"], "mape_pct": m["mape"], "n_days": m["n"]}
    by_h = ok.groupby("lead_days").apply(lambda g: pd.Series({"mae": g["error"].abs().mean(), "n": len(g)}), include_groups=False).reset_index()
    return {
        "meta": _meta(F, start, end, direction),
        "note": "Hindsight comparison on historical days. Error = actual − predicted. The full D-7…D-1 model suite arrives in Phase 4.",
        "accuracy": {"predicted": stats(ok["error"], ok["actual_mov"]), "scheduled": stats(ok["sched_error"], ok["actual_mov"])},
        "by_lead_days": _records(by_h),
        "daily": _records(D[["local_date", "list_name", "lead_days", "actual_mov", "scheduled_mov", "predicted_mov"]]),
    }


# --------------------------------------------------------------------------- historical
def historical(start: date, end: date, direction: str | None = None) -> dict:
    F = demand.build(start, end, direction)
    D, H = F.daily, F.hourly
    c = D[D["actual_complete"]].copy()
    c["weekday"] = pd.to_datetime(c["local_date"]).dt.day_name()
    c["iso_week"] = pd.to_datetime(c["local_date"]).dt.isocalendar().week.astype(int)
    hc = H[H["actual_complete"]].copy()
    hc["wd"] = pd.to_datetime(hc["local_date"]).dt.day_of_week
    heat = hc.groupby(["wd", "local_hour"])["actual_mov"].mean().unstack().reindex(index=range(7), columns=range(24))
    weekly = c.groupby("iso_week").agg(days=("actual_mov", "size"), movements=("actual_mov", "sum"), mean_daily=("actual_mov", "mean")).reset_index()
    monthly = c.assign(month=pd.to_datetime(c["local_date"]).dt.strftime("%Y-%m")).groupby("month").agg(
        days=("actual_mov", "size"), movements=("actual_mov", "sum"), mean_daily=("actual_mov", "mean")).reset_index()
    return {
        "meta": _meta(F, start, end, direction),
        "daily": _records(c[["local_date", "weekday", "actual_arr", "actual_dep", "actual_mov", "peak_actual"]]),
        "weekly": _records(weekly), "monthly": _records(monthly),
        "weekday_hour_mean": {"weekdays": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
                              "values": [[_n(v) for v in row] for row in heat.to_numpy()]},
    }


# --------------------------------------------------------------------------- flights
def flights(start: date, end: date, direction: str | None = None, state: str | None = None, q: str | None = None,
            limit: int = 100, offset: int = 0) -> dict:
    """Movement-level list for the plan-of-record list of each day (matched / added / inferred canceled)."""
    F = demand.build(start, end, direction)
    por = F.hourly.groupby("local_date")["list_id"].first().dropna()
    pairs = [(str(d), int(l)) for d, l in por.items()]
    if not pairs:
        return {"meta": _meta(F, start, end, direction), "total": 0, "rows": [], "note": "no schedule list covers this range"}
    cond = " or ".join(f"(mm.local_date = '{d}' and mm.schedule_list_id = {l})" for d, l in pairs)
    where = [f"({cond})"]
    params: dict = {}
    if direction:
        where.append("mm.direction = :dir")
        params["dir"] = direction
    if state:
        where.append("mm.state = :st")
        params["st"] = state
    if q:
        where.append("(upper(coalesce(e.flight_id,'')) like :q or upper(coalesce(m.callsign,'')) like :q "
                     "or upper(coalesce(e.other_airport, m.other_airport)) like :q or upper(coalesce(m.operator_icao, e.operator_icao,'')) like :q)")
        params["q"] = f"%{q.upper()}%"
    base = (" from movement_match mm left join schedule_entry e on e.id = mm.schedule_entry_id "
            "left join movement m on m.id = mm.movement_id where " + " and ".join(where))
    with engine().connect() as c:
        total = int(pd.read_sql(text("select count(*) n" + base), c, params=params).iloc[0]["n"])
        rows = pd.read_sql(text(
            "select mm.local_date, mm.local_hour, mm.direction, mm.state, mm.stage, mm.offset_min, e.flight_id planned_id, "
            "e.planned_utc, e.planned_reference, m.callsign, m.actual_utc, coalesce(m.aircraft_type, e.aircraft_type) aircraft_type, "
            "coalesce(m.other_airport, e.other_airport) other_airport, coalesce(m.operator_icao, e.operator_icao) operator"
            + base + " order by coalesce(m.actual_utc, e.planned_utc) limit :lim offset :off"), c,
            params={**params, "lim": min(limit, 500), "off": offset})
    rows["kind"] = rows["state"].map({"matched": "actual", "added": "actual", "canceled": "inferred", "confirmed_canceled": "inferred"})
    return {"meta": _meta(F, start, end, direction), "total": total, "rows": _records(rows.astype(object).where(rows.notna(), None))}
