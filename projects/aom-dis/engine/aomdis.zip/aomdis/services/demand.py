"""Common demand frame shared by all modules.

For every local hour in a date range it combines, each with its own provenance kind:

* ``actual_*``     observed movements (movement table)                          -> actual
* ``scheduled_*``  the *plan of record*: entries of the newest schedule list
                   published before that day that covers it                      -> scheduled
* ``predicted_*``  fpred calibrated forecast from that same list                 -> predicted
* ``canceled``     inferred cancellations from fpred matching for that list     -> inferred
* ``capacity``     configured hourly movement capacity                          -> assumption

M(t) = A(t) + D(t);  U(t) = M(t) / C(t);  G(t) = M(t) − C(t).
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..core.timeutil import hours_in_local_day
from ..db.session import engine
from ..ingest.pipeline import latest_dataset_version


@dataclass
class DemandFrame:
    hourly: pd.DataFrame          # one row per (local_date, local_hour)
    daily: pd.DataFrame           # one row per local_date
    lists: pd.DataFrame           # schedule lists available
    capacity: dict                # capacity parameters used (with status)
    dataset_version: str
    model_version: str | None


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


def capacity_params() -> dict:
    df = _q("select key, value_json, unit, status, source from capacity_parameter")
    return {r.key: {"value": json.loads(r.value_json), "unit": r.unit, "status": r.status, "source": r.source}
            for r in df.itertuples()}


def hourly_capacity(flow: str, weekdays, hours) -> np.ndarray:
    """Capacity of the ACTIVE capacity profile (aomdis.capacity.profile) for each (weekday, local hour)."""
    from ..capacity.profile import cap_value
    return np.array([cap_value(flow, int(w), int(h)) for w, h in zip(weekdays, hours)], dtype=float)


def capacity_meta(flow: str = "total") -> dict:
    """Display metadata for the active profile's capacity of one flow."""
    from ..capacity.profile import active_id, base_meta, get_profile
    pid = active_id()
    m = base_meta(pid)[flow]
    prof = get_profile(pid)
    srcs = sorted({r["source"] for r in prof["rules"] if r["flow"] == flow})
    status = "assumption" if "assumption" in m["statuses"] else m["statuses"][0]
    return {"key": f"profile:{prof['name']}:{flow}", "value": m["values"][-1] if not m["varies_by_hour"] else max(m["values"]),
            "values": m["values"], "varies_by_hour": m["varies_by_hour"], "unit": "movements/h", "status": status,
            "source": "; ".join(srcs), "profile": prof["name"], "profile_id": pid}


def plan_of_record(lists: pd.DataFrame, day: date) -> pd.Series | None:
    """Newest list published before ``day`` whose coverage includes it."""
    c = lists[(lists["published_date"] < day) & (lists["coverage_start_local"] <= day) & (lists["coverage_end_local"] >= day)]
    return None if c.empty else c.sort_values("published_date").iloc[-1]


def build(start: date, end: date, direction: str | None = None) -> DemandFrame:
    dsv = latest_dataset_version()
    if dsv is None:
        raise LookupError("warehouse empty")
    lists = _q("select id, name, published_date, coverage_start_local, coverage_end_local from schedule_list where dataset_version_id=:d", d=dsv)
    for c in ("published_date", "coverage_start_local", "coverage_end_local"):
        lists[c] = pd.to_datetime(lists[c]).dt.date
    days = pd.date_range(start, end).date
    por = {d: plan_of_record(lists, d) for d in days}
    span = _q("select min(local_date) a, max(local_date) b from movement where dataset_version_id=:d", d=dsv).iloc[0]
    first_full = pd.Timestamp(span["a"]).date()
    last_full = pd.Timestamp(span["b"]).date()

    a, b = start.isoformat(), end.isoformat()
    dir_sql = "" if not direction else " and direction=:dir"
    act = _q("select local_date, local_hour, direction, count(*) n from movement where dataset_version_id=:d and local_date between :a and :b"
             + dir_sql + " group by 1,2,3", d=dsv, a=a, b=b, dir=direction)
    sch = _q("select e.schedule_list_id lid, e.local_date, e.local_hour, e.direction, count(*) n from schedule_entry e "
             "join schedule_list l on l.id=e.schedule_list_id where l.dataset_version_id=:d and e.local_date between :a and :b"
             + dir_sql.replace("direction", "e.direction") + " group by 1,2,3,4", d=dsv, a=a, b=b, dir=direction)
    mv = _q("select id from model_version where name='fpred-calibrated' order by created_utc desc limit 1")
    model_version = mv["id"].iloc[0] if len(mv) else None
    prd = _q("select r.schedule_list_id lid, f.target_local_date local_date, f.target_local_hour local_hour, f.metric, f.value "
             "from forecast f join forecast_run r on r.id=f.run_id where r.dataset_version_id=:d and r.model_version_id=:m "
             "and f.target_local_hour is not null and f.target_local_date between :a and :b", d=dsv, m=model_version, a=a, b=b)
    can = _q("select schedule_list_id lid, local_date, local_hour, direction, count(*) n from movement_match "
             "where state in ('canceled','confirmed_canceled') and local_date between :a and :b" + dir_sql + " group by 1,2,3,4",
             a=a, b=b, dir=direction)
    mcov = _q("select schedule_list_id lid, min(local_date) d0, max(local_date) d1 from movement_match group by 1")
    mcov = {r.lid: (pd.Timestamp(r.d0).date(), pd.Timestamp(r.d1).date()) for r in mcov.itertuples()}

    for df in (act, sch, prd, can):
        if len(df):
            df["local_date"] = pd.to_datetime(df["local_date"]).dt.date

    # hourly skeleton in local time (DST days have 23/25 hours; hour 2 missing on spring-forward day)
    rows = []
    for d in days:
        n_h = hours_in_local_day(d)
        hours = [h for h in range(24) if not (n_h == 23 and h == 2)]
        p = por[d]
        for h in hours:
            rows.append({"local_date": d, "local_hour": h, "list_id": None if p is None else int(p["id"]),
                         "list_name": None if p is None else p["name"],
                         "lead_days": None if p is None else (d - p["published_date"]).days})
    H = pd.DataFrame(rows)

    def pivot(df, key_cols, val="n"):
        if df.empty:
            return pd.DataFrame(columns=key_cols + ["ARR", "DEP"])
        out = df.pivot_table(index=key_cols, columns="direction", values=val, aggfunc="sum", fill_value=0)
        return out.reindex(columns=["ARR", "DEP"], fill_value=0).reset_index()

    A = pivot(act, ["local_date", "local_hour"]).rename(columns={"ARR": "actual_arr", "DEP": "actual_dep"})
    H = H.merge(A, on=["local_date", "local_hour"], how="left")
    S = pivot(sch, ["lid", "local_date", "local_hour"]).rename(columns={"lid": "list_id", "ARR": "scheduled_arr", "DEP": "scheduled_dep"})
    H = H.merge(S, on=["list_id", "local_date", "local_hour"], how="left")
    C = pivot(can, ["lid", "local_date", "local_hour"]).rename(columns={"lid": "list_id"})
    C["canceled"] = C.get("ARR", 0) + C.get("DEP", 0)
    H = H.merge(C[["list_id", "local_date", "local_hour", "canceled"]], on=["list_id", "local_date", "local_hour"], how="left")
    if len(prd):
        P = prd.pivot_table(index=["lid", "local_date", "local_hour"], columns="metric", values="value", aggfunc="sum").reset_index()
        P = P.rename(columns={"lid": "list_id", "arrivals": "predicted_arr", "departures": "predicted_dep"})
        H = H.merge(P, on=["list_id", "local_date", "local_hour"], how="left")
    else:
        H["predicted_arr"] = np.nan
        H["predicted_dep"] = np.nan
    if direction == "ARR":
        H["predicted_dep"] = 0.0
    elif direction == "DEP":
        H["predicted_arr"] = 0.0

    # availability masks
    # first/last local dates of the realisation file are partial days -> actual unavailable there
    H["actual_complete"] = H["local_date"].map(lambda d: first_full < d < last_full)
    actual_ok = H["actual_complete"]
    H.loc[~actual_ok, ["actual_arr", "actual_dep"]] = np.nan
    H.loc[actual_ok, ["actual_arr", "actual_dep"]] = H.loc[actual_ok, ["actual_arr", "actual_dep"]].fillna(0)
    has_list = H["list_id"].notna()
    H.loc[has_list, ["scheduled_arr", "scheduled_dep"]] = H.loc[has_list, ["scheduled_arr", "scheduled_dep"]].fillna(0)
    has_pred = H["list_id"].isin(prd["lid"].unique()) if len(prd) else pd.Series(False, index=H.index)
    H.loc[has_pred, ["predicted_arr", "predicted_dep"]] = H.loc[has_pred, ["predicted_arr", "predicted_dep"]].fillna(0)
    H.loc[~has_pred, ["predicted_arr", "predicted_dep"]] = np.nan
    in_match = [lid in mcov and mcov[lid][0] <= d <= mcov[lid][1] for lid, d in zip(H["list_id"], H["local_date"])]
    H["canceled"] = np.where(in_match, H["canceled"].fillna(0), np.nan)

    for k in ("actual", "scheduled", "predicted"):
        H[f"{k}_mov"] = H[f"{k}_arr"] + H[f"{k}_dep"]
    flow = {"ARR": "arr", "DEP": "dep"}.get(direction or "", "total")
    H["capacity"] = hourly_capacity(flow, pd.to_datetime(H["local_date"]).dt.day_of_week, H["local_hour"])
    cap_meta = capacity_meta(flow)
    for k in ("actual", "scheduled", "predicted"):
        H[f"{k}_util"] = H[f"{k}_mov"] / H["capacity"]
        H[f"{k}_gap"] = H[f"{k}_mov"] - H["capacity"]

    D = H.groupby("local_date").agg(
        list_name=("list_name", "first"), lead_days=("lead_days", "first"), actual_complete=("actual_complete", "first"),
        **{c: (c, lambda s: s.sum(min_count=1)) for c in
           ("actual_arr", "actual_dep", "actual_mov", "scheduled_arr", "scheduled_dep", "scheduled_mov",
            "predicted_arr", "predicted_dep", "predicted_mov", "canceled")},
        peak_actual=("actual_mov", "max"), peak_scheduled=("scheduled_mov", "max"),
        hours=("local_hour", "size")).reset_index()
    D["peak_actual_util"] = D["peak_actual"] / H["capacity"].iloc[0] if len(H) else np.nan
    return DemandFrame(H, D, lists, cap_meta, dsv, model_version)
