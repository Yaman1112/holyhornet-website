"""Minimal background jobs: a thread per job, state in the ``job`` table (no external queue).

A running job refreshes ``heartbeat_utc`` every HEARTBEAT_S seconds. If its worker process dies
(restart, crash, redeploy), the heartbeat stops; after STALE_S the job is marked ``failed`` with
"interrupted" instead of staying ``running`` forever and blocking new jobs of that kind.
This works across several API workers because the state lives in the database."""
from __future__ import annotations

import json
import logging
import threading
import traceback
from datetime import datetime, timedelta, timezone
from typing import Callable

from sqlalchemy import select

from ..core.settings import browser_mode
from ..db import models as M
from ..db.session import session_scope

log = logging.getLogger("aomdis.jobs")
_lock = threading.Lock()
HEARTBEAT_S = 15
STALE_S = 120
INTERRUPTED = "interrupted: the worker running this job stopped (restart or crash) before it finished"


def _now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def reap_stale(now: datetime | None = None) -> list[int]:
    """Mark queued/running jobs whose heartbeat (or creation, if none yet) is older than STALE_S as failed."""
    now = now or _now()
    cutoff = now - timedelta(seconds=STALE_S)
    with session_scope() as s:
        rows = s.execute(select(M.Job).where(M.Job.status.in_(["queued", "running"]))).scalars().all()
        dead = [j for j in rows if (j.heartbeat_utc or j.created_utc) < cutoff]
        for j in dead:
            j.status, j.error, j.finished_utc = "failed", INTERRUPTED, now
        ids = [j.id for j in dead]
    for i in ids:
        log.warning("job %s marked interrupted (no heartbeat for %ss)", i, STALE_S)
    return ids


def running(kind: str) -> int | None:
    reap_stale()
    with session_scope() as s:
        r = s.execute(select(M.Job.id).where((M.Job.kind == kind) & M.Job.status.in_(["queued", "running"]))).first()
        return r[0] if r else None


class NotInBrowser(RuntimeError):
    """Background jobs need threads; the browser edition (Pyodide) has none."""


def start(kind: str, params: dict, fn: Callable[[Callable[[float], None]], dict], synchronous: bool = False) -> int:
    if browser_mode() and not synchronous:
        raise NotInBrowser("background jobs (backtest, store rebuild) are not available in the browser edition; "
                           "the stored results were computed with the full system")
    with _lock:
        if (jid := running(kind)) is not None:
            raise RuntimeError(f"a {kind} job is already running (job {jid})")
        with session_scope() as s:
            j = M.Job(kind=kind, status="queued", progress=0.0, params_json=json.dumps(params), created_utc=_now(),
                      heartbeat_utc=_now())
            s.add(j)
            s.flush()
            jid = j.id

    def progress(p: float) -> None:
        with session_scope() as s:
            j = s.get(M.Job, jid)
            j.progress, j.heartbeat_utc = round(float(p), 3), _now()

    def work() -> None:
        with session_scope() as s:
            j = s.get(M.Job, jid)
            j.status, j.heartbeat_utc = "running", _now()
        stop = threading.Event()

        def beat() -> None:
            while not stop.wait(HEARTBEAT_S):
                with session_scope() as s:
                    j = s.get(M.Job, jid)
                    if j is not None and j.status == "running":
                        j.heartbeat_utc = _now()

        threading.Thread(target=beat, name=f"job-{jid}-heartbeat", daemon=True).start()
        try:
            result = fn(progress)
            with session_scope() as s:
                j = s.get(M.Job, jid)
                j.status, j.progress, j.result_json, j.finished_utc = "done", 1.0, result, _now()
        except Exception as e:  # noqa: BLE001 — recorded on the job
            log.exception("job %s failed", jid)
            with session_scope() as s:
                j = s.get(M.Job, jid)
                j.status, j.error, j.finished_utc = "failed", f"{e}\n{traceback.format_exc()[-2000:]}", _now()
        finally:
            stop.set()

    if synchronous:
        work()
    else:
        threading.Thread(target=work, name=f"job-{jid}", daemon=True).start()
    return jid


def get(jid: int) -> dict | None:
    reap_stale()
    with session_scope() as s:
        j = s.get(M.Job, jid)
        if j is None:
            return None
        return {"id": j.id, "kind": j.kind, "status": j.status, "progress": j.progress, "params": json.loads(j.params_json),
                "result": j.result_json, "error": (j.error or "").split("\n")[0] or None,
                "created_utc": str(j.created_utc), "finished_utc": str(j.finished_utc) if j.finished_utc else None}
