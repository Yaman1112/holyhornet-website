"""AOM-DIS — Airport Operations Management & Decision Intelligence System (EHAM).

Common data foundation and services for all operational horizons. The D-7 engine
``fpred`` remains an independent module used through ``aomdis.adapters``.
"""

__version__ = "0.1.0"
