"""Capacity analysis on the common demand frame and the active capacity profile.

Per local hour t and flow f ∈ {total, arr, dep}:
    U_f(t) = D_f(t) / C_f(t),   G_f(t) = D_f(t) − C_f(t)
The binding constraint is the flow with the highest U. Pressure band from max U:
    < 0.80 normal · 0.80–0.90 elevated · 0.90–1.00 high · ≥ 1.00 over capacity
Demand sources (common frame): actual (complete days), scheduled (plan of record), predicted
(original D-7 engine on the plan-of-record list). Runway analysis uses the profile's runway configurations
(counts × configured rates; designators not modelled) and a per-day fluid queue for availability scenarios.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd

from ..services import demand
from . import profile as PR

BANDS = [(0.0, 0.8, "normal"), (0.8, 0.9, "elevated"), (0.9, 1.0, "high"), (1.0, np.inf, "over")]
SOURCES = {"actual": "actual", "scheduled": "scheduled", "predicted": "predicted"}
WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def band(u: float) -> str | None:
    if u is None or np.isnan(u):
        return None
    for lo, hi, name in BANDS:
        if lo <= u < hi:
            return name
    return "over"


def frame(source: str, start: date, end: date) -> tuple[pd.DataFrame, dict]:
    if source not in SOURCES:
        raise ValueError(f"source must be one of {list(SOURCES)}")
    F = demand.build(start, end)
    H = F.hourly.copy()
    H = H[H[f"{source}_mov"].notna()].copy()
    if H.empty:
        raise LookupError(f"no {source} demand in {start} … {end}")
    H["weekday"] = pd.to_datetime(H["local_date"]).dt.day_of_week
    H["d_arr"], H["d_dep"] = H[f"{source}_arr"], H[f"{source}_dep"]
    H["d_tot"] = H["d_arr"] + H["d_dep"]
    for f, col in (("total", "c_tot"), ("arr", "c_arr"), ("dep", "c_dep")):
        H[col] = demand.hourly_capacity(f, H["weekday"], H["local_hour"])
    with np.errstate(divide="ignore", invalid="ignore"):
        H["u_tot"], H["u_arr"], H["u_dep"] = H["d_tot"] / H["c_tot"], H["d_arr"] / H["c_arr"], H["d_dep"] / H["c_dep"]
    H["g_tot"], H["g_arr"], H["g_dep"] = H["d_tot"] - H["c_tot"], H["d_arr"] - H["c_arr"], H["d_dep"] - H["c_dep"]
    U = H[["u_tot", "u_arr", "u_dep"]].replace([np.inf], 9.99)
    H["u_max"] = U.max(axis=1)
    H["binding"] = U.idxmax(axis=1).map({"u_tot": "total", "u_arr": "arrivals", "u_dep": "departures"})
    H["band"] = H["u_max"].map(band)
    return H, {"dataset_version": F.dataset_version, "model_version": F.model_version, "_frame": F}


def observed_throughput(start: date, end: date, F=None) -> dict:
    """What the airport actually handled per local hour (complete days only), per flow: p95, maximum and
    the hour of the maximum. A lower bound on capacity in the observed conditions, not capacity itself.
    ``F`` = an already built demand frame for the same range (avoids rebuilding it)."""
    H = (F or demand.build(start, end)).hourly
    H = H[H["actual_complete"]]
    out = {"kind": "actual", "hours": int(len(H)), "range": [str(start), str(end)],
           "definition": "p95 / max of realised movements per local hour over complete days (KPI observed_throughput)"}
    for flow, col in (("total", "actual_mov"), ("arr", "actual_arr"), ("dep", "actual_dep")):
        v = H[col].dropna()
        if v.empty:
            out[flow] = None
            continue
        i = v.idxmax()
        out[flow] = {"p95": float(np.percentile(v, 95)), "max": float(v.max()),
                     "max_at": f"{H.loc[i, 'local_date']} {int(H.loc[i, 'local_hour']):02d}:00"}
    return out


def capacity_basis(pid: int, start: date, end: date, F=None) -> dict:
    """Declared vs configured vs observed, kept apart (requirement CAP-2). Declared capacity is only reported
    when a rule's status is public-reference; otherwise it is unavailable, never inferred."""
    rules = PR.get_profile(pid)["rules"]
    statuses = sorted({r["status"] for r in rules})
    declared = [r for r in rules if r["status"] == "public-reference"]
    base = {f: next((r for r in rules if r["flow"] == f and r["start_hour"] == 0 and r["end_hour"] == 24), None) for f in ("total", "arr", "dep")}
    obs = observed_throughput(start, end, F)
    checks = []
    for f in ("total", "arr", "dep"):
        if base[f] and obs.get(f) and obs[f]["max"] > base[f]["value"]:
            checks.append(f"{f}: observed maximum {obs[f]['max']:.0f}/h ({obs[f]['max_at']}) exceeds the configured base capacity "
                          f"{base[f]['value']:.0f}/h; the configured value is below what was demonstrably handled.")
    return {
        "declared": {"available": bool(declared), "rules": declared,
                     "note": None if declared else "unavailable: no rule in the active profile carries a public-reference (declared) value"},
        "configured": {"profile_id": pid, "statuses": statuses, "base": {f: (base[f] and {"value": base[f]["value"], "status": base[f]["status"],
                                                                                       "source": base[f]["source"]}) for f in base},
                       "note": "values of the active capacity profile; status 'assumption' means modelled, not official"},
        "observed": obs,
        "consistency_checks": checks,
    }


def analyse(source: str, start: date, end: date) -> dict:
    H, meta = frame(source, start, end)
    F = meta.pop("_frame")
    pid = PR.active_id()
    prof = PR.get_profile(pid)
    n = len(H)
    counts = H["band"].value_counts().reindex([b[2] for b in BANDS], fill_value=0)
    peak = H.loc[H["u_max"].idxmax()]
    flow_only = H[(H["u_tot"] < 0.9) & ((H["u_arr"] >= 0.9) | (H["u_dep"] >= 0.9))]

    # recurring bottlenecks by weekday x hour
    g = H.groupby(["weekday", "local_hour"])
    B = pd.DataFrame({"days": g.size(), "mean_u": g["u_max"].mean(), "p90_u": g["u_max"].quantile(0.9),
                      "share_high": g["u_max"].apply(lambda s: float((s >= 0.9).mean())),
                      "binding": g["binding"].agg(lambda s: s.mode().iat[0]),
                      "mean_demand": g["d_tot"].mean(), "capacity": g["c_tot"].first()}).reset_index()
    B["score"] = B["share_high"] * 100 + B["mean_u"]
    top = B.sort_values(["score", "mean_u"], ascending=False).head(15)
    heat = B.pivot(index="weekday", columns="local_hour", values="mean_u").reindex(index=range(7), columns=range(24))

    daily = H.groupby("local_date").apply(lambda d: pd.Series({
        "peak_u": d["u_max"].max(), "peak_hour": int(d.loc[d["u_max"].idxmax(), "local_hour"]),
        "binding": d.loc[d["u_max"].idxmax(), "binding"], "hours_high": int((d["u_max"] >= 0.9).sum()),
        "excess": float(d["g_tot"].clip(lower=0).sum())}), include_groups=False).reset_index()

    rw = runway_requirement(H, prof["runway_configs"])
    return _clean({
        "source": source, "kind": SOURCES[source], "range": [str(start), str(end)], "hours": n, "days": int(H["local_date"].nunique()),
        "profile": {"id": pid, "name": prof["name"]}, **meta,
        "formulas": {"U_f(t)": "D_f(t) / C_f(t)", "G_f(t)": "D_f(t) − C_f(t)", "binding": "argmax_f U_f(t)",
                     "bands": "normal < 0.8 ≤ elevated < 0.9 ≤ high < 1.0 ≤ over"},
        "summary": {
            "bands": {k: int(v) for k, v in counts.items()},
            "hours_over_capacity": int((H["u_max"] >= 1.0).sum()),
            "peak": {"u": float(peak["u_max"]), "at": f"{peak['local_date']} {int(peak['local_hour']):02d}:00", "binding": peak["binding"],
                     "demand": float(peak["d_tot"]), "capacity": float(peak["c_tot"])},
            "excess_movement_hours": float(H["g_tot"].clip(lower=0).sum()),
            "binding_counts_when_high": H[H["u_max"] >= 0.9]["binding"].value_counts().to_dict(),
            "flow_only_pressure_hours": int(len(flow_only)),
            "mean_arr_share": float((H["d_arr"] / H["d_tot"].replace(0, np.nan)).mean()),
        },
        "bottlenecks": top.to_dict("records"),
        "heatmap": {"weekdays": WD, "values": [[None if pd.isna(v) else round(float(v), 3) for v in row] for row in heat.to_numpy()]},
        "daily": daily.assign(local_date=daily["local_date"].astype(str)).to_dict("records"),
        "hourly": [{"t": f"{r.local_date} {int(r.local_hour):02d}", "d_arr": r.d_arr, "d_dep": r.d_dep, "c_tot": r.c_tot, "c_arr": r.c_arr,
                    "c_dep": r.c_dep, "u_tot": r.u_tot, "u_arr": r.u_arr, "u_dep": r.u_dep, "g_tot": r.g_tot, "binding": r.binding, "band": r.band}
                   for r in H.itertuples()] if H["local_date"].nunique() <= 14 else None,
        "runways": rw,
        "capacity_basis": capacity_basis(pid, start, end, F),
    })


def runway_requirement(H: pd.DataFrame, configs: list[dict]) -> dict:
    """Smallest configuration (fewest runways, then lowest capacity) covering both flows in each hour."""
    cs = sorted(configs, key=lambda c: (c["n_arr"] + c["n_dep"], c["total"]))
    need = []
    for a, d in zip(H["d_arr"], H["d_dep"]):
        hit = next((c["name"] for c in cs if a <= c["arr_capacity"] and d <= c["dep_capacity"]), "exceeds all configurations")
        need.append(hit)
    dist = pd.Series(need).value_counts()
    order = [c["name"] for c in cs] + ["exceeds all configurations"]
    return {"configurations": configs, "kind": "derived",
            "note": "Runway counts × configured per-runway rates (assumptions); designators, wind, mixed-mode and noise rules are not modelled.",
            "required": [{"config": k, "hours": int(dist.get(k, 0))} for k in order if dist.get(k, 0)]}


def availability_scenarios(source: str, start: date, end: date, max_runways: list[int] | None = None) -> dict:
    """What if at most N runways are available? Per hour the best allowed configuration for the demand mix
    is chosen; unserved demand queues to the next hour within the same day (reset at local midnight)."""
    H, meta = frame(source, start, end)
    meta.pop("_frame", None)
    cfgs = PR.get_profile(PR.active_id())["runway_configs"]
    maxn = max(c["n_arr"] + c["n_dep"] for c in cfgs)
    ns = sorted(set(max_runways or range(2, maxn + 1)), reverse=True)
    out = []
    for n in ns:
        allowed = [c for c in cfgs if c["n_arr"] + c["n_dep"] <= n]
        if not allowed:
            continue
        rows, backlog_total, max_q, short_hours = [], 0.0, 0.0, 0
        for day, d in H.sort_values(["local_date", "local_hour"]).groupby("local_date"):
            qa = qd = 0.0
            for r in d.itertuples():
                qa += r.d_arr
                qd += r.d_dep
                best = max(allowed, key=lambda c: (min(qa, c["arr_capacity"]) + min(qd, c["dep_capacity"]), -(c["n_arr"] + c["n_dep"])))
                sa, sd = min(qa, best["arr_capacity"]), min(qd, best["dep_capacity"])
                # the airport-level hourly capacity of the profile still applies
                if sa + sd > r.c_tot:
                    k = r.c_tot / (sa + sd)
                    sa, sd = sa * k, sd * k
                qa, qd = qa - sa, qd - sd
                q = qa + qd
                backlog_total += q
                max_q = max(max_q, q)
                short_hours += int(q > 0.5)
        out.append({"max_runways": n, "configurations_allowed": [c["name"] for c in allowed], "hours_with_backlog": short_hours,
                    "delay_movement_hours": round(backlog_total, 1), "max_backlog": round(max_q, 1)})
    return _clean({"source": source, "kind": "simulated", "range": [str(start), str(end)], "scenarios": out, **meta,
                   "model": "per-day fluid queue; best allowed configuration each hour; profile hourly capacity also binds"})


def other_resources() -> list[dict]:
    """Resources the brief asks about and whether this platform has data for them."""
    return [
        {"resource": "Runways", "status": "modelled", "kind": "assumption",
         "note": "Counts × configured rates in the capacity profile; no runway-in-use data, so designators are not assigned."},
        {"resource": "Taxiways", "status": "unavailable", "kind": "unavailable", "note": "No taxi-route or taxi-time data in the source files."},
        {"resource": "Apron / aircraft stands", "status": "simulation only", "kind": "simulated",
         "note": "No stand data. The earlier prototype contains a stand-allocation simulation on an INVENTED stand plan (audit F2); "
                 "use only as a labelled what-if.", "link": "/prototype/#tactical"},
        {"resource": "Terminal / passenger processing", "status": "unavailable", "kind": "unavailable", "note": "No passenger or terminal data."},
        {"resource": "Ground handling", "status": "unavailable", "kind": "unavailable", "note": "No handling-resource data."},
    ]


def _clean(o):
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return None if np.isnan(f) or np.isinf(f) else round(f, 4)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, (date, pd.Timestamp)):
        return str(o)
    return o
