"""Capacity profiles.

Evaluation: for flow f ∈ {total, arr, dep}, weekday w and local hour h the capacity is the value of the
LAST rule (by position) whose weekdays contain w and whose [start_hour, end_hour) contains h.
Every profile must contain a base rule per flow covering all weekdays and hours, so every hour has a value.

The default profile is seeded from config/eham.toml (values and their status/source). Runway
configurations are seeded as runway COUNTS × configured per-runway rates; no runway designators are
assigned because the data has no runway-in-use information.
"""
from __future__ import annotations

import hashlib
import json
import time
from datetime import datetime, timezone
from functools import lru_cache

from sqlalchemy import select, update

from ..core.settings import load_airport_config
from ..db import models as M
from ..db.session import session_scope

FLOWS = ("total", "arr", "dep")
STATUSES = ("public-reference", "assumption", "derived")
CONFIG_KEYS = {"total": "airport.hourly_movement_capacity", "arr": "airport.hourly_arrival_capacity", "dep": "airport.hourly_departure_capacity"}
_version = [0]  # bumped on every change in this process so cached evaluations refresh at once

# Several API workers each keep their own cache. Changes made in this process apply immediately (_bump);
# changes made by another worker are picked up within STAMP_TTL_S, because the cache key is a digest
# of the profile's rules read from the database (not a process-local counter).
STAMP_TTL_S = 5.0
_ttl: dict[tuple, tuple[float, object]] = {}


def _cached(key: tuple, fn):
    hit = _ttl.get(key)
    now = time.monotonic()
    if hit is not None and hit[0] > now:
        return hit[1]
    val = fn()
    _ttl[key] = (now + STAMP_TTL_S, val)
    return val


def _now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _bump():
    _version[0] += 1
    _ttl.clear()
    _caps_table.cache_clear()


def _stamp(pid: int) -> str:
    """Digest of the profile's rules as stored now (cheap: a profile has a few dozen rules)."""
    def load():
        with session_scope() as s:
            rows = s.execute(select(M.CapacityRule.id, M.CapacityRule.position, M.CapacityRule.flow, M.CapacityRule.weekdays_json,
                                    M.CapacityRule.start_hour, M.CapacityRule.end_hour, M.CapacityRule.value, M.CapacityRule.status,
                                    M.CapacityRule.source).where(M.CapacityRule.profile_id == pid)).all()
        return hashlib.sha256(repr(sorted(tuple(r) for r in rows)).encode()).hexdigest()[:16]
    return _cached(("stamp", pid), load)


def ensure_default(actor: str = "system") -> int:
    """Create and activate the default profile from config/eham.toml if no profile exists."""
    with session_scope() as s:
        p = s.execute(select(M.CapacityProfile).where(M.CapacityProfile.active.is_(True))).scalar_one_or_none()
        if p is not None:
            return p.id
        any_p = s.execute(select(M.CapacityProfile)).first()
        if any_p is not None:
            any_p[0].active = True
            return any_p[0].id
    cfg = load_airport_config()
    with session_scope() as s:
        prof = M.CapacityProfile(name="Default (config/eham.toml)", description=f"Seeded from config sha256 {cfg.sha256[:12]}",
                                 active=True, created_by=actor, created_utc=_now())
        s.add(prof)
        s.flush()
        for i, f in enumerate(FLOWS):
            c = cfg.capacity(CONFIG_KEYS[f])
            s.add(M.CapacityRule(profile_id=prof.id, position=i, flow=f, weekdays_json="[0,1,2,3,4,5,6]", start_hour=0, end_hour=24,
                                 value=float(c["value"]), status=c["status"], source=c["source"], label=f"Base {f}"))
        ra, rd = cfg.capacity("runway.arrival_rate_per_hour"), cfg.capacity("runway.departure_rate_per_hour")
        for na, nd in ((1, 1), (2, 1), (1, 2), (2, 2), (3, 1), (1, 3)):
            s.add(M.RunwayConfig(profile_id=prof.id, name=f"{na} landing + {nd} take-off", n_arr=na, n_dep=nd,
                                 arr_capacity=na * float(ra["value"]), dep_capacity=nd * float(rd["value"]),
                                 status="assumption", source=f"count × per-runway rates ({ra['source']}; {rd['source']})"))
        pid = prof.id
    _bump()
    return pid


def active_id() -> int:
    return _cached(("active",), ensure_default)


def _table(pid: int | None) -> dict:
    pid = pid or active_id()
    return _caps_table(pid, _stamp(pid))


@lru_cache(maxsize=8)
def _caps_table(pid: int, stamp: str) -> dict:
    """{(flow, weekday, hour): (value, status, source, rule_id)} for all 3×7×24 cells."""
    with session_scope() as s:
        rules = s.execute(select(M.CapacityRule).where(M.CapacityRule.profile_id == pid).order_by(M.CapacityRule.position, M.CapacityRule.id)).scalars().all()
        out = {}
        for r in rules:
            wds = json.loads(r.weekdays_json)
            for w in wds:
                for h in range(r.start_hour, r.end_hour):
                    out[(r.flow, w, h)] = (float(r.value), r.status, r.source, r.id)
    missing = [(f, w, h) for f in FLOWS for w in range(7) for h in range(24) if (f, w, h) not in out]
    if missing:
        raise ValueError(f"profile {pid} leaves {len(missing)} flow/weekday/hour cells without capacity, e.g. {missing[:3]}")
    return out


def caps(weekday: int, hour: int, pid: int | None = None) -> dict:
    """{'total': (value, status, source, rule_id), 'arr': ..., 'dep': ...} for one weekday & local hour."""
    t = _table(pid)
    return {f: t[(f, weekday, hour)] for f in FLOWS}


def cap_value(flow: str, weekday: int, hour: int, pid: int | None = None) -> float:
    return _table(pid)[(flow, weekday, hour)][0]


def base_meta(pid: int | None = None) -> dict:
    """Status/source of the base (all-hours) rules — used for labels in other modules."""
    t = _table(pid)
    vals = {f: sorted({v[0] for k, v in t.items() if k[0] == f}) for f in FLOWS}
    sts = {f: sorted({v[1] for k, v in t.items() if k[0] == f}) for f in FLOWS}
    return {f: {"values": vals[f], "statuses": sts[f], "varies_by_hour": len(vals[f]) > 1} for f in FLOWS}


# --------------------------------------------------------------------------- read / edit (audited by the API layer)
def get_profile(pid: int) -> dict | None:
    with session_scope() as s:
        p = s.get(M.CapacityProfile, pid)
        if p is None:
            return None
        rules = s.execute(select(M.CapacityRule).where(M.CapacityRule.profile_id == pid).order_by(M.CapacityRule.position, M.CapacityRule.id)).scalars().all()
        rcs = s.execute(select(M.RunwayConfig).where(M.RunwayConfig.profile_id == pid).order_by(M.RunwayConfig.n_arr + M.RunwayConfig.n_dep, M.RunwayConfig.id)).scalars().all()
        return {"id": p.id, "name": p.name, "description": p.description, "active": p.active, "parent_id": p.parent_id,
                "created_by": p.created_by, "created_utc": str(p.created_utc),
                "rules": [{"id": r.id, "position": r.position, "flow": r.flow, "weekdays": json.loads(r.weekdays_json), "start_hour": r.start_hour,
                           "end_hour": r.end_hour, "value": r.value, "status": r.status, "source": r.source, "label": r.label} for r in rules],
                "runway_configs": [{"id": c.id, "name": c.name, "n_arr": c.n_arr, "n_dep": c.n_dep, "arr_capacity": c.arr_capacity,
                                    "dep_capacity": c.dep_capacity, "total": c.arr_capacity + c.dep_capacity, "status": c.status, "source": c.source} for c in rcs]}


def list_profiles() -> list[dict]:
    ensure_default()
    with session_scope() as s:
        return [{"id": p.id, "name": p.name, "active": p.active, "parent_id": p.parent_id, "created_by": p.created_by, "created_utc": str(p.created_utc)}
                for p in s.execute(select(M.CapacityProfile).order_by(M.CapacityProfile.id)).scalars()]


def copy_profile(src: int, name: str, actor: str, description: str | None = None) -> int:
    """New editable draft profile copied from ``src`` (profiles are edited as copies, so history stays intact)."""
    p = get_profile(src)
    if p is None:
        raise LookupError(src)
    with session_scope() as s:
        new = M.CapacityProfile(name=name, description=description or f"Copy of {p['name']}", active=False, parent_id=src,
                                created_by=actor, created_utc=_now())
        s.add(new)
        s.flush()
        for r in p["rules"]:
            s.add(M.CapacityRule(profile_id=new.id, position=r["position"], flow=r["flow"], weekdays_json=json.dumps(r["weekdays"]),
                                 start_hour=r["start_hour"], end_hour=r["end_hour"], value=r["value"], status=r["status"], source=r["source"], label=r["label"]))
        for c in p["runway_configs"]:
            s.add(M.RunwayConfig(profile_id=new.id, name=c["name"], n_arr=c["n_arr"], n_dep=c["n_dep"], arr_capacity=c["arr_capacity"],
                                 dep_capacity=c["dep_capacity"], status=c["status"], source=c["source"]))
        return new.id


def _check_editable(s, pid: int) -> M.CapacityProfile:
    p = s.get(M.CapacityProfile, pid)
    if p is None:
        raise LookupError(pid)
    if p.active:
        raise PermissionError("the active profile is read-only: copy it, edit the copy, then activate the copy")
    return p


def validate_rule(r: dict) -> None:
    if r["flow"] not in FLOWS:
        raise ValueError("flow must be total, arr or dep")
    if not r["weekdays"] or any(w not in range(7) for w in r["weekdays"]):
        raise ValueError("weekdays must be a non-empty subset of 0..6")
    if not (0 <= r["start_hour"] < r["end_hour"] <= 24):
        raise ValueError("need 0 ≤ start_hour < end_hour ≤ 24")
    if not (0 <= r["value"] <= 300):
        raise ValueError("value must be 0..300 movements per hour")
    if r["status"] not in STATUSES:
        raise ValueError(f"status must be one of {STATUSES}")
    if not (r.get("source") or "").strip():
        raise ValueError("every capacity value needs a source (or an explicit assumption statement)")


def add_rule(pid: int, r: dict) -> int:
    validate_rule(r)
    with session_scope() as s:
        _check_editable(s, pid)
        pos = (max([x.position for x in s.execute(select(M.CapacityRule).where(M.CapacityRule.profile_id == pid)).scalars()], default=-1) + 1)
        row = M.CapacityRule(profile_id=pid, position=pos, flow=r["flow"], weekdays_json=json.dumps(sorted(set(r["weekdays"]))),
                             start_hour=r["start_hour"], end_hour=r["end_hour"], value=float(r["value"]), status=r["status"],
                             source=r["source"].strip(), label=r.get("label"))
        s.add(row)
        s.flush()
        rid = row.id
    _bump()
    return rid


def delete_rule(pid: int, rid: int) -> dict:
    with session_scope() as s:
        _check_editable(s, pid)
        r = s.get(M.CapacityRule, rid)
        if r is None or r.profile_id != pid:
            raise LookupError(rid)
        snapshot = {"flow": r.flow, "weekdays": json.loads(r.weekdays_json), "start_hour": r.start_hour, "end_hour": r.end_hour, "value": r.value}
        s.delete(r)
    try:
        _caps_table.__wrapped__(pid, "")        # the profile must still cover every hour
    except ValueError:
        add_rule(pid, {**snapshot, "status": "assumption", "source": "restored: deletion would leave hours without capacity"})
        raise ValueError("deleting this rule would leave hours without capacity; it was restored")
    _bump()
    return snapshot


def upsert_runway_config(pid: int, c: dict) -> int:
    if not (0 <= c["n_arr"] <= 4 and 0 <= c["n_dep"] <= 4 and c["n_arr"] + c["n_dep"] >= 1):
        raise ValueError("runway counts must be 0..4 and at least one runway")
    if c["status"] not in STATUSES or not (c.get("source") or "").strip():
        raise ValueError("status and source are required")
    with session_scope() as s:
        _check_editable(s, pid)
        row = M.RunwayConfig(profile_id=pid, name=c["name"], n_arr=c["n_arr"], n_dep=c["n_dep"], arr_capacity=float(c["arr_capacity"]),
                             dep_capacity=float(c["dep_capacity"]), status=c["status"], source=c["source"].strip())
        s.add(row)
        s.flush()
        return row.id


def activate(pid: int) -> None:
    _caps_table.__wrapped__(pid, "")         # refuse profiles that do not cover every hour
    with session_scope() as s:
        if s.get(M.CapacityProfile, pid) is None:
            raise LookupError(pid)
        s.execute(update(M.CapacityProfile).values(active=False))
        s.get(M.CapacityProfile, pid).active = True
    _bump()
