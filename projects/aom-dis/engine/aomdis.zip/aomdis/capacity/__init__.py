"""Capacity management: versioned capacity profiles (hourly rules per flow + runway configurations)
and the capacity analysis engine. The active profile is the single capacity source for all modules."""
