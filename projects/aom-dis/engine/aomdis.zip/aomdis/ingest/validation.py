"""Flight-data validation suite (data-quality requirement DQ-1…DQ-9).

Runs against the warehouse of one dataset version and returns one result per check:
    {id, title, severity, definition, checked, failing, status, examples}
status = "pass" (failing == 0), or the check's severity ("error" | "warning" | "info") when rows fail.
"error" means the warehouse violates an invariant the analytics rely on; "warning" means a data
property analysts must know about (it is reported, not "fixed"); "info" is descriptive.

Nothing here modifies data. Every check is a SQL or pandas expression that can be re-run by hand
(the definition text states it).
"""
from __future__ import annotations

from datetime import datetime, timezone

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..core.settings import load_airport_config
from ..db.session import engine
from .pipeline import latest_dataset_version

MAX_EXAMPLES = 5


def _q(c, sql: str, **p) -> pd.DataFrame:
    return pd.read_sql(text(sql), c, params=p)


def _result(cid: str, title: str, severity: str, definition: str, checked: int, bad: pd.DataFrame) -> dict:
    failing = int(len(bad))
    ex = bad.head(MAX_EXAMPLES).astype(object).where(bad.head(MAX_EXAMPLES).notna(), None)
    return {"id": cid, "title": title, "severity": severity, "definition": definition, "checked": int(checked),
            "failing": failing, "status": "pass" if failing == 0 else severity,
            "examples": [{k: (str(v) if v is not None and not isinstance(v, (int, float, str, bool)) else v) for k, v in r.items()}
                         for r in ex.to_dict("records")]}


def run(dsv: str | None = None, url: str | None = None) -> dict:
    dsv = dsv or latest_dataset_version(url)
    if dsv is None:
        raise LookupError("no complete dataset version; run `python -m aomdis ingest`")
    tz = load_airport_config().timezone
    out = []
    with engine(url).connect() as c:
        mv = _q(c, "select id, callsign, direction, actual_utc, local_date, local_hour, utc_offset_min, source_flight_id "
                   "from movement where dataset_version_id=:d", d=dsv)
        n = len(mv)
        mv["actual_utc"] = pd.to_datetime(mv["actual_utc"])

        # DQ-1 required fields
        bad = mv[mv["actual_utc"].isna() | mv["callsign"].isna() | (mv["callsign"].astype(str).str.strip() == "") | mv["direction"].isna()]
        out.append(_result("DQ-1", "Required movement fields present", "error",
                           "actual_utc, callsign and direction are non-empty for every movement", n, bad[["id", "callsign", "direction", "actual_utc"]]))

        # DQ-2 direction domain
        bad = mv[~mv["direction"].isin(["ARR", "DEP"])]
        out.append(_result("DQ-2", "Direction is ARR or DEP", "error", "direction ∈ {ARR, DEP}", n, bad[["id", "direction"]]))

        # DQ-3 duplicates
        key = ["callsign", "direction", "actual_utc"]
        dup = mv[mv.duplicated(key, keep=False)].sort_values(key)
        out.append(_result("DQ-3", "No duplicate movements", "warning",
                           "no two movements share callsign, direction and actual runway time (UTC)", n, dup[["id", *key]]))

        # DQ-4 local time consistent with UTC (Europe/Amsterdam, DST-aware)
        loc = mv["actual_utc"].dt.tz_localize("UTC").dt.tz_convert(tz)
        exp_date = loc.dt.date
        exp_hour = loc.dt.hour
        exp_off = (loc.dt.tz_localize(None) - mv["actual_utc"]).dt.total_seconds() / 60
        incon = mv[(pd.to_datetime(mv["local_date"]).dt.date != exp_date) | (mv["local_hour"] != exp_hour) | (mv["utc_offset_min"] != exp_off.round())]
        out.append(_result("DQ-4", "Local date/hour consistent with UTC", "error",
                           f"local_date, local_hour and utc_offset_min equal the conversion of actual_utc to {tz}", n,
                           incon[["id", "actual_utc", "local_date", "local_hour", "utc_offset_min"]]))

        # DQ-5 timestamps plausible: inside the dataset span and not in the future
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        lo, hi = mv["actual_utc"].min(), mv["actual_utc"].max()
        span_days = (hi - lo).days if n else 0
        bad = mv[mv["actual_utc"] > pd.Timestamp(now)]
        out.append(_result("DQ-5", "No movement timestamps in the future", "error",
                           f"actual_utc ≤ now (dataset span {lo} … {hi}, {span_days} days)", n, bad[["id", "actual_utc"]]))

        # DQ-6 referential integrity
        ri = [
            ("movement_match.movement_id → movement", "select mm.id, mm.movement_id from movement_match mm left join movement m on m.id=mm.movement_id "
             "join schedule_list l on l.id=mm.schedule_list_id where l.dataset_version_id=:d and mm.movement_id is not null and m.id is null"),
            ("movement_match.schedule_entry_id → schedule_entry", "select mm.id, mm.schedule_entry_id from movement_match mm left join schedule_entry e on e.id=mm.schedule_entry_id "
             "join schedule_list l on l.id=mm.schedule_list_id where l.dataset_version_id=:d and mm.schedule_entry_id is not null and e.id is null"),
            ("schedule_entry.schedule_list_id → schedule_list", "select e.id, e.schedule_list_id from schedule_entry e left join schedule_list l on l.id=e.schedule_list_id where l.id is null"),
            ("forecast.run_id → forecast_run", "select f.id, f.run_id from forecast f left join forecast_run r on r.id=f.run_id where r.id is null"),
            ("forecast_run.model_version_id → model_version", "select r.id, r.model_version_id from forecast_run r left join model_version v on v.id=r.model_version_id where v.id is null"),
        ]
        orphans = []
        checked = 0
        for name, sql in ri:
            df = _q(c, sql, d=dsv)
            if len(df):
                orphans.append(df.assign(relation=name).head(MAX_EXAMPLES))
        checked = int(_q(c, "select count(*) n from movement_match mm join schedule_list l on l.id=mm.schedule_list_id where l.dataset_version_id=:d", d=dsv)["n"].iloc[0])
        bad = pd.concat(orphans, ignore_index=True) if orphans else pd.DataFrame(columns=["relation"])
        out.append(_result("DQ-6", "Referential integrity", "error",
                           "; ".join(n for n, _ in ri) + " — no dangling references", checked, bad))

        # DQ-7 one-to-one matching per schedule list
        m = _q(c, "select mm.schedule_list_id, mm.schedule_entry_id, mm.movement_id, mm.state from movement_match mm "
                  "join schedule_list l on l.id=mm.schedule_list_id where l.dataset_version_id=:d", d=dsv)
        e_dup = m[m["schedule_entry_id"].notna() & m.duplicated(["schedule_list_id", "schedule_entry_id"], keep=False)]
        m_dup = m[m["movement_id"].notna() & m.duplicated(["schedule_list_id", "movement_id"], keep=False)]
        bad = pd.concat([e_dup.assign(problem="entry matched twice"), m_dup.assign(problem="movement matched twice")], ignore_index=True)
        out.append(_result("DQ-7", "Matching is one-to-one per schedule list", "error",
                           "within a schedule list, each schedule entry and each movement appears in at most one match row", len(m), bad))

        # DQ-8 match state domain and state/link consistency
        st = {"matched", "canceled", "confirmed_canceled", "added"}
        bad = m[~m["state"].isin(st) | ((m["state"] == "matched") & (m["schedule_entry_id"].isna() | m["movement_id"].isna()))
                | ((m["state"] == "added") & m["movement_id"].isna()) | (m["state"].isin(["canceled", "confirmed_canceled"]) & m["schedule_entry_id"].isna())]
        out.append(_result("DQ-8", "Match states consistent with their links", "error",
                           "state ∈ {matched, canceled, confirmed_canceled, added}; matched has entry+movement, added has a movement, canceled has an entry",
                           len(m), bad))

        # DQ-9 hourly outliers (informational; reported, never removed)
        h = mv.groupby(["local_date", "local_hour"]).size().rename("n").reset_index()
        h["wd"] = pd.to_datetime(h["local_date"]).dt.day_of_week
        g = h.groupby(["wd", "local_hour"])["n"]
        med = g.transform("median")
        mad = g.transform(lambda s: (s - s.median()).abs().median()).replace(0, np.nan).fillna(3.0)
        h["robust_z"] = ((h["n"] - med) / (1.4826 * mad)).round(2)
        bad = h[h["robust_z"].abs() >= 4].sort_values("robust_z")
        out.append(_result("DQ-9", "Hourly movement counts without extreme outliers", "info",
                           "robust z = (n − median) / (1.4826·MAD) per weekday-hour over the whole dataset; |z| ≥ 4 listed. "
                           "Outliers are reported, never removed (they include real disruptions such as 18 Feb 2022).",
                           len(h), bad[["local_date", "local_hour", "n", "robust_z"]]))

    summary = {s: sum(1 for r in out if r["status"] == s) for s in ("pass", "error", "warning", "info")}
    return {"dataset_version": dsv, "checked_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "summary": summary, "ok": summary["error"] == 0, "checks": out}
