"""Ingestion: raw EHAM 2022 files -> validated, normalized, versioned warehouse.

Stages
1. register   checksum every raw file; dataset_version id = sha256(file checksums + config + code version)
2. validate   data-quality checks -> data_quality_issue rows (+ handling decision)
3. transform  UTC normalisation, Europe/Amsterdam local fields, sector-row collapse, identifier parsing
4. load       reference tables, movements, schedule lists/entries, callsign map, capacity parameters
5. match      fpred one-to-one matching per schedule list -> movement_match (inferred cancellations)

Idempotent: an existing *complete* dataset version with the same id is not loaded again.
Raw files are only read, never modified.
"""
from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from sqlalchemy import delete, func, select, text

import fpred
from fpred import config as fconfig
from fpred import loaders as floaders
from fpred.identifiers import build_airline_map, build_cdm_callsigns, clean, parse, reverse_airline_map
from fpred.matching import match as fpred_match

from .. import __version__
from ..core import reference as ref
from ..core.settings import AirportConfig, load_airport_config, settings
from ..core.timeutil import local_day_bounds_utc, local_fields
from ..db import models as M
from ..db.session import engine, migrate, session_scope

log = logging.getLogger("aomdis.ingest")

KINDS = {
    fconfig.REALISATION_FILE: ("realisation", "Realised EHAM movements (actual runway times)"),
    fconfig.CDM_FILE: ("cdm", "A-CDM extract: flight number <-> callsign, scheduled/actual times with UTC offsets"),
    fconfig.AIRLINE_MAP_FILE: ("airline_map", "Hand-made IATA -> ICAO airline table (2022)"),
    fconfig.OPENFLIGHTS_FILE: ("reference", "OpenFlights airline reference (third party)"),
}


def _sha(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


@dataclass
class Issue:
    source: str | None
    check: str
    severity: str
    rows: int
    message: str
    handling: str


@dataclass
class IngestResult:
    dataset_version: str
    skipped: bool
    counts: dict = field(default_factory=dict)
    issues: list[Issue] = field(default_factory=list)


def files_manifest(raw_dir) -> list[dict]:
    out = []
    for p in sorted(raw_dir.glob("*")):
        if not p.is_file():
            continue
        if p.name in KINDS:
            kind, desc = KINDS[p.name]
        elif p.name.lower().startswith("flight list"):
            kind, desc = "schedule_list", "Published traffic forecast list (one row per airspace sector)"
        else:
            continue
        out.append({"path": p, "name": p.name, "kind": kind, "description": desc, "sha256": _sha(p), "bytes": p.stat().st_size})
    return out


def dataset_id(manifest: list[dict], cfg: AirportConfig) -> str:
    h = hashlib.sha256()
    for f in manifest:
        h.update(f"{f['name']}:{f['sha256']};".encode())
    h.update(f"config:{cfg.sha256};code:{__version__};fpred:{fpred.__version__}".encode())
    return h.hexdigest()[:32]


def _bulk(conn, table: str, df: pd.DataFrame) -> None:
    if len(df):
        df.to_sql(table, conn, if_exists="append", index=False, chunksize=5000)


def _next_id(conn, model) -> int:
    return int(conn.execute(select(func.coalesce(func.max(model.id), 0))).scalar()) + 1


def full_local_days(start_utc: pd.Timestamp, end_utc: pd.Timestamp, tz: str) -> list:
    """Local calendar days entirely inside [start_utc, end_utc]."""
    days = pd.date_range((start_utc - pd.Timedelta(days=1)).normalize(), end_utc.normalize() + pd.Timedelta(days=1))
    out = []
    for d in days:
        a, b = local_day_bounds_utc(d.date(), tz)
        if a >= start_utc and b <= end_utc:
            out.append(d.date())
    return out


def ingest(force: bool = False, url: str | None = None) -> IngestResult:
    st = settings()
    cfg = load_airport_config()
    tz = cfg.timezone
    if cfg.naive_tz != "UTC":
        raise NotImplementedError("only UTC naive timestamps are supported (see docs/PHASE0_AUDIT.md §3.1)")
    migrate(url)
    manifest = files_manifest(st.raw_dir)
    kinds = {f["kind"] for f in manifest}
    for need in ("realisation", "schedule_list", "cdm", "airline_map"):
        if need not in kinds:
            raise FileNotFoundError(f"missing raw input of kind {need!r} in {st.raw_dir}")
    dsv = dataset_id(manifest, cfg)

    with session_scope(url) as s:
        existing = s.get(M.DatasetVersion, dsv)
        if existing is not None and existing.status == "complete" and not force:
            return IngestResult(dsv, True)
        if existing is not None:
            _purge(s, dsv)
        s.add(M.DatasetVersion(id=dsv, created_utc=_now(), config_sha256=cfg.sha256,
                               code_version=f"aomdis-{__version__}/fpred-{fpred.__version__}", status="loading", notes=None))

    issues: list[Issue] = []
    counts: dict = {}
    eng = engine(url)
    with eng.begin() as conn:
        # ---- 1. register sources
        src_ids = {}
        for f in manifest:
            res = conn.execute(M.DataSource.__table__.insert().values(
                dataset_version_id=dsv, file_name=f["name"], kind=f["kind"], sha256=f["sha256"], bytes=f["bytes"],
                rows_raw=0, rows_loaded=0, timezone_assumed={"realisation": "UTC", "schedule_list": "UTC", "cdm": "explicit offset"}.get(f["kind"], "n/a (no timestamps)"),
                description=f["description"]))
            src_ids[f["name"]] = res.inserted_primary_key[0]

        def set_rows(name, raw, loaded):
            conn.execute(M.DataSource.__table__.update().where(M.DataSource.id == src_ids[name]).values(rows_raw=raw, rows_loaded=loaded))

        # ---- 2+3. reference: airline map, CDM callsigns
        hm = floaders.load_handmade_airlines(st.raw_dir)
        of = floaders.load_openflights(st.raw_dir)
        dup_codes = int(hm["airline"].dropna().duplicated().sum())
        if dup_codes:
            issues.append(Issue(fconfig.AIRLINE_MAP_FILE, "duplicate_airline_code", "warn", dup_codes,
                                f"{dup_codes} IATA codes appear more than once in the hand-made table",
                                "highest-count mapping wins (fpred.identifiers.build_airline_map)"))
        miss = int(hm[["airline", "callsign"]].isna().any(axis=1).sum())
        if miss:
            issues.append(Issue(fconfig.AIRLINE_MAP_FILE, "missing_code", "info", miss, f"{miss} rows lack a code", "row ignored"))
        amap = build_airline_map(hm, of)
        set_rows(fconfig.AIRLINE_MAP_FILE, len(hm), len(hm) - miss)
        if of is not None:
            set_rows(fconfig.OPENFLIGHTS_FILE, len(of), len(of))

        cdm = floaders.load_cdm(st.raw_dir)
        cdm_missing = int(cdm["callsign"].isna().sum())
        issues.append(Issue(fconfig.CDM_FILE, "missing_callsign", "info", cdm_missing,
                            f"{cdm_missing} CDM rows ({cdm_missing / len(cdm):.1%}) have no callsign", "excluded from callsign map"))
        full = pd.read_csv(st.raw_dir / fconfig.CDM_FILE, dtype=str)
        cdm_dup = int(full.duplicated().sum())
        if cdm_dup:
            issues.append(Issue(fconfig.CDM_FILE, "duplicate_rows", "info", cdm_dup, f"{cdm_dup} rows are exact duplicates",
                                "no effect: the callsign map stores distinct (flight, callsign) pairs with occurrence counts"))
        cs = cdm.dropna()
        cs = cs.assign(fn=cs["flightName"].map(clean), cs=cs["callsign"].map(clean))
        rev = reverse_airline_map(amap)
        cs["flight_key"] = [(_key(fn, rev)) for fn in cs["fn"]]
        cmap = cs.dropna(subset=["flight_key"]).groupby(["flight_key", "cs"]).size().reset_index(name="occurrences")
        cmap = cmap.rename(columns={"cs": "callsign"}).assign(dataset_version_id=dsv)
        _bulk(conn, "callsign_map", cmap)
        set_rows(fconfig.CDM_FILE, len(cdm), int(cmap["occurrences"].sum()))
        counts["callsign_map"] = len(cmap)
        cdm_callsigns = build_cdm_callsigns(cdm, rev)

        # ---- realisation -> movement
        real = floaders.load_realisation(st.raw_dir)
        raw_real = pd.read_excel(st.raw_dir / fconfig.REALISATION_FILE, usecols=["FLIGHT_ID", "TIME_DEP", "TIME_ARR"])
        both = int((raw_real["TIME_DEP"].notna() & raw_real["TIME_ARR"].notna()).sum())
        neither = int((raw_real["TIME_DEP"].isna() & raw_real["TIME_ARR"].isna()).sum())
        if both or neither:
            issues.append(Issue(fconfig.REALISATION_FILE, "time_fields", "error", both + neither,
                                f"{both} rows with both and {neither} with neither TIME_DEP/TIME_ARR", "rows without a time are dropped"))
        dup_id = int(raw_real["FLIGHT_ID"].duplicated().sum())
        if dup_id:
            issues.append(Issue(fconfig.REALISATION_FILE, "duplicate_flight_id", "error", dup_id, "duplicate FLIGHT_ID", "kept first"))
        lf = local_fields(real["time"], tz)
        m_base = _next_id(conn, M.Movement)
        mov = pd.DataFrame({
            "id": m_base + real["real_idx"].to_numpy(),
            "source_flight_id": real["real_id"], "callsign": real["callsign"], "operator_icao": real["operator"],
            "aircraft_type": real["ac_type"], "direction": real["direction"], "adep": real["adep"], "dest": real["dest"],
            "other_airport": np.where(real["direction"] == "ARR", real["adep"], real["dest"]),
            "actual_utc": real["time"], "local_date": lf["local_date"], "local_hour": lf["local_hour"].astype(int),
            "utc_offset_min": lf["utc_offset_min"].astype(int), "source_time_raw": real["time"].dt.strftime("%Y-%m-%d %H:%M:%S"),
            "data_source_id": src_ids[fconfig.REALISATION_FILE], "dataset_version_id": dsv,
        })
        _bulk(conn, "movement", mov)
        set_rows(fconfig.REALISATION_FILE, len(raw_real), len(mov))
        counts["movement"] = len(mov)
        r0, r1 = real["time"].min(), real["time"].max()
        real_days = full_local_days(r0.floor("D"), r1, tz)
        partial = sorted({d for d in lf["local_date"].unique()} - set(real_days))
        issues.append(Issue(fconfig.REALISATION_FILE, "partial_days", "info", int(lf["local_date"].isin(partial).sum()),
                            f"local days only partly covered: {', '.join(map(str, partial))}",
                            "excluded from day-level metrics (coverage window "
                            f"{real_days[0]} .. {real_days[-1]})"))
        issues.append(Issue(fconfig.REALISATION_FILE, "timezone", "info", len(mov),
                            "naive timestamps interpreted as UTC (evidence: tools/tz_audit.py, offset 0.00 h vs CDM across DST)",
                            "stored as actual_utc + Europe/Amsterdam local_date/local_hour/utc_offset_min"))

        # ---- reference: airports, operators, aircraft types, runways
        others = pd.Series(pd.concat([mov["other_airport"]]).unique())
        ap = pd.DataFrame({"icao": others, "country_prefix": others.str[:2], "schengen_2022": others.map(ref.is_schengen)})
        ap = pd.concat([ap, pd.DataFrame([{"icao": cfg.icao, "country_prefix": cfg.icao[:2], "schengen_2022": True}])])
        ap = ap.drop_duplicates("icao")
        ap["iata"] = None
        ap["name"] = None
        ap["timezone"] = None
        ap.loc[ap["icao"] == cfg.icao, ["iata", "name", "timezone"]] = [cfg.raw["airport"]["iata"], cfg.raw["airport"]["name"], tz]
        existing_ap = set(r[0] for r in conn.execute(select(M.Airport.icao)))
        _bulk(conn, "airport", ap[~ap["icao"].isin(existing_ap)])
        existing_rw = set(r[0] for r in conn.execute(select(M.Runway.id)))
        rw = pd.DataFrame([{"id": r["id"], "airport_icao": cfg.icao, "name": r.get("name"), "status": r["status"], "source": r["source"]}
                           for r in cfg.raw.get("runway", []) if r["id"] not in existing_rw])
        _bulk(conn, "runway", rw)

        ops = {v: k for k, v in amap.items()}  # icao -> iata (first)
        observed = set(mov["operator_icao"].dropna())
        existing_op = set(r[0] for r in conn.execute(select(M.Operator.icao)))
        op_rows = [{"icao": o, "iata": ops.get(o), "name": None,
                    "source": "handmade" if o in set(hm["callsign"].dropna()) else ("openflights" if o in ops else "observed")}
                   for o in sorted(observed | set(amap.values())) if len(o) == 3 and o not in existing_op]
        _bulk(conn, "operator", pd.DataFrame(op_rows))

        # ---- schedule lists
        infos = floaders.list_schedules(st.raw_dir)
        lists = []
        s_base = _next_id(conn, M.ScheduleEntry)
        sched_frames = {}
        for info in infos:
            raw_rows = len(pd.read_csv(info.path, sep=";", dtype=str, keep_default_na=False, usecols=[0]))
            sch = floaders.load_schedule(info)
            src = src_ids[info.path.name]
            non_eham = raw_rows - int(sch["sector_rows"].sum())
            issues.append(Issue(info.path.name, "sector_rows", "info", int((sch["sector_rows"] - 1).sum()),
                                f"{int((sch['sector_rows'] > 1).sum())} movements listed once per airspace sector",
                                "collapsed to one schedule_entry per (flight, ADEP, DEST, time); sector_rows keeps the count"))
            issues.append(Issue(info.path.name, "non_eham_rows", "info", non_eham,
                                f"{non_eham} rows neither depart from nor arrive at EHAM (or have no parseable time)", "excluded"))
            issues.append(Issue(info.path.name, "no_sibt", "warn", int((sch["direction"] == "ARR").sum()),
                                "SIBT is empty for every arrival; planned arrival reference is FIR entry (ETO_EHFIRAM)",
                                "arrival delays are derived, not measured (planned_reference = ETO_EHFIRAM)"))
            slf = local_fields(sch["time"], tz)
            sch = sch.assign(**{c: slf[c] for c in slf.columns})
            res = conn.execute(M.ScheduleList.__table__.insert().values(
                name=info.name, season=info.season, published_date=info.published,
                coverage_start_local=min(slf["local_date"]), coverage_end_local=max(slf["local_date"]),
                data_source_id=src, dataset_version_id=dsv))
            list_id = res.inserted_primary_key[0]
            kinds_ = sch["flight_id"].map(lambda x: parse(x).kind)
            ops_ = [(_op(fid, amap)) for fid in sch["flight_id"]]
            ent = pd.DataFrame({
                "id": s_base + np.arange(len(sch)), "schedule_list_id": list_id, "flight_id": sch["flight_id"], "id_kind": kinds_,
                "operator_icao": ops_, "aircraft_type": sch["ac_type"], "direction": sch["direction"], "adep": sch["adep"],
                "dest": sch["dest"], "other_airport": np.where(sch["direction"] == "ARR", sch["adep"], sch["dest"]),
                "planned_utc": sch["time"], "planned_reference": sch["planned_reference"], "local_date": sch["local_date"],
                "local_hour": sch["local_hour"].astype(int), "utc_offset_min": sch["utc_offset_min"].astype(int),
                "sector_rows": sch["sector_rows"], "source_time_raw": sch["source_time_raw"],
            })
            _bulk(conn, "schedule_entry", ent)
            set_rows(info.path.name, raw_rows, len(ent))
            sched_frames[info.name] = (list_id, sch, ent["id"].to_numpy(), slf)
            s_base += len(sch)
            lists.append(info.name)
        counts["schedule_entry"] = int(sum(len(v[1]) for v in sched_frames.values()))
        counts["schedule_list"] = len(lists)

        # ---- matching (fpred engine, local-day window)
        n_match = 0
        mm_base = _next_id(conn, M.MovementMatch)
        for name, (list_id, sch, ent_ids, slf) in sched_frames.items():
            s0 = sch["time"].min().floor("D")
            s1 = sch["time"].max()
            days = sorted(set(full_local_days(s0, s1, tz)) & set(real_days))
            if not days:
                issues.append(Issue(None, "no_overlap", "info", 0, f"{name} does not overlap realised data", "not matched"))
                continue
            w0, _ = local_day_bounds_utc(days[0], tz)
            _, w1 = local_day_bounds_utc(days[-1], tz)
            f = fpred_match(sch, real, amap, cdm_callsigns, (w0, w1))
            flf = local_fields(f["time"], tz)
            out = pd.DataFrame({
                "id": mm_base + np.arange(len(f)), "schedule_list_id": list_id,
                "schedule_entry_id": [int(ent_ids[int(i)]) if pd.notna(i) else None for i in f["sched_idx"]],
                "movement_id": [int(m_base + int(i)) if pd.notna(i) else None for i in f["real_idx"]],
                "state": f["state"], "stage": f["stage"], "offset_min": f["offset_min"],
                "local_date": flf["local_date"], "local_hour": flf["local_hour"].astype(int), "direction": f["direction"],
                "engine": f"fpred-{fpred.__version__}",
            })
            _bulk(conn, "movement_match", out)
            mm_base += len(out)
            n_match += len(out)
            vc = f["state"].value_counts().to_dict()
            issues.append(Issue(None, "matching", "info", len(out),
                                f"{name}: {days[0]} .. {days[-1]} ({len(days)} local days) -> " + ", ".join(f"{k} {v}" for k, v in vc.items()),
                                "canceled/confirmed_canceled are INFERRED (no cancellation field exists)"))
        counts["movement_match"] = n_match

        # ---- aircraft types
        types = pd.Series(sorted(set(mov["aircraft_type"].dropna()) | set(pd.concat([v[1]["ac_type"] for v in sched_frames.values()]).dropna())))
        existing_t = set(r[0] for r in conn.execute(select(M.AircraftType.icao)))
        at = pd.DataFrame({"icao": types})
        at = at[~at["icao"].isin(existing_t) & (at["icao"].str.len() <= 8)]
        at["code_letter"] = at["icao"].map(ref.code_letter)
        at["wake"] = at["code_letter"].map(ref.WAKE)
        at["classification_source"] = np.where(at["icao"].map(ref.code_is_tabulated), "table", "default")
        _bulk(conn, "aircraft_type", at)
        defaulted = int((at["classification_source"] == "default").sum())
        issues.append(Issue(None, "aircraft_code_default", "info", defaulted,
                            f"{defaulted} aircraft types not in the code-letter table", "defaulted to code C (flagged)"))

        # ---- capacity parameters from config
        cp = pd.DataFrame([{"key": c["key"], "value_json": json.dumps(c["value"]), "unit": c["unit"], "status": c["status"],
                            "source": c["source"], "valid_from_utc": None, "valid_to_utc": None, "config_sha256": cfg.sha256}
                           for c in cfg.raw.get("capacity", [])])
        conn.execute(delete(M.CapacityParameter).where(M.CapacityParameter.config_sha256 == cfg.sha256))
        _bulk(conn, "capacity_parameter", cp)

        # ---- issues
        id_by_name = src_ids
        _bulk(conn, "data_quality_issue", pd.DataFrame([{
            "dataset_version_id": dsv, "data_source_id": id_by_name.get(i.source), "check_name": i.check, "severity": i.severity,
            "affected_rows": int(i.rows), "message": i.message, "handling": i.handling} for i in issues]))

        conn.execute(M.DatasetVersion.__table__.update().where(M.DatasetVersion.id == dsv).values(status="complete"))
    return IngestResult(dsv, False, counts, issues)


def _key(fn: str, rev: dict[str, str]) -> str | None:
    ident = parse(fn)
    if ident.kind == "icao" and ident.airline in rev:
        ident = parse(rev[ident.airline] + ident.number)
    return ident.flight_key


def _op(fid: str, amap: dict[str, str]) -> str | None:
    i = parse(fid)
    if i.kind == "icao":
        return i.airline
    if i.kind == "iata":
        return amap.get(i.airline)
    return None


def _purge(s, dsv: str) -> None:
    """Remove a (failed or forced) dataset version and everything loaded under it."""
    list_ids = [r[0] for r in s.execute(select(M.ScheduleList.id).where(M.ScheduleList.dataset_version_id == dsv))]
    if list_ids:
        s.execute(delete(M.MovementMatch).where(M.MovementMatch.schedule_list_id.in_(list_ids)))
        s.execute(delete(M.ScheduleEntry).where(M.ScheduleEntry.schedule_list_id.in_(list_ids)))
        s.execute(delete(M.ScheduleList).where(M.ScheduleList.id.in_(list_ids)))
    for model in (M.Movement, M.CallsignMap, M.DataQualityIssue, M.PerformanceMetric):
        s.execute(delete(model).where(model.dataset_version_id == dsv))
    s.execute(delete(M.DataSource).where(M.DataSource.dataset_version_id == dsv))
    s.execute(delete(M.DatasetVersion).where(M.DatasetVersion.id == dsv))
    s.flush()


def latest_dataset_version(url: str | None = None) -> str | None:
    with engine(url).connect() as c:
        r = c.execute(text("select id from dataset_version where status='complete' order by created_utc desc limit 1")).first()
        return r[0] if r else None
