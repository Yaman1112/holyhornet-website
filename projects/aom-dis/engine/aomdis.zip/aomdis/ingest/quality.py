"""Data-quality report built from the warehouse (not from raw files)."""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..core.settings import settings
from ..core.timeutil import hours_in_local_day
from ..db.session import engine
from ..core.settings import load_airport_config
from .pipeline import full_local_days, latest_dataset_version


def _records(df: pd.DataFrame) -> list[dict]:
    return df.astype(object).where(df.notna(), None).to_dict("records")


def report(url: str | None = None, dsv: str | None = None) -> dict:
    dsv = dsv or latest_dataset_version(url)
    if dsv is None:
        raise LookupError("no complete dataset version; run `python -m aomdis ingest`")
    with engine(url).connect() as c:
        q = lambda sql, **p: pd.read_sql(text(sql), c, params={"d": dsv, **p})  # noqa: E731
        ver = q("select * from dataset_version where id=:d").iloc[0].to_dict()
        src = q("select id, file_name, kind, sha256, bytes, rows_raw, rows_loaded, timezone_assumed, description "
                "from data_source where dataset_version_id=:d order by kind, file_name")
        iss = q("select i.check_name, i.severity, i.affected_rows, i.message, i.handling, s.file_name "
                "from data_quality_issue i left join data_source s on s.id=i.data_source_id where i.dataset_version_id=:d")
        daily = q("select local_date, direction, count(*) n from movement where dataset_version_id=:d group by 1,2")
        span = q("select min(actual_utc) a, max(actual_utc) b from movement where dataset_version_id=:d").iloc[0]
        lists = q("select l.id, l.name, l.published_date, l.coverage_start_local, l.coverage_end_local, count(e.id) entries "
                  "from schedule_list l join schedule_entry e on e.schedule_list_id=l.id where l.dataset_version_id=:d group by l.id")
        match = q("select l.name, m.state, count(*) n, min(m.local_date) d0, max(m.local_date) d1 from movement_match m "
                  "join schedule_list l on l.id=m.schedule_list_id where l.dataset_version_id=:d group by 1,2")
    d = daily.pivot_table(index="local_date", columns="direction", values="n", fill_value=0).reset_index()
    d["local_date"] = d["local_date"].astype(str)
    d["hours"] = d["local_date"].map(hours_in_local_day)
    d["total"] = d.get("ARR", 0) + d.get("DEP", 0)
    full = {str(x) for x in full_local_days(pd.Timestamp(span["a"]).floor("D"), pd.Timestamp(span["b"]), load_airport_config().timezone)}
    d["full_day"] = d["local_date"].isin(full)
    tot = d.loc[d["full_day"], "total"]
    med = tot.median()
    mad = (tot - med).abs().median() or 1
    d["robust_z"] = ((d["total"] - med) / (1.4826 * mad)).round(2).where(d["full_day"])
    return {
        "dataset_version": {k: str(v) for k, v in ver.items()},
        "sources": _records(src),
        "issues": _records(iss),
        "coverage": {
            "movement_days": [d["local_date"].min(), d["local_date"].max()],
            "full_local_days": [min(full), max(full), len(full)],
            "partial_days": sorted(set(d["local_date"]) - full),
            "dst_days": d[d["hours"] != 24][["local_date", "hours", "total"]].to_dict("records"),
            "low_traffic_days": _records(d[d["robust_z"] < -3.0][["local_date", "total", "robust_z"]]),
        },
        "daily_movements": _records(d),
        "schedule_lists": lists.astype({"published_date": str, "coverage_start_local": str, "coverage_end_local": str}).to_dict("records"),
        "matching": match.astype({"d0": str, "d1": str}).to_dict("records"),
    }


def write_report(rep: dict) -> str:
    out = settings().reports_dir
    out.mkdir(parents=True, exist_ok=True)
    p = out / f"data_quality_{rep['dataset_version']['id'][:12]}.json"
    p.write_text(json.dumps(rep, indent=1, default=str), encoding="utf-8")
    return str(p)
