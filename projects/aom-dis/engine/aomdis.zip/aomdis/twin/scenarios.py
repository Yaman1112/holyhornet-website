"""Twin scenarios: typed interventions → engine → KPIs, always paired with a baseline run of the same
day and basis so that engine artefacts cancel out (effects are reported as Δ vs baseline).

Intervention types (times are local HH:MM on the operational day; "24:00" = end of day):
  capacity       {flow: total|arr|dep|all, start, end, factor, cause: runway|weather|other}
  runway_limit   {max_runways, start, end}                    runway outage → only configurations with ≤ N runways
  demand_surge   {flow: all|ARR|DEP, start, end, factor > 1}  synthetic flights cloned from the window (seeded)
  delay_wave     {flow: all|ARR|DEP, start, end, shift_min, share}   share of flights in the window arrive later
  cancel         {flow: all|ARR|DEP, start, end, share}       decision what-if: cancel a share of flights (seeded)
Recorded events of the day with a capacity factor can be imported as capacity interventions.
Weather restrictions are user-entered capacity interventions: no weather data exists (never fabricated).
"""
from __future__ import annotations

import hashlib
import json
from datetime import date

import numpy as np
import pandas as pd

from ..core.timeutil import local_day_bounds_utc, local_to_utc, utc_to_local_hhmm
from . import engine as E
from . import model as TM

TYPES = ("capacity", "runway_limit", "demand_surge", "delay_wave", "cancel")
RECOVERY_QUEUE = 1.0


def _minute(day: date, hhmm: str, d0: pd.Timestamp) -> float:
    if hhmm == "24:00":
        return (local_day_bounds_utc(day)[1] - d0).total_seconds() / 60
    return (local_to_utc(day, hhmm) - d0).total_seconds() / 60


def _label(d0: pd.Timestamp, minute: float, day: date) -> str:
    ts = d0 + pd.Timedelta(minutes=float(minute))
    loc = ts.tz_localize("UTC").tz_convert("Europe/Amsterdam")
    return utc_to_local_hhmm(ts) + ("+1" if loc.date() != day else "")


def validate(spec: dict) -> None:
    if spec.get("basis") not in ("observed", "planned"):
        raise ValueError("basis must be observed or planned")
    for iv in spec.get("interventions", []):
        t = iv.get("type")
        if t not in TYPES:
            raise ValueError(f"unknown intervention type {t!r}")
        if iv["start"] >= iv["end"] and iv["end"] != "24:00":
            raise ValueError(f"{t}: end must be after start")
        if t == "capacity" and not (0 <= iv["factor"] <= 2 and iv.get("flow") in ("total", "arr", "dep", "all")):
            raise ValueError("capacity: factor 0..2 and flow total|arr|dep|all")
        if t == "runway_limit" and not (0 <= iv["max_runways"] <= 6):
            raise ValueError("runway_limit: max_runways 0..6")
        if t == "demand_surge" and not (1 < iv["factor"] <= 3):
            raise ValueError("demand_surge: factor must be in (1, 3]")
        if t == "delay_wave" and not (0 < iv["shift_min"] <= 720 and 0 < iv["share"] <= 1):
            raise ValueError("delay_wave: shift_min 1..720, share (0, 1]")
        if t == "cancel" and not (0 < iv["share"] <= 1):
            raise ValueError("cancel: share (0, 1]")


def _apply(inp: TM.TwinInputs, ivs: list[dict], seed: int):
    rng = np.random.default_rng(seed)
    F = inp.flights.copy()
    B = inp.bins
    fac = {k: np.ones(len(B)) for k in ("total", "arr", "dep")}
    limit = None
    windows = []
    cancelled = np.zeros(len(F), dtype=bool)
    d0 = inp.day_start_utc

    def sel(df, flow, a, b):
        m = (df["demand_min"] >= a) & (df["demand_min"] < b)
        return m & (df["direction"] == flow) if flow in ("ARR", "DEP") else m

    # demand changes first (they change the flight list)
    for iv in ivs:
        a, b = _minute(inp.day, iv["start"], d0), _minute(inp.day, iv["end"], d0)
        if iv["type"] == "demand_surge":
            src = F[sel(F, iv.get("flow", "all"), a, b) & ~F["synthetic"]]
            n_new = int(round(len(src) * (iv["factor"] - 1)))
            if n_new and len(src):
                pick = src.iloc[rng.integers(0, len(src), n_new)].copy()
                pick["demand_min"] = np.clip(pick["demand_min"] + rng.uniform(-10, 10, n_new), a, b - 0.01)
                pick["synthetic"] = True
                pick["fid"] = [f"S{i:04d}" for i in range(n_new)]
                pick["callsign"] = "synthetic"
                F = pd.concat([F, pick], ignore_index=True)
        elif iv["type"] == "delay_wave":
            m = sel(F, iv.get("flow", "all"), a, b).to_numpy()
            idx = np.flatnonzero(m)
            chosen = rng.choice(idx, size=int(round(len(idx) * iv["share"])), replace=False) if len(idx) else []
            F.loc[chosen, "demand_min"] = F.loc[chosen, "demand_min"] + iv["shift_min"]
    F = F.sort_values("demand_min", kind="stable").reset_index(drop=True)
    cancelled = np.zeros(len(F), dtype=bool)
    for iv in ivs:
        a, b = _minute(inp.day, iv["start"], d0), _minute(inp.day, iv["end"], d0)
        in_bins = (B["start_min"] >= a) & (B["start_min"] < b)
        if iv["type"] == "capacity":
            flows = ("total", "arr", "dep") if iv["flow"] == "all" else (iv["flow"],)
            for f in flows:
                fac[f] = np.where(in_bins, fac[f] * iv["factor"], fac[f])
            if iv["factor"] < 1:
                windows.append((a, b))
        elif iv["type"] == "runway_limit":
            limit = np.full(len(B), np.nan) if limit is None else limit
            limit = np.where(in_bins, np.fmin(limit, iv["max_runways"]) if not np.isnan(limit).all() else iv["max_runways"], limit)
            windows.append((a, b))
        elif iv["type"] == "cancel":
            idx = np.flatnonzero(sel(F, iv.get("flow", "all"), a, b).to_numpy() & ~cancelled)
            if len(idx):
                cancelled[rng.choice(idx, size=int(round(len(idx) * iv["share"])), replace=False)] = True
    return F, fac, limit, cancelled, windows


def _kpis(inp: TM.TwinInputs, R: pd.DataFrame, Q: pd.DataFrame, windows: list[tuple[float, float]]) -> dict:
    d0 = inp.day_start_utc
    day_end = (local_day_bounds_utc(inp.day)[1] - d0).total_seconds() / 60
    s = R[~R["cancelled"] & R["sim_min"].notna()]
    q = Q["queue_arr"] + Q["queue_dep"]
    imax = int(q.idxmax())
    rec = None
    if windows:
        e = max(b for _, b in windows)
        after = Q[(Q["start_min"] >= e) & (q < RECOVERY_QUEUE)]
        rec = None if after.empty else float(after["start_min"].iloc[0] - e)
    return {
        "flights": int(len(R)), "synthetic": int(R["synthetic"].sum()), "cancelled": int(R["cancelled"].sum()),
        "served": int(len(s)), "unserved": int(R["unserved"].sum()),
        "total_delay_min": float(s["delay_min"].sum()), "mean_delay_min": float(s["delay_min"].mean()) if len(s) else 0.0,
        "p95_delay_min": float(s["delay_min"].quantile(0.95)) if len(s) else 0.0,
        "delayed_15": int((s["delay_min"] > 15).sum()), "delayed_60": int((s["delay_min"] > 60).sum()),
        "max_queue": float(q.max()), "max_queue_at": _label(d0, Q["start_min"].iloc[imax], inp.day),
        "spill_after_midnight": int((s["sim_min"] >= day_end).sum()),
        "recovery_min": rec,
        "recovery_from": _label(d0, max(b for _, b in windows), inp.day) if windows else None,
    }


def _hourly(inp: TM.TwinInputs, R: pd.DataFrame, Q: pd.DataFrame) -> list[dict]:
    d0 = inp.day_start_utc
    B = inp.bins.assign(q=(Q["queue_arr"] + Q["queue_dep"]).to_numpy(), served=(Q["served_arr"] + Q["served_dep"]).to_numpy(),
                        rate=Q["rate_tot"].to_numpy())
    B["slot"] = (B["start_min"] // 60).astype(int)
    R = R.assign(slot=(R["demand_min"] // 60).astype(int))
    s = R[~R["cancelled"] & R["sim_min"].notna()]
    out = []
    for slot, g in B.groupby("slot"):
        dem = R[R["slot"] == slot]
        out.append({"slot": int(slot), "label": _label(d0, slot * 60, inp.day), "next_day": bool(g["next_day"].iloc[0]),
                    "demand": int(len(dem[~dem["cancelled"]])), "served": int(g["served"].sum()),
                    "capacity": round(float(g["rate"].mean()), 1), "queue_end": round(float(g["q"].iloc[-1]), 1),
                    "mean_delay": round(float(s[s["slot"] == slot]["delay_min"].mean()), 1) if (s["slot"] == slot).any() else None})
    return out


def _queue_series(inp: TM.TwinInputs, Q: pd.DataFrame) -> list[dict]:
    d0 = inp.day_start_utc
    return [{"t": _label(d0, r.start_min, inp.day), "arr": int(r.queue_arr), "dep": int(r.queue_dep), "config": r.runway_config if isinstance(r.runway_config, str) else None}
            for r in Q.iloc[::3].itertuples()]                     # every 15 min


def fingerprint(spec: dict) -> str:
    return hashlib.sha256(json.dumps(spec, sort_keys=True, default=str).encode()).hexdigest()[:16]


def run(spec: dict, include_flights: bool = False) -> dict:
    validate(spec)
    day = date.fromisoformat(str(spec["day"]))
    inp = TM.load(day, spec["basis"])
    seed = int(spec.get("seed", 42))
    ivs = list(spec.get("interventions", []))
    imported = []
    if spec.get("import_events"):
        for e in inp.events:
            if e["capacity_factor"] is not None and e["status"] in ("active", "closed"):
                iv = {"type": "capacity", "flow": "all", "start": e["start_local"], "end": e["end_local"] or "24:00",
                      "factor": e["capacity_factor"], "cause": e["category"], "label": f"{e['id']} ({e['kind']})"}
                ivs.append(iv)
                imported.append(iv)
    Fb = inp.flights
    Rb, Qb = E.run(Fb, inp.bins, {k: np.ones(len(inp.bins)) for k in ("total", "arr", "dep")}, None, inp.runway_configs)
    base = _kpis(inp, Rb, Qb, [])
    F, fac, limit, cancelled, windows = _apply(inp, ivs, seed)
    R, Q = E.run(F, inp.bins, fac, limit, inp.runway_configs, cancelled)
    k = _kpis(inp, R, Q, windows)
    delta = {key: (None if k[key] is None or base.get(key) is None else round(k[key] - base[key], 2))
             for key in ("total_delay_min", "mean_delay_min", "p95_delay_min", "delayed_15", "delayed_60", "max_queue", "spill_after_midnight", "unserved", "served")}
    res = {
        "kind": "simulated", "fingerprint": fingerprint(spec), "spec": spec, "imported_events": imported,
        "inputs": {"day": str(day), "basis": spec["basis"], "basis_kind": "actual" if spec["basis"] == "observed" else "scheduled",
                   "profile": inp.profile, "flights": int(len(inp.flights)), "runway_configs": [c["name"] for c in inp.runway_configs],
                   "capacity_status": "from active profile (values with their own status)", "weather": "not modelled: no weather data"},
        "baseline": base, "scenario": k, "delta_vs_baseline": delta,
        "hourly": _hourly(inp, R, Q), "baseline_hourly": _hourly(inp, Rb, Qb), "queue": _queue_series(inp, Q),
        "delay_histogram": _hist(R),
        "most_delayed": R[R["sim_min"].notna()].sort_values("delay_min", ascending=False).head(15)
            .assign(demand=lambda d: [_label(inp.day_start_utc, m, day) for m in d["demand_min"]],
                    simulated=lambda d: [_label(inp.day_start_utc, m, day) for m in d["sim_min"]])
            [["callsign", "direction", "other", "demand", "simulated", "delay_min", "synthetic"]].round(1).to_dict("records"),
    }
    if include_flights:
        res["flights"] = R.to_dict("records")
    return res


def _hist(R: pd.DataFrame) -> list[dict]:
    s = R[R["sim_min"].notna()]["delay_min"].clip(upper=240)
    edges = [0, 5, 15, 30, 60, 120, 241]
    labels = ["0–5", "5–15", "15–30", "30–60", "60–120", "≥120"]
    c = pd.cut(s, edges, right=False, labels=labels).value_counts().reindex(labels, fill_value=0)
    return [{"bucket": k, "flights": int(v)} for k, v in c.items()]


# Example assumptions placed on typical EHAM waves (morning 06–10, evening 17–21); users edit them.
PRESETS = {
    "runway_closure": {"title": "Runway outage in the morning wave: max 2 runways 07:00–10:00",
                       "interventions": [{"type": "runway_limit", "max_runways": 2, "start": "07:00", "end": "10:00"}]},
    "weather_restriction": {"title": "Low-visibility restriction 07:00–10:00 at 60 % capacity (user-entered, simulated)",
                            "interventions": [{"type": "capacity", "flow": "all", "start": "07:00", "end": "10:00", "factor": 0.6, "cause": "weather"}]},
    "demand_surge": {"title": "Demand +20 % in the evening wave 17:00–21:00",
                     "interventions": [{"type": "demand_surge", "flow": "all", "start": "17:00", "end": "21:00", "factor": 1.2}]},
    "delayed_wave": {"title": "Long-haul arrival wave 60 min late (05:00–08:00, 70 % of arrivals)",
                     "interventions": [{"type": "delay_wave", "flow": "ARR", "start": "05:00", "end": "08:00", "shift_min": 60, "share": 0.7}]},
    "closure_with_recovery": {"title": "Morning runway outage + recovery: cancel 10 % of ARRIVALS (the binding flow), +10 % capacity 10:00–13:00",
                              "interventions": [{"type": "runway_limit", "max_runways": 2, "start": "07:00", "end": "10:00"},
                                                {"type": "cancel", "flow": "ARR", "start": "07:00", "end": "10:00", "share": 0.1},
                                                {"type": "capacity", "flow": "all", "start": "10:00", "end": "13:00", "factor": 1.1, "cause": "other"}]},
}
