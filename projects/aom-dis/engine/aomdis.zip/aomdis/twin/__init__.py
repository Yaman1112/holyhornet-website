"""Digital twin: flight-level runway-queue simulation of a historical operational day with user-defined
interventions (capacity cuts, runway outages, weather restrictions, demand surges, delayed waves, recovery
strategies). Every output is SIMULATED; inputs are labelled actual / scheduled / predicted / assumption."""
