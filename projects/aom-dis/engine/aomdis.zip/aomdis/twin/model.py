"""Twin inputs: the demand (flights wanting the runway), the resources (capacity per 5-minute bin from the
active capacity profile and runway configurations) and the day's recorded events.

Demand bases
* observed  every realised movement of the day at its ACTUAL runway time (kind: actual). The real day already
            respects real capacity, so the baseline twin should show little delay; scenario effects are
            reported as differences from that baseline.
* planned   every flight of the plan-of-record list at its PREDICTED runway time (planned reference time +
            median offset learned in the 28 days before the day; kind: scheduled → predicted timing).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

import numpy as np
import pandas as pd

from ..capacity import profile as PR
from ..core.timeutil import local_day_bounds_utc
from ..tactical import flights as FL
from ..tactical import state as ST

BIN_MIN = 5
SPILL_H = 6          # simulate past local midnight so late queues can clear


@dataclass
class TwinInputs:
    day: date
    basis: str
    day_start_utc: pd.Timestamp
    flights: pd.DataFrame      # fid, callsign, direction, operator, other, demand_min (minutes from local midnight), synthetic
    bins: pd.DataFrame         # bin index, start_min, local_hour, weekday, c_tot, c_arr, c_dep (per hour rates)
    runway_configs: list[dict]
    events: list[dict]
    profile: dict


def demand(day: date, basis: str) -> tuple[pd.DataFrame, pd.Timestamp]:
    d0, _ = local_day_bounds_utc(day)
    if basis == "observed":
        T = FL.timeline(day, "23:59")
        T = T[T["actual_utc"].notna()]
        t = T["actual_utc"]
    elif basis == "planned":
        T = FL.timeline(day, "00:00")           # at 00:00 nothing has flown: every scheduled flight is 'expected'
        T = T[T["scheduled"]]
        t = T["predicted_utc"]
    else:
        raise ValueError("basis must be 'observed' or 'planned'")
    F = pd.DataFrame({
        "fid": [f"F{i:04d}" for i in range(len(T))],
        "callsign": T["callsign"].fillna(T["flight"]).to_numpy(),
        "flight": T["flight"].to_numpy(),
        "direction": T["direction"].to_numpy(),
        "operator": T["operator"].to_numpy(),
        "other": T["other"].to_numpy(),
        "demand_min": ((t - d0).dt.total_seconds() / 60).to_numpy(),
        "synthetic": False,
    })
    F = F[(F["demand_min"] >= 0) & (F["demand_min"] < 24 * 60 + 120)].sort_values("demand_min").reset_index(drop=True)
    return F, d0


def bins(day: date, day_start_utc: pd.Timestamp) -> pd.DataFrame:
    """5-minute bins from local midnight to midnight + SPILL_H, with the profile's hourly rates."""
    n = (24 + SPILL_H) * 60 // BIN_MIN
    start_min = np.arange(n) * BIN_MIN
    utc = day_start_utc + pd.to_timedelta(start_min, unit="min")
    loc = utc.tz_localize("UTC").tz_convert("Europe/Amsterdam")
    B = pd.DataFrame({"bin": np.arange(n), "start_min": start_min, "local_hour": loc.hour, "weekday": loc.day_of_week,
                      "next_day": loc.date != day})
    for f, col in (("total", "c_tot"), ("arr", "c_arr"), ("dep", "c_dep")):
        B[col] = [PR.cap_value(f, int(w), int(h)) for w, h in zip(B["weekday"], B["local_hour"])]
    return B


def load(day: date, basis: str) -> TwinInputs:
    F, d0 = demand(day, basis)
    if F.empty:
        raise LookupError(f"no {basis} demand for {day}")
    pid = PR.active_id()
    prof = PR.get_profile(pid)
    ev = ST.events_records(ST.events_on(day))
    return TwinInputs(day, basis, d0, F, bins(day, d0), prof["runway_configs"], ev, {"id": pid, "name": prof["name"]})
