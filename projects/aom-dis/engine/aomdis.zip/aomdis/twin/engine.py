"""Flight-level runway-queue engine (5-minute bins).

Per bin b and flow f ∈ {arr, dep} a capacity credit accrues at rate_f(b) · 5/60 movements, plus a joint
credit for the total rate. Credits may bank up to BURST_MIN minutes of capacity (runways can absorb short
bursts within the hourly rate). Flights enter their flow queue at their demand minute and are served first
come, first served (earliest demand across both flows first) while both the flow credit and the total
credit are ≥ 1. Served time = max(demand minute, bin start); delay = served − demand.

With a runway limit active, the bin uses the allowed configuration that serves most of the current queues;
flow rates become min(profile rate, configuration rate). Flights still queued at the end of the horizon
are reported as unserved. Conservation: served + unserved + cancelled = flights.
"""
from __future__ import annotations

from collections import deque

import numpy as np
import pandas as pd

from .model import BIN_MIN

BURST_MIN = 15


def run(F: pd.DataFrame, B: pd.DataFrame, fac: dict[str, np.ndarray], runway_limit: np.ndarray | None,
        configs: list[dict], cancelled: np.ndarray | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    n_b = len(B)
    F = F.sort_values("demand_min", kind="stable").reset_index(drop=True)
    cancelled = np.zeros(len(F), dtype=bool) if cancelled is None else cancelled
    sim = np.full(len(F), np.nan)
    order = [i for i in range(len(F)) if not cancelled[i]]
    ptr = 0
    q = {"ARR": deque(), "DEP": deque()}
    credit = {"ARR": 0.0, "DEP": 0.0, "TOT": 0.0}
    rows = []
    c_tot = B["c_tot"].to_numpy() * fac["total"]
    c_arr = B["c_arr"].to_numpy() * fac["arr"]
    c_dep = B["c_dep"].to_numpy() * fac["dep"]
    starts = B["start_min"].to_numpy()
    dem = F["demand_min"].to_numpy()
    dirs = F["direction"].to_numpy()
    for b in range(n_b):
        t0, t1 = starts[b], starts[b] + BIN_MIN
        while ptr < len(order) and dem[order[ptr]] < t1:
            i = order[ptr]
            q[dirs[i]].append(i)
            ptr += 1
        ra, rd, rt = c_arr[b], c_dep[b], c_tot[b]
        cfg_name = None
        if runway_limit is not None and not np.isnan(runway_limit[b]):
            allowed = [c for c in configs if c["n_arr"] + c["n_dep"] <= runway_limit[b]]
            if allowed:
                na, nd = len(q["ARR"]), len(q["DEP"])
                best = max(allowed, key=lambda c: (min(na, c["arr_capacity"] * BIN_MIN / 60) + min(nd, c["dep_capacity"] * BIN_MIN / 60),
                                                   -(c["n_arr"] + c["n_dep"])))
                ra, rd, cfg_name = min(ra, best["arr_capacity"]), min(rd, best["dep_capacity"]), best["name"]
            else:
                ra = rd = 0.0
        for k, r in (("ARR", ra), ("DEP", rd), ("TOT", rt)):
            credit[k] = min(credit[k] + r * BIN_MIN / 60, max(r * BURST_MIN / 60, 1.0) if r > 0 else 0.0)
        served = {"ARR": 0, "DEP": 0}
        while credit["TOT"] >= 1:
            heads = [(dem[q[k][0]], k) for k in ("ARR", "DEP") if q[k] and credit[k] >= 1]
            if not heads:
                break
            _, k = min(heads)
            i = q[k].popleft()
            sim[i] = max(dem[i], t0)
            credit[k] -= 1
            credit["TOT"] -= 1
            served[k] += 1
        rows.append((b, t0, len(q["ARR"]), len(q["DEP"]), served["ARR"], served["DEP"], ra, rd, rt, cfg_name))
    out = F.copy()
    out["cancelled"] = cancelled
    out["sim_min"] = sim
    out["delay_min"] = out["sim_min"] - out["demand_min"]
    out["unserved"] = ~cancelled & np.isnan(sim)
    Q = pd.DataFrame(rows, columns=["bin", "start_min", "queue_arr", "queue_dep", "served_arr", "served_dep", "rate_arr", "rate_dep", "rate_tot", "runway_config"])
    return out, Q
