"""Authentication, role-based access control and audit logging.

* Passwords: PBKDF2-HMAC-SHA256, 600 000 iterations, per-user salt (stdlib only).
* Sessions: HS256 JWT in an httpOnly, SameSite=Lax cookie (or a Bearer header for API clients).
  Secret from ``AOMDIS_SECRET_KEY``; without it a random development key is created in the
  (git-ignored) warehouse folder and a warning is logged.
* CSRF: state-changing requests authenticated by cookie must carry the header
  ``X-AOMDIS-CSRF: 1`` (browsers do not let other sites set custom headers).
* Login throttling: 5 failures per user and 50 per client address per 15 minutes, counted in the
  database (table ``login_failure``) so every API worker enforces the same limit.
* "Log out everywhere": tokens carry the account's ``session_version`` (claim ``sv``); bumping it
  ends every existing session of that account.
* Sessions end when the account is disabled, its role changes or its password is reset: every request
  re-reads the user, and the token carries a fingerprint of the password hash.
* Production mode (``AOMDIS_ENV=production``) refuses to start without a strong ``AOMDIS_SECRET_KEY``
  and ``AOMDIS_COOKIE_SECURE=1`` (see ``check_production_settings``).
* The platform is decision support: no role grants operational/ATC authority.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import secrets
from datetime import datetime, timedelta, timezone
from functools import lru_cache

import jwt
from fastapi import Depends, HTTPException, Request
from sqlalchemy import delete, func, select, update

from ..core.settings import ROOT
from ..db import models as M
from ..db.session import session_scope

log = logging.getLogger("aomdis.auth")

COOKIE = "aomdis_session"
CSRF_HEADER = "x-aomdis-csrf"
TOKEN_HOURS = 8
PBKDF2_ITER = int(os.environ.get("AOMDIS_PBKDF2_ITERATIONS", "600000"))   # lower only in the browser demo

MODULES = ["command", "strategic", "pretactical", "tactical", "capacity", "twin", "intel", "postops", "data", "models", "admin"]

ROLES: dict[str, dict] = {
    "admin": {"label": "System Administrator", "view": MODULES,
              "manage": ["users", "data", "events", "models", "scenarios", "capacity"]},
    "ops_manager": {"label": "Airport Operations Manager", "view": [m for m in MODULES if m != "admin"],
                    "manage": ["events", "scenarios", "capacity"]},
    "capacity_planner": {"label": "Capacity Planner",
                         "view": ["command", "strategic", "pretactical", "capacity", "twin", "postops", "data"],
                         "manage": ["scenarios", "capacity"]},
    "flight_ops_analyst": {"label": "Flight Operations Analyst",
                           "view": ["command", "pretactical", "tactical", "capacity", "postops", "intel", "data"],
                           "manage": ["events"]},
    "data_scientist": {"label": "Data Scientist",
                       "view": ["command", "strategic", "pretactical", "postops", "intel", "data", "models"],
                       "manage": ["data", "models"]},
    "executive": {"label": "Executive Viewer", "view": ["command", "strategic", "postops", "intel"], "manage": []},
}


def permissions(role: str) -> set[str]:
    r = ROLES.get(role)
    if r is None:
        return set()
    return {f"view:{m}" for m in r["view"]} | {f"manage:{m}" for m in r["manage"]}


# --------------------------------------------------------------------------- passwords
def _pbkdf2_sha256(pw: bytes, salt: bytes, iterations: int) -> bytes:
    """hashlib.pbkdf2_hmac, with a pure-Python fallback (Pyodide's hashlib does not provide it)."""
    if hasattr(hashlib, "pbkdf2_hmac"):
        return hashlib.pbkdf2_hmac("sha256", pw, salt, iterations)
    inner, outer = hashlib.sha256(), hashlib.sha256()
    key = pw if len(pw) <= 64 else hashlib.sha256(pw).digest()
    key = key.ljust(64, b"\0")
    inner.update(bytes(x ^ 0x36 for x in key))
    outer.update(bytes(x ^ 0x5C for x in key))

    def prf(data: bytes) -> bytes:
        i, o = inner.copy(), outer.copy()
        i.update(data)
        o.update(i.digest())
        return o.digest()

    u = prf(salt + b"\0\0\0\1")      # one 32-byte block = the full SHA-256 output length
    out = int.from_bytes(u, "big")
    for _ in range(iterations - 1):
        u = prf(u)
        out ^= int.from_bytes(u, "big")
    return out.to_bytes(32, "big")


def hash_password(pw: str, iterations: int | None = None) -> str:
    if len(pw) < 12:
        raise ValueError("password must be at least 12 characters")
    it = iterations or PBKDF2_ITER
    salt = secrets.token_bytes(16)
    dk = _pbkdf2_sha256(pw.encode(), salt, it)
    return f"pbkdf2_sha256${it}${salt.hex()}${dk.hex()}"


def verify_password(pw: str, stored: str) -> bool:
    try:
        algo, it, salt, digest = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = _pbkdf2_sha256(pw.encode(), bytes.fromhex(salt), int(it))
        return hmac.compare_digest(dk.hex(), digest)
    except (ValueError, TypeError):
        return False


# --------------------------------------------------------------------------- tokens
@lru_cache(maxsize=1)
def secret_key() -> str:
    env = os.environ.get("AOMDIS_SECRET_KEY")
    if env:
        return env
    p = ROOT / "data" / "warehouse" / "secret.key"
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text(secrets.token_urlsafe(48), encoding="utf-8")
        log.warning("AOMDIS_SECRET_KEY not set: generated a development key at %s", p)
    return p.read_text(encoding="utf-8").strip()


def is_production() -> bool:
    return os.environ.get("AOMDIS_ENV", "development").lower() == "production"


def cookie_secure() -> bool:
    return os.environ.get("AOMDIS_COOKIE_SECURE", "0") == "1"


def check_production_settings() -> list[str]:
    """Problems that make the current environment unsafe for production (empty list = fine)."""
    problems = []
    key = os.environ.get("AOMDIS_SECRET_KEY", "")
    if len(key) < 32:
        problems.append("AOMDIS_SECRET_KEY must be set to a random value of at least 32 characters")
    if not cookie_secure():
        problems.append("AOMDIS_COOKIE_SECURE=1 is required (serve over HTTPS)")
    return problems


def password_fingerprint(password_hash: str) -> str:
    """Short keyed digest of the stored hash: changes when the password is reset, reveals nothing."""
    return hmac.new(secret_key().encode(), password_hash.encode(), hashlib.sha256).hexdigest()[:16]


def issue_token(user: M.User) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode({"sub": user.username, "role": user.role, "iat": now, "exp": now + timedelta(hours=TOKEN_HOURS),
                       "pv": password_fingerprint(user.password_hash), "sv": int(user.session_version or 0),
                       "jti": secrets.token_hex(8)},
                      secret_key(), algorithm="HS256")


def decode_token(token: str) -> dict:
    return jwt.decode(token, secret_key(), algorithms=["HS256"], options={"require": ["exp", "sub"]})


# --------------------------------------------------------------------------- throttling
MAX_FAILURES, MAX_FAILURES_PER_CLIENT, WINDOW_S = 5, 50, 900


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _keys(username: str, client: str | None) -> list[str]:
    keys = ["u:" + username.lower()[:64]]
    if client:
        keys.append("c:" + client[:128])
    return keys


def _recent(key: str) -> int:
    since = _utcnow() - timedelta(seconds=WINDOW_S)
    with session_scope() as s:
        return int(s.execute(select(func.count()).select_from(M.LoginFailure)
                             .where((M.LoginFailure.key == key) & (M.LoginFailure.at_utc > since))).scalar_one())


def throttled(username: str, client: str | None = None) -> bool:
    if _recent(_keys(username, None)[0]) >= MAX_FAILURES:
        return True
    return client is not None and _recent("c:" + client[:128]) >= MAX_FAILURES_PER_CLIENT


def record_failure(username: str, client: str | None = None) -> None:
    now = _utcnow()
    with session_scope() as s:
        s.execute(delete(M.LoginFailure).where(M.LoginFailure.at_utc < now - timedelta(seconds=WINDOW_S)))  # keep the table small
        for k in _keys(username, client):
            s.add(M.LoginFailure(key=k, at_utc=now))


def clear_failures(username: str) -> None:
    with session_scope() as s:
        s.execute(delete(M.LoginFailure).where(M.LoginFailure.key == _keys(username, None)[0]))


def revoke_sessions(username: str) -> bool:
    """Log out everywhere: every token issued before this call stops working. False if no such user."""
    with session_scope() as s:
        r = s.execute(update(M.User).where(M.User.username == username)
                      .values(session_version=M.User.session_version + 1))
        return r.rowcount > 0


# Verified against when the username does not exist, so a failed login costs the same time either way.
_DUMMY_HASH = f"pbkdf2_sha256${PBKDF2_ITER}${'00' * 16}${'00' * 32}"


def authenticate(username: str, password: str) -> M.User | None:
    """Return the active user for these credentials, or None. Same work whether or not the user exists."""
    with session_scope() as s:
        u = s.execute(select(M.User).where(M.User.username == username)).scalar_one_or_none()
        ok = verify_password(password, u.password_hash if u is not None else _DUMMY_HASH)
        if u is None or not ok or not u.active:
            return None
        s.expunge(u)
        return u


# --------------------------------------------------------------------------- audit
def audit(actor: str, action: str, target: str | None = None, **detail) -> None:
    with session_scope() as s:
        s.add(M.AuditLog(at_utc=datetime.now(timezone.utc).replace(tzinfo=None), actor=actor, action=action,
                         target=target, detail_json=json.dumps(detail, default=str) if detail else None))


# --------------------------------------------------------------------------- FastAPI dependencies
class CurrentUser:
    def __init__(self, username: str, role: str, display_name: str):
        self.username, self.role, self.display_name = username, role, display_name
        self.perms = permissions(role)

    def to_dict(self) -> dict:
        r = ROLES[self.role]
        return {"username": self.username, "display_name": self.display_name, "role": self.role, "role_label": r["label"],
                "modules": r["view"], "permissions": sorted(self.perms)}


def current_user(request: Request) -> CurrentUser:
    token, via_cookie = None, False
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        token = auth[7:]
    elif COOKIE in request.cookies:
        token, via_cookie = request.cookies[COOKIE], True
    if not token:
        raise HTTPException(401, "not authenticated")
    if via_cookie and request.method not in ("GET", "HEAD", "OPTIONS") and request.headers.get(CSRF_HEADER) != "1":
        raise HTTPException(403, "missing CSRF header")
    user = user_from_token(token)
    if user is None:
        raise HTTPException(401, "invalid or expired session")
    return user


def user_from_token(token: str | None) -> CurrentUser | None:
    """Validate a session token against the database: signature, expiry, account active, password unchanged.
    The role always comes from the database, never from the token."""
    if not token:
        return None
    try:
        claims = decode_token(token)
    except jwt.PyJWTError:
        return None
    with session_scope() as s:
        u = s.execute(select(M.User).where(M.User.username == claims["sub"])).scalar_one_or_none()
        if u is None or not u.active:
            return None
        if not hmac.compare_digest(str(claims.get("pv", "")), password_fingerprint(u.password_hash)):
            return None
        if int(claims.get("sv", 0)) != int(u.session_version or 0):
            return None
        return CurrentUser(u.username, u.role, u.display_name)


def require(perm: str):
    def dep(user: CurrentUser = Depends(current_user)) -> CurrentUser:
        if perm not in user.perms:
            raise HTTPException(403, f"role '{user.role}' lacks permission '{perm}'")
        return user
    return dep


# --------------------------------------------------------------------------- user management
def create_user(username: str, password: str, role: str, display_name: str | None = None) -> None:
    if role not in ROLES:
        raise ValueError(f"unknown role {role!r}; one of {list(ROLES)}")
    with session_scope() as s:
        if s.execute(select(M.User).where(M.User.username == username)).scalar_one_or_none():
            raise ValueError(f"user {username!r} exists")
        s.add(M.User(username=username, display_name=display_name or username, role=role, password_hash=hash_password(password),
                     active=True, created_utc=datetime.now(timezone.utc).replace(tzinfo=None)))
