"""Model suite. Every model predicts the daily count of arrivals or departures for rows that
share one cutoff; movements = arrivals + departures.

Baselines      schedule_raw (scheduled count), seasonal_naive (same weekday, latest available week)
Preserved D-7  fpred_calibrated (stored forecasts of the original engine, list available at cutoff)
Time series    ets (Holt-Winters, damped additive trend, weekly seasonality), stl_trend (STL decomposition:
               trend extrapolated with its last-week slope + same-weekday seasonal component)
ML             random_forest, gradient_boosting (HistGB), xgboost — retrained at every cutoff on rows
               whose target day is already observed (target < cutoff)
Ensemble       weighted mean of ets, stl_trend, random_forest, gradient_boosting, xgboost, fpred_calibrated with
               weights 1/MAE of each member over the last 28 target days already observed at the cutoff (same
               metric and horizon); equal weights until 7 observed errors exist (computed in backtest.run)
"""
from __future__ import annotations

import hashlib
import inspect
import warnings
from datetime import date

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.seasonal import STL
from xgboost import XGBRegressor

from .data import Snapshot
from .features import FEATURES

VERSION = "1.0.0"
MIN_TRAIN_ROWS = 60

MODELS: dict[str, dict] = {
    "schedule_raw": {"family": "baseline", "label": "Raw schedule", "params": {}},
    "seasonal_naive": {"family": "baseline", "label": "Seasonal naive", "params": {"season": 7}},
    "fpred_calibrated": {"family": "preserved-d7", "label": "fpred calibrated (original D-7)", "params": {"source": "stored fpred forecasts"}},
    "ets": {"family": "time-series", "label": "ETS (Holt-Winters)", "params": {"trend": "add", "damped": True, "seasonal": "add", "period": 7}},
    "stl_trend": {"family": "decomposition", "label": "STL trend + season", "params": {"period": 7, "robust": True, "slope_window": 7}},
    "random_forest": {"family": "ml", "label": "Random forest", "params": {"n_estimators": 200, "min_samples_leaf": 3, "random_state": 0}},
    "gradient_boosting": {"family": "ml", "label": "Gradient boosting (HistGB)", "params": {"max_iter": 200, "learning_rate": 0.05, "random_state": 0}},
    "xgboost": {"family": "ml", "label": "XGBoost", "params": {"n_estimators": 300, "max_depth": 3, "learning_rate": 0.05, "subsample": 0.8, "random_state": 0}},
    "ensemble": {"family": "ensemble", "label": "Ensemble (inverse-MAE weighted)",
                 "params": {"members": ["ets", "stl_trend", "random_forest", "gradient_boosting", "xgboost", "fpred_calibrated"],
                            "weights": "1/MAE over last 28 observed target days, same metric & horizon", "min_errors": 7}},
}
ORDER = list(MODELS)


def code_sha() -> str:
    import aomdis.forecasting.features as f
    src = inspect.getsource(inspect.getmodule(code_sha)) + inspect.getsource(f)
    return hashlib.sha256(src.encode()).hexdigest()


def model_version_id(name: str) -> str:
    return f"{name}@{VERSION}#{code_sha()[:8]}"


# ----------------------------------------------------------------------------- feature matrix
def matrix(R: pd.DataFrame) -> np.ndarray:
    X = R[FEATURES].copy()
    X["sched"] = X["sched"].fillna(X["mean7"])
    X["sched_adj"] = X["sched_adj"].fillna(X["mean7"])
    X["ratio14"] = X["ratio14"].fillna(1.0)
    return X.to_numpy(dtype=float)


def _ml(name: str):
    p = MODELS[name]["params"]
    if name == "random_forest":
        return RandomForestRegressor(n_jobs=1, **p)
    if name == "gradient_boosting":
        return HistGradientBoostingRegressor(**p)
    return XGBRegressor(n_jobs=1, verbosity=0, **p)


# ----------------------------------------------------------------------------- per-cutoff prediction
def predict_cutoff(snap: Snapshot, R: pd.DataFrame, T: pd.DataFrame, cutoff: date) -> dict[str, np.ndarray]:
    """R: rows to predict (all with cutoff == ``cutoff``), T: training rows (target < cutoff, y known)."""
    out: dict[str, np.ndarray] = {}
    out["schedule_raw"] = R["sched"].to_numpy(dtype=float)
    out["seasonal_naive"] = R["lag_same_wd"].to_numpy(dtype=float)
    fp = []
    for r in R.itertuples():
        v = np.nan
        if r.list_id is not None and not pd.isna(r.list_id):
            f = snap.fpred_daily.get(int(r.list_id))
            if f is not None and r.target in f.index and r.metric in f.columns:
                v = float(f.at[r.target, r.metric])
        fp.append(v)
    out["fpred_calibrated"] = np.array(fp)

    last = cutoff - pd.Timedelta(days=1)
    ets, stl = np.full(len(R), np.nan), np.full(len(R), np.nan)
    for metric, idx in R.groupby("metric").groups.items():
        hist = snap.history(metric, last.date() if hasattr(last, "date") else last)
        y = hist.to_numpy(dtype=float)
        steps = R.loc[idx, "horizon"].to_numpy() + 1
        pos = R.index.get_indexer(idx)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            try:
                fit = ExponentialSmoothing(y, trend="add", damped_trend=True, seasonal="add", seasonal_periods=7,
                                           initialization_method="estimated").fit()
                fc = fit.forecast(int(steps.max()))
                ets[pos] = fc[steps - 1]
            except Exception:  # noqa: BLE001 — too little data or non-convergence -> leave NaN
                pass
            try:
                s = STL(y, period=7, robust=True).fit()
                slope = (s.trend[-1] - s.trend[-8]) / 7
                for p_i, st, tgt in zip(pos, steps, R.loc[idx, "target"]):
                    # seasonal component of the same weekday: mean of the last 4 occurrences
                    wd_pos = [i for i in range(len(y)) if (hist.index[i].weekday() == tgt.weekday())][-4:]
                    stl[p_i] = s.trend[-1] + slope * st + float(np.mean(s.seasonal[wd_pos]))
            except Exception:  # noqa: BLE001
                pass
    out["ets"], out["stl_trend"] = ets, stl

    for name in ("random_forest", "gradient_boosting", "xgboost"):
        pred = np.full(len(R), np.nan)
        for metric, idx in R.groupby("metric").groups.items():
            tr = T[(T["metric"] == metric) & T["y"].notna()]
            if len(tr) < MIN_TRAIN_ROWS:
                continue
            m = _ml(name)
            m.fit(matrix(tr), tr["y"].to_numpy(dtype=float))
            pred[R.index.get_indexer(idx)] = m.predict(matrix(R.loc[idx]))
        out[name] = pred

    return out
