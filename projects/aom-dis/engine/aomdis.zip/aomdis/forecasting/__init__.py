"""Pre-tactical forecasting (D-7 … D-0): leakage-safe features, model suite, rolling-origin
backtest, prediction intervals, evaluation and forecast store."""
