"""Warehouse snapshot used by the forecasting engine, plus the information-set rules.

Information set at a forecast issued at 00:00 local on cutoff day ``c`` (horizon k = target − c):
* realised movements of complete local days  ≤ c − 1
* schedule lists with published_date        < c  (published on an earlier day)
* fpred calibrated forecasts built from such lists (themselves trained before publication)
Nothing dated ≥ c may influence a forecast with cutoff c.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..db.session import engine
from ..ingest.pipeline import latest_dataset_version

METRICS = ("arrivals", "departures")
DIR = {"arrivals": "ARR", "departures": "DEP"}


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


@dataclass
class Snapshot:
    dataset_version: str
    days: list[date]                         # complete local days with actuals
    daily: pd.DataFrame                      # index date, columns arrivals, departures (complete days only)
    hourly: pd.DataFrame                     # local_date, local_hour, arrivals, departures (complete days)
    lists: pd.DataFrame                      # id, name, published_date, start, end
    sched: dict[int, pd.DataFrame]           # list_id -> daily scheduled (index date, arrivals, departures)
    fpred_daily: dict[int, pd.DataFrame]     # list_id -> daily calibrated forecast
    fpred_hourly: dict[int, pd.DataFrame]    # list_id -> (local_date, local_hour, movements)
    canceled: dict[int, pd.Series]           # list_id -> inferred cancellations per date (within match coverage)
    fpred_model_version: str | None = None
    _por_cache: dict = field(default_factory=dict)

    # ------------------------------------------------------------------ information-set helpers
    def plan_of_record(self, cutoff: date, target: date) -> pd.Series | None:
        """Newest list published before ``cutoff`` whose coverage contains ``target``."""
        key = (cutoff, target)
        if key not in self._por_cache:
            L = self.lists[(self.lists["published_date"] < cutoff) & (self.lists["start"] <= target) & (self.lists["end"] >= target)]
            self._por_cache[key] = None if L.empty else L.sort_values("published_date").iloc[-1]
        return self._por_cache[key]

    def history(self, metric: str, last: date) -> pd.Series:
        """Complete-day actuals up to and including ``last``."""
        s = self.daily[metric]
        return s[s.index <= last]

    def actual(self, metric: str, d: date) -> float | None:
        if metric == "movements":
            a, b = self.actual("arrivals", d), self.actual("departures", d)
            return None if a is None or b is None else a + b
        return float(self.daily.at[d, metric]) if d in self.daily.index else None


def load() -> Snapshot:
    dsv = latest_dataset_version()
    if dsv is None:
        raise LookupError("warehouse empty: run `python -m aomdis ingest`")
    d = _q("select local_date, direction, count(*) n from movement where dataset_version_id=:d group by 1,2", d=dsv)
    d["local_date"] = pd.to_datetime(d["local_date"]).dt.date
    daily = d.pivot_table(index="local_date", columns="direction", values="n", fill_value=0).rename(columns={"ARR": "arrivals", "DEP": "departures"})
    first, last = min(daily.index), max(daily.index)
    daily = daily.loc[[x for x in daily.index if first < x < last]].astype(float)  # drop partial first/last day
    h = _q("select local_date, local_hour, direction, count(*) n from movement where dataset_version_id=:d group by 1,2,3", d=dsv)
    h["local_date"] = pd.to_datetime(h["local_date"]).dt.date
    hourly = h.pivot_table(index=["local_date", "local_hour"], columns="direction", values="n", fill_value=0).reset_index()
    hourly = hourly.rename(columns={"ARR": "arrivals", "DEP": "departures"})
    hourly = hourly[hourly["local_date"].isin(set(daily.index))]

    lists = _q("select id, name, published_date, coverage_start_local start, coverage_end_local end from schedule_list "
               "where dataset_version_id=:d", d=dsv)
    for c in ("published_date", "start", "end"):
        lists[c] = pd.to_datetime(lists[c]).dt.date
    s = _q("select schedule_list_id lid, local_date, direction, count(*) n from schedule_entry e join schedule_list l on l.id=e.schedule_list_id "
           "where l.dataset_version_id=:d group by 1,2,3", d=dsv)
    s["local_date"] = pd.to_datetime(s["local_date"]).dt.date
    sched = {int(lid): g.pivot_table(index="local_date", columns="direction", values="n", fill_value=0)
             .rename(columns={"ARR": "arrivals", "DEP": "departures"}).astype(float) for lid, g in s.groupby("lid")}

    mv = _q("select id from model_version where name='fpred-calibrated' order by created_utc desc limit 1")
    mvid = mv["id"].iloc[0] if len(mv) else None
    fd, fh = {}, {}
    if mvid:
        f = _q("select r.schedule_list_id lid, f.target_local_date local_date, f.target_local_hour local_hour, f.metric, f.value "
               "from forecast f join forecast_run r on r.id=f.run_id where r.model_version_id=:m and r.dataset_version_id=:d",
               m=mvid, d=dsv)
        f["local_date"] = pd.to_datetime(f["local_date"]).dt.date
        for lid, g in f.groupby("lid"):
            dd = g[g["local_hour"].isna() & g["metric"].isin(["arrivals", "departures"])]
            fd[int(lid)] = dd.pivot_table(index="local_date", columns="metric", values="value")
            hh = g[g["local_hour"].notna()].groupby(["local_date", "local_hour"])["value"].sum().reset_index(name="movements")
            hh["local_hour"] = hh["local_hour"].astype(int)
            fh[int(lid)] = hh
    c = _q("select schedule_list_id lid, local_date, sum(case when state in ('canceled','confirmed_canceled') then 1 else 0 end) n from movement_match group by 1,2")
    c["local_date"] = pd.to_datetime(c["local_date"]).dt.date
    canceled = {int(lid): g.set_index("local_date")["n"].astype(float) for lid, g in c.groupby("lid")}
    return Snapshot(dsv, sorted(daily.index), daily, hourly, lists, sched, fd, fh, canceled, mvid)


def hourly_shape(snap: Snapshot, metric: str, target: date, last: date, weeks: int = 4) -> pd.Series | None:
    """Share of the day's movements per local hour, from the last ``weeks`` same-weekday complete days ≤ ``last``."""
    same = [d for d in snap.days if d <= last and d.weekday() == target.weekday()][-weeks:]
    if not same:
        return None
    H = snap.hourly[snap.hourly["local_date"].isin(same)]
    col = H["arrivals"] + H["departures"] if metric == "movements" else H[metric]
    prof = col.groupby(H["local_hour"]).sum().reindex(range(24), fill_value=0.0)
    from ..core.timeutil import hours_in_local_day
    if hours_in_local_day(target) == 23:
        prof.loc[2] = 0.0
    tot = prof.sum()
    return None if tot <= 0 else prof / tot


def date_range(a: date, b: date) -> list[date]:
    return [a + timedelta(days=i) for i in range((b - a).days + 1)]


def safe_div(a: float, b: float) -> float:
    return float(a / b) if b else np.nan
