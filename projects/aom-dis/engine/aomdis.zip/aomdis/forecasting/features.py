"""Feature rows for (target day t, horizon k, metric). Cutoff c = t − k; information ≤ c − 1.

Every row carries ``info_max_date`` (latest realised day used) and ``list_published`` (publication
date of the schedule list used) so leakage can be asserted mechanically:
    info_max_date ≤ c − 1   and   list_published < c
"""
from __future__ import annotations

import math
from datetime import date, timedelta

import numpy as np
import pandas as pd

from .data import METRICS, Snapshot

MIN_HISTORY = 14
FEATURES = ["sched", "has_sched", "sched_adj", "lag_last", "lag_same_wd", "mean7", "mean28", "ratio14",
            "horizon", "t_index", "wd_0", "wd_1", "wd_2", "wd_3", "wd_4", "wd_5", "wd_6"]


def _sched_for(snap: Snapshot, cutoff: date, target: date, metric: str) -> tuple[float, date | None, int | None]:
    p = snap.plan_of_record(cutoff, target)
    if p is None:
        return np.nan, None, None
    s = snap.sched.get(int(p["id"]))
    v = float(s.at[target, metric]) if s is not None and target in s.index and metric in s.columns else 0.0
    return v, p["published_date"], int(p["id"])


def row(snap: Snapshot, t: date, k: int, metric: str) -> dict | None:
    c = t - timedelta(days=k)
    last = c - timedelta(days=1)
    hist = snap.history(metric, last)
    if len(hist) < MIN_HISTORY:
        return None
    m = math.ceil((k + 1) / 7)
    same_wd = t - timedelta(days=7 * m)
    sched, pub, lid = _sched_for(snap, c, t, metric)
    # realised / scheduled over the last 14 complete days, each day against ITS OWN plan of record
    num = den = 0.0
    for d in hist.index[-14:]:
        v, _, _ = _sched_for(snap, d, d, metric)
        if not np.isnan(v) and v > 0:
            num += hist[d]
            den += v
    ratio = num / den if den else np.nan
    t0 = snap.days[0]
    r = {
        "target": t, "horizon": k, "cutoff": c, "metric": metric, "weekday": t.weekday(),
        "sched": sched, "has_sched": float(not np.isnan(sched)),
        "sched_adj": sched * ratio if not (np.isnan(sched) or np.isnan(ratio)) else np.nan,
        "lag_last": float(hist.iloc[-1]),
        "lag_same_wd": float(hist[same_wd]) if same_wd in hist.index else float(hist.iloc[-7:].mean()),
        "mean7": float(hist.iloc[-7:].mean()), "mean28": float(hist.iloc[-28:].mean()), "ratio14": ratio,
        "t_index": float((t - t0).days),
        "info_max_date": hist.index[-1], "list_published": pub, "list_id": lid,
        "y": snap.actual(metric, t),
    }
    for i in range(7):
        r[f"wd_{i}"] = float(t.weekday() == i)
    return r


def table(snap: Snapshot, targets: list[date], horizons=range(8)) -> pd.DataFrame:
    rows = [r for t in targets for k in horizons for mt in METRICS if (r := row(snap, t, k, mt)) is not None]
    return pd.DataFrame(rows)


def assert_no_leakage(F: pd.DataFrame) -> None:
    bad = F[F["info_max_date"] >= F["cutoff"]]
    if len(bad):
        raise AssertionError(f"{len(bad)} rows use realised data on/after cutoff")
    lp = F.dropna(subset=["list_published"])
    bad = lp[lp["list_published"] >= lp["cutoff"]]
    if len(bad):
        raise AssertionError(f"{len(bad)} rows use a list not yet published at cutoff")
