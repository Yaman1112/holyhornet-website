"""Rolling-origin backtest: for every cutoff in order, train on what was known, predict D-0…D-7,
attach empirical prediction intervals, distribute to hours, store and evaluate.

Prediction interval (80 %): forecast + [q10, q90] of this model's past residuals (actual − forecast)
at the same horizon whose target day was already observed at the cutoff; none until 10 residuals exist.
"""
from __future__ import annotations

import json
import logging
from datetime import date, datetime, timedelta, timezone
from typing import Callable

import numpy as np
import pandas as pd
from sqlalchemy import delete, select

from ..core.settings import settings
from ..db import models as M
from ..db.session import engine, session_scope
from . import features as FT
from . import models as MD
from .data import Snapshot, hourly_shape, load

log = logging.getLogger("aomdis.forecasting")
HORIZONS = list(range(8))
LEVEL = 0.8
MIN_RESID = 10


def default_window(snap: Snapshot) -> tuple[date, date]:
    """Evaluate from six weeks after the first complete day (enough history to train)."""
    return snap.days[0] + timedelta(days=42), snap.days[-1]


def run(start: date | None = None, end: date | None = None, horizons=HORIZONS, persist: bool = True,
        progress: Callable[[float], None] | None = None, snap: Snapshot | None = None) -> dict:
    snap = snap or load()
    w0, w1 = default_window(snap)
    start, end = start or w0, end or w1
    eval_targets = [d for d in snap.days if start <= d <= end]
    all_targets = [d for d in snap.days if d <= end]
    F = FT.table(snap, all_targets, horizons)
    FT.assert_no_leakage(F)
    F = F.reset_index(drop=True)
    E = F[F["target"].isin(set(eval_targets))]
    cutoffs = sorted(E["cutoff"].unique())
    res = []
    resid: dict[tuple[str, int, str], list[tuple[date, float]]] = {}
    for i, c in enumerate(cutoffs):
        R = E[E["cutoff"] == c]
        T = F[F["target"] < c]
        preds = MD.predict_cutoff(snap, R, T, c)
        preds["ensemble"] = _ensemble(preds, R, res, c)
        for name, p in preds.items():
            for (r, v) in zip(R.itertuples(), p):
                res.append({"model": name, "target": r.target, "horizon": r.horizon, "cutoff": c, "metric": r.metric,
                            "pred": float(v), "actual": r.y, "list_id": r.list_id})
        if progress:
            progress((i + 1) / len(cutoffs) * 0.8)
    D = pd.DataFrame(res)
    # movements = arrivals + departures
    piv = D.pivot_table(index=["model", "target", "horizon", "cutoff"], columns="metric", values=["pred", "actual"], aggfunc="first")
    mov = pd.DataFrame({"pred": piv[("pred", "arrivals")] + piv[("pred", "departures")],
                        "actual": piv[("actual", "arrivals")] + piv[("actual", "departures")]}).reset_index()
    mov["metric"] = "movements"
    D = pd.concat([D, mov], ignore_index=True)
    D = _intervals(D)
    C = _cancellations(snap, E)
    H = _hourly(snap, D)
    ev = evaluate(D, H)
    out = {"dataset_version": snap.dataset_version, "window": [str(start), str(end)], "cutoffs": len(cutoffs),
           "predictions": int(len(D)), "evaluation": ev, "cancellations": _eval_cancel(C),
           "fpred_native_hourly": native_fpred_hourly(snap, D)}
    if persist:
        _persist(snap, D, H, ev)
        p = settings().reports_dir
        p.mkdir(parents=True, exist_ok=True)
        (p / "pretactical_backtest.json").write_text(json.dumps(out, default=str, indent=1), encoding="utf-8")
    if progress:
        progress(1.0)
    out["_frames"] = (D, H, C)
    return out


def _ensemble(preds: dict, R: pd.DataFrame, res: list[dict], c: date) -> np.ndarray:
    """Inverse-MAE weights from errors whose target was observed before cutoff c (no leakage)."""
    members = MD.MODELS["ensemble"]["params"]["members"]
    P = np.vstack([preds[m] for m in members])
    past = pd.DataFrame([r for r in res if r["model"] in members and r["target"] < c and r["target"] >= c - timedelta(days=28)
                         and r["actual"] is not None and not np.isnan(r["pred"])]) if res else pd.DataFrame()
    out = np.full(len(R), np.nan)
    for j, (metric, k) in enumerate(zip(R["metric"], R["horizon"])):
        w = np.ones(len(members))
        if len(past):
            g = past[(past["metric"] == metric) & (past["horizon"] == k)]
            for i, m in enumerate(members):
                e = g[g["model"] == m]
                if len(e) >= 7:
                    w[i] = 1.0 / max(float(np.abs(e["actual"] - e["pred"]).mean()), 1e-6)
                else:
                    w[i] = np.nan
            if np.isnan(w).all():
                w = np.ones(len(members))
        col = P[:, j]
        ok = ~np.isnan(col) & ~np.isnan(w)
        if ok.any():
            out[j] = float(np.sum(col[ok] * w[ok]) / np.sum(w[ok]))
    return out


def _intervals(D: pd.DataFrame) -> pd.DataFrame:
    """Sequential empirical intervals: only residuals of targets observed before each cutoff."""
    D = D.sort_values(["cutoff"]).reset_index(drop=True)
    D["lower"] = np.nan
    D["upper"] = np.nan
    for (model, metric, k), g in D.groupby(["model", "metric", "horizon"]):
        g = g.sort_values("cutoff")
        done = g.dropna(subset=["pred", "actual"])
        for idx, r in g.iterrows():
            if np.isnan(r["pred"]):
                continue
            past = done[done["target"] < r["cutoff"]]
            if len(past) < MIN_RESID:
                continue
            e = (past["actual"] - past["pred"]).to_numpy()
            lo, hi = np.quantile(e, [(1 - LEVEL) / 2, 1 - (1 - LEVEL) / 2])
            D.at[idx, "lower"] = r["pred"] + lo
            D.at[idx, "upper"] = r["pred"] + hi
    return D


def _hourly(snap: Snapshot, D: pd.DataFrame) -> pd.DataFrame:
    """Hourly movements: every model (fpred included) distributes its daily forecast with the same-weekday
    hourly shape of the last 4 complete weeks known at the cutoff. fpred's own stored hourly profile is timed
    at schedule reference times (FIR entry / SOBT), not runway times; it is evaluated separately for the record."""
    m = D[(D["metric"] == "movements") & D["pred"].notna()]
    act = snap.hourly.assign(movements=snap.hourly["arrivals"] + snap.hourly["departures"]).set_index(["local_date", "local_hour"])["movements"]
    rows = []
    shapes: dict[tuple, pd.Series | None] = {}
    for r in m.itertuples():
        last = r.cutoff - timedelta(days=1)
        key = (r.target, last)
        if key not in shapes:
            shapes[key] = hourly_shape(snap, "movements", r.target, last)
        sh = shapes[key]
        if sh is None:
            continue
        vals = sh.to_numpy() * r.pred
        for h in range(24):
            a = act.get((r.target, h))
            if a is None and vals[h] == 0:
                continue  # non-existent DST hour
            rows.append((r.model, r.target, r.horizon, r.cutoff, h, float(vals[h]), None if a is None else float(a)))
    return pd.DataFrame(rows, columns=["model", "target", "horizon", "cutoff", "hour", "pred", "actual"])


def native_fpred_hourly(snap: Snapshot, D: pd.DataFrame) -> dict:
    """For the record: hourly error of fpred's own stored hourly profile (schedule reference times)."""
    act = snap.hourly.assign(movements=snap.hourly["arrivals"] + snap.hourly["departures"]).set_index(["local_date", "local_hour"])["movements"]
    a = D[(D["model"] == "fpred_calibrated") & (D["metric"] == "arrivals") & D["pred"].notna()]
    errs = []
    for r in a.itertuples():
        fh = snap.fpred_hourly.get(int(r.list_id)) if r.list_id is not None and not pd.isna(r.list_id) else None
        if fh is None:
            continue
        g = fh[fh["local_date"] == r.target]
        for h, v in zip(g["local_hour"], g["movements"]):
            if (r.target, h) in act.index:
                errs.append(act[(r.target, h)] - v)
    e = np.array(errs, dtype=float)
    return {"n": int(len(e)), "mae": float(np.abs(e).mean()) if len(e) else None,
            "note": "fpred's stored hourly profile times arrivals at FIR entry and departures at SOBT; runway times are later, "
                    "so the platform distributes fpred's daily forecast with the historical runway-time hourly shape instead."}


def _cancellations(snap: Snapshot, E: pd.DataFrame) -> pd.DataFrame:
    """Expected inferred cancellations = scheduled(t) × inferred cancellation rate of the last 14 known days."""
    rows = []
    for (t, k), g in E.groupby(["target", "horizon"]):
        c = t - timedelta(days=int(k))
        p = snap.plan_of_record(c, t)
        if p is None:
            continue
        lid = int(p["id"])
        sch = snap.sched.get(lid)
        sched_t = float(sch.loc[t].sum()) if sch is not None and t in sch.index else 0.0
        num = den = 0.0
        for d in [x for x in snap.days if x < c][-14:]:
            q = snap.plan_of_record(d, d)
            if q is None:
                continue
            cs = snap.canceled.get(int(q["id"]))
            if cs is None or d not in cs.index:
                continue
            num += cs[d]
            den += float(snap.sched[int(q["id"])].loc[d].sum())
        if not den:
            continue
        cs_t = snap.canceled.get(lid)
        actual = float(cs_t[t]) if cs_t is not None and t in cs_t.index else None
        rows.append({"target": t, "horizon": k, "pred": sched_t * num / den, "rate": num / den, "scheduled": sched_t, "actual": actual})
    return pd.DataFrame(rows)


def _metrics(a: np.ndarray, p: np.ndarray, lo=None, hi=None) -> dict:
    ok = ~(np.isnan(a) | np.isnan(p))
    a, p = a[ok], p[ok]
    if not len(a):
        return {"n": 0}
    e = a - p
    out = {"n": int(len(a)), "mae": float(np.abs(e).mean()), "rmse": float(np.sqrt((e ** 2).mean())), "bias": float(e.mean()),
           "mape": float((np.abs(e)[a > 0] / a[a > 0]).mean() * 100) if (a > 0).any() else None}
    if lo is not None:
        lo, hi = lo[ok], hi[ok]
        has = ~(np.isnan(lo) | np.isnan(hi))
        out["n_interval"] = int(has.sum())
        out["coverage"] = float(((a[has] >= lo[has]) & (a[has] <= hi[has])).mean()) if has.any() else None
    return out


def evaluate(D: pd.DataFrame, H: pd.DataFrame) -> dict:
    by_h, by_wd = [], []
    for (model, metric, k), g in D.groupby(["model", "metric", "horizon"]):
        by_h.append({"model": model, "metric": metric, "horizon": int(k),
                     **_metrics(g["actual"].to_numpy(float), g["pred"].to_numpy(float), g["lower"].to_numpy(float), g["upper"].to_numpy(float))})
    mv = D[D["metric"] == "movements"].assign(weekday=lambda d: pd.to_datetime(d["target"]).dt.day_of_week)
    for (model, wd), g in mv.groupby(["model", "weekday"]):
        by_wd.append({"model": model, "weekday": int(wd), **_metrics(g["actual"].to_numpy(float), g["pred"].to_numpy(float))})
    hourly, by_hour, peaks = [], [], []
    for (model, k), g in H.groupby(["model", "horizon"]):
        hourly.append({"model": model, "horizon": int(k), **_metrics(g["actual"].to_numpy(float), g["pred"].to_numpy(float))})
    for (model, h), g in H.groupby(["model", "hour"]):
        by_hour.append({"model": model, "hour": int(h), **_metrics(g["actual"].to_numpy(float), g["pred"].to_numpy(float))})
    for (model, k), g in H.dropna(subset=["actual"]).groupby(["model", "horizon"]):
        hits, err = [], []
        for _, d in g.groupby("target"):
            ph, ah = int(d.loc[d["pred"].idxmax(), "hour"]), int(d.loc[d["actual"].idxmax(), "hour"])
            hits.append(abs(ph - ah) <= 1)
            err.append(d["pred"].max() - d["actual"].max())
        peaks.append({"model": model, "horizon": int(k), "days": len(hits), "peak_hour_hit_rate": float(np.mean(hits)),
                      "peak_size_bias": float(np.mean(err))})
    overall = []
    for (model, metric), g in D.groupby(["model", "metric"]):
        overall.append({"model": model, "metric": metric, **_metrics(g["actual"].to_numpy(float), g["pred"].to_numpy(float),
                                                                    g["lower"].to_numpy(float), g["upper"].to_numpy(float))})
    # like-for-like: only (target, horizon, metric) where every model has a forecast
    piv = D.pivot_table(index=["target", "horizon", "metric"], columns="model", values="pred")
    common = piv.dropna().index
    Dc = D.set_index(["target", "horizon", "metric"]).loc[lambda x: x.index.isin(common)].reset_index()
    overall_common = [{"model": model, "metric": metric, **_metrics(g["actual"].to_numpy(float), g["pred"].to_numpy(float),
                                                                    g["lower"].to_numpy(float), g["upper"].to_numpy(float))}
                      for (model, metric), g in Dc.groupby(["model", "metric"])]
    return {"by_horizon": by_h, "by_weekday": by_wd, "overall_common": overall_common, "hourly_by_horizon": hourly, "hourly_by_hour": by_hour, "peaks": peaks,
            "overall": overall, "interval_level": LEVEL}


def _eval_cancel(C: pd.DataFrame) -> dict:
    if C.empty:
        return {"n": 0}
    c = C.dropna(subset=["actual"])
    return {"model": "cancel_rate14", "kind": "inferred", **_metrics(c["actual"].to_numpy(float), c["pred"].to_numpy(float)),
            "by_horizon": [{"horizon": int(k), **_metrics(g["actual"].to_numpy(float), g["pred"].to_numpy(float))} for k, g in c.groupby("horizon")]}


def _persist(snap: Snapshot, D: pd.DataFrame, H: pd.DataFrame, ev: dict) -> None:
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    from ..core.timeutil import local_day_bounds_utc
    with session_scope() as s:
        ids = {}
        for name, spec in MD.MODELS.items():
            mid = MD.model_version_id(name)
            ids[name] = mid
            if s.get(M.ModelVersion, mid) is None:
                s.add(M.ModelVersion(id=mid, name=name, version=MD.VERSION, family=spec["family"], params_json=json.dumps(spec["params"]),
                                     code_sha256=MD.code_sha(), created_utc=now))
        s.flush()
        old = [r[0] for r in s.execute(select(M.ForecastRun.id).where(M.ForecastRun.model_version_id.in_(list(ids.values()))
                                                                      & (M.ForecastRun.dataset_version_id == snap.dataset_version)))]
        if old:
            s.execute(delete(M.Forecast).where(M.Forecast.run_id.in_(old)))
            s.execute(delete(M.ForecastRun).where(M.ForecastRun.id.in_(old)))
        s.execute(delete(M.ModelEvaluation).where(M.ModelEvaluation.model_version_id.in_(list(ids.values()))
                                                  & (M.ModelEvaluation.dataset_version_id == snap.dataset_version)))
        run_id = {}
        for (model, c) in D[["model", "cutoff"]].drop_duplicates().itertuples(index=False):
            r = M.ForecastRun(model_version_id=ids[model], dataset_version_id=snap.dataset_version,
                              cutoff_utc=local_day_bounds_utc(c)[0].to_pydatetime(), created_utc=now, purpose="backtest")
            s.add(r)
            s.flush()
            run_id[(model, c)] = r.id
        for e in ev["by_horizon"]:
            if e.get("n"):
                s.add(M.ModelEvaluation(model_version_id=ids[e["model"]], dataset_version_id=snap.dataset_version, horizon_days=e["horizon"],
                                        granularity="day", metric=e["metric"], n=e["n"], mae=e["mae"], rmse=e["rmse"], mape=e.get("mape"),
                                        bias=e["bias"], coverage=e.get("coverage"), created_utc=now))
        for e in ev["hourly_by_horizon"]:
            if e.get("n"):
                s.add(M.ModelEvaluation(model_version_id=ids[e["model"]], dataset_version_id=snap.dataset_version, horizon_days=e["horizon"],
                                        granularity="hour", metric="movements", n=e["n"], mae=e["mae"], rmse=e["rmse"], mape=e.get("mape"),
                                        bias=e["bias"], coverage=None, created_utc=now))
    d = D.dropna(subset=["pred"])
    daily = pd.DataFrame({"run_id": [run_id[(m, c)] for m, c in zip(d["model"], d["cutoff"])], "target_local_date": d["target"],
                          "target_local_hour": None, "horizon_days": d["horizon"], "metric": d["metric"], "value": d["pred"].round(3),
                          "lower": d["lower"].round(3), "upper": d["upper"].round(3), "interval_level": np.where(d["lower"].notna(), LEVEL, np.nan)})
    hourly = pd.DataFrame({"run_id": [run_id[(m, c)] for m, c in zip(H["model"], H["cutoff"])], "target_local_date": H["target"],
                           "target_local_hour": H["hour"], "horizon_days": H["horizon"], "metric": "movements", "value": H["pred"].round(3),
                           "lower": None, "upper": None, "interval_level": None})
    with engine().begin() as c:
        pd.concat([daily, hourly], ignore_index=True).to_sql("forecast", c, if_exists="append", index=False, chunksize=5000)
