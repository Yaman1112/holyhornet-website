"""Tactical (day-of-operations) decision support, run as a historical replay.

Replay rule: at replay clock ``now`` (local time on the operational day) the system may use
* actual movements with actual_utc ≤ now
* the D-0 forecast (issued 00:00 local, Phase 4 store)
* the plan-of-record schedule list (published before the day)
* operational events in the event log
Nothing after ``now`` is shown as known. This is decision support, not air traffic control.
"""
