"""Operational event log with full audit history (every create/update stores a diff)."""
from __future__ import annotations

import json
from datetime import datetime, timezone

import pandas as pd
from sqlalchemy import func, select

from ..db import models as M
from ..db.session import session_scope

CATEGORIES = {
    "weather_disruption": "Weather disruption",
    "runway_restriction": "Runway restriction",
    "reduced_capacity": "Reduced operational capacity",
    "movement_disruption": "Aircraft movement disruption",
    "demand_surge": "Traffic demand surge",
    "system_failure": "System or data-feed failure",
}
SEVERITIES = ("low", "medium", "high", "critical")
STATUSES = ("draft", "active", "closed", "cancelled")
KINDS = ("actual", "simulated")
TRANSITIONS = {"draft": {"active", "cancelled"}, "active": {"closed", "cancelled"}, "closed": {"active"}, "cancelled": set()}
FIELDS = ("category", "title", "start_utc", "end_utc", "severity", "impact", "capacity_factor", "status", "kind", "source")


def _now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def validate(d: dict) -> None:
    if d.get("category") not in CATEGORIES:
        raise ValueError(f"category must be one of {list(CATEGORIES)}")
    if d.get("severity") not in SEVERITIES:
        raise ValueError(f"severity must be one of {SEVERITIES}")
    if d.get("status") not in STATUSES:
        raise ValueError(f"status must be one of {STATUSES}")
    if d.get("kind") not in KINDS:
        raise ValueError(f"kind must be 'actual' (a recorded fact) or 'simulated' (what-if)")
    cf = d.get("capacity_factor")
    if cf is not None and not 0 <= cf <= 1.5:
        raise ValueError("capacity_factor must be between 0 and 1.5")
    if d.get("end_utc") is not None and d["end_utc"] <= d["start_utc"]:
        raise ValueError("end must be after start")


def _serial(v):
    return v.isoformat() if isinstance(v, datetime) else v


def create(d: dict, actor: str) -> str:
    validate(d)
    with session_scope() as s:
        # ids use the LOCAL operational date (00:00 local on 18 Feb is 23:00 UTC on 17 Feb)
        day = pd.Timestamp(d["start_utc"]).tz_localize("UTC").tz_convert("Europe/Amsterdam").strftime("%Y%m%d")
        n = s.execute(select(func.count()).select_from(M.OperationalEvent).where(M.OperationalEvent.id.like(f"EVT-{day}-%"))).scalar() or 0
        eid = f"EVT-{day}-{n + 1:04d}"
        s.add(M.OperationalEvent(id=eid, created_by=actor, created_utc=_now(), **{k: d.get(k) for k in FIELDS}))
        s.flush()
        s.add(M.EventAudit(event_id=eid, at_utc=_now(), actor=actor, action="created",
                           changes_json=json.dumps({k: [None, _serial(d.get(k))] for k in FIELDS})))
    return eid


def update(eid: str, patch: dict, actor: str) -> dict:
    with session_scope() as s:
        e = s.get(M.OperationalEvent, eid)
        if e is None:
            raise LookupError(eid)
        cur = {k: getattr(e, k) for k in FIELDS}
        new = {**cur, **{k: v for k, v in patch.items() if k in FIELDS}}
        if new["status"] != cur["status"] and new["status"] not in TRANSITIONS[cur["status"]]:
            raise ValueError(f"status change {cur['status']} -> {new['status']} not allowed")
        validate(new)
        diff = {k: [_serial(cur[k]), _serial(new[k])] for k in FIELDS if cur[k] != new[k]}
        if not diff:
            return {}
        for k, v in new.items():
            setattr(e, k, v)
        s.add(M.EventAudit(event_id=eid, at_utc=_now(), actor=actor, action="updated", changes_json=json.dumps(diff)))
        return diff


def get(eid: str) -> dict | None:
    with session_scope() as s:
        e = s.get(M.OperationalEvent, eid)
        if e is None:
            return None
        hist = s.execute(select(M.EventAudit).where(M.EventAudit.event_id == eid).order_by(M.EventAudit.id)).scalars().all()
        return {**{k: _serial(getattr(e, k)) for k in FIELDS}, "id": e.id, "created_by": e.created_by, "created_utc": _serial(e.created_utc),
                "history": [{"at_utc": _serial(h.at_utc), "actor": h.actor, "action": h.action, "changes": json.loads(h.changes_json)} for h in hist]}


def list_between(a: pd.Timestamp, b: pd.Timestamp) -> list[dict]:
    with session_scope() as s:
        rows = s.execute(select(M.OperationalEvent).where((M.OperationalEvent.start_utc < b.to_pydatetime())
                                                          & ((M.OperationalEvent.end_utc.is_(None)) | (M.OperationalEvent.end_utc > a.to_pydatetime())))
                         .order_by(M.OperationalEvent.start_utc)).scalars().all()
        return [{**{k: _serial(getattr(e, k)) for k in FIELDS}, "id": e.id, "created_by": e.created_by} for e in rows]
