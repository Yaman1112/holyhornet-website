"""Alerting engine: rule-based, evaluated at the replay clock with only information known then.

Each alert carries: rule id + human-readable rule, category (maps to an event category), severity,
evidence (the numbers that fired it), provenance kind, time window and a decision-support suggestion.
Suggestions are phrased as items to consider; the platform issues no operational or ATC instructions.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd

from ..core.timeutil import local_to_utc, utc_to_local_hhmm
from . import flights as FL
from .state import hourly_state, snap

PRESSURE_U = 0.9
LOOKAHEAD_H = 3
DEV_REL, DEV_ABS, DEV_HIGH = 0.08, 25, 0.15
HOUR_DEV = 17          # ≈ 3 × hourly MAE of the D-0 ensemble (Phase 4 backtest: 5.6)
UNUSUAL_Z = 2.5
OVERDUE_COUNT = 10
FEED_GAP_MIN, FEED_MIN_EXPECTED = 45, 20

RULES = {
    "capacity_pressure": f"Outlook demand (actual for past hours, nowcast/plan ahead) ≥ {PRESSURE_U:.0%} of effective capacity "
                         f"in the current or next {LOOKAHEAD_H} hours (also per flow ≥ 100 %)",
    "forecast_deviation": f"Actual so far differs from the D-0 forecast for the same elapsed time by ≥ {DEV_REL:.0%} and ≥ {DEV_ABS} movements "
                          f"(high ≥ {DEV_HIGH:.0%})",
    "hour_deviation": f"Last completed hour differs from its D-0 forecast by more than {HOUR_DEV} movements",
    "unusual_demand": f"Nowcast day total is ≥ {UNUSUAL_Z} SD from the last 4 same weekdays",
    "plan_deviation": "Nowcast day total differs from the plan of record by more than 10 %",
    "overdue_flights": f"Share of scheduled flights overdue by > {FL.OVERDUE_MIN} min (expected in the last 3 h) ≥ max(2 × normal rate, normal + 10 pt) "
                       f"and ≥ {OVERDUE_COUNT} flights; normal = inferred cancellation share of the previous 14 days",
    "data_feed_gap": f"No movement recorded in the last {FEED_GAP_MIN} min while ≥ {FEED_MIN_EXPECTED} were expected (06:00–22:00)",
}


def _a(rule, category, severity, title, message, evidence, kind, window, suggestion):
    return {"id": f"{rule}@{window[0]}", "rule": rule, "rule_text": RULES[rule], "category": category, "severity": severity,
            "title": title, "message": message, "evidence": evidence, "kind": kind, "window_local": window, "suggestion": suggestion}


def evaluate(day: date, now: str, model: str = "ensemble", state: dict | None = None, timeline: pd.DataFrame | None = None) -> list[dict]:
    st = state or hourly_state(day, now, model)
    H = st["frame"]
    now_utc = st["now_utc"]
    out: list[dict] = []
    have_fc = st["d0"] is not None

    # 1. capacity pressure ahead
    ahead = H[~H["elapsed"]].head(LOOKAHEAD_H + 1)
    for r in ahead.itertuples():
        mov = r.nowcast_mov if have_fc else r.planned_mov
        if mov is None or np.isnan(mov):
            continue
        u = mov / r.capacity if r.capacity else np.inf
        flows = {f: (getattr(r, f"nowcast_{f}" if have_fc else f"planned_{f}"), getattr(r, f"capacity_{f}")) for f in ("arr", "dep")}
        flow_over = {f: round(v / c, 2) for f, (v, c) in flows.items() if c and v / c >= 1.0}
        if u >= PRESSURE_U or flow_over:
            sev = "high" if u >= 1.0 or flow_over else "medium"
            out.append(_a("capacity_pressure", "reduced_capacity", sev, f"Capacity pressure {r.local_hour:02d}:00",
                          f"Expected {mov:.0f} movements vs effective capacity {r.capacity:.0f} (U = {u:.0%})"
                          + (f"; flow over capacity: {flow_over}" if flow_over else ""),
                          {"hour": int(r.local_hour), "expected_movements": round(float(mov), 1), "capacity": float(r.capacity), "utilisation": round(float(u), 3),
                           "source": "nowcast" if have_fc else "plan of record", "capacity_reduced_by_events": bool(r.capacity < r.capacity_base - 1e-9),
                           "includes_simulated_event": bool(r.capacity_includes_simulated_event)},
                          "predicted" if have_fc else "scheduled", [f"{r.local_hour:02d}:00", f"{(r.local_hour + 1) % 24:02d}:00"],
                          "Consider reviewing the runway configuration plan and flow measures for this hour with the responsible units."))

    if have_fc:
        # 2. cumulative forecast deviation
        A = sum(v["actual_so_far"] for v in st["ratios"].values() if v)
        F = sum(v["forecast_so_far"] for v in st["ratios"].values() if v)
        if F >= 50:
            dev, rel = A - F, (A - F) / F
            if abs(rel) >= DEV_REL and abs(dev) >= DEV_ABS:
                out.append(_a("forecast_deviation", "demand_surge" if dev > 0 else "movement_disruption", "high" if abs(rel) >= DEV_HIGH else "medium",
                              f"Traffic {'above' if dev > 0 else 'below'} D-0 forecast",
                              f"{A:.0f} movements so far vs {F:.0f} expected by now ({rel:+.0%})",
                              {"actual_so_far": A, "forecast_so_far": round(F, 1), "deviation": round(dev, 1), "relative": round(rel, 3), "model": st["model"]},
                              "derived", ["00:00", st["now"]],
                              "Consider checking for cancellations, diversions or extra flights and updating the day plan."))
        # 3. last completed hour
        done = H[H["elapsed"]]
        if len(done):
            r = done.iloc[-1]
            d = r["actual_mov"] - r["d0_mov"]
            if abs(d) > HOUR_DEV:
                out.append(_a("hour_deviation", "demand_surge" if d > 0 else "movement_disruption", "low",
                              f"{int(r['local_hour']):02d}:00 hour {'busier' if d > 0 else 'quieter'} than forecast",
                              f"{r['actual_mov']:.0f} movements vs {r['d0_mov']:.0f} forecast ({d:+.0f})",
                              {"hour": int(r["local_hour"]), "actual": float(r["actual_mov"]), "forecast": round(float(r["d0_mov"]), 1)},
                              "derived", [f"{int(r['local_hour']):02d}:00", f"{(int(r['local_hour']) + 1) % 24:02d}:00"],
                              "Consider whether the deviation continues in the next hour before acting."))
        # 4. unusual demand vs same weekdays
        s = snap()
        same = [d for d in s.days if d < day and d.weekday() == day.weekday()][-4:]
        if len(same) == 4:
            tot = s.daily.loc[same].sum(axis=1)
            mu, sd = float(tot.mean()), max(float(tot.std(ddof=1)), 20.0)
            nc = st["kpis"]["nowcast_total"]
            z = (nc - mu) / sd
            if abs(z) >= UNUSUAL_Z:
                out.append(_a("unusual_demand", "demand_surge" if z > 0 else "movement_disruption", "high" if abs(z) >= 4 else "medium",
                              f"Unusual day: {'high' if z > 0 else 'low'} demand",
                              f"Nowcast {nc:.0f} movements vs {mu:.0f} ± {sd:.0f} on the last 4 {day.strftime('%A')}s (z = {z:+.1f})",
                              {"nowcast_total": round(nc, 1), "same_weekday_mean": round(mu, 1), "sd": round(sd, 1), "z": round(z, 2),
                               "weekdays_used": [str(x) for x in same]}, "predicted", ["00:00", "24:00"],
                              "Consider investigating the cause (weather, airline schedule changes, events); causes are not in the data."))
        pt = st["kpis"]["planned_total"]
        nc = st["kpis"]["nowcast_total"]
        if pt and nc and abs(nc - pt) / pt > 0.10:
            out.append(_a("plan_deviation", "movement_disruption" if nc < pt else "demand_surge", "low", "Day deviates from the plan of record",
                          f"Nowcast {nc:.0f} vs {pt:.0f} scheduled ({(nc - pt) / pt:+.0%})", {"nowcast_total": round(nc, 1), "planned_total": pt,
                          "list": st["plan_of_record"]["list"]}, "predicted", ["00:00", "24:00"],
                          "Consider which operators drive the gap (see the flight timeline)."))

    # 5. overdue flights
    T = timeline if timeline is not None else FL.timeline(day, now)
    if len(T):
        w0 = now_utc - pd.Timedelta(hours=3)
        w1 = now_utc - pd.Timedelta(minutes=FL.OVERDUE_MIN)
        win = T[T["scheduled"] & (T["predicted_utc"] >= w0) & (T["predicted_utc"] < w1)]
        od = win[win["status"] == "overdue"]
        base = FL.baseline_cancel_rate(day)
        share = len(od) / len(win) if len(win) else 0.0
        threshold = max(2 * base, base + 0.10) if base is not None else 0.25
        if len(od) >= OVERDUE_COUNT and share >= threshold:
            ops = od["operator"].fillna("—").value_counts().head(5).to_dict()
            out.append(_a("overdue_flights", "movement_disruption", "medium", f"{len(od)} scheduled flights overdue",
                          f"{len(od)} of {len(win)} flights expected {utc_to_local_hhmm(w0)}–{utc_to_local_hhmm(w1)} have not operated ({share:.0%}; normal {0 if base is None else base:.0%})",
                          {"overdue": int(len(od)), "scheduled_in_window": int(len(win)), "overdue_share": round(share, 3),
                           "normal_rate": None if base is None else round(base, 3), "threshold": round(threshold, 3), "top_operators": ops},
                          "inferred", [utc_to_local_hhmm(w0), st["now"]],
                          "Consider confirming cancellations with the operators concerned; status is inferred, not confirmed."))

    # 6. data-feed gap
    hh = int(st["now"][:2])
    if 6 <= hh < 22 and have_fc:
        m = T[T["actual_utc"].notna()] if len(T) else T
        last = m["actual_utc"].max() if len(m) else None
        gap = (now_utc - last).total_seconds() / 60 if last is not None and not pd.isna(last) else None
        cur = H[(H["end_utc"] > now_utc - pd.Timedelta(minutes=FEED_GAP_MIN)) & (H["start_utc"] < now_utc)]
        expected = float((cur["d0_mov"] * FEED_GAP_MIN / 60).sum()) if len(cur) else 0.0
        if (gap is None or gap >= FEED_GAP_MIN) and expected >= FEED_MIN_EXPECTED:
            out.append(_a("data_feed_gap", "system_failure", "high", "No movements received",
                          f"No movement recorded for {gap:.0f} min" if gap else "No movement recorded today",
                          {"minutes_since_last": None if gap is None else round(gap), "expected_in_window": round(expected, 1)}, "derived",
                          [utc_to_local_hhmm(now_utc - pd.Timedelta(minutes=FEED_GAP_MIN)), st["now"]],
                          "Consider checking the movement data feed before acting on other indicators."))
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    return sorted(out, key=lambda a: (order[a["severity"]], a["id"]))


def timeline_of_alerts(day: date, model: str = "ensemble") -> list[dict]:
    """Per rule: when it was first raised during the day (evaluated hourly at :30), last seen,
    peak severity, and the hours it was active."""
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    agg: dict[str, dict] = {}
    for h in range(24):
        now = f"{h:02d}:30"
        for a in evaluate(day, now, model):
            x = agg.setdefault(a["rule"], {"rule": a["rule"], "rule_text": a["rule_text"], "category": a["category"],
                                           "first_raised": now, "first_title": a["title"], "peak_severity": a["severity"], "active_at": []})
            x["last_seen"] = now
            x["last_title"] = a["title"]
            if order[a["severity"]] < order[x["peak_severity"]]:
                x["peak_severity"] = a["severity"]
            if now not in x["active_at"]:
                x["active_at"].append(now)
    return sorted(agg.values(), key=lambda x: x["first_raised"])
