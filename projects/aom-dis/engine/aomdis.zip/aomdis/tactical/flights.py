"""Flight-level operational timeline at a replay clock.

Per flight: scheduled (planned reference time from the plan-of-record list), estimated (not in the
data -> unavailable), predicted runway time (planned + median offset learned from matches in the 28
days BEFORE the operational day, per operator & direction when ≥ 20 samples, else per direction),
actual (only if ≤ now) and deviations. Replay status:
    flown          actual ≤ now
    expected       not flown yet, predicted time ≥ now − 60 min
    overdue        not flown, predicted time < now − 60 min (possible cancellation — inferred, not confirmed)
    unscheduled    flown but not in the plan of record (shown only once flown)
"""
from __future__ import annotations

from datetime import date, timedelta
from functools import lru_cache

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..core.timeutil import local_to_utc
from ..db.session import engine
from ..ingest.pipeline import latest_dataset_version
from .state import tactical_plan

OVERDUE_MIN = 60


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


def baseline_cancel_rate(day: date) -> float | None:
    """Inferred cancellation share of scheduled flights over the 14 days before ``day`` (plan-of-record lists)."""
    return _baseline_cancel_rate(day, latest_dataset_version())


# Day-level results depend only on the day and the dataset version (re-ingest creates a new version),
# so they are cached; the replay clock is applied afterwards on a copy.
@lru_cache(maxsize=64)
def _baseline_cancel_rate(day: date, dsv: str) -> float | None:
    from .state import tactical_plan as tp
    num = den = 0.0
    for k in range(1, 15):
        d = day - timedelta(days=k)
        p = tp(d)
        if p is None:
            continue
        r = _q("select sum(case when state in ('canceled','confirmed_canceled') then 1 else 0 end) c, sum(case when state != 'added' then 1 else 0 end) n from movement_match "
               "where schedule_list_id=:l and local_date=:t", l=int(p["id"]), t=d.isoformat()).iloc[0]
        if r["n"]:
            num += float(r["c"])
            den += float(r["n"])
    return num / den if den else None


def offset_model(day: date) -> tuple[dict, dict]:
    """Median (actual − planned) offsets from matches with local_date in [day−28, day−1]."""
    return _offset_model(day, latest_dataset_version())


@lru_cache(maxsize=64)
def _offset_model(day: date, dsv: str) -> tuple[dict, dict]:
    m = _q("select mm.direction, coalesce(m.operator_icao, e.operator_icao) op, mm.offset_min from movement_match mm "
           "left join schedule_entry e on e.id=mm.schedule_entry_id left join movement m on m.id=mm.movement_id "
           "where mm.state='matched' and mm.local_date between :a and :b",
           a=(day - timedelta(days=28)).isoformat(), b=(day - timedelta(days=1)).isoformat())
    by_dir = m.groupby("direction")["offset_min"].median().to_dict()
    g = m.groupby(["op", "direction"])["offset_min"].agg(["median", "size"])
    by_op = {k: float(v["median"]) for k, v in g.iterrows() if v["size"] >= 20}
    return by_dir, by_op


def _hhmm_local(col: pd.Series) -> pd.Series:
    """Vectorised UTC (naive) -> Europe/Amsterdam 'HH:MM'; None where missing."""
    loc = col.dt.tz_localize("UTC").dt.tz_convert("Europe/Amsterdam").dt.strftime("%H:%M")
    return loc.astype(object).where(col.notna(), None)


def timeline(day: date, now: str) -> pd.DataFrame:
    base = _day_base(day, latest_dataset_version())
    if base.empty:
        return base.copy()
    now_utc = local_to_utc(day, now)
    T = base.copy()
    # replay: hide the future
    known = T["actual_utc"].notna() & (T["actual_utc"] <= now_utc)
    T.loc[~known, "actual_utc"] = pd.NaT
    T.loc[~known, "actual_local"] = None
    T = T[T["scheduled"] | known].copy()
    late = T["predicted_utc"] < now_utc - pd.Timedelta(minutes=OVERDUE_MIN)
    T["status"] = np.select([T["actual_utc"].notna() & T["scheduled"], T["actual_utc"].notna(), late], ["flown", "unscheduled", "overdue"], "expected")
    T["kind"] = T["status"].map({"flown": "actual", "unscheduled": "actual", "overdue": "inferred", "expected": "predicted"})
    T["dev_vs_planned_min"] = (T["actual_utc"] - T["planned_utc"]).dt.total_seconds() / 60
    T["dev_vs_predicted_min"] = (T["actual_utc"] - T["predicted_utc"]).dt.total_seconds() / 60
    T["sort_utc"] = T["actual_utc"].fillna(T["predicted_utc"])
    T = T.sort_values("sort_utc", kind="stable").reset_index(drop=True)
    T["estimated_local"] = None   # no estimated times in the source data
    return T


@lru_cache(maxsize=32)
def _day_base(day: date, dsv: str) -> pd.DataFrame:
    """All flights of the day with planned / predicted / actual times, before the replay clock is applied."""
    por = tactical_plan(day)
    by_dir, by_op = offset_model(day)
    rows = []
    if por is not None:
        lid = int(por["id"])
        e = _q("select e.id eid, e.flight_id, e.direction, e.other_airport, e.aircraft_type, e.operator_icao, e.planned_utc, "
               "e.planned_reference, mm.movement_id, m.callsign, m.actual_utc from schedule_entry e "
               "left join movement_match mm on mm.schedule_entry_id=e.id and mm.state='matched' "
               "left join movement m on m.id=mm.movement_id where e.schedule_list_id=:l and e.local_date=:t",
               l=lid, t=day.isoformat())
        for r in e.itertuples():
            off = by_op.get((r.operator_icao, r.direction), by_dir.get(r.direction, 0.0))
            planned = pd.Timestamp(r.planned_utc)
            pred = planned + pd.Timedelta(minutes=float(off))
            actual = pd.Timestamp(r.actual_utc) if r.actual_utc is not None and not pd.isna(r.actual_utc) else None
            rows.append({"flight": r.flight_id, "callsign": r.callsign, "direction": r.direction, "other": r.other_airport,
                         "type": r.aircraft_type, "operator": r.operator_icao, "planned_utc": planned,
                         "planned_reference": r.planned_reference, "predicted_utc": pred, "offset_basis": "operator" if (r.operator_icao, r.direction) in by_op else "direction",
                         "actual_utc": actual, "scheduled": True, "movement_id": r.movement_id})
        matched_ids = set(e["movement_id"].dropna().astype(int))
    else:
        matched_ids = set()
    mv = _q("select id, callsign, direction, other_airport, aircraft_type, operator_icao, actual_utc from movement "
            "where dataset_version_id=:d and local_date=:t", d=dsv, t=day.isoformat())
    for r in mv.itertuples():
        if r.id in matched_ids:
            continue
        rows.append({"flight": None, "callsign": r.callsign, "direction": r.direction, "other": r.other_airport, "type": r.aircraft_type,
                     "operator": r.operator_icao, "planned_utc": None, "planned_reference": None, "predicted_utc": None,
                     "offset_basis": None, "actual_utc": pd.Timestamp(r.actual_utc), "scheduled": False, "movement_id": r.id})
    T = pd.DataFrame(rows)
    if T.empty:
        return T
    for c in ("planned", "predicted", "actual"):
        T[f"{c}_utc"] = pd.to_datetime(T[f"{c}_utc"]).astype("datetime64[ns]")
        T[f"{c}_local"] = _hhmm_local(T[f"{c}_utc"])
    return T


def records(T: pd.DataFrame) -> list[dict]:
    cols = ["flight", "callsign", "direction", "other", "type", "operator", "status", "kind", "planned_local", "planned_reference",
            "estimated_local", "predicted_local", "offset_basis", "actual_local", "dev_vs_planned_min", "dev_vs_predicted_min"]
    out = []
    for r in T[cols].to_dict("records"):
        out.append({k: (None if isinstance(v, float) and np.isnan(v) else (round(v, 1) if isinstance(v, float) else v)) for k, v in r.items()})
    return out
