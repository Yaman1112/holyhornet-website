"""Hourly operational state of a day at a replay clock time, with the intraday nowcast.

Intraday nowcast (per flow f, for hours after ``now``):
    r_f = (A_f + λ) / (F_f + λ)        A = actual so far, F = D-0 forecast for the same elapsed hours
    nowcast_f(h) = D0_f(h) · r_f       for the remaining hours; elapsed hours use the actuals
λ = ∞ (r = 1): calibrated in Phase 10 with tools/nowcast_lambda_study.py on the first half of the
D-0 days only. Scaling the rest of the day by the realised-to-date ratio had no skill at 09:00 or
12:00 (MAE rose as λ fell), so the nowcast is "actuals so far + D-0 for the remaining hours".
The observed ratio A/F is still reported (and drives the forecast-deviation alert).
Hourly D-0 per flow = daily D-0 forecast of the flow × that flow's same-weekday hourly shape of the
last 4 weeks known before the day (Phase 4 rule).
"""
from __future__ import annotations

from datetime import date, timedelta
from functools import lru_cache

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..core.timeutil import hours_in_local_day, local_day_bounds_utc, local_to_utc
from ..db.session import engine
from ..forecasting import models as MD
from ..forecasting.data import hourly_shape, load
from ..ingest.pipeline import latest_dataset_version
from ..services.demand import capacity_meta, hourly_capacity

LAMBDA = float("inf")   # see module docstring; finite values re-enable ratio scaling
FLOWS = (("arr", "arrivals", "ARR"), ("dep", "departures", "DEP"))


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


@lru_cache(maxsize=2)
def snapshot(dsv: str):
    return load()


def snap():
    return snapshot(latest_dataset_version())


@lru_cache(maxsize=4)
def _match_cover(dsv: str) -> pd.DataFrame:
    c = _q("select mm.schedule_list_id lid, min(mm.local_date) a, max(mm.local_date) b from movement_match mm "
           "join schedule_list l on l.id=mm.schedule_list_id where l.dataset_version_id=:d group by 1", d=dsv)
    c["a"] = pd.to_datetime(c["a"]).dt.date
    c["b"] = pd.to_datetime(c["b"]).dt.date
    return c


def tactical_plan(day: date):
    """Plan of record for the replay: newest list published before ``day`` whose matching covers ``day``
    (a list's first local day is partial and unmatched, so the previous list stays the plan for it)."""
    s = snap()
    cov = _match_cover(s.dataset_version)
    ok = set(cov[(cov["a"] <= day) & (cov["b"] >= day)]["lid"])
    L = s.lists[(s.lists["published_date"] < day) & s.lists["id"].isin(ok)]
    return None if L.empty else L.sort_values("published_date").iloc[-1]


def day_hours(day: date) -> list[int]:
    return [h for h in range(24) if not (hours_in_local_day(day) == 23 and h == 2)]


def d0_forecast(day: date, model: str = "ensemble") -> dict | None:
    """Daily D-0 forecast (arrivals, departures) of a Phase 4 model for ``day`` from the forecast store."""
    mid = MD.model_version_id(model)
    f = _q("select f.metric, f.value, f.lower, f.upper from forecast f join forecast_run r on r.id=f.run_id "
           "where r.model_version_id=:m and r.dataset_version_id=:d and f.target_local_date=:t and f.horizon_days=0 "
           "and f.target_local_hour is null", m=mid, d=latest_dataset_version(), t=day.isoformat())
    if f.empty:
        return None
    return {r.metric: {"value": float(r.value), "lower": None if pd.isna(r.lower) else float(r.lower),
                       "upper": None if pd.isna(r.upper) else float(r.upper)} for r in f.itertuples()}


def available_days() -> dict:
    s = snap()
    d0 = _q("select distinct f.target_local_date d from forecast f join forecast_run r on r.id=f.run_id "
            "where r.model_version_id=:m and f.horizon_days=0", m=MD.model_version_id("ensemble"))
    return {"realised": [str(s.days[0]), str(s.days[-1])],
            "with_d0_forecast": sorted(str(x) for x in d0["d"]) if len(d0) else []}


def events_on(day: date) -> pd.DataFrame:
    a, b = local_day_bounds_utc(day)
    ev = _q("select * from operational_event where start_utc < :b and (end_utc is null or end_utc > :a) "
            "and status in ('active','closed') order by start_utc", a=str(a), b=str(b))
    for c in ("start_utc", "end_utc", "created_utc"):
        ev[c] = pd.to_datetime(ev[c])
    return ev


def hourly_state(day: date, now: str, model: str = "ensemble") -> dict:
    s = snap()
    now_utc = local_to_utc(day, now)
    d0_start, d0_end = local_day_bounds_utc(day)
    hours = day_hours(day)
    last_known = day - timedelta(days=1)
    H = pd.DataFrame({"local_hour": hours})
    H["start_utc"] = [local_to_utc(day, f"{h:02d}:00") for h in hours]
    H["end_utc"] = H["start_utc"].shift(-1).fillna(d0_end)
    H["elapsed"] = H["end_utc"] <= now_utc                      # hour fully in the past
    H["current"] = (H["start_utc"] <= now_utc) & (H["end_utc"] > now_utc)

    # actuals up to now (minute precision)
    m = _q("select direction, actual_utc from movement where dataset_version_id=:d and local_date=:t",
           d=s.dataset_version, t=day.isoformat())
    m["actual_utc"] = pd.to_datetime(m["actual_utc"])
    known = m[m["actual_utc"] <= now_utc]
    for short, _, dr in FLOWS:
        cnt = known[known["direction"] == dr].groupby(
            pd.cut(known.loc[known["direction"] == dr, "actual_utc"], bins=list(H["start_utc"]) + [d0_end], right=False, labels=hours)
        ).size()
        H[f"actual_{short}"] = [float(cnt.get(h, 0)) if st <= now_utc else np.nan for h, st in zip(hours, H["start_utc"])]

    # plan of record
    por = tactical_plan(day)
    if por is not None:
        e = _q("select direction, local_hour, count(*) n from schedule_entry where schedule_list_id=:l and local_date=:t group by 1,2",
               l=int(por["id"]), t=day.isoformat())
        for short, _, dr in FLOWS:
            g = e[e["direction"] == dr].set_index("local_hour")["n"]
            H[f"planned_{short}"] = [float(g.get(h, 0)) for h in hours]
    else:
        H["planned_arr"] = H["planned_dep"] = np.nan

    # D-0 forecast distributed per flow, and intraday nowcast
    d0 = d0_forecast(day, model)
    ratios = {}
    for short, metric, _ in FLOWS:
        sh = hourly_shape(s, metric, day, last_known)
        if d0 is None or sh is None:
            H[f"d0_{short}"] = np.nan
            H[f"nowcast_{short}"] = np.nan
            ratios[short] = None
            continue
        H[f"d0_{short}"] = [d0[metric]["value"] * float(sh.get(h, 0.0)) for h in hours]
        # elapsed share: full past hours + fraction of the current hour
        frac = np.where(H["elapsed"], 1.0, np.where(H["current"], ((now_utc - H["start_utc"]) / (H["end_utc"] - H["start_utc"])).astype(float), 0.0))
        F = float((H[f"d0_{short}"] * frac).sum())
        A = float(H[f"actual_{short}"].fillna(0).sum())
        r = 1.0 if np.isinf(LAMBDA) else (A + LAMBDA) / (F + LAMBDA)
        ratios[short] = {"actual_so_far": A, "forecast_so_far": F, "ratio": r, "observed_ratio": A / F if F > 0 else None}
        rest = 1 - frac
        H[f"nowcast_{short}"] = H[f"actual_{short}"].fillna(0) + H[f"d0_{short}"] * rest * r

    # effective capacity with events
    wd = [day.weekday()] * len(H)
    base_h = {"mov": hourly_capacity("total", wd, H["local_hour"]), "arr": hourly_capacity("arr", wd, H["local_hour"]),
              "dep": hourly_capacity("dep", wd, H["local_hour"])}
    base = {k: float(v.max()) for k, v in base_h.items()}
    cmeta = capacity_meta("total")
    ev = events_on(day)
    fac = np.ones(len(H))
    sim = np.zeros(len(H), dtype=bool)
    for e in ev.itertuples():
        if e.capacity_factor is None or pd.isna(e.capacity_factor):
            continue
        end = e.end_utc if not pd.isna(e.end_utc) else d0_end
        hit = (H["start_utc"] < end) & (H["end_utc"] > e.start_utc)
        fac = np.where(hit, fac * float(e.capacity_factor), fac)
        sim |= hit.to_numpy() & (e.kind == "simulated")
    H["capacity_base"] = base_h["mov"]
    H["capacity"] = base_h["mov"] * fac
    H["capacity_arr"] = base_h["arr"] * fac
    H["capacity_dep"] = base_h["dep"] * fac
    H["capacity_includes_simulated_event"] = sim
    for k in ("actual", "planned", "d0", "nowcast"):
        H[f"{k}_mov"] = H[f"{k}_arr"] + H[f"{k}_dep"]
    H["outlook_mov"] = np.where(H["elapsed"], H["actual_mov"], H["nowcast_mov"])
    H["outlook_util"] = H["outlook_mov"] / H["capacity"]
    H["outlook_gap"] = H["outlook_mov"] - H["capacity"]
    H["imbalance"] = np.where(H["elapsed"], H["actual_arr"] - H["actual_dep"], H["nowcast_arr"] - H["nowcast_dep"])

    so_far = {k: float(H[f"actual_{k}"].fillna(0).sum()) for k in ("arr", "dep")}
    return {
        "frame": H, "day": day, "now": now, "now_utc": now_utc, "model": model, "d0": d0, "ratios": ratios,
        "plan_of_record": None if por is None else {"list": por["name"], "published": str(por["published_date"])},
        "events": ev, "capacity_base": base, "capacity_status": cmeta["status"], "capacity_profile": cmeta["profile"],
        "kpis": {
            "planned_total": None if por is None else float(H["planned_mov"].sum()),
            "flown_so_far": so_far["arr"] + so_far["dep"],
            "d0_total": None if d0 is None else d0["arrivals"]["value"] + d0["departures"]["value"],
            "d0_interval": None if d0 is None or d0.get("movements", {}).get("lower") is None else [d0["movements"]["lower"], d0["movements"]["upper"]],
            "nowcast_total": None if H["nowcast_mov"].isna().all() else float(H["nowcast_mov"].sum()),
            "deviation_so_far": None if d0 is None else (so_far["arr"] + so_far["dep"]) - sum(v["forecast_so_far"] for v in ratios.values() if v),
        },
    }


def frame_records(H: pd.DataFrame) -> list[dict]:
    out = []
    for r in H.to_dict("records"):
        row = {}
        for k, v in r.items():
            if k in ("start_utc", "end_utc"):
                continue
            if isinstance(v, (bool, np.bool_)):
                row[k] = bool(v)
            elif isinstance(v, (float, np.floating)):
                row[k] = None if np.isnan(v) else round(float(v), 2)
            else:
                row[k] = int(v) if isinstance(v, np.integer) else v
        out.append(row)
    return out


def events_records(ev: pd.DataFrame) -> list[dict]:
    from ..core.timeutil import utc_to_local_hhmm
    out = []
    for e in ev.itertuples():
        out.append({"id": e.id, "category": e.category, "title": e.title, "severity": e.severity, "status": e.status, "kind": e.kind,
                    "source": e.source, "capacity_factor": None if pd.isna(e.capacity_factor) else float(e.capacity_factor),
                    "start_utc": str(e.start_utc), "end_utc": None if pd.isna(e.end_utc) else str(e.end_utc),
                    "start_local": utc_to_local_hhmm(e.start_utc), "end_local": None if pd.isna(e.end_utc) else utc_to_local_hhmm(e.end_utc),
                    "impact": e.impact})
    return out

