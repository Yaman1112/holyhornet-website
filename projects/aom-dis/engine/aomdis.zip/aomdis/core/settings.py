"""Environment-based settings and the airport configuration file."""
from __future__ import annotations

import hashlib
import os
import tomllib
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Settings:
    database_url: str = field(default_factory=lambda: os.environ.get(
        "AOMDIS_DATABASE_URL", f"sqlite:///{(ROOT / 'data' / 'warehouse' / 'aomdis.sqlite').as_posix()}"))
    raw_dir: Path = field(default_factory=lambda: Path(os.environ.get("AOMDIS_RAW_DIR", ROOT / "data" / "raw")))
    config_file: Path = field(default_factory=lambda: Path(os.environ.get("AOMDIS_CONFIG", ROOT / "config" / "eham.toml")))
    reports_dir: Path = field(default_factory=lambda: Path(os.environ.get("AOMDIS_REPORTS", ROOT / "outputs" / "aomdis")))


def browser_mode() -> bool:
    """True in the static browser edition (backend on Pyodide in a Web Worker): no threads, no legacy mounts."""
    return os.environ.get("AOMDIS_BROWSER", "0") == "1"


@lru_cache(maxsize=1)
def settings() -> Settings:
    return Settings()


@dataclass(frozen=True)
class AirportConfig:
    raw: dict
    sha256: str

    @property
    def icao(self) -> str:
        return self.raw["airport"]["icao"]

    @property
    def timezone(self) -> str:
        return self.raw["airport"]["timezone"]

    @property
    def naive_tz(self) -> str:
        return self.raw["data"]["naive_timestamp_timezone"]

    def capacity(self, key: str):
        for c in self.raw.get("capacity", []):
            if c["key"] == key:
                return c
        raise KeyError(key)

    def value(self, key: str):
        return self.capacity(key)["value"]


def load_airport_config(path: Path | None = None) -> AirportConfig:
    p = Path(path or settings().config_file)
    data = p.read_bytes()
    raw = tomllib.loads(data.decode("utf-8"))
    _validate(raw)
    return AirportConfig(raw, hashlib.sha256(data).hexdigest())


_STATUSES = {"public-reference", "assumption", "derived"}


def _validate(raw: dict) -> None:
    for section in ("airport", "data"):
        if section not in raw:
            raise ValueError(f"config: missing [{section}]")
    items = [raw["airport"], raw["data"], *raw.get("runway", []), *raw.get("capacity", [])]
    for it in items:
        if it.get("status") not in _STATUSES:
            raise ValueError(f"config: every parameter needs status in {_STATUSES}: {it}")
        if not it.get("source"):
            raise ValueError(f"config: every parameter needs a source: {it}")
