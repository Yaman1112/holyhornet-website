"""Data-kind labels carried by every value the platform shows (brief: 'clearly distinguish
actual, scheduled, predicted, simulated and unavailable information')."""
from __future__ import annotations

from enum import StrEnum


class Kind(StrEnum):
    ACTUAL = "actual"            # observed in a source dataset
    SCHEDULED = "scheduled"      # from a published schedule / traffic list
    PREDICTED = "predicted"      # model output
    SIMULATED = "simulated"      # digital-twin / what-if output
    DERIVED = "derived"          # computed from observations by a documented formula
    INFERRED = "inferred"        # concluded by matching/heuristics (e.g. cancellations)
    ASSUMPTION = "assumption"    # configured parameter without authoritative source
    UNAVAILABLE = "unavailable"  # no data source


def value(v, kind: Kind, **meta) -> dict:
    return {"value": v, "kind": str(kind), **meta}
