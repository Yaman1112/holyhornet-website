"""KPI definitions: the single registry of what every headline figure means (requirement KPI-1).

Each entry: id, name, formula, unit, kind (provenance), granularity, where (code that computes it),
caveats. Served at GET /api/v1/system/kpis and rendered in docs/KPI_DEFINITIONS.md
(tools/gen_kpi_docs.py). Notation: A(t) arrivals, D(t) departures, M(t) = A(t) + D(t) movements in
local hour or local day t (Europe/Amsterdam), C(t) configured capacity of the active profile,
S(t) scheduled movements of the plan of record, F(t) forecast.
"""
from __future__ import annotations

KPIS: list[dict] = [
    # ------------------------------------------------------------------ traffic
    {"id": "movements", "name": "Total movements", "formula": "M(t) = A(t) + D(t)", "unit": "movements", "kind": "actual",
     "granularity": "hour, day, range", "where": "aomdis.services.demand", "caveats": "Runway movements at EHAM from the realisation file; local time buckets."},
    {"id": "arrivals", "name": "Arrival movements", "formula": "A(t) = count of realised movements with direction ARR in t", "unit": "movements",
     "kind": "actual", "granularity": "hour, day", "where": "aomdis.services.demand", "caveats": ""},
    {"id": "departures", "name": "Departure movements", "formula": "D(t) = count of realised movements with direction DEP in t", "unit": "movements",
     "kind": "actual", "granularity": "hour, day", "where": "aomdis.services.demand", "caveats": ""},
    {"id": "daily_movements", "name": "Daily movements", "formula": "Σ_h M(h) over the local operational day", "unit": "movements/day",
     "kind": "actual", "granularity": "day", "where": "aomdis.services.demand",
     "caveats": "DST days have 23 or 25 hours; partial first/last days of the dataset are excluded from averages."},
    {"id": "peak_hour", "name": "Peak-hour movements", "formula": "max_h M(h) within the day or range (and the hour where it occurs)",
     "unit": "movements/hour", "kind": "actual", "granularity": "day, range", "where": "aomdis.services.command", "caveats": "Ties resolve to the earliest hour."},
    {"id": "hourly_share", "name": "Movement distribution", "formula": "M(h) / Σ_h M(h)", "unit": "share", "kind": "derived",
     "granularity": "hour of day", "where": "aomdis.forecasting.data.hourly_shape", "caveats": ""},
    {"id": "demand_cv", "name": "Demand variation", "formula": "CV = std(M_day) / mean(M_day) over complete days", "unit": "ratio",
     "kind": "derived", "granularity": "range", "where": "aomdis.api.system (KPI evaluation)", "caveats": "Includes weekday pattern; not a measure of irregularity alone."},
    # ------------------------------------------------------------------ plan vs actual
    {"id": "plan_deviation", "name": "Deviation vs schedule", "formula": "Σ M(t) − Σ S(t) over days with both", "unit": "movements",
     "kind": "derived", "granularity": "day, range", "where": "aomdis.services.command", "caveats": "Plan of record = newest list published before the day that covers it."},
    {"id": "cancel_rate", "name": "Inferred cancellation rate", "formula": "N(listed, not flown) / N(listed) per plan of record",
     "unit": "share", "kind": "inferred", "granularity": "day, range", "where": "aomdis.services.command",
     "caveats": "The data has no cancellation field: a scheduled movement with no matching realised movement is inferred cancelled. "
                "Identity mismatches (business aviation callsigns) inflate it."},
    {"id": "unscheduled", "name": "Unscheduled movements", "formula": "N(flown, not in plan of record)", "unit": "movements", "kind": "inferred",
     "granularity": "day, range", "where": "aomdis.postops.metrics", "caveats": "Same matching caveat as the cancellation rate."},
    {"id": "runway_offset", "name": "Runway-time deviation (delay indicator)", "formula": "median(actual runway time − planned reference time) of matched movements",
     "unit": "minutes", "kind": "derived", "granularity": "day", "where": "aomdis.postops.metrics",
     "caveats": "Planned reference is SOBT (departures) or the FIR-entry estimate (arrivals), not SIBT/SOBT at the gate: a proxy for delay, not a delay statistic."},
    {"id": "late_share", "name": "Share more than 15 min after prediction", "formula": "N(actual − predicted runway time > 15 min) / N(matched)",
     "unit": "share", "kind": "derived", "granularity": "day", "where": "aomdis.postops.metrics", "caveats": "Prediction = planned + learned median offset."},
    # ------------------------------------------------------------------ capacity
    {"id": "utilisation", "name": "Capacity utilisation", "formula": "U(t) = M(t) / C(t)", "unit": "ratio", "kind": "derived",
     "granularity": "hour", "where": "aomdis.services.demand", "caveats": "C(t) comes from the active capacity profile; its values are assumptions, not declared capacity."},
    {"id": "gap", "name": "Capacity gap", "formula": "G(t) = M(t) − C(t)  (positive = demand above capacity)", "unit": "movements/hour",
     "kind": "derived", "granularity": "hour", "where": "aomdis.services.demand", "caveats": "Same capacity caveat."},
    {"id": "headroom", "name": "Capacity headroom", "formula": "H(t) = max(0, C(t) − M(t))", "unit": "movements/hour", "kind": "derived",
     "granularity": "hour", "where": "aomdis.capacity.analysis", "caveats": "Same capacity caveat."},
    {"id": "pressure_hours", "name": "Capacity-pressure hours", "formula": "N(hours with U(t) ≥ 0.9, actual or planned)", "unit": "hours",
     "kind": "derived", "granularity": "range", "where": "aomdis.services.command", "caveats": "Threshold 90 % is a configurable assumption."},
    {"id": "observed_throughput", "name": "Observed throughput", "formula": "p95 and maximum of realised M(h) over complete days (per flow)",
     "unit": "movements/hour", "kind": "actual", "granularity": "range", "where": "aomdis.capacity.analysis.observed_throughput",
     "caveats": "What the airport actually handled. It is a lower bound on capacity in the observed conditions, not capacity itself."},
    # ------------------------------------------------------------------ forecast accuracy
    {"id": "mae", "name": "Mean absolute error", "formula": "MAE = mean |a − f|", "unit": "movements", "kind": "derived",
     "granularity": "per model, horizon", "where": "aomdis.core.metrics", "caveats": ""},
    {"id": "rmse", "name": "Root mean squared error", "formula": "RMSE = sqrt(mean (a − f)²)", "unit": "movements", "kind": "derived",
     "granularity": "per model, horizon", "where": "aomdis.core.metrics", "caveats": "Penalises large misses more than MAE."},
    {"id": "bias", "name": "Bias", "formula": "mean (a − f)   (positive = forecast too low)", "unit": "movements", "kind": "derived",
     "granularity": "per model, horizon", "where": "aomdis.core.metrics", "caveats": ""},
    {"id": "wape", "name": "Weighted absolute percentage error", "formula": "WAPE = 100 · Σ|a − f| / Σ|a|", "unit": "%", "kind": "derived",
     "granularity": "per model, horizon", "where": "aomdis.core.metrics", "caveats": "Headline percentage error. Undefined (null) when Σ|a| = 0."},
    {"id": "mase", "name": "Mean absolute scaled error", "formula": "MASE = MAE / mean |y_t − y_{t−m}| (training history, m = 7 days or 168 hours)",
     "unit": "ratio", "kind": "derived", "granularity": "per model, horizon", "where": "aomdis.core.metrics",
     "caveats": "< 1 beats a seasonal-naive forecast on the training history scale. Scale uses data before the evaluation window only."},
    {"id": "mape", "name": "Mean absolute percentage error", "formula": "MAPE = 100 · mean(|a − f| / |a|) over pairs with |a| ≥ 1",
     "unit": "%", "kind": "derived", "granularity": "per model, horizon", "where": "aomdis.core.metrics",
     "caveats": "Kept for continuity; excluded pairs are counted (mape_excluded_share). Do not use for hourly series with zeros."},
    {"id": "pi_coverage", "name": "Prediction-interval coverage", "formula": "share of actuals inside the 80 % empirical interval",
     "unit": "share", "kind": "derived", "granularity": "per model, horizon", "where": "aomdis.core.metrics",
     "caveats": "Empirical quantiles of past residuals; not a guaranteed confidence level."},
]

_BY_ID = {k["id"]: k for k in KPIS}


def get(kpi_id: str) -> dict:
    return _BY_ID[kpi_id]
