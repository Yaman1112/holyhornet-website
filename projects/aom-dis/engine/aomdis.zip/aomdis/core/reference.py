"""Shared aircraft and geography reference data.

Aircraft code letters follow the ICAO aerodrome reference code (wingspan class) for the
common types in the data; unlisted types default to "C" and are flagged as defaulted.
Wake categories here are a simplification (L/M/H/J) used only by simulations.
"""
from __future__ import annotations

_CODE = {
    "F": {"A388", "B748", "A225", "AN124"},
    "E": {"B77W", "B77L", "B772", "B773", "B744", "B789", "B78X", "B788", "A359", "A35K", "A333",
          "A332", "A339", "A343", "A346", "A338", "B779", "MD11"},
    "D": {"B763", "B764", "B762", "B752", "B753", "A306", "A310", "IL76", "DC10"},
    "B": {"E145", "E135", "CRJ2", "AT72", "AT76", "AT45", "DH8D", "DH8C", "SF34", "F50", "D328", "J328", "D228"},
    "A": {"PC12", "C510", "C525", "C25A", "C25B", "C56X", "E55P", "BE40", "LJ45", "C68A", "C680", "CL35",
          "F2TH", "FA7X", "F900", "GLEX", "GLF4", "GLF5", "GLF6", "C650", "E35L", "C700", "EC35", "EC45",
          "H25B", "BE20", "BE9L", "P180", "PA46", "C750", "G280", "FA8X", "CL60", "E50P", "SR22", "PC24"},
}
CODE_ORDER = "ABCDEF"
WAKE = {"A": "L", "B": "M", "C": "M", "D": "H", "E": "H", "F": "J"}

# ICAO location prefixes of Schengen states in 2022 (Croatia joined 2023; Bulgaria/Romania later).
SCHENGEN_PREFIXES_2022 = {"EB", "ED", "EE", "EF", "EH", "EK", "EL", "EN", "EP", "ES", "ET", "EV", "EY",
                          "LE", "LF", "LG", "LH", "LI", "LJ", "LK", "LM", "LO", "LP", "LS", "LZ", "BI", "GC"}


def code_letter(ac_type: str | None) -> str:
    t = (ac_type or "").upper()
    for k, s in _CODE.items():
        if t in s:
            return k
    return "C"


def code_is_tabulated(ac_type: str | None) -> bool:
    t = (ac_type or "").upper()
    return any(t in s for s in _CODE.values())


def is_schengen(icao: str | None) -> bool:
    return bool(icao) and icao[:2].upper() in SCHENGEN_PREFIXES_2022
