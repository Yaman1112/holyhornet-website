"""Explicit time-zone handling.

Storage convention: every instant is stored as naive **UTC** (``*_utc`` columns) plus the
derived airport-local date and hour (``local_date``, ``local_hour``) and the UTC offset
in minutes that applied (``utc_offset_min``), so DST is visible in the data.
"""
from __future__ import annotations

from zoneinfo import ZoneInfo

import pandas as pd

AMS = "Europe/Amsterdam"


def to_utc(naive: pd.Series, source_tz: str = "UTC") -> pd.Series:
    """Interpret naive timestamps in ``source_tz`` and return naive UTC."""
    s = pd.to_datetime(naive)
    if s.dt.tz is not None:
        return s.dt.tz_convert("UTC").dt.tz_localize(None)
    if source_tz == "UTC":
        return s
    return s.dt.tz_localize(source_tz, ambiguous="NaT", nonexistent="NaT").dt.tz_convert("UTC").dt.tz_localize(None)


def local_fields(utc: pd.Series, tz: str = AMS) -> pd.DataFrame:
    """local_time (naive local wall clock), local_date, local_hour, utc_offset_min for naive-UTC input."""
    aware = pd.to_datetime(utc).dt.tz_localize("UTC").dt.tz_convert(tz)
    off = (aware.dt.tz_localize(None) - pd.to_datetime(utc)).dt.total_seconds() / 60
    return pd.DataFrame({
        "local_time": aware.dt.tz_localize(None),
        "local_date": aware.dt.date,
        "local_hour": aware.dt.hour.astype("Int64"),
        "utc_offset_min": off.astype("Int64"),
    }, index=utc.index)


def local_day_bounds_utc(day, tz: str = AMS) -> tuple[pd.Timestamp, pd.Timestamp]:
    """[start, end) of a local calendar day as naive UTC. A DST day is 23 or 25 hours long."""
    z = ZoneInfo(tz)
    start = pd.Timestamp(day).tz_localize(z)
    end = (pd.Timestamp(day) + pd.Timedelta(days=1)).tz_localize(z)
    return start.tz_convert("UTC").tz_localize(None), end.tz_convert("UTC").tz_localize(None)


def hours_in_local_day(day, tz: str = AMS) -> int:
    a, b = local_day_bounds_utc(day, tz)
    return int((b - a) / pd.Timedelta(hours=1))


def local_to_utc(day, hhmm: str, tz: str = AMS) -> pd.Timestamp:
    """Local wall-clock time on ``day`` -> naive UTC. Non-existent times (spring-forward gap) move
    forward to the first valid instant; ambiguous times (fall-back) take the first occurrence."""
    h, m = (int(x) for x in hhmm.split(":"))
    ts = pd.Timestamp(day) + pd.Timedelta(hours=h, minutes=m)
    loc = ts.tz_localize(ZoneInfo(tz), nonexistent="shift_forward", ambiguous=True)
    return loc.tz_convert("UTC").tz_localize(None)


def utc_to_local_hhmm(ts: pd.Timestamp, tz: str = AMS) -> str:
    return pd.Timestamp(ts).tz_localize("UTC").tz_convert(ZoneInfo(tz)).strftime("%H:%M")
