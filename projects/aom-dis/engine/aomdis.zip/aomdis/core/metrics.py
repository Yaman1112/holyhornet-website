"""Forecast-error metrics with explicit zero-denominator rules (single source for every module).

Notation: a = actual, p = forecast, e = a − p, over the n pairs where both are finite.

| Metric | Formula | Undefined when (-> None) |
|---|---|---|
| MAE   | mean(|e|)                                   | n = 0 |
| RMSE  | sqrt(mean(e²))                              | n = 0 |
| Bias  | mean(e)   (positive = under-forecast)        | n = 0 |
| WAPE  | 100 · Σ|e| / Σ|a|                           | Σ|a| = 0 |
| MASE  | MAE / scale, scale = mean |y_t − y_{t−m}| of the training history (m = 7 for daily data) | scale missing or 0 |
| MAPE  | 100 · mean(|e| / |a|) over pairs with |a| ≥ floor; reported with the share of pairs excluded | no pair passes the floor |

WAPE is the headline percentage error: it is defined whenever total actual volume is non-zero and is not
inflated by near-zero hours (e.g. 03:00 at an airport with a night regime). MAPE is kept for continuity
with earlier reports and is always accompanied by ``mape_excluded_share``; it must not be used for
hourly series with zeros.

MASE scale must come from data available before the evaluated forecasts (no leakage): callers pass
``history`` = the actual series up to the start of the evaluation window.
"""
from __future__ import annotations

import math
from typing import Iterable

import numpy as np

MAPE_FLOOR = 1.0     # pairs whose |actual| is below this are excluded from MAPE (and counted)


def _arr(x: Iterable) -> np.ndarray:
    return np.asarray(list(x) if not isinstance(x, np.ndarray) else x, dtype=float)


def naive_scale(history: Iterable, m: int = 7) -> float | None:
    """Mean absolute m-step seasonal difference of the training history (MASE denominator)."""
    h = _arr(history)
    h = h[np.isfinite(h)]
    if len(h) <= m:
        return None
    d = np.abs(h[m:] - h[:-m])
    s = float(d.mean())
    return s if s > 0 else None


def errors(actual: Iterable, forecast: Iterable, scale: float | None = None, mape_floor: float = MAPE_FLOOR) -> dict:
    """All point-error metrics for one set of (actual, forecast) pairs. Values are floats or None."""
    a, p = _arr(actual), _arr(forecast)
    ok = np.isfinite(a) & np.isfinite(p)
    a, p = a[ok], p[ok]
    n = int(len(a))
    if n == 0:
        return {"n": 0, "mae": None, "rmse": None, "bias": None, "wape": None, "mase": None, "mape": None, "mape_excluded_share": None}
    e = a - p
    abs_e = np.abs(e)
    mae = float(abs_e.mean())
    vol = float(np.abs(a).sum())
    keep = np.abs(a) >= mape_floor
    return {
        "n": n,
        "mae": mae,
        "rmse": float(math.sqrt(float((e ** 2).mean()))),
        "bias": float(e.mean()),
        "wape": 100.0 * float(abs_e.sum()) / vol if vol > 0 else None,
        "mase": mae / scale if scale else None,
        "mape": 100.0 * float((abs_e[keep] / np.abs(a[keep])).mean()) if keep.any() else None,
        "mape_excluded_share": float(1.0 - keep.mean()),
    }


def interval_coverage(actual: Iterable, lower: Iterable, upper: Iterable) -> tuple[int, float | None]:
    """(number of pairs with an interval, share of actuals inside [lower, upper])."""
    a, lo, hi = _arr(actual), _arr(lower), _arr(upper)
    has = np.isfinite(a) & np.isfinite(lo) & np.isfinite(hi)
    if not has.any():
        return 0, None
    return int(has.sum()), float(((a[has] >= lo[has]) & (a[has] <= hi[has])).mean())
