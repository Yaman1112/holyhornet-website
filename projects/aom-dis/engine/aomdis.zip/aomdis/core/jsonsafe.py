"""Strict-JSON conversion for every API response (numerical-integrity rule NI-1).

Rules (docs/DATA_DICTIONARY.md, "Value semantics"):
* NaN, +inf, -inf, pandas NA/NaT  -> null   (an unavailable value is null, never a fake number)
* numpy / pandas scalars          -> the equivalent Python int / float / bool
* numpy arrays, pandas Series     -> lists;  DataFrame -> list of records
* datetime / date / Timestamp     -> ISO-8601 string (naive values are UTC unless the field says local)
* Decimal                         -> float (finite) or null
* sets / tuples                   -> lists

The conversion is pure and total: it never raises on a value it does not know; such values are
converted with ``str()`` so a bug shows up as an odd string in the response, not as a 500.
"""
from __future__ import annotations

import datetime as _dt
import math
from decimal import Decimal
from typing import Any

try:  # numpy/pandas are always installed on the server; guarded so this module stays importable anywhere
    import numpy as _np
except ImportError:  # pragma: no cover
    _np = None
try:
    import pandas as _pd
except ImportError:  # pragma: no cover
    _pd = None


def _float(x: float) -> float | None:
    return x if math.isfinite(x) else None


def to_jsonable(x: Any) -> Any:
    """Recursively convert ``x`` into values the strict JSON encoder accepts (see module docstring)."""
    if x is None or isinstance(x, (str, bool)):
        return x
    if isinstance(x, int):
        return x
    if isinstance(x, float):
        return _float(x)
    if isinstance(x, dict):
        return {str(k) if not isinstance(k, str) else k: to_jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple, set, frozenset)):
        return [to_jsonable(v) for v in x]
    if isinstance(x, Decimal):
        return _float(float(x))
    if _pd is not None and (x is _pd.NaT or x is _pd.NA):    # NaT subclasses datetime: test it first
        return None
    if isinstance(x, (_dt.datetime, _dt.date, _dt.time)):
        return x.isoformat()
    if _pd is not None:
        if isinstance(x, _pd.Timestamp):
            return x.isoformat()
        if isinstance(x, _pd.Timedelta):
            return x.total_seconds()
        if isinstance(x, _pd.DataFrame):
            return [to_jsonable(r) for r in x.to_dict("records")]
        if isinstance(x, _pd.Series):
            return [to_jsonable(v) for v in x.tolist()]
    if _np is not None:
        if isinstance(x, _np.bool_):
            return bool(x)
        if isinstance(x, _np.integer):
            return int(x)
        if isinstance(x, _np.floating):
            return _float(float(x))
        if isinstance(x, _np.datetime64):
            return None if _np.isnat(x) else str(x)
        if isinstance(x, _np.ndarray):
            return [to_jsonable(v) for v in x.tolist()]
    if hasattr(x, "model_dump"):          # pydantic models
        return to_jsonable(x.model_dump())
    return str(x)


def is_strict_json_value(x: Any) -> bool:
    """True if ``x`` contains only JSON types and finite floats (used by the API contract tests)."""
    if x is None or isinstance(x, (str, bool, int)):
        return True
    if isinstance(x, float):
        return math.isfinite(x)
    if isinstance(x, dict):
        return all(isinstance(k, str) and is_strict_json_value(v) for k, v in x.items())
    if isinstance(x, list):
        return all(is_strict_json_value(v) for v in x)
    return False
