"""Reproducibility metadata for simulation and scenario runs (requirement SIM-2).

Every run of a scenario engine records:
* algorithm and algorithm_version = sha256 of the engine's source files (first 12 hex digits)
* dataset_version (the warehouse snapshot the inputs come from)
* capacity_profile = active profile id + digest of its rules as stored
* executed_utc and runtime versions (python, numpy, pandas)
* result_digest = sha256 of the canonical JSON of the outputs (floats rounded to 6 decimals, metadata excluded)

A saved scenario can then be re-run and compared: identical digest = reproduced; otherwise the
metadata says which input changed (data, capacity, algorithm or runtime).
"""
from __future__ import annotations

import hashlib
import importlib
import inspect
import json
import platform
from datetime import datetime, timezone
from functools import lru_cache

from .jsonsafe import to_jsonable

ALGORITHMS = {
    "twin": ("aomdis.twin.engine", "aomdis.twin.model", "aomdis.twin.scenarios"),
    "strategic": ("aomdis.strategic.scenarios", "aomdis.strategic.profiles"),
}
META_KEY = "reproducibility"
_VOLATILE = {META_KEY, "dataset_version", "module", "id", "name", "created_by", "created_utc"}


@lru_cache(maxsize=8)
def algorithm_version(algorithm: str) -> str:
    h = hashlib.sha256()
    for mod in ALGORITHMS[algorithm]:
        h.update(inspect.getsource(importlib.import_module(mod)).replace("\r\n", "\n").encode())
    return h.hexdigest()[:12]


def _round(x):
    if isinstance(x, float):
        return round(x, 6)
    if isinstance(x, dict):
        return {k: _round(v) for k, v in x.items()}
    if isinstance(x, list):
        return [_round(v) for v in x]
    return x


def result_digest(result: dict) -> str:
    core = {k: v for k, v in result.items() if k not in _VOLATILE}
    canon = json.dumps(_round(to_jsonable(core)), sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canon.encode()).hexdigest()[:16]


def metadata(algorithm: str, result: dict) -> dict:
    import numpy
    import pandas

    from ..capacity import profile as PR
    from ..ingest.pipeline import latest_dataset_version
    pid = PR.active_id()
    return {
        "algorithm": algorithm,
        "algorithm_version": algorithm_version(algorithm),
        "dataset_version": latest_dataset_version(),
        "capacity_profile": {"id": pid, "digest": PR._stamp(pid)},
        "executed_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "runtime": {"python": platform.python_version(), "numpy": numpy.__version__, "pandas": pandas.__version__},
        "result_digest": result_digest(result),
    }


def attach(algorithm: str, result: dict) -> dict:
    result[META_KEY] = metadata(algorithm, result)
    return result


def compare(stored: dict, rerun: dict) -> dict:
    """Compare a stored result with a fresh re-run of the same spec.

    reproduced = digest of the stored outputs == digest of the re-run outputs.
    integrity  = the stored outputs still match the digest recorded when they were saved
                 (False means the stored result was altered after saving)."""
    a, b = stored.get(META_KEY), rerun[META_KEY]
    stored_digest = result_digest(stored)
    integrity = None if not a else stored_digest == a["result_digest"]
    same = stored_digest == b["result_digest"]
    changed = []
    if a:
        for key in ("algorithm_version", "dataset_version"):
            if a.get(key) != b.get(key):
                changed.append({"input": key, "stored": a.get(key), "now": b.get(key)})
        if a.get("capacity_profile") != b.get("capacity_profile"):
            changed.append({"input": "capacity_profile", "stored": a.get("capacity_profile"), "now": b.get("capacity_profile")})
        if a.get("runtime") != b.get("runtime"):
            changed.append({"input": "runtime", "stored": a.get("runtime"), "now": b.get("runtime")})
    note = "identical outputs" if same else ("outputs differ" + (": inputs changed since the scenario was saved" if changed else
                                             ": no recorded input changed — investigate (non-determinism or untracked dependency)"))
    if integrity is False:
        note += "; the stored result no longer matches the digest recorded when it was saved"
    if not a:
        note += " (scenario saved before reproducibility tracking)"
    return {"reproduced": same, "stored_integrity": integrity, "stored_digest": stored_digest, "rerun_digest": b["result_digest"],
            "recorded_digest": a["result_digest"] if a else None, "stored_metadata": a, "rerun_metadata": b,
            "changed_inputs": changed, "note": note}
