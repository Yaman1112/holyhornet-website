"""``python -m aomdis <command>``

  migrate   upgrade the database schema (Alembic)
  ingest    load raw files into the warehouse (idempotent; --force to reload)
  quality   print and save the data-quality report of the latest dataset version
  validate  run the flight-data validation suite DQ-1…DQ-9 (exit code 1 if an error-level check fails)
  forecasts store the original D-7 calibrated model's forecasts (fpred adapter)
  backtest  pre-tactical D-7…D-0 rolling-origin backtest of the model suite (stores forecasts + evaluations)
  postops   rebuild the daily post-operations performance store (all planning layers vs actual)
  create-user --username U --role R [--display-name N]   (password read from prompt or AOMDIS_NEW_PASSWORD)
  seed-dev-users   one account per role with random passwords -> data/warehouse/dev_users.txt (git-ignored)
"""
from __future__ import annotations

import argparse
import logging
import time

from .db.session import migrate
from .ingest import pipeline, quality


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    ap = argparse.ArgumentParser(prog="aomdis")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("migrate")
    p = sub.add_parser("ingest")
    p.add_argument("--force", action="store_true")
    sub.add_parser("quality")
    sub.add_parser("validate")
    sub.add_parser("forecasts")
    sub.add_parser("backtest")
    sub.add_parser("postops")
    cu = sub.add_parser("create-user")
    cu.add_argument("--username", required=True)
    cu.add_argument("--role", required=True)
    cu.add_argument("--display-name")
    sub.add_parser("seed-dev-users")
    a = ap.parse_args(argv)

    if a.cmd == "migrate":
        migrate()
        print("schema at head")
    elif a.cmd == "ingest":
        t = time.time()
        r = pipeline.ingest(force=a.force)
        if r.skipped:
            print(f"dataset version {r.dataset_version} already loaded (use --force to reload)")
        else:
            print(f"dataset version {r.dataset_version} loaded in {time.time() - t:.1f}s: {r.counts}")
            for i in r.issues:
                print(f"  [{i.severity:5}] {i.check:22} {i.rows:>7}  {i.message}")
    elif a.cmd == "quality":
        rep = quality.report()
        path = quality.write_report(rep)
        print(f"dataset {rep['dataset_version']['id']}  movements {rep['coverage']['movement_days']}")
        print("DST days:", rep["coverage"]["dst_days"])
        print("low-traffic days (robust z < -3):", rep["coverage"]["low_traffic_days"])
        for s in rep["sources"]:
            print(f"  {s['kind']:13} {s['file_name']:32} raw {s['rows_raw']:>7} loaded {s['rows_loaded']:>7}")
        print("report:", path)
    elif a.cmd == "validate":
        from .ingest import validation
        r = validation.run()
        for c in r["checks"]:
            print(f"  {c['id']:5} {c['status']:7} {c['failing']:>6}/{c['checked']:<7} {c['title']}")
        print("validation:", "OK" if r["ok"] else "FAILED (error-level checks failed)")
        return 0 if r["ok"] else 1
    elif a.cmd == "forecasts":
        from .adapters import fpred_forecast
        r = fpred_forecast.run()
        print(r["model_version"], {k: (v if isinstance(v, str) else f"{v['rows']} rows, {v['days']} days") for k, v in r["lists"].items()})
    elif a.cmd == "backtest":
        from .forecasting import backtest as B
        t = time.time()
        r = B.run(progress=lambda p: print(f"  {p:5.0%}", end=chr(13)))
        print()
        print(f"window {r['window']}  cutoffs {r['cutoffs']}  predictions {r['predictions']}  ({time.time() - t:.0f}s)")
        for o in sorted((o for o in r["evaluation"]["overall"] if o["metric"] == "movements"), key=lambda o: o["mae"]):
            cov = "" if o.get("coverage") is None else f"  80%-PI coverage {o['coverage']:.0%}"
            print(f"  {o['model']:18} MAE {o['mae']:6.1f}  RMSE {o['rmse']:6.1f}  bias {o['bias']:+6.1f}{cov}")
    elif a.cmd == "postops":
        from .postops import metrics as PM
        t = time.time()
        D = PM.compute(progress=lambda p: print(f"  {p:5.0%}", end=chr(13)))
        print()
        print(f"daily performance store: {D['period_start'].nunique()} days, {len(D)} rows ({time.time() - t:.0f}s)")
    elif a.cmd == "create-user":
        import getpass
        import os
        from .auth.security import create_user
        migrate()
        pw = os.environ.get("AOMDIS_NEW_PASSWORD") or getpass.getpass("password (min 12 chars): ")
        create_user(a.username, pw, a.role, a.display_name)
        print(f"created {a.username} ({a.role})")
    elif a.cmd == "seed-dev-users":
        import secrets
        from .auth.security import ROLES, create_user
        from .core.settings import ROOT
        migrate()
        out = ROOT / "data" / "warehouse" / "dev_users.txt"
        lines = ["# Development accounts (local only). Generated by `python -m aomdis seed-dev-users`. Do not commit.\n"]
        for role, spec in ROLES.items():
            user = f"dev.{role}"
            pw = secrets.token_urlsafe(15)
            try:
                create_user(user, pw, role, f"{spec['label']} (dev)")
            except ValueError:
                print(f"{user} exists, skipped")
                continue
            lines.append(f"{user}\t{pw}\t{role}\n")
        with open(out, "a", encoding="utf-8") as f:
            f.writelines(lines)
        print(f"accounts written to {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
