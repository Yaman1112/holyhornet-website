"""Strategic planning: seasonal demand, trend, peak-hour design values, capacity evidence,
runway demand and scenario-based planning on a typical ("design") week."""
