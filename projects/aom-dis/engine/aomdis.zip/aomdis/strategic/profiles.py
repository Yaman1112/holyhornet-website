"""Demand bases and typical-week profiles.

A *basis* is where planning demand comes from:

* ``realised``    actual movements over a local date range                     (kind: actual)
* ``schedule``    entries of one published schedule list over its full weeks   (kind: scheduled)
* ``calibrated``  the fpred calibrated forecast built from one list            (kind: predicted)

The *typical week* is the mean number of arrivals / departures per (weekday, local hour) over
complete local days of the basis. Hours that do not exist (02:00 on the spring-forward day) are
excluded from the mean instead of counted as zero.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..core.provenance import Kind
from ..core.timeutil import hours_in_local_day
from ..db.session import engine
from ..ingest.pipeline import latest_dataset_version

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


@dataclass(frozen=True)
class Basis:
    kind: str                    # realised | schedule | calibrated
    list_name: str | None = None
    start: date | None = None
    end: date | None = None

    @property
    def provenance(self) -> Kind:
        return {"realised": Kind.ACTUAL, "schedule": Kind.SCHEDULED, "calibrated": Kind.PREDICTED}[self.kind]

    def label(self) -> str:
        if self.kind == "realised":
            return f"Realised {self.start} → {self.end}"
        return f"{'Schedule' if self.kind == 'schedule' else 'Calibrated forecast'} {self.list_name} ({self.start} → {self.end})"


def realised_span() -> tuple[date, date]:
    """First and last *complete* local days of the realisation data."""
    d = _q("select min(local_date) a, max(local_date) b from movement where dataset_version_id=:d", d=latest_dataset_version()).iloc[0]
    return pd.Timestamp(d["a"]).date() + timedelta(days=1), pd.Timestamp(d["b"]).date() - timedelta(days=1)


def list_full_weeks(name: str) -> tuple[date, date]:
    """Monday..Sunday span of whole local weeks fully inside a list's coverage (first/last days are partial)."""
    r = _q("select coverage_start_local a, coverage_end_local b from schedule_list where name=:n and dataset_version_id=:d",
           n=name, d=latest_dataset_version())
    if r.empty:
        raise LookupError(f"unknown schedule list {name!r}")
    a = pd.Timestamp(r.iloc[0]["a"]).date() + timedelta(days=1)
    b = pd.Timestamp(r.iloc[0]["b"]).date() - timedelta(days=1)
    a = a + timedelta(days=(7 - a.weekday()) % 7)
    b = b - timedelta(days=(b.weekday() + 1) % 7)
    if b < a:
        raise LookupError(f"{name} has no complete week")
    return a, b


def bases() -> dict:
    r0, r1 = realised_span()
    lists = _q("select l.name, l.published_date, exists(select 1 from forecast_run r where r.schedule_list_id=l.id) has_forecast "
               "from schedule_list l where l.dataset_version_id=:d order by l.published_date", d=latest_dataset_version())
    out = {"realised": {"start": str(r0), "end": str(r1), "kind": str(Kind.ACTUAL)}, "lists": []}
    for row in lists.itertuples():
        try:
            a, b = list_full_weeks(row.name)
        except LookupError:
            continue
        out["lists"].append({"name": row.name, "published": str(row.published_date), "full_weeks": [str(a), str(b)],
                             "has_calibrated_forecast": bool(row.has_forecast)})
    return out


def resolve(kind: str, list_name: str | None = None, start: date | None = None, end: date | None = None) -> Basis:
    if kind == "realised":
        r0, r1 = realised_span()
        s, e = start or (r1 - timedelta(days=27)), end or r1
        if s < r0 or e > r1 or e < s:
            raise ValueError(f"realised range must lie within {r0} … {r1}")
        return Basis("realised", None, s, e)
    if kind in ("schedule", "calibrated"):
        if not list_name:
            raise ValueError("list_name required")
        a, b = list_full_weeks(list_name)
        return Basis(kind, list_name, a, b)
    raise ValueError(f"unknown basis {kind!r}")


def hourly(b: Basis) -> pd.DataFrame:
    """One row per existing local hour of every day in the basis: local_date, local_hour, arr, dep."""
    dsv = latest_dataset_version()
    a, e = b.start.isoformat(), b.end.isoformat()
    if b.kind == "realised":
        df = _q("select local_date, local_hour, direction, count(*) n from movement where dataset_version_id=:d "
                "and local_date between :a and :e group by 1,2,3", d=dsv, a=a, e=e)
    elif b.kind == "schedule":
        df = _q("select e.local_date, e.local_hour, e.direction, count(*) n from schedule_entry e join schedule_list l "
                "on l.id=e.schedule_list_id where l.name=:n and l.dataset_version_id=:d and e.local_date between :a and :e "
                "group by 1,2,3", n=b.list_name, d=dsv, a=a, e=e)
    else:
        df = _q("select f.target_local_date local_date, f.target_local_hour local_hour, "
                "case f.metric when 'arrivals' then 'ARR' else 'DEP' end direction, f.value n "
                "from forecast f join forecast_run r on r.id=f.run_id join schedule_list l on l.id=r.schedule_list_id "
                "where l.name=:n and l.dataset_version_id=:d and r.dataset_version_id=:d and f.target_local_hour is not null "
                "and f.metric in ('arrivals','departures') and f.target_local_date between :a and :e", n=b.list_name, d=dsv, a=a, e=e)
        if df.empty:
            raise LookupError(f"no calibrated forecast for {b.list_name} (the first list has no earlier history)")
    df["local_date"] = pd.to_datetime(df["local_date"]).dt.date
    rows = [(d, h) for d in pd.date_range(b.start, b.end).date for h in range(24)
            if not (hours_in_local_day(d) == 23 and h == 2)]
    H = pd.DataFrame(rows, columns=["local_date", "local_hour"])
    p = df.pivot_table(index=["local_date", "local_hour"], columns="direction", values="n", aggfunc="sum", fill_value=0)
    p = p.reindex(columns=["ARR", "DEP"], fill_value=0).reset_index()
    H = H.merge(p, on=["local_date", "local_hour"], how="left").fillna({"ARR": 0, "DEP": 0})
    H = H.rename(columns={"ARR": "arr", "DEP": "dep"})
    H["mov"] = H["arr"] + H["dep"]
    H["weekday"] = pd.to_datetime(H["local_date"]).dt.day_of_week
    return H


def typical_week(H: pd.DataFrame) -> pd.DataFrame:
    """168 rows (weekday 0=Mon … 6, hour 0..23): mean arr, dep, mov and the number of days averaged."""
    t = H.groupby(["weekday", "local_hour"]).agg(arr=("arr", "mean"), dep=("dep", "mean"), n_days=("arr", "size")).reset_index()
    full = pd.MultiIndex.from_product([range(7), range(24)], names=["weekday", "local_hour"])
    t = t.set_index(["weekday", "local_hour"]).reindex(full).reset_index()
    t[["arr", "dep"]] = t[["arr", "dep"]].fillna(0.0)
    t["n_days"] = t["n_days"].fillna(0).astype(int)
    t["mov"] = t["arr"] + t["dep"]
    return t


def peak_analysis(H: pd.DataFrame, capacity: float) -> dict:
    """Peak-hour design values over the basis' actual dated hours."""
    m = H["mov"].sort_values(ascending=False).reset_index(drop=True)
    busiest = H.loc[H["mov"].idxmax()]
    def nth(n):
        return float(m.iloc[n - 1]) if len(m) >= n else None
    return {
        "busiest_hour": {"movements": float(busiest["mov"]), "at": f"{busiest['local_date']} {int(busiest['local_hour']):02d}:00"},
        "design_hour_30th": nth(30),
        "p95_hour": float(np.percentile(H["mov"], 95)),
        "p99_hour": float(np.percentile(H["mov"], 99)),
        "hours": int(len(H)),
        "hours_over_90pct_capacity": int((H["mov"] >= 0.9 * capacity).sum()),
        "hours_over_capacity": int((H["mov"] > capacity).sum()),
        "distribution": [{"from": int(lo), "to": int(lo + 10), "hours": int(((H["mov"] >= lo) & (H["mov"] < lo + 10)).sum())}
                         for lo in range(0, int(max(m.iloc[0], capacity)) + 10, 10)],
        "note": "Design hour = 30th busiest hour of the basis period (common airport-planning convention); derived.",
    }
