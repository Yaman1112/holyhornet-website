"""Scenario engine on the typical week.

Demand transform per hour h (weekday w, local hour k):

    D'(h) = D(h) · demand_factor · (1 + growth_rate)^growth_years

Capacity per hour, per flow f ∈ {total, arr, dep}:

    C'_f(h) = C_f · capacity_factor · Π override.factor   (for overrides covering w, k)

Fluid queue (deterministic, hour by hour, starting empty on Monday 00:00):

    Q_f(h) = backlog carried in + D'_f(h)
    served arrivals / departures limited by C'_arr, C'_dep and jointly by C'_total
    (if A + D would exceed C'_total both are scaled down in proportion to their queues)
    backlog(h+1) = Q(h) − served(h)

Conservation holds exactly: Σ D' = Σ served + backlog at week end.
Reported delay is backlog movement-hours (each movement waiting one hour adds 1).
Outputs are SIMULATED; inputs are the demand basis (actual / scheduled / predicted) and configured
capacity parameters (status shown) plus the scenario's own assumptions.
"""
from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from ..services.demand import capacity_params
from ..core import reproducibility as RP
from . import profiles as P


@dataclass
class Override:
    weekdays: list[int]
    start_hour: int
    hours: int
    factor: float
    label: str = ""

    def covers(self, wd: int, hour: int) -> bool:
        if wd not in self.weekdays:
            return False
        return self.start_hour <= hour < self.start_hour + self.hours


@dataclass
class ScenarioSpec:
    name: str
    preset: str
    basis: dict                              # {"kind": "realised|schedule|calibrated", "list_name"?, "start"?, "end"?}
    demand_factor: float = 1.0
    growth_rate_pct: float = 0.0             # annual
    growth_years: float = 0.0
    capacity_factor: float = 1.0
    overrides: list[Override] = field(default_factory=list)
    description: str = ""

    def to_dict(self) -> dict:
        d = copy.deepcopy(self.__dict__)
        d["overrides"] = [o.__dict__ for o in self.overrides]
        return d

    @staticmethod
    def from_dict(d: dict) -> "ScenarioSpec":
        d = dict(d)
        d["overrides"] = [o if isinstance(o, Override) else Override(**o) for o in d.get("overrides", [])]
        return ScenarioSpec(**d)

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True, default=str).encode()).hexdigest()[:16]


DEFAULT_BASIS = {"kind": "schedule", "list_name": "S22 23mar22"}

# Preset parameters are scenario ASSUMPTIONS chosen for illustration; users edit them.
PRESETS: dict[str, dict] = {
    "baseline": {"description": "Basis demand against configured capacity, no changes."},
    "low_demand": {"demand_factor": 0.85, "description": "Demand 15 % below basis (e.g. weaker season). Assumption."},
    "high_demand": {"demand_factor": 1.10, "description": "Demand 10 % above basis (e.g. strong recovery). Assumption."},
    "traffic_growth": {"growth_rate_pct": 3.0, "growth_years": 5,
                       "description": "3 % per year for 5 years applied uniformly to every hour. Assumption."},
    "capacity_reduction": {"capacity_factor": 0.75,
                           "description": "All hourly capacities at 75 % for the whole week (e.g. a long runway closure). Assumption."},
    "disruption": {"overrides": [{"weekdays": [4], "start_hour": 14, "hours": 4, "factor": 0.5,
                                  "label": "Friday 14:00–18:00 at 50 % capacity"}],
                   "description": "A 4-hour 50 % capacity loss on Friday afternoon; shows backlog and recovery. Assumption."},
}


def preset(name: str, basis: dict | None = None) -> ScenarioSpec:
    if name not in PRESETS:
        raise ValueError(f"unknown preset {name!r}; one of {list(PRESETS)}")
    p = copy.deepcopy(PRESETS[name])
    return ScenarioSpec.from_dict({"name": name.replace("_", " ").title(), "preset": name, "basis": basis or DEFAULT_BASIS, **p})


def _capacities() -> dict:
    """Display values of the active capacity profile (max over hours if a flow varies) + the annual cap."""
    from ..services.demand import capacity_meta
    cap = capacity_params()
    m = {f: capacity_meta(f) for f in ("total", "arr", "dep")}
    return {
        "total": (float(m["total"]["value"]), m["total"]["status"]),
        "arr": (float(m["arr"]["value"]), m["arr"]["status"]),
        "dep": (float(m["dep"]["value"]), m["dep"]["status"]),
        "annual": (float(cap["airport.annual_movement_cap"]["value"]), cap["airport.annual_movement_cap"]["status"]),
    }


def validate(spec: ScenarioSpec) -> None:
    if not 0 < spec.demand_factor <= 3:
        raise ValueError("demand_factor must be in (0, 3]")
    if not -50 <= spec.growth_rate_pct <= 50 or not 0 <= spec.growth_years <= 30:
        raise ValueError("growth_rate_pct must be in [-50, 50] and growth_years in [0, 30]")
    if not 0 < spec.capacity_factor <= 2:
        raise ValueError("capacity_factor must be in (0, 2]")
    for o in spec.overrides:
        if not o.weekdays or any(w not in range(7) for w in o.weekdays):
            raise ValueError("override weekdays must be 0..6")
        if not (0 <= o.start_hour <= 23 and 1 <= o.hours <= 168 and 0 <= o.factor <= 2):
            raise ValueError("override needs start_hour 0..23, hours 1..168, factor 0..2")


def simulate(tw: pd.DataFrame, spec: ScenarioSpec, caps: dict | None = None) -> pd.DataFrame:
    """Run the fluid queue over a 168-hour typical week. Pure function (no DB) for testability."""
    caps = caps or {k: v[0] for k, v in _capacities().items()}
    g = (1 + spec.growth_rate_pct / 100) ** spec.growth_years
    t = tw.sort_values(["weekday", "local_hour"]).reset_index(drop=True).copy()
    t["d_arr"] = t["arr"] * spec.demand_factor * g
    t["d_dep"] = t["dep"] * spec.demand_factor * g
    fac = np.full(len(t), spec.capacity_factor, dtype=float)
    for i, (wd, h) in enumerate(zip(t["weekday"], t["local_hour"])):
        for o in spec.overrides:
            # overrides may run past midnight: express hour-of-week and compare ranges on the week clock
            how = wd * 24 + h
            for w in o.weekdays:
                start = w * 24 + o.start_hour
                if start <= how < start + o.hours or start <= how + 168 < start + o.hours:
                    fac[i] *= o.factor
                    break
    t["cap_factor"] = fac
    t["c_total"], t["c_arr"], t["c_dep"] = caps["total"] * fac, caps["arr"] * fac, caps["dep"] * fac
    qa = qd = 0.0
    rows = []
    for r in t.itertuples():
        qa += r.d_arr
        qd += r.d_dep
        sa, sd = min(qa, r.c_arr), min(qd, r.c_dep)
        if sa + sd > r.c_total:
            k = r.c_total / (sa + sd) if sa + sd > 0 else 0.0
            sa, sd = sa * k, sd * k
        qa, qd = qa - sa, qd - sd
        rows.append((sa, sd, qa, qd))
    s = np.array(rows)
    t["served_arr"], t["served_dep"], t["backlog_arr"], t["backlog_dep"] = s[:, 0], s[:, 1], s[:, 2], s[:, 3]
    t["demand"] = t["d_arr"] + t["d_dep"]
    t["served"] = t["served_arr"] + t["served_dep"]
    t["backlog"] = t["backlog_arr"] + t["backlog_dep"]
    t["util"] = np.where(t["c_total"] > 0, t["demand"] / t["c_total"], np.inf)
    t["gap"] = t["demand"] - t["c_total"]
    return t


def summarise(t: pd.DataFrame, spec: ScenarioSpec, caps_meta: dict) -> dict:
    over = t[t["demand"] > t["c_total"] + 1e-9]
    weekly = float(t["demand"].sum())
    annual = weekly * 52.18
    # recovery: hours from the end of each overloaded stretch until the backlog returns to ~0
    rec, i, b = [], 0, t["backlog"].to_numpy()
    while i < len(b):
        if b[i] > 0.5:
            j = i
            while j < len(b) and b[j] > 0.5:
                j += 1
            rec.append({"from": _hw(t, i), "cleared_at": _hw(t, j) if j < len(b) else None, "hours": j - i,
                        "peak_backlog": float(b[i:j].max())})
            i = j
        i += 1
    peak = t.loc[t["util"].replace(np.inf, np.nan).idxmax()] if t["util"].replace(np.inf, np.nan).notna().any() else None
    return {
        "weekly_demand": weekly,
        "weekly_capacity": float(t["c_total"].sum()),
        "weekly_headroom": float((t["c_total"] - t["demand"]).clip(lower=0).sum()),
        "annual_movements": annual,
        "annual_cap": caps_meta["annual"][0], "annual_cap_status": caps_meta["annual"][1],
        "annual_share_of_cap": annual / caps_meta["annual"][0],
        "peak_utilisation": None if peak is None else float(peak["util"]),
        "peak_at": None if peak is None else _hw(t, int(peak.name)),
        "hours_over_90pct": int((t["util"] >= 0.9).sum()),
        "hours_over_capacity": int(len(over)),
        "max_gap": float(t["gap"].max()),
        "delay_movement_hours": float(t["backlog"].sum()),
        "max_backlog": float(t["backlog"].max()),
        "unserved_at_week_end": float(t["backlog"].iloc[-1]),
        "backlog_episodes": rec[:20],
        "conservation_error": float(t["demand"].sum() - t["served"].sum() - t["backlog"].iloc[-1]),
    }


def _hw(t: pd.DataFrame, i: int) -> str:
    r = t.iloc[i]
    return f"{P.WEEKDAYS[int(r['weekday'])]} {int(r['local_hour']):02d}:00"


def run(spec: ScenarioSpec) -> dict:
    validate(spec)
    b = spec.basis
    basis = P.resolve(b["kind"], b.get("list_name"), _d(b.get("start")), _d(b.get("end")))
    tw = P.typical_week(P.hourly(basis))
    caps_meta = _capacities()
    tws = tw.sort_values(["weekday", "local_hour"]).reset_index(drop=True)
    from ..services.demand import hourly_capacity
    caps = {"total": hourly_capacity("total", tws["weekday"], tws["local_hour"]), "arr": hourly_capacity("arr", tws["weekday"], tws["local_hour"]),
            "dep": hourly_capacity("dep", tws["weekday"], tws["local_hour"]), "annual": caps_meta["annual"][0]}
    t = simulate(tws, spec, caps)
    return RP.attach("strategic", {
        "kind": "simulated",
        "spec": spec.to_dict(),
        "fingerprint": spec.fingerprint(),
        "basis": {"label": basis.label(), "kind": str(basis.provenance), "start": str(basis.start), "end": str(basis.end)},
        "capacity_inputs": {k: {"value": v[0], "status": v[1]} for k, v in caps_meta.items()},
        "summary": summarise(t, spec, caps_meta),
        "hourly": [{"weekday": int(r.weekday), "hour": int(r.local_hour), "demand": round(r.demand, 2), "d_arr": round(r.d_arr, 2),
                    "d_dep": round(r.d_dep, 2), "capacity": round(r.c_total, 2), "served": round(r.served, 2),
                    "backlog": round(r.backlog, 2), "util": None if not np.isfinite(r.util) else round(r.util, 4)}
                   for r in t.itertuples()],
    })


def _d(x):
    from datetime import date
    return date.fromisoformat(x) if isinstance(x, str) and x else x
