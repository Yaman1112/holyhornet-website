"""Historical trend, weekly seasonality, seasonal comparison, capacity evidence and runway demand."""
from __future__ import annotations

import math

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.tsa.seasonal import STL

from ..services.demand import capacity_params
from . import profiles as P


def trend_and_seasonality(start=None, end=None) -> dict:
    """Daily realised movements: STL (period 7) + OLS trend with weekday effects.

    growth_per_week = slope × 7; reported with its 95 % confidence interval. With ~13 weeks of
    data this is a short-run trend, not an annual growth rate (no full year is available).
    """
    r0, r1 = P.realised_span()
    b = P.resolve("realised", start=start or r0, end=end or r1)
    H = P.hourly(b)
    d = H.groupby("local_date").agg(arr=("arr", "sum"), dep=("dep", "sum"), mov=("mov", "sum")).reset_index()
    d["t"] = np.arange(len(d))
    d["weekday"] = pd.to_datetime(d["local_date"]).dt.day_of_week
    stl = STL(d["mov"].to_numpy(dtype=float), period=7, robust=True).fit()
    d["stl_trend"], d["stl_seasonal"], d["stl_resid"] = stl.trend, stl.seasonal, stl.resid
    X = pd.get_dummies(d["weekday"], prefix="wd", drop_first=True, dtype=float)
    X.insert(0, "t", d["t"].astype(float))
    X = sm.add_constant(X)
    ols = sm.OLS(d["mov"].astype(float), X).fit()
    slope, (lo, hi) = float(ols.params["t"]), [float(x) for x in ols.conf_int().loc["t"]]
    mean = float(d["mov"].mean())
    weekday_effect = d.groupby("weekday")["stl_seasonal"].mean()
    resid_sd = float(np.std(stl.resid, ddof=1))
    return {
        "basis": b.label(), "kind": "derived", "days": int(len(d)),
        "growth_per_week": {"movements_per_day": slope * 7, "ci95": [lo * 7, hi * 7], "pct_of_mean": slope * 7 / mean * 100},
        "mean_daily": mean,
        "weekday_effect": [{"weekday": P.WEEKDAYS[i], "effect": float(weekday_effect.get(i, 0.0))} for i in range(7)],
        "residual_sd": resid_sd,
        "unusual_days": [{"date": str(r.local_date), "movements": int(r.mov), "resid_z": round(r.stl_resid / resid_sd, 2)}
                         for r in d.itertuples() if abs(r.stl_resid) > 2.5 * resid_sd],
        "daily": [{"date": str(r.local_date), "movements": int(r.mov), "trend": round(r.stl_trend, 1),
                   "seasonal": round(r.stl_seasonal, 1)} for r in d.itertuples()],
        "method": "STL(period=7, robust) for decomposition; OLS movements ~ t + weekday dummies for the trend CI.",
        "limitation": "Only Jan–Apr 2022 is available: annual seasonality cannot be estimated from this data.",
    }


def season_comparison() -> dict:
    """Typical weeks of each schedule list (scheduled) and of the realised data, side by side."""
    out = []
    b = P.resolve("realised", *([None] * 0))
    for basis in [b] + [P.resolve("schedule", l["name"]) for l in P.bases()["lists"]]:
        tw = P.typical_week(P.hourly(basis))
        daily = tw.groupby("weekday")["mov"].sum()
        out.append({"basis": basis.label(), "kind": str(basis.provenance), "weekly_movements": float(tw["mov"].sum()),
                    "daily": [float(daily.get(i, 0)) for i in range(7)],
                    "hourly_mean": [float(x) for x in tw.groupby("local_hour")["mov"].mean().reindex(range(24), fill_value=0)],
                    "peak_typical_hour": float(tw["mov"].max())})
    return {"weekdays": P.WEEKDAYS, "seasons": out}


def capacity_evidence() -> dict:
    """Configured capacity vs throughput actually observed in the realised data."""
    cap = capacity_params()
    r0, r1 = P.realised_span()
    H = P.hourly(P.resolve("realised", start=r0, end=r1))
    obs = {"max_hour": float(H["mov"].max()), "p99_hour": float(np.percentile(H["mov"], 99)),
           "max_arr_hour": float(H["arr"].max()), "max_dep_hour": float(H["dep"].max())}
    from ..services.demand import capacity_meta
    cfg = {}
    for key, flow in (("hourly_movement_capacity", "total"), ("hourly_arrival_capacity", "arr"), ("hourly_departure_capacity", "dep")):
        m = capacity_meta(flow)
        cfg[key] = {"value": m["value"], "status": m["status"], "source": m["source"], "profile": m["profile"]}
    checks = []
    for name, cfg_key, obs_key in (("total", "hourly_movement_capacity", "max_hour"), ("arrivals", "hourly_arrival_capacity", "max_arr_hour"),
                                   ("departures", "hourly_departure_capacity", "max_dep_hour")):
        c = float(cfg[cfg_key]["value"])
        o = obs[obs_key]
        status = "consistent" if c >= o else "below_observed"
        checks.append({"flow": name, "configured": c, "configured_status": cfg[cfg_key]["status"], "observed_max": o,
                       "headroom_vs_observed": c - o, "status": status,
                       "message": ("Configured capacity is at least the highest throughput observed — plausible, but observed peaks "
                                   "show demand, not the capacity limit." if status == "consistent" else
                                   "Configured capacity is BELOW a throughput that actually occurred — the parameter is too low.")})
    return {"configured": cfg, "observed": obs, "observed_kind": "derived", "checks": checks,
            "annual_cap": cap.get("airport.annual_movement_cap"),
            "runway_rates": {k: v for k, v in cap.items() if k.startswith("runway.")}}


def runway_demand(tw: pd.DataFrame) -> dict:
    """Runways needed per typical-week hour using the configured per-runway rates (assumption)."""
    cap = capacity_params()
    ra = float(cap["runway.arrival_rate_per_hour"]["value"])
    rd = float(cap["runway.departure_rate_per_hour"]["value"])
    t = tw.copy()
    t["arr_runways"] = np.ceil(t["arr"] / ra).astype(int)
    t["dep_runways"] = np.ceil(t["dep"] / rd).astype(int)
    t["config"] = t["arr_runways"].astype(str) + "+" + t["dep_runways"].astype(str)
    counts = t["config"].value_counts().sort_index()
    return {"arrival_rate": ra, "departure_rate": rd, "kind": "derived",
            "basis_note": "ceil(demand / per-runway rate); rates are configured assumptions, mixed-mode and wind are not modelled.",
            "configurations": [{"config": k, "hours_per_week": int(v)} for k, v in counts.items()],
            "max_arrival_runways": int(t["arr_runways"].max()), "max_departure_runways": int(t["dep_runways"].max()),
            "hourly": [{"weekday": int(r.weekday), "hour": int(r.local_hour), "arr_runways": int(r.arr_runways),
                        "dep_runways": int(r.dep_runways)} for r in t.itertuples()]}


def overview(kind: str, list_name: str | None = None, start=None, end=None) -> dict:
    b = P.resolve(kind, list_name, start, end)
    H = P.hourly(b)
    tw = P.typical_week(H)
    cap = capacity_params()
    from ..services.demand import capacity_meta
    cm = capacity_meta("total")
    C = float(cm["value"])
    weekly = float(tw["mov"].sum())
    annual_cap = float(cap["airport.annual_movement_cap"]["value"])
    return {
        "basis": {"label": b.label(), "kind": str(b.provenance), "type": b.kind, "list": b.list_name,
                  "start": str(b.start), "end": str(b.end), "days": int(H["local_date"].nunique()),
                  "timing_note": None if b.kind == "realised" else
                  "Scheduled arrivals are timed at FIR entry (ETO), typically 20–35 min before landing; departures at SOBT "
                  "(before take-off). Hourly profiles are therefore shifted slightly earlier than runway times."},
        "typical_week": {"weekdays": P.WEEKDAYS, "rows": [{k: (float(v) if isinstance(v, (float, np.floating)) else int(v))
                         for k, v in r.items()} for r in tw.to_dict("records")]},
        "weekly_movements": weekly,
        "annualised": {"value": weekly * 52.18, "cap": annual_cap, "share_of_cap": weekly * 52.18 / annual_cap,
                       "kind": "derived", "note": "typical week × 52.18 — assumes the basis week is representative of a whole year"},
        "peak": P.peak_analysis(H, C),
        "capacity": {"hourly": C, "status": cm["status"], "source": cm["source"], "profile": cm["profile"], "varies_by_hour": cm["varies_by_hour"]},
        "runway_demand": runway_demand(tw),
    }


def _clean(o):
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_clean(v) for v in o]
    if isinstance(o, float) and (math.isnan(o) or math.isinf(o)):
        return None
    if isinstance(o, np.generic):
        return _clean(o.item())
    return o
