"""Anomaly detection.

Daily (complete local days, actual movements)
  1. STL(period 7, robust) residual z per flow: residual / robust SD (1.4826·MAD).
  2. IsolationForest on standardised daily features [arrivals, departures, arrival share, peak hour,
     inferred cancellation rate, unscheduled share] — multivariate "unusual pattern" score.
  A day is anomalous if |z_total| ≥ 3 or (IF flags it and |z| ≥ 2). Confidence: high when both methods agree
  and |z| ≥ 4, medium when one method is strong, low otherwise. The most deviating feature (vs the
  same-weekday median of the previous 4 weeks) is reported as the explanation of WHAT is unusual — not why.
Hourly
  actual vs the same weekday-hour median of the previous 4 weeks; robust z with MAD floor 3; flagged when
  |z| ≥ 4 and |Δ| ≥ 15 movements (catches missing hours / data gaps and local surges).
Operators
  daily movements per operator; a structural shift is a change of ≥ 80 % between the 14-day means before and
  after a date, sustained in both windows (≥ 10 days with data before). Reported with dates and counts only.
"""
from __future__ import annotations

from datetime import date
from functools import lru_cache

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from statsmodels.tsa.seasonal import STL
from sqlalchemy import text

from ..db.session import engine
from ..ingest.pipeline import latest_dataset_version
from ..postops.metrics import load_daily
from ..tactical import state as ST
from . import ev, insight

FEATURES = ["arrivals", "departures", "arr_share", "peak_hour_movements", "cancel_rate", "unscheduled_share"]


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


def _robust_z(x: np.ndarray) -> np.ndarray:
    med = np.median(x)
    mad = np.median(np.abs(x - med)) * 1.4826
    return (x - med) / (mad if mad > 0 else (np.std(x) or 1.0))


@lru_cache(maxsize=4)
def _daily(dsv: str) -> pd.DataFrame:
    s = ST.snap()
    d = s.daily.copy()
    d["total"] = d["arrivals"] + d["departures"]
    d["arr_share"] = d["arrivals"] / d["total"]
    h = s.hourly.assign(m=s.hourly["arrivals"] + s.hourly["departures"]).groupby("local_date")["m"].max()
    d["peak_hour_movements"] = h.reindex(d.index)
    W = load_daily()
    if len(W):
        W = W.set_index("local_date")
        plan = W.get("matched", 0) + W.get("canceled", 0)
        d["cancel_rate"] = (W.get("canceled") / plan.replace(0, np.nan)).reindex(d.index)
        d["unscheduled_share"] = (W.get("added") / W.get("actual_mov")).reindex(d.index)
    else:
        d["cancel_rate"] = np.nan
        d["unscheduled_share"] = np.nan
    return d


def daily(start: date | None = None, end: date | None = None) -> dict:
    d = _daily(latest_dataset_version()).copy()
    out = pd.DataFrame(index=d.index)
    for col in ("total", "arrivals", "departures"):
        fit = STL(d[col].to_numpy(float), period=7, robust=True).fit()
        out[f"z_{col}"] = _robust_z(fit.resid)
        out[f"trend_{col}"] = fit.trend
        out[f"expected_{col}"] = fit.trend + fit.seasonal
    X = d[FEATURES].copy()
    X = X.fillna(X.median())
    Xs = (X - X.median()) / (X.quantile(0.75) - X.quantile(0.25)).replace(0, 1)
    iso = IsolationForest(n_estimators=300, contamination="auto", random_state=0).fit(Xs.to_numpy())
    out["if_score"] = -iso.score_samples(Xs.to_numpy())          # higher = more isolated
    out["if_flag"] = iso.predict(Xs.to_numpy()) == -1
    out["actual"] = d["total"]
    rows = []
    for day, r in out.iterrows():
        z = float(r["z_total"])
        flag = abs(z) >= 3 or (bool(r["if_flag"]) and abs(z) >= 2)
        if not flag:
            continue
        both = bool(r["if_flag"]) and abs(z) >= 3
        conf = "high" if both and abs(z) >= 4 else "medium" if (abs(z) >= 4 or both) else "low"
        edge = (day - d.index[0]).days < 7 or (d.index[-1] - day).days < 7
        if edge:
            conf = "low"                       # STL is unreliable in the first/last week of the series
        # what is unusual: feature furthest from the same-weekday median of the previous 4 weeks
        prev = [x for x in d.index if x < day and x.weekday() == day.weekday()][-4:]
        detail = []
        if prev:
            for f in FEATURES:
                base = d.loc[prev, f].median()
                if pd.notna(base) and pd.notna(d.at[day, f]) and base:
                    detail.append((f, float(d.at[day, f]), float(base), float(d.at[day, f] / base - 1)))
        detail.sort(key=lambda x: -abs(x[3]))
        rows.append({"date": str(day), "weekday": day.strftime("%A"), "actual": int(r["actual"]), "expected": round(float(r["expected_total"]), 1),
                     "z_total": round(z, 2), "z_arrivals": round(float(r["z_arrivals"]), 2), "z_departures": round(float(r["z_departures"]), 2),
                     "isolation_score": round(float(r["if_score"]), 3), "isolation_flag": bool(r["if_flag"]),
                     "direction": "low" if z < 0 else "high", "confidence": conf, "series_edge": edge,
                     "most_unusual": [{"feature": f, "value": round(v, 3), "same_weekday_median": round(b, 3), "change": round(c, 3)} for f, v, b, c in detail[:3]]})
    if start or end:
        rows = [r for r in rows if (not start or r["date"] >= str(start)) and (not end or r["date"] <= str(end))]
    series = [{"date": str(k), "actual": int(v.actual), "expected": round(float(v.expected_total), 1), "z": round(float(v.z_total), 2),
               "if_flag": bool(v.if_flag)} for k, v in out.iterrows()
              if (not start or k >= start) and (not end or k <= end)]
    return {"method": "STL robust residual z (period 7) + IsolationForest on 6 daily features", "anomalies": rows, "series": series}


def hourly(start: date, end: date, z_min: float = 4.0, delta_min: float = 15.0) -> list[dict]:
    s = ST.snap()
    Hh = s.hourly.assign(m=s.hourly["arrivals"] + s.hourly["departures"]).set_index(["local_date", "local_hour"])["m"]
    out = []
    for day in [x for x in s.days if start <= x <= end]:
        prev = [x for x in s.days if x < day and x.weekday() == day.weekday()][-4:]
        if len(prev) < 3:
            continue
        for h in range(24):
            if (day, h) not in Hh.index and not any((p, h) in Hh.index for p in prev):
                continue
            hist = np.array([Hh.get((p, h), 0) for p in prev], float)
            a = float(Hh.get((day, h), 0))
            med = float(np.median(hist))
            mad = max(float(np.median(np.abs(hist - med))) * 1.4826, 3.0)
            z = (a - med) / mad
            if abs(z) >= z_min and abs(a - med) >= delta_min:
                out.append({"date": str(day), "hour": h, "actual": int(a), "usual": med, "delta": round(a - med, 1), "z": round(z, 2),
                            "note": "possible data gap or local disruption" if a == 0 else ("surge" if a > med else "drop")})
    return out


def operator_shifts(min_before_days: int = 10, threshold: float = 0.8) -> list[dict]:
    """Structural level changes per operator (≥ 80 % change between the 14-day windows around a date)."""
    s = ST.snap()
    m = _q("select operator_icao op, local_date d, count(*) n from movement where dataset_version_id=:d and operator_icao is not null group by 1, 2",
           d=latest_dataset_version())
    m["d"] = pd.to_datetime(m["d"]).dt.date
    days = s.days
    P = m.pivot_table(index="d", columns="op", values="n", fill_value=0).reindex(days, fill_value=0)
    out = []
    for op in P.columns:
        x = P[op].to_numpy(float)
        if x.sum() < 60:
            continue
        best = None
        for i in range(max(min_before_days, 14), len(x) - 7):
            before, after = x[i - 14:i].mean(), x[i:i + 14].mean() if i + 14 <= len(x) else x[i:].mean()
            if before < 2 and after < 2:
                continue
            change = (after - before) / max(before, 0.5)
            if abs(change) >= threshold and (best is None or abs(after - before) > abs(best[2] - best[1])):
                best = (i, before, after, change)
        if best:
            i, b, a, c = best
            out.append({"operator": op, "from_date": str(days[i]), "per_day_before": round(float(b), 1), "per_day_after": round(float(a), 1),
                        "change": round(float(c), 3), "total_movements": int(x.sum()), "direction": "drop" if c < 0 else "rise"})
    return sorted(out, key=lambda r: -abs(r["per_day_after"] - r["per_day_before"]))


def insights(start: date, end: date) -> list[dict]:
    res = []
    for a in daily(start, end)["anomalies"]:
        top = a["most_unusual"][0] if a["most_unusual"] else None
        what = f"; most unusual feature: {top['feature']} {top['change']:+.0%} vs the same-weekday median" if top else ""
        res.append(insight(
            f"{a['weekday']} {a['date']} was unusually {a['direction']}: {a['actual']} movements vs about {a['expected']:.0f} expected "
            f"from trend and weekly pattern (z = {a['z_total']:+.1f}){what}. The data does not show the cause.",
            "derived", a["confidence"],
            "within a week of the series edge, where the decomposition is unreliable" if a["series_edge"] else
            "both detectors agree and |z| ≥ 4" if a["confidence"] == "high" else "one detector strong or moderate deviation" if a["confidence"] == "medium" else "borderline deviation",
            [ev("actual movements", a["actual"], "movement table"), ev("expected (STL trend + season)", a["expected"], "STL decomposition"),
             ev("robust z", a["z_total"], "STL residual"), ev("isolation forest flag", a["isolation_flag"], "IsolationForest"),
             ev("root cause view", a["date"], "post-operations", f"/postops?tab=rootcause&day={a['date']}")],
            "anomaly", date=a["date"]))
    for o in operator_shifts():
        if not (str(start) <= o["from_date"] <= str(end)):
            continue
        res.append(insight(
            f"{o['operator']} movements changed structurally from {o['from_date']}: {o['per_day_before']}/day in the 14 days before vs "
            f"{o['per_day_after']}/day after ({o['change']:+.0%}). Cause not in the data.",
            "derived", "high" if abs(o["change"]) >= 0.95 and o["total_movements"] >= 150 else "medium",
            "near-complete and sustained change on a sizeable operator" if abs(o["change"]) >= 0.95 else "large sustained change",
            [ev("per day before", o["per_day_before"], "movement table"), ev("per day after", o["per_day_after"], "movement table"),
             ev("change date", o["from_date"], "14-day window comparison"), ev("operator deviations", o["operator"], "post-operations", "/postops?tab=deviations")],
            "anomaly", operator=o["operator"]))
    return res

