"""Traffic-peak prediction (D-k), leakage-safe, evaluated against the Phase 4 shape baseline.

Peak model for target day t with cutoff c = t − k (information ≤ c − 1):
  peak hour   = most frequent busiest hour on the last 4 same weekdays ≤ c − 1 (ties → most recent)
  top-3 hours = highest mean hourly share over those days
  peak size   = mean busiest-hour count of those days × (ensemble D-k daily forecast / their mean daily total)
  interval    = peak size + [q10, q90] of this model's past peak-size errors on targets < c (≥ 10 needed)
Baseline: the ensemble's stored hourly forecast at the same horizon (daily forecast × hourly shape).
"""
from __future__ import annotations

from collections import Counter
from datetime import date, timedelta
from functools import lru_cache

import numpy as np
import pandas as pd
from sqlalchemy import text

from ..db.session import engine
from ..forecasting import models as MD
from ..ingest.pipeline import latest_dataset_version
from ..tactical import state as ST


def _q(sql: str, **p) -> pd.DataFrame:
    with engine().connect() as c:
        return pd.read_sql(text(sql), c, params=p)


@lru_cache(maxsize=4)
def _store(dsv: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    mid = MD.model_version_id("ensemble")
    f = _q("select f.target_local_date d, f.horizon_days k, f.target_local_hour h, f.value from forecast f join forecast_run r on r.id=f.run_id "
           "where r.model_version_id=:m and r.dataset_version_id=:dsv and f.metric='movements'", m=mid, dsv=dsv)
    f["d"] = pd.to_datetime(f["d"]).dt.date
    return f[f["h"].isna()].drop(columns="h"), f[f["h"].notna()].astype({"h": int})


def _hourly_actual():
    s = ST.snap()
    return s.hourly.assign(m=s.hourly["arrivals"] + s.hourly["departures"])


def model_peak(t: date, k: int) -> dict | None:
    s = ST.snap()
    c = t - timedelta(days=int(k))
    prev = [x for x in s.days if x < c and x.weekday() == t.weekday()][-4:]
    if len(prev) < 3:
        return None
    Hh = _hourly_actual()
    g = Hh[Hh["local_date"].isin(prev)]
    peaks = g.loc[g.groupby("local_date")["m"].idxmax()].sort_values("local_date")
    cnt = Counter(peaks["local_hour"])
    best = max(cnt.values())
    hour = int([h for h in reversed(peaks["local_hour"].tolist()) if cnt[h] == best][0])
    share = g.groupby("local_hour")["m"].sum() / g["m"].sum()
    top3 = [int(h) for h in share.sort_values(ascending=False).index[:3]]
    daily_f, _ = _store(latest_dataset_version())
    fc = daily_f[(daily_f["d"] == t) & (daily_f["k"] == k)]["value"]
    base_tot = float(s.daily.loc[prev].sum(axis=1).mean())
    scale = float(fc.iloc[0]) / base_tot if len(fc) else 1.0
    return {"hour": hour, "top3": top3, "size": float(peaks["m"].mean()) * scale, "scaled_by_forecast": bool(len(fc)),
            "weekdays_used": [str(x) for x in prev]}


def baseline_peak(t: date, k: int) -> dict | None:
    _, hourly_f = _store(latest_dataset_version())
    g = hourly_f[(hourly_f["d"] == t) & (hourly_f["k"] == k)]
    if g.empty:
        return None
    r = g.loc[g["value"].idxmax()]
    return {"hour": int(r["h"]), "size": float(r["value"])}


def actual_peak(t: date) -> dict | None:
    Hh = _hourly_actual()
    g = Hh[Hh["local_date"] == t]
    if g.empty:
        return None
    r = g.loc[g["m"].idxmax()]
    return {"hour": int(r["local_hour"]), "size": float(r["m"])}


@lru_cache(maxsize=8)
def evaluate(k: int = 1, dsv: str | None = None) -> dict:
    daily_f, _ = _store(latest_dataset_version())
    targets = sorted(set(daily_f[daily_f["k"] == k]["d"]))
    rows = []
    for t in targets:
        m, b, a = model_peak(t, k), baseline_peak(t, k), actual_peak(t)
        if not (m and a):
            continue
        rows.append({"date": str(t), "actual_hour": a["hour"], "actual_size": a["size"], "model_hour": m["hour"], "model_size": round(m["size"], 1),
                     "model_top3_hit": a["hour"] in m["top3"], "baseline_hour": b["hour"] if b else None, "baseline_size": round(b["size"], 1) if b else None})
    R = pd.DataFrame(rows)
    if R.empty:
        return {"horizon": k, "n": 0}
    def hit(col):
        x = R.dropna(subset=[col])
        return float((abs(x[col] - x["actual_hour"]) <= 1).mean()) if len(x) else None
    def mae(col):
        x = R.dropna(subset=[col])
        return float((x[col] - x["actual_size"]).abs().mean()) if len(x) else None
    return {"horizon": k, "n": int(len(R)),
            "model": {"hit_rate_pm1h": hit("model_hour"), "top3_hit_rate": float(R["model_top3_hit"].mean()), "size_mae": mae("model_size"),
                      "size_bias": float((R["actual_size"] - R["model_size"]).mean())},
            "baseline": {"hit_rate_pm1h": hit("baseline_hour"), "size_mae": mae("baseline_size"),
                         "size_bias": float((R["actual_size"] - R["baseline_size"]).dropna().mean()) if R["baseline_size"].notna().any() else None},
            "rows": rows}


def predict(t: date, k: int = 1) -> dict:
    m, b = model_peak(t, k), baseline_peak(t, k)
    if m is None:
        raise LookupError(f"not enough same-weekday history before D-{k} for {t}")
    ev = evaluate(k)
    past = [r for r in ev.get("rows", []) if r["date"] < str(t - timedelta(days=k))]
    interval = None
    if len(past) >= 10:
        e = np.array([r["actual_size"] - r["model_size"] for r in past])
        lo, hi = np.quantile(e, [0.1, 0.9])
        interval = [round(float(m["size"] + lo), 1), round(float(m["size"] + hi), 1)]
    return {"date": str(t), "horizon": k, "cutoff": str(t - timedelta(days=k)), "model": {**m, "size": round(m["size"], 1), "interval_80": interval},
            "baseline": b, "actual_hindsight": actual_peak(t), "kind": "predicted"}
