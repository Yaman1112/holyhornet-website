"""Explanations, recurring capacity pressure, scenario comparison, investigation list and the generated
management briefing. Every sentence is produced from cited values (no external AI service)."""
from __future__ import annotations

import json
from datetime import date

import numpy as np
import pandas as pd
from sqlalchemy import select

from ..capacity import analysis as CA
from ..db import models as M
from ..db.session import session_scope
from ..postops import reports as PR
from ..postops.metrics import load_daily
from . import anomalies as AN
from . import ev, insight
from . import peaks as PK

WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


# ----------------------------------------------------------------------------------------- forecast misses
LAYER_LABEL = {k: label for k, label, _ in PR.LAYERS}


def explain(d: date, layer: str = "fc_d1_ensemble") -> dict:
    rc = PR.root_cause(d, with_alerts=False)
    err = rc["errors"].get(layer)
    if err is None:
        raise LookupError(f"no {layer} forecast stored for {d}")
    dec = rc["decomposition"]
    an = {a["date"]: a for a in AN.daily()["anomalies"]}.get(str(d))
    parts, evidence = [], [ev("actual movements", rc["decomposition"]["actual"] if dec else None, "movement table"),
                            ev(f"{layer} forecast", rc["layers"].get(layer), "forecast store"), ev("error (actual − forecast)", err, "derived")]
    if dec:
        fc_vs_plan = rc["layers"][layer] - dec["plan"]
        parts.append(f"the plan of record listed {dec['plan']:.0f} movements and the forecast had already adjusted it by {fc_vs_plan:+.0f}")
        parts.append(f"against the plan, {dec['canceled_inferred']:.0f} listed movements were not flown and {dec['added']:.0f} unscheduled ones flew")
        evidence += [ev("planned (plan of record)", dec["plan"], "schedule_entry"), ev("not flown (inferred)", dec["canceled_inferred"], "movement_match"),
                     ev("unscheduled (inferred)", dec["added"], "movement_match")]
        ops = rc["contributors"].get("operator") or []
        if ops:
            top = ops[0]
            parts.append(f"the largest single contributor was {top['operator']} ({top['net']:+d} vs plan)")
            evidence.append(ev(f"{top['operator']} net vs plan", top["net"], "movement_match", f"/postops?tab=deviations"))
    if an:
        parts.append(f"the day is a detected anomaly (z = {an['z_total']:+.1f}, confidence {an['confidence']})")
        evidence.append(ev("anomaly z", an["z_total"], "STL residual"))
    if not rc["events"]:
        parts.append("no operational event was recorded, so the cause cannot be attributed from the data")
    evidence.append(ev("root cause view", str(d), "post-operations", f"/postops?tab=rootcause&day={d}"))
    size = abs(err)
    conf = "high" if dec and abs(dec["deviation"]) >= 0.7 * size else "medium" if dec else "low"
    statement = f"{d.strftime('%A')} {d}: the {LAYER_LABEL.get(layer, layer)} forecast missed by {err:+.0f} movements; " + "; ".join(parts) + "."
    return insight(statement, "inferred", conf,
                   "the plan-vs-actual decomposition accounts for most of the error" if conf == "high" else
                   "decomposition available but explains only part of the error" if conf == "medium" else "no plan of record to decompose",
                   evidence, "forecast", date=str(d), error=err)


def forecast_insights(start: date, end: date, layer: str = "fc_d1_ensemble") -> list[dict]:
    W = load_daily(start, end)
    if W.empty or layer not in W:
        return []
    e = (W["actual_mov"] - W[layer]).dropna()
    if e.empty:
        return []
    mae = float(e.abs().mean())
    out = []
    acc = PR.accuracy(start, end)
    lay = {l["layer"]: l for l in acc["layers"] if l["common_days"].get("n")}
    if lay:
        best = min(lay.values(), key=lambda l: l["common_days"]["mae"])
        worst = max(lay.values(), key=lambda l: l["common_days"]["mae"])
        out.append(insight(
            f"Across {acc['common_days']} comparable days, error falls from {worst['common_days']['mae']:.0f} movements/day ({worst['label']}) "
            f"to {best['common_days']['mae']:.0f} ({best['label']}).",
            "derived", "high" if acc["common_days"] >= 30 else "medium", f"{acc['common_days']} like-for-like days",
            [ev(l["label"] + " MAE", l["common_days"]["mae"], "post-operations accuracy", "/postops?tab=accuracy") for l in lay.values()], "forecast"))
    misses = W.assign(err=W["actual_mov"] - W[layer]).dropna(subset=["err"])
    misses = misses[misses["err"].abs() > 2 * mae].sort_values("err", key=abs, ascending=False).head(5)
    for r in misses.itertuples():
        try:
            out.append(explain(r.local_date, layer))
        except LookupError:
            continue
    return out


# ----------------------------------------------------------------------------------------- capacity & peaks
def capacity_insights(start: date, end: date) -> list[dict]:
    try:
        a = CA.analyse("actual", start, end)
    except LookupError:
        return []
    out = []
    rec = [b for b in a["bottlenecks"] if b["share_high"] and b["share_high"] >= 0.5]
    for b in rec[:3]:
        out.append(insight(
            f"Recurring capacity pressure on {WD[b['weekday']]} {b['local_hour']:02d}:00: utilisation ≥ 90 % on {b['share_high']:.0%} of {b['days']} such days "
            f"(mean {b['mean_u']:.0%}); {b['binding']} is the binding flow.",
            "derived", "high" if b["days"] >= 8 else "medium" if b["days"] >= 4 else "low", f"{b['days']} occurrences of this weekday-hour",
            [ev("days ≥ 90 %", f"{b['share_high']:.0%}", "capacity analysis", "/capacity"), ev("mean utilisation", b["mean_u"], "capacity analysis"),
             ev("capacity value status", "assumption", "active capacity profile", "/capacity?tab=profiles")], "capacity"))
    D = pd.DataFrame(a["daily"])
    if len(D) >= 28:
        D["month"] = pd.to_datetime(D["local_date"]).dt.strftime("%Y-%m")
        m = D.groupby("month")["peak_u"].mean()
        if len(m) >= 2:
            first, last = float(m.iloc[0]), float(m.iloc[-1])
            out.append(insight(
                f"Average daily peak utilisation moved from {first:.0%} ({m.index[0]}) to {last:.0%} ({m.index[-1]}); "
                f"capacity values are configured assumptions.", "derived", "medium", f"{len(D)} days, monthly means",
                [ev(f"mean peak U {k}", round(float(v), 3), "capacity analysis", "/capacity") for k, v in m.items()], "capacity"))
    return out


def peak_insights() -> list[dict]:
    out = []
    for k in (1, 7):
        e = PK.evaluate(k)
        if not e.get("n"):
            continue
        mo, ba = e["model"], e["baseline"]
        out.append(insight(
            f"At D-{k}, the busiest hour is predicted within ±1 h on {mo['hit_rate_pm1h']:.0%} of days (baseline {ba['hit_rate_pm1h']:.0%}); "
            f"the actual peak lies in the predicted top-3 hours on {mo['top3_hit_rate']:.0%} of days. EHAM days have several near-equal waves, "
            f"so a top-3 window is the more reliable planning signal. Peak size error ≈ {mo['size_mae']:.1f} movements.",
            "predicted", "medium" if e["n"] >= 30 else "low", f"{e['n']} backtest days",
            [ev("hit ±1 h (model)", round(mo["hit_rate_pm1h"], 3), "peak evaluation", "/intel?tab=peaks"),
             ev("hit ±1 h (baseline)", round(ba["hit_rate_pm1h"], 3), "peak evaluation"), ev("top-3 hit", round(mo["top3_hit_rate"], 3), "peak evaluation"),
             ev("peak size MAE", round(mo["size_mae"], 2), "peak evaluation")], "peak"))
    return out


# ----------------------------------------------------------------------------------------- scenarios
def scenario_insights() -> list[dict]:
    with session_scope() as s:
        rows = [(r.id, r.name, json.loads(r.result_json or "{}")) for r in s.execute(select(M.SimulationScenario)).scalars()]
    twin = [(i, n, r) for i, n, r in rows if r.get("module") == "twin"]
    strat = [(i, n, r) for i, n, r in rows if r.get("spec", {}).get("preset")]
    out = []
    if len(twin) >= 2:
        t = sorted(twin, key=lambda x: x[2]["delta_vs_baseline"]["total_delay_min"] or 0)
        best, worst = t[0], t[-1]
        out.append(insight(
            f"Of {len(twin)} saved digital-twin scenarios, '{worst[1]}' adds the most delay ({worst[2]['delta_vs_baseline']['total_delay_min']:+.0f} min) and "
            f"'{best[1]}' the least ({best[2]['delta_vs_baseline']['total_delay_min']:+.0f} min). Simulated results under stated assumptions.",
            "simulated", "medium", "deterministic queue model; values depend on scenario assumptions",
            [ev(n, r["delta_vs_baseline"]["total_delay_min"], "digital twin", "/twin") for _, n, r in t], "scenario"))
    if len(strat) >= 2:
        t = sorted(strat, key=lambda x: x[2]["summary"]["delay_movement_hours"])
        over = [x for x in strat if x[2]["summary"]["annual_share_of_cap"] > 1]
        out.append(insight(
            f"Of {len(strat)} saved strategic scenarios, {len(over)} {'exceeds' if len(over) == 1 else 'exceed'} the annual movement cap"
            + (f" (e.g. '{over[0][1]}' at {over[0][2]['summary']['annual_share_of_cap']:.0%})" if over else "")
            + f"; the highest queueing is '{t[-1][1]}' ({t[-1][2]['summary']['delay_movement_hours']:.0f} movement-hours per typical week).",
            "simulated", "medium", "typical-week simulation under stated assumptions",
            [ev(n, round(r["summary"]["annual_share_of_cap"], 3), "strategic scenarios", "/strategic") for _, n, r in strat], "scenario"))
    return out


# ----------------------------------------------------------------------------------------- investigate
def investigate(start: date, end: date) -> list[dict]:
    from ..tactical import state as ST
    out = []
    for a in AN.daily(start, end)["anomalies"]:
        if a["confidence"] == "low":
            continue
        if len(ST.events_on(date.fromisoformat(a["date"]))) == 0:
            out.append(insight(f"Investigate {a['date']}: a {a['confidence']}-confidence anomaly ({a['actual']} vs ~{a['expected']:.0f}) with no recorded event.",
                               "derived", a["confidence"], "anomaly detector confidence",
                               [ev("anomaly z", a["z_total"], "STL residual"), ev("events recorded", 0, "event log", "/tactical"),
                                ev("root cause", a["date"], "post-operations", f"/postops?tab=rootcause&day={a['date']}")], "investigate", date=a["date"]))
    for h in AN.hourly(start, end):
        if h["actual"] == 0:
            out.append(insight(f"Check the data feed for {h['date']} {h['hour']:02d}:00: no movements recorded where ~{h['usual']:.0f} are usual.",
                               "derived", "medium", "zero count in an hour that normally has traffic",
                               [ev("actual", 0, "movement table"), ev("usual (median of 4 same weekdays)", h["usual"], "movement table")], "investigate"))
    try:
        pat = PR.patterns(start, end)
        for o in pat["unscheduled_operators"][:3]:
            if o["canceled_all"] >= 20:
                out.append(insight(f"Investigate flight-identity matching for {o['operator']}: {o['canceled_all']} listed movements look 'not flown' while "
                                   f"{o['added']} flown ones are 'unscheduled'.", "inferred", "medium", "pattern typical of callsign/flight-number mismatch",
                                   [ev("not flown", o["canceled_all"], "movement_match"), ev("unscheduled", o["added"], "movement_match", "/postops?tab=deviations")],
                                   "investigate", operator=o["operator"]))
    except LookupError:
        pass
    return out


# ----------------------------------------------------------------------------------------- briefing
_CACHE: dict = {}


def briefing(start: date, end: date) -> dict:
    from ..ingest.pipeline import latest_dataset_version
    from ..capacity.profile import _stamp, active_id
    pid = active_id()
    key = (latest_dataset_version(), str(start), str(end), pid, _stamp(pid), _scenario_count())
    if key not in _CACHE:
        _CACHE.clear()
        _CACHE[key] = _build(start, end)
    return _CACHE[key]


def _scenario_count() -> int:
    with session_scope() as s:
        return len(s.execute(select(M.SimulationScenario.id)).all())


def _build(start: date, end: date) -> dict:
    W = load_daily(start, end)
    sections = []
    if len(W):
        tot, per = float(W["actual_mov"].sum()), float(W["actual_mov"].mean())
        plan = W.dropna(subset=["plan_mov"])
        dev = (plan["actual_mov"].sum() - plan["plan_mov"].sum()) / plan["plan_mov"].sum() if len(plan) else None
        head = [insight(f"{len(W)} days analysed: {tot:,.0f} movements ({per:,.0f}/day)"
                        + (f"; {dev:+.1%} versus the plan of record on {len(plan)} days with a plan." if dev is not None else "."),
                        "actual", "high", "counted from the movement table",
                        [ev("movements", int(tot), "movement table"), ev("per day", round(per, 1), "movement table"),
                         ev("deviation vs plan", None if dev is None else round(dev, 4), "performance store", "/postops")], "summary")]
        sections.append({"title": "Headline", "items": head})
    sections += [
        {"title": "Unusual days and patterns", "items": AN.insights(start, end)},
        {"title": "Forecast performance and misses", "items": forecast_insights(start, end)},
        {"title": "Traffic peaks", "items": peak_insights()},
        {"title": "Capacity pressure", "items": capacity_insights(start, end)},
        {"title": "Scenario comparison", "items": scenario_insights()},
        {"title": "Suggested investigations", "items": investigate(start, end)},
        {"title": "Data limits", "items": [insight("Weather, runway-in-use, stand, block-time and passenger data are not connected; insights cannot attribute "
                                                   "deviations to these factors.", "unavailable", "high", "no such source in the warehouse",
                                                   [ev("data sources", "realisation, schedule lists, CDM extract, airline tables", "data management", "/data")], "data")]},
    ]
    return {"range": [str(start), str(end)], "generated_by": "deterministic rules over the warehouse (no external AI service)",
            "sections": sections, "counts": {s["title"]: len(s["items"]) for s in sections}}


def markdown(b: dict) -> str:
    lines = [f"# AOM-DIS operational briefing — EHAM {b['range'][0]} … {b['range'][1]}", "",
             "_Historical data (2022), not live. Generated by deterministic rules; every statement lists its evidence. "
             "Confidence levels are explained; causes not present in the data are not asserted._", ""]
    n = 0
    notes = []
    for s in b["sections"]:
        if not s["items"]:
            continue
        lines += [f"## {s['title']}", ""]
        for it in s["items"]:
            n += 1
            lines.append(f"- {it['statement']} *({it['kind']}, confidence {it['confidence']})* [{n}]")
            notes.append(f"[{n}] " + "; ".join(f"{e['label']}: {e['value']}" + (f" ({e['ref']})" if e.get("ref") else "") for e in it["evidence"])
                         + f" — confidence reason: {it['confidence_reason']}")
        lines.append("")
    return "\n".join(lines + ["## Evidence", ""] + notes) + "\n"


def _json_safe(o):
    if isinstance(o, dict):
        return {k: _json_safe(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_json_safe(v) for v in o]
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o
