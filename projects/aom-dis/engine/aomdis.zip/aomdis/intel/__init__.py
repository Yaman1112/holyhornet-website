"""AI-assisted operational intelligence (deterministic and traceable).

Every insight follows the decision-support contract (requirement INT-1):

  observation  plain-language sentence (``statement`` kept as an alias); never asserts causes not in the data
  evidence     supporting data: list of {label, value, source, ref}; ``ref`` reproduces it in the app
  period       time period the observation covers
  relevance    why it matters operationally
  impact       estimated impact (quantified where the evidence allows; otherwise says it is not quantified)
  confidence   high | medium | low, plus ``confidence_reason`` (evidence level, not a probability)
  action       recommended action for a human to consider (the platform never acts by itself)
  limitations  what the observation cannot tell
  layer        observed_fact | statistical_finding | model_prediction | simulation_result | interpretation
  kind         provenance of the underlying values: actual | derived | inferred | predicted | simulated
  category     anomaly | peak | forecast | capacity | scenario | data | investigate | summary

Layers keep facts, statistics, model outputs and interpretations apart. Human decisions are not insights:
they live in the event log and the audit trail. No external AI service is called.
"""

LAYER_BY_KIND = {"actual": "observed_fact", "derived": "statistical_finding", "inferred": "statistical_finding",
                 "predicted": "model_prediction", "simulated": "simulation_result"}

_DEFAULTS = {
    "forecast": {"relevance": "Pre-tactical and tactical plans (staffing, slot and stand planning) are built on these forecasts.",
                 "action": "Review the forecast-miss explanation and the plan-vs-actual decomposition before relying on the same model for similar days.",
                 "limitations": "Errors are measured on historical days; the data has no cause field, so misses are decomposed, not explained causally."},
    "capacity": {"relevance": "Hours at or above 90 % utilisation leave little margin for disruption recovery.",
                 "action": "Review the capacity profile and resource plan for these hours with the responsible units.",
                 "limitations": "Capacity values are configured assumptions, not declared capacity; utilisation inherits that uncertainty."},
    "peak": {"relevance": "Peak-hour staffing and runway-configuration planning depend on where the busiest hour falls.",
             "action": "Plan for the predicted top-3 hour window rather than a single peak hour.",
             "limitations": "Peak prediction is a backtested statistical model; EHAM days have several near-equal waves."},
    "anomaly": {"relevance": "Unusual days distort averages and forecast training; they may indicate disruption or data issues.",
                "action": "Check the event log and data feed for the day; record the cause if known.",
                "limitations": "Detection says what is unusual, never why."},
    "scenario": {"relevance": "Compares saved what-if scenarios on the same deterministic model.",
                 "action": "Use the comparison to choose which mitigation to study in more depth.",
                 "limitations": "Simulated under stated assumptions with a simplified queue model; not a validated ATC simulation."},
    "investigate": {"relevance": "Unexplained data patterns reduce trust in every downstream figure.",
                    "action": "Investigate the listed item and record the finding.",
                    "limitations": "This is a prompt for human investigation, not a finding."},
    "data": {"relevance": "Defines what the analytics can and cannot say.",
             "action": "Connect the missing data sources before drawing conclusions that need them.",
             "limitations": "Stated by design; not derived from data."},
    "summary": {"relevance": "Context for every other statement in the briefing.",
                "action": "No action; context only.",
                "limitations": "Counts cover complete local days in the selected range."},
}


def insight(statement: str, kind: str, confidence: str, reason: str, evidence: list[dict], category: str,
            *, period: str | None = None, relevance: str | None = None, impact: str | None = None,
            action: str | None = None, limitations: str | None = None, layer: str | None = None, **extra) -> dict:
    assert confidence in ("high", "medium", "low")
    assert evidence, "an insight without evidence is not allowed"
    d = _DEFAULTS.get(category, _DEFAULTS["investigate"])
    lay = layer or ("interpretation" if category == "investigate" else LAYER_BY_KIND.get(kind, "statistical_finding"))
    return {"statement": statement, "observation": statement, "kind": kind, "layer": lay,
            "confidence": confidence, "confidence_reason": reason, "evidence": evidence, "category": category,
            "period": period, "relevance": relevance or d["relevance"], "impact": impact or "not quantified from the available evidence",
            "action": action or d["action"], "limitations": limitations or d["limitations"], **extra}


def ev(label: str, value, source: str, ref: str | None = None) -> dict:
    return {"label": label, "value": value, "source": source, "ref": ref}


def fill_period(items: list[dict], period: str) -> list[dict]:
    """Insights without their own period cover the briefing range."""
    for it in items:
        if not it.get("period"):
            it["period"] = period
    return items
