"""AI-assisted operational intelligence (deterministic and traceable).

Every insight is a dict with:
  statement    plain-language sentence (never asserts causes that are not in the data)
  kind         actual | derived | inferred | predicted | simulated
  confidence   high | medium | low, plus ``confidence_reason``
  evidence     list of {label, value, source, ref} — ``ref`` is an app path / API query that reproduces it
  category     anomaly | peak | forecast | capacity | scenario | data | investigate
No external AI service is called: data stays local and every sentence is generated from cited values.
"""


def insight(statement: str, kind: str, confidence: str, reason: str, evidence: list[dict], category: str, **extra) -> dict:
    assert confidence in ("high", "medium", "low")
    assert evidence, "an insight without evidence is not allowed"
    return {"statement": statement, "kind": kind, "confidence": confidence, "confidence_reason": reason,
            "evidence": evidence, "category": category, **extra}


def ev(label: str, value, source: str, ref: str | None = None) -> dict:
    return {"label": label, "value": value, "source": source, "ref": ref}
