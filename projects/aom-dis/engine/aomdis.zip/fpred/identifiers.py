"""Flight identifier parsing and airline-code mapping.

Three kinds of identifier appear in the data:

* IATA flight numbers   ``KL868``, ``KL0868``, ``U21836``   (2-char airline + digits [+ letter])
* ICAO callsigns        ``KLM48X``, ``SAS594``, ``RYR5GM``  (3-letter operator + alnum)
* registrations / misc  ``PHLGD``, ``9HJLK``                (general aviation, no airline)

The schedule lists mix all three; the realisation uses callsigns; the CDM file
pairs an IATA flight number with the callsign it actually flew under (KLM and
easyJet use alphanumeric callsigns, so ``KL1906`` flies as ``KLM48X``).
"""
from __future__ import annotations

import re
from dataclasses import dataclass

import pandas as pd

_ICAO = re.compile(r"^([A-Z]{3})(\d[0-9A-Z]*)$")
_IATA = re.compile(r"^([A-Z0-9]{2})(\d{1,5})([A-Z]?)$")

# ICAO operators whose flight numbers the CDM file writes with the ICAO prefix.
ICAO_TO_IATA_OVERRIDES = {"EJU": "U2", "EZY": "U2", "EZS": "U2", "AEA": "UX", "KLM": "KL"}


@dataclass(frozen=True)
class Ident:
    kind: str  # "iata" | "icao" | "other"
    airline: str | None
    number: str | None
    suffix: str = ""

    @property
    def flight_key(self) -> str | None:
        """Canonical IATA flight number, leading zeros removed (KL0719 -> KL719)."""
        if self.kind != "iata":
            return None
        return f"{self.airline}{int(self.number)}{self.suffix}"


def clean(s: object) -> str:
    if s is None or (isinstance(s, float) and pd.isna(s)):
        return ""
    return str(s).replace(" ", "").upper().strip()


def parse(s: object) -> Ident:
    s = clean(s)
    m = _ICAO.match(s)
    if m:
        return Ident("icao", m.group(1), m.group(2))
    m = _IATA.match(s)
    if m and not m.group(1).isdigit():
        return Ident("iata", m.group(1), m.group(2), m.group(3))
    return Ident("other", None, None)


def build_airline_map(handmade: pd.DataFrame, openflights: pd.DataFrame | None) -> dict[str, str]:
    """IATA airline code -> ICAO operator code.

    The hand-made list (built in 2022 from callsign co-occurrence counts at EHAM)
    wins; OpenFlights fills the gaps where an active IATA code maps to exactly
    one ICAO code.
    """
    out: dict[str, str] = {}
    if openflights is not None and len(openflights):
        of = openflights.copy()
        of = of[(of["active"] == "Y") & of["flightnr"].notna() & of["callsign"].notna()]
        of = of[of["flightnr"].str.fullmatch(r"[A-Z0-9]{2}") & of["callsign"].str.fullmatch(r"[A-Z]{3}")]
        uniq = of.groupby("flightnr")["callsign"].nunique()
        of = of[of["flightnr"].isin(uniq[uniq == 1].index)]
        out.update(dict(zip(of["flightnr"], of["callsign"])))
    hm = handmade.dropna(subset=["airline", "callsign"]).copy()
    if "count" in hm:
        hm = hm.sort_values("count", ascending=True)  # highest count written last -> wins
    for a, c in zip(hm["airline"].map(clean), hm["callsign"].map(clean)):
        out[a] = c
    return out


def reverse_airline_map(iata_to_icao: dict[str, str]) -> dict[str, str]:
    rev: dict[str, str] = {}
    for iata, icao in iata_to_icao.items():
        rev.setdefault(icao, iata)
    rev.update(ICAO_TO_IATA_OVERRIDES)
    return rev


def build_cdm_callsigns(cdm: pd.DataFrame, icao_to_iata: dict[str, str]) -> dict[str, set[str]]:
    """Canonical IATA flight number -> set of callsigns it was seen flying as (CDM data)."""
    df = cdm.dropna(subset=["flightName", "callsign"])
    out: dict[str, set[str]] = {}
    for fn, cs in zip(df["flightName"].map(clean), df["callsign"].map(clean)):
        ident = parse(fn)
        if ident.kind == "icao" and ident.airline in icao_to_iata:
            ident = parse(icao_to_iata[ident.airline] + ident.number)
        key = ident.flight_key
        if key and cs:
            out.setdefault(key, set()).add(cs)
    return out
