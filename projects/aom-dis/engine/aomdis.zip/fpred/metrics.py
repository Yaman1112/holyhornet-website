"""Turn classified flights into prediction-quality metrics."""
from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd

from .matching import STATES


def _counts(df: pd.DataFrame) -> dict[str, int]:
    vc = df["state"].value_counts()
    return {s: int(vc.get(s, 0)) for s in STATES}


def _scores(c: dict[str, int]) -> dict[str, float | None]:
    scheduled = c["matched"] + c["canceled"] + c["confirmed_canceled"]
    realised = c["matched"] + c["added"]
    return {
        "scheduled": scheduled,
        "realised": realised,
        # share of scheduled flights that actually operated
        "precision": c["matched"] / scheduled if scheduled else None,
        # share of real traffic the schedule foresaw
        "recall": c["matched"] / realised if realised else None,
        "volume_error_pct": (scheduled - realised) / realised * 100 if realised else None,
    }


def summary(flights: pd.DataFrame) -> dict:
    c = _counts(flights)
    out = {"counts": c, **_scores(c)}
    m = flights[flights["state"] == "matched"]
    d = m["offset_min"].dropna()
    out["timing"] = {
        "median_delta_min": float(d.median()) if len(d) else None,
        "mae_min": float(d.abs().mean()) if len(d) else None,
        "within_15_min_pct": float((d.abs() <= 15).mean() * 100) if len(d) else None,
        "within_60_min_pct": float((d.abs() <= 60).mean() * 100) if len(d) else None,
    }
    out["match_stage"] = {k: int(v) for k, v in m["stage"].value_counts().items()}
    return out


def daily(flights: pd.DataFrame, published: date | None) -> pd.DataFrame:
    df = flights.assign(day=flights["time"].dt.normalize())
    t = df.pivot_table(index="day", columns="state", values="time", aggfunc="count", fill_value=0)
    t = t.reindex(columns=STATES, fill_value=0)
    t["scheduled"] = t["matched"] + t["canceled"] + t["confirmed_canceled"]
    t["realised"] = t["matched"] + t["added"]
    t["precision"] = t["matched"] / t["scheduled"].replace(0, np.nan)
    t["recall"] = t["matched"] / t["realised"].replace(0, np.nan)
    if published and published != date.min:
        t["lead_days"] = (t.index - pd.Timestamp(published)).days
    t.index.name = "day"
    return t.reset_index()


def by_group(flights: pd.DataFrame, col: str, min_flights: int = 0) -> pd.DataFrame:
    rows = []
    for key, g in flights.groupby(col, dropna=False):
        c = _counts(g)
        s = _scores(c)
        rows.append({col: key if isinstance(key, str) else ("—" if pd.isna(key) else key), **c, **s})
    out = pd.DataFrame(rows)
    out = out[(out["scheduled"] + out["added"]) >= min_flights]
    return out.sort_values("scheduled", ascending=False).reset_index(drop=True)


def by_hour(flights: pd.DataFrame) -> pd.DataFrame:
    return by_group(flights.assign(hour=flights["time"].dt.hour), "hour").sort_values("hour").reset_index(drop=True)


def delay_histogram(flights: pd.DataFrame, bin_min: int = 15, limit: int = 240) -> pd.DataFrame:
    d = flights.loc[flights["state"] == "matched", "offset_min"].dropna().clip(-limit, limit)
    bins = np.arange(-limit, limit + bin_min, bin_min)
    counts, edges = np.histogram(d, bins=bins)
    return pd.DataFrame({"from_min": edges[:-1].astype(int), "to_min": edges[1:].astype(int), "count": counts})
