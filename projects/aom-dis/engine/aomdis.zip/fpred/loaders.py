"""Load and normalise the raw input files."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from functools import lru_cache
from pathlib import Path

import pandas as pd

from . import config
from .identifiers import clean, parse


@dataclass(frozen=True)
class ScheduleInfo:
    name: str        # e.g. "S22 23mar22"
    season: str      # e.g. "S22"
    published: date  # e.g. 2022-03-23
    path: Path


_NAME = re.compile(r"flight list (?P<name>(?P<season>[SW]\d{2}) (?P<pub>\d{2}[a-z]{3}\d{2}))\.csv$", re.I)


def list_schedules(data_dir: Path | None = None) -> list[ScheduleInfo]:
    data_dir = Path(data_dir or config.DATA_DIR)
    out = []
    for p in sorted(data_dir.glob(config.SCHEDULE_GLOB)):
        m = _NAME.search(p.name)
        if not m:
            continue
        pub = datetime.strptime(m.group("pub").lower(), "%d%b%y").date()
        out.append(ScheduleInfo(m.group("name"), m.group("season").upper(), pub, p))
    return sorted(out, key=lambda s: s.published)


def find_schedule(name: str, data_dir: Path | None = None) -> ScheduleInfo:
    for s in list_schedules(data_dir):
        if s.name.lower() == name.lower() or s.path.name.lower() == name.lower():
            return s
    p = Path(name)
    if p.exists():
        m = _NAME.search(p.name)
        if m:
            pub = datetime.strptime(m.group("pub").lower(), "%d%b%y").date()
            return ScheduleInfo(m.group("name"), m.group("season").upper(), pub, p)
        return ScheduleInfo(p.stem, "?", date.min, p)
    raise FileNotFoundError(f"schedule {name!r} not found in {data_dir or config.DATA_DIR}")



def load_schedule(info: ScheduleInfo) -> pd.DataFrame:
    """One row per scheduled EHAM movement: flight_id, ac_type, adep, dest, direction, time."""
    raw = pd.read_csv(info.path, sep=";", dtype=str, keep_default_na=False)
    raw = raw[(raw["ADEP"] == config.AIRPORT) | (raw["DEST"] == config.AIRPORT)].copy()
    t_dep = pd.to_datetime(raw["SOBT"].replace("", None), format="%d/%m/%Y %H:%M:%S", errors="coerce")
    t_arr = pd.to_datetime(raw["ETO_EHFIRAM"].replace("", None), format="%d/%m/%Y %H:%M:%S", errors="coerce")
    is_dep = raw["ADEP"] == config.AIRPORT
    df = pd.DataFrame({
        "flight_id": raw["Vluchtnummer"].map(clean),
        "ac_type": raw["AC_Type"],
        "adep": raw["ADEP"],
        "dest": raw["DEST"],
        "direction": is_dep.map({True: "DEP", False: "ARR"}),
        "time": t_dep.where(is_dep, t_arr),
    })
    df = df.dropna(subset=["time"])
    # The lists contain exact repeats of the same movement (e.g. one entry per FIR sector).
    key = ["flight_id", "adep", "dest", "time"]
    df["sector_rows"] = df.groupby(key, dropna=False)["flight_id"].transform("size")
    df["planned_reference"] = is_dep.map({True: "SOBT", False: "ETO_EHFIRAM"})
    df["source_time_raw"] = raw["SOBT"].where(is_dep, raw["ETO_EHFIRAM"])
    df = df.drop_duplicates(key)
    df = df.sort_values("time").reset_index(drop=True)
    df["sched_idx"] = df.index
    return df


@lru_cache(maxsize=4)
def _load_realisation_cached(path: str, mtime: float) -> pd.DataFrame:
    cache = config.OUTPUT_DIR / "cache" / "realisation.pkl"
    if cache.exists() and cache.stat().st_mtime > mtime:
        return pd.read_pickle(cache)
    raw = pd.read_excel(path)
    raw = raw[(raw["ADEP"] == config.AIRPORT) | (raw["DEST"] == config.AIRPORT)].copy()
    is_dep = raw["ADEP"] == config.AIRPORT
    df = pd.DataFrame({
        "real_id": raw["FLIGHT_ID"].astype("int64"),
        "callsign": raw["CALLSIGN"].map(clean),
        "ac_type": raw["ICAO_ACTYPE"],
        "adep": raw["ADEP"],
        "dest": raw["DEST"],
        "direction": is_dep.map({True: "DEP", False: "ARR"}),
        "time": pd.to_datetime(raw["TIME_DEP"]).where(is_dep, pd.to_datetime(raw["TIME_ARR"])),
    })
    df = df.dropna(subset=["time"]).sort_values("time").reset_index(drop=True)
    idents = df["callsign"].map(parse)
    df["operator"] = [i.airline if i.kind == "icao" else None for i in idents]
    df["real_idx"] = df.index
    cache.parent.mkdir(parents=True, exist_ok=True)
    df.to_pickle(cache)
    return df


def load_realisation(data_dir: Path | None = None) -> pd.DataFrame:
    p = Path(data_dir or config.DATA_DIR) / config.REALISATION_FILE
    return _load_realisation_cached(str(p), p.stat().st_mtime).copy()


def load_cdm(data_dir: Path | None = None) -> pd.DataFrame:
    p = Path(data_dir or config.DATA_DIR) / config.CDM_FILE
    return pd.read_csv(p, usecols=["flightName", "callsign"], dtype=str)


def load_handmade_airlines(data_dir: Path | None = None) -> pd.DataFrame:
    return pd.read_excel(Path(data_dir or config.DATA_DIR) / config.AIRLINE_MAP_FILE)


def load_openflights(data_dir: Path | None = None) -> pd.DataFrame | None:
    p = Path(data_dir or config.DATA_DIR) / config.OPENFLIGHTS_FILE
    if not p.exists():
        return None
    return pd.read_csv(p, dtype=str, na_values=["\\N", ""], keep_default_na=False)
