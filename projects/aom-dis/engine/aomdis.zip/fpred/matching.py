"""Pair scheduled movements with realised movements.

Every candidate pair must share ADEP, DEST and be within ``tolerance_hours``.
Two candidate stages, ranked into one list and assigned greedily one-to-one
(best score first, each scheduled and each realised flight used at most once):

1. ``callsign`` — the realised callsign is one the scheduled flight is known to fly
   as (itself, the CDM flight-number->callsign history, or ICAO operator + number).
   Score = |time difference| in minutes.
2. ``airline``  — same ICAO operator on the same route (KLM's alphanumeric callsigns
   change, so this catches most of them). Score = |time difference| + penalty.

Unpaired scheduled flights become ``canceled`` — or ``confirmed_canceled`` when no
realised flight of any operator used the route inside the tolerance window.
Unpaired realised flights become ``added``.

Compared with the 2022 script this is one-to-one (merge_asof let two scheduled
flights claim the same realised flight), uses the CDM callsign history, and
reads callsign-style schedule entries (``SAS594``) with their real operator
instead of the first two letters.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import MatchConfig
from .identifiers import parse

STATES = ["matched", "canceled", "confirmed_canceled", "added"]


def schedule_keys(schedule: pd.DataFrame, airline_map: dict[str, str],
                  cdm_callsigns: dict[str, set[str]]) -> pd.DataFrame:
    """Add ``operator`` and ``candidates`` (set of callsigns) to the schedule."""
    ops, cands = [], []
    for fid in schedule["flight_id"]:
        ident = parse(fid)
        c = {fid}
        op = None
        if ident.kind == "icao":
            op = ident.airline
        elif ident.kind == "iata":
            op = airline_map.get(ident.airline)
            c |= cdm_callsigns.get(ident.flight_key, set())
            if op:
                c.add(f"{op}{ident.number}{ident.suffix}")
                c.add(f"{op}{int(ident.number)}{ident.suffix}")
        ops.append(op)
        cands.append(c)
    out = schedule.copy()
    out["operator"] = ops
    out["candidates"] = cands
    return out


def _bucketed(df: pd.DataFrame, tol: pd.Timedelta, explode: bool) -> pd.DataFrame:
    b = (df["time"].astype("int64") // tol.value).astype("int64")
    if not explode:
        return df.assign(bucket=b)
    return pd.concat([df.assign(bucket=b + k) for k in (-1, 0, 1)], ignore_index=True)


def candidate_pairs(sched: pd.DataFrame, real: pd.DataFrame, cfg: MatchConfig) -> pd.DataFrame:
    tol = pd.Timedelta(hours=cfg.tolerance_hours)
    tol_min = cfg.tolerance_hours * 60

    # Stage 1: callsign
    s1 = sched[["sched_idx", "adep", "dest", "time", "candidates"]].explode("candidates")
    s1 = s1.rename(columns={"candidates": "callsign"})
    p1 = s1.merge(real[["real_idx", "adep", "dest", "time", "callsign"]],
                  on=["adep", "dest", "callsign"], suffixes=("_s", "_r"))
    p1["dt"] = (p1["time_r"] - p1["time_s"]).dt.total_seconds() / 60
    p1 = p1[p1["dt"].abs() <= tol_min]
    p1 = p1.assign(stage="callsign", score=p1["dt"].abs())

    # Stage 2: operator + route
    s2 = _bucketed(sched.loc[sched["operator"].notna(), ["sched_idx", "adep", "dest", "operator", "time"]], tol, True)
    r2 = _bucketed(real.loc[real["operator"].notna(), ["real_idx", "adep", "dest", "operator", "time"]], tol, False)
    p2 = s2.merge(r2, on=["adep", "dest", "operator", "bucket"], suffixes=("_s", "_r"))
    p2["dt"] = (p2["time_r"] - p2["time_s"]).dt.total_seconds() / 60
    p2 = p2[p2["dt"].abs() <= tol_min]
    p2 = p2.assign(stage="airline", score=p2["dt"].abs() + cfg.airline_stage_penalty_min)

    cols = ["sched_idx", "real_idx", "dt", "stage", "score"]
    pairs = pd.concat([p1[cols], p2[cols]], ignore_index=True)
    return pairs.sort_values(["score", "sched_idx", "real_idx"]).drop_duplicates(["sched_idx", "real_idx"])


def greedy_assign(pairs: pd.DataFrame) -> pd.DataFrame:
    used_s: set[int] = set()
    used_r: set[int] = set()
    keep = np.zeros(len(pairs), dtype=bool)
    for i, (s, r) in enumerate(zip(pairs["sched_idx"].to_numpy(), pairs["real_idx"].to_numpy())):
        if s in used_s or r in used_r:
            continue
        used_s.add(s)
        used_r.add(r)
        keep[i] = True
    return pairs[keep]


def _route_has_traffic(sched: pd.DataFrame, real: pd.DataFrame, tol: pd.Timedelta) -> pd.Series:
    """For each schedule row: did any realised flight use the same route within tol?"""
    s = _bucketed(sched[["sched_idx", "adep", "dest", "time"]], tol, True)
    r = _bucketed(real[["adep", "dest", "time"]], tol, False)
    m = s.merge(r, on=["adep", "dest", "bucket"], suffixes=("_s", "_r"))
    m = m[(m["time_r"] - m["time_s"]).abs() <= tol]
    return sched["sched_idx"].isin(m["sched_idx"].unique())


def match(schedule: pd.DataFrame, realisation: pd.DataFrame, airline_map: dict[str, str],
          cdm_callsigns: dict[str, set[str]], window: tuple[pd.Timestamp, pd.Timestamp],
          cfg: MatchConfig = MatchConfig()) -> pd.DataFrame:
    """Classify every scheduled and realised movement in ``window`` [start, end).

    Returns one row per flight with columns: state, direction, adep, dest,
    sched_flight_id, sched_time, sched_ac_type, real_callsign, real_time,
    real_ac_type, operator, stage, offset_min, time.
    """
    start, end = window
    tol = pd.Timedelta(hours=cfg.tolerance_hours)
    sched = schedule_keys(schedule, airline_map, cdm_callsigns)
    # Use realised flights slightly outside the window so edge flights can still pair.
    real = realisation[(realisation["time"] >= start - tol) & (realisation["time"] < end + tol)]
    sched = sched[(sched["time"] >= start - tol) & (sched["time"] < end + tol)]

    pairs = greedy_assign(candidate_pairs(sched, real, cfg))

    s = sched.set_index("sched_idx")
    r = real.set_index("real_idx")

    m = pairs.join(s[["flight_id", "ac_type", "adep", "dest", "direction", "time", "operator"]], on="sched_idx")
    m = m.join(r[["callsign", "ac_type", "time", "operator"]], on="real_idx", suffixes=("", "_r"))
    matched = pd.DataFrame({
        "state": "matched",
        "direction": m["direction"], "adep": m["adep"], "dest": m["dest"],
        "sched_flight_id": m["flight_id"], "sched_time": m["time"], "sched_ac_type": m["ac_type"],
        "real_callsign": m["callsign"], "real_time": m["time_r"], "real_ac_type": m["ac_type_r"],
        "operator": m["operator_r"].fillna(m["operator"]), "stage": m["stage"], "offset_min": m["dt"],
        "time": m["time"], "sched_idx": m["sched_idx"].to_numpy(), "real_idx": m["real_idx"].to_numpy(),
    })

    us = sched[~sched["sched_idx"].isin(pairs["sched_idx"])]
    traffic = _route_has_traffic(us, real, tol)
    canceled = pd.DataFrame({
        "state": np.where(traffic, "canceled", "confirmed_canceled"),
        "direction": us["direction"], "adep": us["adep"], "dest": us["dest"],
        "sched_flight_id": us["flight_id"], "sched_time": us["time"], "sched_ac_type": us["ac_type"],
        "real_callsign": None, "real_time": pd.NaT, "real_ac_type": None,
        "operator": us["operator"], "stage": None, "offset_min": np.nan, "time": us["time"],
        "sched_idx": us["sched_idx"], "real_idx": np.nan,
    })

    ur = real[~real["real_idx"].isin(pairs["real_idx"])]
    added = pd.DataFrame({
        "state": "added",
        "direction": ur["direction"], "adep": ur["adep"], "dest": ur["dest"],
        "sched_flight_id": None, "sched_time": pd.NaT, "sched_ac_type": None,
        "real_callsign": ur["callsign"], "real_time": ur["time"], "real_ac_type": ur["ac_type"],
        "operator": ur["operator"], "stage": None, "offset_min": np.nan, "time": ur["time"],
        "sched_idx": np.nan, "real_idx": ur["real_idx"],
    })

    out = pd.concat([matched, canceled, added], ignore_index=True)
    out = out[(out["time"] >= start) & (out["time"] < end)]
    return out.sort_values(["time", "state"]).reset_index(drop=True)
