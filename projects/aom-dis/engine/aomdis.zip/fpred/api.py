"""FastAPI service + static dashboard.

Run:  .venv/Scripts/python -m uvicorn fpred.api:app --port 8780
"""
from __future__ import annotations

import io
import re
import threading
from pathlib import Path

import pandas as pd
from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from . import __version__, config, forecast, loaders, pipeline

WEB_DIR = config.ROOT / "web"
UPLOAD_DIR = config.DATA_DIR / "uploads"

app = FastAPI(title="Schiphol D-7 Schedule Prediction", version=__version__)

_lock = threading.Lock()
_ctx = pipeline.Context()
_evals: dict[str, pipeline.Evaluation] = {}
_reports: dict[str, dict] = {}
_backtest: list[dict] | None = None


def _infos() -> list[loaders.ScheduleInfo]:
    infos = loaders.list_schedules(config.DATA_DIR)
    if UPLOAD_DIR.exists():
        infos += loaders.list_schedules(UPLOAD_DIR)
    seen, out = set(), []
    for i in sorted(infos, key=lambda s: s.published):
        if i.name not in seen:
            seen.add(i.name)
            out.append(i)
    return out


def _evaluation(name: str) -> pipeline.Evaluation:
    with _lock:
        if name not in _evals:
            info = next((i for i in _infos() if i.name == name), None)
            if info is None:
                raise HTTPException(404, f"unknown schedule {name!r}")
            ev = pipeline.evaluate(info, _ctx)
            if ev is None:
                raise HTTPException(422, f"{name} does not overlap the realisation period")
            _evals[name] = ev
            _reports[name] = pipeline._jsonable(ev.report())
        return _evals[name]


def _report(name: str) -> dict:
    _evaluation(name)
    return _reports[name]


@app.get("/api/health")
def health():
    r0, r1 = _ctx.realisation_days
    return {"ok": True, "version": __version__,
            "realisation": [r0.date().isoformat(), (r1 - pd.Timedelta(days=1)).date().isoformat()]}


@app.get("/api/schedules")
def schedules():
    out = []
    for info in _infos():
        try:
            rep = _report(info.name)
            out.append({k: rep[k] for k in ("schedule", "season", "published", "schedule_span", "window", "days_evaluated")}
                       | {"summary": rep["summary"], "uploaded": UPLOAD_DIR in info.path.parents})
        except HTTPException as e:
            out.append({"schedule": info.name, "published": info.published.isoformat(), "error": e.detail})
    return out


@app.get("/api/report/{name}")
def report(name: str):
    return _report(name)


@app.get("/api/flights/{name}")
def flights(name: str, state: str | None = None, q: str | None = None, direction: str | None = None,
            day: str | None = None, limit: int = Query(100, le=1000), offset: int = 0):
    f = _evaluation(name).flights
    if state:
        f = f[f["state"] == state]
    if direction:
        f = f[f["direction"] == direction.upper()]
    if day:
        f = f[f["time"].dt.strftime("%Y-%m-%d") == day]
    if q:
        qq = q.upper()
        mask = pd.Series(False, index=f.index)
        for c in ("sched_flight_id", "real_callsign", "adep", "dest", "operator"):
            mask |= f[c].fillna("").astype(str).str.contains(qq, regex=False)
        f = f[mask]
    page = f.iloc[offset:offset + limit]
    rows = pipeline._jsonable(page.astype(object).where(page.notna(), None).to_dict("records"))
    return {"total": int(len(f)), "offset": offset, "rows": rows}


@app.get("/api/backtest")
def backtest():
    global _backtest
    if _backtest is None:
        evs = []
        for i in _infos():
            try:
                evs.append(_evaluation(i.name))
            except HTTPException:
                pass
        _backtest = forecast.backtest(evs)
    return _backtest


@app.get("/api/download/{name}.xlsx")
def download(name: str):
    ev = _evaluation(name)
    rep = _report(name)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf) as xw:
        ev.flights.to_excel(xw, sheet_name="flights", index=False)
        pd.DataFrame(rep["daily"]).to_excel(xw, sheet_name="daily", index=False)
        pd.DataFrame(rep["by_operator"]).to_excel(xw, sheet_name="by_operator", index=False)
    buf.seek(0)
    fn = f"result_{name.replace(' ', '_')}.xlsx"
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="{fn}"'})


_UPLOAD_NAME = re.compile(r"^flight list [SW]\d{2} \d{2}[a-z]{3}\d{2}\.csv$", re.I)


@app.post("/api/schedules")
async def upload(file: UploadFile = File(...)):
    """Add a new schedule list (same ';'-separated format, named 'flight list S22 23mar22.csv')."""
    global _backtest
    name = Path(file.filename or "").name
    if not _UPLOAD_NAME.match(name):
        raise HTTPException(400, "file must be named like 'flight list S22 23mar22.csv'")
    data = await file.read()
    if len(data) > 50_000_000:
        raise HTTPException(413, "file too large")
    head = data[:400].decode("utf-8", "replace")
    for col in ("Vluchtnummer", "ADEP", "DEST", "SOBT", "ETO_EHFIRAM"):
        if col not in head:
            raise HTTPException(400, f"missing column {col}")
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    (UPLOAD_DIR / name).write_bytes(data)
    info = loaders.find_schedule(str(UPLOAD_DIR / name))
    with _lock:
        _evals.pop(info.name, None)
        _reports.pop(info.name, None)
        _backtest = None
    rep = _report(info.name)
    return {"schedule": info.name, "summary": rep["summary"]}


@app.get("/")
def index():
    return FileResponse(WEB_DIR / "index.html")


app.mount("/", StaticFiles(directory=WEB_DIR), name="web")
