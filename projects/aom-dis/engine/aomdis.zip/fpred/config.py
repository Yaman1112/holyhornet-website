"""Paths and tunables."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("FPRED_DATA", ROOT / "data" / "raw"))
OUTPUT_DIR = Path(os.environ.get("FPRED_OUTPUT", ROOT / "outputs"))

AIRPORT = "EHAM"

REALISATION_FILE = "realisatie.xlsx"
CDM_FILE = "flightnr_callsign.csv"
AIRLINE_MAP_FILE = "flnr_callsign_new.xlsx"
OPENFLIGHTS_FILE = "airlines.dat.txt"
SCHEDULE_GLOB = "flight list *.csv"


@dataclass(frozen=True)
class MatchConfig:
    # Maximum |scheduled - actual| time for a schedule entry and a realised flight to be paired.
    tolerance_hours: float = 4.0
    # Stage-2 (same airline + route, different flight id) pairs are ranked behind exact
    # callsign pairs by adding this penalty (in minutes) to their time difference.
    airline_stage_penalty_min: float = 600.0
