"""fpred — Schiphol (EHAM) D-7 schedule prediction analysis.

Compares the flight schedule lists published ahead of operations (the "D-7"
forecasts) with the flights that actually operated (realisation), classifies
every flight as matched / canceled / confirmed_canceled / added, and measures
how good the published schedule is as a prediction of real traffic.
"""

__version__ = "1.0.0"
