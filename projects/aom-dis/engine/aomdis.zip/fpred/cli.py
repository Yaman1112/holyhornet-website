"""Command line: ``python -m fpred [run|list|backtest] ...``"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from . import config, forecast, loaders, pipeline
from .config import MatchConfig


def _fmt_pct(x):
    return "  n/a" if x is None else f"{x * 100:5.1f}%"


def _print(ev: pipeline.Evaluation) -> None:
    r = ev.report()
    s = r["summary"]
    c = s["counts"]
    print(f"\n{r['schedule']}  published {r['published']}  evaluated {r['window'][0]} -> {r['window'][1]} ({r['days_evaluated']} days)")
    print(f"  scheduled {s['scheduled']:>6}   realised {s['realised']:>6}   volume error {s['volume_error_pct']:+.1f}%")
    print(f"  matched {c['matched']:>6}  canceled {c['canceled']:>5}  confirmed_canceled {c['confirmed_canceled']:>5}  added {c['added']:>5}")
    print(f"  precision {_fmt_pct(s['precision'])}  (scheduled flights that flew)   recall {_fmt_pct(s['recall'])}  (real traffic foreseen)")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="fpred", description="Schiphol D-7 schedule prediction analysis")
    ap.add_argument("--data", type=Path, default=None, help=f"input folder (default {config.DATA_DIR})")
    ap.add_argument("--tolerance", type=float, default=4.0, help="matching tolerance in hours (default 4)")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("list", help="list schedule files")
    p_run = sub.add_parser("run", help="evaluate schedule file(s) and write outputs/")
    p_run.add_argument("schedule", nargs="*", help="schedule name ('S22 23mar22') or path; default all")
    sub.add_parser("backtest", help="evaluate all + calibrated-forecast backtest -> outputs/backtest.json")
    args = ap.parse_args(argv)

    ctx = pipeline.Context(args.data or config.DATA_DIR)
    cfg = MatchConfig(tolerance_hours=args.tolerance)

    if args.cmd == "list":
        for s in loaders.list_schedules(ctx.data_dir):
            print(f"{s.name:14} published {s.published}  {s.path.name}")
        return 0

    if args.cmd == "run":
        infos = [loaders.find_schedule(n, ctx.data_dir) for n in args.schedule] or loaders.list_schedules(ctx.data_dir)
        for info in infos:
            ev = pipeline.evaluate(info, ctx, cfg)
            if ev is None:
                print(f"{info.name}: no overlap with realisation data, skipped")
                continue
            out = pipeline.write_outputs(ev)
            _print(ev)
            print(f"  -> {out}")
        return 0

    if args.cmd in ("backtest", None):
        evs = pipeline.run_all(ctx, cfg)
        for ev in evs:
            _print(ev)
        bt = forecast.backtest(evs)
        config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        (config.OUTPUT_DIR / "backtest.json").write_text(json.dumps(bt, indent=1), encoding="utf-8")
        print("\nCalibrated forecast backtest (daily movements, trained only on data before publication):")
        for b in bt:
            print(f"  {b['schedule']:14} MAE raw {b['mae_raw']:6.1f} -> calibrated {b['mae_calibrated']:6.1f}   "
                  f"MAPE {b['mape_raw_pct']:4.1f}% -> {b['mape_calibrated_pct']:4.1f}%   "
                  f"Brier {b['brier']['raw']:.3f} -> {b['brier']['calibrated']:.3f}")
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
