"""End-to-end evaluation of one or more schedule files."""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from datetime import date
from functools import cached_property
from pathlib import Path

import pandas as pd

from . import config, loaders, metrics
from .config import MatchConfig
from .identifiers import build_airline_map, build_cdm_callsigns, reverse_airline_map
from .matching import match


@dataclass
class Context:
    """Shared reference data, loaded once."""
    data_dir: Path = field(default_factory=lambda: config.DATA_DIR)

    @cached_property
    def realisation(self) -> pd.DataFrame:
        return loaders.load_realisation(self.data_dir)

    @cached_property
    def airline_map(self) -> dict[str, str]:
        return build_airline_map(loaders.load_handmade_airlines(self.data_dir), loaders.load_openflights(self.data_dir))

    @cached_property
    def cdm_callsigns(self) -> dict[str, set[str]]:
        return build_cdm_callsigns(loaders.load_cdm(self.data_dir), reverse_airline_map(self.airline_map))

    @cached_property
    def realisation_days(self) -> tuple[pd.Timestamp, pd.Timestamp]:
        """[first full day, day after last full day) covered by the realisation file."""
        t = self.realisation["time"]
        return t.min().normalize() + pd.Timedelta(days=1), t.max().normalize()


@dataclass
class Evaluation:
    info: loaders.ScheduleInfo
    window: tuple[pd.Timestamp, pd.Timestamp]
    schedule_span: tuple[pd.Timestamp, pd.Timestamp]
    flights: pd.DataFrame

    @property
    def slug(self) -> str:
        return self.info.name.replace(" ", "_")

    def report(self) -> dict:
        f = self.flights
        return {
            "schedule": self.info.name,
            "season": self.info.season,
            "published": self.info.published.isoformat() if self.info.published != date.min else None,
            "schedule_span": [d.date().isoformat() for d in self.schedule_span],
            "window": [self.window[0].date().isoformat(), (self.window[1] - pd.Timedelta(days=1)).date().isoformat()],
            "days_evaluated": int((self.window[1] - self.window[0]).days),
            "summary": metrics.summary(f),
            "by_direction": metrics.by_group(f, "direction").to_dict("records"),
            "daily": metrics.daily(f, self.info.published).to_dict("records"),
            "by_operator": metrics.by_group(f, "operator", min_flights=30).head(40).to_dict("records"),
            "by_hour": metrics.by_hour(f).to_dict("records"),
            "delay_histogram": metrics.delay_histogram(f).to_dict("records"),
        }


def evaluate(info: loaders.ScheduleInfo, ctx: Context | None = None, cfg: MatchConfig = MatchConfig()) -> Evaluation | None:
    ctx = ctx or Context()
    sched = loaders.load_schedule(info)
    span = (sched["time"].min().normalize(), sched["time"].max().normalize())
    r0, r1 = ctx.realisation_days
    start = max(span[0], r0)
    end = min(span[1] + pd.Timedelta(days=1), r1)
    if end <= start:
        return None  # schedule does not overlap the realisation period
    flights = match(sched, ctx.realisation, ctx.airline_map, ctx.cdm_callsigns, (start, end), cfg)
    return Evaluation(info, (start, end), span, flights)


def _jsonable(o):
    if isinstance(o, dict):
        return {str(k): _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if isinstance(o, pd.Timestamp):
        return o.isoformat()
    if isinstance(o, float) and math.isnan(o):
        return None
    if hasattr(o, "item"):
        return _jsonable(o.item())
    return o


def write_outputs(ev: Evaluation, out_dir: Path | None = None) -> Path:
    out = Path(out_dir or config.OUTPUT_DIR) / ev.slug
    out.mkdir(parents=True, exist_ok=True)
    rep = _jsonable(ev.report())
    (out / "report.json").write_text(json.dumps(rep, indent=1), encoding="utf-8")
    ev.flights.to_csv(out / "flights.csv", index=False)
    with pd.ExcelWriter(out / "result.xlsx") as xw:
        ev.flights.to_excel(xw, sheet_name="flights", index=False)
        pd.DataFrame(rep["daily"]).to_excel(xw, sheet_name="daily", index=False)
        pd.DataFrame(rep["by_operator"]).to_excel(xw, sheet_name="by_operator", index=False)
        pd.DataFrame(rep["by_hour"]).to_excel(xw, sheet_name="by_hour", index=False)
    return out


def run_all(ctx: Context | None = None, cfg: MatchConfig = MatchConfig(), write: bool = True) -> list[Evaluation]:
    ctx = ctx or Context()
    evs = []
    for info in loaders.list_schedules(ctx.data_dir):
        ev = evaluate(info, ctx, cfg)
        if ev is None:
            continue
        evs.append(ev)
        if write:
            write_outputs(ev)
    return evs
