"""Calibrated D-7 traffic forecast + honest backtest.

The raw forecast for a day is "every scheduled flight operates". The calibrated
forecast learns, from flights that were already realised *before the schedule was
published*, how often each operator's scheduled flights actually fly and how much
unscheduled traffic appears per weekday:

    E[movements on day d] = Σ_scheduled p_operate(operator, direction)
                            + mean_added(weekday, direction)

p_operate is shrunk toward the direction-wide rate (empirical Bayes, prior weight
``k`` flights) so small operators do not get extreme rates. Optional recency
weighting (``half_life`` days) exists but is off by default: on this data it did not
beat equal weights. Training uses only evaluations from earlier schedule files and
only days < publication date, so the backtest never peeks at the future.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .pipeline import Evaluation

SCHEDULED = ["matched", "canceled", "confirmed_canceled"]


@dataclass
class Model:
    p_operator: dict[tuple[str, str], float]
    p_direction: dict[str, float]
    added_mean: dict[tuple[int, str], float]
    train_flights: int
    train_days: int

    def p_operate(self, operator: str | None, direction: str) -> float:
        return self.p_operator.get((operator or "—", direction), self.p_direction.get(direction, 1.0))


def fit(train: pd.DataFrame, k: float = 20.0, half_life: float = float("inf"),
        cutoff: pd.Timestamp | None = None) -> Model | None:
    if train.empty:
        return None
    if "source" not in train:
        train = train.assign(source="train")
    sch = train[train["state"].isin(SCHEDULED)].assign(op=lambda d: d["operator"].fillna("—"),
                                                        ok=lambda d: d["state"] == "matched")
    # Recency weight: flights `half_life` days before the cutoff count half as much.
    cutoff = cutoff if cutoff is not None else train["time"].max()
    age = lambda t: (cutoff - t).dt.total_seconds() / 86400  # noqa: E731
    sch["w"] = 0.5 ** (age(sch["time"]) / half_life)
    sch["wok"] = sch["w"] * sch["ok"]
    d = sch.groupby("direction")[["wok", "w"]].sum()
    p_dir = (d["wok"] / d["w"]).to_dict()
    g = sch.groupby(["op", "direction"])[["wok", "w"]].sum()
    p_op = {}
    for (op, dr), row in g.iterrows():
        prior = p_dir.get(dr, 1.0)
        p_op[(op, dr)] = (row["wok"] + k * prior) / (row["w"] + k)

    # Unscheduled traffic per (source schedule, day): training may hold several
    # overlapping schedule files, so a day is counted once per file it appears in.
    t = train.assign(day=train["time"].dt.normalize())
    units = t[["source", "day"]].drop_duplicates()
    units = units.assign(w=0.5 ** (age(units["day"] + pd.Timedelta(hours=12)) / half_life))
    add = t[t["state"] == "added"].groupby(["source", "day", "direction"]).size().unstack("direction", fill_value=0)
    units = units.join(add, on=["source", "day"]).fillna(0)
    added_mean = {}
    for wd, gw in units.groupby(units["day"].dt.day_of_week):
        for dr in ("ARR", "DEP"):
            if dr in gw:
                added_mean[(int(wd), dr)] = float((gw[dr] * gw["w"]).sum() / gw["w"].sum())
    return Model(p_op, p_dir, added_mean, int(len(sch)), int(t["day"].nunique()))


def predict_daily(model: Model, flights: pd.DataFrame) -> pd.DataFrame:
    sch = flights[flights["state"].isin(SCHEDULED)].copy()
    sch["p"] = [model.p_operate(o, d) for o, d in zip(sch["operator"], sch["direction"])]
    sch["day"] = sch["time"].dt.normalize()
    real = flights[flights["state"].isin(["matched", "added"])].assign(day=lambda d: d["time"].dt.normalize())
    rows = []
    for day, g in sch.groupby("day"):
        wd = day.weekday()
        added = sum(model.added_mean.get((wd, dr), 0.0) for dr in ("ARR", "DEP"))
        rows.append({
            "day": day,
            "scheduled": len(g),
            "calibrated": float(g["p"].sum() + added),
            "actual": int((real["day"] == day).sum()),
        })
    return pd.DataFrame(rows)


def brier(model: Model, flights: pd.DataFrame) -> dict[str, float]:
    sch = flights[flights["state"].isin(SCHEDULED)]
    y = (sch["state"] == "matched").to_numpy(float)
    p = np.array([model.p_operate(o, d) for o, d in zip(sch["operator"], sch["direction"])])
    return {"raw": float(np.mean((1 - y) ** 2)), "calibrated": float(np.mean((p - y) ** 2))}


def backtest(evs: list[Evaluation]) -> list[dict]:
    evs = sorted(evs, key=lambda e: e.info.published)
    results = []
    for i, test in enumerate(evs):
        cutoff = pd.Timestamp(test.info.published)
        train = pd.concat([e.flights[e.flights["time"] < cutoff].assign(source=e.info.name) for e in evs[:i]], ignore_index=True) if i else pd.DataFrame()
        model = fit(train, cutoff=cutoff) if len(train) else None
        if model is None:
            continue
        d = predict_daily(model, test.flights)
        err_raw = d["scheduled"] - d["actual"]
        err_cal = d["calibrated"] - d["actual"]
        results.append({
            "schedule": test.info.name,
            "published": test.info.published.isoformat(),
            "trained_on": [e.info.name for e in evs[:i]],
            "train_flights": model.train_flights,
            "train_days": model.train_days,
            "days": int(len(d)),
            "mae_raw": float(err_raw.abs().mean()),
            "mae_calibrated": float(err_cal.abs().mean()),
            "mape_raw_pct": float((err_raw.abs() / d["actual"]).mean() * 100),
            "mape_calibrated_pct": float((err_cal.abs() / d["actual"]).mean() * 100),
            "bias_raw": float(err_raw.mean()),
            "bias_calibrated": float(err_cal.mean()),
            "brier": brier(model, test.flights),
            "daily": [{"day": r.day.date().isoformat(), "scheduled": int(r.scheduled),
                       "calibrated": round(r.calibrated, 1), "actual": int(r.actual)} for r in d.itertuples()],
        })
    return results
