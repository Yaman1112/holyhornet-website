"""FastAPI service: session control, live WebSocket stream, assistant, experiments, exports, static UI."""
from __future__ import annotations

import asyncio
import csv
import io
import json
import threading
import time
import uuid
from pathlib import Path

import numpy as np
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .. import SOFTWARE_VERSION
from ..autonomy.assistant import answer
from ..autonomy.safety import FAULT_CATALOG
from ..engine import DeepFlightSim
from ..research.experiments import run_one
from ..robotics.autopilot_bridge import preview as autopilot_preview
from ..research.metrics import compute_metrics, map_accuracy
from ..simulation.scenarios import SCENARIOS, list_scenarios

ROOT = Path(__file__).resolve().parents[3]
WEB = ROOT / "web"
EXP_DIR = ROOT / "research" / "experiments"


class SimSession:
    def __init__(self, scenario: str, seed: int, overrides: dict | None, backend: str = "native",
                 px4_url: str = "udpin:0.0.0.0:14540"):
        self.id = uuid.uuid4().hex[:10]
        self.scenario, self.seed, self.overrides = scenario, seed, overrides or {}
        self.backend = backend
        self.lock = threading.Lock()
        factory = None
        if backend == "px4_sitl":
            from ..robotics.px4_run import connect, make_factory
            self._px4 = {}
            factory = make_factory(connect(px4_url), self._px4)
        self.sim = DeepFlightSim(scenario, seed, self.overrides, wallclock_monitors=True, vehicle_factory=factory)
        self.generation = 0
        self.speed = 1.0
        self.running = False
        self.alive = True
        self.commands: list[dict] = []
        self.created = time.time()
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def _loop(self) -> None:
        last = time.perf_counter()
        while self.alive:
            now = time.perf_counter()
            wall_dt = min(now - last, 0.25)
            last = now
            if self.running:
                with self.lock:
                    while self.commands:
                        self.sim.command(self.commands.pop(0))
                    target = self.sim.t + wall_dt * self.speed
                    t0 = time.perf_counter()
                    while self.sim.t < target - 1e-9 and not self.sim.finished:
                        self.sim.step()
                        if time.perf_counter() - t0 > 0.2:
                            break
                    if self.sim.finished:
                        self.running = False
            time.sleep(0.02)

    def reset(self) -> None:
        if self.backend == "px4_sitl":
            raise HTTPException(400, "PX4 SITL sessions cannot be reset in place: restart SITL and create a new session")
        with self.lock:
            self.sim = DeepFlightSim(self.scenario, self.seed, self.overrides, wallclock_monitors=True)
            self.generation += 1
            self.running = False
            self.commands.clear()

    def status(self) -> dict:
        return {"id": self.id, "scenario": self.scenario, "seed": self.seed, "running": self.running,
                "backend": self.backend,
                "vehicle": self.sim.vehicle.status() if self.backend != "native" else {"backend": "native"},
                "speed": self.speed, "t": self.sim.t, "finished": self.sim.finished, "generation": self.generation,
                "frames": len(self.sim.frames), "overrides": self.overrides}


SESSIONS: dict[str, SimSession] = {}
EXPERIMENTS: list[dict] = []

app = FastAPI(title="HolyHornet DeepFlight AI", version=SOFTWARE_VERSION,
              description="GNSS-independent autonomous navigation research platform (simulation mode).")
app.add_middleware(GZipMiddleware, minimum_size=2000)


@app.middleware("http")
async def revalidate_ui_assets(request, call_next):
    """UI files must be revalidated on every load (ETag/304) so a reload never runs stale modules."""
    resp = await call_next(request)
    if not request.url.path.startswith("/api"):
        resp.headers["Cache-Control"] = "no-cache"
    return resp


def _get(sid: str) -> SimSession:
    s = SESSIONS.get(sid)
    if s is None:
        raise HTTPException(404, "session not found")
    return s


class CreateSession(BaseModel):
    scenario: str = "M1"
    seed: int = 7
    overrides: dict = Field(default_factory=dict)
    backend: str = "native"               # native | px4_sitl
    px4_url: str = "udpin:0.0.0.0:14540"


class Control(BaseModel):
    action: str                     # start | pause | reset | speed | step
    value: float | None = None


class Ask(BaseModel):
    question: str


class ExperimentReq(BaseModel):
    scenario: str = "M1"
    seeds: list[int] = Field(default_factory=lambda: [701, 702])
    overrides: dict = Field(default_factory=dict)
    label: str = "baseline"


@app.get("/api/health")
def health() -> dict:
    return {"ok": True, "version": SOFTWARE_VERSION, "mode": "SIMULATION", "sessions": len(SESSIONS)}


@app.get("/api/scenarios")
def scenarios() -> list[dict]:
    return list_scenarios()


@app.get("/api/faults")
def faults() -> dict:
    return FAULT_CATALOG


@app.post("/api/sessions")
def create_session(req: CreateSession) -> dict:
    if req.scenario not in SCENARIOS:
        raise HTTPException(400, f"unknown scenario {req.scenario}")
    if not SCENARIOS[req.scenario].implemented:
        raise HTTPException(400, f"scenario {req.scenario} is planned, not implemented")
    # keep resource use bounded: retire old sessions
    while len(SESSIONS) >= 4:
        oldest = min(SESSIONS.values(), key=lambda s: s.created)
        oldest.alive = False
        del SESSIONS[oldest.id]
    if req.backend not in ("native", "px4_sitl"):
        raise HTTPException(400, "backend must be native or px4_sitl")
    if req.backend == "px4_sitl" and any(x.backend == "px4_sitl" and x.alive for x in SESSIONS.values()):
        raise HTTPException(409, "a PX4 SITL session already exists (one vehicle per SITL instance)")
    try:
        s = SimSession(req.scenario, req.seed, req.overrides, req.backend, req.px4_url)
    except (KeyError, ValueError, RuntimeError) as exc:
        raise HTTPException(400, str(exc))
    SESSIONS[s.id] = s
    return s.status() | {"info": s.sim.session_info()}


@app.get("/api/sessions")
def list_sessions() -> list[dict]:
    return [s.status() for s in SESSIONS.values()]


@app.get("/api/sessions/{sid}")
def get_session(sid: str) -> dict:
    s = _get(sid)
    return s.status() | {"info": s.sim.session_info()}


@app.post("/api/sessions/{sid}/control")
def control(sid: str, c: Control) -> dict:
    s = _get(sid)
    if c.action == "start":
        s.running = True
    elif c.action == "pause":
        if s.backend == "px4_sitl" and s.sim.mode not in ("PREFLIGHT", "LANDED", "COMPLETE", "CRASHED"):
            # freezing the companion would stop setpoints and trigger PX4's offboard-loss failsafe
            raise HTTPException(400, "cannot pause while PX4 is flying; use the operator Land decision")
        s.running = False
    elif c.action == "reset":
        s.reset()
    elif c.action == "speed":
        # PX4 SITL runs in real time: the companion loop cannot run faster than the autopilot
        s.speed = 1.0 if s.backend == "px4_sitl" else float(np.clip(c.value or 1.0, 0.1, 16.0))
    elif c.action == "step":
        if s.backend == "px4_sitl":
            raise HTTPException(400, "stepping is not available with PX4 SITL (real time)")
        with s.lock:
            s.sim.run_until(s.sim.t + (c.value or 0.1))
    else:
        raise HTTPException(400, "unknown action")
    return s.status()


@app.post("/api/sessions/{sid}/command")
def command(sid: str, cmd: dict) -> dict:
    s = _get(sid)
    if cmd.get("type") not in ("set_goal", "inject_fault", "clear_fault", "operator_decision", "heartbeat"):
        raise HTTPException(400, "unknown command type")
    if s.running:
        s.commands.append(cmd)
        return {"ok": True, "queued": True}
    with s.lock:
        return s.sim.command(cmd)


@app.get("/api/sessions/{sid}/frames")
def frames(sid: str, start: int = 0, end: int | None = None) -> dict:
    s = _get(sid)
    with s.lock:
        fr = s.sim.frames[start:end]
    return {"generation": s.generation, "start": start, "frames": fr}


@app.get("/api/sessions/{sid}/voxels")
def voxels(sid: str) -> dict:
    s = _get(sid)
    with s.lock:
        return {"occupied": s.sim.occupied_voxels(), "frame_index": len(s.sim.frames)}


@app.get("/api/sessions/{sid}/keyframes")
def keyframes(sid: str) -> list[dict]:
    s = _get(sid)
    with s.lock:
        return s.sim.keyframe_list()


@app.get("/api/sessions/{sid}/events")
def events(sid: str) -> list[dict]:
    return _get(sid).sim.events


@app.get("/api/sessions/{sid}/metrics")
def metrics(sid: str) -> dict:
    s = _get(sid)
    with s.lock:
        return compute_metrics(s.sim) | map_accuracy(s.sim)


@app.get("/api/sessions/{sid}/autopilot_preview")
def autopilot(sid: str) -> dict:
    s = _get(sid)
    with s.lock:
        return autopilot_preview(s.sim)


@app.post("/api/sessions/{sid}/assistant")
def assistant(sid: str, a: Ask) -> dict:
    s = _get(sid)
    with s.lock:
        return answer(s.sim, a.question)


@app.get("/api/sessions/{sid}/export/trajectory.csv", response_class=PlainTextResponse)
def export_traj(sid: str) -> str:
    s = _get(sid)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["t", "truth_x", "truth_y", "truth_z", "est_x", "est_y", "est_z", "sigma_x", "sigma_y", "sigma_z",
                "state", "mode", "behaviour", "vio_inliers"])
    with s.lock:
        for r in s.sim.records:
            c = np.sqrt(np.clip(np.diag(r["cov"]), 0, None))
            w.writerow([f"{r['t']:.2f}", *[f"{v:.4f}" for v in r["truth"]], *[f"{v:.4f}" for v in r["est"]],
                        *[f"{v:.4f}" for v in c], r["state"], r["mode"], r["behaviour"], r["inliers"]])
    return buf.getvalue()


@app.get("/api/sessions/{sid}/export/session.json")
def export_session(sid: str) -> dict:
    s = _get(sid)
    with s.lock:
        info = s.sim.session_info()
        info.pop("world", None)
        return {"session": s.status(), "info": info, "events": s.sim.events,
                "metrics": compute_metrics(s.sim) | map_accuracy(s.sim),
                "place_events": s.sim.loc.place_events, "replans": s.sim.replan_reasons,
                "ground_truth_note": "truth values are simulation ground truth used for validation only"}


@app.post("/api/experiments")
async def run_experiment(req: ExperimentReq) -> dict:
    if len(req.seeds) > 6:
        raise HTTPException(400, "at most 6 seeds per interactive request (use the CLI for batches)")
    if req.scenario not in SCENARIOS or not SCENARIOS[req.scenario].implemented:
        raise HTTPException(400, "scenario not available")
    loop = asyncio.get_running_loop()
    rows = []
    for seed in req.seeds:
        rows.append(await loop.run_in_executor(None, run_one, req.scenario, seed, req.overrides, req.label))
    exp = {"id": uuid.uuid4().hex[:8], "created": time.strftime("%Y-%m-%d %H:%M:%S"), "scenario": req.scenario,
           "label": req.label, "overrides": req.overrides, "rows": rows}
    EXPERIMENTS.append(exp)
    try:
        EXP_DIR.mkdir(parents=True, exist_ok=True)
        (EXP_DIR / f"exp_{exp['id']}.json").write_text(json.dumps(exp, indent=2, default=str))
    except OSError:
        pass
    return exp


@app.get("/api/experiments")
def list_experiments() -> list[dict]:
    return EXPERIMENTS


@app.get("/api/experiments/{eid}.csv", response_class=PlainTextResponse)
def experiment_csv(eid: str) -> str:
    exp = next((e for e in EXPERIMENTS if e["id"] == eid), None)
    if exp is None:
        raise HTTPException(404, "experiment not found")
    rows = [{k: (json.dumps(v) if isinstance(v, (dict, list)) else v) for k, v in r.items()} for r in exp["rows"]]
    keys = sorted({k for r in rows for k in r})
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=keys)
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue()


@app.websocket("/ws/sessions/{sid}")
async def ws(websocket: WebSocket, sid: str) -> None:
    await websocket.accept()
    s = SESSIONS.get(sid)
    if s is None:
        await websocket.close(code=4404)
        return
    gen = -1
    sent = 0
    try:
        while True:
            if gen != s.generation:
                gen = s.generation
                with s.lock:
                    init = {"type": "init", "status": s.status(), "info": s.sim.session_info(),
                            "occupied": s.sim.occupied_voxels(), "frame_index": len(s.sim.frames)}
                    sent = len(s.sim.frames)
                    hist = s.sim.frames[:sent]
                await websocket.send_text(json.dumps(init))
                # history in chunks so a late-joining client can replay the whole run
                for i in range(0, len(hist), 200):
                    await websocket.send_text(json.dumps({"type": "history", "start": i, "frames": hist[i:i + 200]}))
            with s.lock:
                new = s.sim.frames[sent:]
                sent += len(new)
                st = s.status()
            if new:
                await websocket.send_text(json.dumps({"type": "frames", "frames": new, "status": st}))
            else:
                await websocket.send_text(json.dumps({"type": "status", "status": st}))
            try:
                msg = await asyncio.wait_for(websocket.receive_text(), timeout=0.1)
                if msg:
                    cmd = json.loads(msg)
                    if cmd.get("type") == "heartbeat":
                        pass
            except asyncio.TimeoutError:
                pass
    except (WebSocketDisconnect, RuntimeError):
        return


@app.get("/")
def index() -> FileResponse:
    return FileResponse(WEB / "index.html")


if WEB.exists():
    app.mount("/", StaticFiles(directory=WEB), name="web")
