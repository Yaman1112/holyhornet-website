"""Configuration dataclasses. Every hardware/algorithm number lives here so experiments can record it."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields, is_dataclass
from typing import Any


@dataclass
class AircraftConfig:
    name: str = "DF-Q1 research quadcopter (simulated)"
    mass_kg: float = 1.45
    arm_length_m: float = 0.18
    collision_radius_m: float = 0.25
    max_tilt_deg: float = 25.0
    attitude_time_constant_s: float = 0.08
    max_speed_ms: float = 1.2
    max_accel_ms2: float = 1.5
    max_yaw_rate_dps: float = 60.0
    battery_wh: float = 55.0
    hover_power_w: float = 210.0
    companion_power_w: float = 15.0


@dataclass
class ImuConfig:
    rate_hz: float = 100.0
    gyro_noise_density: float = 0.004        # rad/s/sqrt(Hz)
    accel_noise_density: float = 0.04        # m/s^2/sqrt(Hz)
    gyro_bias_walk: float = 4e-5             # rad/s^2/sqrt(Hz)
    accel_bias_walk: float = 6e-4            # m/s^3/sqrt(Hz)
    initial_gyro_bias: tuple = (0.002, -0.003, 0.0015)
    initial_accel_bias: tuple = (0.04, -0.03, 0.05)


@dataclass
class CameraConfig:
    enabled: bool = True
    rate_hz: float = 20.0
    width: int = 640
    height: int = 480
    fx: float = 320.0
    fy: float = 320.0
    pixel_noise: float = 0.8
    max_range_m: float = 10.0
    depth_max_range_m: float = 6.0
    depth_noise_coeff: float = 0.004         # sigma_z = c * z^2 + 0.01 (stereo-style)
    mount_pitch_deg: float = 10.0
    lever_arm_m: tuple = (0.10, 0.0, 0.02)
    mismatch_rate: float = 0.03              # tracker association errors (outliers)
    max_features: int = 120
    exposure_s: float = 0.008
    depth_rays: tuple = (24, 18)             # depth image subsampled for mapping


@dataclass
class LidarConfig:
    enabled: bool = False
    rate_hz: float = 10.0
    channels: int = 16
    vertical_fov_deg: float = 30.0
    horizontal_step_deg: float = 3.0
    max_range_m: float = 20.0
    noise_m: float = 0.02


@dataclass
class FlowConfig:
    enabled: bool = True
    rate_hz: float = 25.0
    noise_ms: float = 0.04
    min_light: float = 0.25


@dataclass
class RangefinderConfig:
    enabled: bool = True
    rate_hz: float = 25.0
    noise_m: float = 0.02
    max_range_m: float = 8.0


@dataclass
class BaroConfig:
    enabled: bool = True
    rate_hz: float = 20.0
    noise_m: float = 0.12
    drift_m_per_s: float = 0.004


@dataclass
class GnssConfig:
    enabled: bool = True          # receiver present ...
    denied: bool = True           # ... but no fix: GNSS-denied operation


@dataclass
class SensorSuite:
    imu: ImuConfig = field(default_factory=ImuConfig)
    camera: CameraConfig = field(default_factory=CameraConfig)
    lidar: LidarConfig = field(default_factory=LidarConfig)
    flow: FlowConfig = field(default_factory=FlowConfig)
    rangefinder: RangefinderConfig = field(default_factory=RangefinderConfig)
    baro: BaroConfig = field(default_factory=BaroConfig)
    gnss: GnssConfig = field(default_factory=GnssConfig)


@dataclass
class EstimatorConfig:
    vio_min_inliers: int = 12
    vio_weak_inliers: int = 25
    vio_max_update_features: int = 40
    flow_fallback_only: bool = False          # fuse optical flow only while vision is not aiding
    chi2_gate_2dof: float = 9.21              # 99 %
    landmark_window_s: float = 6.0
    vio_drift_rate: float = 0.008             # 1-sigma horizontal drift per metre travelled (calibrated, see docs)            # sliding-window "marginalisation" of unseen landmarks
    keyframe_dist_m: float = 0.8
    keyframe_angle_deg: float = 20.0
    loop_min_inliers: int = 12
    loop_min_inlier_ratio: float = 0.35
    loop_exclude_recent_s: float = 20.0
    reloc_inlier_threshold_m: float = 0.25


@dataclass
class IntegrityConfig:
    reliable_sigma_m: float = 0.25
    degraded_sigma_m: float = 0.60
    lost_sigma_m: float = 1.50
    max_unaided_s_uncertain: float = 2.0
    max_unaided_s_lost: float = 8.0
    improve_dwell_s: float = 1.5
    recovering_dwell_s: float = 2.0
    reloc_timeout_s: float = 25.0


@dataclass
class MappingConfig:
    voxel_m: float = 0.2
    bounds_min: tuple = (-8.0, -4.0, -0.4)
    bounds_max: tuple = (34.0, 24.0, 3.6)
    log_hit: float = 0.85
    log_miss: float = -0.4
    log_min: float = -2.0
    log_max: float = 3.5
    occupied_threshold: float = 0.85
    integrate_only_when: str = "reliable_or_degraded"


@dataclass
class PlannerConfig:
    flight_altitude_m: float = 1.2
    altitude_band_m: float = 0.55
    base_margin_m: float = 0.35           # hard: 0.25 vehicle radius + 0.10 voxel half-size
    clearance_cost: float = 4.0           # soft: pulls routes to the middle of doorways (absorbs tracking error)
    sigma_inflation_k: float = 2.0
    max_inflation_m: float = 0.95
    unknown_cost: float = 1.5
    replan_period_s: float = 1.5
    lookahead_m: float = 1.0
    goal_tolerance_m: float = 0.35
    reactive_stop_m: float = 0.55


@dataclass
class SafetyConfig:
    degraded_speed_scale: float = 0.5
    recovering_speed_scale: float = 0.3
    search_yaw_rate_dps: float = 18.0
    low_battery_pct: float = 25.0
    critical_battery_pct: float = 12.0
    compute_budget_ms: float = 25.0
    lost_response: str = "hold_and_request_operator"   # | "land_in_place"
    uncertain_response: str = "hold"                    # | "continue_slow"


@dataclass
class DeepFlightConfig:
    aircraft: AircraftConfig = field(default_factory=AircraftConfig)
    sensors: SensorSuite = field(default_factory=SensorSuite)
    estimator: EstimatorConfig = field(default_factory=EstimatorConfig)
    integrity: IntegrityConfig = field(default_factory=IntegrityConfig)
    mapping: MappingConfig = field(default_factory=MappingConfig)
    planner: PlannerConfig = field(default_factory=PlannerConfig)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    sim_dt: float = 0.01

    def to_dict(self) -> dict:
        return asdict(self)


def apply_overrides(cfg: Any, overrides: dict | None) -> Any:
    """Apply nested ``{"sensors": {"lidar": {"enabled": true}}}`` style overrides in place."""
    if not overrides:
        return cfg
    names = {f.name for f in fields(cfg)}
    for key, value in overrides.items():
        if key not in names:
            raise KeyError(f"unknown config key '{key}' for {type(cfg).__name__}")
        current = getattr(cfg, key)
        if is_dataclass(current) and isinstance(value, dict):
            apply_overrides(current, value)
        else:
            if isinstance(current, tuple) and isinstance(value, list):
                value = tuple(value)
            setattr(cfg, key, value)
    return cfg
