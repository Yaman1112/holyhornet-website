"""Coordinate frames and rotation utilities.

Conventions (see docs/architecture/COORDINATE_FRAMES.md):

* ``map``   - local world frame, ENU-style: x forward/east, y left/north, z up. Origin = surveyed
              take-off point. Gravity is ``[0, 0, -9.81]``.
* ``body``  - FLU: x forward, y left, z up, origin at the IMU.
* ``cam``   - optical: z along the optical axis, x right, y down.
* ``R_ab``  - rotation taking vectors expressed in frame b into frame a (v_a = R_ab v_b).

PX4/ArduPilot use NED/FRD; ``enu_to_ned`` / ``flu_to_frd`` convert at the autopilot boundary only.
"""
from __future__ import annotations

import numpy as np

GRAVITY = np.array([0.0, 0.0, -9.81])


def skew(v: np.ndarray) -> np.ndarray:
    x, y, z = v
    return np.array([[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]])


def exp_so3(phi: np.ndarray) -> np.ndarray:
    """Rodrigues' formula: rotation vector -> rotation matrix."""
    angle = float(np.linalg.norm(phi))
    if angle < 1e-9:
        return np.eye(3) + skew(phi)
    axis = phi / angle
    K = skew(axis)
    return np.eye(3) + np.sin(angle) * K + (1.0 - np.cos(angle)) * (K @ K)


def log_so3(R: np.ndarray) -> np.ndarray:
    """Rotation matrix -> rotation vector."""
    cos_angle = np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0)
    angle = float(np.arccos(cos_angle))
    if angle < 1e-7:
        return np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]]) / 2.0
    if np.pi - angle < 1e-4:
        # Near pi: use the diagonal to recover the axis robustly.
        diag = np.clip((np.diag(R) + 1.0) / 2.0, 0.0, None)
        axis = np.sqrt(diag)
        k = int(np.argmax(axis))
        for j in range(3):
            if j != k:
                axis[j] = np.copysign(axis[j], R[k, j] + R[j, k])
        return angle * axis / np.linalg.norm(axis)
    w = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    return angle * w / (2.0 * np.sin(angle))


def rot_z(yaw: float) -> np.ndarray:
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def rot_from_ypr(yaw: float, pitch: float, roll: float) -> np.ndarray:
    """Z-Y-X intrinsic (yaw, pitch, roll) -> R_map_body."""
    cy, sy = np.cos(yaw), np.sin(yaw)
    cp, sp = np.cos(pitch), np.sin(pitch)
    cr, sr = np.cos(roll), np.sin(roll)
    return np.array([
        [cy * cp, cy * sp * sr - sy * cr, cy * sp * cr + sy * sr],
        [sy * cp, sy * sp * sr + cy * cr, sy * sp * cr - cy * sr],
        [-sp, cp * sr, cp * cr],
    ])


def ypr_from_rot(R: np.ndarray) -> tuple[float, float, float]:
    yaw = float(np.arctan2(R[1, 0], R[0, 0]))
    pitch = float(-np.arcsin(np.clip(R[2, 0], -1.0, 1.0)))
    roll = float(np.arctan2(R[2, 1], R[2, 2]))
    return yaw, pitch, roll


def wrap_angle(a: float) -> float:
    return float((a + np.pi) % (2.0 * np.pi) - np.pi)


def orthonormalize(R: np.ndarray) -> np.ndarray:
    U, _, Vt = np.linalg.svd(R)
    out = U @ Vt
    if np.linalg.det(out) < 0:
        U[:, -1] *= -1
        out = U @ Vt
    return out


def quat_from_rot(R: np.ndarray) -> np.ndarray:
    """Rotation matrix -> unit quaternion [w, x, y, z]."""
    tr = np.trace(R)
    if tr > 0:
        s = np.sqrt(tr + 1.0) * 2
        q = [0.25 * s, (R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s]
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        q = [(R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s]
    elif R[1, 1] > R[2, 2]:
        s = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        q = [(R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s]
    else:
        s = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        q = [(R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s]
    q = np.array(q)
    q /= np.linalg.norm(q)
    return q if q[0] >= 0 else -q


# --- autopilot boundary conversions -------------------------------------------------------------
R_NED_ENU = np.array([[0.0, 1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, -1.0]])
R_FRD_FLU = np.diag([1.0, -1.0, -1.0])


def enu_to_ned(v: np.ndarray) -> np.ndarray:
    """Vector in the ENU map frame -> NED (PX4 local frame convention).

    Note: our ``map`` x-axis is the building's long axis, which is treated as East.
    """
    return R_NED_ENU @ v


def rot_flu_enu_to_frd_ned(R_map_body: np.ndarray) -> np.ndarray:
    """Attitude R_enu_flu -> R_ned_frd for MAVLink attitude / odometry messages."""
    return R_NED_ENU @ R_map_body @ R_FRD_FLU


# --- camera mount ------------------------------------------------------------------------------
# Optical frame (z fwd, x right, y down) expressed in FLU body axes.
R_BODY_CAMOPT = np.array([[0.0, 0.0, 1.0], [-1.0, 0.0, 0.0], [0.0, -1.0, 0.0]])


def camera_mount(pitch_down_deg: float = 0.0) -> np.ndarray:
    """R_body_cam for a forward camera pitched down by ``pitch_down_deg`` degrees."""
    pitch = np.deg2rad(pitch_down_deg)
    # rotate about body y (left) by +pitch -> nose-down tilt of the optical axis
    c, s = np.cos(pitch), np.sin(pitch)
    Ry = np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])
    return Ry @ R_BODY_CAMOPT
