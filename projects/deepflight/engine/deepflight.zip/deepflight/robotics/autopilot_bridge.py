"""Autopilot boundary: maps DeepFlight estimates / setpoints to MAVLink message fields (PX4 / ArduPilot).

This module only *builds* message dictionaries (field names follow the MAVLink common message set).
Nothing is transmitted: hardware mode is locked until HIL validation and operator authorisation
exist (docs/engineering/SAFETY.md). Frame conversion happens here and nowhere else:
DeepFlight uses ENU / FLU internally; MAVLink local frames are NED / FRD.
"""
from __future__ import annotations

import numpy as np

from ..core.frames import R_NED_ENU, enu_to_ned, quat_from_rot, rot_flu_enu_to_frd_ned

MAV_FRAME_LOCAL_NED = 1
MAV_FRAME_BODY_FRD = 12
MAV_ESTIMATOR_TYPE_VIO = 3

# quality reported to the autopilot per integrity state (0 = invalid, 100 = best). PX4 EKF2 uses
# the covariance; quality lets the autopilot reject estimates the companion itself distrusts.
QUALITY = {"RELIABLE": 100, "DEGRADED": 60, "RECOVERING": 0, "UNCERTAIN": 0, "LOST": 0}


def odometry_message(t: float, p_enu: np.ndarray, v_enu: np.ndarray, R_enu_flu: np.ndarray,
                     cov_pos_enu: np.ndarray, integrity_state: str, reset_counter: int,
                     cov_vel_enu: np.ndarray | None = None, velocity_valid: bool = False) -> dict:
    """MAVLink ODOMETRY (#331). Position/velocity in LOCAL_NED; covariance rotated accordingly.

    Content follows what DeepFlight actually knows: full pose when localization is valid; velocity only
    (position/attitude NaN) when the global position is not established but visual velocity is
    (e.g. RECOVERING before relocalization); nothing at all when neither is trustworthy."""
    p = enu_to_ned(p_enu)
    v_body_frd = (rot_flu_enu_to_frd_ned(R_enu_flu).T @ enu_to_ned(v_enu))
    q = quat_from_rot(rot_flu_enu_to_frd_ned(R_enu_flu))
    C = R_NED_ENU @ cov_pos_enu @ R_NED_ENU.T
    pose_cov = [float("nan")] * 21
    # upper-triangular 6x6 (x, y, z, roll, pitch, yaw): fill position block, mark the rest unknown
    pose_cov[0], pose_cov[1], pose_cov[2] = C[0, 0], C[0, 1], C[0, 2]
    pose_cov[6], pose_cov[7] = C[1, 1], C[1, 2]
    pose_cov[11] = C[2, 2]
    vel_cov = [float("nan")] * 21
    if cov_vel_enu is not None:
        Rb = rot_flu_enu_to_frd_ned(R_enu_flu).T @ R_NED_ENU        # ENU -> body FRD
        Cb = Rb @ cov_vel_enu @ Rb.T
        vel_cov[0], vel_cov[1], vel_cov[2] = Cb[0, 0], Cb[0, 1], Cb[0, 2]
        vel_cov[6], vel_cov[7] = Cb[1, 1], Cb[1, 2]
        vel_cov[11] = Cb[2, 2]
    quality = QUALITY.get(integrity_state, 0)
    content = "pose+velocity" if quality > 0 else ("velocity" if velocity_valid else "none")
    if content == "velocity":
        nan = float("nan")
        p = np.full(3, nan)
        q = np.full(4, nan)
        pose_cov = [nan] * 21
        quality = 30
    return {
        "msg": "ODOMETRY", "time_usec": int(t * 1e6), "frame_id": MAV_FRAME_LOCAL_NED,
        "child_frame_id": MAV_FRAME_BODY_FRD, "x": p[0], "y": p[1], "z": p[2],
        "q": q.tolist(), "vx": v_body_frd[0], "vy": v_body_frd[1], "vz": v_body_frd[2],
        "pose_covariance": pose_cov, "velocity_covariance": vel_cov, "reset_counter": reset_counter,
        "estimator_type": MAV_ESTIMATOR_TYPE_VIO, "quality": quality,
        "content": content,
        "send": content != "none",   # nothing trustworthy -> withheld; the autopilot uses its own failsafe
    }


def velocity_setpoint_message(t: float, v_enu: np.ndarray | None, yaw_enu: float | None,
                              yaw_rate_enu: float = 0.0) -> dict:
    """SET_POSITION_TARGET_LOCAL_NED with velocity + yaw (position / acceleration ignored)."""
    v = enu_to_ned(np.zeros(3) if v_enu is None else np.asarray(v_enu, float))
    # ENU yaw (from +x east, CCW) -> NED yaw (from north, CW)
    yaw_ned = None if yaw_enu is None else float((np.pi / 2 - yaw_enu + np.pi) % (2 * np.pi) - np.pi)
    # POSITION_TARGET_TYPEMASK: ignore x,y,z (1|2|4) and ax,ay,az (64|128|256); then ignore either yaw
    # (1024) or yaw_rate (2048) depending on what is commanded
    type_mask = 1 | 2 | 4 | 64 | 128 | 256
    type_mask |= 1024 if yaw_ned is None else 2048
    return {"msg": "SET_POSITION_TARGET_LOCAL_NED", "time_boot_ms": int(t * 1000),
            "coordinate_frame": MAV_FRAME_LOCAL_NED, "type_mask": type_mask,
            "vx": v[0], "vy": v[1], "vz": v[2], "yaw": yaw_ned, "yaw_rate": -yaw_rate_enu}


def preview(sim) -> dict:
    e = sim.loc.eskf
    sp = sim.setpoint
    odo = odometry_message(sim.t, e.p, e.v, e.R, sim.loc.global_cov(), sim.integrity_state, sim.loc.segment)
    out = {"mode": "SIMULATION - messages are built for inspection only, not transmitted",
           "odometry": _round(odo)}
    if sp.mode in ("velocity", "position"):
        out["setpoint"] = _round(velocity_setpoint_message(sim.t, sp.velocity, sp.yaw, sp.yaw_rate))
    else:
        out["setpoint"] = {"msg": None, "note": f"autopilot-internal mode '{sp.mode}' (no companion setpoint)"}
    return out


def _round(d: dict) -> dict:
    out = {}
    for k, v in d.items():
        if isinstance(v, float):
            out[k] = None if np.isnan(v) else round(v, 4)
        elif isinstance(v, (list, np.ndarray)):
            out[k] = [None if (isinstance(x, float) and np.isnan(x)) else (round(float(x), 5)) for x in v]
        elif isinstance(v, np.floating):
            out[k] = round(float(v), 4)
        else:
            out[k] = v
    return out
