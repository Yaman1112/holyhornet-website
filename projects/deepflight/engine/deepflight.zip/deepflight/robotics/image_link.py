"""Client for tools/gz/df_image_bridge (Gazebo camera frames over TCP).

Frames arrive as (kind, width, height, stamp_s, seq, ndarray): kind 1 = gray8 image, kind 2 = float32 depth (m).
A background thread keeps only the newest frame of each kind (the estimator wants the latest view, not a queue).
"""
from __future__ import annotations

import socket
import struct
import threading
import time
from dataclasses import dataclass

import numpy as np

HEADER = struct.Struct("<4sB3xIIQII")


@dataclass
class ImageFrame:
    kind: int
    stamp: float          # simulation time (s)
    seq: int
    data: np.ndarray
    t_rx: float


class ImageLink:
    def __init__(self, host: str, port: int = 5600, timeout: float = 10.0):
        self.sock = socket.create_connection((host, port), timeout=timeout)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.sock.settimeout(None)
        self.latest: dict[int, ImageFrame] = {}
        self.counts = {1: 0, 2: 0}
        self._lock = threading.Lock()
        self._alive = True
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _recv_exact(self, n: int) -> bytes:
        buf = bytearray()
        while len(buf) < n:
            chunk = self.sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("image bridge closed the connection")
            buf += chunk
        return bytes(buf)

    def _run(self) -> None:
        try:
            while self._alive:
                magic, kind, w, h, stamp_ns, nbytes, seq = HEADER.unpack(self._recv_exact(HEADER.size))
                if magic != b"DFIM":
                    raise ConnectionError("bad frame magic")
                payload = self._recv_exact(nbytes)
                if kind == 1:
                    arr = np.frombuffer(payload, np.uint8).reshape(h, w)
                else:
                    arr = np.frombuffer(payload, np.float32).reshape(h, w)
                with self._lock:
                    self.latest[kind] = ImageFrame(kind, stamp_ns * 1e-9, seq, arr, time.monotonic())
                    self.counts[kind] = self.counts.get(kind, 0) + 1
        except (OSError, ConnectionError):
            self._alive = False

    def get(self, kind: int) -> ImageFrame | None:
        with self._lock:
            return self.latest.get(kind)

    @property
    def alive(self) -> bool:
        return self._alive

    def close(self) -> None:
        self._alive = False
        try:
            self.sock.close()
        except OSError:
            pass
