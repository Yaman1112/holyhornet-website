"""Flight recorder for PX4 + Gazebo camera runs: every estimator input, in the order the engine applied it.

Records the autopilot IMU samples with PX4 sample times, each rendered gray / depth frame with its Gazebo stamp
(images PNG-compressed, depth as float16), the front end's output, the synthetic flow / rangefinder / baro
samples, landed / take-off notifications, integrity evaluations and ground truth at every engine step.
``deepflight.research.replay`` feeds a recording back through a fresh ``LocalizationSystem`` so estimator
variants can be compared on identical data, offline and in seconds instead of a real-time flight.
"""
from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np


class FlightRecorder:
    def __init__(self, sim, vehicle, path: str | Path, keep_images: bool = True):
        self.sim, self.veh, self.path = sim, vehicle, Path(path)
        self.keep_images = keep_images
        self.events: list[tuple] = []
        self.gray: dict[int, bytes] = {}
        self.depth: dict[int, tuple[float, np.ndarray]] = {}
        self._wrap()

    # ------------------------------------------------------------------ hooks
    def _wrap(self) -> None:
        import cv2
        sim, veh, ev = self.sim, self.veh, self.events
        loc = sim.loc

        orig_pop = veh.pop_imu

        def pop_imu(t_engine):
            raw = [(float(t), np.array(a, float), np.array(g, float)) for t, a, g in veh.link.state.imu_queue]
            out = orig_pop(t_engine)
            ev.append(("imu_raw", t_engine, raw))
            return out
        veh.pop_imu = pop_imu

        orig_cam = veh.camera_frame

        def camera_frame(t_engine):
            g = veh.image_link.get(1)
            d = veh.image_link.get(2)
            frame = orig_cam(t_engine)
            if frame is not None:
                if self.keep_images and g.seq not in self.gray:
                    self.gray[g.seq] = cv2.imencode(".png", g.data)[1].tobytes()
                if d is not None and d.seq not in self.depth:
                    self.depth[d.seq] = (d.stamp, d.data.astype(np.float16))
                ev.append(("frame", t_engine, g.seq, g.stamp, None if d is None else d.seq,
                           None if d is None else d.stamp, frame, veh._imu_t_prev))
            return frame
        veh.camera_frame = camera_frame

        def wrap(name):
            f = getattr(loc, name)

            def g(*a, **k):
                ev.append(("loc", name, a, k))
                return f(*a, **k)
            setattr(loc, name, g)
        for name in ("on_imu", "on_camera", "on_flow", "on_rangefinder", "on_baro", "on_landed", "on_takeoff",
                     "evaluate", "operator_reinitialize"):
            wrap(name)

    def step(self) -> None:
        s = self.sim.quad.s
        self.events.append(("truth", self.sim.t, self.veh._imu_t_prev, s.p.copy(), s.R.copy(), s.v.copy(),
                            self.sim.loc.eskf.p.copy(), self.sim.loc.eskf.yaw()))

    def save(self) -> Path:
        sim = self.sim
        sc = sim.scenario
        meta = {"scenario": getattr(sc, "name", None), "seed": sim.seed,
                "cfg": sim.cfg, "p0": np.array(sc.start[:3], float) if hasattr(sc, "start") else None,
                "yaw0": getattr(sc, "start_yaw", 0.0),
                "intrinsics": (self.veh.frontend.fx, self.veh.frontend.fy, self.veh.frontend.cx, self.veh.frontend.cy)}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "wb") as fh:
            pickle.dump({"meta": meta, "events": self.events, "gray": self.gray, "depth": self.depth}, fh,
                        protocol=pickle.HIGHEST_PROTOCOL)
        return self.path
