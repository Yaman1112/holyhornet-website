"""MAVLink link to a PX4 SITL instance (pymavlink).

Responsibilities: connection + heartbeat, parameter setup for GNSS-denied external-vision flight,
offboard arming, sending ODOMETRY / velocity / attitude setpoints, and decoding PX4 ground truth
(``HIL_STATE_QUATERNION``, published from the simulator's ground-truth topics) and PX4's own EKF2
output (``LOCAL_POSITION_NED``) for validation.

Nothing here runs against hardware: ``Px4Link`` refuses non-loopback / non-private endpoints unless
``allow_remote`` is set, and the platform's hardware mode stays locked (docs/engineering/SAFETY.md).
"""
from __future__ import annotations

import ipaddress
import os

os.environ.setdefault("MAVLINK20", "1")   # ODOMETRY etc. are MAVLink 2 messages; must precede pymavlink import
import math
import time
from dataclasses import dataclass, field

import numpy as np

try:
    from pymavlink import mavutil
except ImportError:  # pragma: no cover - optional dependency
    mavutil = None

PX4_CUSTOM_MAIN_MODE_OFFBOARD = 6
MAV_MODE_FLAG_CUSTOM_MODE_ENABLED = 1
MAV_FRAME_LOCAL_NED = 1
MAV_FRAME_BODY_FRD = 12

# Parameters for GNSS-denied flight on DeepFlight external vision (PX4 v1.15 names).
SITL_PARAMS: dict[str, float] = {
    "EKF2_GPS_CTRL": 0,       # never fuse GNSS
    "EKF2_EV_CTRL": 15,       # fuse external-vision horizontal pos, vertical pos, velocity and yaw
    "EKF2_MAG_TYPE": 5,       # no magnetometer fusion indoors (heading from vision, as DeepFlight itself does)
    "EKF2_HGT_REF": 1,        # baro height reference: altitude stays valid if vision is withheld
    "EKF2_EV_DELAY": 40.0,    # ms: truth stream + companion loop latency (measured ~30-50 ms)
    "EKF2_EVP_NOISE": 0.1,    # PX4 default vision noise floors (m, m/s); DeepFlight covariance applies above them
    "EKF2_EVV_NOISE": 0.1,    # FLOAT params are given as Python floats, INT32 as ints
    "COM_RC_IN_MODE": 4,      # no RC in simulation
    "COM_RCL_EXCEPT": 4,      # do not failsafe on RC loss in offboard
    "NAV_RCL_ACT": 0,
    "NAV_DLL_ACT": 0,
    "COM_OF_LOSS_T": 1.0,     # offboard signal loss timeout (s)
    "COM_DISARM_LAND": 2.0,
}


# SIH only: its IMU model adds accel noise sigma (0.5, 1.7, 1.4) m/s^2 and gyro (0.14, 0.07, 0.03) rad/s
# (src/modules/simulation/simulator_sih/sih.cpp). EKF2's defaults (0.35, 0.015) are for real IMUs, so with SIH
# its innovations are inconsistent and the preflight velocity test fails. Match the estimator to the sensor.
SIH_IMU_PARAMS: dict[str, float] = {
    "EKF2_ACC_NOISE": 1.2,
    "EKF2_GYR_NOISE": 0.1,
}


@dataclass
class Px4Truth:
    t_wall: float
    lat: float
    lon: float
    alt: float               # m AMSL
    q: np.ndarray            # [w, x, y, z] NED/FRD
    v_ned: np.ndarray        # m/s
    omega_frd: np.ndarray    # rad/s
    t_px4: float = 0.0       # PX4 time of the sample (s) - use this, not arrival time, for derivatives


@dataclass
class Px4State:
    connected: bool = False
    armed: bool = False
    custom_main_mode: int = 0
    landed_state: int = 0            # MAV_LANDED_STATE: 1 on ground, 2 in air, 3 takeoff, 4 landing
    prearm_ok: bool | None = None    # SYS_STATUS MAV_SYS_STATUS_PREARM_CHECK health bit (None = not reported)
    imu_queue: list = field(default_factory=list)   # (t_px4 s, acc_frd, gyro_frd) from HIGHRES_IMU
    vel_horiz_valid: bool = False    # ESTIMATOR_STATUS ESTIMATOR_VELOCITY_HORIZ (PX4 can fly velocity setpoints)
    vel_valid_t: float = 0.0
    truth: Px4Truth | None = None
    ekf_local_ned: np.ndarray | None = None
    statustexts: list = field(default_factory=list)
    params: dict = field(default_factory=dict)
    last_rx: float = 0.0

    @property
    def offboard(self) -> bool:
        return self.custom_main_mode == PX4_CUSTOM_MAIN_MODE_OFFBOARD


def _check_endpoint(url: str, allow_remote: bool) -> None:
    host = url.split(":")[1] if ":" in url else ""
    if allow_remote or host in ("", "0.0.0.0", "localhost"):
        return
    ip = ipaddress.ip_address(host)
    if not (ip.is_loopback or ip.is_private):
        raise ValueError(f"refusing non-local MAVLink endpoint {url} (simulation only)")


class Px4Link:
    def __init__(self, url: str = "udpin:0.0.0.0:14540", *, allow_remote: bool = False, conn=None,
                 local_port: int | None = 14541):
        """For ``udpout`` URLs the local socket is bound to ``local_port``: PX4 answers the first address that
        talks to it, so a fixed source port keeps working across DeepFlight restarts."""
        if conn is None:
            if mavutil is None:
                raise RuntimeError("pymavlink is not installed")
            _check_endpoint(url, allow_remote)
            conn = mavutil.mavlink_connection(url, source_system=245, source_component=191, dialect="common")
            if url.startswith("udpout:") and local_port:
                conn.port.bind(("0.0.0.0", local_port))
        self.conn = conn
        self.mav = conn.mav
        self.state = Px4State()
        self.target_system = 1
        self.target_component = 1
        self._boot = time.monotonic()

    # ------------------------------------------------------------------ receive
    def poll(self, max_msgs: int = 200) -> None:
        for _ in range(max_msgs):
            msg = self.conn.recv_match(blocking=False)
            if msg is None:
                break
            self._handle(msg)

    def _handle(self, msg) -> None:
        st = self.state
        typ = msg.get_type()
        if typ == "BAD_DATA":
            return
        st.last_rx = time.monotonic()
        if typ == "HEARTBEAT" and msg.get_srcComponent() == 1:
            st.connected = True
            self.target_system = msg.get_srcSystem()
            st.armed = bool(msg.base_mode & 128)
            st.custom_main_mode = (msg.custom_mode >> 16) & 0xFF
        elif typ == "HIL_STATE_QUATERNION":
            st.truth = Px4Truth(time.monotonic(), msg.lat * 1e-7, msg.lon * 1e-7, msg.alt * 1e-3,
                                np.array(msg.attitude_quaternion, float),
                                np.array([msg.vx, msg.vy, msg.vz], float) * 0.01,
                                np.array([msg.rollspeed, msg.pitchspeed, msg.yawspeed], float),
                                msg.time_usec * 1e-6)
        elif typ == "LOCAL_POSITION_NED":
            st.ekf_local_ned = np.array([msg.x, msg.y, msg.z, msg.vx, msg.vy, msg.vz], float)
        elif typ == "SYS_STATUS":
            # PX4 v1.15 sets only the *health* bit (not "present") for MAV_SYS_STATUS_PREARM_CHECK
            st.prearm_ok = bool(msg.onboard_control_sensors_health & (1 << 28))
        elif typ == "HIGHRES_IMU":
            st.imu_queue.append((msg.time_usec * 1e-6, np.array([msg.xacc, msg.yacc, msg.zacc], float),
                                 np.array([msg.xgyro, msg.ygyro, msg.zgyro], float)))
            del st.imu_queue[:-2000]
        elif typ == "ESTIMATOR_STATUS":
            st.vel_horiz_valid = bool(msg.flags & 2)          # ESTIMATOR_VELOCITY_HORIZ
            st.vel_valid_t = time.monotonic()
        elif typ == "EXTENDED_SYS_STATE":
            st.landed_state = msg.landed_state
        elif typ == "STATUSTEXT":
            st.statustexts.append(msg.text)
            del st.statustexts[:-50]
        elif typ == "PARAM_VALUE":
            st.params[msg.param_id] = msg.param_value

    def wait_connected(self, timeout: float = 30.0) -> bool:
        t0 = time.monotonic()
        while time.monotonic() - t0 < timeout:
            self.send_heartbeat()
            self.poll()
            if self.state.connected:
                return True
            time.sleep(0.1)
        return False

    # ------------------------------------------------------------------ send
    def _ms(self) -> int:
        return int((time.monotonic() - self._boot) * 1000)

    def send_heartbeat(self) -> None:
        self.mav.heartbeat_send(mavutil.mavlink.MAV_TYPE_ONBOARD_CONTROLLER if mavutil else 18,
                                8, 0, 0, 4)   # MAV_AUTOPILOT_INVALID, state ACTIVE

    def command(self, cmd: int, *params: float) -> None:
        p = list(params) + [0.0] * (7 - len(params))
        self.mav.command_long_send(self.target_system, self.target_component, cmd, 0, *p)

    def set_message_interval(self, msg_id: int, hz: float) -> None:
        self.command(511, msg_id, 1e6 / hz)          # MAV_CMD_SET_MESSAGE_INTERVAL

    def request_streams(self) -> None:
        self.set_message_interval(115, 50)           # HIL_STATE_QUATERNION (ground truth)
        self.set_message_interval(32, 30)            # LOCAL_POSITION_NED (PX4 EKF2)
        self.set_message_interval(245, 5)            # EXTENDED_SYS_STATE
        self.set_message_interval(1, 2)              # SYS_STATUS (pre-arm health)
        self.set_message_interval(230, 20)           # ESTIMATOR_STATUS (velocity validity)
        self.set_message_interval(105, 200)          # HIGHRES_IMU (autopilot IMU for the companion estimator)

    def set_param(self, name: str, value: int | float) -> None:
        """Python int -> MAV_PARAM_TYPE_INT32 (PX4 bytewise encoding), float -> REAL32."""
        import struct
        if isinstance(value, int) and not isinstance(value, bool):
            fval, ptype = struct.unpack("<f", struct.pack("<i", value))[0], 6
        else:
            fval, ptype = float(value), 9
        self.mav.param_set_send(self.target_system, self.target_component, name.encode(), fval, ptype)

    def configure(self, params: dict | None = None, settle_s: float = 1.0) -> None:
        for k, v in (params or SITL_PARAMS).items():
            self.set_param(k, v)
            time.sleep(0.02)
        t0 = time.monotonic()
        while time.monotonic() - t0 < settle_s:
            self.poll()
            time.sleep(0.05)

    def set_offboard(self) -> None:
        self.command(176, MAV_MODE_FLAG_CUSTOM_MODE_ENABLED, PX4_CUSTOM_MAIN_MODE_OFFBOARD)  # DO_SET_MODE

    def arm(self, arm: bool = True) -> None:
        self.command(400, 1.0 if arm else 0.0)       # COMPONENT_ARM_DISARM

    def send_odometry(self, msg: dict) -> None:
        cov = [v if v is not None else float("nan") for v in msg["pose_covariance"]]
        vcov = [v if v is not None else float("nan") for v in msg.get("velocity_covariance", [None] * 21)]
        self.mav.odometry_send(msg["time_usec"], msg["frame_id"], msg["child_frame_id"],
                               msg["x"], msg["y"], msg["z"], [float(v) for v in msg["q"]],
                               msg["vx"], msg["vy"], msg["vz"], float("nan"), float("nan"), float("nan"),
                               cov, vcov, msg["reset_counter"], msg["estimator_type"], msg["quality"])

    def send_velocity_setpoint(self, msg: dict) -> None:
        yaw = msg["yaw"] if msg["yaw"] is not None else 0.0
        self.mav.set_position_target_local_ned_send(self._ms(), self.target_system, self.target_component,
                                                    MAV_FRAME_LOCAL_NED, msg["type_mask"], 0, 0, 0,
                                                    msg["vx"], msg["vy"], msg["vz"], 0, 0, 0,
                                                    yaw, msg["yaw_rate"])

    def send_attitude_target(self, q_ned: np.ndarray, thrust: float, yaw_rate_frd: float = 0.0) -> None:
        """Attitude + normalised collective thrust (0..1). Body roll/pitch rates ignored (mask 0b11)."""
        self.mav.set_attitude_target_send(self._ms(), self.target_system, self.target_component, 0b00000011,
                                          [float(v) for v in q_ned], 0.0, 0.0, yaw_rate_frd,
                                          float(np.clip(thrust, 0.0, 1.0)))


# ---------------------------------------------------------------------- geodesy helpers
EARTH_R = 6378137.0


def geodetic_to_enu(lat: float, lon: float, alt: float, lat0: float, lon0: float, alt0: float) -> np.ndarray:
    """Small-area equirectangular projection (adequate for a building-sized local frame)."""
    d_lat = math.radians(lat - lat0)
    d_lon = math.radians(lon - lon0)
    east = d_lon * EARTH_R * math.cos(math.radians(lat0))
    north = d_lat * EARTH_R
    return np.array([east, north, alt - alt0])
