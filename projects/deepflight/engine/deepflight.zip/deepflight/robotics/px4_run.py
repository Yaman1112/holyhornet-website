"""Fly a DeepFlight scenario with PX4 SITL in the loop (real time).

    # terminal 1 (WSL):  cd ~/PX4-Autopilot && HEADLESS=1 make px4_sitl sihsim_quadx
    # terminal 2 (WSL):  python3 -m deepflight.robotics.px4_run --scenario M1 --seed 5001

Writes research/reports/px4_sitl/<scenario>_<seed>.{json,md}: DeepFlight metrics plus bridge statistics,
PX4 EKF2-vs-DeepFlight agreement and PX4 status texts.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np

from .. import SOFTWARE_VERSION
from ..engine import DeepFlightSim
from ..research.metrics import compute_metrics, map_accuracy
from ..simulation.vehicles import Px4Vehicle
from .px4_link import SIH_IMU_PARAMS, SITL_PARAMS, Px4Link

ROOT = Path(__file__).resolve().parents[3]


def make_factory(link: Px4Link, holder: dict, autopilot_imu: bool = False, image_link=None):
    def factory(cfg, start, yaw, rng, log):
        frontend = None
        if image_link is not None:
            from ..perception.image_frontend import FrontEndConfig, ImageFrontEnd
            cc = cfg.sensors.camera
            frontend = ImageFrontEnd(cc.fx, cc.fy, cc.width / 2, cc.height / 2,
                                     FrontEndConfig(max_features=cc.max_features))
        v = Px4Vehicle(link, cfg.aircraft, start, yaw, log=log, autopilot_imu=autopilot_imu,
                       image_link=image_link, frontend=frontend)
        if not v.wait_ready(20.0):
            raise RuntimeError("no ground truth (HIL_STATE_QUATERNION) from PX4 - is SITL running?")
        hover = link.state.params.get("MPC_THR_HOVER")
        if hover:
            v.hover_thrust = float(hover)
        holder["vehicle"] = v
        return v
    return factory


def resolve_url(url: str, distro: str = "Ubuntu-22.04") -> str:
    """``wsl`` -> udpout to the WSL2 VM's address (its IP changes on every boot). PX4's onboard MAVLink
    instance listens on 14580 and answers the sender, so no firewall or WSL network changes are needed."""
    if url != "wsl":
        return url
    import subprocess
    ip = subprocess.run(["wsl.exe", "-d", distro, "hostname", "-I"], capture_output=True, timeout=20)
    addr = ip.stdout.decode("utf-8", "ignore").replace("\x00", "").split()[0]
    return f"udpout:{addr}:14580"


def connect(url: str, sim: str = "sih") -> Px4Link:
    link = Px4Link(resolve_url(url))
    if not link.wait_connected(60.0):
        raise RuntimeError(f"no PX4 heartbeat on {url}")
    params = dict(SITL_PARAMS) | (SIH_IMU_PARAMS if sim == "sih" else {})
    link.configure(params, settle_s=1.0)
    link.request_streams()
    t0 = time.monotonic()
    while time.monotonic() - t0 < 5.0 and "MPC_THR_HOVER" not in link.state.params:
        if int((time.monotonic() - t0) * 2) % 2 == 0:
            link.mav.param_request_read_send(link.target_system, link.target_component, b"MPC_THR_HOVER", -1)
        link.poll()
        time.sleep(0.1)
    if "MPC_THR_HOVER" not in link.state.params:
        print("warning: MPC_THR_HOVER not received; attitude fallback starts from 0.5 and adapts via its integrator")
    return link


def gz_light_hook(distro: str = "Ubuntu-22.04"):
    """Mirror DeepFlight lighting events into the rendered Gazebo world (east-wing light circuit)."""
    import subprocess

    def hook(zone: str, level: float) -> None:
        if zone != "corridor east circuit":
            return
        arg = "off" if level < 0.05 else f"{level:.2f}"
        subprocess.Popen(["wsl.exe", "-d", distro, "-u", "root", "--", "bash", "-lc", f"bash /root/gz_lights.sh {arg}"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return hook


X500_REST_HEIGHT_M = 0.22


def run(scenario: str, seed: int, url: str, duration: float | None, out_dir: Path, physics: str = "sih",
        trace: tuple | None = None, camera: bool = False, record: str | None = None) -> dict:
    link = connect(url, physics)
    image_link = None
    if camera:
        from .image_link import ImageLink
        image_link = ImageLink(resolve_url(url).split(":")[1] if url == "wsl" else "127.0.0.1", 5600)
    holder: dict = {}
    # rendered camera: the real image front end drifts more than the simulator's track oracle. Drift bound
    # calibrated on seeds 7001-7003 (A goal errors, RMS 0.88 m over ~39 m -> 0.016 per metre, 1 sigma per axis);
    # validated on fresh seeds (7101+).
    overrides = {"sensors": {"camera": {"lever_arm_m": [0.12, 0.0, -0.06]}},
                 # flow is synthetic here and, fused next to VIO, corrupted roll/heading (replay of A 7003);
                 # it stays the fallback velocity source for visual outages
                 "estimator": {"vio_drift_rate": 0.016, "flow_fallback_only": True}} if camera else None
    sim = DeepFlightSim(scenario, seed, overrides, vehicle_factory=make_factory(link, holder, autopilot_imu=physics == "gz",
                                                                     image_link=image_link),
                        wallclock_monitors=True,
                        # Gazebo x500 stands on its landing gear with base_link 0.22 m above the floor (measured: the
                        # rendered depth matched the building only after +0.10 m on the 0.12 m default)
                        rest_height_m=X500_REST_HEIGHT_M if physics == "gz" else None)
    if camera:
        sim.environment_hook = gz_light_hook()
    veh: Px4Vehicle = holder["vehicle"]
    recorder = None
    if record:
        from .flight_recorder import FlightRecorder
        recorder = FlightRecorder(sim, veh, record)
    T = duration or sim.scenario.duration_s
    t0 = time.monotonic()
    ekf_err, late = [], 0
    next_print = 0.0
    while sim.t < T and not sim.finished:
        sim.step()
        if recorder is not None:
            recorder.step()
        lag = sim.t - (time.monotonic() - t0)
        if lag > 0:
            time.sleep(lag)
        elif lag < -0.05:
            late += 1
        if veh.ekf_error is not None and sim.integrity_state in ("RELIABLE", "DEGRADED") and not sim.quad.s.landed:
            ekf_err.append(float(np.linalg.norm(veh.ekf_error[:2])))
        if trace and trace[0] <= sim.t <= trace[1] and sim.k % 50 == 0:
            sp = sim.setpoint
            print(f"  trace t={sim.t:6.2f} beh={sim.behaviour:15s} sp={sp.mode:8s} "
                  f"truth_p={np.round(sim.quad.s.p, 2).tolist()} est_p={np.round(sim.loc.eskf.p, 2).tolist()} "
                  f"truth_v={np.round(sim.quad.s.v, 2).tolist()} est_v={np.round(sim.loc.eskf.v, 2).tolist()} "
                  f"acc_cmd={None if sp.accel is None else np.round(sp.accel, 2).tolist()} "
                  f"v_cmd={None if sp.velocity is None else np.round(sp.velocity, 2).tolist()} "
                  f"prox_min={sim.prox.min():.2f} odom={veh._odom_content}", flush=True)
        if sim.t >= next_print:
            next_print += 5.0
            print(f"t={sim.t:6.1f} mode={sim.mode:9s} beh={sim.behaviour:15s} loc={sim.integrity_state:10s} "
                  f"px4 armed={link.state.armed} offb={link.state.offboard} "
                  f"err={np.linalg.norm(sim.quad.s.p - sim.loc.eskf.p):.2f} "
                  f"dxyz={np.round(sim.quad.s.p - sim.loc.eskf.p, 2).tolist()} truth={np.round(sim.quad.s.p, 1).tolist()} "
                  f"vio={sim.loc.vio.quality.status}/{sim.loc.vio.quality.inliers}/{sim.loc.vio.quality.detected} "
                  f"odom={veh.stats['odom_sent']}/{veh.stats['odom_withheld']}", flush=True)
    m = compute_metrics(sim) | map_accuracy(sim)
    res = {
        "software_version": SOFTWARE_VERSION, "backend": f"PX4 SITL ({physics})", "url": url, "scenario": scenario,
        "seed": seed, "physics": {"sih": "PX4 SIH", "gz": "Gazebo gz-sim 7 (deepflight_building world)"}[physics],
        "camera": "rendered (Gazebo) + OpenCV front end" if camera else "synthetic tracks",
        "wall_time_s": round(time.monotonic() - t0, 1), "late_steps": late, "metrics": m,
        "bridge": veh.status(),
        "px4_ekf2_vs_deepflight_xy_m": None if not ekf_err else
        {"mean": round(float(np.mean(ekf_err)), 3), "p95": round(float(np.percentile(ekf_err, 95)), 3)},
        "events": [e for e in sim.events if e["category"] in ("integrity", "mission", "relocalization", "safety", "planning",
                                                             "vehicle", "environment", "operator")],
        "place_diag": getattr(sim.loc, "place_diag", []),
        "note": "PX4 flight stack + SIH/Gazebo physics; DeepFlight building and sensor models; not flight data.",
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f"{scenario}_{seed}{'_gz' if physics == 'gz' else ''}{'_cam' if camera else ''}.json").write_text(json.dumps(res, indent=2, default=str))
    if recorder is not None:
        print("recording:", recorder.save())
    return res


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", default="A")
    ap.add_argument("--seed", type=int, default=5001)
    ap.add_argument("--url", default="udpin:0.0.0.0:14540")
    ap.add_argument("--duration", type=float, default=None)
    ap.add_argument("--sim", choices=["sih", "gz"], default="sih", help="PX4 physics backend running in WSL")
    ap.add_argument("--record", default=None, help="write a flight recording (estimator inputs) to this file")
    ap.add_argument("--trace", default=None, help="t0,t1: print state twice a second in this window")
    ap.add_argument("--camera", action="store_true", help="use the rendered Gazebo camera (tools/px4_gz_cam_start.sh)")
    ap.add_argument("--out", default=str(ROOT / "research" / "reports" / "px4_sitl"))
    a = ap.parse_args()
    res = run(a.scenario, a.seed, a.url, a.duration, Path(a.out), a.sim,
              tuple(float(x) for x in a.trace.split(",")) if a.trace else None, a.camera, a.record)
    m = res["metrics"]
    print(json.dumps({k: m.get(k) for k in ("mission_complete", "collisions", "ate_rmse_m", "lost_events", "recoveries",
                                            "goals_reached", "nees_xy_mean_valid")}, indent=1))
    print("bridge:", json.dumps(res["bridge"]), "\nEKF2 vs DeepFlight:", res["px4_ekf2_vs_deepflight_xy_m"])


if __name__ == "__main__":
    main()
