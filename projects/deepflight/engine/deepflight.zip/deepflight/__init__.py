"""HolyHornet DeepFlight AI - GNSS-independent autonomous navigation research platform.

Simulation-first research software. Not certified avionics or collision-avoidance equipment.
"""
import os

# Small dense matrices dominate the estimator; multi-threaded BLAS only adds overhead and makes
# concurrent sessions contend for cores (measured 50x slow-downs in a sibling project).
for _var in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ.setdefault(_var, "1")

__version__ = "0.1.0"
SOFTWARE_VERSION = f"deepflight-{__version__}"
