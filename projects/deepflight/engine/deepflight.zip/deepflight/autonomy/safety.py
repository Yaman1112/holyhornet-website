"""Fault management and safety supervision.

The supervisor converts localization integrity, sensor health, battery, compute load and link state
into a *movement authority* (speed scale + allowed behaviours). It never commands return-to-home
unless localization is RELIABLE, and never lets the planner act on an invalid position.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..config import SafetyConfig

# Fault catalogue: detection method, threshold, severity, response, notification, recovery condition.
FAULT_CATALOG: dict[str, dict] = {
    "CAMERA_FAIL": dict(
        name="Camera failure", detection="no camera frames (health monitor age > 10 periods / 0.5 s)",
        threshold="0.5 s without frames", severity="major",
        response="VIO unavailable -> integrity degrades on sigma growth; reduce speed, hold if UNCERTAIN",
        notification="operator alert", recovery="frames resume and VIO re-acquires / relocalizes"),
    "CAMERA_STALE": dict(
        name="Camera frozen / timestamp fault", detection="repeated or non-increasing frame timestamps",
        threshold=">= 3 periods of repeated stamps", severity="major",
        response="frames rejected before fusion; same as camera failure", notification="operator alert",
        recovery="monotonic timestamps resume"),
    "VISUAL_DEGRADED": dict(
        name="Visual tracking degraded", detection="VIO inliers below weak threshold / low light / blur",
        threshold=f"inliers < 25 (weak), < 12 (lost) for 0.5 s", severity="minor",
        response="reduce speed to 50 %", notification="status indicator", recovery="inliers >= 25 for 1.5 s"),
    "IMU_DEGRADED": dict(
        name="IMU degradation", detection="no samples, or visual innovation NIS inconsistent with IMU prediction",
        threshold="NIS/dof EMA > 6", severity="critical", response="hold; land if not recovered",
        notification="operator alert", recovery="consistent innovations for 1.5 s"),
    "FLOW_DEGRADED": dict(
        name="Optical flow degraded", detection="flow quality (surface light/texture) < 0.2",
        threshold="quality < 0.2", severity="minor", response="velocity aiding unavailable (no action alone)",
        notification="status indicator", recovery="quality > 0.35"),
    "RANGEFINDER_FAIL": dict(
        name="Rangefinder failure", detection="no samples", threshold="0.5 s", severity="minor",
        response="altitude from barometer only (larger vertical margin)", notification="status indicator",
        recovery="samples resume"),
    "BARO_FAIL": dict(
        name="Barometer failure", detection="no samples / gated jumps", threshold="0.5 s", severity="minor",
        response="altitude from rangefinder", notification="status indicator", recovery="samples resume"),
    "LIDAR_FAIL": dict(
        name="LiDAR failure", detection="no scans", threshold="0.5 s", severity="major",
        response="LiDAR aiding removed from fusion", notification="operator alert", recovery="scans resume"),
    "GNSS_DENIED": dict(
        name="GNSS unavailable", detection="receiver reports no fix", threshold="no fix", severity="info",
        response="none - GNSS-independent navigation is the design baseline", notification="status indicator",
        recovery="n/a"),
    "LOC_DEGRADED": dict(
        name="Localization degraded", detection="integrity monitor", threshold="sigma_h >= 0.25 m or weak tracking",
        severity="minor", response="reduce movement authority (50 % speed), larger planning margins",
        notification="status indicator", recovery="RELIABLE for 1.5 s"),
    "LOC_UNCERTAIN": dict(
        name="Localization uncertain", detection="integrity monitor", threshold="sigma_h >= 0.6 m or no aiding 2 s",
        severity="major", response="hold (velocity hold on inertial/flow estimate, altitude on rangefinder)",
        notification="operator alert", recovery="RECOVERING -> RELIABLE"),
    "LOC_LOST": dict(
        name="Localization lost", detection="integrity monitor", threshold="sigma_h >= 1.5 m or no aiding 8 s",
        severity="critical",
        response="hold with depth-based repulsion; NO return-to-home; request operator after 10 s",
        notification="operator intervention request", recovery="relocalization against keyframe map or operator decision"),
    "MAP_INCONSISTENT": dict(
        name="Map inconsistency", detection="fraction of depth hits landing in confidently-free voxels",
        threshold="EMA > 0.25", severity="minor",
        response="flag (localization error, dynamic object or map change); pause map insertion if integrity not RELIABLE",
        notification="status indicator", recovery="ratio < 0.15"),
    "OBSTACLE_PROXIMITY": dict(
        name="Obstacle proximity", detection="raw depth returns inside the reactive envelope",
        threshold="< 0.55 m in direction of travel", severity="major", response="brake, replan",
        notification="event log", recovery="clearance restored"),
    "BATTERY_LOW": dict(
        name="Battery low", detection="energy model", threshold="< 25 %", severity="major",
        response="abort mission; return home only if localization RELIABLE, else land", notification="operator alert",
        recovery="n/a"),
    "BATTERY_CRITICAL": dict(
        name="Battery critical", detection="energy model", threshold="< 12 %", severity="critical",
        response="land in place", notification="operator alert", recovery="n/a"),
    "COMPUTE_OVERLOAD": dict(
        name="Companion computer overload", detection="processing time per 10 Hz cycle",
        threshold="> budget for 2 s", severity="minor", response="reduce speed to 50 %",
        notification="status indicator", recovery="within budget for 2 s"),
    "LINK_LOSS": dict(
        name="Telemetry link loss", detection="operator heartbeat timeout (simulated)", threshold="5 s",
        severity="major", response="continue only if RELIABLE, otherwise hold; land after 60 s",
        notification="logged; shown on reconnect", recovery="heartbeat resumes"),
}


@dataclass
class Authority:
    behaviour: str = "NOMINAL"      # NOMINAL | REDUCED | HOLD | RECOVERY_SEARCH | OPERATOR_WAIT | LAND
    speed_scale: float = 1.0
    allow_rth: bool = True
    allow_planning: bool = True
    velocity_aided: bool = True
    reasons: list = field(default_factory=list)


class SafetySupervisor:
    def __init__(self, cfg: SafetyConfig):
        self.cfg = cfg
        self.active: dict[str, float] = {}     # fault id -> time raised
        self.authority = Authority()
        self.lost_since: float | None = None
        self.overload_since: float | None = None

    RAISE_DWELL_S = 0.3      # condition must persist before a non-critical fault is raised ...
    CLEAR_DWELL_S = 1.0      # ... and be absent this long before it is cleared (prevents log flapping)

    def update_faults(self, t: float, detected: set[str]) -> tuple[list[str], list[str]]:
        if not hasattr(self, "_seen"):
            self._seen: dict[str, float] = {}
            self._gone: dict[str, float] = {}
        raised, cleared = [], []
        for f in detected:
            self._gone.pop(f, None)
            if f in self.active:
                continue
            first = self._seen.setdefault(f, t)
            critical = FAULT_CATALOG[f]["severity"] == "critical"
            if critical or t - first >= self.RAISE_DWELL_S - 1e-9:
                self.active[f] = t
                raised.append(f)
                self._seen.pop(f, None)
        for f in list(self._seen):
            if f not in detected:
                self._seen.pop(f)
        for f in list(self.active):
            if f in detected:
                continue
            gone = self._gone.setdefault(f, t)
            if t - gone >= self.CLEAR_DWELL_S - 1e-9:
                del self.active[f]
                self._gone.pop(f, None)
                cleared.append(f)
        return raised, cleared

    def decide(self, t: float, integrity_state: str, operator_required: bool, battery_pct: float,
               link_ok: bool, velocity_aided: bool = True, visual_tracking_ok: bool = False) -> Authority:
        c = self.cfg
        a = Authority()
        a.velocity_aided = velocity_aided
        if integrity_state == "DEGRADED":
            a.behaviour, a.speed_scale = "REDUCED", c.degraded_speed_scale
            a.reasons.append("localization degraded: movement authority reduced")
        if "COMPUTE_OVERLOAD" in self.active:
            a.behaviour, a.speed_scale = "REDUCED", min(a.speed_scale, 0.5)
            a.reasons.append("compute overload")
        if not velocity_aided:
            a.behaviour, a.speed_scale = "HOLD", 0.0
            a.reasons.append("no velocity aiding (vision and optical flow unavailable): altitude-hold fallback")
        if integrity_state == "UNCERTAIN":
            if c.uncertain_response == "continue_slow" or (visual_tracking_ok and velocity_aided):
                # uncertain only through accumulated drift while relative navigation is healthy: holding would
                # never reduce the uncertainty, so continue slowly (collision margins use map-relative sigma)
                a.behaviour, a.speed_scale = "REDUCED", 0.25
                a.reasons.append("localization uncertain from accumulated drift; visual tracking healthy: 25 % speed")
            else:
                a.behaviour, a.speed_scale = "HOLD", 0.0
                a.reasons.append("localization uncertain: holding")
        if integrity_state == "RECOVERING":
            a.behaviour, a.speed_scale = "RECOVERY_SEARCH", 0.0
            a.reasons.append("relocalizing: hold and sweep camera over previously mapped areas")
        if integrity_state == "LOST":
            if self.lost_since is None:
                self.lost_since = t
            a.behaviour, a.speed_scale = "HOLD", 0.0
            a.reasons.append("localization lost: hold, no return-to-home")
            if c.lost_response == "land_in_place":
                a.behaviour = "LAND"
            elif operator_required or t - self.lost_since > 10.0:
                a.behaviour = "OPERATOR_WAIT"
                a.reasons.append("operator intervention requested")
        else:
            self.lost_since = None
        if not link_ok and integrity_state != "RELIABLE" and a.behaviour == "NOMINAL":
            a.behaviour, a.speed_scale = "HOLD", 0.0
            a.reasons.append("link lost while not RELIABLE")
        if battery_pct < c.critical_battery_pct:
            a.behaviour = "LAND"
            a.reasons.append("battery critical: land in place")
        a.allow_rth = integrity_state == "RELIABLE"
        a.allow_planning = integrity_state in ("RELIABLE", "DEGRADED")
        self.authority = a
        return a

    def active_list(self) -> list[dict]:
        return [{"id": f, "since": round(t0, 2), **{k: FAULT_CATALOG[f][k] for k in ("name", "severity", "response")}}
                for f, t0 in self.active.items()]
