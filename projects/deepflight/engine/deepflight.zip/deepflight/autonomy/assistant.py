"""Grounded research assistant.

Answers operator / researcher questions strictly from the live session state and its event log.
Every answer lists its evidence (values + timestamps). It never invents telemetry and never claims to
have executed anything - it is read-only.
"""
from __future__ import annotations

import re

import numpy as np

INTENTS = [
    ("confidence", r"\b(confiden|uncertain|sure|accura|sigma|covariance|trust)"),
    ("position", r"\b(where|position|located|localized|localised|location)\b"),
    ("sensors", r"\b(sensor|unreliable|health|fail|camera|imu|flow|baro|lidar|gnss|gps)"),
    ("why_degraded", r"\b(why).*(degrad|lost|uncertain|hold|recover|stop)"),
    ("obstacles", r"\b(obstacle|wall|clearance|collision|close|near)"),
    ("route", r"\b(route|path|plan).*(clearance|safe|wide)|greatest clearance"),
    ("revisit", r"\b(revisit|visited|loop|place recognition|relocali)"),
    ("replan", r"\b(replan|re-plan|why.*(route|plan|path)|changed (route|path))"),
    ("mission", r"\b(mission|goal|target|doing|mode|status|battery)"),
]


def _fmt(v, n=2):
    return f"{v:.{n}f}"


def answer(sim, question: str) -> dict:
    q = question.lower().strip()
    intent = None
    # more specific intents first
    for name in ("why_degraded", "replan", "route", "revisit"):
        pat = dict(INTENTS)[name]
        if re.search(pat, q):
            intent = name
            break
    if intent is None:
        for name, pat in INTENTS:
            if re.search(pat, q):
                intent = name
                break
    t = sim.t
    e = sim.loc.eskf
    ev: list[str] = []
    if intent is None:
        return {"t": t, "intent": None, "answer": (
            "I can answer from live session data about: current position estimate, localization confidence, "
            "sensor health, why localization degraded, obstacles and clearance, route clearance, place "
            "recognition / revisits, why the planner replanned, and mission status. I do not control the aircraft."),
            "evidence": []}

    state = sim.integrity_state
    sig = sim.loc.sigma_h()
    if intent == "position":
        p = e.p
        valid = state in ("RELIABLE", "DEGRADED")
        ans = (f"Estimated position ({_fmt(p[0])}, {_fmt(p[1])}, {_fmt(p[2])}) m in the map frame, "
               f"1-sigma horizontal uncertainty {_fmt(sig)} m, source: {sim.estimate_source()}. "
               f"Localization state is {state}.")
        if not valid:
            ans += (" This estimate is NOT valid for navigation: the system has not re-established its "
                    "position against the map" if sim.loc.awaiting_reloc else
                    " This estimate should not be used for navigation until the state improves.")
        ev += [f"est.p = {np.round(p, 2).tolist()} @ t={t:.1f}s", f"sigma_h = {_fmt(sig, 3)} m",
               f"integrity = {state}", f"map segment = {sim.loc.segment}"]
    elif intent == "confidence":
        cov = sim.loc.global_cov()
        ans = (f"Localization is {state}. Horizontal 1-sigma {_fmt(sig)} m, vertical {_fmt(np.sqrt(cov[2, 2]))} m, "
               f"heading {_fmt(np.rad2deg(sim.loc.yaw_sigma()), 1)} deg. Contributions: filter "
               f"{_fmt(np.sqrt(e.P[0, 0]))} m, odometry drift bound {_fmt(np.sqrt(sim.loc.drift_var()))} m, "
               f"map anchor {_fmt(np.sqrt(np.trace(sim.loc.anchor_pos[:2, :2]) / 2))} m.")
        if sim.integrity_reasons:
            ans += " Active criteria: " + "; ".join(sim.integrity_reasons[:3]) + "."
        ev += [f"global covariance diag = {np.round(np.diag(cov), 4).tolist()}",
               f"VIO inliers = {sim.loc.vio.quality.inliers}", f"t = {t:.1f}s"]
    elif intent == "sensors":
        bad = [(h.name, h.status, h.reason) for h in sim.loc.health.values()
               if h.status not in ("OK", "DISABLED")]
        if bad:
            ans = "Sensors not fully healthy: " + "; ".join(f"{n}: {s}" + (f" ({r})" if r else "") for n, s, r in bad) + "."
        else:
            ans = "All fitted sensors report OK."
        vq = sim.loc.vio.quality
        ans += (f" Visual tracking {vq.status}: {vq.inliers} inliers of {vq.detected} detected features, "
                f"light level {_fmt(vq.mean_light)}, blur {_fmt(vq.blur_px, 1)} px.")
        ev += [f"{h.name}: {h.status}" for h in sim.loc.health.values()]
    elif intent == "why_degraded":
        rank = {"RELIABLE": 0, "DEGRADED": 1, "RECOVERING": 2, "UNCERTAIN": 2, "LOST": 3}
        trans = [x for x in sim.events if x["category"] == "integrity"]
        worse = [x for x in trans if rank.get(x["data"].get("to"), 0) > rank.get(x["data"].get("from"), 0)]
        if not worse:
            ans = "Localization has not degraded in this session."
        else:
            # report the most significant degradation episode: its first step and its worst state
            # most severe episode in the session: its worst transition and the first step leading to it
            worst = max(worse, key=lambda x: (rank.get(x["data"].get("to"), 0), x["t"]))
            first = worst
            for x in reversed([w for w in worse if w["t"] <= worst["t"]]):
                if first["t"] - x["t"] > 15.0:
                    break
                first = x
            causes = [c for c in sim.events if c["category"] in ("environment", "fault_injection", "localization", "fault")
                      and first["t"] - 6.0 <= c["t"] <= first["t"] + 0.05][-4:]
            ans = f"Localization first degraded at t={first['t']:.1f}s ({first['message']})."
            if worst is not first:
                ans += f" It reached {worst['data'].get('to')} at t={worst['t']:.1f}s: {worst['message']}."
            if worse[-1]["t"] > worst["t"] + 0.05:
                ans += f" Most recent degradation: t={worse[-1]['t']:.1f}s {worse[-1]['message']}."
            if causes:
                ans += " Preceding events: " + " | ".join(f"t={c['t']:.1f}s {c['message']}" for c in causes) + "."
            ans += f" Current state: {state}."
            ev += [f"t={x['t']:.1f}s {x['message']}" for x in trans[-6:]]
    elif intent == "obstacles":
        occ = int(sim.vmap.occ.sum())
        near_map = sim.vmap.nearest_obstacle(e.p)
        prox = sim.prox
        dirs = ["front", "front-left", "left", "rear-left", "rear", "rear-right", "right", "front-right"]
        k = int(np.argmin(prox))
        ans = (f"The map holds {occ} occupied voxels ({sim.vmap.res:.1f} m). Nearest mapped obstacle "
               f"{_fmt(near_map)} m from the estimated position; proximity sensors read the closest surface at "
               f"{_fmt(prox[k])} m ({dirs[k]}). Collision avoidance uses raw depth/proximity geometry, not "
               f"object classification.")
        ev += [f"proximity ring = {np.round(prox, 2).tolist()}", f"occupied voxels = {occ}"]
    elif intent == "route":
        pi = sim.plan_info
        if not pi:
            ans = "No route has been planned yet."
        else:
            ans = (f"Current route ({pi.get('length_m')} m) keeps at least {pi.get('min_clearance_m')} m from mapped "
                   f"obstacles; the planner required {pi.get('inflation_m')} m clearance (base margin + 2 x local "
                   f"sigma). The planner computes one minimum-cost route; it does not enumerate alternatives, so I "
                   f"cannot rank other routes by clearance.")
            ev += [f"plan = {pi}"]
    elif intent == "revisit":
        pe = sim.loc.place_events
        acc = [p for p in pe if p["accepted"]]
        rej = [p for p in pe if not p["accepted"]]
        if not pe:
            ans = f"No place-recognition matches yet ({len(sim.loc.kfdb.keyframes)} keyframes stored)."
        else:
            ans = (f"{len(acc)} accepted and {len(rej)} rejected place matches. ")
            if acc:
                a = acc[-1]
                ans += (f"Last accepted: {a['kind'].replace('_', ' ')} at t={a['t']}s against keyframe #{a['kf']} "
                        f"({a['inliers']} geometric inliers, {a['note']}).")
            ev += [f"t={p['t']} {p['kind']} kf#{p['kf']} accepted={p['accepted']} {p['note']}" for p in pe[-4:]]
    elif intent == "replan":
        rr = [r for r in sim.replan_reasons if r["reason"] != "periodic"]
        if not rr:
            ans = "No event-driven replans so far (only periodic refreshes)."
        else:
            last = rr[-1]
            ans = f"Last replan at t={last['t']}s because: {last['reason']} (new route {last['length_m']} m)."
            ev += [f"t={r['t']}s {r['reason']}" for r in rr[-5:]]
    else:  # mission
        g = sim.goals[sim.goal_idx] if sim.goal_idx < len(sim.goals) else None
        ans = (f"Mode {sim.mode}, movement authority {sim.behaviour}, goal {min(sim.goal_idx + 1, len(sim.goals))}/"
               f"{len(sim.goals)}" + (f" at ({_fmt(g[0], 1)}, {_fmt(g[1], 1)})" if g is not None else "") +
               f", battery {_fmt(sim.battery_pct(), 0)} %. Localization {state}.")
        ev += [f"t={t:.1f}s", f"speed scale {sim.safety.authority.speed_scale}"]
    return {"t": round(t, 2), "intent": intent, "answer": ans, "evidence": ev,
            "note": "Answer generated from session data; read-only, no actions taken."}
