"""Visual-inertial odometry front/back end (map-based ESKF visual update with a sliding landmark window).

Front end: the simulator's tracker supplies per-feature track ids (a KLT/descriptor tracker stand-in
with injected mis-associations). Everything after that is real estimation:

* landmarks are initialised from stereo depth at the *estimated* pose (with propagated covariance),
* each observation is a 2-D reprojection residual with analytic Jacobians,
* per-feature chi-square gating rejects mis-associations before a stacked ESKF update,
* landmarks unseen for ``landmark_window_s`` are marginalised (dropped) -> VIO drifts like real VIO,
* cross-correlations between landmarks and the state (tracked by a full MSCKF / SLAM back end) are not
  modelled, so the filter covariance is optimistic; the fusion layer adds a calibrated odometry-drift
  bound to the reported global covariance (see fusion.py and docs/algorithms/LOCALIZATION.md).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import CameraConfig, EstimatorConfig
from ..core.frames import camera_mount, skew
from ..simulation.sensors import CameraFrame
from .eskf import ESKF, P_SL, TH_SL


@dataclass
class Landmark:
    pos: np.ndarray
    cov: np.ndarray
    word: int
    created: float
    last_seen: float
    n_obs: int = 1
    n_reject: int = 0


@dataclass
class TrackingQuality:
    t: float = 0.0
    detected: int = 0
    with_depth: int = 0
    tracked: int = 0
    inliers: int = 0
    rejected: int = 0
    initialized: int = 0
    reproj_rms_px: float = 0.0
    coverage: float = 0.0          # fraction of 4x4 image cells containing an inlier
    mean_light: float = 1.0
    blur_px: float = 0.0
    status: str = "INIT"           # INIT | OK | WEAK | LOST | STALE | NO_DATA
    nis_mean: float = 0.0

    def to_dict(self) -> dict:
        return {k: (round(v, 3) if isinstance(v, float) else v) for k, v in self.__dict__.items()}


@dataclass
class VisualObservation:
    """Gravity-aligned body-frame 3-D points of the current frame, for place recognition."""
    t: float
    pts_body: np.ndarray
    words: np.ndarray
    pts_map: np.ndarray
    desc: np.ndarray | None = None


class VisualInertialOdometry:
    def __init__(self, cam: CameraConfig, est: EstimatorConfig):
        self.cam = cam
        self.est = est
        self.R_bc = camera_mount(cam.mount_pitch_deg)
        self.t_bc = np.array(cam.lever_arm_m, float)
        self.landmarks: dict[int, Landmark] = {}
        self.quality = TrackingQuality()
        self.last_frame_t = -1.0
        self.lost_since: float | None = None
        self.inlier_ids: np.ndarray = np.zeros(0, int)
        self.last_obs: VisualObservation | None = None

    # ------------------------------------------------------------------ geometry
    def _project(self, eskf: ESKF, P_l: np.ndarray):
        R, p = eskf.R, eskf.p
        q = (P_l - p) @ R                         # body frame (rows): R^T (P_l - p)
        pc = (q - self.t_bc) @ self.R_bc          # camera frame: R_bc^T (q - t_bc)
        return q, pc

    def _jacobians(self, eskf: ESKF, q: np.ndarray, pc: np.ndarray):
        fx, fy = self.cam.fx, self.cam.fy
        X, Y, Z = pc[:, 0], pc[:, 1], pc[:, 2]
        n = pc.shape[0]
        Jpi = np.zeros((n, 2, 3))
        Jpi[:, 0, 0] = fx / Z
        Jpi[:, 0, 2] = -fx * X / Z ** 2
        Jpi[:, 1, 1] = fy / Z
        Jpi[:, 1, 2] = -fy * Y / Z ** 2
        A = Jpi @ self.R_bc.T                     # d uv / d q   (n,2,3)
        H_p = A @ (-eskf.R.T)                     # (n,2,3)
        Sq = np.zeros((n, 3, 3))
        Sq[:, 0, 1], Sq[:, 0, 2] = -q[:, 2], q[:, 1]
        Sq[:, 1, 0], Sq[:, 1, 2] = q[:, 2], -q[:, 0]
        Sq[:, 2, 0], Sq[:, 2, 1] = -q[:, 1], q[:, 0]
        H_th = A @ Sq                             # d q / d theta = [q]x
        # Roll and pitch are observable only through gravity (IMU). Landmarks were initialised from this
        # filter's own attitude, so letting them "measure" roll/pitch would inject false information.
        # Keep only the yaw component of the attitude Jacobian: dtheta_b -> yaw = R[2,:] . dtheta_b.
        r = eskf.R[2, :]
        H_th = H_th @ np.outer(r, r)
        H_l = A @ eskf.R.T
        return H_p, H_th, H_l

    def backproject(self, eskf: ESKF, uv: np.ndarray, depth: np.ndarray) -> np.ndarray:
        m = np.stack([(uv[:, 0] - self.cam.width / 2) / self.cam.fx * depth,
                      (uv[:, 1] - self.cam.height / 2) / self.cam.fy * depth, depth], axis=1)
        b = m @ self.R_bc.T + self.t_bc
        return b @ eskf.R.T + eskf.p, b

    # ------------------------------------------------------------------ main entry
    def process(self, frame: CameraFrame, eskf: ESKF, *, allow_new_landmarks: bool = True) -> TrackingQuality:
        cam, est = self.cam, self.est
        Q = TrackingQuality(t=frame.t, mean_light=frame.mean_light, blur_px=frame.blur_px)
        if frame.t <= self.last_frame_t + 1e-9:
            Q.status = "STALE"
            Q.detected = int(frame.ids.size)
            self.quality = Q
            return Q
        self.last_frame_t = frame.t
        Q.detected = int(frame.ids.size)
        Q.with_depth = int(np.isfinite(frame.depth).sum())
        sigma_px = cam.pixel_noise / np.clip(frame.mean_light, 0.3, 1.0) + 0.3 * frame.blur_px

        known = np.array([i in self.landmarks for i in frame.ids], bool) if frame.ids.size else np.zeros(0, bool)
        idx_known = np.nonzero(known)[0]
        Q.tracked = int(idx_known.size)
        inlier_mask = np.zeros(frame.ids.size, bool)
        nis_vals = []
        if idx_known.size:
            P_l = np.array([self.landmarks[int(frame.ids[i])].pos for i in idx_known])
            cov_l = np.array([self.landmarks[int(frame.ids[i])].cov for i in idx_known])
            q, pc = self._project(eskf, P_l)
            ok = pc[:, 2] > 0.15
            idx_known, P_l, cov_l, q, pc = idx_known[ok], P_l[ok], cov_l[ok], q[ok], pc[ok]
            if idx_known.size:
                uv_hat = np.stack([cam.fx * pc[:, 0] / pc[:, 2] + cam.width / 2,
                                   cam.fy * pc[:, 1] / pc[:, 2] + cam.height / 2], 1)
                res = frame.uv[idx_known] - uv_hat
                H_p, H_th, H_l = self._jacobians(eskf, q, pc)
                Pp = eskf.P[P_SL, P_SL]
                Pt = eskf.P[TH_SL, TH_SL]
                Ppt = eskf.P[P_SL, TH_SL]
                HPH = (H_p @ Pp @ H_p.transpose(0, 2, 1) + H_th @ Pt @ H_th.transpose(0, 2, 1)
                       + H_p @ Ppt @ H_th.transpose(0, 2, 1) + H_th @ Ppt.T @ H_p.transpose(0, 2, 1))
                Rl = H_l @ cov_l @ H_l.transpose(0, 2, 1) + np.eye(2) * sigma_px ** 2
                S = HPH + Rl
                Sinv = np.linalg.inv(S)
                nis = np.einsum("ni,nij,nj->n", res, Sinv, res)
                good = nis < est.chi2_gate_2dof
                for k, i in enumerate(idx_known):
                    lm = self.landmarks.get(int(frame.ids[i]))
                    if lm is None:          # duplicate track id in this frame, already removed
                        good[k] = False
                        continue
                    if good[k]:
                        lm.last_seen = frame.t
                        lm.n_obs += 1
                        lm.n_reject = 0
                    else:
                        lm.n_reject += 1
                        if lm.n_reject >= 3 and lm.n_obs < 30:
                            del self.landmarks[int(frame.ids[i])]
                sel = np.nonzero(good)[0]
                Q.inliers = int(sel.size)
                Q.rejected = int(idx_known.size - sel.size)
                if sel.size:
                    nis_vals = nis[sel]
                    inlier_mask[idx_known[sel]] = True
                    if sel.size > est.vio_max_update_features:
                        # keep a spatially spread subset: sort by image cell then take round robin
                        cells = (frame.uv[idx_known[sel], 0] // 160).astype(int) * 4 + \
                                (frame.uv[idx_known[sel], 1] // 120).astype(int)
                        order = np.lexsort((np.arange(sel.size), cells))
                        rank = np.zeros(sel.size)
                        counter: dict[int, int] = {}
                        for o in order:
                            c = cells[o]
                            rank[o] = counter.get(c, 0)
                            counter[c] = counter.get(c, 0) + 1
                        picked = np.argsort(rank, kind="stable")[: est.vio_max_update_features]
                        sel = sel[picked]
                    m = sel.size
                    H = np.zeros((2 * m, 15))
                    H[:, P_SL] = H_p[sel].reshape(2 * m, 3)
                    H[:, TH_SL] = H_th[sel].reshape(2 * m, 3)
                    r = res[sel].reshape(2 * m)
                    Rm = np.zeros((2 * m, 2 * m))
                    for k in range(m):
                        Rm[2 * k:2 * k + 2, 2 * k:2 * k + 2] = Rl[sel[k]]
                    eskf.update(r, H, Rm)
                    Q.reproj_rms_px = float(np.sqrt(np.mean(res[sel] ** 2)))
                    cells_hit = set(((frame.uv[idx_known[sel], 0] // 160).astype(int) * 4 +
                                     (frame.uv[idx_known[sel], 1] // 120).astype(int)).tolist())
                    Q.coverage = len(cells_hit) / 16.0
        Q.nis_mean = float(np.mean(nis_vals)) if len(nis_vals) else 0.0
        self.inlier_ids = frame.ids[inlier_mask]

        # ---- landmark initialisation from stereo depth
        if allow_new_landmarks:
            new = np.nonzero(~known & np.isfinite(frame.depth))[0]
            room = 450 - len(self.landmarks)
            if new.size and room > 0:
                new = new[:room]
                pts_w, pts_b = self.backproject(eskf, frame.uv[new], frame.depth[new])
                Pp = eskf.P[P_SL, P_SL]
                Pt = eskf.P[TH_SL, TH_SL]
                for k, i in enumerate(new):
                    lid = int(frame.ids[i])
                    if lid in self.landmarks:
                        continue
                    z = frame.depth[i]
                    J_th = -eskf.R @ skew(pts_b[k])
                    sd = cam.depth_noise_coeff * z * z + 0.01
                    sp = sigma_px * z / cam.fx
                    Cm = np.diag([sp ** 2, sp ** 2, sd ** 2])
                    Rwc = eskf.R @ self.R_bc
                    cov = Pp + J_th @ Pt @ J_th.T + Rwc @ Cm @ Rwc.T
                    self.landmarks[lid] = Landmark(pts_w[k], cov * 1.3, int(frame.words[i]), frame.t, frame.t)
                    Q.initialized += 1

        # ---- sliding window marginalisation
        stale = [k for k, lm in self.landmarks.items() if frame.t - lm.last_seen > self.est.landmark_window_s]
        for k in stale:
            del self.landmarks[k]

        # ---- observation for place recognition (gravity-aligned body frame)
        dmask = np.isfinite(frame.depth)
        if dmask.sum() >= 8:
            pts_w, pts_b = self.backproject(eskf, frame.uv[dmask], frame.depth[dmask])
            yaw = eskf.yaw()
            c, s = np.cos(-yaw), np.sin(-yaw)
            Rz_inv = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.0]])
            pts_g = pts_b @ (Rz_inv @ eskf.R).T
            self.last_obs = VisualObservation(frame.t, pts_g, frame.words[dmask], pts_w,
                                              None if frame.desc is None else frame.desc[dmask])
        else:
            self.last_obs = None

        if Q.inliers >= est.vio_weak_inliers:
            Q.status = "OK"
        elif Q.inliers >= est.vio_min_inliers:
            Q.status = "WEAK"
        elif Q.detected == 0 and Q.tracked == 0:
            Q.status = "NO_FEATURES"
        else:
            Q.status = "LOST" if self.landmarks or Q.detected < 10 else "INIT"
        if Q.status in ("OK", "WEAK"):
            self.lost_since = None
        elif self.lost_since is None:
            self.lost_since = frame.t
        self.quality = Q
        return Q

    def reset_map(self) -> None:
        self.landmarks.clear()

    def transform_map(self, Rz: np.ndarray, dp: np.ndarray, extra_cov: np.ndarray | None = None) -> None:
        """Re-express the local map in another frame; ``extra_cov`` = uncertainty of that frame change."""
        for lm in self.landmarks.values():
            lm.pos = Rz @ lm.pos + dp
            lm.cov = Rz @ lm.cov @ Rz.T + (0 if extra_cov is None else extra_cov)

    def landmark_array(self, limit: int = 400) -> np.ndarray:
        if not self.landmarks:
            return np.zeros((0, 3))
        pts = np.array([lm.pos for lm in self.landmarks.values()])
        return pts[:limit]
