"""Self-aware localization: integrity state machine with measurable transition criteria.

States: RELIABLE, DEGRADED, UNCERTAIN, LOST, RECOVERING.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..config import IntegrityConfig

LEVEL = {"RELIABLE": 0, "DEGRADED": 1, "RECOVERING": 2, "UNCERTAIN": 2, "LOST": 3}


@dataclass
class IntegrityInputs:
    t: float
    sigma_h: float                  # 1-sigma horizontal position uncertainty (largest axis), global frame
    sigma_v: float
    since_map_aiding: float         # s since VIO / LiDAR / relocalization constrained position
    since_any_aiding: float         # s since any aiding (incl. velocity from optical flow)
    vio_status: str
    sensor_faults: list = field(default_factory=list)
    nis_inconsistent: bool = False
    awaiting_reloc: bool = False    # map segment not yet tied to the global map


@dataclass
class IntegrityDecision:
    state: str
    reasons: list
    changed: bool
    previous: str
    operator_required: bool
    time_in_state: float


class IntegrityMonitor:
    def __init__(self, cfg: IntegrityConfig):
        self.cfg = cfg
        self.state = "RELIABLE"
        self.since = 0.0
        self.better_since: float | None = None
        self.operator_required = False
        self.reasons: list[str] = []
        self.history: list[tuple[float, str, str]] = []

    def classify(self, m: IntegrityInputs) -> tuple[str, list[str]]:
        c = self.cfg
        reasons: list[str] = []
        level = "RELIABLE"

        def worse(new: str, why: str) -> None:
            nonlocal level
            reasons.append(why)
            if LEVEL[new] > LEVEL[level]:
                level = new

        if m.sigma_h >= c.lost_sigma_m:
            worse("LOST", f"horizontal sigma {m.sigma_h:.2f} m >= {c.lost_sigma_m} m")
        elif m.sigma_h >= c.degraded_sigma_m:
            worse("UNCERTAIN", f"horizontal sigma {m.sigma_h:.2f} m >= {c.degraded_sigma_m} m")
        elif m.sigma_h >= c.reliable_sigma_m:
            worse("DEGRADED", f"horizontal sigma {m.sigma_h:.2f} m >= {c.reliable_sigma_m} m")
        if m.since_any_aiding >= c.max_unaided_s_lost:
            worse("LOST", f"no aiding for {m.since_any_aiding:.1f} s (inertial only)")
        elif m.since_any_aiding >= c.max_unaided_s_uncertain:
            worse("UNCERTAIN", f"no aiding for {m.since_any_aiding:.1f} s (inertial only)")
        if m.since_map_aiding >= 1.0:
            worse("DEGRADED", f"no map-relative aiding for {m.since_map_aiding:.1f} s")
        if m.vio_status == "WEAK":
            worse("DEGRADED", "visual tracking weak")
        if m.sensor_faults:
            worse("DEGRADED", "sensor faults: " + ", ".join(m.sensor_faults))
        if m.nis_inconsistent:
            worse("DEGRADED", "estimator innovations inconsistent")
        if m.sigma_v >= 0.6:
            worse("DEGRADED", f"vertical sigma {m.sigma_v:.2f} m")
        return level, reasons

    def update(self, m: IntegrityInputs) -> IntegrityDecision:
        c = self.cfg
        raw, reasons = self.classify(m)
        prev = self.state
        # hysteresis: once RECOVERING, brief tracking dropouts (< 2 s) do not fall back to UNCERTAIN
        tracking_back = (m.since_map_aiding < 0.5 and m.vio_status in ("OK", "WEAK")) or             (prev == "RECOVERING" and m.since_map_aiding < 2.0)
        # RECOVERING means "tracking is back, waiting to be tied to the global map again" - it only applies
        # while a re-initialised map segment awaits relocalization (otherwise there is nothing to recover to)
        if LEVEL[raw] >= 2 and prev in ("LOST", "UNCERTAIN", "RECOVERING") and tracking_back and m.awaiting_reloc:
            # tracking is back but the position is still not tied to the global map
            target = "RECOVERING"
            self.better_since = None
            reasons = reasons + ["visual tracking re-established; relocalizing against the keyframe map"]
            if prev == "RECOVERING" and m.t - self.since > c.reloc_timeout_s:
                target = "LOST"
                self.operator_required = True
                reasons.append(f"relocalization not achieved within {c.reloc_timeout_s:.0f} s")
            elif prev == "LOST" and self.operator_required:
                target = "LOST"
        elif LEVEL[raw] > LEVEL[prev] or (prev == "RECOVERING" and LEVEL[raw] >= 2):
            target = raw                                  # degradation is immediate
            self.better_since = None
        elif LEVEL[raw] < LEVEL[prev] or prev == "RECOVERING":
            if prev in ("LOST", "UNCERTAIN"):
                target = "RECOVERING"                     # never jump straight back to RELIABLE
            else:
                if self.better_since is None:
                    self.better_since = m.t
                dwell = c.recovering_dwell_s if prev == "RECOVERING" else c.improve_dwell_s
                target = raw if m.t - self.better_since >= dwell else prev
        else:
            target = prev
            self.better_since = None
        if target in ("RELIABLE", "DEGRADED"):
            self.operator_required = False
        changed = target != prev
        if changed:
            self.history.append((m.t, prev, target))
            self.state = target
            self.since = m.t
            self.better_since = None
        self.reasons = reasons
        return IntegrityDecision(self.state, reasons, changed, prev, self.operator_required, m.t - self.since)

    def clear_operator_flag(self) -> None:
        self.operator_required = False
