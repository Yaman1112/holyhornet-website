"""Multi-sensor fusion manager: ESKF + VIO + optical flow + rangefinder + barometer + place recognition.

Key design points
-----------------
* Every aiding source has a health monitor and a chi-square gate; nothing is trusted blindly.
* **Map anchoring.** After visual tracking is lost and later re-acquired, VIO restarts on a new map
  segment. The position uncertainty accumulated while unaided is moved into an *anchor* covariance
  that VIO cannot reduce (VIO only observes motion relative to its own new landmarks). The reported
  global covariance = filter covariance + anchor (+ yaw-anchor lever-arm term). Only relocalization
  against the keyframe map built while localization was reliable can remove the anchor. This avoids
  the classic failure of re-observing freshly initialised landmarks and becoming falsely confident.
* Relocalization needs two geometrically verified, mutually consistent place matches before the
  map segments are merged; loop closures in the reliable state are chi-square gated ESKF updates.
"""
from __future__ import annotations

import os

from typing import Callable

import numpy as np

from ..config import DeepFlightConfig
from ..core.frames import rot_z, wrap_angle
from ..perception.place_recognition import Keyframe, KeyframeDatabase, PlaceMatch
from ..simulation.sensors import CameraFrame, FlowSample, ImuSample, ScalarSample
from .eskf import ESKF, P_SL, TH_SL, V_SL
from .health import SensorHealth
from .integrity import IntegrityInputs, IntegrityMonitor
from .vio import VisualInertialOdometry

EventFn = Callable[[float, str, str, str, dict], None]


class LocalizationSystem:
    def __init__(self, cfg: DeepFlightConfig, p0: np.ndarray, yaw0: float, log: EventFn, seed: int = 0):
        self.cfg = cfg
        self.log = log
        self.eskf = ESKF(cfg.sensors.imu, p0, rot_z(yaw0))
        self.vio = VisualInertialOdometry(cfg.sensors.camera, cfg.estimator)
        self.kfdb = KeyframeDatabase(cfg.estimator, seed=seed)
        s = cfg.sensors
        self.health = {
            "imu": SensorHealth("IMU", s.imu.rate_hz),
            "camera": SensorHealth("Stereo camera", s.camera.rate_hz, enabled=s.camera.enabled),
            "flow": SensorHealth("Optical flow", s.flow.rate_hz, enabled=s.flow.enabled),
            "rangefinder": SensorHealth("Rangefinder", s.rangefinder.rate_hz, enabled=s.rangefinder.enabled),
            "baro": SensorHealth("Barometer", s.baro.rate_hz, enabled=s.baro.enabled),
            "lidar": SensorHealth("LiDAR", s.lidar.rate_hz, enabled=s.lidar.enabled),
            "gnss": SensorHealth("GNSS", 5.0, enabled=s.gnss.enabled, denied=s.gnss.denied),
            "magnetometer": SensorHealth("Magnetometer", 50.0, enabled=False),
        }
        self.health["magnetometer"].reason = "excluded indoors (magnetic disturbance)"
        self.integrity = IntegrityMonitor(cfg.integrity)
        self.anchor_pos = np.zeros((3, 3))
        self.anchor_yaw_var = 0.0
        self.anchor_origin = np.array(p0, float)
        self.awaiting_reloc = False          # True after VIO re-initialisation until relocalized
        self.place_diag: list = []            # recent relocalization attempts (diagnostics)
        self.segment = 0
        self.vio_lost = False
        self.last_map_aiding_t = 0.0
        self.last_vel_aiding_t = 0.0
        self.last_kf_p: np.ndarray | None = None
        self.last_kf_yaw = 0.0
        self.last_reloc_try = -1.0
        self.pending_reloc: dict | None = None
        self.home_locked = True             # before first take-off the vehicle sits on the surveyed pad
        self.contrib: dict[str, list] = {k: [] for k in ("vio", "flow", "rangefinder", "baro", "zupt", "reloc", "loop")}
        self.stats = {"loop_accepted": 0, "loop_rejected": 0, "reloc_accepted": 0, "reloc_rejected": 0,
                      "vio_reinit": 0, "keyframes": 0}
        self.last_match: dict | None = None
        self.place_events: list[dict] = []
        self.truth_fn: Callable[[], np.ndarray] | None = None   # validation hook (keyframe truth tags)
        self.odom_dist = 0.0                # distance travelled since the last absolute fix (drift bound)
        self._last_p = np.array(p0, float)
        self.t = 0.0

    # ================================================================== covariance views
    def drift_var(self) -> float:
        return (self.cfg.estimator.vio_drift_rate * self.odom_dist) ** 2

    def global_cov(self) -> np.ndarray:
        P = self.eskf.P[P_SL, P_SL] + self.anchor_pos + np.diag([1.0, 1.0, 0.1]) * self.drift_var()
        if self.anchor_yaw_var > 0:
            d = self.eskf.p - self.anchor_origin
            J = np.array([-d[1], d[0], 0.0])
            P = P + np.outer(J, J) * self.anchor_yaw_var
        return P

    def sigma_h(self) -> float:
        w = np.linalg.eigvalsh(self.global_cov()[:2, :2])
        return float(np.sqrt(max(w[-1], 0.0)))

    def sigma_local(self) -> float:
        """Uncertainty relative to the recently built local map (filter covariance only). Obstacles mapped
        moments ago share the vehicle's accumulated drift, so collision margins use this, while integrity
        decisions use the global covariance (filter + drift bound + anchor)."""
        w = np.linalg.eigvalsh(self.eskf.P[:2, :2])
        return float(np.sqrt(max(w[-1], 0.0)))

    def yaw_sigma(self) -> float:
        j = self.eskf.yaw_jacobian()
        return float(np.sqrt(j @ self.eskf.P[TH_SL, TH_SL] @ j + self.anchor_yaw_var))

    def _note(self, key: str, t: float) -> None:
        lst = self.contrib[key]
        lst.append(t)
        while lst and lst[0] < t - 1.0:
            lst.pop(0)

    # ================================================================== sensor callbacks
    def on_imu(self, s: ImuSample, dt: float) -> None:
        self.health["imu"].on_sample(s.t, s.t)
        self.eskf.propagate(s.acc, s.gyro, dt)
        self.t = s.t
        if not self.home_locked:
            self.odom_dist += float(np.linalg.norm(self.eskf.p[:2] - self._last_p[:2]))
        self._last_p = self.eskf.p.copy()

    def on_landed(self, t: float) -> None:
        """Zero-velocity update on the ground; position pinned while on the surveyed take-off pad."""
        H = np.zeros((3, 15))
        H[:, V_SL] = np.eye(3)
        self.eskf.update(-self.eskf.v, H, np.eye(3) * 0.01 ** 2)
        if self.home_locked:
            Hp = np.zeros((3, 15))
            Hp[:, P_SL] = np.eye(3)
            self.eskf.update(self.anchor_origin - self.eskf.p, Hp, np.eye(3) * 0.01 ** 2)
            self.last_map_aiding_t = t
        self.last_vel_aiding_t = t
        self._note("zupt", t)

    def on_takeoff(self) -> None:
        self.home_locked = False

    def on_flow(self, f: FlowSample) -> None:
        h = self.health["flow"]
        h.on_sample(f.t, f.t, f.quality)
        if f.quality < 0.2:
            return
        e = self.eskf
        vb = e.R.T @ e.v
        r = f.v_body_xy - vb[:2]
        H = np.zeros((2, 15))
        H[:, V_SL] = e.R.T[:2, :]
        Sv = np.array([[0, -vb[2], vb[1]], [vb[2], 0, -vb[0]], [-vb[1], vb[0], 0]])
        H[:, TH_SL] = Sv[:2, :]
        sd = self.cfg.sensors.flow.noise_ms / max(f.quality, 0.2) * 1.3
        Rf = np.eye(2) * sd ** 2
        if self.cfg.estimator.flow_fallback_only and f.t - self.last_map_aiding_t < 0.3:
            # vision is aiding: flow is only cross-checked (innovation consistency for the health monitor), not
            # fused. Fused alongside map-based VIO, whose velocity is over-confident (landmark errors are
            # correlated), flow residuals are absorbed by roll (climb) and yaw (cruise) through the body-frame
            # coupling - measured on Gazebo flights: +0.8 deg roll, ~1 deg heading.
            _, nis = e.innovation(r, H, Rf)
            h.on_update(nis <= 13.8, nis, 2)
            return
        res = e.update(r, H, Rf, gate=13.8)
        h.on_update(res.accepted, res.nis, 2)
        if res.accepted:
            self.last_vel_aiding_t = f.t
            self._note("flow", f.t)

    def on_rangefinder(self, m: ScalarSample) -> None:
        h = self.health["rangefinder"]
        h.on_sample(m.t, m.t)
        e = self.eskf
        z = m.value * e.R[2, 2]               # tilt-compensated height above the surface below
        H = np.zeros((1, 15))
        H[0, 2] = 1.0
        res = e.update(np.array([z - e.p[2]]), H, np.array([[0.04 ** 2]]), gate=10.8)
        h.on_update(res.accepted, res.nis, 1)   # rejections = furniture under the vehicle
        if res.accepted:
            self._note("rangefinder", m.t)

    def on_baro(self, m: ScalarSample) -> None:
        h = self.health["baro"]
        h.on_sample(m.t, m.t)
        e = self.eskf
        H = np.zeros((1, 15))
        H[0, 2] = 1.0
        res = e.update(np.array([m.value - e.p[2]]), H, np.array([[0.35 ** 2]]), gate=10.8)
        h.on_update(res.accepted, res.nis, 1)
        if res.accepted:
            self._note("baro", m.t)

    # ------------------------------------------------------------------ camera / VIO
    def on_camera(self, frame: CameraFrame | None, t: float, allow_keyframes: bool) -> None:
        hc = self.health["camera"]
        if frame is None:
            return
        hc.on_sample(t, frame.t, quality=min(1.0, frame.ids.size / 60.0))
        # Landmarks initialised from an uncertain pose carry that pose error; re-observing them would make the
        # filter falsely confident. While tracking is lost (or sigma >= 0.5 m) no landmarks are created - the
        # anchored re-initialisation path below is used instead.
        allow_init = (not self.vio_lost) and float(np.sqrt(np.linalg.eigvalsh(self.eskf.P[:2, :2])[-1])) < 0.5
        Q = self.vio.process(frame, self.eskf, allow_new_landmarks=allow_init)
        if Q.status == "STALE":
            return
        hc.on_update(Q.inliers > 0, Q.nis_mean * 2 if Q.inliers else None, 2)
        est = self.cfg.estimator
        if Q.status in ("OK", "WEAK"):
            self.last_map_aiding_t = t
            self._note("vio", t)
            if self.vio_lost:
                self.vio_lost = False
                self.log(t, "localization", "info", "Visual tracking re-acquired on the existing local map",
                         {"inliers": Q.inliers})
        elif self.vio.lost_since is not None and t - self.vio.lost_since > 0.5 and not self.vio_lost                 and not self.home_locked:          # on the surveyed pad the position is known anyway
            self.vio_lost = True
            self.log(t, "localization", "warning",
                     f"Visual tracking lost ({Q.detected} features, light {Q.mean_light:.2f}, blur {Q.blur_px:.1f}px)",
                     {"detected": Q.detected, "tracked": Q.tracked, "inliers": Q.inliers})
        # re-initialise VIO on a new map segment once enough features are visible again
        if self.vio_lost and Q.with_depth >= 30 and Q.inliers < est.vio_min_inliers:
            self._reinitialize(t)
        # keyframes
        if allow_keyframes and Q.status == "OK" and not self.awaiting_reloc:
            self._maybe_keyframe(t)
        # relocalization / loop closure
        self._place_recognition(t)

    def anchor_trace(self) -> float:
        return float(np.trace(self.anchor_pos) + self.anchor_yaw_var)

    def _set_anchor(self, cov_pos: np.ndarray, yaw_var: float) -> None:
        """Uncertainty of the current map frame w.r.t. the global map. VIO cannot reduce it."""
        self.anchor_pos = np.array(cov_pos, float)
        self.anchor_yaw_var = float(yaw_var)
        self.anchor_origin = self.eskf.p.copy()
        self.odom_dist = 0.0

    def _reinitialize(self, t: float) -> None:
        e = self.eskf
        gcov = self.global_cov()
        j = e.yaw_jacobian()
        yaw_var = float(j @ e.P[TH_SL, TH_SL] @ j)
        self._set_anchor(gcov, self.anchor_yaw_var + yaw_var)
        # a short outage with small accumulated uncertainty keeps the segment usable as global map
        sig = float(np.sqrt(np.linalg.eigvalsh(gcov[:2, :2])[-1]))
        self.awaiting_reloc = self.awaiting_reloc or sig > self.cfg.integrity.reliable_sigma_m
        # restart the filter's position / yaw uncertainty relative to the new segment
        for sl in (P_SL,):
            e.P[sl, :] = 0.0
            e.P[:, sl] = 0.0
            e.P[sl, sl] = np.eye(3) * 0.03 ** 2
        e.P[8, :] = 0.0
        e.P[:, 8] = 0.0
        e.P[8, 8] = np.deg2rad(0.5) ** 2
        self.vio.reset_map()
        self.vio.lost_since = None
        self.vio_lost = False
        self.segment += 1
        self.stats["vio_reinit"] += 1
        self.pending_reloc = None
        self.log(t, "localization", "warning",
                 f"VIO re-initialised on map segment #{self.segment}; "
                 + ("global position not yet re-established " if self.awaiting_reloc else "segment kept anchored ")
                 + f"(anchor sigma {np.sqrt(np.trace(gcov[:2, :2]) / 2):.2f} m, yaw {np.rad2deg(np.sqrt(self.anchor_yaw_var)):.1f} deg)",
                 {"segment": self.segment})

    def _maybe_keyframe(self, t: float) -> None:
        e, est = self.eskf, self.cfg.estimator
        obs = self.vio.last_obs
        if obs is None or obs.words.size < 20:
            return
        if self.last_kf_p is not None:
            moved = np.linalg.norm(e.p - self.last_kf_p)
            turned = abs(wrap_angle(e.yaw() - self.last_kf_yaw))
            if moved < est.keyframe_dist_m and turned < np.deg2rad(est.keyframe_angle_deg):
                return
        j = e.yaw_jacobian()
        kf = Keyframe(len(self.kfdb.keyframes), t, e.p.copy(), e.yaw(), self.global_cov().copy(),
                      float(j @ e.P[TH_SL, TH_SL] @ j), obs.words.copy(), obs.pts_map.copy(), self.segment,
                      truth_p=None if self.truth_fn is None else self.truth_fn(),
                      desc=None if obs.desc is None else obs.desc.copy())
        self.kfdb.add(kf)
        self.last_kf_p, self.last_kf_yaw = e.p.copy(), e.yaw()
        self.stats["keyframes"] += 1

    def _place_recognition(self, t: float) -> None:
        obs = self.vio.last_obs
        relocalizing = self.awaiting_reloc
        period = 0.5 if relocalizing else 1.0
        if obs is None or t - self.last_reloc_try < period or len(self.kfdb.keyframes) < 3:
            return
        self.last_reloc_try = t
        exclude_after = None if relocalizing else t - self.cfg.estimator.loop_exclude_recent_s
        if obs.desc is not None:
            # real descriptors: retrieval by position prior (keyframes the estimate's uncertainty allows),
            # nearest first; descriptor matching + 4-DOF RANSAC decide
            radius = 3.0 * self.sigma_h() + 6.0
            near = [(i, float(np.linalg.norm(kf.p[:2] - self.eskf.p[:2])))
                    for i, kf in enumerate(self.kfdb.keyframes)
                    if (exclude_after is None or kf.t <= exclude_after) and kf.desc is not None]
            near = sorted((x for x in near if x[1] < radius), key=lambda x: x[1])[:8]
            cands = [(i, 1.0 / (1.0 + d)) for i, d in near]
        else:
            cands = self.kfdb.query(obs.words, exclude_after=exclude_after, top_k=3)
        if not cands:
            return
        best: PlaceMatch | None = None
        reasons = []
        for i, score in cands:
            kf = self.kfdb.keyframes[i]
            res = self.kfdb.verify(kf, obs.pts_body, obs.words, obs.desc)
            if isinstance(res, PlaceMatch):
                res.score = score
                if best is None or res.inliers > best.inliers:
                    best = res
            else:
                reasons.append((kf.kf_id, res[1]))
        if relocalizing and len(self.place_diag) < 6 and os.environ.get("DF_DUMP_PLACE"):
            import pickle
            with open(os.environ["DF_DUMP_PLACE"] + f"_{len(self.place_diag)}.pkl", "wb") as fh:
                pickle.dump({"obs": obs, "p": self.eskf.p.copy(), "yaw": self.eskf.yaw(),
                             "truth": None if self.truth_fn is None else self.truth_fn(),
                             "kfs": self.kfdb.keyframes}, fh)
        if relocalizing:
            self.place_diag = (self.place_diag + [{
                "t": round(t, 1), "cands": [(int(i), round(sc, 3)) for i, sc in cands],
                "fails": [f"kf{k}: {r}" for k, r in reasons],
                "best": None if best is None else {"kf": best.kf.kf_id, "inliers": best.inliers,
                                                   "ratio": round(best.ratio, 2)}}])[-60:]
        if best is None:
            return
        if relocalizing:
            self._handle_reloc(t, best)
        else:
            self._handle_loop(t, best)

    def _record_place(self, t: float, m: PlaceMatch, kind: str, accepted: bool, note: str) -> None:
        truth_ok = None
        if self.truth_fn is not None:
            # validation only: a correct match yields a pose close to the true pose
            err = float(np.linalg.norm(self.truth_fn()[:2] - m.p[:2]))
            truth_ok = bool(err < max(1.0, 3.0 * float(np.sqrt(np.trace(m.cov_pos[:2, :2]) / 2))))
        ev = {"t": round(t, 2), "kind": kind, "accepted": accepted, "kf": m.kf.kf_id,
              "kf_p": np.round(m.kf.p, 2).tolist(), "p": np.round(self.eskf.p, 2).tolist(),
              "inliers": m.inliers, "ratio": round(m.ratio, 2), "score": round(m.score, 3),
              "note": note, "truth_correct": truth_ok}
        self.place_events.append(ev)
        self.last_match = ev

    def _handle_loop(self, t: float, m: PlaceMatch) -> None:
        e = self.eskf
        r = np.concatenate([m.p - e.p, [wrap_angle(m.yaw - e.yaw())]])
        H = np.zeros((4, 15))
        H[:3, P_SL] = np.eye(3)
        H[3, TH_SL] = e.yaw_jacobian()
        Rm = np.zeros((4, 4))
        Rm[:3, :3] = m.cov_pos
        Rm[3, 3] = m.yaw_var
        corr = float(np.linalg.norm(r[:3]))
        res = e.update(r, H, Rm, gate=13.28)
        if res.accepted:
            self.stats["loop_accepted"] += 1
            # the fix replaces accumulated drift + old anchor by the fix's own uncertainty, which VIO
            # re-observations must not be allowed to shrink
            if np.trace(m.cov_pos) < np.trace(self.global_cov()):
                self._set_anchor(m.cov_pos, m.yaw_var)
            self.last_map_aiding_t = t
            self._note("loop", t)
            self._record_place(t, m, "loop_closure", True, f"correction {corr:.2f} m")
            if corr > 0.05:
                self.log(t, "loop_closure", "info",
                         f"Loop closure with keyframe #{m.kf.kf_id} ({t - m.kf.t:.0f} s old): drift correction "
                         f"{corr:.2f} m, {m.inliers} inliers", {"kf": m.kf.kf_id, "correction_m": corr})
        else:
            self.stats["loop_rejected"] += 1
            self._record_place(t, m, "loop_closure", False, f"NIS {res.nis:.1f} > gate")
            self.log(t, "loop_closure", "warning",
                     f"Rejected loop-closure candidate keyframe #{m.kf.kf_id}: inconsistent with current estimate "
                     f"(NIS {res.nis:.1f}, implied jump {corr:.2f} m)", {"kf": m.kf.kf_id})

    def _handle_reloc(self, t: float, m: PlaceMatch) -> None:
        e = self.eskf
        dpsi = wrap_angle(m.yaw - e.yaw())
        Rz = rot_z(dpsi)
        dp = m.p - Rz @ e.p
        # plausibility against the (large) global uncertainty
        corr = m.p - e.p
        S = self.global_cov() + m.cov_pos
        d2 = float(corr @ np.linalg.solve(S, corr))
        if d2 > 16.27:
            self.stats["reloc_rejected"] += 1
            self._record_place(t, m, "relocalization", False, f"implausible jump (d2 {d2:.1f})")
            self.log(t, "relocalization", "warning",
                     f"Rejected relocalization to keyframe #{m.kf.kf_id}: {np.linalg.norm(corr):.2f} m jump is "
                     f"outside the 99.9% uncertainty region", {"kf": m.kf.kf_id})
            return
        pend = self.pending_reloc
        if pend is None or t - pend["t"] > 3.0:
            self.pending_reloc = {"t": t, "dp": dp, "dpsi": dpsi, "kf": m.kf.kf_id}
            self._record_place(t, m, "relocalization", False, "candidate - awaiting confirmation")
            self.log(t, "relocalization", "info",
                     f"Relocalization candidate: keyframe #{m.kf.kf_id} ({m.inliers} inliers) - awaiting a second "
                     f"consistent match", {"kf": m.kf.kf_id})
            return
        if np.linalg.norm(dp - pend["dp"]) > 0.35 or abs(wrap_angle(dpsi - pend["dpsi"])) > np.deg2rad(5):
            self.pending_reloc = {"t": t, "dp": dp, "dpsi": dpsi, "kf": m.kf.kf_id}
            self.stats["reloc_rejected"] += 1
            self._record_place(t, m, "relocalization", False, "inconsistent with previous candidate")
            return
        # merge: re-express the current segment in the global map frame
        e.p = m.p.copy()
        e.v = Rz @ e.v
        e.R = Rz @ e.R
        self.vio.transform_map(Rz, dp)
        for sl in (P_SL,):
            e.P[sl, :] = 0.0
            e.P[:, sl] = 0.0
        e.P[P_SL, P_SL] = np.eye(3) * 0.03 ** 2
        e.P[8, :] = 0.0
        e.P[:, 8] = 0.0
        e.P[8, 8] = np.deg2rad(0.5) ** 2
        self._set_anchor(m.cov_pos, m.yaw_var)
        self.awaiting_reloc = False
        self.pending_reloc = None
        self.last_map_aiding_t = t
        self.stats["reloc_accepted"] += 1
        self._note("reloc", t)
        self._record_place(t, m, "relocalization", True, f"correction {np.linalg.norm(corr):.2f} m")
        self.log(t, "relocalization", "info",
                 f"Relocalized against keyframe #{m.kf.kf_id}: map segment #{self.segment} merged into the global "
                 f"map (correction {np.linalg.norm(corr):.2f} m, yaw {np.rad2deg(dpsi):.1f} deg, {m.inliers} inliers)",
                 {"kf": m.kf.kf_id, "correction_m": float(np.linalg.norm(corr))})

    # ================================================================== integrity
    def evaluate(self, t: float):
        faults = []
        for key, h in self.health.items():
            st = h.evaluate(t)
            if st in ("FAILED", "STALE") and key in ("imu", "camera", "flow", "rangefinder", "baro", "lidar"):
                faults.append(f"{h.name} {st.lower()}")
        cov = self.global_cov()
        since_map = t - self.last_map_aiding_t
        since_any = t - max(self.last_map_aiding_t, self.last_vel_aiding_t)
        nis_bad = (self.health["camera"].nis_ema or 0) > 6.0
        m = IntegrityInputs(t, self.sigma_h(), float(np.sqrt(max(cov[2, 2], 0))), since_map, since_any,
                            self.vio.quality.status, faults, nis_bad, self.awaiting_reloc)
        return self.integrity.update(m), m

    def contributions(self) -> dict:
        return {k: len(v) for k, v in self.contrib.items()}

    def operator_reinitialize(self, t: float) -> None:
        """Operator-confirmed: accept the current estimate as the new global reference (logged)."""
        self._set_anchor(np.zeros((3, 3)), 0.0)
        self.awaiting_reloc = False
        self.integrity.clear_operator_flag()
        self.log(t, "operator", "warning",
                 "Operator accepted the current estimate as the global reference; earlier map may be misaligned",
                 {})
