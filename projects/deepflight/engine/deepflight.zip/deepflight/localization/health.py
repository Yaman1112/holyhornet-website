"""Per-sensor health monitoring: staleness, timestamp consistency, innovation consistency, quality."""
from __future__ import annotations

from dataclasses import dataclass, field

STATUS_ORDER = {"OK": 0, "DISABLED": 0, "DENIED": 0, "DEGRADED": 1, "STALE": 2, "FAILED": 3}


@dataclass
class SensorHealth:
    name: str
    expected_hz: float
    enabled: bool = True
    denied: bool = False
    last_t: float | None = None
    last_stamp: float | None = None
    count: int = 0
    accepted: int = 0
    rejected: int = 0
    nis_ema: float | None = None
    dof: int = 1
    quality: float = 1.0
    status: str = "OK"
    reason: str = ""
    stamp_errors: int = 0
    stale_min_s: float = 0.06       # transport-jitter allowance
    history: list = field(default_factory=list)

    def on_sample(self, t: float, stamp: float | None = None, quality: float | None = None) -> None:
        if stamp is not None and self.last_stamp is not None and stamp <= self.last_stamp:
            self.stamp_errors += 1
        else:
            self.last_t = t
            self.stamp_errors = 0
        if stamp is not None:
            self.last_stamp = stamp
        self.count += 1
        if quality is not None:
            self.quality = 0.8 * self.quality + 0.2 * quality

    def on_update(self, accepted: bool, nis: float | None, dof: int) -> None:
        self.dof = dof
        if accepted:
            self.accepted += 1
        else:
            self.rejected += 1
        if nis is not None:
            x = nis / max(dof, 1)
            self.nis_ema = x if self.nis_ema is None else 0.9 * self.nis_ema + 0.1 * min(x, 50.0)

    def evaluate(self, t: float) -> str:
        if not self.enabled:
            self.status, self.reason = "DISABLED", "not fitted in this configuration"
            return self.status
        if self.denied:
            self.status, self.reason = "DENIED", "no fix (GNSS-denied environment)"
            return self.status
        if self.last_t is None:
            self.status, self.reason = ("FAILED", "no data received") if t > 1.0 else ("OK", "starting")
            return self.status
        age = t - self.last_t
        period = 1.0 / self.expected_hz
        if self.stamp_errors and age > 5 * period:
            self.status, self.reason = "STALE", f"frozen timestamps ({self.stamp_errors} repeated)"
        elif age > max(10 * period, 0.5):
            self.status, self.reason = "FAILED", f"no data for {age:.1f} s"
        elif age > max(3 * period, self.stale_min_s):
            self.status, self.reason = "STALE", f"last sample {age * 1000:.0f} ms ago"
        elif self.nis_ema is not None and self.nis_ema > 4.0:
            self.status, self.reason = "DEGRADED", f"innovations inconsistent (NIS/dof {self.nis_ema:.1f})"
        elif self.quality < 0.35:
            self.status, self.reason = "DEGRADED", f"low measurement quality ({self.quality:.2f})"
        else:
            self.status, self.reason = "OK", ""
        return self.status

    def to_dict(self) -> dict:
        return {
            "name": self.name, "status": self.status, "reason": self.reason,
            "rate_hz": self.expected_hz, "accepted": self.accepted, "rejected": self.rejected,
            "nis": None if self.nis_ema is None else round(self.nis_ema, 2),
            "quality": round(self.quality, 2),
        }
