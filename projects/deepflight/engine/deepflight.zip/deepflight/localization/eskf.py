"""15-state error-state Kalman filter (ESKF) with IMU propagation.

Nominal state: p (map), v (map), R_map_body, accel bias ba, gyro bias bg.
Error state (15): [dp, dv, dtheta (body-frame, right perturbation), dba, dbg].
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..config import ImuConfig
from ..core.frames import GRAVITY, exp_so3, orthonormalize, skew

P_SL, V_SL, TH_SL, BA_SL, BG_SL = slice(0, 3), slice(3, 6), slice(6, 9), slice(9, 12), slice(12, 15)


@dataclass
class UpdateResult:
    accepted: bool
    nis: float
    dof: int
    reason: str = ""


class ESKF:
    def __init__(self, imu_cfg: ImuConfig, p0: np.ndarray, R0: np.ndarray, *,
                 sigma_p0: float = 0.02, sigma_v0: float = 0.02, sigma_att0_deg: float = 1.0,
                 sigma_yaw0_deg: float = 1.0):
        self.cfg = imu_cfg
        self.p = np.array(p0, float)
        self.v = np.zeros(3)
        self.R = np.array(R0, float)
        self.ba = np.zeros(3)
        self.bg = np.zeros(3)
        P = np.zeros((15, 15))
        P[P_SL, P_SL] = np.eye(3) * sigma_p0 ** 2
        P[V_SL, V_SL] = np.eye(3) * sigma_v0 ** 2
        P[TH_SL, TH_SL] = np.diag([np.deg2rad(sigma_att0_deg) ** 2] * 2 + [np.deg2rad(sigma_yaw0_deg) ** 2])
        P[BA_SL, BA_SL] = np.eye(3) * 0.08 ** 2
        P[BG_SL, BG_SL] = np.eye(3) * 0.006 ** 2
        self.P = P
        self.last_acc = np.zeros(3)
        self.last_gyro = np.zeros(3)
        self.t = 0.0

    # ------------------------------------------------------------------ propagation
    def propagate(self, acc_m: np.ndarray, gyro_m: np.ndarray, dt: float, *, noise_scale: float = 1.0) -> None:
        a = acc_m - self.ba
        w = gyro_m - self.bg
        R = self.R
        a_w = R @ a + GRAVITY
        self.p = self.p + self.v * dt + 0.5 * a_w * dt * dt
        self.v = self.v + a_w * dt
        self.R = R @ exp_so3(w * dt)
        self.last_acc, self.last_gyro = a, w

        F = np.eye(15)
        F[P_SL, V_SL] = np.eye(3) * dt
        F[V_SL, TH_SL] = -R @ skew(a) * dt
        F[V_SL, BA_SL] = -R * dt
        F[TH_SL, TH_SL] = exp_so3(-w * dt)
        F[TH_SL, BG_SL] = -np.eye(3) * dt
        c = self.cfg
        # rotor vibration is part of the accelerometer noise budget in flight
        acc_sd = np.hypot(c.accel_noise_density, 0.15 * np.sqrt(dt)) * noise_scale
        q = np.concatenate([
            np.full(3, (acc_sd ** 2) * dt),
            np.full(3, (c.gyro_noise_density * noise_scale) ** 2 * dt),
            np.full(3, c.accel_bias_walk ** 2 * dt),
            np.full(3, c.gyro_bias_walk ** 2 * dt),
        ])
        P = F @ self.P @ F.T
        P[V_SL, V_SL] += np.eye(3) * q[0]
        P[TH_SL, TH_SL] += np.eye(3) * q[3]
        P[BA_SL, BA_SL] += np.eye(3) * q[6]
        P[BG_SL, BG_SL] += np.eye(3) * q[9]
        self.P = 0.5 * (P + P.T)
        self.t += dt

    # ------------------------------------------------------------------ update
    def innovation(self, r: np.ndarray, H: np.ndarray, Rm: np.ndarray) -> tuple[np.ndarray, float]:
        S = H @ self.P @ H.T + Rm
        nis = float(r @ np.linalg.solve(S, r))
        return S, nis

    def update(self, r: np.ndarray, H: np.ndarray, Rm: np.ndarray, *, gate: float | None = None) -> UpdateResult:
        S, nis = self.innovation(r, H, Rm)
        if gate is not None and nis > gate:
            return UpdateResult(False, nis, r.size, "chi2 gate")
        K = np.linalg.solve(S, H @ self.P).T
        dx = K @ r
        I_KH = np.eye(15) - K @ H
        self.P = I_KH @ self.P @ I_KH.T + K @ Rm @ K.T
        self.P = 0.5 * (self.P + self.P.T)
        self.inject(dx)
        return UpdateResult(True, nis, r.size)

    def inject(self, dx: np.ndarray) -> None:
        self.p = self.p + dx[P_SL]
        self.v = self.v + dx[V_SL]
        self.R = orthonormalize(self.R @ exp_so3(dx[TH_SL]))
        self.ba = self.ba + dx[BA_SL]
        self.bg = self.bg + dx[BG_SL]

    # ------------------------------------------------------------------ helpers
    def yaw(self) -> float:
        return float(np.arctan2(self.R[1, 0], self.R[0, 0]))

    def yaw_jacobian(self) -> np.ndarray:
        """d(yaw)/d(dtheta) for the right-perturbed attitude (row vector, 3)."""
        # yaw depends on the world-frame rotation about z: dtheta_world = R dtheta_body
        return self.R[2, :].copy()

    def sigma_pos(self) -> np.ndarray:
        return np.sqrt(np.clip(np.diag(self.P)[P_SL], 0, None))

    def state_vector(self) -> dict:
        return {"p": self.p.tolist(), "v": self.v.tolist(), "ba": self.ba.tolist(), "bg": self.bg.tolist()}
