"""Keyframe database, bag-of-words place recognition and 4-DOF geometric verification.

Retrieval: tf-idf weighted visual-word histograms, cosine similarity (DBoW-style).
Verification: putative matches share a visual word; 2-point RANSAC over yaw + translation in the
gravity-aligned frame (roll/pitch are observable from the IMU), least-squares refinement on inliers.
Ambiguous appearance (repetitive geometry) yields many putative matches with no consistent geometry;
those candidates fail the inlier-count / inlier-ratio tests and are reported as rejected.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import EstimatorConfig


@dataclass
class Keyframe:
    kf_id: int
    t: float
    p: np.ndarray                 # global position estimate at creation
    yaw: float
    cov_pos: np.ndarray           # global 3x3 covariance at creation
    yaw_var: float
    words: np.ndarray
    pts_map: np.ndarray           # (N,3) landmark positions in the global map frame
    segment: int = 0
    truth_p: np.ndarray | None = None      # validation only (never read by the estimator)
    desc: np.ndarray | None = None         # (N,32) ORB descriptors (image front end only)


@dataclass
class PlaceMatch:
    kf: Keyframe
    score: float
    inliers: int
    putative: int
    ratio: float
    p: np.ndarray                 # estimated global body position
    yaw: float
    cov_pos: np.ndarray
    yaw_var: float
    rms: float


@dataclass
class QueryResult:
    candidates: list = field(default_factory=list)   # [(kf_id, score)]
    match: PlaceMatch | None = None
    rejected: list = field(default_factory=list)     # [(kf_id, reason)]


class KeyframeDatabase:
    def __init__(self, est: EstimatorConfig, vocab: int = 600, seed: int = 0):
        self.est = est
        self.vocab = vocab
        self.keyframes: list[Keyframe] = []
        self.df = np.zeros(vocab)
        self._vecs: list[np.ndarray] = []
        self.rng = np.random.default_rng(seed)

    def _bow(self, words: np.ndarray) -> np.ndarray:
        h = np.bincount(np.clip(words, 0, self.vocab - 1), minlength=self.vocab).astype(float)
        return h

    def _tfidf(self, h: np.ndarray) -> np.ndarray:
        n = max(len(self.keyframes), 1)
        idf = np.log((n + 1.0) / (self.df + 1.0)) + 1.0
        v = h * idf
        nrm = np.linalg.norm(v)
        return v / nrm if nrm > 0 else v

    def add(self, kf: Keyframe) -> None:
        h = self._bow(kf.words)
        self.df += h > 0
        self.keyframes.append(kf)
        self._vecs.append(h)

    def query(self, words: np.ndarray, *, exclude_after: float | None = None, top_k: int = 3) -> list[tuple[int, float]]:
        if not self.keyframes or words.size == 0:
            return []
        qv = self._tfidf(self._bow(words))
        scores = []
        for i, kf in enumerate(self.keyframes):
            if exclude_after is not None and kf.t > exclude_after:
                continue
            scores.append((i, float(qv @ self._tfidf(self._vecs[i]))))
        scores.sort(key=lambda x: -x[1])
        return scores[:top_k]

    # ------------------------------------------------------------------ verification
    def verify(self, kf: Keyframe, pts_g: np.ndarray, words: np.ndarray,
               desc: np.ndarray | None = None) -> PlaceMatch | tuple[None, str]:
        est = self.est
        if desc is not None and kf.desc is not None:
            qi, mj = _descriptor_matches(desc, kf.desc)
        else:
            # putative matches by word
            by_word: dict[int, list[int]] = {}
            for j, w in enumerate(kf.words):
                by_word.setdefault(int(w), []).append(j)
            qi, mj = [], []
            for i, w in enumerate(words):
                for j in by_word.get(int(w), [])[:4]:
                    qi.append(i)
                    mj.append(j)
        if len(qi) < est.loop_min_inliers:
            return None, f"only {len(qi)} putative matches"
        qi, mj = np.array(qi), np.array(mj)
        Q = pts_g[qi]
        M = kf.pts_map[mj]
        thr = est.reloc_inlier_threshold_m
        best_inl, best = None, None
        n = qi.size
        for _ in range(250):
            a, b = self.rng.choice(n, 2, replace=False)
            dq = Q[b, :2] - Q[a, :2]
            dm = M[b, :2] - M[a, :2]
            if np.linalg.norm(dq) < 0.4 or abs(np.linalg.norm(dq) - np.linalg.norm(dm)) > 2 * thr:
                continue
            if abs((Q[b, 2] - Q[a, 2]) - (M[b, 2] - M[a, 2])) > 2 * thr:
                continue
            psi = np.arctan2(dm[1], dm[0]) - np.arctan2(dq[1], dq[0])
            Rz = _rz(psi)
            t = M[a] - Rz @ Q[a]
            err = np.linalg.norm(M - (Q @ Rz.T + t), axis=1)
            inl = err < thr
            if best_inl is None or inl.sum() > best_inl.sum():
                best_inl, best = inl, (psi, t)
        if best_inl is None:
            return None, "no valid minimal sample"
        # one feature may vote only once
        inl_idx = np.nonzero(best_inl)[0]
        uniq = len(set(qi[inl_idx].tolist()))
        n_query = len(set(qi.tolist()))
        ratio = uniq / max(n_query, 1)
        if uniq < est.loop_min_inliers:
            return None, f"{uniq} geometric inliers < {est.loop_min_inliers}"
        if ratio < est.loop_min_inlier_ratio:
            return None, f"inlier ratio {ratio:.2f} < {est.loop_min_inlier_ratio}"
        psi, t = _refine(Q[inl_idx], M[inl_idx])
        Rz = _rz(psi)
        res = M[inl_idx] - (Q[inl_idx] @ Rz.T + t)
        rms = float(np.sqrt(np.mean(np.sum(res ** 2, axis=1))))
        # pose covariance: residual scatter / inlier count, plus the keyframe's own uncertainty
        pt_var = max(rms ** 2, 0.03 ** 2)
        meas_var = pt_var / uniq * 6.0                       # x6: conservative (outliers, correlated errors)
        sxx = float(np.sum((Q[inl_idx, :2] - Q[inl_idx, :2].mean(0)) ** 2))
        yaw_var = 3.0 * pt_var / max(sxx, 1.0) + kf.yaw_var  # LS heading variance, x3 conservative
        cov = np.eye(3) * meas_var + kf.cov_pos
        return PlaceMatch(kf, 0.0, uniq, int(n_query), ratio, t, float(psi), cov, float(yaw_var), rms)

    def to_list(self) -> list[dict]:
        return [{"id": k.kf_id, "t": round(k.t, 2), "p": np.round(k.p, 3).tolist(), "segment": k.segment}
                for k in self.keyframes]


_POPCOUNT = np.array([bin(i).count("1") for i in range(256)], np.uint8)


def _descriptor_matches(dq: np.ndarray, dm: np.ndarray, max_dist: int = 56, k: int = 3):
    """Putative matches between two ORB descriptor sets, (n, L, 32) multi-scale (or (n, 32) single scale).

    Every scale of a query feature is compared with every scale of a map feature (scale change between the
    two views); the feature distance is the best pair. Up to the k nearest map features with distance
    <= max_dist are kept per query feature. No ratio test: indoor scenes repeat textures (doors, panels,
    tiles), so true matches are often ambiguous in appearance alone - the 4-DOF RANSAC resolves them.
    All-zero rows (no descriptor could be computed) are ignored."""
    if dq.ndim == 2:
        dq = dq[:, None, :]
    if dm.ndim == 2:
        dm = dm[:, None, :]
    nq, lq = dq.shape[:2]
    nm, lm = dm.shape[:2]
    fq, fm = dq.reshape(-1, 32), dm.reshape(-1, 32)
    vq, vm = np.nonzero(fq.any(axis=1))[0], np.nonzero(fm.any(axis=1))[0]
    if len(vq) < 2 or len(vm) < 2:
        return [], []
    dist_v = _POPCOUNT[np.bitwise_xor(fq[vq][:, None, :], fm[vm][None, :, :])].sum(axis=2, dtype=np.int32)
    full = np.full((nq * lq, nm * lm), 256, np.int32)
    full[np.ix_(vq, vm)] = dist_v
    dist = full.reshape(nq, lq, nm, lm).min(axis=(1, 3))           # best scale pair per feature pair
    kk = min(k, nm)
    nn = np.argsort(dist, axis=1)[:, :kk]
    qi, mj = [], []
    for a in range(nq):
        for b in nn[a]:
            if dist[a, b] <= max_dist:
                qi.append(a)
                mj.append(int(b))
    return qi, mj


def _rz(psi: float) -> np.ndarray:
    c, s = np.cos(psi), np.sin(psi)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def _refine(Q: np.ndarray, M: np.ndarray) -> tuple[float, np.ndarray]:
    """Least-squares yaw + translation (2-D Kabsch in xy, mean offset in z)."""
    qc, mc = Q.mean(0), M.mean(0)
    A = (Q[:, :2] - qc[:2])
    B = (M[:, :2] - mc[:2])
    H = A.T @ B
    psi = float(np.arctan2(H[0, 1] - H[1, 0], H[0, 0] + H[1, 1]))
    Rz = _rz(psi)
    t = mc - Rz @ qc
    return psi, t
