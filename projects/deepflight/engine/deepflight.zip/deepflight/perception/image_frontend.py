"""Image front end: real feature detection and tracking on rendered (or real) grayscale images.

Replaces the simulator's track oracle when a camera stream exists (PX4 + Gazebo). Output is the same
``CameraFrame`` the VIO back end already consumes, so estimation, gating, keyframing and place recognition
are unchanged.

* Detection: FAST with an *absolute* contrast threshold (dark, low-contrast images genuinely yield few
  features - a relative-quality detector would still find "corners" in noise), bucketed on a grid for spread.
* Tracking: pyramidal Lucas-Kanade, forward-backward consistency check (< 1 px), border rejection.
* Depth: nearest sample of the aligned depth image (same FOV, lower resolution), Z-depth in metres.
* Appearance words for place recognition: ORB descriptor computed when a track is born, quantised to the
  nearest of ``vocab`` fixed random binary words (Hamming). Crude compared to a trained DBoW vocabulary, but
  real appearance, and the geometric verification downstream is unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import cv2
import numpy as np

from ..simulation.sensors import CameraFrame, DepthCloud


@dataclass
class FrontEndConfig:
    max_features: int = 120
    fast_threshold: int = 14
    grid: tuple = (8, 6)               # detection buckets (cols, rows)
    min_distance_px: int = 12
    lk_win: int = 21
    lk_levels: int = 3
    fb_max_px: float = 1.0
    border_px: int = 8
    vocab: int = 600
    depth_min: float = 0.35
    desc_levels: int = 3               # ORB descriptor scales for relocalization
    desc_scale: float = 1.5
    depth_max: float = 6.0
    depth_planar_rel: float = 0.25     # max inverse-depth spread in the 2x2 interpolation cell


def depth_at(uv: np.ndarray, depth: np.ndarray, w: int, h: int, dmin: float, dmax: float,
             planar_rel: float = 0.25) -> np.ndarray:
    """Feature depth from the aligned, lower-resolution Z-depth image: bilinear interpolation of *inverse*
    depth at the exact feature position. Inverse depth is affine in pixel coordinates on any plane, so this is
    exact on planar surfaces - including the floor seen at grazing angles from the pad, where the nearest depth
    sample was off by up to 12 % (p90; 1.7 % in the corridor -> 0.7 % interpolated, measured on Gazebo flights).
    Cells whose four inverse depths spread by more than ``planar_rel`` (a depth edge) give no depth."""
    out = np.full(len(uv), np.nan)
    if not len(uv):
        return out
    d = depth.astype(float)
    hd, wd = d.shape
    xd = (uv[:, 0] + 0.5) * wd / w - 0.5           # pixel centres: OpenCV integer coordinates
    yd = (uv[:, 1] + 0.5) * hd / h - 0.5
    x0 = np.clip(np.floor(xd).astype(int), 0, wd - 2)
    y0 = np.clip(np.floor(yd).astype(int), 0, hd - 2)
    fx = np.clip(xd - x0, 0.0, 1.0)
    fy = np.clip(yd - y0, 0.0, 1.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        q = np.stack([1.0 / d[y0 + a, x0 + b] for a in (0, 1) for b in (0, 1)])
        winv = q[0] * (1 - fx) * (1 - fy) + q[1] * fx * (1 - fy) + q[2] * (1 - fx) * fy + q[3] * fx * fy
        z = 1.0 / winv
        planar = np.isfinite(q).all(axis=0) & ((q.max(axis=0) - q.min(axis=0)) <= planar_rel * winv)
    ok = planar & np.isfinite(z) & (z > dmin) & (z < dmax)
    out[ok] = z[ok]
    return out


@dataclass
class FrontEndStats:
    tracked: int = 0
    lost: int = 0
    detected_new: int = 0
    mean_intensity: float = 0.0
    process_ms: float = 0.0
    history: list = field(default_factory=list)


class ImageFrontEnd:
    def __init__(self, fx: float, fy: float, cx: float, cy: float, cfg: FrontEndConfig | None = None, seed: int = 3):
        self.cfg = cfg or FrontEndConfig()
        self.fx, self.fy, self.cx, self.cy = fx, fy, cx, cy
        self.fast = cv2.FastFeatureDetector_create(threshold=self.cfg.fast_threshold, nonmaxSuppression=True)
        self.orb = cv2.ORB_create(nfeatures=500)
        rng = np.random.default_rng(seed)
        self.vocab_bits = rng.integers(0, 2, (self.cfg.vocab, 256), dtype=np.uint8)
        self.prev: np.ndarray | None = None
        self.pts = np.zeros((0, 2), np.float32)
        self.ids = np.zeros(0, np.int64)
        self.words = np.zeros(0, np.int64)
        self.desc = np.zeros((0, self.cfg.desc_levels, 32), np.uint8)
        self.next_id = 1_000_000
        self.stats = FrontEndStats()

    # ------------------------------------------------------------------ helpers
    def _words(self, img: np.ndarray, pts: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Appearance word (level-0 ORB descriptor -> nearest vocabulary word) and ORB descriptors at
        ``desc_levels`` image scales (factor ``desc_scale``), so a feature seen from 1.5-3x closer still matches.
        All-zero descriptor rows mean 'not computable' (too close to the border at that scale)."""
        c = self.cfg
        descs = np.zeros((len(pts), c.desc_levels, 32), np.uint8)
        words = np.full(len(pts), c.vocab - 1, np.int64)               # reserved word for border features
        if len(pts) == 0:
            return words, descs
        im = img
        for lvl in range(c.desc_levels):
            s = c.desc_scale ** lvl
            if lvl:
                im = cv2.resize(img, (int(round(img.shape[1] / s)), int(round(img.shape[0] / s))),
                                interpolation=cv2.INTER_AREA)
            kps = [cv2.KeyPoint(float(x / s), float(y / s), 31, -1, 0, 0, i) for i, (x, y) in enumerate(pts)]
            kps, desc = self.orb.compute(im, kps)
            if desc is None or not len(kps):
                continue
            for kp, d in zip(kps, desc):
                descs[kp.class_id, lvl] = d
            if lvl == 0:
                bits = np.unpackbits(desc, axis=1)                      # (n, 256)
                dist = (bits[:, None, :] != self.vocab_bits[None, :, :]).sum(axis=2)
                for kp, wi in zip(kps, np.argmin(dist, axis=1)):
                    words[kp.class_id] = int(wi)
        return words, descs

    def _detect(self, img: np.ndarray, n_wanted: int) -> np.ndarray:
        if n_wanted <= 0:
            return np.zeros((0, 2), np.float32)
        c = self.cfg
        mask = np.full(img.shape, 255, np.uint8)
        b = c.border_px
        mask[:b, :] = mask[-b:, :] = 0
        mask[:, :b] = mask[:, -b:] = 0
        for x, y in self.pts:
            cv2.circle(mask, (int(x), int(y)), c.min_distance_px, 0, -1)
        kps = self.fast.detect(img, mask)
        if not kps:
            return np.zeros((0, 2), np.float32)
        # strongest per grid bucket first, round-robin over buckets for spatial spread
        h, w = img.shape
        gx, gy = c.grid
        buckets: dict[int, list] = {}
        for kp in sorted(kps, key=lambda k: -k.response):
            key = int(kp.pt[1] * gy / h) * gx + int(kp.pt[0] * gx / w)
            buckets.setdefault(key, []).append(kp)
        out = []
        while len(out) < n_wanted and buckets:
            for key in list(buckets):
                kp = buckets[key].pop(0)
                if not buckets[key]:
                    del buckets[key]
                if all((kp.pt[0] - q[0]) ** 2 + (kp.pt[1] - q[1]) ** 2 >= c.min_distance_px ** 2 for q in out):
                    out.append(kp.pt)
                if len(out) >= n_wanted:
                    break
        return np.array(out, np.float32).reshape(-1, 2)

    # ------------------------------------------------------------------ main
    def process(self, img: np.ndarray, t: float, depth: np.ndarray | None = None) -> CameraFrame:
        import time
        t0 = time.perf_counter()
        c = self.cfg
        h, w = img.shape
        lost = 0
        if self.prev is not None and len(self.pts):
            p0 = self.pts.reshape(-1, 1, 2)
            lk = dict(winSize=(c.lk_win, c.lk_win), maxLevel=c.lk_levels,
                      criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
            p1, st1, _ = cv2.calcOpticalFlowPyrLK(self.prev, img, p0, None, **lk)
            p0r, st2, _ = cv2.calcOpticalFlowPyrLK(img, self.prev, p1, None, **lk)
            fb = np.linalg.norm((p0 - p0r).reshape(-1, 2), axis=1)
            p1 = p1.reshape(-1, 2)
            inside = (p1[:, 0] > c.border_px) & (p1[:, 0] < w - c.border_px) & \
                     (p1[:, 1] > c.border_px) & (p1[:, 1] < h - c.border_px)
            good = (st1.ravel() == 1) & (st2.ravel() == 1) & (fb < c.fb_max_px) & inside
            lost = int((~good).sum())
            self.pts, self.ids, self.words, self.desc = p1[good], self.ids[good], self.words[good], self.desc[good]
        new = self._detect(img, c.max_features - len(self.pts))
        if len(new):
            new_ids = np.arange(self.next_id, self.next_id + len(new), dtype=np.int64)
            self.next_id += len(new)
            self.pts = np.vstack([self.pts, new]).astype(np.float32)
            self.ids = np.concatenate([self.ids, new_ids])
            w_new, d_new = self._words(img, new)
            self.words = np.concatenate([self.words, w_new])
            self.desc = np.vstack([self.desc, d_new])
        self.prev = img
        dep = np.full(len(self.pts), np.nan)
        if depth is not None and len(self.pts):
            dep = depth_at(self.pts, depth, w, h, c.depth_min, c.depth_max, c.depth_planar_rel)
        mean_i = float(img.mean())
        self.stats = FrontEndStats(len(self.pts) - len(new), lost, len(new), mean_i,
                                   (time.perf_counter() - t0) * 1000)
        light = float(np.clip(mean_i / 110.0, 0.0, 1.0))
        return CameraFrame(t, self.ids.copy(), self.pts.astype(float).copy(), dep, self.words.copy(), light, 0.0,
                           desc=self.desc.copy())

    def depth_cloud(self, depth: np.ndarray, t: float, step: int = 5, max_range: float = 6.0,
                    min_range: float = 0.35) -> DepthCloud:
        """Z-depth image -> camera-frame points (+ free-space directions for pixels without a return)."""
        hd, wd = depth.shape
        fxd, fyd = self.fx * wd / (2 * self.cx), self.fy * hd / (2 * self.cy)
        vs, us = np.mgrid[step // 2:hd:step, step // 2:wd:step]
        z = depth[vs, us].astype(float)
        x = (us + 0.5 - wd / 2) / fxd
        y = (vs + 0.5 - hd / 2) / fyd
        dirs = np.stack([x, y, np.ones_like(x)], -1).reshape(-1, 3)
        z = z.ravel()
        # returns closer than min_range are the airframe itself (self-occlusion): neither obstacle nor free space
        hit = np.isfinite(z) & (z > min_range) & (z < max_range)
        pts = dirs[hit] * z[hit, None]
        free = dirs[~hit & ~(np.isfinite(z) & (z <= min_range))]
        free = free / np.linalg.norm(free, axis=1, keepdims=True)
        return DepthCloud(t, pts, free)
