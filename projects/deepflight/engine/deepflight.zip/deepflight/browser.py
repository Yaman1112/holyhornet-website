"""Browser edition: the DeepFlight API without a server, for Pyodide (CPython on WebAssembly) in a Web Worker.

The FastAPI service (``api/app.py``) steps sessions on background threads and streams frames over a WebSocket.
WebAssembly has neither, so here the worker calls ``tick()`` on a timer to advance running sessions, and the
messages the WebSocket would have sent come back as its return value. Requests go through ``request()`` with the
same paths, bodies and responses as the HTTP API, so the web console is unchanged apart from its transport.

Same simulator, estimator, planner, assistant, metrics and exports as the full install. Not available here: the
PX4 SITL backend (needs a MAVLink link to an autopilot) and batch experiments (minutes of blocking compute).
"""
from __future__ import annotations

import csv
import io
import json
import re
import time
import uuid

import numpy as np

from . import SOFTWARE_VERSION
from .autonomy.assistant import answer
from .autonomy.safety import FAULT_CATALOG
from .engine import DeepFlightSim
from .research.metrics import compute_metrics, map_accuracy
from .robotics.autopilot_bridge import preview as autopilot_preview
from .simulation.scenarios import SCENARIOS, list_scenarios

MAX_SESSIONS = 2


class HttpError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status, self.detail = status, detail


class Session:
    def __init__(self, scenario: str, seed: int, overrides: dict | None):
        self.id = uuid.uuid4().hex[:10]
        self.scenario, self.seed, self.overrides = scenario, seed, overrides or {}
        self.sim = DeepFlightSim(scenario, seed, self.overrides, wallclock_monitors=False)
        self.generation = 0
        self.speed = 1.0
        self.running = False
        self.commands: list[dict] = []
        self.created = time.time()
        # stream state for the subscribed console
        self.sent_gen = -1
        self.sent = 0

    def reset(self) -> None:
        self.sim = DeepFlightSim(self.scenario, self.seed, self.overrides, wallclock_monitors=False)
        self.generation += 1
        self.running = False
        self.commands.clear()

    def status(self) -> dict:
        return {"id": self.id, "scenario": self.scenario, "seed": self.seed, "running": self.running,
                "backend": "native", "vehicle": {"backend": "native"}, "speed": self.speed, "t": self.sim.t,
                "finished": self.sim.finished, "generation": self.generation, "frames": len(self.sim.frames),
                "overrides": self.overrides}

    def advance(self, wall_dt: float, budget_s: float) -> None:
        """Advance by ``wall_dt * speed`` of simulated time, within a compute budget (the browser stays responsive;
        if the device is slower than real time the simulation simply runs slower)."""
        if not self.running:
            return
        while self.commands:
            self.sim.command(self.commands.pop(0))
        target = self.sim.t + min(wall_dt, 0.25) * self.speed
        t0 = time.perf_counter()
        while self.sim.t < target - 1e-9 and not self.sim.finished:
            self.sim.step()
            if time.perf_counter() - t0 > budget_s:
                break
        if self.sim.finished:
            self.running = False


SESSIONS: dict[str, Session] = {}
SUBSCRIBED: str | None = None


def _get(sid: str) -> Session:
    s = SESSIONS.get(sid)
    if s is None:
        raise HttpError(404, "session not found")
    return s


def _json_default(o):
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, np.generic):
        return o.item()
    raise TypeError(f"not JSON serialisable: {type(o).__name__}")


# ------------------------------------------------------------------ routes (mirror api/app.py)
def _create(body: dict) -> dict:
    scenario = body.get("scenario", "M1")
    if scenario not in SCENARIOS:
        raise HttpError(400, f"unknown scenario {scenario}")
    if not SCENARIOS[scenario].implemented:
        raise HttpError(400, f"scenario {scenario} is planned, not implemented")
    if body.get("backend", "native") != "native":
        raise HttpError(400, "the PX4 SITL backend needs the full install (a MAVLink link to PX4); "
                             "the browser edition runs the native simulator")
    while len(SESSIONS) >= MAX_SESSIONS:
        oldest = min(SESSIONS.values(), key=lambda s: s.created)
        del SESSIONS[oldest.id]
    try:
        s = Session(scenario, int(body.get("seed", 7)), body.get("overrides") or {})
    except (KeyError, ValueError, RuntimeError) as exc:
        raise HttpError(400, str(exc))
    SESSIONS[s.id] = s
    return s.status() | {"info": s.sim.session_info()}


def _control(s: Session, body: dict) -> dict:
    action, value = body.get("action"), body.get("value")
    if action == "start":
        s.running = True
    elif action == "pause":
        s.running = False
    elif action == "reset":
        s.reset()
    elif action == "speed":
        s.speed = float(np.clip(value or 1.0, 0.1, 16.0))
    elif action == "step":
        s.sim.run_until(s.sim.t + (value or 0.1))
    else:
        raise HttpError(400, "unknown action")
    return s.status()


def _command(s: Session, cmd: dict) -> dict:
    if cmd.get("type") not in ("set_goal", "inject_fault", "clear_fault", "operator_decision", "heartbeat"):
        raise HttpError(400, "unknown command type")
    if s.running:
        s.commands.append(cmd)
        return {"ok": True, "queued": True}
    return s.sim.command(cmd)


def _trajectory_csv(s: Session) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["t", "truth_x", "truth_y", "truth_z", "est_x", "est_y", "est_z", "sigma_x", "sigma_y", "sigma_z",
                "state", "mode", "behaviour", "vio_inliers"])
    for r in s.sim.records:
        c = np.sqrt(np.clip(np.diag(r["cov"]), 0, None))
        w.writerow([f"{r['t']:.2f}", *[f"{v:.4f}" for v in r["truth"]], *[f"{v:.4f}" for v in r["est"]],
                    *[f"{v:.4f}" for v in c], r["state"], r["mode"], r["behaviour"], r["inliers"]])
    return buf.getvalue()


def _session_json(s: Session) -> dict:
    info = s.sim.session_info()
    info.pop("world", None)
    return {"session": s.status(), "info": info, "events": s.sim.events,
            "metrics": compute_metrics(s.sim) | map_accuracy(s.sim),
            "place_events": s.sim.loc.place_events, "replans": s.sim.replan_reasons,
            "ground_truth_note": "truth values are simulation ground truth used for validation only"}


def _route(method: str, path: str, query: dict, body: dict):
    if method == "GET" and path == "/api/health":
        return {"ok": True, "version": SOFTWARE_VERSION, "mode": "SIMULATION (browser edition)",
                "sessions": len(SESSIONS)}
    if method == "GET" and path == "/api/scenarios":
        return list_scenarios()
    if method == "GET" and path == "/api/faults":
        return FAULT_CATALOG
    if path == "/api/sessions":
        if method == "POST":
            return _create(body)
        return [s.status() for s in SESSIONS.values()]
    if path.startswith("/api/experiments"):
        if method == "GET" and path == "/api/experiments":
            return []
        raise HttpError(501, "Batch experiments run minutes of compute and need the full install "
                             "(python -m deepflight.research.validate); this browser edition runs live sessions.")
    m = re.fullmatch(r"/api/sessions/([0-9a-f]+)(/.*)?", path)
    if not m:
        raise HttpError(404, "not found")
    s = _get(m.group(1))
    sub = m.group(2) or ""
    if sub == "" and method == "GET":
        return s.status() | {"info": s.sim.session_info()}
    if sub == "/control" and method == "POST":
        return _control(s, body)
    if sub == "/command" and method == "POST":
        return _command(s, body)
    if sub == "/frames":
        start = int(query.get("start", 0))
        end = int(query["end"]) if "end" in query else None
        return {"generation": s.generation, "start": start, "frames": s.sim.frames[start:end]}
    if sub == "/voxels":
        return {"occupied": s.sim.occupied_voxels(), "frame_index": len(s.sim.frames)}
    if sub == "/keyframes":
        return s.sim.keyframe_list()
    if sub == "/events":
        return s.sim.events
    if sub == "/metrics":
        return compute_metrics(s.sim) | map_accuracy(s.sim)
    if sub == "/autopilot_preview":
        return autopilot_preview(s.sim)
    if sub == "/assistant" and method == "POST":
        return answer(s.sim, str(body.get("question", "")))
    if sub == "/export/trajectory.csv":
        return ("text/csv", _trajectory_csv(s))
    if sub == "/export/session.json":
        return _session_json(s)
    raise HttpError(404, "not found")


def request(method: str, url: str, body_text: str | None = None) -> str:
    """HTTP-shaped call -> JSON string {status, type, body}."""
    path, _, qs = url.partition("?")
    query = dict(p.split("=", 1) for p in qs.split("&") if "=" in p)
    try:
        body = json.loads(body_text) if body_text else {}
        out = _route(method.upper(), path, query, body)
        if isinstance(out, tuple):
            return json.dumps({"status": 200, "type": out[0], "body": out[1]})
        return json.dumps({"status": 200, "type": "application/json",
                           "body": json.dumps(out, default=_json_default)})
    except HttpError as e:
        return json.dumps({"status": e.status, "type": "application/json", "body": json.dumps({"detail": e.detail})})
    except Exception as e:  # surfaced to the console like a 500
        return json.dumps({"status": 500, "type": "application/json",
                           "body": json.dumps({"detail": f"{type(e).__name__}: {e}"})})


def subscribe(sid: str | None) -> None:
    """The console's live stream now follows ``sid`` (replaces the WebSocket connect)."""
    global SUBSCRIBED
    SUBSCRIBED = sid
    s = SESSIONS.get(sid) if sid else None
    if s is not None:
        s.sent_gen = -1


def tick(wall_dt: float, budget_s: float = 0.06) -> str:
    """Advance running sessions and return the stream messages for the subscribed session (JSON list), exactly
    as the WebSocket in api/app.py sends them: init + history on (re)subscribe or reset, then frames/status."""
    for s in list(SESSIONS.values()):
        s.advance(wall_dt, budget_s / max(1, sum(x.running for x in SESSIONS.values())))
    s = SESSIONS.get(SUBSCRIBED) if SUBSCRIBED else None
    if s is None:
        return "[]"
    msgs = []
    if s.sent_gen != s.generation:
        s.sent_gen = s.generation
        s.sent = len(s.sim.frames)
        hist = s.sim.frames[:s.sent]
        msgs.append({"type": "init", "status": s.status(), "info": s.sim.session_info(),
                     "occupied": s.sim.occupied_voxels(), "frame_index": len(s.sim.frames)})
        for i in range(0, len(hist), 200):
            msgs.append({"type": "history", "start": i, "frames": hist[i:i + 200]})
    new = s.sim.frames[s.sent:]
    s.sent += len(new)
    msgs.append({"type": "frames", "frames": new, "status": s.status()} if new
                else {"type": "status", "status": s.status()})
    return json.dumps(msgs, default=_json_default)


def boot() -> dict:
    return {"version": SOFTWARE_VERSION, "scenarios": len(SCENARIOS), "mode": "browser"}
