"""Ground-truth quadrotor dynamics and the emulated autopilot (PX4-style cascaded controller).

The autopilot closes its position/velocity loops on the *estimated* state supplied by the
companion computer - exactly like an external-vision setup on a real vehicle - so estimation
error produces real (simulated) trajectory error. Its attitude loop uses the true attitude
(on hardware that is the flight controller's own AHRS, which DeepFlight never bypasses).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import AircraftConfig
from ..core.frames import GRAVITY, rot_from_ypr, wrap_angle

G = 9.81


@dataclass
class TruthState:
    p: np.ndarray
    v: np.ndarray
    yaw: float
    pitch: float = 0.0
    roll: float = 0.0
    omega_b: np.ndarray = field(default_factory=lambda: np.zeros(3))
    acc_w: np.ndarray = field(default_factory=lambda: np.zeros(3))
    landed: bool = True

    @property
    def R(self) -> np.ndarray:
        return rot_from_ypr(self.yaw, self.pitch, self.roll)


@dataclass
class Setpoint:
    """Interface between DeepFlight navigation and the autopilot (see robotics/autopilot)."""
    mode: str = "idle"                 # idle | position | velocity | altitude | land
    position: np.ndarray | None = None
    velocity: np.ndarray | None = None
    accel: np.ndarray | None = None    # altitude mode: horizontal acceleration request (level otherwise)
    yaw: float | None = None
    yaw_rate: float = 0.0


class QuadrotorSim:
    def __init__(self, cfg: AircraftConfig, start: np.ndarray, yaw: float, rng: np.random.Generator):
        self.cfg = cfg
        self.rng = rng
        self.ground_z = 0.12
        p0 = np.array(start, float)
        p0[2] = max(p0[2], self.ground_z)
        self.s = TruthState(p=p0, v=np.zeros(3), yaw=yaw)
        self.thrust = 0.0
        self.gust = np.zeros(3)
        self.drag = 0.35

    def step(self, dt: float, roll_cmd: float, pitch_cmd: float, yaw_rate_cmd: float, thrust_acc: float) -> None:
        s, cfg = self.s, self.cfg
        tau = cfg.attitude_time_constant_s
        max_tilt = np.deg2rad(cfg.max_tilt_deg)
        roll_cmd = float(np.clip(roll_cmd, -max_tilt, max_tilt))
        pitch_cmd = float(np.clip(pitch_cmd, -max_tilt, max_tilt))
        yaw_rate_cmd = float(np.clip(yaw_rate_cmd, -np.deg2rad(cfg.max_yaw_rate_dps), np.deg2rad(cfg.max_yaw_rate_dps)))

        if s.landed and thrust_acc < G * 1.02:
            s.v[:] = 0.0
            s.acc_w = np.zeros(3)
            s.omega_b = np.zeros(3)
            s.roll = s.pitch = 0.0
            s.p[2] = self.ground_z
            return
        s.landed = False

        droll = (roll_cmd - s.roll) / tau
        dpitch = (pitch_cmd - s.pitch) / tau
        dyaw = yaw_rate_cmd
        r, pch = s.roll, s.pitch
        s.omega_b = np.array([
            droll - dyaw * np.sin(pch),
            dpitch * np.cos(r) + dyaw * np.sin(r) * np.cos(pch),
            -dpitch * np.sin(r) + dyaw * np.cos(r) * np.cos(pch),
        ])
        s.roll += droll * dt
        s.pitch += dpitch * dt
        s.yaw = wrap_angle(s.yaw + dyaw * dt)

        # slowly varying indoor air disturbance (HVAC / ground effect), Ornstein-Uhlenbeck
        self.gust += -0.5 * self.gust * dt + self.rng.normal(0.0, 0.08, 3) * np.sqrt(dt)
        R = s.R
        acc = R[:, 2] * thrust_acc + GRAVITY - self.drag * s.v + self.gust
        s.acc_w = acc
        s.p = s.p + s.v * dt + 0.5 * acc * dt * dt
        s.v = s.v + acc * dt
        if s.p[2] <= self.ground_z and s.v[2] <= 0.0:
            s.p[2] = self.ground_z
            s.v[:] = 0.0
            s.landed = True


class Autopilot:
    """Cascaded position -> velocity -> acceleration -> attitude/thrust controller."""

    def __init__(self, cfg: AircraftConfig):
        self.cfg = cfg
        self.kp = np.array([1.1, 1.1, 1.6])
        self.kv = np.array([2.2, 2.2, 3.0])
        self.armed = False

    def compute(self, sp: Setpoint, p_est: np.ndarray, v_est: np.ndarray, yaw_est: float,
                landed: bool) -> tuple[float, float, float, float]:
        cfg = self.cfg
        if sp.mode == "idle" or not self.armed:
            return 0.0, 0.0, 0.0, 0.0
        if sp.mode == "altitude":
            # Position-estimate-independent fallback (PX4 ALTCTL-like): level attitude plus an optional
            # horizontal acceleration request, vertical loop on the (rangefinder-aided) height estimate.
            a = np.zeros(3) if sp.accel is None else np.array(sp.accel, float)
            vz_des = np.clip(self.kp[2] * (sp.position[2] - p_est[2]), -0.6, 0.6) if sp.position is not None else 0.0
            a[2] = np.clip(self.kv[2] * (vz_des - v_est[2]), -2.0, 2.5)
            an = np.linalg.norm(a[:2])
            if an > 1.0:
                a[:2] *= 1.0 / an
            return self._attitude(a, yaw_est, sp)
        if sp.mode == "land" and sp.accel is not None:
            if landed:
                return 0.0, 0.0, 0.0, 0.0
            a = np.array(sp.accel, float)
            a[2] = np.clip(self.kv[2] * (-0.35 - v_est[2]), -2.0, 2.5)
            return self._attitude(a, yaw_est, sp)
        if sp.mode == "land":
            v_des = np.array([0.0, 0.0, -0.35 if not landed else -0.6])
            if sp.velocity is not None:
                v_des[:2] = sp.velocity[:2]
            if landed:
                return 0.0, 0.0, 0.0, 0.0
        elif sp.mode == "position":
            v_des = self.kp * (sp.position - p_est)
            if sp.velocity is not None:
                v_des = v_des + sp.velocity
        else:
            v_des = np.zeros(3) if sp.velocity is None else sp.velocity.copy()
            if sp.position is not None:          # hold altitude while flying velocity setpoints
                v_des[2] += self.kp[2] * (sp.position[2] - p_est[2])
        vmax = cfg.max_speed_ms
        hn = np.linalg.norm(v_des[:2])
        if hn > vmax:
            v_des[:2] *= vmax / hn
        v_des[2] = np.clip(v_des[2], -0.8, 1.0)
        a_des = self.kv * (v_des - v_est)
        an = np.linalg.norm(a_des[:2])
        if an > cfg.max_accel_ms2:
            a_des[:2] *= cfg.max_accel_ms2 / an
        a_des[2] = np.clip(a_des[2], -2.5, 3.0)
        return self._attitude(a_des, yaw_est, sp)

    def _attitude(self, a_des: np.ndarray, yaw_est: float, sp: Setpoint) -> tuple[float, float, float, float]:
        c, s = np.cos(yaw_est), np.sin(yaw_est)
        a_fwd = c * a_des[0] + s * a_des[1]
        a_left = -s * a_des[0] + c * a_des[1]
        az = G + a_des[2]
        pitch = np.arctan2(a_fwd, az)
        roll = np.arctan2(-a_left * np.cos(pitch), az)
        thrust = az / max(np.cos(pitch) * np.cos(roll), 0.5)
        if sp.yaw is not None:
            yaw_rate = 1.8 * wrap_angle(sp.yaw - yaw_est)
        else:
            yaw_rate = sp.yaw_rate
        return float(roll), float(pitch), float(yaw_rate), float(thrust)
