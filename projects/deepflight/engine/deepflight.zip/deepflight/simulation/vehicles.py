"""Vehicle backends: who flies the aircraft.

* ``NativeVehicle`` - DeepFlight's kinematic quadrotor + emulated autopilot (fast, deterministic).
* ``Px4Vehicle``   - PX4 SITL (SIH or Gazebo physics + the real PX4 flight stack) over MAVLink. DeepFlight
  keeps its own virtual building and sensor models; the aircraft's true pose comes from PX4's
  simulator ground truth, DeepFlight sends ODOMETRY (its estimate) and offboard setpoints. Runs in
  real time.

Both expose ``s`` (TruthState in the building ``map`` frame), ``armed`` and ``step(t, dt, setpoint, est)``.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np

from ..config import AircraftConfig
from ..core.frames import R_FRD_FLU, R_NED_ENU, quat_from_rot, rot_flu_enu_to_frd_ned, rot_z, wrap_angle, \
    ypr_from_rot
from ..robotics.autopilot_bridge import odometry_message, velocity_setpoint_message
from .dynamics import G, Autopilot, QuadrotorSim, Setpoint, TruthState


@dataclass
class EstimateView:
    """What the companion computer knows (never truth)."""
    p: np.ndarray
    v: np.ndarray
    R: np.ndarray
    cov: np.ndarray
    integrity: str
    segment: int
    cov_vel: np.ndarray | None = None
    velocity_valid: bool = False

    @property
    def yaw(self) -> float:
        return float(np.arctan2(self.R[1, 0], self.R[0, 0]))


class NativeVehicle:
    kind = "native"

    def __init__(self, cfg: AircraftConfig, start: np.ndarray, yaw: float, rng: np.random.Generator):
        self.quad = QuadrotorSim(cfg, start, yaw, rng)
        self.autopilot = Autopilot(cfg)

    @property
    def s(self) -> TruthState:
        return self.quad.s

    @property
    def armed(self) -> bool:
        return self.autopilot.armed

    @armed.setter
    def armed(self, v: bool) -> None:
        self.autopilot.armed = v

    def step(self, t: float, dt: float, sp: Setpoint, est: EstimateView) -> None:
        roll, pitch, yaw_rate, thrust = self.autopilot.compute(sp, est.p, est.v, est.yaw, self.s.landed)
        self.thrust = thrust
        self.quad.step(dt, roll, pitch, yaw_rate, thrust)

    ready = True

    def crash(self) -> None:
        self.s.v[:] = 0.0
        self.s.landed = True
        self.s.p[2] = 0.12

    def status(self) -> dict:
        return {"backend": "native", "armed": self.armed}


class FrameAligner:
    """Building ``map`` frame <-> PX4 local ENU frame (origin = PX4 spawn point).

    map = start_map + Rz(delta) * enu_px4,  yaw_map = yaw_enu_px4 + delta, with delta chosen so the
    vehicle's initial heading equals the scenario's start heading.
    """

    def __init__(self, start_map: np.ndarray, start_yaw_map: float, yaw0_enu_px4: float):
        self.start = np.array(start_map, float)
        self.delta = wrap_angle(start_yaw_map - yaw0_enu_px4)
        self.Rz = rot_z(self.delta)

    def p_to_map(self, p_enu: np.ndarray) -> np.ndarray:
        return self.start + self.Rz @ p_enu

    def v_to_map(self, v_enu: np.ndarray) -> np.ndarray:
        return self.Rz @ v_enu

    def R_to_map(self, R_enu: np.ndarray) -> np.ndarray:
        return self.Rz @ R_enu

    def p_to_px4(self, p_map: np.ndarray) -> np.ndarray:
        return self.Rz.T @ (p_map - self.start)

    def v_to_px4(self, v_map: np.ndarray) -> np.ndarray:
        return self.Rz.T @ v_map

    def R_to_px4(self, R_map: np.ndarray) -> np.ndarray:
        return self.Rz.T @ R_map

    def cov_to_px4(self, C_map: np.ndarray) -> np.ndarray:
        return self.Rz.T @ C_map @ self.Rz

    def yaw_to_px4(self, yaw_map: float) -> float:
        return wrap_angle(yaw_map - self.delta)


def quat_to_rot(q: np.ndarray) -> np.ndarray:
    w, x, y, z = q / np.linalg.norm(q)
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


class Px4Vehicle:
    kind = "px4_sitl"

    def __init__(self, link, cfg: AircraftConfig, start_map: np.ndarray, start_yaw: float, *,
                 odom_hz: float = 30.0, setpoint_hz: float = 50.0, log=None, clock=time.monotonic,
                 autopilot_imu: bool = False, image_link=None, frontend=None):
        """``autopilot_imu``: feed DeepFlight's estimator with PX4's IMU (HIGHRES_IMU) instead of an IMU synthesised
        by differentiating ground-truth velocity - as a real companion computer would. Used with Gazebo; SIH's IMU
        noise model (accel sigma up to 1.7 m/s^2) is unrealistically large."""
        self.autopilot_imu = autopilot_imu
        self._imu_t_prev: float | None = None
        self.image_link = image_link
        self.frontend = frontend
        self._img_seq = -1
        self._depth_seq = -1
        self.camera_stats = {"frames": 0, "latency_ms": [], "features": [], "frontend_ms": []}
        self.link = link
        self.cfg = cfg
        self.start = np.array(start_map, float)
        self.start_yaw = start_yaw
        self.ground_z = float(self.start[2])      # body height standing on the pad (landing gear)
        self.s = TruthState(p=self.start.copy(), v=np.zeros(3), yaw=start_yaw)
        self.aligner: FrameAligner | None = None
        self.origin = None
        self.hover_thrust = 0.5
        self.odom_period = 1.0 / odom_hz
        self.sp_period = 1.0 / setpoint_hz
        self._next_odom = 0.0
        self._next_sp = 0.0
        self._next_hb = 0.0
        self._armed_req = False
        self._arm_phase_t: float | None = None
        self._last_truth_t: float | None = None
        self._v_prev: np.ndarray | None = None
        self._t_px4_prev: float | None = None
        self.log = log or (lambda *a, **k: None)
        self.clock = clock
        self.stats = {"odom_sent": 0, "odom_withheld": 0, "setpoints_sent": 0, "attitude_sent": 0,
                      "truth_msgs": 0, "arm_attempts": 0}
        self.ekf_error = None           # PX4 EKF2 position minus DeepFlight estimate (map frame)
        self._agree_since: float | None = None
        self._thr_int = 0.0
        self._last_sp_kind = ""
        self._was_in_control = False
        self._odom_content = "pose+velocity"
        self._px4_vel_ok_since: float | None = None
        self._odom_vel_since: float | None = None     # DeepFlight has been sending velocity odometry since
        self.autopilot_override = False     # PX4 failsafe / pilot has control
        self.handed_off = False             # DeepFlight deliberately handed control to a PX4 mode (landing)
        self.thrust = 0.0

    # ------------------------------------------------------------------ state
    @property
    def armed(self) -> bool:
        return self._armed_req

    @armed.setter
    def armed(self, v: bool) -> None:
        if v and not self._armed_req:
            self._arm_phase_t = None
        if not v and self._armed_req and self.link.state.armed:
            self.link.arm(False)
        self._armed_req = v

    @property
    def camera_source(self) -> bool:
        return self.image_link is not None and self.frontend is not None

    def camera_frame(self, t_engine: float):
        """Newest rendered frame through the image front end, or None if nothing new arrived."""
        g = self.image_link.get(1)
        if g is None or g.seq == self._img_seq:
            return None
        self._img_seq = g.seq
        d = self.image_link.get(2)
        frame = self.frontend.process(g.data, t_engine, None if d is None else d.data)
        cs = self.camera_stats
        cs["frames"] += 1
        if self._imu_t_prev is not None:          # PX4 IMU time and Gazebo image stamps share the sim clock
            cs["latency_ms"].append(1000.0 * (self._imu_t_prev - g.stamp))
        cs["features"].append(len(frame.ids))
        cs["frontend_ms"].append(self.frontend.stats.process_ms)
        for k in ("latency_ms", "features", "frontend_ms"):
            del cs[k][:-2000]
        return frame

    def depth_cloud(self, t_engine: float):
        d = self.image_link.get(2)
        if d is None or d.seq == self._depth_seq:
            return None
        self._depth_seq = d.seq
        return self.frontend.depth_cloud(d.data, t_engine)

    def pop_imu(self, t_engine: float) -> list:
        """New autopilot IMU samples as (ImuSample in FLU, dt from PX4 sample times)."""
        from .sensors import ImuSample
        out = []
        q = self.link.state.imu_queue
        while q:
            t_px4, acc_frd, gyro_frd = q.pop(0)
            if self._imu_t_prev is None or t_px4 <= self._imu_t_prev:
                self._imu_t_prev = t_px4 if self._imu_t_prev is None else self._imu_t_prev
                continue
            dt = min(t_px4 - self._imu_t_prev, 0.05)
            self._imu_t_prev = t_px4
            out.append((ImuSample(t_engine, R_FRD_FLU @ acc_frd, R_FRD_FLU @ gyro_frd), dt))
        return out

    @property
    def ready(self) -> bool:
        """PX4's EKF2 is fusing DeepFlight's vision: its position has agreed with DeepFlight's estimate (< 0.3 m
        horizontally) for 3 s. PX4's SYS_STATUS pre-arm bit refers to the *current* mode (Position mode, which
        needs RC), not OFFBOARD, so it is reported but not required; PX4 still makes the arming decision."""
        if self.aligner is None:
            return False
        if self.link.state.prearm_ok:
            return True
        return self._agree_since is not None and self.clock() - self._agree_since > 3.0

    def wait_ready(self, timeout: float = 30.0) -> bool:
        """Block until truth is streaming and the frame alignment is established."""
        t0 = self.clock()
        while self.clock() - t0 < timeout:
            self.link.send_heartbeat()
            self.link.poll()
            self._update_truth(self.clock())
            if self.aligner is not None:
                return True
            time.sleep(0.05)
        return False

    def _update_truth(self, now: float) -> None:
        tr = self.link.state.truth
        if tr is None or (self._last_truth_t is not None and tr.t_wall <= self._last_truth_t):
            return
        from ..robotics.px4_link import geodetic_to_enu
        R_ned_frd = quat_to_rot(tr.q)
        R_enu_flu = R_NED_ENU.T @ R_ned_frd @ R_FRD_FLU
        if self.aligner is None:
            self.origin = (tr.lat, tr.lon, tr.alt)
            yaw0 = float(np.arctan2(R_enu_flu[1, 0], R_enu_flu[0, 0]))
            self.aligner = FrameAligner(self.start, self.start_yaw, yaw0)
            self.log("vehicle", "info", f"PX4 frame aligned: heading offset {np.rad2deg(self.aligner.delta):.1f} deg")
        A = self.aligner
        enu = geodetic_to_enu(tr.lat, tr.lon, tr.alt, *self.origin)
        v_enu = R_NED_ENU.T @ tr.v_ned
        s = self.s
        s.p = A.p_to_map(enu)
        s.v = A.v_to_map(v_enu)
        Rm = A.R_to_map(R_enu_flu)
        s.yaw, s.pitch, s.roll = ypr_from_rot(Rm)
        s.omega_b = R_FRD_FLU @ tr.omega_frd
        # acceleration for DeepFlight's simulated IMU: differentiate truth velocity. PX4 v1.15 sends
        # HIL_STATE_QUATERNION.time_usec = 0, so arrival time is used (measured jitter: 0.5 ms std at 50 Hz)
        t_sample = tr.t_px4 if tr.t_px4 > 0 else tr.t_wall
        if self._v_prev is not None and self._t_px4_prev is not None and t_sample > self._t_px4_prev:
            dt = t_sample - self._t_px4_prev
            # clip like a real accelerometer range: finite differences across ground-contact impulses (Gazebo
            # touchdown) otherwise produce 100+ m/s^2 spikes that no IMU on this airframe would report
            acc = np.clip((s.v - self._v_prev) / dt, -20.0, 20.0)
            s.acc_w = 0.7 * s.acc_w + 0.3 * acc
        self._v_prev = s.v.copy()
        self._t_px4_prev = t_sample
        self._last_truth_t = tr.t_wall
        self.stats["truth_msgs"] += 1
        on_ground = self.link.state.landed_state == 1 or (not self.link.state.armed and s.p[2] < self.start[2] + 0.25)
        s.landed = bool(on_ground)
        ekf = self.link.state.ekf_local_ned
        if ekf is not None:
            self.ekf_p_map = A.p_to_map(R_NED_ENU.T @ ekf[:3])

    # ------------------------------------------------------------------ control
    def _velocity_command(self, sp: Setpoint, est: EstimateView) -> tuple[np.ndarray, float | None, float]:
        kp = np.array([1.1, 1.1, 1.6])
        if sp.mode == "position" and sp.position is not None:
            v = kp * (sp.position - est.p) + (sp.velocity if sp.velocity is not None else 0)
        else:
            v = np.zeros(3) if sp.velocity is None else np.array(sp.velocity, float)
            if sp.mode == "land":
                v[2] = -0.35
            elif sp.position is not None:
                v[2] += kp[2] * (sp.position[2] - est.p[2])
        hn = np.linalg.norm(v[:2])
        if hn > self.cfg.max_speed_ms:
            v[:2] *= self.cfg.max_speed_ms / hn
        v[2] = float(np.clip(v[2], -0.8, 1.0))
        return v, sp.yaw, sp.yaw_rate

    def _attitude_command(self, sp: Setpoint, est: EstimateView) -> tuple[np.ndarray, float]:
        """Level attitude + horizontal acceleration request, thrust from DeepFlight's height loop."""
        a = np.zeros(3) if sp.accel is None else np.array(sp.accel, float)
        if sp.mode == "land":
            vz_des = -0.35
        else:
            z_ref = sp.position[2] if sp.position is not None else est.p[2]
            vz_des = float(np.clip(1.6 * (z_ref - est.p[2]), -0.6, 0.6))
        vz_err = vz_des - est.v[2]
        # integral term: absorbs hover-thrust error so the vehicle really climbs / descends as asked
        self._thr_int = float(np.clip(self._thr_int + 0.08 * vz_err * self.sp_period, -0.25, 0.25))
        a[2] = float(np.clip(3.0 * vz_err, -2.0, 2.5))
        a_px4 = self.aligner.v_to_px4(a)
        yaw_map = sp.yaw if sp.yaw is not None else est.yaw
        yaw = self.aligner.yaw_to_px4(yaw_map)
        c, s = np.cos(yaw), np.sin(yaw)
        a_fwd = c * a_px4[0] + s * a_px4[1]
        a_left = -s * a_px4[0] + c * a_px4[1]
        az = G + a_px4[2]
        pitch = np.arctan2(a_fwd, az)
        roll = np.arctan2(-a_left * np.cos(pitch), az)
        from ..core.frames import rot_from_ypr
        R_enu = rot_from_ypr(yaw, pitch, roll)
        q_ned = quat_from_rot(rot_flu_enu_to_frd_ned(R_enu))
        thrust = (self.hover_thrust * az / G + self._thr_int) / max(np.cos(pitch) * np.cos(roll), 0.5)
        # touchdown: below 0.25 m (rangefinder-aided height) ramp thrust down so PX4's land detector can
        # confirm the landing and disarm
        if sp.mode == "land" and est.p[2] - self.ground_z < 0.25:
            self._land_cut = min(getattr(self, "_land_cut", 0.0) + 0.5 * self.sp_period, 1.0)
            thrust = thrust * (1.0 - self._land_cut) + 0.05 * self._land_cut
        else:
            self._land_cut = 0.0
        return q_ned, float(thrust)

    def step(self, t: float, dt: float, sp: Setpoint, est: EstimateView) -> None:
        now = self.clock()
        link = self.link
        link.poll()
        self._update_truth(now)
        if self.aligner is None:
            return
        A = self.aligner
        if now >= self._next_hb:
            link.send_heartbeat()
            self._next_hb = now + 1.0
        # external vision: only a valid estimate is forwarded (quality 0 -> withheld)
        if now >= self._next_odom:
            self._next_odom = now + self.odom_period
            msg = odometry_message(t, A.p_to_px4(est.p), A.v_to_px4(est.v), A.R_to_px4(est.R),
                                   A.cov_to_px4(est.cov), est.integrity, est.segment,
                                   None if est.cov_vel is None else A.cov_to_px4(est.cov_vel),
                                   velocity_valid=est.velocity_valid)
            self._odom_content = msg["content"]
            if msg["content"] == "velocity":
                self.stats["odom_velocity_only"] = self.stats.get("odom_velocity_only", 0) + 1
            if msg["send"]:
                self._odom_vel_since = self._odom_vel_since or now
            else:
                self._odom_vel_since = None
            if msg["send"]:
                link.send_odometry(msg)
                self.stats["odom_sent"] += 1
            else:
                self.stats["odom_withheld"] += 1
            if getattr(self, "ekf_p_map", None) is not None:
                self.ekf_error = self.ekf_p_map - est.p
                agree = float(np.linalg.norm(self.ekf_error[:2])) < 0.3
                if agree and self._agree_since is None:
                    self._agree_since = now
                elif not agree:
                    self._agree_since = None
        if now >= self._next_sp:
            self._next_sp = now + self.sp_period
            # PX4 can only execute velocity setpoints with a valid velocity estimate: if DeepFlight is not
            # sending one, fly attitude setpoints (DeepFlight closes its own loops) instead
            st = link.state
            px4_vel_ok = st.vel_horiz_valid and now - st.vel_valid_t < 0.5
            if px4_vel_ok:
                self._px4_vel_ok_since = self._px4_vel_ok_since or now
            else:
                self._px4_vel_ok_since = None
            # require PX4's velocity to have been valid for 1 s (its EKF re-validates after vision returns) AND
            # DeepFlight to have been sending velocity odometry for 1 s. PX4 keeps reporting a dead-reckoned
            # velocity as valid until its no-aiding timeout (~4.5 s): resuming velocity setpoints on that alone, just
            # before the timeout, made PX4 declare the offboard signal lost and fail safe (Gazebo M1 7302, ulog)
            vel_setpoints_ok = (self._px4_vel_ok_since is not None and now - self._px4_vel_ok_since > 1.0
                                and self._odom_vel_since is not None and now - self._odom_vel_since > 1.0)
            # landing without a valid velocity: hand the descent to PX4 (its Land/Descend modes work without a
            # position estimate and its land detector confirms touchdown) - a logged, deliberate handover
            # landing without a valid PX4 velocity: DeepFlight descends on attitude + thrust itself (handing the
            # descent to a PX4 mode that runs on a stale position estimate let the aircraft wander - seen in Gazebo)
            if sp.mode == "land" and not vel_setpoints_ok and sp.accel is None and not self.s.landed:
                sp = Setpoint("land", accel=np.zeros(3), yaw=sp.yaw)
            if not vel_setpoints_ok and sp.mode in ("velocity", "position", "land") and sp.accel is None                     and not self.s.landed:
                v_des, yaw_des, _ = self._velocity_command(sp, est)
                sp = Setpoint("altitude", position=np.array([0.0, 0.0, est.p[2] + v_des[2] / 1.6]),
                              accel=np.clip(2.2 * (v_des - est.v), -1.0, 1.0) * np.array([1.0, 1.0, 0.0]),
                              yaw=yaw_des)
            if sp.mode in ("altitude",) or (sp.mode == "land" and sp.accel is not None):
                if self._last_sp_kind != "attitude":
                    self._thr_int = 0.0
                self._last_sp_kind = "attitude"
                q, thr = self._attitude_command(sp, est)
                self.thrust = thr * G / max(self.hover_thrust, 1e-3)
                link.send_attitude_target(q, thr)
                self.stats["attitude_sent"] += 1
            else:
                if sp.mode == "idle":
                    v, yaw, yr = np.zeros(3), None, 0.0
                else:
                    v, yaw, yr = self._velocity_command(sp, est)
                self._last_sp_kind = "velocity"
                m = velocity_setpoint_message(t, A.v_to_px4(v), None if yaw is None else A.yaw_to_px4(yaw), yr)
                link.send_velocity_setpoint(m)
                self.thrust = G
                self.stats["setpoints_sent"] += 1
        # Once airborne under DeepFlight control, losing OFFBOARD means PX4 (failsafe) or a pilot took over:
        # never silently take control back - that needs an explicit operator decision (allow_reengage()).
        if link.state.armed and link.state.offboard and not self.s.landed:
            self._was_in_control = True
        if self._was_in_control and not link.state.offboard and not self.autopilot_override and not self.handed_off:
            self.autopilot_override = True
            self.log("vehicle", "critical", "PX4 left OFFBOARD in flight (autopilot failsafe or pilot); DeepFlight "
                     "will not re-take control without an operator decision")
        # arming sequence: stream setpoints >= 1 s, switch to OFFBOARD, arm; retry every 2 s
        if self._armed_req and not self.autopilot_override and not (link.state.armed and link.state.offboard):
            if self._arm_phase_t is None:
                self._arm_phase_t = now
            elif now - self._arm_phase_t > 1.0:
                link.set_offboard()
                link.arm(True)
                self.stats["arm_attempts"] += 1
                self._arm_phase_t = now + 1.0

    def allow_reengage(self) -> None:
        """Operator decision: let DeepFlight request OFFBOARD again after an autopilot takeover."""
        self.autopilot_override = False
        self._was_in_control = False
        self._arm_phase_t = None
        self.log("operator", "warning", "Operator allowed DeepFlight to re-engage OFFBOARD control")

    def crash(self) -> None:
        self.link.command(21)   # MAV_CMD_NAV_LAND
        self.log("vehicle", "critical", "Virtual collision with the DeepFlight building model: commanding PX4 to land")

    def status(self) -> dict:
        st = self.link.state
        return {"backend": "px4_sitl", "connected": st.connected, "armed": st.armed, "offboard": st.offboard,
                "landed_state": st.landed_state, "hover_thrust": self.hover_thrust,
                "autopilot_override": self.autopilot_override, "handed_off_to_px4": self.handed_off,
                "camera": None if not self.camera_source else {
                    "frames": self.camera_stats["frames"],
                    "latency_ms_median": round(float(np.median(self.camera_stats["latency_ms"])), 1)
                    if self.camera_stats["latency_ms"] else None,
                    "features_median": int(np.median(self.camera_stats["features"])) if self.camera_stats["features"] else None,
                    "frontend_ms_median": round(float(np.median(self.camera_stats["frontend_ms"])), 1)
                    if self.camera_stats["frontend_ms"] else None},
                "heading_offset_deg": None if self.aligner is None else round(float(np.rad2deg(self.aligner.delta)), 1),
                "ekf2_minus_deepflight_m": None if self.ekf_error is None else np.round(self.ekf_error, 3).tolist(),
                **self.stats, "statustext": st.statustexts[-5:]}
