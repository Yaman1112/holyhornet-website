"""Ground-truth simulated environment: axis-aligned geometry, visual landmarks, lighting.

The estimator never reads this module directly - it only sees sensor measurements produced by
``simulation.sensors``. The digital twin may display it, always labelled as simulation ground truth.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class Box:
    bmin: np.ndarray
    bmax: np.ndarray
    kind: str                 # wall | floor | ceiling | column | furniture | pipe | lintel | person
    label: str = ""
    texture: float = 1.2      # visual features per m^2 on its faces
    dynamic: bool = False

    def contains(self, p: np.ndarray, margin: float = 0.0) -> np.ndarray:
        p = np.atleast_2d(p)
        return np.all((p >= self.bmin - margin) & (p <= self.bmax + margin), axis=1)


@dataclass
class LightZone:
    name: str
    bmin: np.ndarray
    bmax: np.ndarray
    level: float              # 0 = dark, 1 = nominal lighting
    nominal: float = 1.0


@dataclass
class MovingObstacle:
    """Box-shaped obstacle following a closed polyline at constant speed (people, carts)."""
    label: str
    size: np.ndarray
    waypoints: np.ndarray
    speed: float
    start_time: float = 0.0
    box: Box | None = None

    def position(self, t: float) -> np.ndarray:
        pts = self.waypoints
        seg = np.linalg.norm(np.diff(np.vstack([pts, pts[:1]]), axis=0), axis=1)
        total = seg.sum()
        s = max(0.0, (t - self.start_time)) * self.speed % total
        for i, L in enumerate(seg):
            if s <= L:
                a, b = pts[i], pts[(i + 1) % len(pts)]
                return a + (b - a) * (s / max(L, 1e-9))
            s -= L
        return pts[0].copy()

    def velocity(self, t: float, dt: float = 0.05) -> np.ndarray:
        return (self.position(t + dt) - self.position(t)) / dt


@dataclass
class Landmarks:
    pos: np.ndarray           # (N,3)
    normal: np.ndarray        # (N,3)
    word: np.ndarray          # (N,) visual-word id (appearance), may repeat across places
    box_index: np.ndarray     # (N,)


@dataclass
class World:
    name: str
    boxes: list[Box]
    landmarks: Landmarks
    light_zones: list[LightZone]
    ambient_light: float = 1.0
    movers: list[MovingObstacle] = field(default_factory=list)
    bounds_min: np.ndarray = field(default_factory=lambda: np.array([-8.0, -4.0, 0.0]))
    bounds_max: np.ndarray = field(default_factory=lambda: np.array([34.0, 24.0, 3.2]))

    def __post_init__(self) -> None:
        self._static_count = len(self.boxes)
        for m in self.movers:
            m.box = Box(np.zeros(3), np.zeros(3), "person", m.label, texture=0.0, dynamic=True)
        self._rebuild_arrays()
        self.time = 0.0

    # ---------------------------------------------------------------- geometry arrays
    def _rebuild_arrays(self) -> None:
        all_boxes = self.boxes + [m.box for m in self.movers]
        self._bmin = np.array([b.bmin for b in all_boxes], dtype=float)
        self._bmax = np.array([b.bmax for b in all_boxes], dtype=float)

    def set_time(self, t: float) -> None:
        self.time = t
        if not self.movers:
            return
        for i, m in enumerate(self.movers):
            c = m.position(t)
            half = m.size / 2.0
            m.box.bmin = np.array([c[0] - half[0], c[1] - half[1], 0.0])
            m.box.bmax = np.array([c[0] + half[0], c[1] + half[1], m.size[2]])
            k = self._static_count + i
            self._bmin[k] = m.box.bmin
            self._bmax[k] = m.box.bmax

    def all_boxes(self) -> list[Box]:
        return self.boxes + [m.box for m in self.movers]

    # ---------------------------------------------------------------- queries
    def raycast(self, origins: np.ndarray, dirs: np.ndarray, max_range: float) -> tuple[np.ndarray, np.ndarray]:
        """Vectorised slab test. Returns (range, box index); range = inf and index = -1 for misses."""
        origins = np.atleast_2d(origins)
        dirs = np.atleast_2d(dirs)
        if origins.shape[0] == 1 and dirs.shape[0] > 1:
            origins = np.broadcast_to(origins, dirs.shape)
        d = np.where(np.abs(dirs) < 1e-12, 1e-12, dirs)
        inv = 1.0 / d
        t1 = (self._bmin[None, :, :] - origins[:, None, :]) * inv[:, None, :]
        t2 = (self._bmax[None, :, :] - origins[:, None, :]) * inv[:, None, :]
        tnear = np.max(np.minimum(t1, t2), axis=2)
        tfar = np.min(np.maximum(t1, t2), axis=2)
        hit = (tfar >= np.maximum(tnear, 0.0)) & (tnear <= max_range)
        t = np.where(tnear > 0.0, tnear, 0.0)
        t = np.where(hit, t, np.inf)
        idx = np.argmin(t, axis=1)
        rng = t[np.arange(t.shape[0]), idx]
        idx = np.where(np.isfinite(rng), idx, -1)
        return rng, idx

    def collides(self, p: np.ndarray, radius: float) -> int:
        """Index of a box intersecting a sphere at p, or -1."""
        closest = np.clip(p[None, :], self._bmin, self._bmax)
        d2 = np.sum((closest - p[None, :]) ** 2, axis=1)
        hits = np.nonzero(d2 < radius * radius)[0]
        return int(hits[0]) if hits.size else -1

    def light_at(self, pts: np.ndarray) -> np.ndarray:
        pts = np.atleast_2d(pts)
        level = np.full(pts.shape[0], self.ambient_light)
        for z in self.light_zones:   # later zones override earlier ones
            inside = np.all((pts >= z.bmin) & (pts <= z.bmax), axis=1)
            level[inside] = z.level
        return level

    def zone(self, name: str) -> LightZone | None:
        return next((z for z in self.light_zones if z.name == name), None)

    def floor_height_below(self, p: np.ndarray) -> float:
        rng, _ = self.raycast(p[None, :], np.array([[0.0, 0.0, -1.0]]), 50.0)
        return float(p[2] - rng[0]) if np.isfinite(rng[0]) else 0.0

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "boxes": [
                {"min": np.round(b.bmin, 3).tolist(), "max": np.round(b.bmax, 3).tolist(),
                 "kind": b.kind, "label": b.label}
                for b in self.boxes
            ],
            "light_zones": [
                {"name": z.name, "min": z.bmin.tolist(), "max": z.bmax.tolist(), "level": z.level}
                for z in self.light_zones
            ],
            "movers": [{"label": m.label, "size": m.size.tolist()} for m in self.movers],
            "landmark_count": int(self.landmarks.pos.shape[0]),
            "bounds_min": self.bounds_min.tolist(),
            "bounds_max": self.bounds_max.tolist(),
            "ground_truth": True,
        }


# --------------------------------------------------------------------------- landmark generation
_FACES = [
    (0, -1), (0, +1), (1, -1), (1, +1), (2, -1), (2, +1),
]


def generate_landmarks(boxes: list[Box], rng: np.random.Generator, vocab: int = 600,
                       word_fn=None) -> Landmarks:
    """Scatter visual features over exposed box faces with each box's texture density."""
    pos, nrm, words, owners = [], [], [], []
    bmins = np.array([b.bmin for b in boxes])
    bmaxs = np.array([b.bmax for b in boxes])
    for bi, b in enumerate(boxes):
        if b.texture <= 0:
            continue
        size = b.bmax - b.bmin
        for axis, sign in _FACES:
            u, v = [a for a in range(3) if a != axis]
            area = size[u] * size[v]
            n = rng.poisson(b.texture * area)
            if n == 0:
                continue
            p = np.empty((n, 3))
            p[:, u] = rng.uniform(b.bmin[u], b.bmax[u], n)
            p[:, v] = rng.uniform(b.bmin[v], b.bmax[v], n)
            p[:, axis] = b.bmax[axis] if sign > 0 else b.bmin[axis]
            normal = np.zeros(3)
            normal[axis] = sign
            probe = p + normal * 0.02
            inside = np.any(
                np.all((probe[:, None, :] >= bmins[None]) & (probe[:, None, :] <= bmaxs[None]), axis=2), axis=1)
            p = p[~inside]
            if p.shape[0] == 0:
                continue
            pos.append(p + normal * 0.001)
            nrm.append(np.repeat(normal[None], p.shape[0], axis=0))
            if word_fn is not None:
                words.append(np.array([word_fn(q, rng) for q in p], dtype=int))
            else:
                words.append(rng.integers(0, vocab, p.shape[0]))
            owners.append(np.full(p.shape[0], bi))
    return Landmarks(np.vstack(pos), np.vstack(nrm), np.concatenate(words), np.concatenate(owners))
