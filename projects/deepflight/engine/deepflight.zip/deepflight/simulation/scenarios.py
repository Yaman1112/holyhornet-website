"""Repeatable, clearly labelled simulation scenarios.

Each scenario = environment builder + start pose + mission goals + config overrides + scripted
environment events (triggers). All randomness comes from the session seed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np

from .environments import build_office_building, build_tunnel


@dataclass
class Trigger:
    name: str
    condition: Callable          # (sim) -> bool
    action: Callable             # (sim) -> None
    once: bool = True
    fired: bool = False


@dataclass
class Scenario:
    id: str
    name: str
    description: str
    implemented: bool
    build: Callable | None = None
    start: tuple = (-4.0, 9.5, 0.12)
    start_yaw: float = 0.0
    goals: list = field(default_factory=list)
    overrides: dict = field(default_factory=dict)
    triggers: Callable | None = None      # (sim) -> list[Trigger]
    duration_s: float = 150.0
    expected: str = ""

    def summary(self) -> dict:
        return {"id": self.id, "name": self.name, "description": self.description,
                "implemented": self.implemented, "duration_s": self.duration_s, "expected": self.expected,
                "goals": [list(g) for g in self.goals]}


# ------------------------------------------------------------------ triggers
def _in_corridor_past(x: float):
    return lambda sim: sim.truth.p[0] > x and 8.0 < sim.truth.p[1] < 11.0


def lighting_failure(x_trigger: float, duration: float | None, restore_level: float = 0.65):
    """Corridor lighting circuit fails when the vehicle passes ``x_trigger``; emergency lighting after
    ``duration`` seconds (None = never restored automatically)."""

    def make(sim):
        state = {}

        def off(s):
            s.set_light("corridor east circuit", 0.02, "Corridor lighting circuit failed (simulated event)")
            state["t_off"] = s.t

        trig = [Trigger("lights_off", _in_corridor_past(x_trigger), off)]
        if duration is not None:
            trig.append(Trigger("lights_restored",
                                lambda s: "t_off" in state and s.t - state["t_off"] >= duration,
                                lambda s: s.set_light("corridor east circuit", restore_level,
                                                      "Emergency lighting restored (simulated event)")))
        return trig

    return make


def sensor_degradation(sim):
    return [
        Trigger("camera_freeze", lambda s: s.t > 40.0,
                lambda s: s.inject_fault("camera_freeze", "scenario G: camera driver freezes (repeated frames)")),
        Trigger("camera_recover", lambda s: s.t > 46.0, lambda s: s.clear_fault("camera_freeze", "camera driver restarted")),
        Trigger("flow_fail", lambda s: s.t > 55.0, lambda s: s.inject_fault("flow_fail", "scenario G: optical flow sensor fails")),
        Trigger("imu_bias", lambda s: s.t > 65.0,
                lambda s: s.inject_bias_jump("scenario G: accelerometer bias step (thermal)")),
    ]


SCENARIOS: dict[str, Scenario] = {}


def _add(s: Scenario) -> None:
    SCENARIOS[s.id] = s


_GOAL_N2 = (27.0, 17.0, 1.2)
_GOAL_S3 = (28.6, 6.2, 1.2)

_add(Scenario(
    "M1", "Milestone 1 - GNSS-denied indoor ingress with lighting failure",
    "Quadcopter takes off outside an unfamiliar building with GNSS denied, enters through the west door, "
    "maps the building with stereo depth while flying VIO, and navigates to the far north-east room. "
    "The corridor lighting circuit fails mid-flight: visual tracking is lost, the integrity monitor "
    "escalates DEGRADED -> UNCERTAIN -> LOST, the vehicle holds (no return-to-home). Emergency lighting "
    "returns after 10 s, VIO re-initialises on a new map segment, relocalizes against keyframes "
    "and the mission resumes.",
    True, lambda rng: build_office_building(rng), goals=[_GOAL_N2],
    triggers=lighting_failure(13.0, 10.0), duration_s=170.0,
    expected="lost -> recovering -> reliable; goal reached; no collision"))

_add(Scenario(
    "A", "A - GPS-denied indoor navigation", "Nominal flight through the building to the north-east room.",
    True, lambda rng: build_office_building(rng), goals=[_GOAL_N2], duration_s=120.0,
    expected="reliable throughout; goal reached"))

_add(Scenario(
    "B", "B - Underground tunnel", "Curving tunnel at reduced light. LiDAR scan matching module is planned "
    "(Phase 3); currently flown with VIO + flow only.", False, lambda rng: build_tunnel(rng),
    start=(-1.0, 10.0, 0.12), goals=[(28.0, 10.0 + 2.5 * np.sin(30 / 9.0), 1.2)], duration_s=120.0))

_add(Scenario(
    "C", "C - Low-light environment", "Corridor lighting dims to 25 % for the rest of the flight: "
    "feature detection probability and pixel accuracy drop; the system should report DEGRADED, not RELIABLE.",
    True, lambda rng: build_office_building(rng), goals=[_GOAL_N2],
    triggers=lambda sim: [Trigger("dim", _in_corridor_past(4.0),
                                  lambda s: s.set_light("corridor east circuit", 0.25, "Corridor lights dimmed to 25 % (simulated)"))],
    duration_s=140.0, expected="degraded in corridor; goal reached at reduced speed"))

_add(Scenario(
    "D", "D - Textureless corridor", "Plain painted corridor walls between x = 13.5 and 22 m: few "
    "distinctive features, VIO weakens, optical flow and rangefinder carry the estimate.",
    True, lambda rng: build_office_building(rng, textureless_corridor=True), goals=[_GOAL_N2],
    duration_s=140.0, expected="weak tracking detected in plain section"))

_add(Scenario(
    "E", "E - Repetitive geometry", "Identical-looking corridors to stress false place recognition (planned).",
    False))

_add(Scenario(
    "F", "F - Dynamic obstacles", "People walk across the corridor and through the target room. Raw-depth "
    "reactive layer brakes; the map clears cells as people move; the planner replans.",
    True, lambda rng: build_office_building(rng, with_people=True), goals=[_GOAL_N2], duration_s=150.0,
    expected="KNOWN FAILURE in this release: without dynamic-object tracking a person walking into the "
             "hovering aircraft can collide (see VALIDATION.md); tracking + predicted occupancy is Phase 4"))

_add(Scenario(
    "G", "G - Sensor degradation", "Camera freeze (stale timestamps), optical-flow failure and an "
    "accelerometer bias step are injected in sequence.",
    True, lambda rng: build_office_building(rng), goals=[_GOAL_N2], triggers=sensor_degradation,
    duration_s=150.0, expected="each fault detected and logged; mission continues or holds"))

_add(Scenario(
    "H", "H - Localization loss without recovery", "The corridor lights fail and are NOT restored. The "
    "vehicle must declare LOST, hold without attempting return-to-home, and request operator intervention.",
    True, lambda rng: build_office_building(rng), goals=[_GOAL_N2], triggers=lighting_failure(13.0, None),
    duration_s=90.0, expected="LOST + operator request; no RTH"))

_add(Scenario(
    "I", "I - Loop closure", "Out-and-back mission: fly to the far end of the corridor, visit the south-east "
    "room, return to the entrance hall. Revisiting mapped areas triggers place recognition and drift correction.",
    True, lambda rng: build_office_building(rng), goals=[(25.0, 9.5, 1.2), _GOAL_S3, (2.0, 9.5, 1.2)],
    duration_s=200.0, expected="loop closures accepted near the entrance; drift corrected"))

_add(Scenario(
    "J", "J - Map change", "Furniture moved between two mapping sessions (planned: multi-session maps).",
    False))


def list_scenarios() -> list[dict]:
    return [s.summary() for s in SCENARIOS.values()]
