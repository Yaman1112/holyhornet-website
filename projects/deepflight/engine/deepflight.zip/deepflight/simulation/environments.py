"""Procedural indoor environments (all simulated, clearly labelled)."""
from __future__ import annotations

import numpy as np

from .world import Box, LightZone, MovingObstacle, World, generate_landmarks

H = 3.0           # storey height
T = 0.2           # wall thickness
DOOR_H = 2.2


def _box(x0, y0, z0, x1, y1, z1, kind, label="", texture=1.2) -> Box:
    return Box(np.array([x0, y0, z0], float), np.array([x1, y1, z1], float), kind, label, texture)


def wall_along_x(y: float, x0: float, x1: float, openings: list[tuple[float, float]], label: str,
                 texture: float = 1.2, tex_fn=None, splits: tuple = ()) -> list[Box]:
    """Wall centred on ``y`` spanning x0..x1 with door openings [(xa, xb), ...].

    ``splits`` adds extra segment boundaries (so a section can get its own surface texture)."""
    out, cursor = [], x0

    def solid(a: float, b: float) -> None:
        cuts = [a] + [s for s in splits if a < s < b] + [b]
        for c0, c1 in zip(cuts[:-1], cuts[1:]):
            out.append(_box(c0, y - T / 2, 0, c1, y + T / 2, H, "wall", label, texture))

    for xa, xb in sorted(openings):
        if xa > cursor:
            solid(cursor, xa)
        out.append(_box(xa, y - T / 2, DOOR_H, xb, y + T / 2, H, "lintel", label + " door lintel", texture))
        cursor = xb
    if cursor < x1:
        solid(cursor, x1)
    if tex_fn is not None:
        for b in out:
            b.texture = tex_fn(b)
    return out


def wall_along_y(x: float, y0: float, y1: float, openings: list[tuple[float, float]], label: str,
                 texture: float = 1.2) -> list[Box]:
    out, cursor = [], y0
    for ya, yb in sorted(openings):
        if ya > cursor:
            out.append(_box(x - T / 2, cursor, 0, x + T / 2, ya, H, "wall", label, texture))
        out.append(_box(x - T / 2, ya, DOOR_H, x + T / 2, yb, H, "lintel", label + " door lintel", texture))
        cursor = yb
    if cursor < y1:
        out.append(_box(x - T / 2, cursor, 0, x + T / 2, y1, H, "wall", label, texture))
    return out


def build_office_building(rng: np.random.Generator, *, textureless_corridor: bool = False,
                          with_people: bool = False, moved_furniture: bool = False) -> World:
    """30 m x 20 m single-storey building entered from the west through a doorway.

    Layout: an east-west corridor (y 8..11) with three rooms to the south and two to the north.
    The corridor section x 9..30 has its own lighting circuit (used for the lighting-failure event).
    """
    boxes: list[Box] = []
    # ground (outside + inside) and ceiling (inside only)
    boxes.append(_box(-8, -4, -0.1, 34, 24, 0.0, "floor", "floor / ground", texture=0.6))
    boxes.append(_box(0, 0, H, 30, 20, H + 0.1, "ceiling", "ceiling", texture=0.35))
    # outer walls
    boxes += wall_along_y(0.0, 0.0, 20.0, [(8.6, 10.4)], "west facade")
    boxes += wall_along_y(30.0, 0.0, 20.0, [], "east facade")
    boxes += wall_along_x(0.0, -0.1, 30.1, [], "south facade")
    boxes += wall_along_x(20.0, -0.1, 30.1, [], "north facade")

    plain = 0.06

    def corridor_tex(b: Box) -> float:
        if textureless_corridor and b.bmin[0] >= 13.5 and b.bmax[0] <= 22.0:
            return plain
        return 1.3

    # corridor walls with doors to rooms
    boxes += wall_along_x(8.0, 0.1, 29.9, [(4.0, 5.2), (14.0, 15.2), (24.0, 25.2)], "corridor south wall",
                          tex_fn=corridor_tex, splits=(13.5, 22.0))
    boxes += wall_along_x(11.0, 0.1, 29.9, [(6.0, 7.2), (22.0, 23.2)], "corridor north wall",
                          tex_fn=corridor_tex, splits=(13.5, 22.0))
    # room partitions
    boxes += wall_along_y(10.0, 0.1, 7.9, [], "partition S1/S2")
    boxes += wall_along_y(20.0, 0.1, 7.9, [], "partition S2/S3")
    boxes += wall_along_y(15.0, 11.1, 19.9, [(15.0, 16.2)], "partition N1/N2")

    # structure and furniture
    boxes.append(_box(0.1, 9.3, 2.62, 29.9, 9.48, 2.80, "pipe", "corridor service pipe", 0.8))
    for x in (3.0, 9.0):
        boxes.append(_box(x - 0.2, 14.8, 0, x + 0.2, 15.2, H, "column", "column N1"))
    for x in (19.0, 25.0):
        boxes.append(_box(x - 0.2, 15.3, 0, x + 0.2, 15.7, H, "column", "column N2"))
    boxes.append(_box(2.0, 17.5, 0, 6.0, 18.3, 0.76, "furniture", "table N1"))
    boxes.append(_box(10.5, 12.0, 0, 11.0, 14.5, 2.0, "furniture", "shelf N1"))
    shelf_x = (17.0, 17.5) if not moved_furniture else (17.0, 19.5)
    shelf_y = (17.0, 19.5) if not moved_furniture else (18.9, 19.4)
    boxes.append(_box(shelf_x[0], shelf_y[0], 0, shelf_x[1], shelf_y[1], 2.0, "furniture", "shelf N2"))
    boxes.append(_box(21.5, 12.5, 0, 23.0, 13.3, 1.1, "furniture", "cabinet N2"))
    boxes.append(_box(26.0, 13.0, 0, 28.5, 14.0, 0.76, "furniture", "desk N2"))
    boxes.append(_box(2.0, 2.0, 0, 5.0, 3.0, 0.76, "furniture", "desk S1"))
    boxes.append(_box(12.0, 1.0, 0, 13.0, 4.0, 1.8, "furniture", "rack S2"))
    boxes.append(_box(26.0, 2.0, 0, 27.0, 5.0, 1.2, "furniture", "crates S3"))
    # outdoor reference objects near the entrance
    boxes.append(_box(-6.5, 5.5, 0, -5.5, 6.5, 1.0, "furniture", "outdoor bollard / crate"))
    boxes.append(_box(-6.5, 12.5, 0, -5.5, 13.5, 1.4, "furniture", "outdoor cabinet"))

    landmarks = generate_landmarks(boxes, rng)

    zones = [
        LightZone("building", np.array([0.0, 0.0, -1.0]), np.array([30.0, 20.0, 4.0]), 1.0),
        LightZone("corridor east circuit", np.array([9.0, 8.05, -1.0]), np.array([30.0, 10.95, 4.0]), 1.0),
    ]
    movers = []
    if with_people:
        movers.append(MovingObstacle("person 1", np.array([0.5, 0.5, 1.8]),
                                     np.array([[16.0, 8.6, 0.0], [16.0, 10.4, 0.0]]), 0.6, start_time=8.0))
        movers.append(MovingObstacle("person 2", np.array([0.5, 0.5, 1.75]),
                                     np.array([[24.0, 13.0, 0.0], [27.0, 18.0, 0.0], [20.5, 18.5, 0.0]]),
                                     0.8, start_time=0.0))
    return World("HolyHornet test building (simulated)", boxes, landmarks, zones, ambient_light=1.0,
                 movers=movers)


def build_tunnel(rng: np.random.Generator) -> World:
    """Gently curving underground tunnel approximated by box segments (Scenario B)."""
    boxes: list[Box] = [_box(-8, -4, -0.1, 34, 24, 0.0, "floor", "tunnel floor", 0.5)]
    y = 10.0
    width, height = 3.0, 3.0
    for i, x in enumerate(np.arange(-2.0, 30.0, 2.0)):
        y_next = 10.0 + 2.5 * np.sin((x + 2.0) / 9.0)
        yc = 0.5 * (y + y_next)
        boxes.append(_box(x, yc - width / 2 - 0.3, 0, x + 2.0, yc - width / 2, height, "wall", f"tunnel wall S{i}", 0.9))
        boxes.append(_box(x, yc + width / 2, 0, x + 2.0, yc + width / 2 + 0.3, height, "wall", f"tunnel wall N{i}", 0.9))
        boxes.append(_box(x, yc - width / 2 - 0.3, height, x + 2.0, yc + width / 2 + 0.3, height + 0.2, "ceiling", f"tunnel roof {i}", 0.4))
        y = y_next
    landmarks = generate_landmarks(boxes, rng)
    zones = [LightZone("tunnel", np.array([-2.0, -4.0, -1.0]), np.array([34.0, 24.0, 5.0]), 0.55, nominal=0.55)]
    return World("Underground tunnel (simulated)", boxes, landmarks, zones, ambient_light=1.0)
