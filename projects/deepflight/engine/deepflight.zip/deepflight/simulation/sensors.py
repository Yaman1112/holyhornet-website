"""Simulated sensors. Every output is a timestamped measurement; nothing here leaks truth to the
estimator except through modelled noise (truth-only diagnostics are kept in ``.debug`` fields that the
estimator does not read and that are used only for validation metrics)."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import SensorSuite
from ..core.frames import GRAVITY, camera_mount
from .dynamics import TruthState
from .world import World


@dataclass
class ImuSample:
    t: float
    acc: np.ndarray
    gyro: np.ndarray


@dataclass
class CameraFrame:
    t: float
    ids: np.ndarray          # tracker track ids (= landmark ids, with injected mismatches)
    uv: np.ndarray           # (N,2) pixels
    depth: np.ndarray        # (N,) metres, nan when out of stereo range
    words: np.ndarray        # (N,) appearance words for place recognition
    mean_light: float
    blur_px: float
    debug_outlier: np.ndarray = field(default_factory=lambda: np.zeros(0, bool))
    desc: np.ndarray | None = None   # (N,32) ORB descriptors from a real image front end (else None)


@dataclass
class DepthCloud:
    t: float
    points_cam: np.ndarray   # (N,3) camera optical frame, valid returns only
    max_dirs_cam: np.ndarray # (M,3) unit directions with no return within range (free-space rays)


@dataclass
class LidarScan:
    t: float
    points_body: np.ndarray


@dataclass
class FlowSample:
    t: float
    v_body_xy: np.ndarray
    quality: float           # 0..1 (surface light and texture)


@dataclass
class ScalarSample:
    t: float
    value: float


class SensorSuiteSim:
    def __init__(self, cfg: SensorSuite, world: World, rng: np.random.Generator):
        self.cfg = cfg
        self.world = world
        self.rng = rng
        ic = cfg.imu
        self.ba = np.array(ic.initial_accel_bias, float)
        self.bg = np.array(ic.initial_gyro_bias, float)
        self.baro_bias = 0.0
        self.R_bc = camera_mount(cfg.camera.mount_pitch_deg)
        self.t_bc = np.array(cfg.camera.lever_arm_m, float)
        self.faults: dict[str, dict] = {}
        self._last_frame: CameraFrame | None = None
        cc = cfg.camera
        self.K = np.array([[cc.fx, 0, cc.width / 2], [0, cc.fy, cc.height / 2], [0, 0, 1.0]])
        # depth ray pattern (camera frame)
        nu, nv = cc.depth_rays
        us = np.linspace(20, cc.width - 20, nu)
        vs = np.linspace(20, cc.height - 20, nv)
        uu, vv = np.meshgrid(us, vs)
        d = np.stack([(uu.ravel() - cc.width / 2) / cc.fx, (vv.ravel() - cc.height / 2) / cc.fy,
                      np.ones(uu.size)], axis=1)
        self.depth_dirs_cam = d / np.linalg.norm(d, axis=1, keepdims=True)
        lc = cfg.lidar
        az = np.deg2rad(np.arange(0.0, 360.0, lc.horizontal_step_deg))
        el = np.deg2rad(np.linspace(-lc.vertical_fov_deg / 2, lc.vertical_fov_deg / 2, lc.channels))
        A, E = np.meshgrid(az, el)
        self.lidar_dirs = np.stack([np.cos(E) * np.cos(A), np.cos(E) * np.sin(A), np.sin(E)], axis=-1).reshape(-1, 3)

    # ------------------------------------------------------------------ faults
    def fault(self, name: str) -> bool:
        return name in self.faults

    # ------------------------------------------------------------------ IMU
    def imu(self, t: float, s: TruthState, dt: float) -> ImuSample | None:
        ic = self.cfg.imu
        self.bg += self.rng.normal(0, ic.gyro_bias_walk * np.sqrt(dt), 3)
        self.ba += self.rng.normal(0, ic.accel_bias_walk * np.sqrt(dt), 3)
        if self.fault("imu_fail"):
            return None
        R = s.R
        f_b = R.T @ (s.acc_w - GRAVITY)
        if s.landed:
            f_b = R.T @ (-GRAVITY)
        # rotor vibration
        vib = 0.0 if s.landed else 0.15
        acc = f_b + self.ba + self.rng.normal(0, ic.accel_noise_density / np.sqrt(dt), 3) \
            + self.rng.normal(0, vib, 3)
        gyro = s.omega_b + self.bg + self.rng.normal(0, ic.gyro_noise_density / np.sqrt(dt), 3)
        if self.fault("imu_degraded"):
            acc = acc + self.rng.normal(0, 1.5, 3)
            gyro = gyro + self.rng.normal(0, 0.05, 3)
        return ImuSample(t, acc, gyro)

    def apply_imu_bias_jump(self, accel: np.ndarray, gyro: np.ndarray) -> None:
        self.ba += accel
        self.bg += gyro

    # ------------------------------------------------------------------ camera
    def camera_pose(self, s: TruthState) -> tuple[np.ndarray, np.ndarray]:
        R = s.R
        return s.p + R @ self.t_bc, R @ self.R_bc

    def camera(self, t: float, s: TruthState) -> CameraFrame | None:
        cc = self.cfg.camera
        if not cc.enabled or self.fault("camera_fail"):
            return None
        if self.fault("camera_freeze") and self._last_frame is not None:
            return self._last_frame          # stale frame with an old timestamp
        rng = self.rng
        w = self.world
        p_c, R_wc = self.camera_pose(s)
        L = w.landmarks
        rel = L.pos - p_c
        dist = np.linalg.norm(rel, axis=1)
        cand = np.nonzero((dist > 0.3) & (dist < cc.max_range_m))[0]
        pc = rel[cand] @ R_wc                       # camera-frame coordinates
        infront = pc[:, 2] > 0.2
        cand, pc = cand[infront], pc[infront]
        u = cc.fx * pc[:, 0] / pc[:, 2] + cc.width / 2
        v = cc.fy * pc[:, 1] / pc[:, 2] + cc.height / 2
        inimg = (u > 4) & (u < cc.width - 4) & (v > 4) & (v < cc.height - 4)
        cand, pc, u, v = cand[inimg], pc[inimg], u[inimg], v[inimg]
        facing = np.einsum("ij,ij->i", L.normal[cand], -rel[cand]) > 0.05 * dist[cand]
        cand, pc, u, v = cand[facing], pc[facing], u[facing], v[facing]
        light_cam = float(w.light_at(p_c)[0])
        if cand.size:
            # occlusion test
            dirs = rel[cand] / dist[cand, None]
            hit_r, _ = w.raycast(np.repeat(p_c[None], cand.size, 0), dirs, cc.max_range_m)
            vis = hit_r >= dist[cand] - 0.05
            cand, pc, u, v = cand[vis], pc[vis], u[vis], v[vis]
        blur_px = float(np.linalg.norm(s.omega_b) * cc.exposure_s * cc.fx)
        if cand.size == 0:
            frame = CameraFrame(t, np.zeros(0, int), np.zeros((0, 2)), np.zeros(0), np.zeros(0, int),
                                light_cam, blur_px)
            self._last_frame = frame
            return frame
        light = w.light_at(L.pos[cand])
        tex_ok = np.ones(cand.size)
        p_det = np.clip((light - 0.12) / 0.33, 0.0, 1.0) * tex_ok
        p_det *= np.clip(1.0 - (blur_px - 3.0) / 10.0, 0.05, 1.0)
        keep = rng.random(cand.size) < p_det
        cand, pc, u, v, light = cand[keep], pc[keep], u[keep], v[keep], light[keep]
        if cand.size > cc.max_features:
            sel = rng.choice(cand.size, cc.max_features, replace=False)
            cand, pc, u, v, light = cand[sel], pc[sel], u[sel], v[sel], light[sel]
        sigma = cc.pixel_noise / np.clip(light, 0.3, 1.0) + 0.3 * blur_px
        uv = np.stack([u, v], 1) + rng.normal(0, 1, (cand.size, 2)) * sigma[:, None]
        z = pc[:, 2]
        depth = z + rng.normal(0, 1, cand.size) * (cc.depth_noise_coeff * z * z + 0.01)
        depth = np.where(z <= cc.depth_max_range_m, depth, np.nan)
        ids = cand.copy()
        outlier = rng.random(cand.size) < cc.mismatch_rate
        if outlier.any():
            # wrong association: the track id now belongs to some other landmark
            ids[outlier] = rng.integers(0, L.pos.shape[0], int(outlier.sum()))
        frame = CameraFrame(t, ids, uv, depth, L.word[cand], light_cam, blur_px, outlier)
        self._last_frame = frame
        return frame

    def depth(self, t: float, s: TruthState) -> DepthCloud | None:
        cc = self.cfg.camera
        if not cc.enabled or self.fault("camera_fail"):
            return None
        p_c, R_wc = self.camera_pose(s)
        dirs_w = self.depth_dirs_cam @ R_wc.T
        rng_, _ = self.world.raycast(p_c[None], dirs_w, cc.depth_max_range_m)
        hit = np.isfinite(rng_) & (rng_ > 0.15)
        r = rng_[hit]
        r = r + self.rng.normal(0, 1, r.size) * (cc.depth_noise_coeff * r * r + 0.01)
        pts = self.depth_dirs_cam[hit] * r[:, None]
        return DepthCloud(t, pts, self.depth_dirs_cam[~hit & ~(rng_ <= 0.15)])

    # ------------------------------------------------------------------ others
    def lidar(self, t: float, s: TruthState) -> LidarScan | None:
        lc = self.cfg.lidar
        if not lc.enabled or self.fault("lidar_fail"):
            return None
        R = s.R
        origin = s.p + R @ np.array([0.0, 0.0, 0.08])
        dirs_w = self.lidar_dirs @ R.T
        r, _ = self.world.raycast(origin[None], dirs_w, lc.max_range_m)
        ok = np.isfinite(r) & (r > 0.3)
        r = r[ok] + self.rng.normal(0, lc.noise_m, int(ok.sum()))
        pts = self.lidar_dirs[ok] * r[:, None] + np.array([0.0, 0.0, 0.08])
        return LidarScan(t, pts)

    def flow(self, t: float, s: TruthState) -> FlowSample | None:
        fc = self.cfg.flow
        if not fc.enabled or self.fault("flow_fail"):
            return None
        if s.landed:                     # too close to the ground to resolve flow: valid but no quality
            return FlowSample(t, np.zeros(2), 0.0)
        R = s.R
        light = float(self.world.light_at(np.array([s.p[0], s.p[1], 0.05]))[0])
        h = s.p[2]
        quality = float(np.clip((light - fc.min_light) / 0.4, 0.0, 1.0)) * (1.0 if 0.25 < h < 6.0 else 0.0)
        if quality <= 0.05:
            return FlowSample(t, np.zeros(2), 0.0)
        v_b = R.T @ s.v
        noise = fc.noise_ms / max(quality, 0.2)
        return FlowSample(t, v_b[:2] + self.rng.normal(0, noise, 2), quality)

    def rangefinder(self, t: float, s: TruthState) -> ScalarSample | None:
        rc = self.cfg.rangefinder
        if not rc.enabled or self.fault("rangefinder_fail"):
            return None
        R = s.R
        r, _ = self.world.raycast(s.p[None], (-R[:, 2])[None], rc.max_range_m)
        if not np.isfinite(r[0]):
            return None
        return ScalarSample(t, float(r[0] + self.rng.normal(0, rc.noise_m)))

    def baro(self, t: float, s: TruthState, dt: float) -> ScalarSample | None:
        bc = self.cfg.baro
        self.baro_bias += self.rng.normal(0, bc.drift_m_per_s * np.sqrt(dt) * 3.0)
        if not bc.enabled or self.fault("baro_fail"):
            return None
        return ScalarSample(t, float(s.p[2] + self.baro_bias + self.rng.normal(0, bc.noise_m)))

    def gnss(self, t: float, s: TruthState):
        gc = self.cfg.gnss
        if not gc.enabled or gc.denied or self.fault("gnss_fail"):
            return None
        return ScalarSample(t, 0.0)  # GNSS-aided mode is out of scope for milestone 1
