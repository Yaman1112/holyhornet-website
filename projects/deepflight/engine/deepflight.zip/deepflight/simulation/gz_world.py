"""Export a DeepFlight environment as a Gazebo (gz-sim 7) world, so PX4 SITL flies in the same building.

    python -m deepflight.simulation.gz_world --scenario M1 --template default.sdf --out deepflight_building.sdf

The world reuses PX4's default world (physics, sensor systems, spherical coordinates, ground plane) and adds
one static model whose links are the DeepFlight boxes (walls, lintels, columns, furniture, pipe, ceiling).
Both frames are ENU with the same origin, so DeepFlight's map frame equals the Gazebo world frame.
The floor box is omitted (Gazebo's ground plane is z = 0). Lighting zones and visual landmarks are not
exported: DeepFlight's camera model is still synthetic (see docs/engineering/PX4_SITL.md).
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path
from xml.sax.saxutils import escape

import numpy as np

from .scenarios import SCENARIOS

COLORS = {"wall": "0.75 0.76 0.78 1", "lintel": "0.75 0.76 0.78 1", "ceiling": "0.55 0.55 0.55 1",
          "column": "0.6 0.62 0.66 1", "furniture": "0.55 0.42 0.3 1", "pipe": "0.4 0.45 0.5 1"}


def building_model_sdf(world, name: str = "deepflight_building") -> str:
    links = []
    for i, b in enumerate(world.boxes):
        if b.kind == "floor":
            continue
        size = b.bmax - b.bmin
        c = (b.bmax + b.bmin) / 2
        col = COLORS.get(b.kind, "0.7 0.7 0.7 1")
        geom = f"<geometry><box><size>{size[0]:.3f} {size[1]:.3f} {size[2]:.3f}</size></box></geometry>"
        links.append(
            f'      <link name="b{i:03d}_{b.kind}">\n'
            f"        <pose>{c[0]:.3f} {c[1]:.3f} {c[2]:.3f} 0 0 0</pose>\n"
            f'        <collision name="c">{geom}</collision>\n'
            f'        <visual name="v">{geom}<material><ambient>{col}</ambient><diffuse>{col}</diffuse></material>'
            f"</visual>\n"
            f"        <!-- {escape(b.label)} -->\n"
            f"      </link>")
    return (f'    <model name="{name}">\n      <static>true</static>\n' + "\n".join(links) + "\n    </model>\n")


def make_textures(out_dir, n: int = 32, size: int = 256, seed: int = 11) -> list[str]:
    """Procedural high-contrast textures (shapes, lines, blobs, noise) so rendered walls carry trackable features.
    A few are deliberately reused across panels: indoor scenes repeat (doors, posters), which place recognition
    must cope with."""
    import cv2
    from pathlib import Path
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    names = []
    for k in range(n):
        base = int(rng.integers(110, 200))
        img = np.full((size, size, 3), base, np.uint8)
        img = np.clip(img.astype(int) + rng.normal(0, 10, img.shape), 0, 255).astype(np.uint8)
        for _ in range(int(rng.integers(14, 30))):
            col = tuple(int(c) for c in rng.integers(0, 255, 3))
            shape = rng.integers(0, 4)
            p = tuple(int(v) for v in rng.integers(0, size, 2))
            if shape == 0:
                cv2.circle(img, p, int(rng.integers(6, 40)), col, -1)
            elif shape == 1:
                q = tuple(int(v) for v in rng.integers(0, size, 2))
                cv2.rectangle(img, p, q, col, -1 if rng.random() < 0.6 else 3)
            elif shape == 2:
                q = tuple(int(v) for v in rng.integers(0, size, 2))
                cv2.line(img, p, q, col, int(rng.integers(2, 7)))
            else:
                pts = rng.integers(0, size, (3, 2)).astype(np.int32)
                cv2.fillPoly(img, [pts], col)
        name = f"df_tex_{k:02d}.png"
        cv2.imwrite(str(out / name), img)
        names.append(name)
    return names


def _material(texture: str | None, color: str) -> str:
    if texture is None:
        return f"<material><ambient>{color}</ambient><diffuse>{color}</diffuse></material>"
    return (f"<material><ambient>1 1 1 1</ambient><diffuse>1 1 1 1</diffuse><specular>0.1 0.1 0.1 1</specular>"
            f"<pbr><metal><albedo_map>{texture}</albedo_map><roughness>0.9</roughness><metalness>0</metalness>"
            f"</metal></pbr></material>")


def textured_building_sdf(world, tex_uri: str, n_tex: int, panel_m: float = 1.5, floor_tile_m: float = 2.0,
                          name: str = "deepflight_building", seed: int = 5) -> str:
    """Same collision geometry as ``building_model_sdf``; visuals are split into ~1.5 m textured panels (one
    texture per panel, so features keep a realistic density) and the floor gets 2 m textured tiles."""
    rng = np.random.default_rng(seed)
    pick = lambda: f"{tex_uri}/df_tex_{int(rng.integers(0, n_tex)):02d}.png"
    links = []
    for i, b in enumerate(world.boxes):
        if b.kind == "floor":
            continue
        size = b.bmax - b.bmin
        c = (b.bmax + b.bmin) / 2
        geom = f"<geometry><box><size>{size[0]:.3f} {size[1]:.3f} {size[2]:.3f}</size></box></geometry>"
        visuals = []
        if b.kind in ("wall", "lintel") and max(size[0], size[1]) > panel_m:
            ax = 0 if size[0] >= size[1] else 1
            nh = max(int(np.ceil(size[ax] / panel_m)), 1)
            nv = max(int(np.ceil(size[2] / panel_m)), 1)
            for a in range(nh):
                for v in range(nv):
                    lo = b.bmin.copy()
                    hi = b.bmax.copy()
                    lo[ax] = b.bmin[ax] + size[ax] * a / nh
                    hi[ax] = b.bmin[ax] + size[ax] * (a + 1) / nh
                    lo[2] = b.bmin[2] + size[2] * v / nv
                    hi[2] = b.bmin[2] + size[2] * (v + 1) / nv
                    pc, ps = (lo + hi) / 2 - c, hi - lo
                    visuals.append(f'        <visual name="p{a}_{v}"><pose>{pc[0]:.3f} {pc[1]:.3f} {pc[2]:.3f} 0 0 0</pose>'
                                   f"<geometry><box><size>{ps[0]:.3f} {ps[1]:.3f} {ps[2]:.3f}</size></box></geometry>"
                                   f"{_material(pick(), '')}</visual>")
        elif b.kind == "ceiling":
            visuals.append(f'        <visual name="v">{geom}{_material(None, COLORS["ceiling"])}</visual>')
        else:
            visuals.append(f'        <visual name="v">{geom}{_material(pick(), "")}</visual>')
        links.append(f'      <link name="b{i:03d}_{b.kind}">\n        <pose>{c[0]:.3f} {c[1]:.3f} {c[2]:.3f} 0 0 0</pose>\n'
                     f'        <collision name="c">{geom}</collision>\n' + "\n".join(visuals) + "\n      </link>")
    # textured floor tiles (visual only; Gazebo's ground plane provides the collision)
    b0, b1 = world.bounds_min, world.bounds_max
    tiles = []
    for x in np.arange(b0[0], b1[0], floor_tile_m):
        for y in np.arange(b0[1], b1[1], floor_tile_m):
            tiles.append(f'        <visual name="f{len(tiles)}"><pose>{x + floor_tile_m / 2:.2f} {y + floor_tile_m / 2:.2f} 0.001 0 0 0</pose>'
                         f"<geometry><box><size>{floor_tile_m} {floor_tile_m} 0.002</size></box></geometry>"
                         f"{_material(pick(), '')}</visual>")
    links.append('      <link name="floor_tiles">\n' + "\n".join(tiles) + "\n      </link>")
    return f'    <model name="{name}">\n      <static>true</static>\n' + "\n".join(links) + "\n    </model>\n"


CORRIDOR_EAST_PREFIX = "corridor_east_"


def indoor_lights_sdf(world, spacing: float = 5.0, intensity: float = 1.0) -> str:
    """Ceiling point lights on a grid inside the building (z = 2.7 m). Lights of the east wing (x >= start of
    DeepFlight's "corridor east circuit" zone) are named ``corridor_east_<k>`` so a scenario can switch exactly that circuit off
    through Gazebo's /world/<name>/light_config service (a rendered blackout, not a modelled one)."""
    zone = next((z for z in world.light_zones if z.name == "corridor east circuit"), None)
    out, k_corr, k = [], 0, 0
    bmin, bmax = np.array([0.0, 0.0]), np.array([30.0, 20.0])
    for x in np.arange(bmin[0] + 2.5, bmax[0], spacing):
        for y in list(np.arange(bmin[1] + 2.5, bmax[1], spacing)) + [9.5]:
            in_corridor = 8.1 < y < 10.9
            if in_corridor and y != 9.5:
                continue
            name = f"room_{k}"
            # east-wing circuit: every light from the start of DeepFlight's corridor-east zone eastwards (point
            # lights without shadows shine through walls, so the adjoining rooms must be on the same circuit for
            # the corridor to really go dark)
            if zone is not None and x >= zone.bmin[0]:
                name = f"{CORRIDOR_EAST_PREFIX}{k_corr}"
                k_corr += 1
            elif in_corridor:
                name = f"corridor_west_{k}"
            k += 1
            out.append(f'    <light name="{name}" type="point"><pose>{x:.2f} {y:.2f} 2.7 0 0 0</pose>'
                       f"<diffuse>0.9 0.9 0.85 1</diffuse><specular>0.1 0.1 0.1 1</specular><intensity>{intensity}</intensity>"
                       f"<attenuation><range>10</range><constant>0.3</constant><linear>0.05</linear>"
                       f"<quadratic>0.02</quadratic></attenuation><cast_shadows>false</cast_shadows></light>\n")
    return "".join(out)


def make_world(scenario: str, template_sdf: str, world_name: str = "deepflight_building", seed: int = 0,
               tex_uri: str | None = None, n_tex: int = 32) -> str:
    sc = SCENARIOS[scenario]
    world = sc.build(np.random.default_rng(seed))      # geometry does not depend on the seed (landmarks do)
    sdf = re.sub(r'<world name="[^"]+">', f'<world name="{world_name}">', template_sdf, count=1)
    if tex_uri is not None:
        # low scene ambient: indoor light comes from the ceiling lights, so switching a circuit off really darkens it
        sdf = re.sub(r"(<scene>.*?)<ambient>[^<]*</ambient>", r"\1<ambient>0.04 0.04 0.04 1</ambient>", sdf, count=1,
                     flags=re.S)
    model = building_model_sdf(world) if tex_uri is None else textured_building_sdf(world, tex_uri, n_tex)         + indoor_lights_sdf(world)
    return sdf.replace("</world>", model + "  </world>", 1)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", default="M1")
    ap.add_argument("--template", required=True, help="PX4 Tools/simulation/gz/worlds/default.sdf")
    ap.add_argument("--out", required=True)
    ap.add_argument("--name", default="deepflight_building")
    ap.add_argument("--textures", default=None, help="write textures to this local dir and texture the world")
    ap.add_argument("--tex-uri", default="file:///root/PX4-Autopilot/Tools/simulation/gz/worlds/deepflight_textures",
                    help="where Gazebo will find the textures")
    a = ap.parse_args()
    tex_uri = None
    if a.textures:
        make_textures(a.textures)
        tex_uri = a.tex_uri
    Path(a.out).write_text(make_world(a.scenario, Path(a.template).read_text(), a.name, tex_uri=tex_uri))
    sc = SCENARIOS[a.scenario]
    print(f"wrote {a.out}; spawn pose for PX4_GZ_MODEL_POSE: {sc.start[0]},{sc.start[1]},0,0,0,{sc.start_yaw}")


if __name__ == "__main__":
    main()
