"""DeepFlight simulation engine: wires truth simulation, sensors, localization, mapping, navigation,
safety supervision and mission management into one deterministic, steppable loop.

Rates (dt = 10 ms): dynamics + IMU 100 Hz, camera 20 Hz, depth->map 10 Hz, flow/range 25 Hz,
baro 20 Hz, integrity / safety / navigation 10 Hz, recorded frames 10 Hz.
"""
from __future__ import annotations

import time
from copy import deepcopy
from dataclasses import replace

import numpy as np

from . import SOFTWARE_VERSION
from .autonomy.safety import FAULT_CATALOG, SafetySupervisor
from .config import DeepFlightConfig, apply_overrides
from .core.frames import camera_mount, rot_z, wrap_angle, ypr_from_rot
from .localization.fusion import LocalizationSystem
from .mapping.voxel_map import VoxelMap
from .navigation.planner import GlobalPlanner, PathFollower
from .simulation.dynamics import Setpoint
from .simulation.vehicles import EstimateView, NativeVehicle
from .simulation.scenarios import SCENARIOS
from .simulation.sensors import SensorSuiteSim

PROX_DIRS = np.array([[np.cos(a), np.sin(a), 0.0] for a in np.deg2rad(np.arange(0, 360, 45))])


class DeepFlightSim:
    def __init__(self, scenario_id: str = "M1", seed: int = 7, overrides: dict | None = None,
                 wallclock_monitors: bool = False, vehicle_factory=None, rest_height_m: float | None = None):
        """``wallclock_monitors`` enables checks that depend on real processing time (compute overload).
        They make runs load-dependent, so they are off for reproducible experiments and on for live
        sessions. ``vehicle_factory(cfg, start, yaw, rng, log)`` selects who flies the aircraft (default: the
        native kinematic quadrotor; see simulation/vehicles.py for PX4 SITL)."""
        if scenario_id not in SCENARIOS:
            raise KeyError(f"unknown scenario {scenario_id}")
        sc = SCENARIOS[scenario_id]
        if not sc.implemented or sc.build is None:
            raise ValueError(f"scenario {scenario_id} is planned but not implemented yet")
        if rest_height_m is not None:
            # the airframe's body height when standing on the pad (landing gear); the scenario's default 0.12 m
            # is the native model's. A wrong value shifts the whole map frame vertically against the real world.
            sc = replace(sc, start=(sc.start[0], sc.start[1], float(rest_height_m)))
        self.scenario = sc
        self.seed = int(seed)
        self.cfg = DeepFlightConfig()
        apply_overrides(self.cfg, deepcopy(sc.overrides))
        apply_overrides(self.cfg, deepcopy(overrides or {}))
        self.overrides = overrides or {}
        self.wallclock_monitors = wallclock_monitors
        ss = np.random.SeedSequence(self.seed)
        r_world, r_sens, r_dyn, r_db = [np.random.default_rng(s) for s in ss.spawn(4)]
        self.world = sc.build(r_world)
        self.dt = self.cfg.sim_dt
        self.t = 0.0
        self.k = 0
        start = np.array(sc.start, float)
        self.home = start.copy()
        self.home[2] = 0.12
        self.events: list[dict] = []
        self._new_events: list[dict] = []
        self.environment_hook = None
        if vehicle_factory is None:
            self.vehicle = NativeVehicle(self.cfg.aircraft, start, sc.start_yaw, r_dyn)
        else:
            self.vehicle = vehicle_factory(self.cfg, start, sc.start_yaw, r_dyn,
                                           lambda cat, sev, msg: self.log(self.t, cat, sev, msg, {}))
        self.quad = self.vehicle            # truth access: self.quad.s
        self.sensors = SensorSuiteSim(self.cfg.sensors, self.world, r_sens)
        self.loc = LocalizationSystem(self.cfg, self.quad.s.p.copy(), sc.start_yaw, self.log, seed=int(r_db.integers(1 << 30)))
        self.loc.truth_fn = lambda: self.quad.s.p.copy()
        if getattr(self.vehicle, "autopilot_imu", False):
            # autopilot IMU arrives over UDP in bursts and the engine may briefly run ahead of it
            self.loc.health["imu"].stale_min_s = 0.25
        self.vmap = VoxelMap(self.cfg.mapping)
        self.planner = GlobalPlanner(self.cfg.planner, self.vmap)
        ac = self.cfg.aircraft
        self.follower = PathFollower(self.cfg.planner, ac.max_speed_ms, ac.max_accel_ms2, ac.max_yaw_rate_dps)
        self.safety = SafetySupervisor(self.cfg.safety)
        self.R_bc = camera_mount(self.cfg.sensors.camera.mount_pitch_deg)
        self.t_bc = np.array(self.cfg.sensors.camera.lever_arm_m)
        # mission
        self.goals = [np.array(g, float) for g in sc.goals]
        self.goal_idx = 0
        self.mode = "PREFLIGHT"
        self.behaviour = "NOMINAL"
        self.path = np.zeros((0, 3))
        self.plan_info: dict = {}
        self.last_plan_t = -99.0
        self.last_plan_sigma = 0.0
        self.replans = 0
        self.replan_reasons: list[dict] = []
        self.need_replan = "initial plan"
        self.hold_yaw: float | None = None
        self.hold_alt = self.cfg.planner.flight_altitude_m
        self.setpoint = Setpoint()
        self.integrity_state = "RELIABLE"
        self.integrity_reasons: list[str] = []
        self.operator_required = False
        self.operator_request_logged = False
        self.integrity_inputs = None
        self.battery_wh = ac.battery_wh
        self.power_w = 0.0
        self.link_ok = True
        self.velocity_aided = True
        self.takeoff_cmd_t = 0.0
        self.collisions: list[dict] = []
        self.crashed = False
        self.min_clearance = 99.0
        self.latest_cloud_w = np.zeros((0, 3))
        self.prox = np.full(8, 4.0)
        self.prox_prev: tuple | None = None       # (t, ranges) for range-rate damping
        self.prox_rate = np.zeros(8)
        self.compute_ms: list[float] = []
        self._cycle_ms = 0.0
        self.records: list[dict] = []           # 10 Hz truth / estimate log for metrics
        self.frames: list[dict] = []
        self.triggers = sc.triggers(self) if sc.triggers else []
        self.time_in_state = {k: 0.0 for k in ("RELIABLE", "DEGRADED", "UNCERTAIN", "LOST", "RECOVERING")}
        self.goal_reached_t: list[float] = []
        # relocalization by backtracking: return to keyframes of the anchored map and look the same way
        self.bt: dict | None = None
        self.bt_await_since: float | None = None
        self.bt_exhausted = False
        self.finished = False
        self.log(0.0, "system", "info",
                 f"Session started: scenario {sc.id} '{sc.name}', seed {self.seed}, {SOFTWARE_VERSION}. "
                 f"SIMULATION MODE - all data simulated.", {})
        self.log(0.0, "sensors", "info", "GNSS denied (simulated): navigation uses IMU, stereo camera, optical flow, "
                 "rangefinder and barometer only.", {})

    # ================================================================== logging
    def log(self, t: float, category: str, severity: str, message: str, data: dict | None = None) -> None:
        ev = {"t": round(float(t), 2), "category": category, "severity": severity, "message": message,
              "data": data or {}}
        self.events.append(ev)
        self._new_events.append(ev)

    # ================================================================== environment / operator hooks
    def set_light(self, zone: str, level: float, message: str) -> None:
        z = self.world.zone(zone)
        if z is None:
            return
        z.level = float(level)
        self.log(self.t, "environment", "warning" if level < 0.5 else "info", message, {"zone": zone, "level": level})
        if self.environment_hook is not None:          # e.g. switch the rendered Gazebo lights as well
            self.environment_hook(zone, float(level))

    def inject_fault(self, name: str, message: str = "") -> None:
        self.sensors.faults[name] = {"t": self.t}
        self.log(self.t, "fault_injection", "warning", message or f"Fault injected: {name}", {"fault": name})

    def clear_fault(self, name: str, message: str = "") -> None:
        self.sensors.faults.pop(name, None)
        self.log(self.t, "fault_injection", "info", message or f"Fault cleared: {name}", {"fault": name})

    def inject_bias_jump(self, message: str) -> None:
        self.sensors.apply_imu_bias_jump(np.array([0.25, -0.15, 0.0]), np.array([0.0, 0.0, 0.004]))
        self.log(self.t, "fault_injection", "warning", message, {})

    def command(self, cmd: dict) -> dict:
        """Operator / researcher commands, applied at a step boundary and logged."""
        typ = cmd.get("type")
        if typ == "set_goal":
            g = np.array(cmd["goal"], float)
            if g.size == 2:
                g = np.append(g, self.cfg.planner.flight_altitude_m)
            self.goals = self.goals[: self.goal_idx] + [g]
            self.need_replan = "operator set a new goal"
            if self.mode in ("COMPLETE", "LANDED") and not self.crashed:
                self.mode = "TAKEOFF"
            self.log(self.t, "operator", "info", f"Operator goal set to ({g[0]:.1f}, {g[1]:.1f}, {g[2]:.1f})",
                     {"goal": g.tolist()})
        elif typ == "inject_fault":
            name = cmd["fault"]
            if name == "lights_off":
                self.set_light("corridor east circuit", 0.02, "Operator: corridor lighting switched off (simulated)")
            elif name == "imu_bias_jump":
                self.inject_bias_jump("Operator injected an accelerometer bias step")
            elif name == "link_loss":
                self.link_ok = False
                self.log(self.t, "fault_injection", "warning", "Telemetry link loss simulated", {})
            else:
                self.inject_fault(name, f"Operator injected fault: {name}")
        elif typ == "clear_fault":
            name = cmd["fault"]
            if name == "lights_off":
                self.set_light("corridor east circuit", 1.0, "Operator: corridor lighting restored (simulated)")
            elif name == "link_loss":
                self.link_ok = True
                self.log(self.t, "operator", "info", "Telemetry link restored", {})
            else:
                self.clear_fault(name)
        elif typ == "operator_decision":
            choice = cmd.get("choice")
            if choice == "land":
                self.mode = "LAND"
                self.log(self.t, "operator", "warning", "Operator decision: land in place", {})
            elif choice == "accept_estimate":
                self.loc.operator_reinitialize(self.t)
                self.need_replan = "operator re-referenced the estimate"
            elif choice == "restore_lights":
                self.set_light("corridor east circuit", 0.8, "Operator restored corridor lighting (simulated)")
            elif choice == "reengage" and hasattr(self.vehicle, "allow_reengage"):
                self.vehicle.allow_reengage()
                self.mode = "NAVIGATE"
                self.need_replan = "operator re-engaged DeepFlight after autopilot takeover"
            elif choice == "abort":
                self.mode = "LAND"
                self.log(self.t, "operator", "warning", "Operator aborted the mission: landing in place", {})
            self.operator_request_logged = False
        elif typ == "heartbeat":
            pass
        else:
            return {"ok": False, "error": f"unknown command {typ}"}
        return {"ok": True}

    # ================================================================== main loop
    @property
    def truth(self):
        return self.quad.s

    def step(self) -> None:
        if self.finished:
            return
        dt = self.dt
        self.k += 1
        self.t = round(self.k * dt, 6)
        t, k = self.t, self.k
        self.world.set_time(t)
        s = self.quad.s
        sc = self.cfg.sensors

        if getattr(self.vehicle, "autopilot_imu", False):
            for imu, imu_dt in self.vehicle.pop_imu(t):     # the autopilot's IMU (PX4 HIGHRES_IMU)
                self.loc.on_imu(imu, imu_dt)
        else:
            imu = self.sensors.imu(t, s, dt)
            if imu is not None:
                self.loc.on_imu(imu, dt)
        if s.landed and k % 10 == 0 and self.mode in ("PREFLIGHT", "TAKEOFF", "LANDED", "COMPLETE"):
            self.loc.on_landed(t)
        every = lambda hz: k % max(int(round(1.0 / (hz * dt))), 1) == 0
        camera_source = getattr(self.vehicle, "camera_source", False)
        if camera_source:
            # rendered camera (Gazebo): process every new frame as it arrives
            cam = self.vehicle.camera_frame(t)
            if cam is not None and (not s.landed or self.mode in ("PREFLIGHT", "TAKEOFF")):
                self.loc.on_camera(cam, t, allow_keyframes=self.integrity_state == "RELIABLE")
        elif every(sc.camera.rate_hz) and (not s.landed or self.mode in ("PREFLIGHT", "TAKEOFF")):
            cam = self.sensors.camera(t, s)
            self.loc.on_camera(cam, t, allow_keyframes=self.integrity_state == "RELIABLE")
        if every(10.0):
            self._mapping(t, s)
        if every(sc.flow.rate_hz):
            f = self.sensors.flow(t, s)
            if f is not None:
                self.loc.on_flow(f)
        if every(sc.rangefinder.rate_hz):
            r = self.sensors.rangefinder(t, s)
            if r is not None:
                self.loc.on_rangefinder(r)
        if every(sc.baro.rate_hz):
            b = self.sensors.baro(t, s, dt * max(int(round(1.0 / (sc.baro.rate_hz * dt))), 1))
            if b is not None:
                self.loc.on_baro(b)
        if every(10.0):
            c0 = time.perf_counter()
            self._supervise(t)
            self._navigate(t)
            for trig in self.triggers:
                if (not trig.fired or not trig.once) and trig.condition(self):
                    trig.fired = True
                    trig.action(self)
            self._cycle_ms += (time.perf_counter() - c0) * 1000
        # autopilot + dynamics (native model or PX4 SITL)
        e = self.loc.eskf
        cov = self.loc.global_cov() if self.vehicle.kind != "native" else None
        state = "RECOVERING" if self.loc.awaiting_reloc else self.integrity_state
        self.vehicle.step(t, dt, self.setpoint, EstimateView(e.p, e.v, e.R, cov, state, self.loc.segment,
                                                             e.P[3:6, 3:6] if cov is not None else None,
                                                             self.velocity_aided and self.loc.vio.quality.status in ("OK", "WEAK")))
        self._energy(self.vehicle.thrust, dt)
        if not s.landed and k % 5 == 0:
            self._collision_check(t)
        if every(10.0):
            self._record(t)

    def run_until(self, t_end: float) -> None:
        while self.t < t_end - 1e-9 and not self.finished:
            self.step()

    # ================================================================== subsystems
    def _mapping(self, t: float, s) -> None:
        if getattr(self.vehicle, "camera_source", False):
            cloud = self.vehicle.depth_cloud(t)          # rendered depth image (Gazebo)
        else:
            cloud = self.sensors.depth(t, s)
        prox_r, _ = self.world.raycast(np.repeat(s.p[None], 8, 0), PROX_DIRS @ s.R.T, 4.0)
        self.prox = np.where(np.isfinite(prox_r), prox_r + self.sensors.rng.normal(0, 0.02, 8), 4.0)
        if self.prox_prev is not None and t > self.prox_prev[0]:
            rate = (self.prox - self.prox_prev[1]) / (t - self.prox_prev[0])
            valid = (self.prox < 3.9) & (self.prox_prev[1] < 3.9)
            self.prox_rate = np.where(valid, 0.6 * self.prox_rate + 0.4 * rate, 0.0)
        self.prox_prev = (t, self.prox.copy())
        if cloud is None:
            self.latest_cloud_w = np.zeros((0, 3))
            return
        e = self.loc.eskf
        R_wc = e.R @ self.R_bc
        p_c = e.p + e.R @ self.t_bc
        pts_w = cloud.points_cam @ R_wc.T + p_c
        self.latest_cloud_w = pts_w
        self._cloud_body = cloud.points_cam @ self.R_bc.T + self.t_bc
        ok_state = self.integrity_state in ("RELIABLE", "DEGRADED") and not self.loc.awaiting_reloc
        if ok_state and not s.landed:
            self.vmap.integrate(p_c, pts_w, cloud.max_dirs_cam @ R_wc.T, self.cfg.sensors.camera.depth_max_range_m)

    def _supervise(self, t: float) -> None:
        dec, m = self.loc.evaluate(t)
        self.integrity_inputs = m
        self.time_in_state[dec.state] = self.time_in_state.get(dec.state, 0.0) + 0.1
        if dec.changed:
            sev = {"RELIABLE": "info", "DEGRADED": "warning", "UNCERTAIN": "warning", "LOST": "critical",
                   "RECOVERING": "info"}[dec.state]
            self.log(t, "integrity", sev, f"Localization {dec.previous} -> {dec.state}: " + "; ".join(dec.reasons[:3]),
                     {"from": dec.previous, "to": dec.state, "sigma_h": round(m.sigma_h, 3)})
            if dec.state in ("RELIABLE",) and dec.previous == "RECOVERING":
                self.need_replan = "localization recovered"
        self.integrity_state = dec.state
        self.integrity_reasons = dec.reasons
        self.operator_required = dec.operator_required
        # fault detection
        detected = set()
        H = self.loc.health
        if H["camera"].status == "FAILED":
            detected.add("CAMERA_FAIL")
        if H["camera"].status == "STALE":
            detected.add("CAMERA_STALE")
        if self.loc.vio.quality.status in ("WEAK", "LOST", "NO_FEATURES") and not self.quad.s.landed:
            detected.add("VISUAL_DEGRADED")
        if H["imu"].status in ("FAILED", "STALE") or (H["camera"].nis_ema or 0) > 6.0:
            detected.add("IMU_DEGRADED")
        if H["flow"].enabled and (H["flow"].status != "OK") and not self.quad.s.landed:
            detected.add("FLOW_DEGRADED")
        if H["rangefinder"].status == "FAILED" and not self.quad.s.landed:
            detected.add("RANGEFINDER_FAIL")
        if H["baro"].status == "FAILED":
            detected.add("BARO_FAIL")
        if H["lidar"].enabled and H["lidar"].status == "FAILED":
            detected.add("LIDAR_FAIL")
        detected.add("GNSS_DENIED")
        st = dec.state
        if st == "DEGRADED":
            detected.add("LOC_DEGRADED")
        elif st == "UNCERTAIN":
            detected.add("LOC_UNCERTAIN")
        elif st == "LOST":
            detected.add("LOC_LOST")
        if self.vmap.conflict_ratio > 0.25:
            detected.add("MAP_INCONSISTENT")
        if self.prox.min() < self.cfg.planner.reactive_stop_m and not self.quad.s.landed:
            detected.add("OBSTACLE_PROXIMITY")
        pct = self.battery_pct()
        if pct < self.cfg.safety.low_battery_pct:
            detected.add("BATTERY_LOW")
        if pct < self.cfg.safety.critical_battery_pct:
            detected.add("BATTERY_CRITICAL")
        self.compute_ms.append(self._cycle_ms)
        self._cycle_ms = 0.0
        if self.wallclock_monitors and len(self.compute_ms) > 20 and                 np.mean(self.compute_ms[-20:]) > self.cfg.safety.compute_budget_ms:
            detected.add("COMPUTE_OVERLOAD")
        if not self.link_ok:
            detected.add("LINK_LOSS")
        raised, cleared = self.safety.update_faults(t, detected)
        for f in raised:
            if f in ("GNSS_DENIED",) and t > 0.2:
                continue
            fc = FAULT_CATALOG[f]
            sev = {"info": "info", "minor": "warning", "major": "warning", "critical": "critical"}[fc["severity"]]
            self.log(t, "fault", sev, f"{fc['name']} detected -> {fc['response']}", {"fault": f})
        for f in cleared:
            self.log(t, "fault", "info", f"{FAULT_CATALOG[f]['name']} cleared", {"fault": f})
        if self.mode in ("PREFLIGHT", "LANDED", "COMPLETE", "CRASHED"):
            return
        self.velocity_aided = t - max(self.loc.last_vel_aiding_t, self.loc.last_map_aiding_t) < 0.5
        a = self.safety.decide(t, st, dec.operator_required, pct, self.link_ok, self.velocity_aided,
                               self.loc.vio.quality.status in ("OK", "WEAK") and not self.loc.awaiting_reloc)
        if a.behaviour != self.behaviour:
            self.log(t, "safety", "warning" if a.behaviour != "NOMINAL" else "info",
                     f"Movement authority: {self.behaviour} -> {a.behaviour}"
                     + (f" ({'; '.join(a.reasons)})" if a.reasons else ""), {"behaviour": a.behaviour})
            if a.behaviour in ("HOLD", "RECOVERY_SEARCH", "OPERATOR_WAIT"):
                self.hold_yaw = self.loc.eskf.yaw()
                self.follower.reset()
            if a.behaviour in ("NOMINAL", "REDUCED") and self.behaviour not in ("NOMINAL", "REDUCED"):
                self.need_replan = "resuming after hold"
            self.behaviour = a.behaviour
        if a.behaviour == "OPERATOR_WAIT" and not self.operator_request_logged:
            self.operator_request_logged = True
            self.log(t, "operator", "critical",
                     "OPERATOR INTERVENTION REQUESTED: position cannot be re-established autonomously. Options: "
                     "land in place, restore lighting (simulation), or accept the current estimate.", {})
        if a.behaviour == "LAND" and self.mode != "LAND":
            self.mode = "LAND"
            self.log(t, "mission", "warning", "Landing in place (" + "; ".join(a.reasons) + ")", {})

    def _repulsion(self, v: np.ndarray) -> np.ndarray:
        """Reactive layer on raw proximity + depth data (independent of map and localization)."""
        e = self.loc.eskf
        stop = self.cfg.planner.reactive_stop_m
        yaw = e.yaw()
        Rz = rot_z(yaw)
        dirs, ranges = [PROX_DIRS @ Rz.T], [self.prox]
        if getattr(self, "_cloud_body", None) is not None and self._cloud_body.size:
            cb = self._cloud_body
            d = np.linalg.norm(cb, axis=1)
            near = (d < 1.2) & (np.abs(cb[:, 2]) < 0.4)
            if near.any():
                u = cb[near] / d[near, None]
                dirs.append((u @ e.R.T))
                ranges.append(d[near])
        dirs = np.vstack(dirs)
        ranges = np.concatenate(ranges)
        out = v.copy()
        for u, r in zip(dirs, ranges):
            u = u.copy()
            u[2] = 0.0
            nu = np.linalg.norm(u)
            if nu < 1e-6 or r > stop + 0.35:
                continue
            u /= nu
            toward = out[:2] @ u[:2]
            if toward > 0 and r < stop + 0.35:
                out[:2] -= toward * u[:2] * min(1.0, (stop + 0.35 - r) / 0.35)
            if r < stop:
                out[:2] -= u[:2] * 0.8 * (stop - r) / stop
        return out

    def _repulsion_accel(self) -> np.ndarray:
        """Acceleration for the estimate-independent fallback (no velocity aiding):

        * away from close surfaces (proximity ring; needs no position/velocity estimate);
        * damping of motion relative to surfaces from the ring's range rates (estimate-independent);
        * braking on the inertially propagated velocity, weighted by its own uncertainty: full while
          sigma_v <= 0.2 m/s, none once sigma_v >= 0.6 m/s (IMU-only velocity is trustworthy only briefly).
        Without brake and damping, a low-drag airframe coasts on - into walls, or (Gazebo x500, camera M1)
        7.7 m down a corridor after the push from a door frame."""
        Rz = rot_z(self.loc.eskf.yaw())
        a = np.zeros(3)
        P = self.loc.eskf.P
        sigma_v = float(np.sqrt(max(P[3, 3], P[4, 4])))
        w = float(np.clip((0.6 - sigma_v) / 0.4, 0.0, 1.0))
        a[:2] -= 1.5 * w * self.loc.eskf.v[:2]
        dirs = PROX_DIRS @ Rz.T
        for u, r, rr in zip(dirs, self.prox, self.prox_rate):
            if r < 1.1:
                a[:2] -= u[:2] * 1.6 * (1.1 - r) / 1.1
            if r < 3.9 and rr < 0.0:                 # closing on a surface along u: oppose the closing speed
                a[:2] -= u[:2] * 1.0 * min(-rr, 1.5)
        n = float(np.linalg.norm(a[:2]))
        if n > 2.0:
            a[:2] *= 2.0 / n
        return a

    def _navigate(self, t: float) -> None:
        e = self.loc.eskf
        alt = self.cfg.planner.flight_altitude_m
        sp = Setpoint()
        if self.mode == "PREFLIGHT":
            ready = getattr(self.vehicle, "ready", True)
            if not ready and t > 120.0:
                self.mode = "LANDED"
                self.log(t, "mission", "critical", "Autopilot pre-arm checks did not pass within 120 s: mission not started", {})
            elif not ready and int(t * 10) % 100 == 0:
                self.log(t, "mission", "info", "Waiting for autopilot pre-arm checks (EKF2 alignment / vision fusion)", {})
            if t >= 2.0 and self.goals and ready and self.mode == "PREFLIGHT":
                self.mode = "TAKEOFF"
                self.vehicle.armed = True
                self.takeoff_cmd_t = t
                self.log(t, "mission", "info", f"Armed; taking off to {alt:.1f} m (home pad, surveyed position)", {})
            self.setpoint = sp
            return
        if self.mode in ("LANDED", "COMPLETE", "CRASHED"):
            self.setpoint = Setpoint("idle")
            if self.quad.s.landed:
                self.vehicle.armed = False
            return
        if self.mode == "LAND":
            # in the last 0.6 m the proximity ring sees furniture as "walls": descend straight down, no repulsion
            near_ground = e.p[2] - self.home[2] < 0.6
            if self.velocity_aided:
                v = np.zeros(3) if near_ground else self._repulsion(np.zeros(3))
                sp = Setpoint("land", velocity=v, yaw=self.hold_yaw)
            else:   # no trustworthy velocity: level descent with proximity repulsion only
                sp = Setpoint("land", accel=np.zeros(3) if near_ground else self._repulsion_accel(), yaw=self.hold_yaw)
            if self.quad.s.landed:
                self.mode = "COMPLETE" if self.goal_idx >= len(self.goals) else "LANDED"
                self.log(t, "mission", "info", "Landed. Motors disarmed.", {})
            self.setpoint = sp
            return
        if self.mode == "TAKEOFF":
            if self.loc.home_locked and not self.quad.s.landed:
                # the pad constraint is released only once the vehicle has really left the ground (an external
                # autopilot may take several seconds to arm)
                self.loc.on_takeoff()
                self.log(t, "mission", "info", "Lift-off detected; releasing the surveyed-pad constraint", {})
            elif self.loc.home_locked and t - self.takeoff_cmd_t > 15.0:
                self.mode = "LANDED"
                self.vehicle.armed = False
                self.log(t, "mission", "critical", "Autopilot did not arm / lift off within 15 s: mission aborted "
                         "on the ground", {})
                self.setpoint = Setpoint("idle")
                return
            sp = Setpoint("position", position=np.array([self.home[0], self.home[1], alt]), yaw=self.scenario.start_yaw)
            if e.p[2] > alt - 0.15:
                self.mode = "NAVIGATE"
                self.log(t, "mission", "info", "Take-off complete; navigating to goal 1", {})
            self.setpoint = sp
            return
        # ---- autopilot (PX4 failsafe / pilot) has taken control: DeepFlight only monitors
        if getattr(self.vehicle, "autopilot_override", False):
            if self.mode != "AUTOPILOT_CONTROL":
                self.mode = "AUTOPILOT_CONTROL"
                self.log(t, "mission", "critical", "Autopilot has control (failsafe or pilot); mission suspended. "
                         "Operator decision needed: let it land, or re-engage DeepFlight", {})
            self.setpoint = Setpoint("idle")
            if self.quad.s.landed:
                self.mode = "LANDED"
                self.vehicle.armed = False
                self.log(t, "mission", "warning", "Vehicle landed under autopilot control; mission ended", {})
            return
        # ---- NAVIGATE (subject to safety authority)
        beh = self.behaviour
        if beh in ("HOLD", "OPERATOR_WAIT", "RECOVERY_SEARCH") and not self.velocity_aided:
            self.setpoint = Setpoint("altitude", position=np.array([0, 0, self.hold_alt]),
                                     accel=self._repulsion_accel(), yaw=self.hold_yaw)
            return
        if beh in ("HOLD", "OPERATOR_WAIT", "RECOVERY_SEARCH"):
            v = self._repulsion(np.zeros(3))
            poor_view = self.loc.vio.quality.status not in ("OK",) and self.integrity_state != "RELIABLE"
            if beh == "RECOVERY_SEARCH" or (beh == "HOLD" and poor_view):
                sp = Setpoint("velocity", position=np.array([0, 0, self.hold_alt]), velocity=v,
                              yaw_rate=np.deg2rad(self.cfg.safety.search_yaw_rate_dps))
            else:
                sp = Setpoint("velocity", position=np.array([0, 0, self.hold_alt]), velocity=v, yaw=self.hold_yaw)
            self.setpoint = sp
            return
        if self.goal_idx >= len(self.goals):
            self.mode = "LAND"
            self.hold_yaw = e.yaw()
            self.log(t, "mission", "info", "All goals reached; landing", {})
            return
        goal = self.goals[self.goal_idx]
        bt = self._backtrack(t)
        if bt is not None:
            goal = bt["p"]
        sigma = self.loc.sigma_local()
        reason = self.need_replan
        if reason is None:
            if t - self.last_plan_t > self.cfg.planner.replan_period_s:
                reason = "periodic"
            elif self.path.shape[0] >= 2 and t - self.last_plan_t > 0.5 and \
                    self.planner.path_blocked(self.path, self.follower.progress_idx, sigma):
                reason = "new obstacle on the planned route"
            elif abs(self.planner.inflation(sigma) - self.planner.inflation(self.last_plan_sigma)) > 0.15:
                reason = "safety margin changed with localization uncertainty"
        if reason is not None:
            self._replan(t, goal, sigma, reason)
        if self.path.shape[0] < 2:
            v = self._repulsion(np.zeros(3))
            self.setpoint = Setpoint("velocity", position=np.array([0, 0, alt]), velocity=v, yaw=e.yaw())
            return
        clearance = float(min(self.prox.min(), 3.0))
        v, yaw, to_goal = self.follower.step(e.p, self.path, self.safety.authority.speed_scale, clearance, 0.1)
        if bt is not None and np.linalg.norm(e.p[:2] - bt["p"][:2]) < 0.4:
            # at the keyframe: stop and take its heading, so the camera sees what the keyframe saw
            v, yaw = np.zeros(3), bt["yaw"]
            bt["arrived"] = bt["arrived"] if bt["arrived"] is not None else t
        v = self._repulsion(v)
        self.setpoint = Setpoint("velocity", position=np.array([0, 0, alt]), velocity=v,
                                 yaw=yaw if yaw is not None else e.yaw())
        # goal acceptance needs a valid, anchored estimate; in UNCERTAIN it is accepted with its sigma recorded
        if bt is None and to_goal < self.cfg.planner.goal_tolerance_m and self.integrity_state in ("RELIABLE", "DEGRADED", "UNCERTAIN")                 and not self.loc.awaiting_reloc:
            self.goal_reached_t.append(t)
            self.log(t, "mission", "info", f"Goal {self.goal_idx + 1} reached (estimate within "
                     f"{self.cfg.planner.goal_tolerance_m} m, global sigma_h {self.loc.sigma_h():.2f} m)",
                     {"goal": self.goal_idx + 1, "truth_error_m": float(np.linalg.norm(self.quad.s.p[:2] - goal[:2]))})
            self.goal_idx += 1
            self.path = np.zeros((0, 3))
            self.follower.reset()
            self.need_replan = f"next goal" if self.goal_idx < len(self.goals) else None

    def _backtrack(self, t: float) -> dict | None:
        """Relocalization by revisiting: when the global position is still not re-established a few seconds after
        visual tracking (and flight) resumed, fly back to the newest keyframe of the anchored map and face its
        heading - place recognition needs a similar viewpoint (a real front end, unlike the simulator's oracle
        words, does not match the same wall seen from twice as close). If no match comes within 6 s, try a
        keyframe further back; after three tries continue the mission unanchored (goals are then not accepted)."""
        if not self.loc.awaiting_reloc:
            if self.bt is not None:
                self.log(t, "relocalization", "info", "Relocalized while backtracking; resuming the mission", {})
                self.need_replan = "relocalized; resuming mission"
            self.bt, self.bt_await_since, self.bt_exhausted = None, None, False
            return None
        if self.behaviour not in ("NOMINAL", "REDUCED") or self.bt_exhausted:
            return self.bt
        if self.bt_await_since is None:
            self.bt_await_since = t
        if self.bt is None and t - self.bt_await_since < 4.0:
            return None
        if self.bt is not None and (self.bt["arrived"] is None or t - self.bt["arrived"] < 6.0)                 and t - self.bt["t0"] < 40.0:
            return self.bt
        rank = 0 if self.bt is None else self.bt["rank"] + 3
        # keyframes are only created while anchored, so every keyframe belongs to the global map
        kfs = sorted(self.loc.kfdb.keyframes, key=lambda k: -k.t)
        if rank >= min(len(kfs), 9):
            self.bt, self.bt_exhausted = None, True
            self.log(t, "relocalization", "warning", "Backtracking did not relocalize; continuing unanchored "
                     "(goals are not accepted until the position is re-established)", {})
            self.need_replan = "backtracking abandoned"
            return None
        kf = kfs[rank]
        self.bt = {"rank": rank, "kf": kf.kf_id, "p": np.array([kf.p[0], kf.p[1], self.cfg.planner.flight_altitude_m]),
                   "yaw": kf.yaw, "arrived": None, "t0": t}
        self.need_replan = f"backtracking to keyframe #{kf.kf_id} to relocalize"
        self.log(t, "relocalization", "info", f"Position not re-established: returning to keyframe #{kf.kf_id} "
                 f"({np.linalg.norm(self.loc.eskf.p[:2] - kf.p[:2]):.1f} m back) to look at mapped surroundings",
                 {"kf": kf.kf_id})
        return self.bt

    def _replan(self, t: float, goal: np.ndarray, sigma: float, reason: str) -> None:
        e = self.loc.eskf
        res = self.planner.plan(e.p, goal, sigma)
        self.last_plan_t = t
        self.last_plan_sigma = sigma
        self.need_replan = None
        self.replans += 1
        self.plan_info = {"ok": res.ok, "reason": reason, "fail_reason": res.reason, "expansions": res.expansions,
                          "compute_ms": round(res.compute_ms, 1), "inflation_m": round(res.inflation_m, 2),
                          "min_clearance_m": round(res.min_clearance_m, 2), "length_m": round(res.length_m, 1),
                          "t": round(t, 2)}
        if res.ok:
            self._last_plan_fail = None
            changed = self.path.shape[0] < 2 or self.path.shape != res.path.shape or \
                np.max(np.abs(self.path[-1] - res.path[-1])) > 0.01 or \
                (self.path.shape == res.path.shape and np.max(np.abs(self.path - res.path)) > 0.6)
            self.path = res.path
            self.follower.progress_idx = 0
            if reason != "periodic" or changed:
                self.replan_reasons.append({"t": round(t, 2), "reason": reason, "length_m": round(res.length_m, 1)})
                if reason != "periodic":
                    self.log(t, "planning", "info",
                             f"Route planned ({reason}): {res.length_m:.1f} m, margin {res.inflation_m:.2f} m "
                             f"(local sigma {sigma:.2f} m)", self.plan_info)
        else:
            self.path = np.zeros((0, 3))
            key = res.reason
            if key != getattr(self, "_last_plan_fail", None) or t - getattr(self, "_last_plan_fail_t", -99) > 15:
                self._last_plan_fail, self._last_plan_fail_t = key, t
                self.log(t, "planning", "warning", f"Planning failed ({reason}): {res.reason}; holding and retrying",
                         self.plan_info)

    def _energy(self, thrust: float, dt: float) -> None:
        ac = self.cfg.aircraft
        flying = not self.quad.s.landed
        p = (ac.hover_power_w * (max(thrust, 0.0) / 9.81) ** 1.5 if flying else 0.0) + ac.companion_power_w
        self.power_w = p
        self.battery_wh = max(self.battery_wh - p * dt / 3600.0, 0.0)

    def battery_pct(self) -> float:
        return 100.0 * self.battery_wh / self.cfg.aircraft.battery_wh

    def _collision_check(self, t: float) -> None:
        s = self.quad.s
        r = self.cfg.aircraft.collision_radius_m
        # clearance to nearest non-floor geometry (validation metric)
        bmin, bmax = self.world._bmin[1:], self.world._bmax[1:]
        closest = np.clip(s.p[None], bmin, bmax)
        d = float(np.min(np.linalg.norm(closest - s.p[None], axis=1)))
        if s.p[2] > 0.5:
            self.min_clearance = min(self.min_clearance, d)
        hit = d < r
        if hit and not self.crashed:
            self.crashed = True
            self.collisions.append({"t": round(t, 2), "p": np.round(s.p, 2).tolist()})
            self.log(t, "safety", "critical", f"COLLISION (simulation truth) at ({s.p[0]:.1f}, {s.p[1]:.1f}, {s.p[2]:.1f})", {})
            self.mode = "CRASHED"
            self.vehicle.crash()

    # ================================================================== outputs
    def _record(self, t: float) -> None:
        e = self.loc.eskf
        s = self.quad.s
        cov = self.loc.global_cov()
        self.records.append({
            "t": t, "truth": s.p.copy(), "est": e.p.copy(), "cov": cov.copy(), "truth_yaw": s.yaw,
            "est_yaw": e.yaw(), "state": self.integrity_state, "mode": self.mode, "behaviour": self.behaviour,
            "inliers": self.loc.vio.quality.inliers, "flying": not s.landed,
        })
        if self.mode in ("COMPLETE", "CRASHED") or t >= self.scenario.duration_s:
            if not self.finished:
                self.finished = True
                self.log(t, "system", "info", f"Scenario finished ({self.mode}).", {})
        self.frames.append(self.frame())

    def estimate_source(self) -> str:
        c = self.loc.contributions()
        parts = []
        if c["vio"]:
            parts.append("VIO")
        if c["flow"]:
            parts.append("optical flow")
        if c["rangefinder"]:
            parts.append("rangefinder")
        if c["baro"]:
            parts.append("baro")
        if c["reloc"] or c["loop"]:
            parts.append("place recognition")
        if c["zupt"]:
            parts.append("ZUPT/home pad")
        return " + ".join(["IMU"] + parts) if parts else "IMU dead-reckoning only"

    def frame(self, full: bool = False) -> dict:
        e = self.loc.eskf
        s = self.quad.s
        cov = self.loc.global_cov()
        yaw, pitch, roll = ypr_from_rot(e.R)
        added, removed = self.vmap.pop_diff()
        lm = self.loc.vio.landmark_array(300)
        inl = set(self.loc.vio.inlier_ids.tolist())
        q = self.loc.vio.quality
        valid = self.integrity_state in ("RELIABLE", "DEGRADED", "RECOVERING") and not (
            self.integrity_state == "RECOVERING" and self.loc.awaiting_reloc)
        if self.integrity_state in ("UNCERTAIN",):
            valid = True
        events, self._new_events = self._new_events, []
        cloud = self.latest_cloud_w
        if cloud.shape[0] > 260:
            cloud = cloud[:: int(np.ceil(cloud.shape[0] / 260))]
        r = lambda a, n=2: np.round(np.asarray(a, float), n).tolist()
        err = float(np.linalg.norm(s.p - e.p))
        return {
            "t": round(self.t, 2),
            "mode": self.mode, "behaviour": self.behaviour,
            "integrity": {"state": self.integrity_state, "reasons": self.integrity_reasons[:4],
                          "operator_required": self.behaviour == "OPERATOR_WAIT",
                          "segment": self.loc.segment, "anchored": not self.loc.awaiting_reloc},
            "est": {"p": r(e.p, 3), "v": r(e.v, 3), "yaw": round(yaw, 4), "pitch": round(pitch, 4),
                    "roll": round(roll, 4), "cov": r(cov, 5), "sigma_h": round(self.loc.sigma_h(), 3),
                    "sigma_v": round(float(np.sqrt(max(cov[2, 2], 0))), 3),
                    "sigma_vel": round(float(np.sqrt(max(np.trace(e.P[3:6, 3:6]) / 3, 0))), 3),
                    "sigma_yaw_deg": round(float(np.rad2deg(self.loc.yaw_sigma())), 2),
                    "sigma_att_deg": round(float(np.rad2deg(np.sqrt(max((e.P[6, 6] + e.P[7, 7]) / 2, 0)))), 2),
                    "valid": bool(valid), "source": self.estimate_source(),
                    "ba": r(e.ba, 3), "bg": r(e.bg, 4)},
            "truth": {"p": r(s.p, 3), "yaw": round(s.yaw, 4), "pitch": round(s.pitch, 4), "roll": round(s.roll, 4),
                      "error_m": round(err, 3), "label": "simulation ground truth - validation only"},
            "vio": q.to_dict(),
            "landmarks": r(lm, 2),
            "inlier_count": len(inl),
            "health": {k: h.to_dict() for k, h in self.loc.health.items()},
            "contrib": self.loc.contributions(),
            "map": {"added": added, "removed": removed, **(self.vmap.stats() if self.k % 100 == 0 or full else {})},
            "cloud": r(cloud, 2),
            "prox": r(self.prox, 2),
            "path": r(self.path, 2),
            "goal": r(self.goals[self.goal_idx], 2) if self.goal_idx < len(self.goals) else None,
            "goal_idx": self.goal_idx, "goals_total": len(self.goals),
            "plan": self.plan_info,
            "setpoint": {"mode": self.setpoint.mode,
                         "v": r(self.setpoint.velocity if self.setpoint.velocity is not None else np.zeros(3), 2),
                         "speed_scale": self.safety.authority.speed_scale},
            "battery": {"pct": round(self.battery_pct(), 1), "power_w": round(self.power_w, 0)},
            "faults": self.safety.active_list(),
            "place": self.loc.last_match,
            "keyframes": len(self.loc.kfdb.keyframes),
            "stats": self.loc.stats,
            "compute_ms": round(float(np.mean(self.compute_ms[-10:])) if self.compute_ms else 0.0, 1),
            "events": events,
            "finished": self.finished,
            "lights": {z.name: z.level for z in self.world.light_zones},
            "movers": [r(m.box.bmin.tolist() + m.box.bmax.tolist(), 2) for m in self.world.movers],
        }

    def session_info(self) -> dict:
        vm = self.vmap
        return {
            "scenario": self.scenario.summary(), "seed": self.seed, "software_version": SOFTWARE_VERSION,
            "config": self.cfg.to_dict(), "overrides": self.overrides,
            "world": self.world.to_dict(),
            "voxel": {"origin": vm.origin.tolist(), "shape": [int(x) for x in vm.shape], "res": float(vm.res)},
            "home": self.home.tolist(), "goals": [g.tolist() for g in self.goals],
            "camera": {"R_bc": self.R_bc.tolist(), "t_bc": self.t_bc.tolist(),
                       "hfov_deg": float(np.rad2deg(2 * np.arctan(self.cfg.sensors.camera.width / 2 / self.cfg.sensors.camera.fx))),
                       "vfov_deg": float(np.rad2deg(2 * np.arctan(self.cfg.sensors.camera.height / 2 / self.cfg.sensors.camera.fy))),
                       "depth_range": self.cfg.sensors.camera.depth_max_range_m},
            "mode": "SIMULATION",
        }

    def keyframe_list(self) -> list[dict]:
        return self.loc.kfdb.to_list()

    def occupied_voxels(self) -> list[int]:
        return self.vmap.occupied_indices().tolist()
