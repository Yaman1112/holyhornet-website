"""Uncertainty-aware global planning (2.5-D A* on the voxel map) and a local trajectory follower.

* The occupancy slice at flight altitude (+/- band) is inflated by
  ``base_margin + k * sigma_h`` (clamped) - a route is not "safe" merely because it avoids obstacles in
  the estimated map; it must clear them by the current localization uncertainty.
* Unknown space is traversable at a cost (the environment is unfamiliar) - the local layer re-checks
  clearance against the live map and raw depth before every step.
* The follower enforces speed / acceleration / yaw-rate limits and slows down near obstacles, so the
  commanded motion is dynamically feasible for the emulated autopilot.
"""
from __future__ import annotations

import heapq
from dataclasses import dataclass, field

import numpy as np

from ..config import PlannerConfig
from ..mapping.voxel_map import VoxelMap

SQ2 = np.sqrt(2.0)
NBRS = [(1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0), (1, 1, SQ2), (1, -1, SQ2), (-1, 1, SQ2), (-1, -1, SQ2)]


@dataclass
class PlanResult:
    ok: bool
    path: np.ndarray = field(default_factory=lambda: np.zeros((0, 3)))
    reason: str = ""
    expansions: int = 0
    compute_ms: float = 0.0
    inflation_m: float = 0.0
    min_clearance_m: float = 0.0
    length_m: float = 0.0


class GlobalPlanner:
    def __init__(self, cfg: PlannerConfig, vmap: VoxelMap):
        self.cfg = cfg
        self.vmap = vmap
        self.last_grid: dict | None = None

    def inflation(self, sigma_h: float) -> float:
        c = self.cfg
        return float(min(c.base_margin_m + c.sigma_inflation_k * sigma_h, c.max_inflation_m))

    def grid(self, sigma_h: float) -> dict:
        c = self.cfg
        blocked, unknown = self.vmap.planning_slice(c.flight_altitude_m, c.altitude_band_m)
        dist = self.vmap.distance_field(blocked)
        infl = self.inflation(sigma_h)
        g = {"blocked": blocked, "unknown": unknown, "dist": dist, "inflation": infl,
             "res": self.vmap.res, "origin": self.vmap.origin[:2]}
        self.last_grid = g
        return g

    def cell(self, p: np.ndarray) -> tuple[int, int]:
        ij = np.floor((p[:2] - self.vmap.origin[:2]) / self.vmap.res).astype(int)
        return int(np.clip(ij[0], 0, self.vmap.shape[0] - 1)), int(np.clip(ij[1], 0, self.vmap.shape[1] - 1))

    def center(self, ij) -> np.ndarray:
        return self.vmap.origin[:2] + (np.array(ij) + 0.5) * self.vmap.res

    def plan(self, start: np.ndarray, goal: np.ndarray, sigma_h: float) -> PlanResult:
        import time
        t0 = time.perf_counter()
        c = self.cfg
        g = self.grid(sigma_h)
        dist, unknown, infl = g["dist"], g["unknown"], g["inflation"]
        nx, ny = dist.shape
        s, goal_ij = self.cell(start), self.cell(goal)
        if dist[goal_ij] < infl * 0.8:
            return PlanResult(False, reason=f"goal within {infl:.2f} m inflated obstacle clearance", inflation_m=infl)
        passable = dist >= infl
        # the vehicle may currently sit inside the inflated zone (after uncertainty grew): allow escape
        escape_r = int(np.ceil(0.6 / self.vmap.res))
        si, sj = s
        passable[max(si - escape_r, 0):si + escape_r + 1, max(sj - escape_r, 0):sj + escape_r + 1] |= \
            dist[max(si - escape_r, 0):si + escape_r + 1, max(sj - escape_r, 0):sj + escape_r + 1] > 0.25
        # soft clearance cost on top of the hard margin: strongly prefer the middle of doorways / corridors so
        # path-tracking error (larger with a real autopilot, e.g. PX4 in Gazebo) does not bring the hull to a wall
        cost_extra = np.where(unknown, c.unknown_cost - 1.0, 0.0) + c.clearance_cost * np.clip(0.9 - dist, 0.0, None) ** 2             + 0.6 * np.clip(1.2 - dist, 0.0, None)
        gx, gy = goal_ij
        openq = [(0.0, 0.0, s)]
        came: dict = {s: None}
        gcost = {s: 0.0}
        exp = 0
        found = False
        while openq:
            _, gc, cur = heapq.heappop(openq)
            if cur == goal_ij:
                found = True
                break
            if gc > gcost.get(cur, np.inf) + 1e-9:
                continue
            exp += 1
            if exp > 60000:
                break
            ci, cj = cur
            for di, dj, w in NBRS:
                ni, nj = ci + di, cj + dj
                if ni < 0 or nj < 0 or ni >= nx or nj >= ny or not passable[ni, nj]:
                    continue
                if di and dj and (not passable[ci + di, cj] or not passable[ci, cj + dj]):
                    continue
                ng = gc + w * (1.0 + cost_extra[ni, nj])
                nb = (ni, nj)
                if ng < gcost.get(nb, np.inf):
                    gcost[nb] = ng
                    came[nb] = cur
                    h = np.hypot(ni - gx, nj - gy)
                    heapq.heappush(openq, (ng + h, ng, nb))
        ms = (time.perf_counter() - t0) * 1000
        if not found:
            return PlanResult(False, reason="no collision-free route in the current map with the current safety margin",
                              expansions=exp, compute_ms=ms, inflation_m=infl)
        cells = []
        cur = goal_ij
        while cur is not None:
            cells.append(cur)
            cur = came[cur]
        cells.reverse()
        pts = self._shortcut(cells, passable)
        xy = np.array([self.center(ij) for ij in pts])
        xy[0] = start[:2]
        xy[-1] = goal[:2]
        path = np.column_stack([xy, np.full(len(xy), c.flight_altitude_m)])
        clear = float(min(dist[ij] for ij in cells))
        length = float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
        return PlanResult(True, path, "", exp, ms, infl, clear, length)

    @staticmethod
    def _line_ok(a, b, passable) -> bool:
        n = int(max(abs(b[0] - a[0]), abs(b[1] - a[1]))) * 2 + 1
        for s in np.linspace(0.0, 1.0, n):
            i = int(round(a[0] + (b[0] - a[0]) * s))
            j = int(round(a[1] + (b[1] - a[1]) * s))
            if not passable[i, j]:
                return False
        return True

    def _shortcut(self, cells, passable):
        out = [cells[0]]
        i = 0
        while i < len(cells) - 1:
            j = len(cells) - 1
            while j > i + 1 and not self._line_ok(cells[i], cells[j], passable):
                j -= 1
            out.append(cells[j])
            i = j
        return out

    def path_blocked(self, path: np.ndarray, from_idx: int, sigma_h: float) -> bool:
        """True if the remaining path now crosses inflated obstacles in the latest map."""
        if path.shape[0] < 2:
            return False
        g = self.grid(sigma_h)
        dist, infl = g["dist"], g["inflation"]
        for a, b in zip(path[from_idx:-1], path[from_idx + 1:]):
            L = np.linalg.norm(b[:2] - a[:2])
            for s in np.linspace(0, 1, max(int(L / 0.1), 2)):
                ij = self.cell(a + (b - a) * s)
                if dist[ij] < infl * 0.7:
                    return True
        return False


class PathFollower:
    """Carrot-chasing follower producing velocity + yaw setpoints within the vehicle limits."""

    def __init__(self, cfg: PlannerConfig, max_speed: float, max_accel: float, max_yaw_rate_dps: float):
        self.cfg = cfg
        self.max_speed = max_speed
        self.max_accel = max_accel
        self.max_yaw_rate = np.deg2rad(max_yaw_rate_dps)
        self.v_cmd = np.zeros(3)
        self.progress_idx = 0

    def reset(self) -> None:
        self.v_cmd = np.zeros(3)
        self.progress_idx = 0

    def step(self, p: np.ndarray, path: np.ndarray, speed_scale: float, clearance: float, dt: float):
        c = self.cfg
        if path.shape[0] < 2:
            return np.zeros(3), None, 0.0
        # project onto the path, advance progress index monotonically
        best_d, best_i, best_pt = np.inf, self.progress_idx, path[self.progress_idx]
        for i in range(self.progress_idx, path.shape[0] - 1):
            a, b = path[i], path[i + 1]
            ab = b - a
            s = np.clip(np.dot(p - a, ab) / max(np.dot(ab, ab), 1e-9), 0, 1)
            q = a + ab * s
            d = np.linalg.norm(p[:2] - q[:2])
            if d < best_d:
                best_d, best_i, best_pt = d, i, q
        self.progress_idx = best_i
        # carrot point
        remaining = c.lookahead_m
        carrot = best_pt.copy()
        i = best_i
        while remaining > 0 and i < path.shape[0] - 1:
            seg = path[i + 1] - carrot
            L = np.linalg.norm(seg)
            if L >= remaining:
                carrot = carrot + seg / max(L, 1e-9) * remaining
                remaining = 0
            else:
                carrot = path[i + 1].copy()
                remaining -= L
                i += 1
        to_goal = np.linalg.norm(path[-1][:2] - p[:2])
        vmax = self.max_speed * speed_scale
        vmax = min(vmax, 0.35 + 0.45 * max(clearance - 0.3, 0.0))       # slow near obstacles
        vmax = min(vmax, np.sqrt(2 * 0.6 * max(to_goal, 0.0)) + 0.05)     # brake into the goal
        d = carrot - p
        d[2] = 0.0
        n = np.linalg.norm(d)
        v_des = d / n * vmax if n > 1e-6 else np.zeros(3)
        dv = v_des - self.v_cmd
        lim = self.max_accel * dt
        if np.linalg.norm(dv) > lim:
            dv *= lim / np.linalg.norm(dv)
        self.v_cmd = self.v_cmd + dv
        yaw = float(np.arctan2(d[1], d[0])) if n > 0.2 else None
        return self.v_cmd.copy(), yaw, float(to_goal)
