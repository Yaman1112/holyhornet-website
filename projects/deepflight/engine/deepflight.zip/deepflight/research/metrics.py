"""Validation metrics computed against simulation ground truth.

All metrics use the 10 Hz records of a run. The map frame is defined by the surveyed take-off pad, so
ATE is reported both unaligned (what the vehicle actually experienced) and after a 4-DOF (yaw + xyz)
alignment (the convention used in VIO benchmarks such as EuRoC, for comparison with literature).
"""
from __future__ import annotations

import numpy as np


def _arrays(records: list[dict], flying_only: bool = True):
    recs = [r for r in records if r["flying"]] if flying_only else records
    if not recs:
        return None
    T = np.array([r["truth"] for r in recs])
    E = np.array([r["est"] for r in recs])
    C = np.array([r["cov"] for r in recs])
    t = np.array([r["t"] for r in recs])
    S = [r["state"] for r in recs]
    yaw_t = np.array([r["truth_yaw"] for r in recs])
    yaw_e = np.array([r["est_yaw"] for r in recs])
    return t, T, E, C, S, yaw_t, yaw_e


def align_4dof(T: np.ndarray, E: np.ndarray) -> np.ndarray:
    """Best yaw + translation aligning E onto T (least squares). Returns aligned E."""
    tc, ec = T.mean(0), E.mean(0)
    A, B = E[:, :2] - ec[:2], T[:, :2] - tc[:2]
    H = A.T @ B
    psi = np.arctan2(H[0, 1] - H[1, 0], H[0, 0] + H[1, 1])
    c, s = np.cos(psi), np.sin(psi)
    R = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.0]])
    return (E - ec) @ R.T + tc


def ate(T: np.ndarray, E: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.sum((T - E) ** 2, axis=1))))


def rpe(t: np.ndarray, T: np.ndarray, E: np.ndarray, delta_m: float = 2.0) -> float:
    """Relative pose (translation) error over segments of ``delta_m`` travelled distance, RMSE."""
    d = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(T, axis=0), axis=1))])
    errs = []
    j = 0
    for i in range(len(T)):
        while j < len(T) and d[j] - d[i] < delta_m:
            j += 1
        if j >= len(T):
            break
        errs.append(np.linalg.norm((T[j] - T[i]) - (E[j] - E[i])))
    return float(np.sqrt(np.mean(np.square(errs)))) if errs else 0.0


def nees_xy(T: np.ndarray, E: np.ndarray, C: np.ndarray) -> np.ndarray:
    e = (T - E)[:, :2]
    out = np.empty(len(e))
    for i in range(len(e)):
        Ci = C[i][:2, :2] + np.eye(2) * 1e-6
        out[i] = e[i] @ np.linalg.solve(Ci, e[i])
    return out


def compute_metrics(sim) -> dict:
    arr = _arrays(sim.records)
    out: dict = {"scenario": sim.scenario.id, "seed": sim.seed, "duration_s": round(sim.t, 1)}
    if arr is None:
        return out | {"note": "vehicle never flew"}
    t, T, E, C, S, yt, ye = arr
    path_len = float(np.sum(np.linalg.norm(np.diff(T, axis=0), axis=1)))
    err = np.linalg.norm(T - E, axis=1)
    valid = np.array([s in ("RELIABLE", "DEGRADED") for s in S])
    nees = nees_xy(T, E, C)
    nees_valid = nees[valid] if valid.any() else nees
    yaw_err = np.rad2deg(np.abs((ye - yt + np.pi) % (2 * np.pi) - np.pi))
    places = sim.loc.place_events
    loops = [p for p in places if p["kind"] == "loop_closure" and p["accepted"]]
    relocs = [p for p in places if p["kind"] == "relocalization" and p["accepted"]]
    acc_tagged = [p for p in loops + relocs if p["truth_correct"] is not None]
    precision = (sum(p["truth_correct"] for p in acc_tagged) / len(acc_tagged)) if acc_tagged else None
    tis = {k: round(v, 1) for k, v in sim.time_in_state.items()}
    flying_time = max(sum(tis.values()), 1e-6)
    lost_events = [h for h in sim.loc.integrity.history if h[2] == "LOST"]
    recovered = [h for h in sim.loc.integrity.history if h[1] == "RECOVERING" and h[2] in ("RELIABLE", "DEGRADED")]
    out.update({
        "path_length_m": round(path_len, 1),
        "ate_rmse_m": round(ate(T, E), 3),
        "ate_rmse_aligned_m": round(ate(T, align_4dof(T, E)), 3),
        "rpe_2m_rmse_m": round(rpe(t, T, E, 2.0), 3),
        "max_error_m": round(float(err.max()), 3),
        "final_error_m": round(float(err[-1]), 3),
        "drift_pct_of_distance": round(100.0 * float(err[-1]) / max(path_len, 1e-6), 2),
        "yaw_error_rms_deg": round(float(np.sqrt(np.mean(yaw_err ** 2))), 2),
        "nees_xy_mean_valid": round(float(np.mean(nees_valid)), 2),       # ideal 2.0 for a 2-D consistent estimate
        "nees_xy_95pct_inside": round(float(np.mean(nees_valid < 5.99)), 3),  # ideal 0.95
        "availability_reliable_or_degraded": round((tis.get("RELIABLE", 0) + tis.get("DEGRADED", 0)) / flying_time, 3),
        "time_in_state_s": tis,
        "lost_events": len(lost_events),
        "recoveries": len(recovered),
        "loop_closures_accepted": sim.loc.stats["loop_accepted"],
        "loop_closures_rejected": sim.loc.stats["loop_rejected"],
        "relocalizations_accepted": sim.loc.stats["reloc_accepted"],
        "relocalizations_rejected": sim.loc.stats["reloc_rejected"],
        "place_recognition_precision": None if precision is None else round(precision, 3),
        "keyframes": len(sim.loc.kfdb.keyframes),
        "goals_reached": sim.goal_idx, "goals_total": len(sim.goals),
        "mission_complete": sim.mode == "COMPLETE",
        "collisions": len(sim.collisions),
        "min_clearance_m": round(sim.min_clearance, 3),
        "replans": len(sim.replan_reasons),
        "occupied_voxels": int(sim.vmap.occ.sum()),
        "observed_volume_m3": sim.vmap.stats()["observed_volume_m3"],
        "map_conflict_ratio": round(sim.vmap.conflict_ratio, 3),
        "compute_ms_per_cycle_mean": round(float(np.mean(sim.compute_ms)) if sim.compute_ms else 0.0, 2),
        "energy_used_wh": round(sim.cfg.aircraft.battery_wh - sim.battery_wh, 2),
    })
    return out


def map_accuracy(sim) -> dict:
    """Fraction of occupied voxels within one voxel of true geometry (map precision)."""
    idx = sim.vmap.occupied_indices()
    if idx.size == 0:
        return {"map_precision": None}
    centers = sim.vmap.center(idx)
    bmin, bmax = sim.world._bmin, sim.world._bmax
    d = np.full(len(centers), np.inf)
    for a, b in zip(bmin, bmax):
        closest = np.clip(centers, a, b)
        d = np.minimum(d, np.linalg.norm(centers - closest, axis=1))
    tol = sim.vmap.res * 1.5
    return {"map_precision": round(float(np.mean(d <= tol)), 3), "map_mean_surface_dist_m": round(float(np.mean(d)), 3)}
