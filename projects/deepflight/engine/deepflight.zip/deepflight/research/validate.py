"""Validation campaign: every implemented scenario on held-out seeds -> research/reports/VALIDATION.md (+ JSON/CSV).

    python -m deepflight.research.validate [--quick]

Default seeds 4001+ are held out: never used while developing or tuning (tuning 1001-1010, tests
2000-2199; the first campaign on 3001+ exposed bugs that were then debugged on seeds 3005/3010, so
3001+ is no longer clean).
"""
from __future__ import annotations

import argparse
import json
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np

from .. import SOFTWARE_VERSION
from ..simulation.scenarios import SCENARIOS
from .experiments import run_one, write_results

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "research" / "reports"

PLAN = {"M1": 10, "A": 5, "C": 3, "D": 3, "F": 3, "G": 3, "H": 3, "I": 3}
COLS = ["mission_complete", "collisions", "ate_rmse_m", "ate_rmse_aligned_m", "rpe_2m_rmse_m", "max_error_m",
        "nees_xy_mean_valid", "nees_xy_95pct_inside", "availability_reliable_or_degraded", "lost_events", "recoveries",
        "relocalizations_accepted", "loop_closures_accepted", "loop_closures_rejected", "place_recognition_precision",
        "min_clearance_m", "map_precision", "replans", "compute_ms_per_cycle_mean", "energy_used_wh"]


def _job(args):
    sc, seed = args
    return run_one(sc, seed)


def summarize(rows: list[dict]) -> dict:
    out = {"runs": len(rows)}
    for c in COLS:
        vals = [r.get(c) for r in rows if r.get(c) is not None]
        if not vals:
            out[c] = None
        elif isinstance(vals[0], bool):
            out[c] = f"{sum(vals)}/{len(vals)}"
        else:
            v = np.array(vals, float)
            out[c] = f"{v.mean():.3g} (max {v.max():.3g})" if c not in ("collisions", "lost_events", "recoveries") \
                else f"{int(v.sum())} total"
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="2 seeds per scenario")
    ap.add_argument("--base-seed", type=int, default=4001, help="first held-out seed")
    a = ap.parse_args()
    jobs = []
    for sc, n in PLAN.items():
        if SCENARIOS[sc].implemented:
            for k in range(2 if a.quick else n):
                jobs.append((sc, a.base_seed + k))
    t0 = time.time()
    with ProcessPoolExecutor(max_workers=6) as ex:
        rows = list(ex.map(_job, jobs))
    OUT.mkdir(parents=True, exist_ok=True)
    write_results(rows, OUT / "validation_runs")
    by = {}
    for r in rows:
        by.setdefault(r["scenario"], []).append(r)
    lines = [
        "# DeepFlight AI - simulation validation report", "",
        f"Software `{SOFTWARE_VERSION}` · generated {time.strftime('%Y-%m-%d %H:%M')} · {len(rows)} runs · "
        f"wall time {time.time() - t0:.0f} s · held-out seeds {a.base_seed}+", "",
        "**Scope.** Every number below comes from the DeepFlight simulator (kinematic quadrotor, synthetic sensors, "
        "procedural building). These are *simulation results*, not dataset (EuRoC/TUM/KITTI) or flight results; "
        "see docs/testing/VALIDATION_PLAN.md for what is and is not validated.", "",
        "Metric notes: ATE = RMS of truth-minus-estimate position over the flight (map frame fixed by the surveyed "
        "take-off pad; *aligned* = after 4-DOF alignment as in VIO benchmarks). NEES (2-D) ~2 means the reported "
        "uncertainty matches the true error; < 2 is conservative, > 2 overconfident. Availability = share of flight "
        "time RELIABLE or DEGRADED. Place-recognition precision = accepted matches whose recovered pose is within "
        "max(1 m, 3 sigma) of truth.", "",
    ]
    for sc, rs in by.items():
        s = summarize(rs)
        lines += [f"## {sc} - {SCENARIOS[sc].name}", "", f"Expected behaviour: {SCENARIOS[sc].expected or 'n/a'}", "",
                  "| metric | mean (max) / total |", "|---|---|"]
        lines += [f"| {k.replace('_', ' ')} | {v} |" for k, v in s.items() if k != "runs"]
        lines += ["", "| seed | complete | collisions | ATE m | max err m | NEES | lost | recovered | relocs | loops acc/rej |",
                  "|---|---|---|---|---|---|---|---|---|---|"]
        for r in rs:
            lines.append(f"| {r['seed']} | {r['mission_complete']} | {r['collisions']} | {r['ate_rmse_m']} | {r['max_error_m']} | "
                         f"{r['nees_xy_mean_valid']} | {r['lost_events']} | {r['recoveries']} | {r['relocalizations_accepted']} | "
                         f"{r['loop_closures_accepted']}/{r['loop_closures_rejected']} |")
        lines.append("")
    (OUT / "VALIDATION.md").write_text("\n".join(lines), encoding="utf-8")
    (OUT / "validation_summary.json").write_text(json.dumps({k: summarize(v) for k, v in by.items()}, indent=2))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
