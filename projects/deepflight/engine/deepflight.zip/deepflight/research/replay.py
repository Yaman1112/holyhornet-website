"""Offline replay of a flight recording (``deepflight.robotics.flight_recorder``) through a fresh estimator.

    python -m deepflight.research.replay <recording.pkl> [--variant NAME ...]

The engine's calls into ``LocalizationSystem`` are replayed in their original order with the original sample
objects, so the ``baseline`` variant reproduces the online estimate. Variants change one thing at a time:

* ``timing``      - apply each camera frame at its capture time (Gazebo stamp) instead of after all IMU samples
                    that had arrived when it was processed (images are ~20 ms old on arrival);
* ``depth_sync``  - look up feature depth in the depth image closest in time to the gray image, instead of the
                    newest depth image (10 Hz vs 20 Hz: up to 100 ms older);
* ``depth_offset=<s>`` - as depth_sync, pairing with the depth image nearest to gray stamp + offset;
* ``pitch=<deg>`` / ``lever=<x>,<y>,<z>`` - camera extrinsics as given;
* ``flow_fallback`` - fuse optical flow only while vision is not aiding (``EstimatorConfig.flow_fallback_only``);
* ``drop=<method>`` - skip every call of one ``LocalizationSystem`` input (ablation), e.g. ``drop=on_flow``.

Errors are against the recorded ground truth (Gazebo) at the same engine time.
"""
from __future__ import annotations

import argparse
import copy
import pickle
from dataclasses import replace

import numpy as np

from ..localization.fusion import LocalizationSystem


def _yaw(R: np.ndarray) -> float:
    return float(np.arctan2(R[1, 0], R[0, 0]))


def _wrap(a: float) -> float:
    return (a + np.pi) % (2 * np.pi) - np.pi


def _depth_lookup(frame, depth: np.ndarray, w: int = 640, h: int = 480, dmin: float = 0.35, dmax: float = 6.0):
    dep = np.full(len(frame.uv), np.nan)
    if len(frame.uv):
        d = depth.astype(float)
        iu = np.clip((frame.uv[:, 0] * d.shape[1] / w).astype(int), 0, d.shape[1] - 1)
        iv = np.clip((frame.uv[:, 1] * d.shape[0] / h).astype(int), 0, d.shape[0] - 1)
        z = d[iv, iu]
        ok = np.isfinite(z) & (z > dmin) & (z < dmax)
        dep[ok] = z[ok]
    return dep


def _depth_bilinear_inv(frame, depth: np.ndarray, w: int = 640, h: int = 480):
    from ..perception.image_frontend import FrontEndConfig, depth_at
    c = FrontEndConfig()
    return depth_at(frame.uv, depth, w, h, c.depth_min, c.depth_max, c.depth_planar_rel)


def replay(rec: dict, variants: tuple = (), quiet: bool = True) -> dict:
    meta, events = rec["meta"], rec["events"]
    cfg = copy.deepcopy(meta["cfg"])
    timing = "timing" in variants
    drop = {v.split("=")[1] for v in variants if v.startswith("drop=")}   # e.g. drop=on_flow (ablation)
    depth_interp = "depth_interp" in variants
    depth_sync = "depth_sync" in variants or any(v.startswith("depth_offset=") for v in variants)
    depth_offset = sum(float(v.split("=")[1]) for v in variants if v.startswith("depth_offset="))
    for v in variants:
        if v.startswith("pitch="):
            cfg.sensors.camera.mount_pitch_deg = float(v.split("=")[1])
        if v == "flow_fallback":
            cfg.estimator.flow_fallback_only = True
        if v.startswith("drift="):
            cfg.estimator.vio_drift_rate = float(v.split("=")[1])
        if v.startswith("lever="):
            cfg.sensors.camera.lever_arm_m = tuple(float(x) for x in v.split("=")[1].split(","))
    log = (lambda *a, **k: None) if quiet else (lambda t, c, s, m, d=None: print(f"  {t:7.2f} {m}"))
    loc = LocalizationSystem(cfg, meta["p0"], meta["yaw0"], log, seed=1)
    loc.health["imu"].stale_min_s = 0.25
    for v in variants:
        if v.startswith("camrot="):           # extra camera rotation (deg) about its optical z, x(right), y(down)
            rz, rx, ry = (np.radians(float(x)) for x in v.split("=")[1].split(","))
            def R(axis, a):
                c, s_ = np.cos(a), np.sin(a)
                return {"z": np.array([[c, -s_, 0], [s_, c, 0], [0, 0, 1]]),
                        "x": np.array([[1, 0, 0], [0, c, -s_], [0, s_, c]]),
                        "y": np.array([[c, 0, s_], [0, 1, 0], [-s_, 0, c]])}[axis]
            loc.vio.R_bc = loc.vio.R_bc @ R("z", rz) @ R("x", rx) @ R("y", ry)

    depth_stamps = sorted((st, seq) for seq, (st, _) in rec["depth"].items())
    ds_t = np.array([s for s, _ in depth_stamps])

    # build the call stream with a time key (PX4 sim clock) for re-ordering
    calls, t_imu, last_frame, truth = [], None, None, []
    for e in events:
        if e[0] == "imu_raw":
            if t_imu is None and e[2]:
                t_imu = e[2][0][0]
        elif e[0] == "frame":
            last_frame = e
        elif e[0] == "truth":
            truth.append(e)
            calls.append(((t_imu or 0.0), len(calls), ("truth", e)))
        elif e[0] == "loc":
            name, a, k = e[1], e[2], e[3]
            if name == "on_imu" and t_imu is not None:
                t_imu += a[1]
                calls.append((t_imu, len(calls), ("loc", name, a, k)))
            elif name == "on_camera" and a[0] is not None and last_frame is not None:
                frame = a[0]
                if depth_sync and len(ds_t):
                    j = int(np.argmin(np.abs(ds_t - (last_frame[3] + depth_offset))))
                    frame = replace(frame, depth=_depth_lookup(frame, rec["depth"][depth_stamps[j][1]][1]))
                elif depth_interp and last_frame[4] is not None:
                    frame = replace(frame, depth=_depth_bilinear_inv(frame, rec["depth"][last_frame[4]][1]))
                key = last_frame[3] if timing else (t_imu or 0.0)
                calls.append((key + 1e-9, len(calls), ("loc", name, (frame,) + tuple(a[1:]), k)))
            else:
                calls.append(((t_imu or 0.0), len(calls), ("loc", name, a, k)))
    if timing:
        calls.sort(key=lambda c: (c[0], c[1]))

    out = {"t": [], "pos_err": [], "yaw_err": [], "truth": [], "tilt_err": [], "ba": [], "bg": []}
    for _, _, c in calls:
        if c[0] == "loc":
            if c[1] in drop:
                continue
            getattr(loc, c[1])(*c[2], **c[3])
        else:
            _, t, _, p, R, v, _, _ = c[1]
            if abs(t * 10 - round(t * 10)) < 1e-6:
                out["t"].append(t)
                out["pos_err"].append(loc.eskf.p - p)
                out["yaw_err"].append(_wrap(loc.eskf.yaw() - _yaw(R)))
                out["truth"].append(p.copy())
                # roll / pitch error: small-angle rotation between estimated and true attitude, body frame
                dR = R.T @ loc.eskf.R
                out["tilt_err"].append(np.array([dR[2, 1] - dR[1, 2], dR[0, 2] - dR[2, 0]]) / 2.0)
                out["ba"].append(loc.eskf.ba.copy() if hasattr(loc.eskf, "ba") else np.zeros(3))
                out["bg"].append(loc.eskf.bg.copy() if hasattr(loc.eskf, "bg") else np.zeros(3))
    for k in out:
        out[k] = np.array(out[k])
    return out


def summary(res: dict, marks=(10.0, 30.0, 60.0, 80.0)) -> str:
    parts = []
    for m in marks:
        i = int(np.argmin(np.abs(res["t"] - m)))
        e = res["pos_err"][i]
        tl = np.degrees(res["tilt_err"][i])
        parts.append(f"t={m:.0f}: xy[{e[0]:+.2f},{e[1]:+.2f}] yaw {np.degrees(res['yaw_err'][i]):+.2f} "
                     f"roll {tl[0]:+.2f} pitch {tl[1]:+.2f}")
    fly = res["truth"][:, 2] > 0.5
    rmse = float(np.sqrt(np.mean(np.sum(res["pos_err"][fly, :2] ** 2, axis=1)))) if fly.any() else float("nan")
    return f"ATE_xy {rmse:.3f} m | " + " | ".join(parts)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("recording")
    ap.add_argument("--variant", action="append", default=[], help="comma-separated variant set; repeatable")
    a = ap.parse_args()
    with open(a.recording, "rb") as fh:
        rec = pickle.load(fh)
    sets = [()] + [tuple(v.split("+")) for v in a.variant]
    for vs in sets:
        res = replay(rec, vs)
        print(f"{'+'.join(vs) or 'baseline':28s} {summary(res)}")


if __name__ == "__main__":
    main()
