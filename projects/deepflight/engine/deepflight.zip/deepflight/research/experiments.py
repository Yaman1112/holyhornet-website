"""Reproducible experiment runner: scenario x seeds x config variants -> metrics (JSON + CSV).

Usage:  python -m deepflight.research.experiments --scenario M1 --seeds 700-704 --out ../research/experiments/m1
Every result row records software version, scenario, seed, config hash, overrides, ground-truth
availability and validation status.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import time
from pathlib import Path

from .. import SOFTWARE_VERSION
from ..engine import DeepFlightSim
from .metrics import compute_metrics, map_accuracy


def config_hash(cfg_dict: dict) -> str:
    return hashlib.sha256(json.dumps(cfg_dict, sort_keys=True, default=str).encode()).hexdigest()[:12]


def run_one(scenario: str, seed: int, overrides: dict | None = None, label: str = "baseline") -> dict:
    t0 = time.perf_counter()
    sim = DeepFlightSim(scenario, seed, overrides)
    sim.run_until(sim.scenario.duration_s)
    m = compute_metrics(sim) | map_accuracy(sim)
    m.update({
        "variant": label, "software_version": SOFTWARE_VERSION, "config_hash": config_hash(sim.cfg.to_dict()),
        "overrides": json.dumps(overrides or {}), "dataset": f"simulated:{scenario}:seed{seed}",
        "ground_truth": "simulation truth (exact)", "validation_status": "simulation-only (not flight-validated)",
        "wall_time_s": round(time.perf_counter() - t0, 1), "python": platform.python_version(),
    })
    return m


def parse_seeds(spec: str) -> list[int]:
    out = []
    for part in spec.split(","):
        if "-" in part:
            a, b = part.split("-")
            out += list(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return out


def write_results(rows: list[dict], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "results.json").write_text(json.dumps(rows, indent=2, default=str))
    flat = []
    for r in rows:
        f = {k: (json.dumps(v) if isinstance(v, (dict, list)) else v) for k, v in r.items()}
        flat.append(f)
    keys = sorted({k for r in flat for k in r})
    with open(out_dir / "results.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        w.writerows(flat)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", default="M1")
    ap.add_argument("--seeds", default="700-704")
    ap.add_argument("--out", default="experiment_out")
    ap.add_argument("--overrides", default="{}")
    ap.add_argument("--label", default="baseline")
    a = ap.parse_args()
    rows = []
    for seed in parse_seeds(a.seeds):
        r = run_one(a.scenario, seed, json.loads(a.overrides), a.label)
        rows.append(r)
        print(json.dumps({k: r[k] for k in ("scenario", "seed", "ate_rmse_m", "nees_xy_mean_valid", "mission_complete",
                                              "collisions", "lost_events", "recoveries", "wall_time_s") if k in r}))
    write_results(rows, Path(a.out))


if __name__ == "__main__":
    main()
