"""Probabilistic 3-D occupancy voxel map (log-odds) built from depth returns at the *estimated* pose."""
from __future__ import annotations

import numpy as np
from scipy import ndimage

from ..config import MappingConfig


class VoxelMap:
    def __init__(self, cfg: MappingConfig):
        self.cfg = cfg
        self.res = cfg.voxel_m
        self.origin = np.array(cfg.bounds_min, float)
        self.shape = tuple(np.ceil((np.array(cfg.bounds_max) - self.origin) / self.res).astype(int))
        self.L = np.zeros(self.shape, np.float32)
        self.occ = np.zeros(self.shape, bool)
        self.observed = np.zeros(self.shape, bool)
        self.added: list[int] = []
        self.removed: list[int] = []
        self.conflict_ratio = 0.0
        self.scans = 0
        self.version = 0

    # ------------------------------------------------------------------ indexing
    def index(self, pts: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        ijk = np.floor((pts - self.origin) / self.res).astype(int)
        ok = np.all((ijk >= 0) & (ijk < np.array(self.shape)), axis=1)
        return ijk, ok

    def flat(self, ijk: np.ndarray) -> np.ndarray:
        return np.ravel_multi_index(ijk.T, self.shape)

    def center(self, flat_idx: np.ndarray) -> np.ndarray:
        ijk = np.array(np.unravel_index(flat_idx, self.shape)).T
        return self.origin + (ijk + 0.5) * self.res

    # ------------------------------------------------------------------ integration
    def integrate(self, origin: np.ndarray, hits: np.ndarray, free_dirs: np.ndarray, max_range: float) -> None:
        cfg = self.cfg
        step = self.res * 0.7
        segs_end = [hits]
        if free_dirs.size:
            segs_end.append(origin + free_dirs * max_range)
        ends = np.vstack(segs_end) if len(segs_end) > 1 else hits
        if ends.shape[0] == 0:
            return
        vec = ends - origin
        length = np.linalg.norm(vec, axis=1)
        n = np.maximum((length / step).astype(int), 1)
        is_hit = np.zeros(ends.shape[0], bool)
        is_hit[: hits.shape[0]] = True
        # free samples stop one voxel short of a hit
        n_free = np.where(is_hit, np.maximum(n - 2, 0), n)
        rep = np.repeat(np.arange(ends.shape[0]), n_free)
        if rep.size:
            k = np.arange(rep.size) - np.repeat(np.cumsum(n_free) - n_free, n_free)
            pts = origin + vec[rep] * ((k + 0.5) * step / np.maximum(length[rep], 1e-6))[:, None]
            ijk, ok = self.index(pts)
            free_idx = np.unique(self.flat(ijk[ok]))
        else:
            free_idx = np.zeros(0, int)
        ijk, ok = self.index(hits)
        hit_idx = np.unique(self.flat(ijk[ok])) if ok.any() else np.zeros(0, int)
        free_idx = np.setdiff1d(free_idx, hit_idx, assume_unique=True)
        Lf = self.L.reshape(-1)
        if hit_idx.size:
            self.conflict_ratio = 0.8 * self.conflict_ratio + 0.2 * float(np.mean(Lf[hit_idx] < -1.2))
        Lf[free_idx] = np.maximum(Lf[free_idx] + cfg.log_miss, cfg.log_min)
        Lf[hit_idx] = np.minimum(Lf[hit_idx] + cfg.log_hit, cfg.log_max)
        obs = self.observed.reshape(-1)
        obs[free_idx] = True
        obs[hit_idx] = True
        touched = np.concatenate([free_idx, hit_idx])
        occf = self.occ.reshape(-1)
        new_state = Lf[touched] > cfg.occupied_threshold
        changed = new_state != occf[touched]
        if changed.any():
            ch = touched[changed]
            st = new_state[changed]
            occf[ch] = st
            self.added.extend(ch[st].tolist())
            self.removed.extend(ch[~st].tolist())
            self.version += 1
        self.scans += 1

    def pop_diff(self) -> tuple[list[int], list[int]]:
        a, r = self.added, self.removed
        self.added, self.removed = [], []
        # a voxel added then removed within one window cancels out
        sa, sr = set(a), set(r)
        both = sa & sr
        return sorted(sa - both), sorted(sr - both)

    # ------------------------------------------------------------------ products
    def occupied_indices(self) -> np.ndarray:
        return np.flatnonzero(self.occ)

    def planning_slice(self, z: float, band: float) -> tuple[np.ndarray, np.ndarray]:
        """2-D (x,y) blocked / unknown masks for the altitude band [z - band, z + band]."""
        k0 = max(int(np.floor((z - band - self.origin[2]) / self.res)), 0)
        k1 = min(int(np.ceil((z + band - self.origin[2]) / self.res)), self.shape[2])
        blocked = self.occ[:, :, k0:k1].any(axis=2)
        unknown = ~self.observed[:, :, k0:k1].any(axis=2)
        return blocked, unknown

    def distance_field(self, blocked: np.ndarray) -> np.ndarray:
        if not blocked.any():
            return np.full(blocked.shape, 99.0)
        return ndimage.distance_transform_edt(~blocked) * self.res

    def stats(self) -> dict:
        obs = int(self.observed.sum())
        return {
            "occupied_voxels": int(self.occ.sum()),
            "observed_voxels": obs,
            "observed_volume_m3": round(obs * self.res ** 3, 1),
            "voxel_m": self.res,
            "conflict_ratio": round(self.conflict_ratio, 3),
            "scans": self.scans,
        }

    def nearest_obstacle(self, p: np.ndarray, radius: float = 3.0) -> float:
        ijk, ok = self.index(p[None])
        if not ok[0]:
            return 99.0
        r = int(np.ceil(radius / self.res))
        i, j, k = ijk[0]
        sub = self.occ[max(i - r, 0):i + r + 1, max(j - r, 0):j + r + 1, max(k - r, 0):k + r + 1]
        idx = np.argwhere(sub)
        if idx.size == 0:
            return 99.0
        base = np.array([max(i - r, 0), max(j - r, 0), max(k - r, 0)])
        centers = self.origin + (idx + base + 0.5) * self.res
        return float(np.min(np.linalg.norm(centers - p, axis=1)))
