"""FastAPI application factory."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.exc import IntegrityError

from . import config, jobs
from .api import admin, flights, operations, resources
from .config import APP_NAME, APP_VERSION

log = logging.getLogger("hhfms")

DESCRIPTION = """
REST + WebSocket API of the HolyHornet Flight Management System (HH-FMS).

* Authenticate with `POST /api/auth/login` and send `Authorization: Bearer <token>`.
* All times are UTC (ISO-8601, no offset).
* Every flight, position and weather record carries a `data_source`
  (SIMULATED, HISTORICAL, LIVE, IMPORTED, MANUAL).
* Dispatch outputs are **planning support only** and not certified release data.
"""


def create_app(run_startup: bool = True) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if run_startup:
            info = jobs.startup()
            log.info("Startup complete: %s", info)
            if config.settings.background_jobs:
                jobs.start_background()
        yield
        jobs.stop_background()

    app = FastAPI(title=f"{APP_NAME} API", version=APP_VERSION, description=DESCRIPTION, lifespan=lifespan,
                  docs_url="/api/docs", redoc_url="/api/redoc", openapi_url="/api/openapi.json")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:3800", "http://127.0.0.1:3800", "app://fms"],
        allow_credentials=False, allow_methods=["*"], allow_headers=["*"],
    )

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        if request.url.path.startswith("/api/") and "cache-control" not in resp.headers:
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.exception_handler(IntegrityError)
    async def integrity(_: Request, exc: IntegrityError):
        return JSONResponse({"detail": "Database constraint violated (duplicate or invalid reference)"}, status_code=409)

    @app.exception_handler(RequestValidationError)
    async def validation(_: Request, exc: RequestValidationError):
        msgs = []
        for e in exc.errors():
            loc = ".".join(str(x) for x in e.get("loc", []) if x not in ("body", "query"))
            msgs.append(f"{loc}: {e.get('msg')}" if loc else e.get("msg"))
        return JSONResponse({"detail": "; ".join(msgs), "errors": jsonable(exc.errors())}, status_code=422)

    app.include_router(admin.router)
    app.include_router(flights.router)
    app.include_router(resources.router)
    app.include_router(operations.router)
    app.include_router(operations.ws_router)

    static = config.settings.static_dir
    if static and (static / "index.html").exists():
        app.mount("/assets", StaticFiles(directory=static / "assets"), name="assets")

        @app.get("/{path:path}", include_in_schema=False)
        async def spa(path: str):
            if path.startswith("api/"):
                return JSONResponse({"detail": "Not found"}, status_code=404)
            f = (static / path).resolve()
            if path and f.is_file() and static.resolve() in f.parents:
                return FileResponse(f)
            return FileResponse(static / "index.html")

    return app


def jsonable(errors):
    out = []
    for e in errors:
        out.append({k: (str(v) if k == "ctx" else v) for k, v in e.items() if k != "input"})
    return out
