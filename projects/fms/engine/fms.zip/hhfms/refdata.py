"""Demo reference dataset.

Airport positions, elevations and runway lengths are approximate public values
for demonstration; runway headings are derived from the designator (x10 deg).
The two airlines and their fleets/crews are fictional. Verify every value
against official AIP sources before any real-world use.
"""
from __future__ import annotations

# icao, iata, name, city, country, lat, lon, elev_ft, tz, terminals, cap_arr, cap_dep, min_turn, runways[(desig, len_m, width_m)]
AIRPORTS = [
    ("EHAM", "AMS", "Amsterdam Schiphol", "Amsterdam", "Netherlands", 52.3086, 4.7639, -11, "Europe/Amsterdam", 1, 68, 68, 40,
     [("18R/36L", 3800, 60), ("06/24", 3500, 45), ("09/27", 3453, 45), ("18L/36R", 3400, 45), ("18C/36C", 3300, 45), ("04/22", 2014, 45)]),
    ("EGLL", "LHR", "London Heathrow", "London", "United Kingdom", 51.4706, -0.4619, 83, "Europe/London", 4, 44, 44, 45,
     [("09L/27R", 3902, 50), ("09R/27L", 3660, 50)]),
    ("LFPG", "CDG", "Paris Charles de Gaulle", "Paris", "France", 49.0097, 2.5479, 392, "Europe/Paris", 3, 60, 60, 40,
     [("08L/26R", 4215, 45), ("08R/26L", 2700, 60), ("09L/27R", 2700, 60), ("09R/27L", 4200, 45)]),
    ("EDDF", "FRA", "Frankfurt am Main", "Frankfurt", "Germany", 50.0379, 8.5622, 364, "Europe/Berlin", 2, 52, 52, 40,
     [("07C/25C", 4000, 60), ("07R/25L", 4000, 60), ("07L/25R", 2800, 45), ("18/36", 4000, 60)]),
    ("LEMD", "MAD", "Adolfo Suarez Madrid-Barajas", "Madrid", "Spain", 40.4719, -3.5626, 1998, "Europe/Madrid", 4, 48, 48, 40,
     [("14L/32R", 3500, 60), ("14R/32L", 4100, 60), ("18L/36R", 3500, 60), ("18R/36L", 4350, 60)]),
    ("LIRF", "FCO", "Rome Fiumicino", "Rome", "Italy", 41.8003, 12.2389, 13, "Europe/Rome", 3, 40, 40, 40,
     [("16L/34R", 3900, 60), ("16R/34L", 3900, 60), ("07/25", 3309, 45)]),
    ("LOWW", "VIE", "Vienna International", "Vienna", "Austria", 48.1103, 16.5697, 600, "Europe/Vienna", 3, 34, 34, 35,
     [("11/29", 3500, 45), ("16/34", 3600, 45)]),
    ("LSZH", "ZRH", "Zurich", "Zurich", "Switzerland", 47.4647, 8.5492, 1416, "Europe/Zurich", 3, 36, 36, 35,
     [("10/28", 2500, 60), ("14/32", 3300, 60), ("16/34", 3700, 60)]),
    ("EKCH", "CPH", "Copenhagen Kastrup", "Copenhagen", "Denmark", 55.6181, 12.6561, 17, "Europe/Copenhagen", 2, 40, 40, 35,
     [("04L/22R", 3600, 45), ("04R/22L", 3300, 45), ("12/30", 2800, 45)]),
    ("ENGM", "OSL", "Oslo Gardermoen", "Oslo", "Norway", 60.1939, 11.1004, 681, "Europe/Oslo", 1, 36, 36, 30,
     [("01L/19R", 3600, 45), ("01R/19L", 2950, 45)]),
    ("ESSA", "ARN", "Stockholm Arlanda", "Stockholm", "Sweden", 59.6519, 17.9186, 137, "Europe/Stockholm", 3, 40, 40, 30,
     [("01L/19R", 3301, 45), ("01R/19L", 2500, 45), ("08/26", 2500, 45)]),
    ("EIDW", "DUB", "Dublin", "Dublin", "Ireland", 53.4213, -6.2701, 242, "Europe/Dublin", 2, 32, 32, 30,
     [("10R/28L", 3110, 75), ("10L/28R", 3110, 60), ("16/34", 2072, 61)]),
    ("LPPT", "LIS", "Lisbon Humberto Delgado", "Lisbon", "Portugal", 38.7813, -9.1359, 374, "Europe/Lisbon", 2, 30, 30, 35,
     [("02/20", 3805, 45), ("17/35", 2400, 45)]),
    ("LEBL", "BCN", "Barcelona El Prat", "Barcelona", "Spain", 41.2971, 2.0785, 14, "Europe/Madrid", 2, 42, 42, 35,
     [("07L/25R", 3352, 60), ("07R/25L", 2660, 45), ("02/20", 2528, 45)]),
    ("EBBR", "BRU", "Brussels", "Brussels", "Belgium", 50.9014, 4.4844, 184, "Europe/Brussels", 1, 38, 38, 35,
     [("07L/25R", 3211, 45), ("07R/25L", 3638, 45), ("01/19", 2987, 50)]),
    ("EDDM", "MUC", "Munich", "Munich", "Germany", 48.3538, 11.7861, 1487, "Europe/Berlin", 2, 45, 45, 40,
     [("08L/26R", 4000, 60), ("08R/26L", 4000, 60)]),
    ("LGAV", "ATH", "Athens Eleftherios Venizelos", "Athens", "Greece", 37.9364, 23.9445, 308, "Europe/Athens", 2, 34, 34, 40,
     [("03L/21R", 4000, 45), ("03R/21L", 3800, 45)]),
    ("LTFM", "IST", "Istanbul Airport", "Istanbul", "Turkiye", 41.2753, 28.7519, 325, "Europe/Istanbul", 1, 60, 60, 45,
     [("16L/34R", 3750, 60), ("16R/34L", 3750, 60), ("17L/35R", 4100, 60), ("17R/35L", 4100, 60), ("18/36", 3060, 45)]),
    ("OMDB", "DXB", "Dubai International", "Dubai", "United Arab Emirates", 25.2532, 55.3657, 62, "Asia/Dubai", 3, 40, 40, 60,
     [("12L/30R", 4351, 60), ("12R/30L", 4447, 60)]),
    ("KJFK", "JFK", "New York John F. Kennedy", "New York", "United States", 40.6413, -73.7781, 13, "America/New_York", 5, 44, 44, 60,
     [("04L/22R", 3682, 61), ("04R/22L", 2560, 61), ("13L/31R", 3048, 61), ("13R/31L", 4423, 61)]),
    ("ENBR", "BGO", "Bergen Flesland", "Bergen", "Norway", 60.2934, 5.2181, 170, "Europe/Oslo", 1, 20, 20, 25,
     [("17/35", 2990, 45)]),
    ("ENVA", "TRD", "Trondheim Vaernes", "Trondheim", "Norway", 63.4578, 10.9240, 56, "Europe/Oslo", 1, 16, 16, 25,
     [("09/27", 2999, 45)]),
    ("ENZV", "SVG", "Stavanger Sola", "Stavanger", "Norway", 58.8767, 5.6378, 29, "Europe/Oslo", 1, 18, 18, 25,
     [("18/36", 2556, 45), ("10/28", 2449, 45)]),
    ("ESGG", "GOT", "Gothenburg Landvetter", "Gothenburg", "Sweden", 57.6628, 12.2798, 506, "Europe/Stockholm", 1, 18, 18, 25,
     [("03/21", 3299, 45)]),
    ("EKBI", "BLL", "Billund", "Billund", "Denmark", 55.7403, 9.1518, 247, "Europe/Copenhagen", 1, 14, 14, 25,
     [("09/27", 3100, 45)]),
]

# icao, manufacturer, model, mtow_kg, range_km, cruise_ktas, cruise_fl, pax, fuel_kg, burn_kg_h, min_rwy_m, min_turn, cabin_crew, wake
AIRCRAFT_TYPES = [
    ("A20N", "Airbus", "A320neo", 79000, 6300, 450, 360, 180, 21400, 2400, 1950, 35, 4, "M"),
    ("A21N", "Airbus", "A321neo", 97000, 7400, 450, 350, 220, 26300, 2800, 2200, 40, 5, "M"),
    ("B38M", "Boeing", "737 MAX 8", 82200, 6570, 453, 370, 186, 20700, 2350, 2100, 35, 4, "M"),
    ("E295", "Embraer", "E195-E2", 61500, 4800, 450, 350, 132, 13700, 1800, 1800, 30, 3, "M"),
    ("AT76", "ATR", "ATR 72-600", 23000, 1528, 275, 220, 72, 5000, 650, 1300, 25, 2, "M"),
    ("B789", "Boeing", "787-9 Dreamliner", 254011, 14010, 488, 390, 290, 101400, 5800, 2800, 90, 10, "H"),
    ("A359", "Airbus", "A350-900", 283000, 15000, 488, 390, 315, 110500, 6000, 2800, 90, 11, "H"),
]

AIRLINES = [
    # icao, iata, name, callsign, country, hub
    ("HHA", "HH", "HolyHornet Airways", "HORNET", "Netherlands", "EHAM"),
    ("PLX", "PL", "Polar Regional", "POLAR", "Norway", "ENGM"),
]

# airline, registration prefix, type, count
FLEET = [
    ("HHA", "PH-HN", "A20N", 6),
    ("HHA", "PH-HX", "A21N", 4),
    ("HHA", "PH-HM", "B38M", 4),
    ("HHA", "PH-HW", "B789", 3),
    ("HHA", "PH-HA", "A359", 2),
    ("PLX", "LN-PE", "E295", 4),
    ("PLX", "LN-PT", "AT76", 3),
]

# rotation lines: id, airline, flight-number base, type, first STD (UTC), out-and-back destinations from hub
ROTATION_LINES = [
    ("L01", "HHA", 101, "A20N", "05:30", ["EGLL", "LSZH", "EGLL"]),
    ("L02", "HHA", 111, "A20N", "05:45", ["LFPG", "LEBL"]),
    ("L03", "HHA", 121, "A20N", "06:00", ["EDDF", "EKCH", "EDDM"]),
    ("L04", "HHA", 131, "A20N", "06:10", ["LIRF", "EBBR"]),
    ("L05", "HHA", 141, "A20N", "06:20", ["LOWW", "ESSA"]),
    ("L06", "HHA", 151, "A21N", "05:50", ["LEMD", "EGLL"]),
    ("L07", "HHA", 161, "A21N", "06:05", ["LPPT", "EIDW"]),
    ("L08", "HHA", 171, "A21N", "06:30", ["LGAV"]),
    ("L09", "HHA", 181, "B38M", "06:15", ["LTFM"]),
    ("L10", "HHA", 191, "B38M", "05:40", ["EIDW", "LFPG", "EGLL"]),
    ("L11", "HHA", 201, "B38M", "06:40", ["LEBL", "EDDF"]),
    ("L12", "HHA", 601, "B789", "09:30", ["KJFK"]),
    ("L13", "HHA", 611, "B789", "08:30", ["OMDB"]),
    ("L14", "HHA", 621, "A359", "12:30", ["KJFK"]),
    ("L21", "PLX", 301, "E295", "05:30", ["ESSA", "EKCH", "ENBR"]),
    ("L22", "PLX", 311, "E295", "05:45", ["EHAM", "ESGG"]),
    ("L23", "PLX", 321, "E295", "06:00", ["ENVA", "EKCH", "ENZV"]),
    ("L24", "PLX", 331, "AT76", "05:40", ["ENBR", "ENVA", "ENZV"]),
    ("L25", "PLX", 341, "AT76", "06:10", ["ESGG", "ENBR"]),
]

TYPE_FAMILY = {"A20N": "A320", "A21N": "A320", "B38M": "B737", "E295": "E2", "AT76": "ATR", "B789": "B787", "A359": "A350"}

FIRST_NAMES = [
    "Anna", "Lars", "Sofia", "Daan", "Emma", "Jonas", "Lea", "Mateo", "Ingrid", "Noah", "Yara", "Omar", "Elif", "Pieter",
    "Chloe", "Mikkel", "Amira", "Luca", "Freya", "Sanne", "Tomas", "Nadia", "Erik", "Maya", "Hugo", "Leila", "Bram", "Sara",
    "Kai", "Lotte", "Ravi", "Ines", "Felix", "Hana", "Jan", "Zoe", "Arjun", "Mila", "Sven", "Nora",
]
LAST_NAMES = [
    "de Vries", "Jansen", "Haugen", "Berg", "Nielsen", "Dubois", "Rossi", "Garcia", "Kaya", "Mueller", "Svensson", "Ahmed",
    "Bakker", "Visser", "Larsen", "Moreau", "Novak", "Silva", "Kowalski", "Hansen", "Petrov", "Lindqvist", "Okafor", "Smit",
    "Dekker", "Andersen", "Costa", "Fischer", "Yilmaz", "Nakamura", "Olsen", "Mendes", "Brouwer", "Eriksen", "Haddad", "Meijer",
]

DEFAULT_CONFIG = {
    "ops.on_time_threshold_min": (15, "Delay (minutes) up to which a departure/arrival counts as on time (industry standard 15)."),
    "ops.abnormal_delay_min": (45, "Departure delay above which an abnormal-delay alert is raised."),
    "ops.unusual_duration_pct": (20, "Block-time deviation (%) from schedule that flags an unusual duration."),
    "ops.max_daily_block_hours": (14, "Aircraft block hours per day above which over-utilisation is flagged."),
    "ops.min_daily_block_hours": (3, "Active aircraft below this daily block time are flagged as under-utilised."),
    "crew.max_fdp_hours": (13, "Maximum flight duty period (hours) per duty, planning check only."),
    "crew.min_rest_hours": (10, "Minimum rest between duties (hours)."),
    "weather.live_enabled": (False, "Fetch live METAR/TAF from aviationweather.gov when online (otherwise simulated)."),
    "weather.max_crosswind_kt": (30, "Crosswind limit used for runway suitability warnings."),
    "tracking.update_seconds": (2, "Live tracking refresh period."),
    "backup.keep": (10, "Number of automatic backups to keep."),
    "backup.auto_daily": (True, "Create an automatic backup once per day."),
    "ui.time_zone": ("UTC", "Display time zone (all data is stored in UTC)."),
}

DEMO_USERS = [
    ("admin", "System Administrator", "ADMIN", "Admin#2026"),
    ("opsmanager", "Operations Manager", "OPS_MANAGER", "Ops#2026"),
    ("dispatcher", "Flight Dispatcher", "DISPATCHER", "Dispatch#2026"),
    ("analyst", "Operations Analyst", "ANALYST", "Analyst#2026"),
]
