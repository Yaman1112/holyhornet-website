"""Simplified aircraft performance model used for planning support.

These are planning-grade approximations (no wind, standard atmosphere) and are
NOT certified performance data.
"""
from __future__ import annotations

from dataclasses import dataclass

from .geo import NM_TO_KM

TAXI_OUT_MIN = 14
TAXI_IN_MIN = 7
CLIMB_DESCENT_OVERHEAD_MIN = 18  # extra time vs. pure cruise for climb, descent, approach


def airborne_minutes(distance_nm: float, cruise_ktas: float) -> float:
    # routing inefficiency of ~5% over great circle; slower average speed on short legs
    eff_dist = distance_nm * 1.05
    return CLIMB_DESCENT_OVERHEAD_MIN + eff_dist / (cruise_ktas * 0.93) * 60.0


def block_minutes(distance_nm: float, cruise_ktas: float) -> float:
    return TAXI_OUT_MIN + airborne_minutes(distance_nm, cruise_ktas) + TAXI_IN_MIN


def scheduled_block_minutes(distance_nm: float, cruise_ktas: float) -> int:
    """Commercial block time: estimate + schedule buffer, rounded up to 5 min."""
    est = block_minutes(distance_nm, cruise_ktas)
    buffered = est * 1.06 + 5
    return int(-(-buffered // 5) * 5)


@dataclass
class FuelPlan:
    taxi_kg: float
    trip_kg: float
    contingency_kg: float
    alternate_kg: float
    final_reserve_kg: float
    extra_kg: float

    @property
    def block_kg(self) -> float:
        return self.taxi_kg + self.trip_kg + self.contingency_kg + self.alternate_kg + self.final_reserve_kg + self.extra_kg

    @property
    def takeoff_kg(self) -> float:
        return self.block_kg - self.taxi_kg

    def as_dict(self) -> dict:
        return {
            "taxi_fuel_kg": round(self.taxi_kg),
            "trip_fuel_kg": round(self.trip_kg),
            "contingency_fuel_kg": round(self.contingency_kg),
            "alternate_fuel_kg": round(self.alternate_kg),
            "final_reserve_kg": round(self.final_reserve_kg),
            "extra_fuel_kg": round(self.extra_kg),
            "block_fuel_kg": round(self.block_kg),
        }


def fuel_plan(
    distance_nm: float,
    alternate_distance_nm: float,
    cruise_ktas: float,
    burn_kg_h: float,
    extra_kg: float = 0.0,
) -> FuelPlan:
    """EASA-style fuel breakdown (planning approximation).

    trip = airborne time x burn (climb penalty included via overhead minutes)
    contingency = 5% of trip (minimum 5 min holding)
    alternate = airborne time to alternate x burn
    final reserve = 30 min holding at 1500 ft (~ 75% of cruise burn)
    """
    taxi = burn_kg_h * 0.18 * (TAXI_OUT_MIN / 60.0) * 2.2  # taxi burn ~ low thrust
    trip = airborne_minutes(distance_nm, cruise_ktas) / 60.0 * burn_kg_h * 1.04
    contingency = max(trip * 0.05, burn_kg_h * 0.75 * 5 / 60.0)
    alternate = (airborne_minutes(alternate_distance_nm, cruise_ktas * 0.85) / 60.0) * burn_kg_h if alternate_distance_nm > 0 else 0.0
    final_reserve = burn_kg_h * 0.75 * 0.5
    return FuelPlan(taxi, trip, contingency, alternate, final_reserve, extra_kg)


def range_ok(distance_nm: float, range_km: float, margin: float = 0.9) -> bool:
    return distance_nm * NM_TO_KM <= range_km * margin
