"""Online SQLite backups (sqlite3 backup API) and restore."""
from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from . import config, db as dbmod


def create_backup(label: str = "manual") -> dict:
    s = config.settings
    s.ensure_dirs()
    ts = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    safe = "".join(c for c in label if c.isalnum() or c in "-_")[:20] or "manual"
    dest = s.backup_dir / f"fms-{ts}-{safe}.db"
    src = sqlite3.connect(s.db_path)
    dst = sqlite3.connect(dest)
    try:
        with dst:
            src.backup(dst)
    finally:
        dst.close()
        src.close()
    return info(dest)


def info(p: Path) -> dict:
    st = p.stat()
    return {"name": p.name, "size_bytes": st.st_size, "created_utc": datetime.utcfromtimestamp(st.st_mtime).isoformat(timespec="seconds")}


def list_backups() -> list[dict]:
    d = config.settings.backup_dir
    if not d.exists():
        return []
    return [info(p) for p in sorted(d.glob("fms-*.db"), reverse=True)]


def prune(keep: int) -> int:
    files = sorted(config.settings.backup_dir.glob("fms-*-auto.db"), reverse=True)
    n = 0
    for p in files[keep:]:
        p.unlink(missing_ok=True)
        n += 1
    return n


def _resolve(name: str) -> Path:
    p = (config.settings.backup_dir / name).resolve()
    if p.parent != config.settings.backup_dir.resolve() or not p.name.startswith("fms-") or p.suffix != ".db":
        raise ValueError("Invalid backup name")
    if not p.exists():
        raise FileNotFoundError(name)
    return p


def backup_path(name: str) -> Path:
    return _resolve(name)


def restore(name: str) -> dict:
    """Restore a backup: snapshot current DB first, then copy the backup in place."""
    p = _resolve(name)
    con = sqlite3.connect(p)
    try:
        ok = con.execute("PRAGMA integrity_check").fetchone()[0]
        if ok != "ok":
            raise ValueError(f"Backup failed integrity check: {ok}")
        if not con.execute("SELECT name FROM sqlite_master WHERE name='flights'").fetchone():
            raise ValueError("Not an HH-FMS database")
    finally:
        con.close()
    pre = create_backup("pre-restore")
    dbmod.reset_engine()
    target = config.settings.db_path
    for ext in ("-wal", "-shm"):
        Path(str(target) + ext).unlink(missing_ok=True)
    shutil.copyfile(p, target)
    from . import migrations

    migrations.migrate()
    return {"restored": name, "safety_backup": pre["name"]}
