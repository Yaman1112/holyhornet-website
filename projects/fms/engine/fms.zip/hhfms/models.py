"""Relational schema of the Flight Management System.

All timestamps are stored as naive UTC datetimes. ``data_source`` columns mark
where a record came from: SIMULATED (generated demo/sim data), IMPORTED
(user-supplied files), LIVE (external provider) or MANUAL (entered in the UI).
"""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def utcnow() -> datetime:
    return datetime.utcnow().replace(microsecond=0)


# --------------------------------------------------------------------------- reference


class Airline(Base):
    __tablename__ = "airlines"
    id: Mapped[int] = mapped_column(primary_key=True)
    icao: Mapped[str] = mapped_column(String(3), unique=True)
    iata: Mapped[str | None] = mapped_column(String(2))
    name: Mapped[str] = mapped_column(String(80))
    callsign: Mapped[str] = mapped_column(String(40))
    country: Mapped[str] = mapped_column(String(60), default="")
    hub_icao: Mapped[str | None] = mapped_column(String(4))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Airport(Base):
    __tablename__ = "airports"
    id: Mapped[int] = mapped_column(primary_key=True)
    icao: Mapped[str] = mapped_column(String(4), unique=True, index=True)
    iata: Mapped[str | None] = mapped_column(String(3), index=True)
    name: Mapped[str] = mapped_column(String(120))
    city: Mapped[str] = mapped_column(String(80), default="")
    country: Mapped[str] = mapped_column(String(60), default="")
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    elevation_ft: Mapped[int] = mapped_column(Integer, default=0)
    timezone: Mapped[str] = mapped_column(String(40), default="UTC")
    terminals: Mapped[int] = mapped_column(Integer, default=1)
    terminal_info: Mapped[str] = mapped_column(Text, default="")
    capacity_arr_per_hour: Mapped[int] = mapped_column(Integer, default=30)
    capacity_dep_per_hour: Mapped[int] = mapped_column(Integer, default=30)
    min_turnaround_min: Mapped[int] = mapped_column(Integer, default=35)
    status: Mapped[str] = mapped_column(String(20), default="OPEN")  # OPEN/RESTRICTED/CLOSED
    status_note: Mapped[str] = mapped_column(Text, default="")
    data_source: Mapped[str] = mapped_column(String(12), default="SIMULATED")
    runways: Mapped[list["Runway"]] = relationship(back_populates="airport", cascade="all, delete-orphan")


class Runway(Base):
    __tablename__ = "runways"
    id: Mapped[int] = mapped_column(primary_key=True)
    airport_id: Mapped[int] = mapped_column(ForeignKey("airports.id", ondelete="CASCADE"), index=True)
    designator: Mapped[str] = mapped_column(String(10))  # e.g. "18R/36L"
    length_m: Mapped[int] = mapped_column(Integer)
    width_m: Mapped[int] = mapped_column(Integer, default=45)
    heading_deg: Mapped[float] = mapped_column(Float)  # true heading of the first end
    surface: Mapped[str] = mapped_column(String(20), default="ASPH")
    ils: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(20), default="OPEN")  # OPEN/CLOSED
    airport: Mapped[Airport] = relationship(back_populates="runways")


class AircraftType(Base):
    __tablename__ = "aircraft_types"
    id: Mapped[int] = mapped_column(primary_key=True)
    icao: Mapped[str] = mapped_column(String(4), unique=True)
    manufacturer: Mapped[str] = mapped_column(String(40))
    model: Mapped[str] = mapped_column(String(60))
    mtow_kg: Mapped[int] = mapped_column(Integer)
    range_km: Mapped[int] = mapped_column(Integer)
    cruise_ktas: Mapped[int] = mapped_column(Integer)
    cruise_fl: Mapped[int] = mapped_column(Integer, default=360)
    pax_capacity: Mapped[int] = mapped_column(Integer)
    fuel_capacity_kg: Mapped[int] = mapped_column(Integer)
    fuel_burn_kg_h: Mapped[int] = mapped_column(Integer)
    min_runway_m: Mapped[int] = mapped_column(Integer, default=2000)
    min_turnaround_min: Mapped[int] = mapped_column(Integer, default=35)
    cockpit_crew: Mapped[int] = mapped_column(Integer, default=2)
    cabin_crew: Mapped[int] = mapped_column(Integer, default=4)
    wake_category: Mapped[str] = mapped_column(String(2), default="M")


class Aircraft(Base):
    __tablename__ = "aircraft"
    id: Mapped[int] = mapped_column(primary_key=True)
    registration: Mapped[str] = mapped_column(String(10), unique=True, index=True)
    type_id: Mapped[int] = mapped_column(ForeignKey("aircraft_types.id"), index=True)
    airline_id: Mapped[int | None] = mapped_column(ForeignKey("airlines.id"))
    msn: Mapped[str] = mapped_column(String(20), default="")
    delivery_date: Mapped[date | None] = mapped_column(Date)
    seats: Mapped[int | None] = mapped_column(Integer)  # cabin config, defaults to type capacity
    operational_status: Mapped[str] = mapped_column(String(20), default="ACTIVE")  # ACTIVE/AOG/STORED/MAINTENANCE
    maintenance_status: Mapped[str] = mapped_column(String(20), default="SERVICEABLE")  # SERVICEABLE/DUE/OVERDUE/IN_CHECK
    base_icao: Mapped[str] = mapped_column(String(4), default="EHAM")
    total_flight_hours: Mapped[float] = mapped_column(Float, default=0.0)
    total_cycles: Mapped[int] = mapped_column(Integer, default=0)
    hours_since_check: Mapped[float] = mapped_column(Float, default=0.0)
    check_interval_hours: Mapped[float] = mapped_column(Float, default=750.0)
    notes: Mapped[str] = mapped_column(Text, default="")
    data_source: Mapped[str] = mapped_column(String(12), default="SIMULATED")
    type: Mapped[AircraftType] = relationship()
    airline: Mapped[Airline | None] = relationship()


class MaintenanceRecord(Base):
    __tablename__ = "maintenance_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    aircraft_id: Mapped[int] = mapped_column(ForeignKey("aircraft.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(20))  # A-CHECK/C-CHECK/LINE/DEFECT/ENGINE/CABIN
    description: Mapped[str] = mapped_column(Text, default="")
    start_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    end_utc: Mapped[datetime] = mapped_column(DateTime)
    status: Mapped[str] = mapped_column(String(20), default="PLANNED")  # PLANNED/IN_PROGRESS/COMPLETED/CANCELLED
    station: Mapped[str] = mapped_column(String(4), default="EHAM")
    flight_hours_at: Mapped[float | None] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    aircraft: Mapped[Aircraft] = relationship()


class CrewMember(Base):
    __tablename__ = "crew_members"
    id: Mapped[int] = mapped_column(primary_key=True)
    employee_no: Mapped[str] = mapped_column(String(12), unique=True)
    first_name: Mapped[str] = mapped_column(String(40))
    last_name: Mapped[str] = mapped_column(String(40))
    role: Mapped[str] = mapped_column(String(4))  # CPT/FO/SCCM/CC
    base_icao: Mapped[str] = mapped_column(String(4), default="EHAM")
    type_ratings: Mapped[str] = mapped_column(String(80), default="")  # comma separated ICAO types
    airline_id: Mapped[int | None] = mapped_column(ForeignKey("airlines.id"))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


# --------------------------------------------------------------------------- schedule & flights


class Route(Base):
    __tablename__ = "routes"
    __table_args__ = (UniqueConstraint("origin_id", "destination_id", name="uq_route"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    origin_id: Mapped[int] = mapped_column(ForeignKey("airports.id"), index=True)
    destination_id: Mapped[int] = mapped_column(ForeignKey("airports.id"), index=True)
    distance_nm: Mapped[float] = mapped_column(Float)
    typical_block_min: Mapped[int] = mapped_column(Integer)
    waypoints: Mapped[list | None] = mapped_column(JSON)  # optional [[lat, lon], ...]
    origin: Mapped[Airport] = relationship(foreign_keys=[origin_id])
    destination: Mapped[Airport] = relationship(foreign_keys=[destination_id])


class FlightSchedule(Base):
    """Recurring (seasonal) schedule pattern from which daily flights are materialised."""

    __tablename__ = "flight_schedules"
    id: Mapped[int] = mapped_column(primary_key=True)
    airline_id: Mapped[int] = mapped_column(ForeignKey("airlines.id"))
    flight_number: Mapped[str] = mapped_column(String(8), index=True)
    route_id: Mapped[int] = mapped_column(ForeignKey("routes.id"))
    aircraft_type_id: Mapped[int] = mapped_column(ForeignKey("aircraft_types.id"))
    days_of_week: Mapped[str] = mapped_column(String(7), default="1234567")  # 1=Mon
    std_utc: Mapped[str] = mapped_column(String(5))  # HH:MM
    block_min: Mapped[int] = mapped_column(Integer)
    rotation_line: Mapped[str] = mapped_column(String(12), default="")
    leg_seq: Mapped[int] = mapped_column(Integer, default=1)
    valid_from: Mapped[date] = mapped_column(Date)
    valid_to: Mapped[date] = mapped_column(Date)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    airline: Mapped[Airline] = relationship()
    route: Mapped[Route] = relationship()
    aircraft_type: Mapped[AircraftType] = relationship()


FLIGHT_STATUSES = (
    "SCHEDULED",
    "BOARDING",
    "DEPARTED",
    "AIRBORNE",
    "LANDED",
    "ARRIVED",
    "DELAYED",
    "CANCELLED",
    "DIVERTED",
)


class Flight(Base):
    __tablename__ = "flights"
    __table_args__ = (
        UniqueConstraint("flight_number", "flight_date", name="uq_flight_day"),
        Index("ix_flights_std", "std_utc"),
        Index("ix_flights_status", "status"),
        Index("ix_flights_aircraft_std", "aircraft_id", "std_utc"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    airline_id: Mapped[int] = mapped_column(ForeignKey("airlines.id"))
    flight_number: Mapped[str] = mapped_column(String(8), index=True)
    callsign: Mapped[str] = mapped_column(String(10))
    flight_date: Mapped[date] = mapped_column(Date, index=True)
    schedule_id: Mapped[int | None] = mapped_column(ForeignKey("flight_schedules.id", ondelete="SET NULL"))
    origin_id: Mapped[int] = mapped_column(ForeignKey("airports.id"), index=True)
    destination_id: Mapped[int] = mapped_column(ForeignKey("airports.id"), index=True)
    alternate_id: Mapped[int | None] = mapped_column(ForeignKey("airports.id"))
    aircraft_type_id: Mapped[int] = mapped_column(ForeignKey("aircraft_types.id"))
    aircraft_id: Mapped[int | None] = mapped_column(ForeignKey("aircraft.id", ondelete="SET NULL"))
    rotation_line: Mapped[str] = mapped_column(String(12), default="")
    leg_seq: Mapped[int] = mapped_column(Integer, default=1)
    std_utc: Mapped[datetime] = mapped_column(DateTime)
    sta_utc: Mapped[datetime] = mapped_column(DateTime)
    etd_utc: Mapped[datetime | None] = mapped_column(DateTime)
    eta_utc: Mapped[datetime | None] = mapped_column(DateTime)
    atd_utc: Mapped[datetime | None] = mapped_column(DateTime)  # actual off-block
    takeoff_utc: Mapped[datetime | None] = mapped_column(DateTime)
    landing_utc: Mapped[datetime | None] = mapped_column(DateTime)
    ata_utc: Mapped[datetime | None] = mapped_column(DateTime)  # actual on-block
    status: Mapped[str] = mapped_column(String(12), default="SCHEDULED")
    delay_code: Mapped[str | None] = mapped_column(String(4))
    delay_reason: Mapped[str | None] = mapped_column(String(120))
    cancel_reason: Mapped[str | None] = mapped_column(String(120))
    pax_booked: Mapped[int] = mapped_column(Integer, default=0)
    cabin_crew_count: Mapped[int] = mapped_column(Integer, default=4)
    turnaround_min: Mapped[int | None] = mapped_column(Integer)  # planned ground time before this leg
    cruise_fl: Mapped[int | None] = mapped_column(Integer)
    route_text: Mapped[str] = mapped_column(Text, default="")
    remarks: Mapped[str] = mapped_column(Text, default="")
    data_source: Mapped[str] = mapped_column(String(12), default="SIMULATED")
    # simulation ground truth (hidden from the UI until the event happens)
    sim_out_utc: Mapped[datetime | None] = mapped_column(DateTime)
    sim_off_utc: Mapped[datetime | None] = mapped_column(DateTime)
    sim_on_utc: Mapped[datetime | None] = mapped_column(DateTime)
    sim_in_utc: Mapped[datetime | None] = mapped_column(DateTime)
    sim_cancel: Mapped[bool] = mapped_column(Boolean, default=False)
    sim_divert: Mapped[bool] = mapped_column(Boolean, default=False)
    sim_delay_code: Mapped[str | None] = mapped_column(String(4))
    sim_delay_reason: Mapped[str | None] = mapped_column(String(120))
    sim_cancel_reason: Mapped[str | None] = mapped_column(String(120))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    airline: Mapped[Airline] = relationship()
    origin: Mapped[Airport] = relationship(foreign_keys=[origin_id])
    destination: Mapped[Airport] = relationship(foreign_keys=[destination_id])
    alternate: Mapped[Airport | None] = relationship(foreign_keys=[alternate_id])
    aircraft_type: Mapped[AircraftType] = relationship()
    aircraft: Mapped[Aircraft | None] = relationship()
    crew: Mapped[list["FlightCrewAssignment"]] = relationship(
        back_populates="flight", cascade="all, delete-orphan"
    )


class FlightCrewAssignment(Base):
    __tablename__ = "flight_crew_assignments"
    __table_args__ = (UniqueConstraint("flight_id", "crew_id", name="uq_flight_crew"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    flight_id: Mapped[int] = mapped_column(ForeignKey("flights.id", ondelete="CASCADE"), index=True)
    crew_id: Mapped[int] = mapped_column(ForeignKey("crew_members.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(4))
    flight: Mapped[Flight] = relationship(back_populates="crew")
    crew_member: Mapped[CrewMember] = relationship()


class FlightMovement(Base):
    """Discrete OOOI-style movement events (OUT/OFF/ON/IN, plus DIVERT/CANCEL)."""

    __tablename__ = "flight_movements"
    __table_args__ = (Index("ix_mov_flight_event", "flight_id", "event"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    flight_id: Mapped[int] = mapped_column(ForeignKey("flights.id", ondelete="CASCADE"), index=True)
    event: Mapped[str] = mapped_column(String(10))
    time_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    airport_id: Mapped[int | None] = mapped_column(ForeignKey("airports.id"))
    runway: Mapped[str | None] = mapped_column(String(6))
    data_source: Mapped[str] = mapped_column(String(12), default="SIMULATED")


class DispatchRelease(Base):
    __tablename__ = "dispatch_releases"
    id: Mapped[int] = mapped_column(primary_key=True)
    flight_id: Mapped[int] = mapped_column(ForeignKey("flights.id", ondelete="CASCADE"), unique=True)
    status: Mapped[str] = mapped_column(String(12), default="DRAFT")  # DRAFT/PLANNED/BRIEFED/RELEASED/HOLD
    route_text: Mapped[str] = mapped_column(Text, default="")
    cruise_fl: Mapped[int | None] = mapped_column(Integer)
    alternate_icao: Mapped[str | None] = mapped_column(String(4))
    alternate2_icao: Mapped[str | None] = mapped_column(String(4))
    taxi_fuel_kg: Mapped[float] = mapped_column(Float, default=0)
    trip_fuel_kg: Mapped[float] = mapped_column(Float, default=0)
    contingency_fuel_kg: Mapped[float] = mapped_column(Float, default=0)
    alternate_fuel_kg: Mapped[float] = mapped_column(Float, default=0)
    final_reserve_kg: Mapped[float] = mapped_column(Float, default=0)
    extra_fuel_kg: Mapped[float] = mapped_column(Float, default=0)
    block_fuel_kg: Mapped[float] = mapped_column(Float, default=0)
    est_tow_kg: Mapped[float | None] = mapped_column(Float)
    restrictions: Mapped[str] = mapped_column(Text, default="")
    remarks: Mapped[str] = mapped_column(Text, default="")
    prepared_by: Mapped[str | None] = mapped_column(String(40))
    released_by: Mapped[str | None] = mapped_column(String(40))
    released_at: Mapped[datetime | None] = mapped_column(DateTime)
    history: Mapped[list | None] = mapped_column(JSON)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
    flight: Mapped[Flight] = relationship()


# --------------------------------------------------------------------------- environment


class WeatherRecord(Base):
    __tablename__ = "weather_records"
    __table_args__ = (UniqueConstraint("airport_id", "kind", "obs_time_utc", name="uq_wx"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    airport_id: Mapped[int] = mapped_column(ForeignKey("airports.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(5))  # METAR/TAF
    obs_time_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    raw: Mapped[str] = mapped_column(Text)
    wind_dir_deg: Mapped[int | None] = mapped_column(Integer)
    wind_speed_kt: Mapped[int | None] = mapped_column(Integer)
    wind_gust_kt: Mapped[int | None] = mapped_column(Integer)
    visibility_m: Mapped[int | None] = mapped_column(Integer)
    temperature_c: Mapped[int | None] = mapped_column(Integer)
    dewpoint_c: Mapped[int | None] = mapped_column(Integer)
    qnh_hpa: Mapped[int | None] = mapped_column(Integer)
    clouds: Mapped[str | None] = mapped_column(String(60))
    ceiling_ft: Mapped[int | None] = mapped_column(Integer)
    phenomena: Mapped[str | None] = mapped_column(String(40))
    flight_category: Mapped[str | None] = mapped_column(String(5))  # VFR/MVFR/IFR/LIFR
    severity: Mapped[float] = mapped_column(Float, default=0.0)
    data_source: Mapped[str] = mapped_column(String(12), default="SIMULATED")


class Notam(Base):
    __tablename__ = "notams"
    id: Mapped[int] = mapped_column(primary_key=True)
    notam_id: Mapped[str] = mapped_column(String(16), unique=True)
    airport_id: Mapped[int | None] = mapped_column(ForeignKey("airports.id", ondelete="CASCADE"), index=True)
    category: Mapped[str] = mapped_column(String(20))  # RWY/TWY/NAV/AD/AIRSPACE/OBST/OTHER
    subject: Mapped[str] = mapped_column(String(120))
    text: Mapped[str] = mapped_column(Text)
    valid_from_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    valid_to_utc: Mapped[datetime] = mapped_column(DateTime, index=True)
    severity: Mapped[str] = mapped_column(String(10), default="INFO")  # INFO/CAUTION/CRITICAL
    runway: Mapped[str | None] = mapped_column(String(10))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    data_source: Mapped[str] = mapped_column(String(12), default="SIMULATED")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    airport: Mapped[Airport | None] = relationship()


class OperationalAlert(Base):
    __tablename__ = "operational_alerts"
    __table_args__ = (Index("ix_alert_key", "dedupe_key"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    category: Mapped[str] = mapped_column(String(24))  # DELAY/CONFLICT/DURATION/UTILISATION/WEATHER/MAINTENANCE
    severity: Mapped[str] = mapped_column(String(10))  # INFO/WARNING/CRITICAL
    title: Mapped[str] = mapped_column(String(160))
    detail: Mapped[str] = mapped_column(Text, default="")
    flight_id: Mapped[int | None] = mapped_column(ForeignKey("flights.id", ondelete="CASCADE"))
    aircraft_id: Mapped[int | None] = mapped_column(ForeignKey("aircraft.id", ondelete="CASCADE"))
    airport_id: Mapped[int | None] = mapped_column(ForeignKey("airports.id", ondelete="CASCADE"))
    dedupe_key: Mapped[str] = mapped_column(String(120))
    acknowledged: Mapped[bool] = mapped_column(Boolean, default=False)
    acknowledged_by: Mapped[str | None] = mapped_column(String(40))
    resolved: Mapped[bool] = mapped_column(Boolean, default=False)


class DailyStat(Base):
    """Archived per-day operational KPIs (historical data mart, rebuilt nightly)."""

    __tablename__ = "daily_stats"
    __table_args__ = (UniqueConstraint("day", "airport_icao", name="uq_daily_stat"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    day: Mapped[date] = mapped_column(Date, index=True)
    airport_icao: Mapped[str] = mapped_column(String(4), default="ALL")
    flights: Mapped[int] = mapped_column(Integer, default=0)
    completed: Mapped[int] = mapped_column(Integer, default=0)
    cancelled: Mapped[int] = mapped_column(Integer, default=0)
    diverted: Mapped[int] = mapped_column(Integer, default=0)
    on_time_dep: Mapped[int] = mapped_column(Integer, default=0)
    on_time_arr: Mapped[int] = mapped_column(Integer, default=0)
    avg_dep_delay: Mapped[float] = mapped_column(Float, default=0.0)
    avg_arr_delay: Mapped[float] = mapped_column(Float, default=0.0)
    block_hours: Mapped[float] = mapped_column(Float, default=0.0)
    pax: Mapped[int] = mapped_column(Integer, default=0)


# --------------------------------------------------------------------------- system


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(80), default="")
    role: Mapped[str] = mapped_column(String(24))  # ADMIN/OPS_MANAGER/DISPATCHER/ANALYST
    password_hash: Mapped[str] = mapped_column(String(200))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=False)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime)
    last_login: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    time_utc: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    username: Mapped[str] = mapped_column(String(40), index=True)
    action: Mapped[str] = mapped_column(String(40))
    entity: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[str | None] = mapped_column(String(40))
    detail: Mapped[dict | None] = mapped_column(JSON)
    ip: Mapped[str | None] = mapped_column(String(45))


class SystemConfig(Base):
    __tablename__ = "system_config"
    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[dict | list | str | int | float | bool | None] = mapped_column(JSON)
    description: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
    updated_by: Mapped[str | None] = mapped_column(String(40))


class SchemaMigration(Base):
    __tablename__ = "schema_migrations"
    version: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    applied_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
