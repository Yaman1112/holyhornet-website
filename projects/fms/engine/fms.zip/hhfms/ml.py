"""Predictive flight analytics (scikit-learn gradient boosting).

Models
* departure delay  - HistGradientBoostingRegressor + 10/90% quantile models
* arrival delay    - same structure
* cancellation     - HistGradientBoostingClassifier (probability)
* turnaround       - regressor on actual ground time (prev ATA -> ATD)
* traffic demand   - regressor on actual movements per airport-hour

Explanations use feature occlusion: each feature is replaced by its training
reference value and the change in prediction is reported as that factor's
contribution. Models are trained on the database contents (simulated demo
history by default) and their holdout metrics are reported with every result.
"""
from __future__ import annotations

import threading
from datetime import datetime, timedelta

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, roc_auc_score
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import analytics, config, weather
from .geo import distance_nm
from .models import Airport, Flight, WeatherRecord, utcnow

FEATURES = ["hour", "dow", "origin", "destination", "type", "leg_seq", "turnaround_min", "origin_wx", "dest_wx",
            "distance_nm", "inbound_delay", "pax_load"]
CATEGORICAL = ["origin", "destination", "type"]
LABELS = {
    "hour": "Departure hour (UTC)", "dow": "Day of week", "origin": "Departure airport", "destination": "Arrival airport",
    "type": "Aircraft type", "leg_seq": "Leg in aircraft rotation", "turnaround_min": "Planned ground time before leg",
    "origin_wx": "Weather severity at departure", "dest_wx": "Weather severity at arrival", "distance_nm": "Route distance",
    "inbound_delay": "Inbound aircraft delay", "pax_load": "Passenger load",
}
DEMAND_FEATURES = ["airport", "hour", "dow", "scheduled", "wx"]
DOW = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

_lock = threading.Lock()
_cache: dict = {}


def _path():
    return config.settings.model_dir / "fms_models.joblib"


# --------------------------------------------------------------------------- features


class WxLookup:
    def __init__(self, db: Session, start: datetime, end: datetime):
        self.db = db
        rows = db.execute(select(WeatherRecord.airport_id, WeatherRecord.obs_time_utc, WeatherRecord.severity).where(
            WeatherRecord.kind == "METAR", WeatherRecord.obs_time_utc >= start - timedelta(hours=2),
            WeatherRecord.obs_time_utc <= end + timedelta(hours=2))).all()
        self.obs = {(a, t.replace(minute=0, second=0)): s for a, t, s in rows}
        self.airports = {a.id: a for a in db.scalars(select(Airport)).all()}

    def sev(self, airport_id: int, t: datetime) -> float:
        k = (airport_id, t.replace(minute=0, second=0, microsecond=0))
        if k in self.obs:
            return float(self.obs[k])
        a = self.airports[airport_id]
        # forecast: simulator state (what the TAF is built from)
        return weather.simulate(a.icao, a.lat, a.lon, a.elevation_ft, k[1], config.settings.seed).severity


def _features(db: Session, df: pd.DataFrame, wx: WxLookup, now: datetime | None = None) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=FEATURES)
    ap = wx.airports
    df = df.sort_values(["aircraft_id", "std"]).copy()
    # inbound delay: previous leg of the same tail within 14 h
    prev_arr_delay = []
    last: dict = {}
    for row in df.itertuples():
        p = last.get(row.aircraft_id)
        v = 0.0
        if p is not None and pd.notna(row.aircraft_id) and (row.std - p[0]).total_seconds() < 14 * 3600:
            v = p[1]
        prev_arr_delay.append(v)
        if pd.notna(row.aircraft_id):
            if pd.notna(row.ata):
                arr_delay = (row.ata - row.sta).total_seconds() / 60
            elif "eta" in df.columns and pd.notna(getattr(row, "eta", None)):
                arr_delay = (row.eta - row.sta).total_seconds() / 60
            else:
                arr_delay = 0.0
            last[row.aircraft_id] = (row.sta, max(0.0, arr_delay) if row.status != "CANCELLED" else 0.0)
    df["inbound_delay"] = prev_arr_delay
    X = pd.DataFrame(index=df.index)
    X["hour"] = df["std"].dt.hour
    X["dow"] = df["std"].dt.dayofweek
    X["origin"] = df["origin"].astype(str)
    X["destination"] = df["destination"].astype(str)
    X["type"] = df["type"].astype(str)
    X["leg_seq"] = df["leg_seq"].fillna(1)
    X["turnaround_min"] = df["turnaround_min"].fillna(0)
    X["origin_wx"] = [wx.sev(o, t.to_pydatetime()) for o, t in zip(df["origin_id"], df["std"])]
    X["dest_wx"] = [wx.sev(d, t.to_pydatetime()) for d, t in zip(df["destination_id"], df["sta"])]
    X["distance_nm"] = [distance_nm(ap[o].lat, ap[o].lon, ap[d].lat, ap[d].lon) for o, d in zip(df["origin_id"], df["destination_id"])]
    X["inbound_delay"] = df["inbound_delay"]
    X["pax_load"] = df["pax"].fillna(0)
    return X


def _encode(X: pd.DataFrame, cats: dict[str, list[str]]) -> pd.DataFrame:
    X = X.copy()
    for c in CATEGORICAL:
        m = {v: i for i, v in enumerate(cats[c])}
        X[c] = X[c].map(lambda v: m.get(v, -1)).astype(float)
        X.loc[X[c] < 0, c] = np.nan
    return X[FEATURES].astype(float)


def _reg(loss="squared_error", q=None):
    kw = dict(max_iter=250, learning_rate=0.06, max_leaf_nodes=31, min_samples_leaf=25, random_state=7,
              categorical_features=[FEATURES.index(c) for c in CATEGORICAL])
    if loss == "quantile":
        return HistGradientBoostingRegressor(loss="quantile", quantile=q, **kw)
    return HistGradientBoostingRegressor(**kw)


# --------------------------------------------------------------------------- training


def train(db: Session, now: datetime | None = None, days: int = 120) -> dict:
    now = now or utcnow()
    start = now - timedelta(days=days)
    df = analytics.flights_df(db, start, now)
    df = df[df["std"] < pd.Timestamp(now - timedelta(hours=1))]
    if len(df) < 300:
        raise ValueError(f"Not enough historical flights to train ({len(df)}; need >= 300)")
    wx = WxLookup(db, start, now + timedelta(days=2))
    Xraw = _features(db, df, wx)
    df = df.loc[Xraw.index]
    cats = {c: sorted(Xraw[c].dropna().unique().tolist()) for c in CATEGORICAL}
    X = _encode(Xraw, cats)
    order = np.argsort(df["std"].values)
    split = int(len(order) * 0.85)
    tr_idx, te_idx = order[:split], order[split:]
    models: dict = {}
    metrics: dict = {}
    reference = X.iloc[tr_idx].median(numeric_only=True)
    for c in CATEGORICAL:
        reference[c] = float(X.iloc[tr_idx][c].mode().iloc[0])

    for target, col in (("departure_delay", "dep_delay"), ("arrival_delay", "arr_delay")):
        mask = df[col].notna().values
        y = df[col].clip(-15, 300).values
        tr = tr_idx[mask[tr_idx]]
        te = te_idx[mask[te_idx]]
        m = _reg().fit(X.iloc[tr], y[tr])
        lo = _reg("quantile", 0.1).fit(X.iloc[tr], y[tr])
        hi = _reg("quantile", 0.9).fit(X.iloc[tr], y[tr])
        pred = m.predict(X.iloc[te])
        p_lo, p_hi = lo.predict(X.iloc[te]), hi.predict(X.iloc[te])
        metrics[target] = {
            "mae_min": round(float(mean_absolute_error(y[te], pred)), 2),
            "baseline_mae_min": round(float(mean_absolute_error(y[te], np.full(len(te), np.median(y[tr])))), 2),
            "interval_coverage_80": round(float(np.mean((y[te] >= p_lo) & (y[te] <= p_hi))), 3),
            "n_train": int(len(tr)), "n_test": int(len(te)),
        }
        models[target] = (m, lo, hi)

    # cancellations
    yc = (df["status"] == "CANCELLED").astype(int).values
    clf = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.06, min_samples_leaf=30, random_state=7,
                                         categorical_features=[FEATURES.index(c) for c in CATEGORICAL],
                                         class_weight=None)
    clf.fit(X.iloc[tr_idx], yc[tr_idx])
    pc = clf.predict_proba(X.iloc[te_idx])[:, 1]
    auc = None
    if len(set(yc[te_idx].tolist())) > 1:
        auc = float(roc_auc_score(yc[te_idx], pc))
    metrics["cancellation"] = {
        "auc": round(auc, 3) if auc is not None else None,
        "brier": round(float(np.mean((pc - yc[te_idx]) ** 2)), 4),
        "base_rate": round(float(yc.mean()), 4), "n_train": int(len(tr_idx)), "n_test": int(len(te_idx)),
    }
    models["cancellation"] = clf

    # turnaround (actual ground time prior to departure)
    df_s = df.sort_values(["aircraft_id", "std"])
    prev_ata = df_s.groupby("aircraft_id")["ata"].shift(1)
    ground = (df_s["atd"] - prev_ata).dt.total_seconds() / 60
    valid = ground.notna() & (ground > 10) & (ground < 600) & (df_s["turnaround_min"].notna())
    Xt = X.loc[df_s.index[valid]]
    yt = ground[valid].values
    if len(Xt) > 200:
        o = np.argsort(df_s.loc[valid, "std"].values)
        s2 = int(len(o) * 0.85)
        mt = _reg().fit(Xt.iloc[o[:s2]], yt[o[:s2]])
        lo = _reg("quantile", 0.1).fit(Xt.iloc[o[:s2]], yt[o[:s2]])
        hi = _reg("quantile", 0.9).fit(Xt.iloc[o[:s2]], yt[o[:s2]])
        pt = mt.predict(Xt.iloc[o[s2:]])
        metrics["turnaround"] = {
            "mae_min": round(float(mean_absolute_error(yt[o[s2:]], pt)), 2),
            "baseline_mae_min": round(float(mean_absolute_error(yt[o[s2:]], np.full(len(pt), np.median(yt[o[:s2]])))), 2),
            "n_train": int(s2), "n_test": int(len(o) - s2),
        }
        models["turnaround"] = (mt, lo, hi)

    # traffic demand per airport-hour
    dm, dmet, dcats = _train_demand(df, wx)
    models["demand"] = dm
    metrics["traffic_demand"] = dmet

    bundle = {"models": models, "cats": cats, "demand_cats": dcats, "reference": reference.to_dict(),
              "metrics": metrics, "trained_at": now.isoformat(), "n_samples": int(len(df)),
              "data_sources": df["data_source"].value_counts().to_dict(),
              "train_range": [start.isoformat(), now.isoformat()]}
    config.settings.model_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, _path())
    with _lock:
        _cache["bundle"] = bundle
    return _clean({k: v for k, v in bundle.items() if k not in ("models", "reference", "cats", "demand_cats")})


def _demand_frame(df: pd.DataFrame, wx: WxLookup) -> pd.DataFrame:
    live = df.copy()
    rows = []
    sched = pd.concat([
        pd.DataFrame({"airport": live["origin"], "airport_id": live["origin_id"], "t": live["std"].dt.floor("h")}),
        pd.DataFrame({"airport": live["destination"], "airport_id": live["destination_id"], "t": live["sta"].dt.floor("h")}),
    ])
    act_src = live[live["status"] != "CANCELLED"]
    actual = pd.concat([
        pd.DataFrame({"airport": act_src["origin"], "t": act_src["takeoff"].dt.floor("h")}),
        pd.DataFrame({"airport": act_src["destination"], "t": act_src["landing"].dt.floor("h")}),
    ]).dropna()
    sc = sched.groupby(["airport", "airport_id", "t"]).size().rename("scheduled").reset_index()
    ac = actual.groupby(["airport", "t"]).size().rename("actual")
    sc = sc.join(ac, on=["airport", "t"]).fillna({"actual": 0})
    sc["hour"] = sc["t"].dt.hour
    sc["dow"] = sc["t"].dt.dayofweek
    sc["wx"] = [wx.sev(int(a), t.to_pydatetime()) for a, t in zip(sc["airport_id"], sc["t"])]
    return sc


def _train_demand(df: pd.DataFrame, wx: WxLookup):
    sc = _demand_frame(df, wx)
    cats = sorted(sc["airport"].unique().tolist())
    m = {v: i for i, v in enumerate(cats)}
    X = pd.DataFrame({"airport": sc["airport"].map(m).astype(float), "hour": sc["hour"], "dow": sc["dow"],
                      "scheduled": sc["scheduled"], "wx": sc["wx"]})
    y = sc["actual"].values
    o = np.argsort(sc["t"].values)
    s = int(len(o) * 0.85)
    kw = dict(max_iter=200, learning_rate=0.06, min_samples_leaf=20, random_state=7, categorical_features=[0])
    mdl = HistGradientBoostingRegressor(**kw).fit(X.iloc[o[:s]], y[o[:s]])
    lo = HistGradientBoostingRegressor(loss="quantile", quantile=0.1, **kw).fit(X.iloc[o[:s]], y[o[:s]])
    hi = HistGradientBoostingRegressor(loss="quantile", quantile=0.9, **kw).fit(X.iloc[o[:s]], y[o[:s]])
    p = mdl.predict(X.iloc[o[s:]])
    met = {"mae_movements": round(float(mean_absolute_error(y[o[s:]], p)), 3),
           "baseline_mae_movements": round(float(mean_absolute_error(y[o[s:]], X.iloc[o[s:]]["scheduled"].values)), 3),
           "n_train": int(s), "n_test": int(len(o) - s)}
    return (mdl, lo, hi), met, cats


def load() -> dict | None:
    with _lock:
        if "bundle" in _cache:
            return _cache["bundle"]
        p = _path()
        if p.exists():
            try:
                _cache["bundle"] = joblib.load(p)
                return _cache["bundle"]
            except Exception:
                return None
    return None


def status() -> dict:
    b = load()
    if not b:
        return {"trained": False}
    return _clean({"trained": True, **{k: v for k, v in b.items() if k not in ("models", "reference", "cats", "demand_cats")}})


# --------------------------------------------------------------------------- inference


def _clean(o):
    """Convert numpy scalars/containers to plain Python for JSON."""
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, np.generic):
        v = o.item()
        return None if isinstance(v, float) and not np.isfinite(v) else v
    if isinstance(o, float) and not np.isfinite(o):
        return None
    return o


def _confidence(lo: float, hi: float, scale: float = 45.0) -> dict:
    width = max(0.0, hi - lo)
    score = 1.0 / (1.0 + width / scale)
    level = "HIGH" if score >= 0.6 else ("MEDIUM" if score >= 0.4 else "LOW")
    return {"interval_80": [round(lo, 1), round(hi, 1)], "score": round(score, 2), "level": level}


def _explain(model, Xrow: pd.DataFrame, ref: dict, raw: pd.Series, top: int = 6, proba: bool = False) -> list[dict]:
    def pred(x):
        return float(model.predict_proba(x)[:, 1][0]) if proba else float(model.predict(x)[0])

    base = pred(Xrow)
    rows = []
    for f in FEATURES:
        x2 = Xrow.copy()
        x2[f] = ref.get(f, x2[f].iloc[0])
        delta = base - pred(x2)
        val = raw[f]
        if f == "dow":
            val = DOW[int(val)]
        elif isinstance(val, float):
            val = round(val, 2)
        rows.append({"feature": f, "label": LABELS[f], "value": val, "contribution": round(delta * (100 if proba else 1), 2)})
    rows.sort(key=lambda r: -abs(r["contribution"]))
    return rows[:top]


def _frame_for_flights(db: Session, flights: list[Flight]) -> pd.DataFrame:
    """flights_df-like frame (with prior legs for inbound delay)."""
    if not flights:
        return pd.DataFrame()
    t0 = min(f.std_utc for f in flights) - timedelta(hours=16)
    t1 = max(f.std_utc for f in flights) + timedelta(minutes=1)
    df = analytics.flights_df(db, t0, t1)
    eta = {f.id: f.eta_utc for f in db.scalars(select(Flight).where(Flight.std_utc >= t0, Flight.std_utc < t1)).all()}
    df["eta"] = pd.to_datetime(df["id"].map(eta))
    return df


def predict_flights(db: Session, flight_ids: list[int], explain: bool = True) -> list[dict]:
    b = load()
    if not b:
        raise RuntimeError("Models not trained yet")
    flights = db.scalars(select(Flight).where(Flight.id.in_(flight_ids))).all()
    df = _frame_for_flights(db, flights)
    if df.empty:
        return []
    wx = WxLookup(db, df["std"].min().to_pydatetime(), df["sta"].max().to_pydatetime())
    Xraw = _features(db, df, wx)
    Xraw = Xraw[df.loc[Xraw.index, "id"].isin(flight_ids)]
    X = _encode(Xraw, b["cats"])
    ids = df.loc[X.index, "id"].values
    out = []
    ref = b["reference"]
    M = b["models"]
    for i, fid in enumerate(ids):
        xr = X.iloc[[i]]
        raw = Xraw.iloc[i]
        res: dict = {"flight_id": int(fid), "flight_number": df.loc[X.index[i], "flight_number"],
                     "route": df.loc[X.index[i], "route"], "std": df.loc[X.index[i], "std"].isoformat(),
                     "status": df.loc[X.index[i], "status"]}
        for target in ("departure_delay", "arrival_delay"):
            m, lo, hi = M[target]
            p = float(m.predict(xr)[0])
            l_, h_ = sorted([float(lo.predict(xr)[0]), float(hi.predict(xr)[0])])
            res[target] = {"minutes": round(p, 1), **_confidence(l_, h_),
                           "probability_over_15": None}
            if explain:
                res[target]["factors"] = _explain(m, xr, ref, raw)
        # probability of exceeding 15 min from the quantile pair (logistic approximation)
        dd = res["departure_delay"]
        lo_, hi_ = dd["interval_80"]
        sigma = max(3.0, (hi_ - lo_) / 2.563)
        dd["probability_over_15"] = round(float(1 / (1 + np.exp(-(dd["minutes"] - 15) / (sigma * 0.6)))), 3)
        clf = M["cancellation"]
        pc = float(clf.predict_proba(xr)[:, 1][0])
        res["cancellation"] = {"probability": round(pc, 4), "level": "HIGH" if pc > 0.15 else ("ELEVATED" if pc > 0.04 else "LOW")}
        if explain:
            res["cancellation"]["factors"] = _explain(clf, xr, ref, raw, proba=True)
        if "turnaround" in M and float(raw["turnaround_min"]) > 0:
            m, lo, hi = M["turnaround"]
            p = float(m.predict(xr)[0])
            l_, h_ = sorted([float(lo.predict(xr)[0]), float(hi.predict(xr)[0])])
            res["turnaround"] = {"minutes": round(p, 1), "planned_minutes": float(raw["turnaround_min"]), **_confidence(l_, h_, 30)}
            if explain:
                res["turnaround"]["factors"] = _explain(m, xr, ref, raw)
        out.append(_clean(res))
    out.sort(key=lambda r: r["std"])
    return out


def predict_upcoming(db: Session, hours: int = 24, now: datetime | None = None, limit: int = 200) -> list[dict]:
    now = now or utcnow()
    flights = db.scalars(select(Flight.id).where(
        Flight.std_utc >= now, Flight.std_utc <= now + timedelta(hours=hours), Flight.status.notin_(("CANCELLED",)),
    ).order_by(Flight.std_utc).limit(limit)).all()
    return predict_flights(db, list(flights), explain=False)


def predict_demand(db: Session, airport_icao: str, day: datetime) -> dict:
    b = load()
    if not b:
        raise RuntimeError("Models not trained yet")
    d0 = datetime.combine(day.date(), datetime.min.time())
    df = analytics.flights_df(db, d0 - timedelta(hours=12), d0 + timedelta(days=1))
    ap = db.scalars(select(Airport).where(Airport.icao == airport_icao)).first()
    if ap is None:
        raise ValueError("Unknown airport")
    wx = WxLookup(db, d0, d0 + timedelta(days=1))
    rows = []
    dm, lo, hi = b["models"]["demand"]
    cat = {v: i for i, v in enumerate(b["demand_cats"])}
    for h in range(24):
        t = d0 + timedelta(hours=h)
        if df.empty:
            sched = 0
        else:
            sched = int(((df["origin"] == airport_icao) & (df["std"].dt.floor("h") == t)).sum()
                        + ((df["destination"] == airport_icao) & (df["sta"].dt.floor("h") == t)).sum())
        x = pd.DataFrame([{"airport": float(cat.get(airport_icao, np.nan)), "hour": h, "dow": t.weekday(),
                           "scheduled": sched, "wx": wx.sev(ap.id, t)}])
        p = max(0.0, float(dm.predict(x)[0]))
        l_, h_ = sorted([max(0.0, float(lo.predict(x)[0])), max(0.0, float(hi.predict(x)[0]))])
        rows.append({"hour": h, "scheduled": sched, "predicted": round(p, 2), "low": round(l_, 2), "high": round(h_, 2),
                     "weather_severity": round(wx.sev(ap.id, t), 2)})
    cap = ap.capacity_arr_per_hour + ap.capacity_dep_per_hour
    return _clean({"airport": airport_icao, "date": d0.date().isoformat(), "hourly": rows,
            "total_predicted": round(sum(r["predicted"] for r in rows), 1), "total_scheduled": sum(r["scheduled"] for r in rows),
            "hourly_capacity": cap, "metrics": b["metrics"].get("traffic_demand")})
