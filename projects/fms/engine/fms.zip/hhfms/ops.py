"""Operations engine.

* materialise_day(): turns recurring schedules into dated flights, assigns
  tails (rotation lines) and crews, and draws the *simulated* operational
  outcome (delays, cancellations, diversions) used by the live simulator.
* simulate_flight_truth(): the outcome model for a single flight (also used for
  manually created flights).
* advance(): moves flights through their lifecycle as the wall clock passes the
  simulated OUT/OFF/ON/IN times and records movement events.
"""
from __future__ import annotations

import math
import random
from collections import defaultdict
from datetime import date, datetime, time, timedelta

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from . import config, perf, weather
from .geo import distance_nm
from .models import (
    Aircraft,
    AircraftType,
    Airport,
    CrewMember,
    Flight,
    FlightCrewAssignment,
    FlightMovement,
    FlightSchedule,
    MaintenanceRecord,
    utcnow,
)
from .refdata import TYPE_FAMILY

FINAL_STATUSES = ("ARRIVED", "CANCELLED", "DIVERTED")
HUB_PEAKS = {6, 7, 8, 16, 17, 18}


def _rng(*parts) -> random.Random:
    return random.Random(weather._h(config.settings.seed, *parts))


# --------------------------------------------------------------------------- weather cache


class WxCache:
    """Memoised simulated weather severity per (airport, hour)."""

    def __init__(self, airports: dict[int, Airport]):
        self.airports = airports
        self._c: dict[tuple[int, datetime], weather.WxState] = {}

    def state(self, airport_id: int, t: datetime) -> weather.WxState:
        k = (airport_id, t.replace(minute=0, second=0, microsecond=0))
        if k not in self._c:
            a = self.airports[airport_id]
            self._c[k] = weather.simulate(a.icao, a.lat, a.lon, a.elevation_ft, k[1], config.settings.seed)
        return self._c[k]

    def sev(self, airport_id: int, t: datetime) -> float:
        return self.state(airport_id, t).severity


# --------------------------------------------------------------------------- outcome model


def simulate_flight_truth(
    f: Flight,
    wx: WxCache,
    prev_in: datetime | None,
    min_turn: int,
    hubs: set[int],
    airborne_min: float,
    rng: random.Random,
    allow_cancel: bool = True,
) -> None:
    """Draw the operational outcome for one flight (writes sim_* fields)."""
    std = f.std_utc
    wo = wx.sev(f.origin_id, std)
    wd = wx.sev(f.destination_id, f.sta_utc)
    peak = 1.0 if (std.hour in HUB_PEAKS and f.origin_id in hubs) else 0.0
    dow = std.weekday()
    busy_day = 1.0 if dow in (4, 6) else 0.0

    # own (primary) delay
    p_late = min(0.85, 0.22 + 0.45 * wo + 0.12 * peak + 0.06 * busy_day + 0.03 * (f.leg_seq - 1) + 0.15 * wd)
    code, reason = None, None
    if rng.random() < p_late:
        mean = 9 + 38 * wo + 8 * peak + 5 * busy_day + 2 * f.leg_seq + 14 * wd
        own = rng.expovariate(1 / mean)
        factors = {
            "71": 38 * wo + 14 * wd,  # weather
            "81": 8 * peak + 5 * busy_day + 10 * wd,  # ATFM / capacity
            "15": 4 + 2 * f.leg_seq,  # boarding
            "13": 3,  # check-in / pax
            "63": 2,  # crew
            "87": 2.5 * peak,  # airport facilities
        }
        code = rng.choices(list(factors), weights=list(factors.values()))[0]
    else:
        own = max(-5.0, rng.gauss(-2, 3))
    if rng.random() < 0.012:  # technical issue
        own += rng.uniform(45, 200)
        code = "41"
    reasons = {
        "71": "Weather at departure/destination", "81": "ATFM / ATC capacity restriction", "15": "Boarding",
        "13": "Passenger / check-in", "63": "Crew late or rostering", "87": "Airport facilities", "41": "Aircraft technical defect",
        "93": "Late inbound aircraft (rotation)",
    }

    out = std + timedelta(minutes=own)
    if prev_in is not None:
        ready = prev_in + timedelta(minutes=min_turn)
        if ready > out:
            if (ready - std).total_seconds() / 60 >= 5:
                code = "93"
            out = ready
    out = out.replace(second=0, microsecond=0)

    # cancellations (decided on outbound legs; the return leg follows)
    cancel = False
    creason = None
    if allow_cancel:
        p_c = 0.006 + 0.18 * wo ** 3 + 0.12 * wd ** 3 + (0.3 if (out - std).total_seconds() > 4 * 3600 else 0)
        if rng.random() < p_c:
            cancel = True
            creason = "Weather" if max(wo, wd) > 0.45 else ("Technical" if code == "41" else "Operational / network recovery")

    taxi_out = 9 + 6 * peak + 8 * wo + rng.uniform(0, 6)
    hold = (wd * 22 * rng.random()) + (3 * rng.random() if f.destination_id in hubs else 0)
    air = airborne_min * (1 + rng.gauss(0, 0.035)) + hold
    taxi_in = 4 + rng.uniform(0, 6) + 3 * wd
    off = out + timedelta(minutes=taxi_out)
    on = off + timedelta(minutes=air)
    inn = on + timedelta(minutes=taxi_in)

    divert = (not cancel) and rng.random() < (0.0015 + 0.05 * wd ** 4)

    f.sim_cancel = cancel
    f.sim_cancel_reason = creason
    f.sim_divert = divert
    f.sim_out_utc = out
    f.sim_off_utc = off.replace(microsecond=0)
    f.sim_on_utc = on.replace(microsecond=0)
    f.sim_in_utc = inn.replace(microsecond=0)
    dep_delay = (out - std).total_seconds() / 60
    if dep_delay >= 5 and code:
        f.sim_delay_code = code
        f.sim_delay_reason = reasons[code]
    else:
        f.sim_delay_code = None
        f.sim_delay_reason = None


# --------------------------------------------------------------------------- materialisation


def _parse_hhmm(s: str) -> time:
    h, m = s.split(":")
    return time(int(h), int(m))


def _available_tails(db: Session, type_id: int, day: date) -> list[Aircraft]:
    tails = db.scalars(
        select(Aircraft).where(Aircraft.type_id == type_id, Aircraft.operational_status.in_(("ACTIVE", "MAINTENANCE")))
        .order_by(Aircraft.registration)
    ).all()
    d0 = datetime.combine(day, time(0))
    d1 = d0 + timedelta(days=1)
    busy = set(
        db.scalars(
            select(MaintenanceRecord.aircraft_id).where(
                MaintenanceRecord.status.in_(("PLANNED", "IN_PROGRESS")),
                MaintenanceRecord.kind.in_(("C-CHECK", "ENGINE", "DEFECT")),
                MaintenanceRecord.start_utc < d1,
                MaintenanceRecord.end_utc > d0,
            )
        ).all()
    )
    return [a for a in tails if a.id not in busy and a.operational_status != "STORED"]


def materialise_day(db: Session, day: date, now: datetime | None = None, ctx: dict | None = None) -> int:
    """Create flights for `day` from active schedules. Idempotent per flight number/day."""
    now = now or utcnow()
    ctx = ctx if ctx is not None else build_ctx(db)
    existing = set(db.scalars(select(Flight.flight_number).where(Flight.flight_date == day)).all())
    dow = str(day.isoweekday())
    scheds = db.scalars(
        select(FlightSchedule).where(
            FlightSchedule.active.is_(True), FlightSchedule.valid_from <= day, FlightSchedule.valid_to >= day
        ).order_by(FlightSchedule.rotation_line, FlightSchedule.leg_seq)
    ).all()
    scheds = [s for s in scheds if dow in s.days_of_week]
    by_line: dict[str, list[FlightSchedule]] = defaultdict(list)
    for s in scheds:
        by_line[s.rotation_line or f"S{s.id}"].append(s)

    # tail assignment: rotate the available tails of each type daily
    lines_by_type: dict[int, list[str]] = defaultdict(list)
    for line, legs in sorted(by_line.items()):
        lines_by_type[legs[0].aircraft_type_id].append(line)
    tail_for_line: dict[str, Aircraft | None] = {}
    for type_id, lines in lines_by_type.items():
        tails = _available_tails(db, type_id, day)
        if tails:
            k = day.toordinal() % len(tails)
            tails = tails[k:] + tails[:k]
        for i, line in enumerate(lines):
            tail_for_line[line] = tails[i] if i < len(tails) else None

    crew_pool = ctx["crew_pool"]
    created = 0
    for line, legs in sorted(by_line.items()):
        if all(s.flight_number in existing for s in legs):
            continue
        tail = tail_for_line.get(line)
        legs.sort(key=lambda s: s.leg_seq)
        prev_in: datetime | None = None
        prev_cancel = False
        prev_sta: datetime | None = None
        rng = _rng("day", day.isoformat(), line)
        line_flights: list[Flight] = []
        for s in legs:
            atype: AircraftType = ctx["types"][s.aircraft_type_id]
            route = s.route
            std = datetime.combine(day, _parse_hhmm(s.std_utc))
            if prev_sta and std < prev_sta:  # leg after midnight
                std += timedelta(days=1)
            sta = std + timedelta(minutes=s.block_min)
            prev_sta = sta
            if s.flight_number in existing:
                continue
            f = Flight(
                airline_id=s.airline_id,
                flight_number=s.flight_number,
                callsign=ctx["callsign"][s.airline_id] + s.flight_number[2:],
                flight_date=day,
                schedule_id=s.id,
                origin_id=route.origin_id,
                destination_id=route.destination_id,
                aircraft_type_id=atype.id,
                aircraft_id=tail.id if tail else None,
                rotation_line=line,
                leg_seq=s.leg_seq,
                std_utc=std,
                sta_utc=sta,
                status="SCHEDULED",
                pax_booked=int(atype.pax_capacity * min(0.98, max(0.45, rng.gauss(0.83, 0.08)))),
                cabin_crew_count=atype.cabin_crew,
                cruise_fl=atype.cruise_fl if route.distance_nm > 250 else min(atype.cruise_fl, 240),
                data_source="SIMULATED",
            )
            f.alternate_id = ctx["alternates"].get(route.destination_id)
            if line_flights:
                f.turnaround_min = int((std - line_flights[-1].sta_utc).total_seconds() / 60)
            airborne = perf.airborne_minutes(route.distance_nm, atype.cruise_ktas)
            turn = ctx["min_turn"](route.origin_id, atype)
            outbound = route.origin_id in ctx["hubs"]
            simulate_flight_truth(f, ctx["wx"], prev_in, turn, ctx["hubs"], airborne, rng, allow_cancel=outbound)
            if not outbound and prev_cancel:
                f.sim_cancel = True
                f.sim_cancel_reason = "Inbound/outbound pair cancelled"
            if f.sim_cancel:
                prev_cancel = True
            else:
                prev_cancel = False
                prev_in = f.sim_in_utc
                if f.sim_divert:
                    prev_in = f.sim_in_utc + timedelta(minutes=150)  # recovery from diversion
            line_flights.append(f)
            db.add(f)
            created += 1
        if line_flights:
            db.flush()
            _assign_crew(db, line, line_flights, day, crew_pool, TYPE_FAMILY.get(ctx["types"][legs[0].aircraft_type_id].icao, ""))
    db.flush()
    return created


def _assign_crew(db: Session, line: str, flights: list[Flight], day: date, crew_pool: dict, fam: str) -> None:
    """Pairing assignment: one cockpit + lead cabin crew per line per day; long-haul
    return sectors get a separate (rested) crew."""
    pool = crew_pool.get(fam)
    if not pool:
        return
    longhaul = fam in ("B787", "A350")
    lines = pool["lines"]
    li = lines.index(line) if line in lines else 0
    n_lines = len(lines)
    groups = [[f] for f in flights] if longhaul else _duty_groups(flights)
    per_line = 2
    for gi, group in enumerate(groups[:per_line]):
        slot = li * per_line + gi
        slots = n_lines * per_line
        stride = 3 if longhaul else 2
        rot = day.toordinal() % stride
        for role in ("CPT", "FO", "SCCM"):
            members = pool[role]
            if not members:
                continue
            cm = members[(slot + rot * slots) % len(members)]
            for f in group:
                db.add(FlightCrewAssignment(flight_id=f.id, crew_id=cm.id, role=role))


MAX_PLANNED_DUTY_H = 12.0


def _duty_groups(flights: list[Flight]) -> list[list[Flight]]:
    """Split a short-haul line into at most two duties, changing crew at the hub
    after a completed out-and-back when one duty would exceed the planning limit."""
    pairs = [flights[i:i + 2] for i in range(0, len(flights), 2)]
    groups: list[list[Flight]] = [[]]
    for p in pairs:
        cand = groups[-1] + p
        duty = (cand[-1].sta_utc - cand[0].std_utc).total_seconds() / 3600 + 1.5
        if groups[-1] and duty > MAX_PLANNED_DUTY_H and len(groups) < 2:
            groups.append(list(p))
        else:
            groups[-1].extend(p)
    return groups


def build_ctx(db: Session) -> dict:
    airports = {a.id: a for a in db.scalars(select(Airport)).all()}
    types = {t.id: t for t in db.scalars(select(AircraftType)).all()}
    from .models import Airline

    airlines = db.scalars(select(Airline)).all()
    hubs = {a.id for a in airports.values() if a.icao in {al.hub_icao for al in airlines}}
    callsign = {al.id: al.icao for al in airlines}

    def min_turn(airport_id: int, atype: AircraftType) -> int:
        ap = airports[airport_id]
        base = atype.min_turnaround_min
        if atype.icao in ("B789", "A359") and airport_id not in hubs:
            base = 100
        return max(base, min(ap.min_turnaround_min, base + 10))

    # alternate: nearest other airport with long enough runways
    alternates: dict[int, int] = {}
    for a in airports.values():
        best = None
        for b in airports.values():
            if b.id == a.id:
                continue
            d = distance_nm(a.lat, a.lon, b.lat, b.lon)
            if d < 40:
                continue
            if best is None or d < best[0]:
                best = (d, b.id)
        if best:
            alternates[a.id] = best[1]

    # crew pools per type family (ordered, deterministic)
    crew_pool: dict[str, dict] = {}
    scheds = db.scalars(select(FlightSchedule).where(FlightSchedule.active.is_(True))).all()
    for s in scheds:
        fam = TYPE_FAMILY.get(types[s.aircraft_type_id].icao, "")
        p = crew_pool.setdefault(fam, {"lines": [], "CPT": [], "FO": [], "SCCM": []})
        if s.rotation_line and s.rotation_line not in p["lines"]:
            p["lines"].append(s.rotation_line)
    for p in crew_pool.values():
        p["lines"].sort()
    for cm in db.scalars(select(CrewMember).where(CrewMember.active.is_(True)).order_by(CrewMember.employee_no)).all():
        for fam in (cm.type_ratings or "").split(","):
            fam = fam.strip()
            if fam in crew_pool and cm.role in crew_pool[fam]:
                crew_pool[fam][cm.role].append(cm)
    return {
        "airports": airports, "types": types, "hubs": hubs, "callsign": callsign, "min_turn": min_turn,
        "alternates": alternates, "crew_pool": crew_pool, "wx": WxCache(airports),
    }


def resimulate_flight(db: Session, f: Flight) -> None:
    """Recompute the simulated outcome after a manual edit (keeps it consistent with
    the new times/route). Previous rotation leg is respected."""
    ctx = build_ctx(db)
    prev = None
    if f.aircraft_id:
        prev = db.scalars(
            select(Flight).where(
                Flight.aircraft_id == f.aircraft_id, Flight.std_utc < f.std_utc, Flight.id != f.id,
                Flight.status != "CANCELLED", Flight.std_utc > f.std_utc - timedelta(hours=20),
            ).order_by(Flight.std_utc.desc())
        ).first()
    atype = ctx["types"][f.aircraft_type_id]
    o, d = ctx["airports"][f.origin_id], ctx["airports"][f.destination_id]
    dist = distance_nm(o.lat, o.lon, d.lat, d.lon)
    airborne = perf.airborne_minutes(dist, atype.cruise_ktas)
    prev_in = (prev.ata_utc or prev.sim_in_utc) if prev else None
    rng = _rng("flight", f.flight_number, f.flight_date.isoformat(), f.std_utc.isoformat())
    keep_cancel = f.status == "CANCELLED"
    simulate_flight_truth(f, ctx["wx"], prev_in, ctx["min_turn"](f.origin_id, atype), ctx["hubs"], airborne, rng, allow_cancel=False)
    f.sim_cancel = keep_cancel


# --------------------------------------------------------------------------- lifecycle


def _mov(db: Session, f: Flight, event: str, t: datetime, airport_id: int | None) -> None:
    db.add(FlightMovement(flight_id=f.id, event=event, time_utc=t, airport_id=airport_id, data_source=f.data_source))


def apply_lifecycle(db: Session, f: Flight, now: datetime, ctx_hours: dict | None = None) -> bool:
    """Advance one flight to the state implied by `now`. Returns True if changed."""
    if f.status in FINAL_STATUSES or f.sim_out_utc is None:
        return False
    before = (f.status, f.atd_utc, f.takeoff_utc, f.landing_utc, f.ata_utc, f.etd_utc)
    if f.sim_cancel:
        if now >= f.std_utc - timedelta(hours=3) and f.status != "CANCELLED":
            f.status = "CANCELLED"
            f.cancel_reason = f.cancel_reason or f.sim_cancel_reason or "Operational"
            f.etd_utc = None
            f.eta_utc = None
            _mov(db, f, "CANCEL", min(now, f.std_utc), f.origin_id)
        return before[0] != f.status
    block = f.sta_utc - f.std_utc
    dep_delay = (f.sim_out_utc - f.std_utc).total_seconds() / 60
    if now < f.sim_out_utc:
        if now >= f.std_utc - timedelta(hours=3) and dep_delay >= 15:
            f.status = "DELAYED"
            f.etd_utc = f.sim_out_utc
            f.eta_utc = f.sim_in_utc
            f.delay_code = f.sim_delay_code
            f.delay_reason = f.sim_delay_reason
        elif now >= max(f.std_utc, f.sim_out_utc) - timedelta(minutes=40):
            f.status = "BOARDING"
            f.etd_utc = f.sim_out_utc
            f.eta_utc = f.sim_in_utc
        else:
            f.etd_utc = f.std_utc if dep_delay < 15 or now < f.std_utc - timedelta(hours=3) else f.sim_out_utc
            f.eta_utc = f.etd_utc + block
        return before != (f.status, f.atd_utc, f.takeoff_utc, f.landing_utc, f.ata_utc, f.etd_utc)
    if f.atd_utc is None:
        f.atd_utc = f.sim_out_utc
        f.etd_utc = f.sim_out_utc
        f.delay_code = f.sim_delay_code
        f.delay_reason = f.sim_delay_reason
        _mov(db, f, "OUT", f.atd_utc, f.origin_id)
    f.status = "DEPARTED"
    f.eta_utc = f.sim_in_utc
    if now >= f.sim_off_utc:
        if f.takeoff_utc is None:
            f.takeoff_utc = f.sim_off_utc
            _mov(db, f, "OFF", f.takeoff_utc, f.origin_id)
        f.status = "AIRBORNE"
    if now >= f.sim_on_utc:
        dest = f.destination_id
        if f.sim_divert and f.alternate_id:
            dest = f.alternate_id
        if f.landing_utc is None:
            f.landing_utc = f.sim_on_utc
            _mov(db, f, "ON", f.landing_utc, dest)
        f.status = "LANDED"
        if f.sim_divert and f.alternate_id:
            f.status = "DIVERTED"
            f.remarks = (f.remarks + " Diverted to alternate due to destination weather.").strip()
            f.ata_utc = f.sim_in_utc
            _mov(db, f, "DIVERT", f.sim_on_utc, dest)
            _credit_hours(db, f)
    if now >= f.sim_in_utc and f.status == "LANDED":
        f.ata_utc = f.sim_in_utc
        f.status = "ARRIVED"
        _mov(db, f, "IN", f.ata_utc, f.destination_id)
        _credit_hours(db, f)
    return before != (f.status, f.atd_utc, f.takeoff_utc, f.landing_utc, f.ata_utc, f.etd_utc)


def _credit_hours(db: Session, f: Flight) -> None:
    if f.aircraft_id and f.takeoff_utc and f.landing_utc:
        ac = db.get(Aircraft, f.aircraft_id)
        if ac:
            h = (f.landing_utc - f.takeoff_utc).total_seconds() / 3600
            ac.total_flight_hours = round(ac.total_flight_hours + h, 2)
            ac.hours_since_check = round(ac.hours_since_check + h, 2)
            ac.total_cycles += 1


def advance(db: Session, now: datetime | None = None) -> int:
    """Advance all open flights whose window overlaps `now`."""
    now = now or utcnow()
    open_flights = db.scalars(
        select(Flight).where(
            Flight.status.notin_(FINAL_STATUSES),
            Flight.std_utc <= now + timedelta(hours=4),
            Flight.data_source.in_(("SIMULATED", "MANUAL")),
        )
    ).all()
    n = 0
    for f in open_flights:
        if apply_lifecycle(db, f, now):
            n += 1
    db.flush()
    return n


def ensure_horizon(db: Session, now: datetime | None = None) -> int:
    """Make sure dated flights exist from today up to the configured horizon."""
    now = now or utcnow()
    ctx = build_ctx(db)
    n = 0
    for k in range(-1, config.settings.future_days + 1):
        n += materialise_day(db, (now + timedelta(days=k)).date(), now, ctx)
    return n


def update_maintenance_status(db: Session, now: datetime | None = None) -> None:
    now = now or utcnow()
    for ac in db.scalars(select(Aircraft)).all():
        active = db.scalars(
            select(MaintenanceRecord).where(
                MaintenanceRecord.aircraft_id == ac.id, MaintenanceRecord.status.in_(("PLANNED", "IN_PROGRESS")),
                MaintenanceRecord.start_utc <= now, MaintenanceRecord.end_utc > now,
                MaintenanceRecord.kind.in_(("C-CHECK", "ENGINE", "DEFECT")),
            )
        ).first()
        if active:
            active.status = "IN_PROGRESS"
            ac.maintenance_status = "IN_CHECK"
            if ac.operational_status == "ACTIVE":
                ac.operational_status = "MAINTENANCE"
        else:
            if ac.operational_status == "MAINTENANCE":
                ac.operational_status = "ACTIVE"
            ratio = ac.hours_since_check / max(1.0, ac.check_interval_hours)
            ac.maintenance_status = "OVERDUE" if ratio >= 1.0 else ("DUE" if ratio >= 0.9 else "SERVICEABLE")
        done = db.scalars(
            select(MaintenanceRecord).where(
                MaintenanceRecord.aircraft_id == ac.id, MaintenanceRecord.status.in_(("PLANNED", "IN_PROGRESS")),
                MaintenanceRecord.end_utc <= now,
            )
        ).all()
        for m in done:
            m.status = "COMPLETED"
            if m.kind in ("A-CHECK", "C-CHECK"):
                ac.hours_since_check = 0.0


def recompute_hours_since_check(db: Session, ac: Aircraft, now: datetime) -> None:
    """hours_since_check = airborne hours flown since the last completed A/C-check."""
    last = db.scalar(
        select(func.max(MaintenanceRecord.end_utc)).where(
            MaintenanceRecord.aircraft_id == ac.id, MaintenanceRecord.kind.in_(("A-CHECK", "C-CHECK")),
            MaintenanceRecord.end_utc <= now,
        )
    )
    q = select(Flight.takeoff_utc, Flight.landing_utc).where(
        Flight.aircraft_id == ac.id, Flight.takeoff_utc.is_not(None), Flight.landing_utc.is_not(None)
    )
    if last is not None:
        q = q.where(Flight.takeoff_utc >= last)
    hours = sum((b - a).total_seconds() / 3600 for a, b in db.execute(q).all())
    if last is None:
        hours += 150.0
    ac.hours_since_check = round(hours, 1)
