"""Browser edition bridge: the unmodified HH-FMS FastAPI application inside Pyodide (CPython on WebAssembly).

The Web Worker (frontend/public/engine/worker.js) writes the prepared demo database to ``db_path``, calls
``boot()`` once, then ``request(method, path, headers_json, body)`` for every API call and ``tick()`` every
20 s (the flight-lifecycle simulation and monitoring that a server runs in a background thread).

Differences from the desktop/server edition, all deliberate:
* no threads: sync endpoints run inline and prediction models train on first use;
* the shipped database is shifted by whole days so its "today" is the visitor's today;
* everything lives in the visitor's tab and is discarded on reload; nothing is sent anywhere.
"""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import date, datetime

_app = None


def _no_threads() -> None:
    import anyio.to_thread

    async def run_sync(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):  # noqa: ARG001
        return func(*args)

    anyio.to_thread.run_sync = run_sync


def shift_to_today(db_path: str) -> int:
    """Move every date/datetime column by N whole days so the demo's anchor day becomes today (UTC).

    Two passes keep unique constraints (e.g. flight number + date) valid while rows move."""
    from . import models  # noqa: F401  (registers tables)
    from .db import Base
    from sqlalchemy import Date, DateTime

    con = sqlite3.connect(db_path)
    row = con.execute("select value from system_config where key = 'demo.anchor_date'").fetchone()
    if not row:
        con.close()
        return 0
    anchor = date.fromisoformat(json.loads(row[0]))
    days = (datetime.utcnow().date() - anchor).days
    if days == 0:
        con.close()
        return 0
    mod = f"{days:+d} days"
    for table in Base.metadata.sorted_tables:
        cols = [c.name for c in table.columns if isinstance(c.type, (DateTime, Date))]
        if not cols:
            continue
        sets1 = ", ".join(f"{c} = 'X' || {c}" for c in cols)
        con.execute(f"update {table.name} set {sets1}")
        sets2 = []
        for c in table.columns:
            if c.name not in cols:
                continue
            if isinstance(c.type, DateTime):
                sets2.append(f"{c.name} = case when {c.name} is null then null else "
                             f"strftime('%Y-%m-%d %H:%M:%S', substr({c.name}, 2, 19), '{mod}') || substr({c.name}, 21) end")
            else:
                sets2.append(f"{c.name} = case when {c.name} is null then null else date(substr({c.name}, 2, 10), '{mod}') end")
        con.execute(f"update {table.name} set {', '.join(sets2)}")
    con.execute("update system_config set value = ? where key = 'demo.anchor_date'",
                (json.dumps(datetime.utcnow().date().isoformat()),))
    con.commit()
    con.close()
    return days


def boot(db_path: str, secret: str) -> dict:
    global _app
    import time

    t = time.time()
    data_dir = os.path.dirname(db_path)
    os.environ.update({
        "FMS_BROWSER": "1", "FMS_BACKGROUND": "0", "FMS_DATA_DIR": data_dir, "FMS_SECRET_KEY": secret,
        "FMS_STATIC_DIR": "/nonexistent", "FMS_PBKDF2_ITER": "2000", "FMS_HISTORY_DAYS": "60",
    })
    _no_threads()
    shifted = shift_to_today(db_path)
    from . import config, jobs
    from .main import create_app

    config.reload_settings()
    info = jobs.startup()
    _app = create_app(run_startup=False)
    return {"ok": True, "boot_s": round(time.time() - t, 2), "shifted_days": shifted,
            "startup": {k: v for k, v in info.items() if k != "seed"}}


def tick() -> str:
    from . import jobs

    jobs.tick()
    return "ok"


async def request(method: str, path: str, headers_json: str = "{}", body: bytes | None = None) -> dict:
    if _app is None:
        raise RuntimeError("call boot() first")
    headers = json.loads(headers_json or "{}")
    p, _, qs = path.partition("?")
    raw_body = bytes(body) if body is not None and type(body).__name__ != "JsNull" else b""
    hdrs = [(k.lower().encode(), str(v).encode()) for k, v in headers.items()]
    hdrs.append((b"host", b"fms.local"))
    if raw_body:
        hdrs.append((b"content-length", str(len(raw_body)).encode()))
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(), "scheme": "http",
             "path": p, "raw_path": p.encode(), "query_string": qs.encode(), "root_path": "", "headers": hdrs,
             "client": ("browser", 0), "server": ("fms.local", 80)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": raw_body, "more_body": False}
        return {"type": "http.disconnect"}

    out = {"status": 500, "headers": [], "body": b""}
    chunks: list[bytes] = []

    async def send(msg):
        if msg["type"] == "http.response.start":
            out["status"] = msg["status"]
            out["headers"] = [[k.decode(), v.decode()] for k, v in msg.get("headers", [])]
        elif msg["type"] == "http.response.body":
            chunks.append(msg.get("body", b""))

    await _app(scope, receive, send)
    out["body"] = b"".join(chunks)
    return out
