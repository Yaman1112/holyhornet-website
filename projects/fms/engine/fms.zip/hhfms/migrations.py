"""Versioned schema migrations.

Each migration is a numbered function applied once and recorded in
``schema_migrations``. Add new migrations at the end of ``MIGRATIONS``; never
edit one that has shipped.
"""
from __future__ import annotations

from typing import Callable

from sqlalchemy import inspect, text
from sqlalchemy.engine import Connection

from .db import Base, get_engine


def _m001_initial(conn: Connection) -> None:
    from . import models  # noqa: F401  (register tables)

    Base.metadata.create_all(conn)


def _m002_analytics_indexes(conn: Connection) -> None:
    stmts = [
        "CREATE INDEX IF NOT EXISTS ix_flights_date_status ON flights (flight_date, status)",
        "CREATE INDEX IF NOT EXISTS ix_flights_origin_std ON flights (origin_id, std_utc)",
        "CREATE INDEX IF NOT EXISTS ix_flights_dest_sta ON flights (destination_id, sta_utc)",
        "CREATE INDEX IF NOT EXISTS ix_wx_airport_time ON weather_records (airport_id, kind, obs_time_utc)",
        "CREATE INDEX IF NOT EXISTS ix_alert_open ON operational_alerts (resolved, created_at)",
    ]
    for s in stmts:
        conn.execute(text(s))


def _m003_audit_entity_index(conn: Connection) -> None:
    conn.execute(text("CREATE INDEX IF NOT EXISTS ix_audit_entity ON audit_logs (entity, entity_id)"))


MIGRATIONS: list[tuple[int, str, Callable[[Connection], None]]] = [
    (1, "initial schema", _m001_initial),
    (2, "analytics indexes", _m002_analytics_indexes),
    (3, "audit entity index", _m003_audit_entity_index),
]


def current_version(conn: Connection) -> int:
    if "schema_migrations" not in inspect(conn).get_table_names():
        return 0
    v = conn.execute(text("SELECT MAX(version) FROM schema_migrations")).scalar()
    return int(v or 0)


def migrate() -> list[int]:
    """Apply all pending migrations; returns the versions applied."""
    applied: list[int] = []
    engine = get_engine()
    with engine.begin() as conn:
        ver = current_version(conn)
        for num, name, fn in MIGRATIONS:
            if num <= ver:
                continue
            fn(conn)
            conn.execute(
                text("INSERT INTO schema_migrations (version, name, applied_at) VALUES (:v, :n, CURRENT_TIMESTAMP)"),
                {"v": num, "n": name},
            )
            applied.append(num)
    return applied
