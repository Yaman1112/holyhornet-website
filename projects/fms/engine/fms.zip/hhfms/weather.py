"""Aviation weather: deterministic simulator, METAR/TAF encoding, METAR decoding,
severity scoring, runway wind analysis and an optional live provider.

The simulator is a pure function of (airport, UTC hour, seed) so history,
"now" and the near-term future are always consistent across restarts.
"""
from __future__ import annotations

import hashlib
import math
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta

from .geo import wind_components

# --------------------------------------------------------------------------- deterministic noise


def _h(*parts) -> int:
    return int.from_bytes(hashlib.blake2b("|".join(map(str, parts)).encode(), digest_size=8).digest(), "big")


def _u(*parts) -> float:
    """Deterministic uniform in [0,1)."""
    return (_h(*parts) % 10_000_000) / 10_000_000.0


def _smooth(key: str, t_h: float, periods=(19.0, 53.0, 131.0)) -> float:
    """Smooth pseudo-random signal in roughly [-1, 1] (sum of seeded sines)."""
    v = 0.0
    for i, p in enumerate(periods):
        ph = _u(key, "ph", i) * 2 * math.pi
        v += math.sin(2 * math.pi * t_h / p + ph) / (i + 1.4)
    return v / 1.3


EPOCH = datetime(2020, 1, 1)


@dataclass
class WxState:
    icao: str
    time_utc: datetime
    wind_dir: int
    wind_speed: int
    wind_gust: int | None
    visibility_m: int
    temperature: int
    dewpoint: int
    qnh: int
    clouds: list[tuple[str, int]] = field(default_factory=list)  # (FEW/SCT/BKN/OVC, base ft)
    phenomena: list[str] = field(default_factory=list)
    cb: bool = False

    @property
    def ceiling_ft(self) -> int | None:
        for cov, base in self.clouds:
            if cov in ("BKN", "OVC"):
                return base
        return None

    @property
    def flight_category(self) -> str:
        return flight_category(self.visibility_m, self.ceiling_ft)

    @property
    def severity(self) -> float:
        return severity_score(self.wind_speed, self.wind_gust, self.visibility_m, self.ceiling_ft, self.phenomena)

    def metar(self) -> str:
        return encode_metar(self)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["time_utc"] = self.time_utc.isoformat()
        d["ceiling_ft"] = self.ceiling_ft
        d["flight_category"] = self.flight_category
        d["severity"] = round(self.severity, 3)
        d["raw"] = self.metar()
        return d


def flight_category(vis_m: int | None, ceiling_ft: int | None) -> str:
    vis_sm = (vis_m or 9999) / 1609.0
    ceil = ceiling_ft if ceiling_ft is not None else 99999
    if ceil < 500 or vis_sm < 1:
        return "LIFR"
    if ceil < 1000 or vis_sm < 3:
        return "IFR"
    if ceil <= 3000 or vis_sm <= 5:
        return "MVFR"
    return "VFR"


def severity_score(wind: int | None, gust: int | None, vis_m: int | None, ceiling_ft: int | None, phen: list[str]) -> float:
    """Operational weather severity 0 (benign) .. 1 (severe)."""
    s = 0.0
    w = max(wind or 0, (gust or 0) * 0.85)
    if w > 15:
        s += min(0.45, (w - 15) / 40)
    v = vis_m if vis_m is not None else 9999
    if v < 5000:
        s += min(0.5, (5000 - v) / 9000)
    if ceiling_ft is not None and ceiling_ft < 1000:
        s += min(0.3, (1000 - ceiling_ft) / 2500)
    ph = " ".join(phen)
    if "TS" in ph:
        s += 0.45
    if "SN" in ph:
        s += 0.35 if "+" in ph or "FZ" in ph else 0.22
    if "FZ" in ph:
        s += 0.3
    if "+RA" in ph or "+SHRA" in ph:
        s += 0.12
    if "FG" in ph:
        s += 0.15
    if "DU" in ph or "SA" in ph:
        s += 0.15
    return round(min(1.0, s), 3)


def _climate(lat: float, elev_ft: int, t: datetime) -> tuple[float, float]:
    """(mean temp for the day, diurnal amplitude) from a crude latitude climatology."""
    t_ann = 27 - 0.6 * (abs(lat) - 25) - elev_ft / 1000 * 2
    amp = 3 + 0.18 * max(0.0, abs(lat) - 20)
    doy = t.timetuple().tm_yday
    season = -math.cos(2 * math.pi * (doy - 20) / 365.25)
    if lat < 0:
        season = -season
    return t_ann + amp * season, 3.0 + 1.5 * (1 if abs(lat) < 35 else 0)


def simulate(icao: str, lat: float, lon: float, elev_ft: int, t: datetime, seed: int = 42) -> WxState:
    """Deterministic simulated weather at the top of the UTC hour containing t."""
    t = t.replace(minute=0, second=0, microsecond=0)
    th = (t - EPOCH).total_seconds() / 3600.0
    key = f"{seed}:{icao}"
    regional = f"{seed}:{round(lat / 6)}:{round(lon / 8)}"  # neighbouring airports share synoptic patterns
    syn = 0.65 * _smooth(regional + "p", th, (61.0, 113.0, 233.0)) + 0.35 * _smooth(key + "p", th)
    month = t.month
    winter = month in (11, 12, 1, 2, 3)
    summer = month in (6, 7, 8)
    desert = abs(lat) < 30

    qnh = int(round(1013 + 17 * syn))
    base_wind = 7 + 9 * max(0.0, -syn) + 4 * (_smooth(key + "w", th) + 1) / 2
    if desert:
        base_wind *= 0.75
    hour_local = (t.hour + lon / 15) % 24
    diurnal = math.sin(2 * math.pi * (hour_local - 9) / 24)
    wind = max(0, int(round(base_wind * (1 + 0.25 * diurnal))))
    prevailing = 240 if not desert else 320
    wdir = int(round((prevailing + 70 * _smooth(regional + "d", th, (37.0, 89.0, 151.0))) / 10.0) * 10) % 360 or 360
    gust = None
    if wind >= 14 and _u(key, "g", int(th)) < 0.65:
        gust = wind + 8 + int(_u(key, "gg", int(th)) * 10)

    tmean, damp = _climate(lat, elev_ft, t)
    temp = int(round(tmean + damp * diurnal + 2 * _smooth(key + "t", th)))
    humid = 0.5 + 0.5 * (_smooth(key + "h", th) + 1) / 2 + (0.15 if syn < -0.3 else 0)
    if desert:
        humid *= 0.6
    spread = max(0, int(round((1 - min(humid, 1.0)) * 12)))
    dew = temp - spread

    phen: list[str] = []
    vis = 9999
    clouds: list[tuple[str, int]] = []
    cb = False
    # cloud cover from synoptic pattern
    cover_idx = max(0.0, min(1.0, 0.45 - 0.55 * syn + 0.2 * _smooth(key + "c", th)))
    if desert:
        cover_idx *= 0.3
    low_base = int(max(200, (1800 + 2800 * (syn + 1) / 2 + 1200 * _smooth(key + "cb", th))) // 100 * 100)
    if cover_idx > 0.75:
        clouds = [("BKN", low_base), ("OVC", low_base + 3000)]
    elif cover_idx > 0.55:
        clouds = [("SCT", low_base), ("BKN", low_base + 2500)]
    elif cover_idx > 0.35:
        clouds = [("FEW", low_base), ("SCT", low_base + 4000)]
    elif cover_idx > 0.2:
        clouds = [("FEW", low_base + 1500)]

    # precipitation
    precip = syn < -0.25 and cover_idx > 0.55 and _smooth(key + "r", th, (7.0, 17.0, 29.0)) > -0.2
    if precip and not desert:
        cold = temp <= 1
        intense = syn < -0.75 and _u(key, "i", int(th)) < 0.5
        if cold:
            phen.append(("+SN" if intense else "-SN") if temp < 0 else "RASN")
            vis = 1200 if intense else 3500
        else:
            convective = summer and diurnal > 0.3 and _u(key, "ts", int(th)) < 0.35
            if convective:
                phen.append("TSRA" if not intense else "+TSRA")
                cb = True
                vis = 3000 if intense else 6000
                gust = max(gust or 0, wind + 15)
            else:
                phen.append("+RA" if intense else ("-RA" if _u(key, "lr", int(th)) < 0.6 else "RA"))
                vis = 4000 if intense else 8000
        if clouds:
            clouds[0] = ("BKN", max(600, low_base - 1000))

    # radiation fog: calm, humid, night/morning, cool season, mid latitudes
    if not desert and winter and wind <= 5 and spread <= 1 and (hour_local < 10 or hour_local > 21):
        if _u(key, "fog", t.date().isoformat()) < 0.45:
            phen = ["FG"]
            vis = int(150 + 650 * _u(key, "fv", int(th)))
            clouds = [("OVC", 100 if vis < 400 else 200)]
            if temp < 0:
                phen = ["FZFG"]
        elif spread <= 1:
            phen.append("BR")
            vis = min(vis, 3000)
    if desert and wind > 14 and _u(key, "du", t.date().isoformat()) < 0.3:
        phen = ["DU"] if wind < 20 else ["SA"]
        vis = 2500 if wind < 20 else 1400
    if desert and not phen and _u(key, "hz", int(th)) < 0.25:
        phen = ["HZ"]
        vis = 6000

    return WxState(icao, t, wdir, wind, gust, vis, temp, dew, qnh, clouds, phen, cb)


# --------------------------------------------------------------------------- METAR / TAF encoding


def _fmt_temp(v: int) -> str:
    return f"M{abs(v):02d}" if v < 0 else f"{v:02d}"


def encode_metar(s: WxState) -> str:
    parts = [s.icao, s.time_utc.strftime("%d%H%MZ")]
    wind = f"{s.wind_dir:03d}{s.wind_speed:02d}" if s.wind_speed >= 3 else "VRB02"
    if s.wind_gust:
        wind += f"G{s.wind_gust:02d}"
    parts.append(wind + "KT")
    parts.append(f"{min(s.visibility_m, 9999):04d}")
    parts.extend(s.phenomena)
    if s.clouds:
        for i, (cov, base) in enumerate(s.clouds):
            parts.append(f"{cov}{base // 100:03d}" + ("CB" if s.cb and i == 0 else ""))
    else:
        parts.append("NSC")
    parts.append(f"{_fmt_temp(s.temperature)}/{_fmt_temp(s.dewpoint)}")
    parts.append(f"Q{s.qnh}")
    parts.append("NOSIG")
    return " ".join(parts)


def _taf_group(s: WxState) -> str:
    wind = f"{s.wind_dir:03d}{s.wind_speed:02d}" + (f"G{s.wind_gust:02d}" if s.wind_gust else "") + "KT"
    cl = " ".join(f"{c}{b // 100:03d}" + ("CB" if s.cb and i == 0 else "") for i, (c, b) in enumerate(s.clouds)) or "NSC"
    return " ".join([wind, f"{min(s.visibility_m, 9999):04d}", *s.phenomena, cl])


def encode_taf(icao: str, lat: float, lon: float, elev: int, issue: datetime, seed: int = 42, hours: int = 30) -> str:
    """Build a TAF from the simulator's future states plus forecast uncertainty."""
    issue = issue.replace(minute=0, second=0, microsecond=0)
    start = issue + timedelta(hours=1)
    end = start + timedelta(hours=hours)
    first = simulate(icao, lat, lon, elev, start, seed)
    lines = [f"TAF {icao} {issue.strftime('%d%H%MZ')} {start.strftime('%d%H')}/{end.strftime('%d%H')} {_taf_group(first)}"]
    prev = first
    for h in range(3, hours, 3):
        t = start + timedelta(hours=h)
        s = simulate(icao, lat, lon, elev, t, seed)
        changed = (
            abs(s.wind_speed - prev.wind_speed) >= 8
            or s.flight_category != prev.flight_category
            or set(s.phenomena) != set(prev.phenomena)
        )
        if changed:
            kind = "TEMPO" if s.phenomena and any(p in " ".join(s.phenomena) for p in ("TS", "SH", "+")) else "BECMG"
            t2 = t + timedelta(hours=2 if kind == "BECMG" else 4)
            lines.append(f"  {kind} {t.strftime('%d%H')}/{t2.strftime('%d%H')} {_taf_group(s)}")
            prev = s
    return "\n".join(lines) + "="


# --------------------------------------------------------------------------- METAR decoding

_RE_WIND = re.compile(r"^(?P<dir>\d{3}|VRB)(?P<spd>\d{2,3})(G(?P<gst>\d{2,3}))?(?P<unit>KT|MPS)$")
_RE_VIS = re.compile(r"^(\d{4})$")
_RE_VIS_SM = re.compile(r"^(?:(\d+)\s)?(\d+)?(?:/(\d+))?SM$")
_RE_CLOUD = re.compile(r"^(FEW|SCT|BKN|OVC|VV)(\d{3})(CB|TCU)?$")
_RE_TEMP = re.compile(r"^(M?\d{2})/(M?\d{2})?$")
_RE_QNH = re.compile(r"^Q(\d{4})$")
_RE_ALT = re.compile(r"^A(\d{4})$")
_RE_WX = re.compile(r"^(-|\+|VC)?(MI|PR|BC|DR|BL|SH|TS|FZ)?((DZ|RA|SN|SG|IC|PL|GR|GS|UP|BR|FG|FU|VA|DU|SA|HZ|PY|PO|SQ|FC|SS|DS)+)$")


def _t(v: str) -> int:
    return -int(v[1:]) if v.startswith("M") else int(v)


def decode_metar(raw: str) -> dict:
    """Decode the common groups of an ICAO/US METAR into structured fields."""
    tokens = raw.replace("=", "").split()
    out: dict = {"raw": raw.strip(), "wind_dir_deg": None, "wind_speed_kt": None, "wind_gust_kt": None,
                 "visibility_m": None, "temperature_c": None, "dewpoint_c": None, "qnh_hpa": None,
                 "clouds": [], "phenomena": [], "station": None, "time": None}
    i = 0
    if tokens and tokens[0] in ("METAR", "SPECI"):
        i = 1
    if i < len(tokens):
        out["station"] = tokens[i]
        i += 1
    for tok in tokens[i:]:
        if tok in ("NOSIG", "BECMG", "TEMPO", "RMK"):
            if tok == "RMK":
                break
            continue
        if re.match(r"^\d{6}Z$", tok):
            out["time"] = tok
            continue
        if tok == "CAVOK":
            out["visibility_m"] = 9999
            continue
        m = _RE_WIND.match(tok)
        if m:
            factor = 1.94384 if m["unit"] == "MPS" else 1
            out["wind_dir_deg"] = None if m["dir"] == "VRB" else int(m["dir"])
            out["wind_speed_kt"] = int(round(int(m["spd"]) * factor))
            out["wind_gust_kt"] = int(round(int(m["gst"]) * factor)) if m["gst"] else None
            continue
        m = _RE_VIS.match(tok)
        if m and out["visibility_m"] is None:
            out["visibility_m"] = int(m[1])
            continue
        m = _RE_VIS_SM.match(tok)
        if m:
            whole = int(m[1]) if m[1] else 0
            if m[3]:
                frac = int(m[2] or 0) / int(m[3])
            else:
                frac = 0
                whole = whole or int(m[2] or 0)
            out["visibility_m"] = min(9999, int(round((whole + frac) * 1609)))
            continue
        m = _RE_CLOUD.match(tok)
        if m:
            out["clouds"].append((m[1], int(m[2]) * 100, m[3] or ""))
            continue
        if tok in ("NSC", "SKC", "CLR", "NCD"):
            continue
        m = _RE_TEMP.match(tok)
        if m:
            out["temperature_c"] = _t(m[1])
            out["dewpoint_c"] = _t(m[2]) if m[2] else None
            continue
        m = _RE_QNH.match(tok)
        if m:
            out["qnh_hpa"] = int(m[1])
            continue
        m = _RE_ALT.match(tok)
        if m:
            out["qnh_hpa"] = int(round(int(m[1]) / 100 * 33.8639))
            continue
        if _RE_WX.match(tok):
            out["phenomena"].append(tok)
    ceiling = None
    for cov, base, _ in out["clouds"]:
        if cov in ("BKN", "OVC", "VV"):
            ceiling = base
            break
    out["ceiling_ft"] = ceiling
    out["flight_category"] = flight_category(out["visibility_m"], ceiling)
    out["severity"] = severity_score(out["wind_speed_kt"], out["wind_gust_kt"], out["visibility_m"], ceiling, out["phenomena"])
    return out


# --------------------------------------------------------------------------- runway & warnings


def runway_analysis(runways: list[dict], wind_dir: int | None, wind_speed: int | None, gust: int | None, max_xwind: float = 30) -> list[dict]:
    """Head/crosswind for each runway end and the preferred landing direction."""
    res = []
    spd = max(wind_speed or 0, gust or 0)
    for rw in runways:
        if rw.get("status") == "CLOSED":
            continue
        ends = rw["designator"].split("/")
        h1 = rw["heading_deg"]
        for idx, end in enumerate(ends):
            hdg = (h1 + 180 * idx) % 360
            if wind_dir is None:
                head, cross = 0.0, 0.0
            else:
                head, cross = wind_components(hdg, wind_dir, spd)
            res.append({
                "runway": end, "heading": round(hdg), "length_m": rw["length_m"],
                "headwind_kt": round(head, 1), "crosswind_kt": round(cross, 1),
                "tailwind": head < -0.5, "exceeds_crosswind": cross > max_xwind,
            })
    res.sort(key=lambda r: (r["exceeds_crosswind"], r["tailwind"], -r["headwind_kt"]))
    if res:
        res[0]["preferred"] = True
    return res


def warnings_for(icao: str, d: dict, max_xwind: float, rwy: list[dict] | None = None) -> list[dict]:
    """Derive operational weather warnings from decoded observation fields."""
    w: list[dict] = []
    ph = " ".join(d.get("phenomena") or [])
    gust = d.get("wind_gust_kt") or 0
    if "TS" in ph:
        w.append({"level": "CRITICAL", "code": "TS", "text": f"{icao}: thunderstorm activity - expect ground stop / holding"})
    if gust >= 35 or (d.get("wind_speed_kt") or 0) >= 28:
        w.append({"level": "WARNING", "code": "WIND", "text": f"{icao}: strong wind {d.get('wind_speed_kt')}G{gust or '--'} kt"})
    vis = d.get("visibility_m") or 9999
    ceil = d.get("ceiling_ft")
    if vis < 550 or (ceil is not None and ceil < 200):
        w.append({"level": "CRITICAL", "code": "LVP", "text": f"{icao}: low visibility procedures (vis {vis} m) - reduced capacity"})
    elif vis < 1500 or (ceil is not None and ceil < 500):
        w.append({"level": "WARNING", "code": "LOWVIS", "text": f"{icao}: low visibility / ceiling (vis {vis} m, ceiling {ceil} ft)"})
    if "SN" in ph or "FZ" in ph:
        w.append({"level": "WARNING", "code": "WINTER", "text": f"{icao}: winter conditions ({ph}) - de-icing expected"})
    if "SA" in ph or "DU" in ph:
        w.append({"level": "WARNING", "code": "DUST", "text": f"{icao}: dust/sand reducing visibility"})
    if rwy and all(r["exceeds_crosswind"] for r in rwy):
        w.append({"level": "CRITICAL", "code": "XWIND", "text": f"{icao}: crosswind exceeds {max_xwind:.0f} kt on all runways"})
    return w


# --------------------------------------------------------------------------- live provider


def fetch_live_metars(icaos: list[str], timeout: float = 6.0) -> dict[str, str]:
    """Fetch latest raw METARs from aviationweather.gov (returns {} when offline)."""
    import httpx

    try:
        r = httpx.get(
            "https://aviationweather.gov/api/data/metar",
            params={"ids": ",".join(icaos), "format": "raw"},
            timeout=timeout,
            headers={"User-Agent": "HH-FMS/1.0"},
        )
        r.raise_for_status()
    except Exception:
        return {}
    out: dict[str, str] = {}
    for line in r.text.splitlines():
        line = line.strip()
        if not line:
            continue
        tok = line.split()
        st = tok[1] if tok[0] in ("METAR", "SPECI") and len(tok) > 1 else tok[0]
        out.setdefault(st, line)
    return out


def fetch_live_tafs(icaos: list[str], timeout: float = 6.0) -> dict[str, str]:
    import httpx

    try:
        r = httpx.get(
            "https://aviationweather.gov/api/data/taf",
            params={"ids": ",".join(icaos), "format": "raw"},
            timeout=timeout,
            headers={"User-Agent": "HH-FMS/1.0"},
        )
        r.raise_for_status()
    except Exception:
        return {}
    out: dict[str, str] = {}
    cur: list[str] = []
    for line in r.text.splitlines():
        if line.startswith("TAF") and cur:
            txt = "\n".join(cur)
            out.setdefault(txt.split()[1] if txt.split()[1] not in ("AMD", "COR") else txt.split()[2], txt)
            cur = []
        if line.strip():
            cur.append(line.rstrip())
    if cur:
        txt = "\n".join(cur)
        parts = txt.split()
        st = parts[2] if parts[1] in ("AMD", "COR") else parts[1]
        out.setdefault(st, txt)
    return out
