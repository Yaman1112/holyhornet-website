"""Dashboard, tracking (REST + WebSocket), history/playback, analytics, alerts,
predictions, scenarios and dispatch."""
from __future__ import annotations

import asyncio
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload

from .. import analytics, dispatch, ml, monitoring, reports, scenarios, serial, tracking
from ..db import SessionLocal, get_db
from ..models import Aircraft, Airport, DispatchRelease, Flight, FlightCrewAssignment, OperationalAlert, User, utcnow
from ..security import audit, current_user, require, user_from_query_token
from .flights import _dt, flight_query, get_flight

router = APIRouter(prefix="/api", tags=["operations"])
ws_router = APIRouter(tags=["websocket"])


def _file(content: bytes, media: str, name: str) -> Response:
    return Response(content, media_type=media, headers={"Content-Disposition": f'attachment; filename="{name}"'})


XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

# --------------------------------------------------------------------------- dashboard


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), _: User = Depends(current_user)):
    d = analytics.dashboard(db)
    d["alerts"] = [serial.alert(a) for a in db.scalars(select(OperationalAlert).where(OperationalAlert.resolved.is_(False))
                                                       .order_by(OperationalAlert.created_at.desc()).limit(12)).all()]
    d["alert_counts"] = dict(db.execute(select(OperationalAlert.severity, func.count()).where(
        OperationalAlert.resolved.is_(False)).group_by(OperationalAlert.severity)).all())
    now = utcnow()
    d["next_departures"] = [serial.flight(f) for f in db.scalars(flight_query().where(
        Flight.std_utc >= now - timedelta(minutes=30), Flight.status.in_(("SCHEDULED", "BOARDING", "DELAYED")))
        .order_by(Flight.std_utc).limit(10)).unique().all()]
    d["airborne"] = [serial.flight(f) for f in db.scalars(flight_query().where(
        Flight.status.in_(("DEPARTED", "AIRBORNE", "LANDED"))).order_by(Flight.eta_utc).limit(40)).unique().all()]
    return d


# --------------------------------------------------------------------------- tracking


@router.get("/tracking/live")
def tracking_live(db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    return {"time": now.isoformat(), "aircraft": tracking.snapshot(db, now, live=True), "data_source": "SIMULATED"}


@router.get("/tracking/at")
def tracking_at(t: str, db: Session = Depends(get_db), _: User = Depends(current_user)):
    ts = _dt(t, utcnow())
    if ts > utcnow():
        raise HTTPException(422, "Historical snapshot must be in the past")
    return {"time": ts.isoformat(), "aircraft": tracking.snapshot(db, ts, live=False), "data_source": "HISTORICAL"}


@router.get("/tracking/airports")
def tracking_airports(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return [{"icao": a.icao, "iata": a.iata, "name": a.name, "lat": a.lat, "lon": a.lon, "status": a.status}
            for a in db.scalars(select(Airport)).all()]


@ws_router.websocket("/ws/tracking")
async def ws_tracking(ws: WebSocket, token: str = Query(...)):
    db = SessionLocal()
    try:
        user_from_query_token(token, db)
    except Exception:
        db.close()
        await ws.close(code=4401)
        return
    db.close()
    await ws.accept()
    try:
        while True:
            def snap():
                s = SessionLocal()
                try:
                    from ..models import SystemConfig

                    cfg = s.get(SystemConfig, "tracking.update_seconds")
                    now = utcnow()
                    return {"type": "snapshot", "time": now.isoformat(), "data_source": "SIMULATED",
                            "aircraft": tracking.snapshot(s, now, live=True)}, float(cfg.value if cfg else 2)
                finally:
                    s.close()

            payload, period = await asyncio.to_thread(snap)
            await ws.send_json(payload)
            await asyncio.sleep(max(1.0, period))
    except (WebSocketDisconnect, RuntimeError):
        return
    except Exception:
        try:
            await ws.close()
        except Exception:
            pass


# --------------------------------------------------------------------------- history


def _history_query(db: Session, date_from, date_to, airport, registration, flight_number, status, data_source):
    now = utcnow()
    d0 = _dt(date_from, now - timedelta(days=7))
    d1 = _dt(date_to, now)
    q = flight_query().where(Flight.std_utc >= d0, Flight.std_utc < d1, Flight.std_utc <= now)
    if airport:
        ap = db.scalars(select(Airport.id).where(Airport.icao == airport.upper())).first()
        q = q.where(or_(Flight.origin_id == ap, Flight.destination_id == ap))
    if registration:
        q = q.join(Aircraft, Flight.aircraft_id == Aircraft.id).where(Aircraft.registration == registration.upper())
    if flight_number:
        q = q.where(Flight.flight_number.like(f"%{flight_number.upper().replace(' ', '')}%"))
    if status:
        q = q.where(Flight.status.in_([s.upper() for s in status.split(",")]))
    if data_source:
        q = q.where(Flight.data_source == data_source.upper())
    return d0, d1, q


def _hist_row(f: Flight) -> dict:
    d = serial.flight(f)
    d["planned_block_min"] = d["block_min"]
    d["actual_block_min"] = round((f.ata_utc - f.atd_utc).total_seconds() / 60) if f.ata_utc and f.atd_utc else None
    d["airborne_min"] = round((f.landing_utc - f.takeoff_utc).total_seconds() / 60) if f.landing_utc and f.takeoff_utc else None
    d["taxi_out_min"] = round((f.takeoff_utc - f.atd_utc).total_seconds() / 60) if f.takeoff_utc and f.atd_utc else None
    d["taxi_in_min"] = round((f.ata_utc - f.landing_utc).total_seconds() / 60) if f.ata_utc and f.landing_utc else None
    return d


@router.get("/history/flights")
def history_flights(date_from: str | None = None, date_to: str | None = None, airport: str | None = None,
                    registration: str | None = None, flight_number: str | None = None, status: str | None = None,
                    data_source: str | None = None, page: int = Query(1, ge=1), size: int = Query(200, ge=1, le=2000),
                    db: Session = Depends(get_db), _: User = Depends(current_user)):
    d0, d1, q = _history_query(db, date_from, date_to, airport, registration, flight_number, status, data_source)
    total = db.scalar(select(func.count()).select_from(q.with_only_columns(Flight.id).subquery()))
    rows = db.scalars(q.order_by(Flight.std_utc.desc()).offset((page - 1) * size).limit(size)).unique().all()
    items = [_hist_row(f) for f in rows]
    allrows = db.scalars(q).unique().all()
    dep = [f for f in allrows if f.atd_utc]
    arr = [f for f in allrows if f.ata_utc and f.status == "ARRIVED"]
    thr = analytics.otp_threshold(db)

    def avg(xs):
        return round(sum(xs) / len(xs), 1) if xs else None

    comp = {
        "flights": total,
        "avg_dep_delay": avg([max(0, (f.atd_utc - f.std_utc).total_seconds() / 60) for f in dep]),
        "avg_arr_delay": avg([max(0, (f.ata_utc - f.sta_utc).total_seconds() / 60) for f in arr]),
        "avg_planned_block": avg([(f.sta_utc - f.std_utc).total_seconds() / 60 for f in arr]),
        "avg_actual_block": avg([(f.ata_utc - f.atd_utc).total_seconds() / 60 for f in arr if f.atd_utc]),
        "otp_departure": round(sum(1 for f in dep if (f.atd_utc - f.std_utc).total_seconds() / 60 <= thr) / len(dep) * 100, 1) if dep else None,
        "otp_arrival": round(sum(1 for f in arr if (f.ata_utc - f.sta_utc).total_seconds() / 60 <= thr) / len(arr) * 100, 1) if arr else None,
        "cancelled": sum(1 for f in allrows if f.status == "CANCELLED"),
    }
    return {"total": total, "items": items, "page": page, "size": size, "comparison": comp,
            "range": [d0.isoformat(), d1.isoformat()]}


@router.get("/history/export")
def history_export(format: str = "xlsx", date_from: str | None = None, date_to: str | None = None, airport: str | None = None,
                   registration: str | None = None, flight_number: str | None = None, status: str | None = None,
                   data_source: str | None = None, request: Request = None, db: Session = Depends(get_db),
                   user: User = Depends(require("data.export"))):
    d0, d1, q = _history_query(db, date_from, date_to, airport, registration, flight_number, status, data_source)
    rows = [_hist_row(f) for f in db.scalars(q.order_by(Flight.std_utc).limit(50000)).unique().all()]
    cols = ["flight_number", "flight_date", "origin", "destination", "registration", "aircraft_type", "std_utc", "atd_utc",
            "sta_utc", "ata_utc", "dep_delay_min", "arr_delay_min", "planned_block_min", "actual_block_min", "status",
            "delay_code", "delay_reason", "pax_booked", "data_source"]
    slim = [{c: r.get(c) for c in cols} for r in rows]
    audit(db, user, "EXPORT", "history", None, {"format": format, "rows": len(rows)}, request)
    db.commit()
    stamp = f"{d0:%Y%m%d}-{d1:%Y%m%d}"
    if format == "csv":
        return _file(reports.to_csv(slim), "text/csv", f"flight_history_{stamp}.csv")
    if format == "pdf":
        df = analytics.flights_df(db, d0, d1, airport=airport.upper() if airport else None,
                                  aircraft=registration.upper() if registration else None)
        k = analytics.kpis(df, analytics.otp_threshold(db))
        pdf = reports.pdf_report("Historical Flight Report", f"{d0:%d %b %Y} - {d1:%d %b %Y} UTC", [
            {"heading": "Summary", "kv": [("Flights", k["total"]), ("Completed", k["completed"]), ("Cancelled", k["cancelled"]),
                                          ("OTP departure", f"{k['otp_departure']}%"), ("OTP arrival", f"{k['otp_arrival']}%"),
                                          ("Avg dep delay", f"{k['avg_departure_delay']} min")]},
            {"heading": "Flights (planned vs actual)", "table": [
                {"flt": r["flight_number"], "date": r["flight_date"], "route": f"{r['origin']}-{r['destination']}",
                 "reg": r["registration"], "std": (r["std_utc"] or "")[11:16], "atd": (r["atd_utc"] or "")[11:16],
                 "sta": (r["sta_utc"] or "")[11:16], "ata": (r["ata_utc"] or "")[11:16], "dly": r["dep_delay_min"],
                 "status": r["status"]} for r in rows],
             "columns": ["flt", "date", "route", "reg", "std", "atd", "sta", "ata", "dly", "status"],
             "widths": [16, 20, 26, 18, 14, 14, 14, 14, 12, 22]},
        ], banner="Data source: simulated demo operations unless imported. Times UTC.")
        return _file(pdf, "application/pdf", f"flight_history_{stamp}.pdf")
    return _file(reports.to_excel({"history": slim}), XLSX, f"flight_history_{stamp}.xlsx")


@router.get("/history/playback")
def history_playback(start: str, end: str, step: int = Query(60, ge=15, le=600), db: Session = Depends(get_db),
                     _: User = Depends(current_user)):
    t0, t1 = _dt(start, utcnow()), _dt(end, utcnow())
    if t1 <= t0 or (t1 - t0) > timedelta(hours=24):
        raise HTTPException(422, "Window must be between 0 and 24 hours")
    return tracking.playback(db, t0, t1, step)


# --------------------------------------------------------------------------- analytics


def _range(start, end, default_days=30):
    now = utcnow()
    e = _dt(end, now)
    s = _dt(start, e - timedelta(days=default_days))
    if e <= s:
        raise HTTPException(422, "end must be after start")
    if (e - s) > timedelta(days=400):
        raise HTTPException(422, "Range limited to 400 days")
    return s, e


@router.get("/analytics/summary")
def analytics_summary(start: str | None = None, end: str | None = None, airport: str | None = None, registration: str | None = None,
                      route: str | None = None, airline_id: int | None = None, db: Session = Depends(get_db),
                      _: User = Depends(current_user)):
    s, e = _range(start, end)
    res = analytics.summary(db, s, e, airport=airport.upper() if airport else None,
                            aircraft=registration.upper() if registration else None, route=route.upper() if route else None,
                            airline_id=airline_id)
    res["utilisation"] = analytics.aircraft_utilisation(db, s, min(e, utcnow()))
    return res


@router.get("/analytics/export")
def analytics_export(format: str = "xlsx", start: str | None = None, end: str | None = None, airport: str | None = None,
                     registration: str | None = None, route: str | None = None, request: Request = None,
                     db: Session = Depends(get_db), user: User = Depends(require("data.export"))):
    s, e = _range(start, end)
    res = analytics.summary(db, s, e, airport=airport.upper() if airport else None,
                            aircraft=registration.upper() if registration else None, route=route.upper() if route else None)
    util = analytics.aircraft_utilisation(db, s, min(e, utcnow()))
    k = res["kpis"]
    audit(db, user, "EXPORT", "analytics", None, {"format": format}, request)
    db.commit()
    stamp = f"{s:%Y%m%d}-{e:%Y%m%d}"
    if format == "csv":
        return _file(reports.to_csv(res["daily"]), "text/csv", f"analytics_daily_{stamp}.csv")
    if format == "pdf":
        filt = ", ".join(x for x in [airport and f"airport {airport}", registration and f"aircraft {registration}", route and f"route {route}"] if x) or "all operations"
        pdf = reports.pdf_report("Flight Operations Analytics", f"{s:%d %b %Y} - {e:%d %b %Y} UTC  |  {filt}", [
            {"heading": "Key performance indicators", "kv": [
                ("Flights", k["total"]), ("Completed", k["completed"]), ("Cancelled", k["cancelled"]),
                ("On-time departure", f"{k['otp_departure']}%"), ("On-time arrival", f"{k['otp_arrival']}%"),
                ("Completion rate", f"{k['completion_rate']}%"), ("Cancellation rate", f"{k['cancellation_rate']}%"),
                ("Avg departure delay", f"{k['avg_departure_delay']} min"), ("Avg arrival delay", f"{k['avg_arrival_delay']} min"),
                ("Avg block time", f"{k['avg_block_min']} min"), ("Passengers", f"{k['pax']:,}"), ("OTP threshold", f"{res['threshold_min']} min")]},
            {"heading": "Weekly trend", "table": res["weekly"], "columns": ["period", "flights", "cancelled", "otp_departure", "otp_arrival", "avg_departure_delay", "avg_arrival_delay"]},
            {"heading": "Delay causes", "table": res["delay_causes"], "columns": ["code", "cause", "flights", "delay_minutes"]},
            {"heading": "Route performance", "table": res["routes"][:40], "columns": ["route", "flights", "cancelled", "otp_departure", "otp_arrival", "avg_departure_delay", "avg_actual_block"]},
            {"heading": "Airport traffic", "table": res["airports"], "columns": ["airport", "departures", "arrivals", "movements", "avg_departure_delay"]},
            {"heading": "Aircraft utilisation", "table": util, "columns": ["registration", "type", "flights", "block_hours", "block_hours_per_day", "utilisation_pct", "maintenance_status"]},
        ], banner="Analytics computed from the FMS database. Demo installations contain simulated operations data.")
        return _file(pdf, "application/pdf", f"analytics_{stamp}.pdf")
    return _file(reports.to_excel({"kpis": [k], "daily": res["daily"], "weekly": res["weekly"], "monthly": res["monthly"],
                                   "routes": res["routes"], "airports": res["airports"], "delay_causes": res["delay_causes"],
                                   "utilisation": util}), XLSX, f"analytics_{stamp}.xlsx")


# --------------------------------------------------------------------------- alerts / monitoring


@router.get("/alerts")
def list_alerts(open_only: bool = True, category: str | None = None, limit: int = Query(300, le=2000),
                db: Session = Depends(get_db), _: User = Depends(current_user)):
    q = select(OperationalAlert).order_by(OperationalAlert.created_at.desc()).limit(limit)
    if open_only:
        q = q.where(OperationalAlert.resolved.is_(False))
    if category:
        q = q.where(OperationalAlert.category == category.upper())
    return [serial.alert(a) for a in db.scalars(q).all()]


@router.post("/alerts/run")
def run_monitoring(request: Request, db: Session = Depends(get_db), user: User = Depends(require("alerts.ack"))):
    res = monitoring.run(db)
    db.commit()
    return res


@router.post("/alerts/{aid}/ack")
def ack_alert(aid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require("alerts.ack"))):
    a = db.get(OperationalAlert, aid)
    if not a:
        raise HTTPException(404, "Alert not found")
    a.acknowledged = True
    a.acknowledged_by = user.username
    audit(db, user, "ACK", "alert", aid, None, request)
    db.commit()
    return serial.alert(a)


@router.post("/alerts/{aid}/resolve")
def resolve_alert(aid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require("alerts.ack"))):
    a = db.get(OperationalAlert, aid)
    if not a:
        raise HTTPException(404, "Alert not found")
    a.resolved = True
    a.acknowledged = True
    a.acknowledged_by = a.acknowledged_by or user.username
    audit(db, user, "RESOLVE", "alert", aid, None, request)
    db.commit()
    return serial.alert(a)


# --------------------------------------------------------------------------- predictions


@router.get("/predictions/status")
def prediction_status(_: User = Depends(current_user)):
    return ml.status()


@router.post("/predictions/train")
def prediction_train(request: Request, db: Session = Depends(get_db), user: User = Depends(require("ml.train"))):
    try:
        res = ml.train(db)
    except ValueError as e:
        raise HTTPException(422, str(e))
    audit(db, user, "TRAIN", "ml", None, {"n_samples": res["n_samples"]}, request)
    db.commit()
    return res


def _need_model():
    from .. import config
    from ..db import session_scope

    if not ml.load() and config.settings.browser:
        with session_scope() as s:   # browser edition: no background thread, train on first use
            ml.train(s)
    if not ml.load():
        raise HTTPException(409, "Prediction models are not trained yet (they train automatically after first start, or use Train now)")


@router.get("/predictions/flight/{fid}")
def prediction_flight(fid: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    _need_model()
    res = ml.predict_flights(db, [fid], explain=True)
    if not res:
        raise HTTPException(404, "Flight not found")
    return {**res[0], "model": ml.status()}


@router.get("/predictions/upcoming")
def prediction_upcoming(hours: int = Query(24, ge=1, le=72), db: Session = Depends(get_db), _: User = Depends(current_user)):
    _need_model()
    return {"items": ml.predict_upcoming(db, hours), "model": ml.status()}


@router.get("/predictions/demand")
def prediction_demand(airport: str = "EHAM", day: str | None = None, db: Session = Depends(get_db), _: User = Depends(current_user)):
    _need_model()
    d = datetime.combine(date.fromisoformat(day), datetime.min.time()) if day else utcnow()
    try:
        return ml.predict_demand(db, airport.upper(), d)
    except ValueError as e:
        raise HTTPException(404, str(e))


# --------------------------------------------------------------------------- scenarios


class ScenarioIn(BaseModel):
    name: str = "Scenario"
    day: date | None = None
    traffic_increase_pct: float = Field(0, ge=-50, le=200)
    traffic_airports: list[str] = []
    weather: list[dict] = []
    runway_closures: list[dict] = []
    aircraft_unavailable: list[dict] = []
    cancel_flights: list[str] = []
    delayed_rotations: list[dict] = []


@router.post("/scenarios/simulate")
def scenario_simulate(body: ScenarioIn, db: Session = Depends(get_db), user: User = Depends(require("scenarios.run"))):
    try:
        return scenarios.simulate(db, body.model_dump(mode="json"))
    except ValueError as e:
        raise HTTPException(422, str(e))


@router.get("/scenarios/presets")
def scenario_presets(_: User = Depends(current_user)):
    return [
        {"name": "Thunderstorms at Amsterdam (afternoon)", "weather": [{"airport": "EHAM", "start_hour": 13, "end_hour": 18, "severity": "SEVERE"}]},
        {"name": "Fog / LVP at Amsterdam (morning)", "weather": [{"airport": "EHAM", "start_hour": 5, "end_hour": 10, "severity": "SEVERE"}]},
        {"name": "Main runway closed at Heathrow", "runway_closures": [{"airport": "EGLL", "runway": "09L/27R", "start_hour": 6, "end_hour": 22}]},
        {"name": "Oslo airport closed 2 h (snow)", "runway_closures": [{"airport": "ENGM", "runway": "ALL", "start_hour": 7, "end_hour": 9}]},
        {"name": "+25% traffic at hub", "traffic_increase_pct": 25, "traffic_airports": ["EHAM"]},
        {"name": "A320neo AOG at 06:00", "aircraft_unavailable": [{"registration": "PH-HNA", "from_hour": 6}]},
        {"name": "Late first wave (90 min rotation delay)", "delayed_rotations": [{"registration": "PH-HNB", "delay_min": 90}, {"registration": "PH-HXA", "delay_min": 90}]},
    ]


# --------------------------------------------------------------------------- dispatch


@router.get("/dispatch/board")
def dispatch_board(hours: int = Query(24, ge=1, le=72), db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    fl = db.scalars(flight_query().where(Flight.std_utc >= now - timedelta(hours=2), Flight.std_utc <= now + timedelta(hours=hours))
                    .order_by(Flight.std_utc)).unique().all()
    rel = {r.flight_id: r for r in db.scalars(select(DispatchRelease).where(DispatchRelease.flight_id.in_([f.id for f in fl]))).all()}
    out = []
    for f in fl:
        d = serial.flight(f)
        r = rel.get(f.id)
        d["dispatch_status"] = r.status if r else "DRAFT"
        d["released_by"] = r.released_by if r else None
        d["block_fuel_kg"] = r.block_fuel_kg if r else None
        out.append(d)
    counts: dict[str, int] = {}
    for d in out:
        counts[d["dispatch_status"]] = counts.get(d["dispatch_status"], 0) + 1
    return {"items": out, "counts": counts, "disclaimer": dispatch.DISCLAIMER}


def _flight_for_dispatch(db: Session, fid: int) -> Flight:
    return get_flight(db, fid, crew=True)


@router.get("/dispatch/{fid}")
def dispatch_get(fid: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    f = _flight_for_dispatch(db, fid)
    rel = db.scalars(select(DispatchRelease).where(DispatchRelease.flight_id == fid)).first()
    plan = dispatch.build_plan(db, f, extra_fuel_kg=rel.extra_fuel_kg if rel else 0.0,
                               alternate_icao=rel.alternate_icao if rel else None, cruise_fl=rel.cruise_fl if rel else None)
    return {"plan": plan, "release": dispatch.release_dict(rel) if rel else {"status": "DRAFT", "history": []},
            "transitions": sorted(dispatch.TRANSITIONS.get(rel.status if rel else "DRAFT", []))}


class PlanIn(BaseModel):
    extra_fuel_kg: float = Field(0, ge=0, le=50000)
    alternate_icao: str | None = None
    cruise_fl: int | None = Field(None, ge=50, le=450)
    remarks: str | None = None


@router.post("/dispatch/{fid}/plan")
def dispatch_plan(fid: int, body: PlanIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("dispatch.write"))):
    f = _flight_for_dispatch(db, fid)
    if f.status in ("ARRIVED", "CANCELLED", "DIVERTED"):
        raise HTTPException(409, f"Flight is {f.status}")
    rel = dispatch.get_or_create_release(db, f)
    if rel.status == "RELEASED":
        raise HTTPException(409, "Flight is released - revoke (move to PLANNED) before re-planning")
    plan = dispatch.build_plan(db, f, extra_fuel_kg=body.extra_fuel_kg, alternate_icao=body.alternate_icao, cruise_fl=body.cruise_fl)
    dispatch.apply_plan(rel, plan, user.username)
    rel.extra_fuel_kg = body.extra_fuel_kg
    if body.remarks is not None:
        rel.remarks = body.remarks
    if rel.status in ("DRAFT", "HOLD"):
        dispatch.transition(rel, "PLANNED", user.username, "Plan computed")
    if body.cruise_fl:
        f.cruise_fl = body.cruise_fl
    audit(db, user, "PLAN", "dispatch", fid, {"block_fuel_kg": rel.block_fuel_kg, "alternate": rel.alternate_icao}, request)
    db.commit()
    return {"plan": plan, "release": dispatch.release_dict(rel), "transitions": sorted(dispatch.TRANSITIONS[rel.status])}


class TransitionIn(BaseModel):
    to: str
    note: str = ""
    override: bool = False


@router.post("/dispatch/{fid}/transition")
def dispatch_transition(fid: int, body: TransitionIn, request: Request, db: Session = Depends(get_db),
                        user: User = Depends(require("dispatch.write"))):
    to = body.to.upper()
    if to == "RELEASED" or (to == "PLANNED" and db.scalars(select(DispatchRelease).where(
            DispatchRelease.flight_id == fid, DispatchRelease.status == "RELEASED")).first()):
        from ..security import PERMISSIONS

        if user.role not in PERMISSIONS["dispatch.release"]:
            raise HTTPException(403, "Only a Dispatcher or Administrator may release or revoke a release")
    f = _flight_for_dispatch(db, fid)
    rel = dispatch.get_or_create_release(db, f)
    plan = dispatch.build_plan(db, f, extra_fuel_kg=rel.extra_fuel_kg, alternate_icao=rel.alternate_icao, cruise_fl=rel.cruise_fl)
    try:
        dispatch.transition(rel, to, user.username, body.note, body.override, plan)
    except ValueError as e:
        raise HTTPException(409, str(e))
    audit(db, user, "TRANSITION", "dispatch", fid, {"to": to, "override": body.override, "note": body.note}, request)
    db.commit()
    return {"release": dispatch.release_dict(rel), "transitions": sorted(dispatch.TRANSITIONS[rel.status])}


@router.get("/dispatch/{fid}/briefing.pdf")
def dispatch_briefing(fid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    f = _flight_for_dispatch(db, fid)
    rel = db.scalars(select(DispatchRelease).where(DispatchRelease.flight_id == fid)).first()
    plan = dispatch.build_plan(db, f, extra_fuel_kg=rel.extra_fuel_kg if rel else 0.0,
                               alternate_icao=rel.alternate_icao if rel else None, cruise_fl=rel.cruise_fl if rel else None)
    pdf = reports.briefing_pdf(plan, dispatch.release_dict(rel) if rel else None)
    audit(db, user, "BRIEFING", "dispatch", fid, None, request)
    db.commit()
    return _file(pdf, "application/pdf", f"briefing_{f.flight_number}_{f.flight_date}.pdf")
