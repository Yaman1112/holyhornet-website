"""Flights, scheduling, planning, crew assignment and conflicts."""
from __future__ import annotations

from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload, selectinload

from .. import conflicts, ops, perf, serial, tracking
from ..db import get_db
from ..geo import distance_nm
from ..models import (
    FLIGHT_STATUSES,
    Aircraft,
    AircraftType,
    Airline,
    Airport,
    CrewMember,
    Flight,
    FlightCrewAssignment,
    FlightMovement,
    FlightSchedule,
    Route,
    User,
    utcnow,
)
from ..refdata import TYPE_FAMILY
from ..security import audit, current_user, require

router = APIRouter(prefix="/api", tags=["flights"])


def flight_query():
    return select(Flight).options(
        joinedload(Flight.origin), joinedload(Flight.destination), joinedload(Flight.alternate),
        joinedload(Flight.aircraft), joinedload(Flight.aircraft_type), joinedload(Flight.airline),
    )


def get_flight(db: Session, fid: int, crew: bool = False) -> Flight:
    q = flight_query().where(Flight.id == fid)
    if crew:
        q = q.options(selectinload(Flight.crew).joinedload(FlightCrewAssignment.crew_member))
    f = db.scalars(q).unique().first()
    if not f:
        raise HTTPException(404, "Flight not found")
    return f


def _dt(s: str | None, default: datetime) -> datetime:
    if not s:
        return default
    try:
        v = datetime.fromisoformat(s.replace("Z", ""))
    except ValueError:
        raise HTTPException(422, f"Invalid datetime {s}")
    return v.replace(tzinfo=None)


@router.get("/flights")
def list_flights(
    date_from: str | None = None, date_to: str | None = None, status: str | None = None, airport: str | None = None,
    registration: str | None = None, airline: str | None = None, q: str | None = None, data_source: str | None = None,
    sort: str = "std_utc", order: str = "asc", page: int = Query(1, ge=1), size: int = Query(100, ge=1, le=2000),
    db: Session = Depends(get_db), _: User = Depends(current_user),
):
    now = utcnow()
    d0 = _dt(date_from, datetime.combine(now.date(), datetime.min.time()))
    d1 = _dt(date_to, d0 + timedelta(days=1))
    if d1 <= d0:
        d1 = d0 + timedelta(days=1)
    qry = flight_query().where(Flight.std_utc >= d0, Flight.std_utc < d1)
    if status:
        sts = [s.strip().upper() for s in status.split(",") if s.strip()]
        qry = qry.where(Flight.status.in_(sts))
    if airport:
        ap = db.scalars(select(Airport.id).where(or_(Airport.icao == airport.upper(), Airport.iata == airport.upper()))).first()
        if ap is None:
            return {"total": 0, "items": [], "page": page, "size": size}
        qry = qry.where(or_(Flight.origin_id == ap, Flight.destination_id == ap))
    if registration:
        qry = qry.join(Aircraft, Flight.aircraft_id == Aircraft.id).where(Aircraft.registration == registration.upper())
    if airline:
        qry = qry.join(Airline, Flight.airline_id == Airline.id).where(Airline.icao == airline.upper())
    if q:
        like = f"%{q.upper().replace(' ', '')}%"
        qry = qry.where(or_(Flight.flight_number.like(like), Flight.callsign.like(like)))
    if data_source:
        qry = qry.where(Flight.data_source == data_source.upper())
    total = db.scalar(select(func.count()).select_from(qry.with_only_columns(Flight.id).subquery()))
    col = {"std_utc": Flight.std_utc, "flight_number": Flight.flight_number, "status": Flight.status,
           "sta_utc": Flight.sta_utc}.get(sort, Flight.std_utc)
    qry = qry.order_by(col.desc() if order == "desc" else col.asc(), Flight.id).offset((page - 1) * size).limit(size)
    items = [serial.flight(f) for f in db.scalars(qry).unique().all()]
    return {"total": total, "items": items, "page": page, "size": size, "range": [d0.isoformat(), d1.isoformat()]}


@router.get("/flights/estimate")
def estimate(origin: str, destination: str, aircraft_type: str, std_utc: str | None = None,
             db: Session = Depends(get_db), _: User = Depends(current_user)):
    o = db.scalars(select(Airport).where(Airport.icao == origin.upper())).first()
    d = db.scalars(select(Airport).where(Airport.icao == destination.upper())).first()
    t = db.scalars(select(AircraftType).where(AircraftType.icao == aircraft_type.upper())).first()
    if not (o and d and t):
        raise HTTPException(404, "Unknown airport or aircraft type")
    dist = distance_nm(o.lat, o.lon, d.lat, d.lon)
    block = perf.scheduled_block_minutes(dist, t.cruise_ktas)
    res = {"distance_nm": round(dist), "airborne_min": round(perf.airborne_minutes(dist, t.cruise_ktas)),
           "block_min": block, "within_range": perf.range_ok(dist, t.range_km), "range_km": t.range_km}
    if std_utc:
        std = _dt(std_utc, utcnow())
        res["sta_utc"] = (std + timedelta(minutes=block)).isoformat()
    return res


@router.get("/flights/{fid}")
def flight_detail(fid: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    f = get_flight(db, fid, crew=True)
    d = serial.flight(f, full=True)
    d["movements"] = [{"event": m.event, "time_utc": m.time_utc.isoformat(), "airport_id": m.airport_id,
                       "data_source": m.data_source} for m in db.scalars(
        select(FlightMovement).where(FlightMovement.flight_id == fid).order_by(FlightMovement.time_utc)).all()]
    d["conflicts"] = conflicts.detect_conflicts(db, f.std_utc - timedelta(hours=1), f.std_utc + timedelta(hours=1), {f.id})
    rot = []
    if f.aircraft_id:
        rot = db.scalars(flight_query().where(
            Flight.aircraft_id == f.aircraft_id, Flight.std_utc >= f.std_utc - timedelta(hours=18),
            Flight.std_utc <= f.std_utc + timedelta(hours=18)).order_by(Flight.std_utc)).unique().all()
    d["rotation"] = [serial.flight(x) for x in rot]
    from ..models import DispatchRelease

    rel = db.scalars(select(DispatchRelease).where(DispatchRelease.flight_id == fid)).first()
    d["dispatch_status"] = rel.status if rel else "DRAFT"
    d["position"] = tracking.position(f, utcnow()) if f.status in ("DEPARTED", "AIRBORNE") else None
    return d


class FlightIn(BaseModel):
    flight_number: str = Field(min_length=3, max_length=8)
    airline_id: int
    origin: str = Field(min_length=4, max_length=4)
    destination: str = Field(min_length=4, max_length=4)
    std_utc: datetime
    sta_utc: datetime | None = None
    aircraft_type: str
    registration: str | None = None
    pax_booked: int = Field(0, ge=0, le=900)
    cruise_fl: int | None = Field(None, ge=50, le=450)
    remarks: str = ""
    flight_date: date | None = None

    @field_validator("flight_number", "origin", "destination", "aircraft_type")
    @classmethod
    def up(cls, v):
        return v.upper().replace(" ", "")

    @field_validator("std_utc", "sta_utc")
    @classmethod
    def naive(cls, v):
        return v.replace(tzinfo=None, second=0, microsecond=0) if v else v


class FlightPatch(BaseModel):
    std_utc: datetime | None = None
    sta_utc: datetime | None = None
    origin: str | None = None
    destination: str | None = None
    aircraft_type: str | None = None
    registration: str | None = None
    pax_booked: int | None = Field(None, ge=0, le=900)
    cruise_fl: int | None = Field(None, ge=50, le=450)
    remarks: str | None = None
    etd_utc: datetime | None = None

    @field_validator("std_utc", "sta_utc", "etd_utc")
    @classmethod
    def naive(cls, v):
        return v.replace(tzinfo=None, second=0, microsecond=0) if v else v


def _resolve(db: Session, icao: str) -> Airport:
    a = db.scalars(select(Airport).where(Airport.icao == icao.upper())).first()
    if not a:
        raise HTTPException(422, f"Unknown airport {icao}")
    return a


def _resolve_type(db: Session, icao: str) -> AircraftType:
    t = db.scalars(select(AircraftType).where(AircraftType.icao == icao.upper())).first()
    if not t:
        raise HTTPException(422, f"Unknown aircraft type {icao}")
    return t


def _resolve_ac(db: Session, reg: str | None) -> Aircraft | None:
    if not reg:
        return None
    a = db.scalars(select(Aircraft).where(Aircraft.registration == reg.upper())).first()
    if not a:
        raise HTTPException(422, f"Unknown registration {reg}")
    return a


@router.post("/flights", status_code=201)
def create_flight(body: FlightIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("flights.write"))):
    al = db.get(Airline, body.airline_id)
    if not al:
        raise HTTPException(422, "Unknown airline")
    o, d = _resolve(db, body.origin), _resolve(db, body.destination)
    if o.id == d.id:
        raise HTTPException(422, "Origin and destination must differ")
    t = _resolve_type(db, body.aircraft_type)
    ac = _resolve_ac(db, body.registration)
    dist = distance_nm(o.lat, o.lon, d.lat, d.lon)
    sta = body.sta_utc or body.std_utc + timedelta(minutes=perf.scheduled_block_minutes(dist, t.cruise_ktas))
    if sta <= body.std_utc:
        raise HTTPException(422, "STA must be after STD")
    if (sta - body.std_utc) > timedelta(hours=20):
        raise HTTPException(422, "Block time exceeds 20 hours")
    fdate = body.flight_date or body.std_utc.date()
    if db.scalars(select(Flight).where(Flight.flight_number == body.flight_number, Flight.flight_date == fdate)).first():
        raise HTTPException(409, f"{body.flight_number} already exists on {fdate}")
    num = body.flight_number[len(al.iata or ""):] if body.flight_number.startswith(al.iata or "#") else body.flight_number
    f = Flight(
        airline_id=al.id, flight_number=body.flight_number, callsign=f"{al.icao}{num}", flight_date=fdate,
        origin_id=o.id, destination_id=d.id, aircraft_type_id=t.id, aircraft_id=ac.id if ac else None,
        std_utc=body.std_utc, sta_utc=sta, pax_booked=body.pax_booked, cabin_crew_count=t.cabin_crew,
        cruise_fl=body.cruise_fl or t.cruise_fl, remarks=body.remarks, data_source="MANUAL", status="SCHEDULED",
    )
    db.add(f)
    db.flush()
    f = get_flight(db, f.id, crew=True)
    ops.resimulate_flight(db, f)
    ops.apply_lifecycle(db, f, utcnow())
    audit(db, user, "CREATE", "flight", f.id, {"flight_number": f.flight_number, "date": str(fdate)}, request)
    db.commit()
    res = serial.flight(f, full=True)
    res["conflicts"] = conflicts.detect_conflicts(db, f.std_utc - timedelta(hours=1), f.std_utc + timedelta(hours=1), {f.id})
    return res


@router.put("/flights/{fid}")
def update_flight(fid: int, body: FlightPatch, request: Request, db: Session = Depends(get_db),
                  user: User = Depends(require("flights.write"))):
    f = get_flight(db, fid, crew=True)
    if f.status in ("ARRIVED", "DIVERTED") and (body.std_utc or body.origin or body.destination):
        raise HTTPException(409, "Completed flights cannot be re-planned")
    changes = body.model_dump(exclude_none=True)
    if body.origin:
        f.origin_id = _resolve(db, body.origin).id
    if body.destination:
        f.destination_id = _resolve(db, body.destination).id
    if f.origin_id == f.destination_id:
        raise HTTPException(422, "Origin and destination must differ")
    if body.aircraft_type:
        f.aircraft_type_id = _resolve_type(db, body.aircraft_type).id
    if "registration" in body.model_fields_set:
        ac = _resolve_ac(db, body.registration)
        f.aircraft_id = ac.id if ac else None
    if body.std_utc:
        block = f.sta_utc - f.std_utc
        f.std_utc = body.std_utc
        f.sta_utc = body.sta_utc or (body.std_utc + block)
    elif body.sta_utc:
        f.sta_utc = body.sta_utc
    if f.sta_utc <= f.std_utc:
        raise HTTPException(422, "STA must be after STD")
    if body.pax_booked is not None:
        f.pax_booked = body.pax_booked
    if body.cruise_fl is not None:
        f.cruise_fl = body.cruise_fl
    if body.remarks is not None:
        f.remarks = body.remarks
    replan = any(k in changes for k in ("std_utc", "sta_utc", "origin", "destination", "aircraft_type", "registration"))
    if body.etd_utc and f.atd_utc is None:
        # manual delay: shift simulated outcome to the new estimate
        f.etd_utc = body.etd_utc
        if f.sim_out_utc:
            shift = body.etd_utc - f.sim_out_utc
            if shift.total_seconds() > 0:
                f.sim_out_utc += shift
                f.sim_off_utc += shift
                f.sim_on_utc += shift
                f.sim_in_utc += shift
                f.sim_delay_code = f.sim_delay_code or "93"
                f.sim_delay_reason = f.sim_delay_reason or "Manual estimate update"
    elif replan and f.atd_utc is None and f.data_source in ("SIMULATED", "MANUAL"):
        db.flush()
        ops.resimulate_flight(db, f)
    if f.data_source == "SIMULATED" and replan:
        f.data_source = "MANUAL"
    if f.atd_utc is None and f.status not in ("CANCELLED",):
        f.status = "SCHEDULED"
    ops.apply_lifecycle(db, f, utcnow())
    audit(db, user, "UPDATE", "flight", f.id, {k: str(v) for k, v in changes.items()}, request)
    db.commit()
    f = get_flight(db, fid, crew=True)
    res = serial.flight(f, full=True)
    res["conflicts"] = conflicts.detect_conflicts(db, f.std_utc - timedelta(hours=1), f.std_utc + timedelta(hours=1), {f.id})
    return res


class StatusIn(BaseModel):
    status: str
    reason: str | None = None
    delay_code: str | None = None


ALLOWED_STATUS = {
    "SCHEDULED": {"BOARDING", "DELAYED", "CANCELLED", "DEPARTED"},
    "DELAYED": {"SCHEDULED", "BOARDING", "CANCELLED", "DEPARTED"},
    "BOARDING": {"DELAYED", "DEPARTED", "CANCELLED", "SCHEDULED"},
    "DEPARTED": {"AIRBORNE", "SCHEDULED"},
    "AIRBORNE": {"LANDED", "DIVERTED"},
    "LANDED": {"ARRIVED"},
    "CANCELLED": {"SCHEDULED"},
    "ARRIVED": set(),
    "DIVERTED": set(),
}


@router.patch("/flights/{fid}/status")
def set_status(fid: int, body: StatusIn, request: Request, db: Session = Depends(get_db),
               user: User = Depends(require("flights.write"))):
    f = get_flight(db, fid)
    new = body.status.upper()
    if new not in FLIGHT_STATUSES:
        raise HTTPException(422, f"Unknown status {new}")
    if new not in ALLOWED_STATUS.get(f.status, set()):
        raise HTTPException(409, f"Transition {f.status} -> {new} not allowed")
    now = utcnow()
    old = f.status
    if new == "CANCELLED":
        f.sim_cancel = True
        f.cancel_reason = body.reason or "Cancelled by operations"
        f.etd_utc = f.eta_utc = None
        db.add(FlightMovement(flight_id=f.id, event="CANCEL", time_utc=now, airport_id=f.origin_id, data_source="MANUAL"))
    elif old == "CANCELLED" and new == "SCHEDULED":
        f.sim_cancel = False
        f.cancel_reason = None
        ops.resimulate_flight(db, f)
    elif new == "DELAYED":
        f.delay_code = body.delay_code or f.delay_code
        f.delay_reason = body.reason or f.delay_reason
    elif new == "DEPARTED":
        f.atd_utc = f.atd_utc or now
        db.add(FlightMovement(flight_id=f.id, event="OUT", time_utc=f.atd_utc, airport_id=f.origin_id, data_source="MANUAL"))
        f.sim_out_utc = f.atd_utc
        f.sim_off_utc = max(f.sim_off_utc or now, f.atd_utc + timedelta(minutes=8))
    elif new == "AIRBORNE":
        f.takeoff_utc = f.takeoff_utc or now
        db.add(FlightMovement(flight_id=f.id, event="OFF", time_utc=f.takeoff_utc, airport_id=f.origin_id, data_source="MANUAL"))
    elif new in ("LANDED", "DIVERTED"):
        f.landing_utc = f.landing_utc or now
        db.add(FlightMovement(flight_id=f.id, event="ON", time_utc=f.landing_utc, airport_id=f.destination_id, data_source="MANUAL"))
        if new == "DIVERTED":
            f.ata_utc = f.landing_utc
            f.remarks = (f.remarks + f" Diverted: {body.reason or 'ops decision'}").strip()
    elif new == "ARRIVED":
        f.ata_utc = f.ata_utc or now
        db.add(FlightMovement(flight_id=f.id, event="IN", time_utc=f.ata_utc, airport_id=f.destination_id, data_source="MANUAL"))
    f.status = new
    if new in ("DEPARTED", "AIRBORNE", "LANDED", "ARRIVED", "DIVERTED"):
        f.data_source = "MANUAL" if f.data_source == "SIMULATED" else f.data_source
        f.sim_out_utc = None if new in ("ARRIVED", "DIVERTED") else f.sim_out_utc
    audit(db, user, "STATUS", "flight", f.id, {"from": old, "to": new, "reason": body.reason}, request)
    db.commit()
    return serial.flight(get_flight(db, fid))


@router.delete("/flights/{fid}")
def delete_flight(fid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require("flights.delete"))):
    f = get_flight(db, fid)
    if f.status in ("DEPARTED", "AIRBORNE", "LANDED"):
        raise HTTPException(409, "Cannot delete a flight in progress")
    audit(db, user, "DELETE", "flight", f.id, {"flight_number": f.flight_number, "date": str(f.flight_date)}, request)
    db.delete(f)
    db.commit()
    return {"deleted": fid}


class AssignAircraft(BaseModel):
    registration: str | None


@router.post("/flights/{fid}/aircraft")
def assign_aircraft(fid: int, body: AssignAircraft, request: Request, db: Session = Depends(get_db),
                    user: User = Depends(require("flights.write"))):
    f = get_flight(db, fid)
    ac = _resolve_ac(db, body.registration)
    old = f.aircraft.registration if f.aircraft else None
    f.aircraft_id = ac.id if ac else None
    db.flush()
    audit(db, user, "ASSIGN_AIRCRAFT", "flight", f.id, {"from": old, "to": body.registration}, request)
    db.commit()
    f = get_flight(db, fid, crew=True)
    return {"flight": serial.flight(f, full=True),
            "conflicts": conflicts.detect_conflicts(db, f.std_utc - timedelta(hours=1), f.std_utc + timedelta(hours=1), {f.id})}


class AssignCrew(BaseModel):
    crew_id: int
    role: str


@router.post("/flights/{fid}/crew")
def assign_crew(fid: int, body: AssignCrew, request: Request, db: Session = Depends(get_db),
                user: User = Depends(require("flights.write"))):
    f = get_flight(db, fid, crew=True)
    cm = db.get(CrewMember, body.crew_id)
    if not cm or not cm.active:
        raise HTTPException(404, "Crew member not found")
    role = body.role.upper()
    if role not in ("CPT", "FO", "SCCM", "CC"):
        raise HTTPException(422, "Role must be CPT, FO, SCCM or CC")
    if any(c.crew_id == cm.id for c in f.crew):
        raise HTTPException(409, "Already assigned")
    if role in ("CPT", "FO") and cm.role not in ("CPT", "FO"):
        raise HTTPException(422, "Cabin crew cannot be rostered in the cockpit")
    if role in ("CPT", "FO", "SCCM"):
        for c in list(f.crew):
            if c.role == role:
                db.delete(c)
    db.add(FlightCrewAssignment(flight_id=f.id, crew_id=cm.id, role=role))
    audit(db, user, "ASSIGN_CREW", "flight", f.id, {"crew": cm.employee_no, "role": role}, request)
    db.commit()
    f = get_flight(db, fid, crew=True)
    return {"flight": serial.flight(f, full=True),
            "conflicts": conflicts.detect_conflicts(db, f.std_utc - timedelta(hours=1), f.std_utc + timedelta(hours=1), {f.id})}


@router.delete("/flights/{fid}/crew/{crew_id}")
def unassign_crew(fid: int, crew_id: int, request: Request, db: Session = Depends(get_db),
                  user: User = Depends(require("flights.write"))):
    a = db.scalars(select(FlightCrewAssignment).where(FlightCrewAssignment.flight_id == fid,
                                                      FlightCrewAssignment.crew_id == crew_id)).first()
    if not a:
        raise HTTPException(404, "Assignment not found")
    db.delete(a)
    audit(db, user, "UNASSIGN_CREW", "flight", fid, {"crew_id": crew_id}, request)
    db.commit()
    return {"ok": True}


@router.get("/flights/{fid}/crew-candidates")
def crew_candidates(fid: int, role: str = "CPT", db: Session = Depends(get_db), _: User = Depends(current_user)):
    """Rated crew of the role, flagged when they already fly within +/- 12 h."""
    f = get_flight(db, fid)
    fam = TYPE_FAMILY.get(f.aircraft.type.icao if f.aircraft else f.aircraft_type.icao, "")
    cands = db.scalars(select(CrewMember).where(CrewMember.active.is_(True), CrewMember.role == role.upper(),
                                                CrewMember.type_ratings.like(f"%{fam}%")).order_by(CrewMember.last_name)).all()
    busy_rows = db.execute(select(FlightCrewAssignment.crew_id, Flight.flight_number, Flight.std_utc).join(Flight).where(
        Flight.std_utc >= f.std_utc - timedelta(hours=12), Flight.std_utc <= f.std_utc + timedelta(hours=12),
        Flight.status != "CANCELLED")).all()
    busy: dict[int, list[str]] = {}
    for cid, fn, std in busy_rows:
        busy.setdefault(cid, []).append(f"{fn} {std:%H:%M}Z")
    return [{**serial.crew(c), "busy": busy.get(c.id, [])} for c in cands]


@router.get("/flights/{fid}/trajectory")
def flight_trajectory(fid: int, step: int = Query(60, ge=10, le=600), db: Session = Depends(get_db), _: User = Depends(current_user)):
    f = get_flight(db, fid)
    now = utcnow()
    live = f.status in ("DEPARTED", "AIRBORNE", "LANDED")
    pts = tracking.trajectory(f, until=now if live or f.status not in ("ARRIVED", "DIVERTED") else None, step_s=step)
    if f.status in ("SCHEDULED", "DELAYED", "BOARDING"):
        pts = []
    planned = [[f.origin.lat, f.origin.lon], [tracking.dest_airport(f).lat, tracking.dest_airport(f).lon]]
    return {"flight": serial.flight(f), "points": pts, "planned": planned,
            "data_source": "SIMULATED" if live else ("HISTORICAL" if f.status in ("ARRIVED", "DIVERTED") else "PLANNED"),
            "note": "Trajectory reconstructed from movement times on a great-circle model."}


# --------------------------------------------------------------------------- schedule & planning


@router.get("/schedule/gantt")
def gantt(day: str | None = None, days: int = Query(1, ge=1, le=7), db: Session = Depends(get_db), _: User = Depends(current_user)):
    d = date.fromisoformat(day) if day else utcnow().date()
    d0 = datetime.combine(d, datetime.min.time())
    d1 = d0 + timedelta(days=days)
    fl = db.scalars(flight_query().where(Flight.std_utc >= d0 - timedelta(hours=8), Flight.std_utc < d1)
                    .order_by(Flight.std_utc)).unique().all()
    fl = [f for f in fl if f.sta_utc > d0]
    acs = db.scalars(select(Aircraft).options(joinedload(Aircraft.type)).order_by(Aircraft.type_id, Aircraft.registration)).all()
    rows = {a.id: {"aircraft_id": a.id, "registration": a.registration, "type": a.type.icao,
                   "operational_status": a.operational_status, "maintenance_status": a.maintenance_status, "flights": []} for a in acs}
    unassigned = []
    for f in fl:
        item = serial.flight(f)
        if f.aircraft_id in rows:
            rows[f.aircraft_id]["flights"].append(item)
        else:
            unassigned.append(item)
    from ..models import MaintenanceRecord

    mx = db.scalars(select(MaintenanceRecord).where(MaintenanceRecord.start_utc < d1, MaintenanceRecord.end_utc > d0,
                                                    MaintenanceRecord.status != "CANCELLED")).all()
    for m in mx:
        if m.aircraft_id in rows:
            rows[m.aircraft_id].setdefault("maintenance", []).append(serial.maintenance(m))
    cf = conflicts.detect_conflicts(db, d0, d1)
    return {"start": d0.isoformat(), "end": d1.isoformat(), "rows": list(rows.values()), "unassigned": unassigned,
            "conflicts": cf}


@router.get("/schedule/calendar")
def calendar(month: str | None = None, db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    y, m = (int(x) for x in month.split("-")) if month else (now.year, now.month)
    d0 = datetime(y, m, 1)
    d1 = datetime(y + (m == 12), (m % 12) + 1, 1)
    rows = db.execute(select(Flight.flight_date, Flight.status, func.count()).where(
        Flight.std_utc >= d0, Flight.std_utc < d1).group_by(Flight.flight_date, Flight.status)).all()
    days: dict[str, dict] = {}
    for fd, st, n in rows:
        e = days.setdefault(fd.isoformat(), {"date": fd.isoformat(), "total": 0, "cancelled": 0, "completed": 0, "open": 0})
        e["total"] += n
        if st == "CANCELLED":
            e["cancelled"] += n
        elif st in ("ARRIVED", "DIVERTED"):
            e["completed"] += n
        else:
            e["open"] += n
    return {"month": f"{y:04d}-{m:02d}", "days": sorted(days.values(), key=lambda x: x["date"])}


@router.get("/schedule/conflicts")
def schedule_conflicts(start: str | None = None, end: str | None = None, db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    s = _dt(start, now - timedelta(hours=2))
    e = _dt(end, now + timedelta(days=2))
    if (e - s) > timedelta(days=31):
        raise HTTPException(422, "Range limited to 31 days")
    cf = conflicts.detect_conflicts(db, s, e)
    summary: dict[str, int] = {}
    for c in cf:
        summary[c["type"]] = summary.get(c["type"], 0) + 1
    return {"start": s.isoformat(), "end": e.isoformat(), "total": len(cf), "by_type": summary, "items": cf}


@router.get("/schedule/itinerary")
def itinerary(registration: str | None = None, crew_id: int | None = None, day: str | None = None, days: int = Query(1, ge=1, le=14),
              db: Session = Depends(get_db), _: User = Depends(current_user)):
    d = date.fromisoformat(day) if day else utcnow().date()
    d0 = datetime.combine(d, datetime.min.time())
    q = flight_query().where(Flight.std_utc >= d0, Flight.std_utc < d0 + timedelta(days=days)).order_by(Flight.std_utc)
    if registration:
        ac = _resolve_ac(db, registration)
        q = q.where(Flight.aircraft_id == ac.id)
    elif crew_id:
        q = q.join(FlightCrewAssignment, FlightCrewAssignment.flight_id == Flight.id).where(FlightCrewAssignment.crew_id == crew_id)
    else:
        raise HTTPException(422, "registration or crew_id required")
    items = [serial.flight(f) for f in db.scalars(q).unique().all()]
    block = sum(i["block_min"] for i in items if i["status"] != "CANCELLED")
    return {"items": items, "legs": len(items), "block_hours": round(block / 60, 1)}


class ScheduleIn(BaseModel):
    airline_id: int
    flight_number: str
    origin: str
    destination: str
    aircraft_type: str
    days_of_week: str = "1234567"
    std_utc: str
    valid_from: date
    valid_to: date
    rotation_line: str = ""
    leg_seq: int = 1
    active: bool = True

    @field_validator("days_of_week")
    @classmethod
    def dow(cls, v):
        if not v or any(c not in "1234567" for c in v):
            raise ValueError("days_of_week must contain digits 1-7")
        return "".join(sorted(set(v)))

    @field_validator("std_utc")
    @classmethod
    def hhmm(cls, v):
        datetime.strptime(v, "%H:%M")
        return v


def _sched_dict(s: FlightSchedule) -> dict:
    return {"id": s.id, "airline_id": s.airline_id, "flight_number": s.flight_number, "origin": s.route.origin.icao,
            "destination": s.route.destination.icao, "aircraft_type": s.aircraft_type.icao, "days_of_week": s.days_of_week,
            "std_utc": s.std_utc, "block_min": s.block_min, "rotation_line": s.rotation_line, "leg_seq": s.leg_seq,
            "valid_from": s.valid_from.isoformat(), "valid_to": s.valid_to.isoformat(), "active": s.active,
            "distance_nm": s.route.distance_nm}


@router.get("/schedule/patterns")
def list_patterns(db: Session = Depends(get_db), _: User = Depends(current_user)):
    rows = db.scalars(select(FlightSchedule).options(joinedload(FlightSchedule.route).joinedload(Route.origin),
                                                     joinedload(FlightSchedule.route).joinedload(Route.destination),
                                                     joinedload(FlightSchedule.aircraft_type))
                      .order_by(FlightSchedule.rotation_line, FlightSchedule.leg_seq)).unique().all()
    return [_sched_dict(s) for s in rows]


def _upsert_pattern(db: Session, s: FlightSchedule, body: ScheduleIn) -> None:
    o, d = _resolve(db, body.origin), _resolve(db, body.destination)
    t = _resolve_type(db, body.aircraft_type)
    if body.valid_to < body.valid_from:
        raise HTTPException(422, "valid_to before valid_from")
    route = db.scalars(select(Route).where(Route.origin_id == o.id, Route.destination_id == d.id)).first()
    dist = distance_nm(o.lat, o.lon, d.lat, d.lon)
    if not route:
        route = Route(origin_id=o.id, destination_id=d.id, distance_nm=round(dist, 1),
                      typical_block_min=perf.scheduled_block_minutes(dist, t.cruise_ktas))
        db.add(route)
        db.flush()
    s.airline_id, s.flight_number, s.route_id, s.aircraft_type_id = body.airline_id, body.flight_number.upper(), route.id, t.id
    s.days_of_week, s.std_utc, s.valid_from, s.valid_to = body.days_of_week, body.std_utc, body.valid_from, body.valid_to
    s.rotation_line, s.leg_seq, s.active = body.rotation_line, body.leg_seq, body.active
    s.block_min = perf.scheduled_block_minutes(dist, t.cruise_ktas)


@router.post("/schedule/patterns", status_code=201)
def create_pattern(body: ScheduleIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("schedule.write"))):
    s = FlightSchedule()
    _upsert_pattern(db, s, body)
    db.add(s)
    db.flush()
    audit(db, user, "CREATE", "schedule", s.id, body.model_dump(mode="json"), request)
    db.commit()
    db.refresh(s)
    return _sched_dict(s)


@router.put("/schedule/patterns/{sid}")
def update_pattern(sid: int, body: ScheduleIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("schedule.write"))):
    s = db.get(FlightSchedule, sid)
    if not s:
        raise HTTPException(404, "Schedule not found")
    _upsert_pattern(db, s, body)
    audit(db, user, "UPDATE", "schedule", s.id, body.model_dump(mode="json"), request)
    db.commit()
    db.refresh(s)
    return _sched_dict(s)


@router.delete("/schedule/patterns/{sid}")
def delete_pattern(sid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require("schedule.write"))):
    s = db.get(FlightSchedule, sid)
    if not s:
        raise HTTPException(404, "Schedule not found")
    s.active = False
    audit(db, user, "DEACTIVATE", "schedule", sid, None, request)
    db.commit()
    return {"deactivated": sid}


class MaterialiseIn(BaseModel):
    date_from: date
    date_to: date


@router.post("/schedule/materialise")
def materialise(body: MaterialiseIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("schedule.write"))):
    if (body.date_to - body.date_from).days > 60 or body.date_to < body.date_from:
        raise HTTPException(422, "Range must be 0-60 days")
    ctx = ops.build_ctx(db)
    n = 0
    d = body.date_from
    while d <= body.date_to:
        n += ops.materialise_day(db, d, utcnow(), ctx)
        d += timedelta(days=1)
    ops.advance(db)
    audit(db, user, "MATERIALISE", "schedule", None, {"from": str(body.date_from), "to": str(body.date_to), "created": n}, request)
    db.commit()
    return {"created": n}


@router.get("/airlines")
def airlines(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return [{"id": a.id, "icao": a.icao, "iata": a.iata, "name": a.name, "callsign": a.callsign, "country": a.country,
             "hub_icao": a.hub_icao} for a in db.scalars(select(Airline)).all()]
