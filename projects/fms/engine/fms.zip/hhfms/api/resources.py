"""Fleet, maintenance, crew, airports, runways, weather and NOTAMs."""
from __future__ import annotations

from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, joinedload, selectinload

from .. import analytics, config, seed, serial, weather
from ..db import get_db
from ..models import (
    Aircraft,
    AircraftType,
    Airline,
    Airport,
    CrewMember,
    Flight,
    FlightCrewAssignment,
    MaintenanceRecord,
    Notam,
    Runway,
    SystemConfig,
    User,
    WeatherRecord,
    utcnow,
)
from ..security import audit, current_user, require
from .flights import flight_query

router = APIRouter(prefix="/api", tags=["resources"])


def _cfg(db: Session, key: str, default):
    row = db.get(SystemConfig, key)
    return row.value if row and row.value is not None else default


# --------------------------------------------------------------------------- fleet


@router.get("/aircraft-types")
def types(db: Session = Depends(get_db), _: User = Depends(current_user)):
    return [serial.aircraft_type(t) for t in db.scalars(select(AircraftType).order_by(AircraftType.icao)).all()]


@router.get("/aircraft")
def list_aircraft(db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    acs = db.scalars(select(Aircraft).options(joinedload(Aircraft.type), joinedload(Aircraft.airline))
                     .order_by(Aircraft.registration)).unique().all()
    # current position/state
    cur = {}
    for f in db.scalars(flight_query().where(Flight.std_utc >= now - timedelta(hours=20), Flight.std_utc <= now + timedelta(hours=20),
                                             Flight.status != "CANCELLED").order_by(Flight.std_utc)).unique().all():
        if not f.aircraft_id:
            continue
        e = cur.setdefault(f.aircraft_id, {"last": None, "next": None, "active": None})
        if f.status in ("DEPARTED", "AIRBORNE", "LANDED"):
            e["active"] = f
        elif f.status in ("ARRIVED", "DIVERTED"):
            e["last"] = f
        elif e["next"] is None:
            e["next"] = f
    out = []
    for a in acs:
        d = serial.aircraft(a)
        e = cur.get(a.id, {})
        act, last, nxt = e.get("active"), e.get("last"), e.get("next")
        d["current_state"] = "AIRBORNE" if act else "ON_GROUND"
        d["current_flight"] = act.flight_number if act else None
        d["location"] = (act.destination.icao if act else (last.destination.icao if last else a.base_icao))
        d["next_flight"] = f"{nxt.flight_number} {nxt.origin.icao}-{nxt.destination.icao} {nxt.std_utc:%H:%M}Z" if nxt else None
        out.append(d)
    return out


@router.get("/aircraft/{aid}")
def aircraft_detail(aid: int, db: Session = Depends(get_db), _: User = Depends(current_user)):
    a = db.get(Aircraft, aid)
    if not a:
        raise HTTPException(404, "Aircraft not found")
    now = utcnow()
    d = serial.aircraft(a)
    d["maintenance"] = [serial.maintenance(m) for m in db.scalars(select(MaintenanceRecord).where(
        MaintenanceRecord.aircraft_id == aid).order_by(MaintenanceRecord.start_utc.desc())).all()]
    d["upcoming"] = [serial.flight(f) for f in db.scalars(flight_query().where(
        Flight.aircraft_id == aid, Flight.std_utc >= now - timedelta(hours=6)).order_by(Flight.std_utc).limit(20)).unique().all()]
    d["recent"] = [serial.flight(f) for f in db.scalars(flight_query().where(
        Flight.aircraft_id == aid, Flight.std_utc < now).order_by(Flight.std_utc.desc()).limit(20)).unique().all()]
    util = analytics.aircraft_utilisation(db, now - timedelta(days=30), now)
    d["utilisation_30d"] = next((u for u in util if u["aircraft_id"] == aid), None)
    # daily block hours (last 30 days)
    df = analytics.flights_df(db, now - timedelta(days=30), now, aircraft=a.registration)
    daily = []
    if not df.empty:
        g = df[df["ata"].notna()].groupby(df["std"].dt.date)["actual_block"].sum() / 60
        daily = [{"date": k.isoformat(), "block_hours": round(float(v), 2)} for k, v in g.items()]
    d["daily_block_hours"] = daily
    return d


class AircraftIn(BaseModel):
    registration: str = Field(min_length=3, max_length=10)
    type_id: int
    airline_id: int | None = None
    msn: str = ""
    seats: int | None = Field(None, ge=1, le=900)
    operational_status: str = "ACTIVE"
    base_icao: str = "EHAM"
    total_flight_hours: float = Field(0, ge=0)
    total_cycles: int = Field(0, ge=0)
    check_interval_hours: float = Field(750, gt=0)
    notes: str = ""

    @field_validator("operational_status")
    @classmethod
    def st(cls, v):
        v = v.upper()
        if v not in ("ACTIVE", "AOG", "STORED", "MAINTENANCE"):
            raise ValueError("operational_status must be ACTIVE, AOG, STORED or MAINTENANCE")
        return v


@router.post("/aircraft", status_code=201)
def create_aircraft(body: AircraftIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("fleet.write"))):
    reg = body.registration.upper()
    if db.scalars(select(Aircraft).where(Aircraft.registration == reg)).first():
        raise HTTPException(409, "Registration already exists")
    t = db.get(AircraftType, body.type_id)
    if not t:
        raise HTTPException(422, "Unknown aircraft type")
    a = Aircraft(**{**body.model_dump(), "registration": reg, "base_icao": body.base_icao.upper(),
                    "seats": body.seats or t.pax_capacity}, data_source="MANUAL")
    db.add(a)
    db.flush()
    audit(db, user, "CREATE", "aircraft", a.id, {"registration": reg}, request)
    db.commit()
    db.refresh(a)
    return serial.aircraft(a)


@router.put("/aircraft/{aid}")
def update_aircraft(aid: int, body: AircraftIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("fleet.write"))):
    a = db.get(Aircraft, aid)
    if not a:
        raise HTTPException(404, "Aircraft not found")
    reg = body.registration.upper()
    other = db.scalars(select(Aircraft).where(Aircraft.registration == reg, Aircraft.id != aid)).first()
    if other:
        raise HTTPException(409, "Registration already exists")
    before = serial.aircraft(a)
    for k, v in body.model_dump().items():
        setattr(a, k, v)
    a.registration = reg
    a.base_icao = body.base_icao.upper()
    audit(db, user, "UPDATE", "aircraft", aid, {k: v for k, v in body.model_dump().items() if before.get(k) != v}, request)
    db.commit()
    db.refresh(a)
    return serial.aircraft(a)


@router.delete("/aircraft/{aid}")
def delete_aircraft(aid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require("fleet.write"))):
    a = db.get(Aircraft, aid)
    if not a:
        raise HTTPException(404, "Aircraft not found")
    future = db.scalar(select(func.count()).select_from(Flight).where(Flight.aircraft_id == aid, Flight.std_utc > utcnow(),
                                                                      Flight.status != "CANCELLED"))
    if future:
        raise HTTPException(409, f"Aircraft has {future} future flights - reassign them or set status STORED")
    a.operational_status = "STORED"
    audit(db, user, "RETIRE", "aircraft", aid, None, request)
    db.commit()
    return {"retired": aid}


@router.get("/fleet/utilisation")
def fleet_utilisation(days: int = Query(30, ge=1, le=365), db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    rows = analytics.aircraft_utilisation(db, now - timedelta(days=days), now)
    by_type: dict[str, dict] = {}
    for r in rows:
        e = by_type.setdefault(r["type"], {"type": r["type"], "aircraft": 0, "block_hours": 0.0, "flights": 0})
        e["aircraft"] += 1
        e["block_hours"] += r["block_hours"]
        e["flights"] += r["flights"]
    for e in by_type.values():
        e["block_hours_per_aircraft_day"] = round(e["block_hours"] / max(1, e["aircraft"]) / days, 2)
        e["block_hours"] = round(e["block_hours"], 1)
    avail = {"total": len(rows), "active": sum(1 for r in rows if r["operational_status"] == "ACTIVE"),
             "maintenance": sum(1 for r in rows if r["operational_status"] == "MAINTENANCE"),
             "aog": sum(1 for r in rows if r["operational_status"] == "AOG"),
             "stored": sum(1 for r in rows if r["operational_status"] == "STORED")}
    avail["availability_pct"] = round(avail["active"] / max(1, avail["total"] - avail["stored"]) * 100, 1)
    return {"days": days, "aircraft": rows, "by_type": list(by_type.values()), "availability": avail}


class MaintenanceIn(BaseModel):
    kind: str
    description: str = ""
    start_utc: datetime
    end_utc: datetime
    status: str = "PLANNED"
    station: str = "EHAM"

    @field_validator("kind")
    @classmethod
    def k(cls, v):
        v = v.upper()
        if v not in ("A-CHECK", "C-CHECK", "LINE", "DEFECT", "ENGINE", "CABIN"):
            raise ValueError("invalid maintenance kind")
        return v

    @field_validator("start_utc", "end_utc")
    @classmethod
    def naive(cls, v):
        return v.replace(tzinfo=None)


@router.get("/maintenance")
def list_maintenance(days: int = Query(30, ge=1, le=365), db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    rows = db.scalars(select(MaintenanceRecord).options(joinedload(MaintenanceRecord.aircraft)).where(
        MaintenanceRecord.end_utc >= now - timedelta(days=days), MaintenanceRecord.start_utc <= now + timedelta(days=days))
        .order_by(MaintenanceRecord.start_utc)).unique().all()
    return [serial.maintenance(m) for m in rows]


@router.post("/aircraft/{aid}/maintenance", status_code=201)
def add_maintenance(aid: int, body: MaintenanceIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("fleet.write"))):
    a = db.get(Aircraft, aid)
    if not a:
        raise HTTPException(404, "Aircraft not found")
    if body.end_utc <= body.start_utc:
        raise HTTPException(422, "end must be after start")
    m = MaintenanceRecord(aircraft_id=aid, **body.model_dump(), flight_hours_at=a.total_flight_hours)
    m.station = m.station.upper()
    db.add(m)
    db.flush()
    from .. import conflicts, ops

    ops.update_maintenance_status(db)
    audit(db, user, "CREATE", "maintenance", m.id, {"aircraft": a.registration, "kind": m.kind}, request)
    db.commit()
    impacted = conflicts.detect_conflicts(db, body.start_utc - timedelta(hours=12), body.end_utc)
    impacted = [c for c in impacted if c["type"] == "MAINTENANCE" and a.registration in c["message"]]
    return {"record": serial.maintenance(m), "impacted_flights": impacted}


@router.put("/maintenance/{mid}")
def update_maintenance(mid: int, body: MaintenanceIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("fleet.write"))):
    m = db.get(MaintenanceRecord, mid)
    if not m:
        raise HTTPException(404, "Record not found")
    if body.end_utc <= body.start_utc:
        raise HTTPException(422, "end must be after start")
    for k, v in body.model_dump().items():
        setattr(m, k, v)
    from .. import ops

    ops.update_maintenance_status(db)
    audit(db, user, "UPDATE", "maintenance", mid, body.model_dump(mode="json"), request)
    db.commit()
    return serial.maintenance(m)


# --------------------------------------------------------------------------- crew


@router.get("/crew")
def list_crew(role: str | None = None, rating: str | None = None, q: str | None = None,
              db: Session = Depends(get_db), _: User = Depends(current_user)):
    qry = select(CrewMember).order_by(CrewMember.role, CrewMember.last_name)
    if role:
        qry = qry.where(CrewMember.role == role.upper())
    if rating:
        qry = qry.where(CrewMember.type_ratings.like(f"%{rating}%"))
    if q:
        like = f"%{q}%"
        qry = qry.where(or_(CrewMember.first_name.like(like), CrewMember.last_name.like(like), CrewMember.employee_no.like(like)))
    crew = db.scalars(qry).all()
    now = utcnow()
    hrs = dict(db.execute(select(FlightCrewAssignment.crew_id, func.sum(
        (func.julianday(Flight.sta_utc) - func.julianday(Flight.std_utc)) * 24)).join(Flight).where(
        Flight.std_utc >= now - timedelta(days=28), Flight.std_utc <= now, Flight.status != "CANCELLED")
        .group_by(FlightCrewAssignment.crew_id)).all())
    return [{**serial.crew(c), "block_hours_28d": round(float(hrs.get(c.id) or 0), 1)} for c in crew]


class CrewIn(BaseModel):
    employee_no: str
    first_name: str
    last_name: str
    role: str
    base_icao: str = "EHAM"
    type_ratings: str = ""
    airline_id: int | None = None
    active: bool = True

    @field_validator("role")
    @classmethod
    def r(cls, v):
        v = v.upper()
        if v not in ("CPT", "FO", "SCCM", "CC"):
            raise ValueError("role must be CPT, FO, SCCM or CC")
        return v


@router.post("/crew", status_code=201)
def create_crew(body: CrewIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("crew.write"))):
    if db.scalars(select(CrewMember).where(CrewMember.employee_no == body.employee_no)).first():
        raise HTTPException(409, "Employee number exists")
    c = CrewMember(**body.model_dump())
    db.add(c)
    db.flush()
    audit(db, user, "CREATE", "crew", c.id, {"employee_no": c.employee_no}, request)
    db.commit()
    return serial.crew(c)


@router.put("/crew/{cid}")
def update_crew(cid: int, body: CrewIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("crew.write"))):
    c = db.get(CrewMember, cid)
    if not c:
        raise HTTPException(404, "Crew member not found")
    for k, v in body.model_dump().items():
        setattr(c, k, v)
    audit(db, user, "UPDATE", "crew", cid, body.model_dump(), request)
    db.commit()
    return serial.crew(c)


# --------------------------------------------------------------------------- airports


def get_airport(db: Session, key: str) -> Airport:
    q = select(Airport).options(selectinload(Airport.runways))
    a = db.scalars(q.where(Airport.id == int(key))).first() if key.isdigit() else db.scalars(
        q.where(or_(Airport.icao == key.upper(), Airport.iata == key.upper()))).first()
    if not a:
        raise HTTPException(404, "Airport not found")
    return a


@router.get("/airports")
def list_airports(db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    d0 = datetime.combine(now.date(), datetime.min.time())
    dep = dict(db.execute(select(Flight.origin_id, func.count()).where(Flight.std_utc >= d0, Flight.std_utc < d0 + timedelta(days=1),
                                                                      Flight.status != "CANCELLED").group_by(Flight.origin_id)).all())
    arr = dict(db.execute(select(Flight.destination_id, func.count()).where(Flight.sta_utc >= d0, Flight.sta_utc < d0 + timedelta(days=1),
                                                                           Flight.status != "CANCELLED").group_by(Flight.destination_id)).all())
    wx = {}
    for r in db.execute(select(WeatherRecord.airport_id, WeatherRecord.flight_category, WeatherRecord.severity, WeatherRecord.obs_time_utc)
                        .where(WeatherRecord.kind == "METAR", WeatherRecord.obs_time_utc <= now, WeatherRecord.obs_time_utc >= now - timedelta(hours=3))
                        .order_by(WeatherRecord.obs_time_utc)).all():
        wx[r[0]] = {"flight_category": r[1], "severity": r[2]}
    out = []
    for a in db.scalars(select(Airport).options(selectinload(Airport.runways)).order_by(Airport.icao)).all():
        d = serial.airport(a)
        d["departures_today"] = dep.get(a.id, 0)
        d["arrivals_today"] = arr.get(a.id, 0)
        d["weather"] = wx.get(a.id)
        d["open_runways"] = sum(1 for r in a.runways if r.status != "CLOSED")
        out.append(d)
    return out


@router.get("/airports/{key}")
def airport_detail(key: str, days: int = Query(30, ge=1, le=365), db: Session = Depends(get_db), _: User = Depends(current_user)):
    a = get_airport(db, key)
    now = utcnow()
    d = serial.airport(a)
    df = analytics.flights_df(db, now - timedelta(days=days), now + timedelta(hours=1), airport=a.icao)
    thr = analytics.otp_threshold(db)
    d["stats"] = analytics.kpis(df, thr, now)
    if not df.empty:
        deps = df[df["origin"] == a.icao]
        arrs = df[df["destination"] == a.icao]
        d["stats"]["departures"] = int((deps["status"] != "CANCELLED").sum())
        d["stats"]["arrivals"] = int((arrs["status"] != "CANCELLED").sum())
        d["stats"]["avg_taxi_out_min"] = round(float(((deps["takeoff"] - deps["atd"]).dt.total_seconds() / 60).mean()), 1) if deps["takeoff"].notna().any() else None
        d["stats"]["avg_taxi_in_min"] = round(float(((arrs["ata"] - arrs["landing"]).dt.total_seconds() / 60).mean()), 1) if arrs["landing"].notna().any() else None
        d["stats"]["otp_departure_here"] = analytics.kpis(deps, thr, now)["otp_departure"]
        d["stats"]["otp_arrival_here"] = analytics.kpis(arrs, thr, now)["otp_arrival"]
        d["daily"] = analytics.trends(df, "D", thr)
        d["hourly"] = analytics.hourly_profile(df[(df["origin"] == a.icao) | (df["destination"] == a.icao)])
        d["routes"] = analytics.route_performance(df, thr)[:15]
    d0 = datetime.combine(now.date(), datetime.min.time())
    today = db.scalars(flight_query().where(or_(Flight.origin_id == a.id, Flight.destination_id == a.id),
                                            Flight.std_utc >= d0 - timedelta(hours=12), Flight.std_utc < d0 + timedelta(days=1))
                       .order_by(Flight.std_utc)).unique().all()
    d["departures"] = [serial.flight(f) for f in today if f.origin_id == a.id and f.std_utc >= d0]
    d["arrivals"] = [serial.flight(f) for f in today if f.destination_id == a.id and f.sta_utc >= d0 and f.sta_utc < d0 + timedelta(days=1)]
    d["notams"] = [serial.notam(n) for n in db.scalars(select(Notam).where(Notam.airport_id == a.id, Notam.active.is_(True),
                                                                           Notam.valid_to_utc >= now)).all()]
    return d


class AirportIn(BaseModel):
    icao: str = Field(min_length=4, max_length=4)
    iata: str | None = Field(None, max_length=3)
    name: str
    city: str = ""
    country: str = ""
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    elevation_ft: int = 0
    timezone: str = "UTC"
    terminals: int = Field(1, ge=0, le=20)
    terminal_info: str = ""
    capacity_arr_per_hour: int = Field(30, ge=0, le=200)
    capacity_dep_per_hour: int = Field(30, ge=0, le=200)
    min_turnaround_min: int = Field(35, ge=10, le=300)
    status: str = "OPEN"
    status_note: str = ""

    @field_validator("status")
    @classmethod
    def s(cls, v):
        v = v.upper()
        if v not in ("OPEN", "RESTRICTED", "CLOSED"):
            raise ValueError("status must be OPEN, RESTRICTED or CLOSED")
        return v


@router.post("/airports", status_code=201)
def create_airport(body: AirportIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("airports.write"))):
    if db.scalars(select(Airport).where(Airport.icao == body.icao.upper())).first():
        raise HTTPException(409, "ICAO code exists")
    a = Airport(**{**body.model_dump(), "icao": body.icao.upper(), "iata": (body.iata or "").upper() or None}, data_source="MANUAL")
    db.add(a)
    db.flush()
    audit(db, user, "CREATE", "airport", a.id, {"icao": a.icao}, request)
    db.commit()
    return serial.airport(get_airport(db, str(a.id)))


@router.put("/airports/{aid}")
def update_airport(aid: int, body: AirportIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("airports.write"))):
    a = db.get(Airport, aid)
    if not a:
        raise HTTPException(404, "Airport not found")
    for k, v in body.model_dump().items():
        setattr(a, k, v)
    a.icao = body.icao.upper()
    audit(db, user, "UPDATE", "airport", aid, body.model_dump(), request)
    db.commit()
    return serial.airport(get_airport(db, str(aid)))


class RunwayIn(BaseModel):
    designator: str
    length_m: int = Field(ge=300, le=6000)
    width_m: int = Field(45, ge=10, le=100)
    heading_deg: float = Field(ge=0, le=360)
    surface: str = "ASPH"
    ils: bool = True
    status: str = "OPEN"


@router.post("/airports/{aid}/runways", status_code=201)
def add_runway(aid: int, body: RunwayIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("airports.write"))):
    a = db.get(Airport, aid)
    if not a:
        raise HTTPException(404, "Airport not found")
    r = Runway(airport_id=aid, **body.model_dump())
    db.add(r)
    audit(db, user, "CREATE", "runway", None, {"airport": a.icao, **body.model_dump()}, request)
    db.commit()
    return serial.airport(get_airport(db, str(aid)))


@router.put("/runways/{rid}")
def update_runway(rid: int, body: RunwayIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("airports.write"))):
    r = db.get(Runway, rid)
    if not r:
        raise HTTPException(404, "Runway not found")
    for k, v in body.model_dump().items():
        setattr(r, k, v)
    audit(db, user, "UPDATE", "runway", rid, body.model_dump(), request)
    db.commit()
    return serial.airport(get_airport(db, str(r.airport_id)))


@router.delete("/runways/{rid}")
def delete_runway(rid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require("airports.write"))):
    r = db.get(Runway, rid)
    if not r:
        raise HTTPException(404, "Runway not found")
    aid = r.airport_id
    db.delete(r)
    audit(db, user, "DELETE", "runway", rid, None, request)
    db.commit()
    return serial.airport(get_airport(db, str(aid)))


# --------------------------------------------------------------------------- weather


def _latest(db: Session, aid: int, kind: str, at: datetime):
    return db.scalars(select(WeatherRecord).where(WeatherRecord.airport_id == aid, WeatherRecord.kind == kind,
                                                  WeatherRecord.obs_time_utc <= at).order_by(WeatherRecord.obs_time_utc.desc())).first()


def _wx_summary(db: Session, a: Airport, now: datetime, max_x: float) -> dict:
    m = _latest(db, a.id, "METAR", now)
    t = _latest(db, a.id, "TAF", now)
    d = weather.decode_metar(m.raw) if m else {}
    rw = weather.runway_analysis([{"designator": r.designator, "heading_deg": r.heading_deg, "length_m": r.length_m,
                                   "status": r.status} for r in a.runways], d.get("wind_dir_deg"), d.get("wind_speed_kt"),
                                 d.get("wind_gust_kt"), max_x) if m else []
    return {"airport_id": a.id, "icao": a.icao, "iata": a.iata, "name": a.name, "lat": a.lat, "lon": a.lon,
            "metar": m.raw if m else None, "metar_time": m.obs_time_utc.isoformat() if m else None,
            "taf": t.raw if t else None, "taf_time": t.obs_time_utc.isoformat() if t else None,
            "data_source": m.data_source if m else None, "decoded": d,
            "stale": bool(m and m.obs_time_utc < now - timedelta(hours=2)),
            "runways": rw, "warnings": weather.warnings_for(a.icao, d, max_x, rw) if m else []}


@router.get("/weather/current")
def weather_current(db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    max_x = float(_cfg(db, "weather.max_crosswind_kt", 30))
    return [_wx_summary(db, a, now, max_x) for a in db.scalars(select(Airport).options(selectinload(Airport.runways)).order_by(Airport.icao)).all()]


@router.get("/weather/warnings")
def weather_warnings(db: Session = Depends(get_db), _: User = Depends(current_user)):
    out = []
    for s in weather_current(db):
        for w in s["warnings"]:
            out.append({**w, "icao": s["icao"], "metar": s["metar"]})
    return out


@router.get("/weather/compare")
def weather_compare(icaos: str, hours: int = Query(24, ge=1, le=168), db: Session = Depends(get_db), _: User = Depends(current_user)):
    now = utcnow()
    res = {}
    for code in [c.strip().upper() for c in icaos.split(",") if c.strip()][:8]:
        a = db.scalars(select(Airport).where(Airport.icao == code)).first()
        if not a:
            continue
        rows = db.scalars(select(WeatherRecord).where(WeatherRecord.airport_id == a.id, WeatherRecord.kind == "METAR",
                                                      WeatherRecord.obs_time_utc >= now - timedelta(hours=hours),
                                                      WeatherRecord.obs_time_utc <= now).order_by(WeatherRecord.obs_time_utc)).all()
        res[code] = [{"t": r.obs_time_utc.isoformat(), "wind": r.wind_speed_kt, "gust": r.wind_gust_kt, "vis": r.visibility_m,
                      "temp": r.temperature_c, "qnh": r.qnh_hpa, "ceiling": r.ceiling_ft, "severity": r.severity,
                      "category": r.flight_category} for r in rows]
    return res


@router.get("/weather/{icao}")
def weather_airport(icao: str, hours: int = Query(24, ge=1, le=168), db: Session = Depends(get_db), _: User = Depends(current_user)):
    a = get_airport(db, icao)
    now = utcnow()
    max_x = float(_cfg(db, "weather.max_crosswind_kt", 30))
    s = _wx_summary(db, a, now, max_x)
    s["history"] = [{"t": r.obs_time_utc.isoformat(), "raw": r.raw, "wind_dir": r.wind_dir_deg, "wind": r.wind_speed_kt,
                     "gust": r.wind_gust_kt, "vis": r.visibility_m, "temp": r.temperature_c, "dew": r.dewpoint_c,
                     "qnh": r.qnh_hpa, "ceiling": r.ceiling_ft, "category": r.flight_category, "severity": r.severity,
                     "source": r.data_source}
                    for r in db.scalars(select(WeatherRecord).where(
                        WeatherRecord.airport_id == a.id, WeatherRecord.kind == "METAR", WeatherRecord.obs_time_utc >= now - timedelta(hours=hours),
                        WeatherRecord.obs_time_utc <= now).order_by(WeatherRecord.obs_time_utc)).all()]
    return s


class DecodeIn(BaseModel):
    raw: str = Field(min_length=6, max_length=600)


@router.post("/weather/decode")
def weather_decode(body: DecodeIn, _: User = Depends(current_user)):
    return weather.decode_metar(body.raw)


@router.post("/weather/refresh")
def weather_refresh(request: Request, db: Session = Depends(get_db), user: User = Depends(require("weather.write"))):
    """Fetch live METAR/TAF when enabled, else (re)generate the simulated current hour."""
    from .. import jobs

    res = jobs.refresh_weather(db, force=True)
    audit(db, user, "REFRESH", "weather", None, res, request)
    db.commit()
    return res


class MetarIn(BaseModel):
    icao: str
    raw: str = Field(min_length=10, max_length=600)


@router.post("/weather/observations", status_code=201)
def add_observation(body: MetarIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("weather.write"))):
    a = get_airport(db, body.icao)
    d = weather.decode_metar(body.raw)
    t = utcnow().replace(second=0, microsecond=0)
    r = WeatherRecord(airport_id=a.id, kind="METAR", obs_time_utc=t, raw=body.raw.strip(), wind_dir_deg=d["wind_dir_deg"],
                      wind_speed_kt=d["wind_speed_kt"], wind_gust_kt=d["wind_gust_kt"], visibility_m=d["visibility_m"],
                      temperature_c=d["temperature_c"], dewpoint_c=d["dewpoint_c"], qnh_hpa=d["qnh_hpa"],
                      clouds=" ".join(f"{c}{b // 100:03d}" for c, b, _ in d["clouds"]) or "NSC", ceiling_ft=d["ceiling_ft"],
                      phenomena=" ".join(d["phenomena"]), flight_category=d["flight_category"], severity=d["severity"],
                      data_source="MANUAL")
    db.merge(r)
    audit(db, user, "CREATE", "weather", a.icao, {"raw": body.raw}, request)
    db.commit()
    return d


# --------------------------------------------------------------------------- NOTAMs


@router.get("/notams")
def list_notams(airport: str | None = None, active_only: bool = True, db: Session = Depends(get_db), _: User = Depends(current_user)):
    q = select(Notam).options(joinedload(Notam.airport)).order_by(Notam.valid_from_utc.desc())
    if airport:
        a = get_airport(db, airport)
        q = q.where(Notam.airport_id == a.id)
    if active_only:
        q = q.where(Notam.active.is_(True), Notam.valid_to_utc >= utcnow())
    return [serial.notam(n) for n in db.scalars(q).unique().all()]


class NotamIn(BaseModel):
    notam_id: str | None = None
    airport: str
    category: str = "AD"
    subject: str = Field(min_length=3, max_length=120)
    text: str = Field(min_length=3)
    valid_from_utc: datetime
    valid_to_utc: datetime
    severity: str = "INFO"
    runway: str | None = None
    active: bool = True
    close_runway: bool = False

    @field_validator("valid_from_utc", "valid_to_utc")
    @classmethod
    def naive(cls, v):
        return v.replace(tzinfo=None)

    @field_validator("severity")
    @classmethod
    def sev(cls, v):
        v = v.upper()
        if v not in ("INFO", "CAUTION", "CRITICAL"):
            raise ValueError("severity must be INFO, CAUTION or CRITICAL")
        return v


def _apply_notam_runway(db: Session, a: Airport, body: NotamIn) -> None:
    if body.close_runway and body.runway:
        for r in a.runways:
            if r.designator == body.runway:
                r.status = "CLOSED" if body.active else "OPEN"


@router.post("/notams", status_code=201)
def create_notam(body: NotamIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("notams.write"))):
    a = get_airport(db, body.airport)
    if body.valid_to_utc <= body.valid_from_utc:
        raise HTTPException(422, "valid_to must be after valid_from")
    nid = body.notam_id or f"M{(db.scalar(select(func.count()).select_from(Notam)) or 0) + 2000}/{utcnow().year % 100:02d}"
    if db.scalars(select(Notam).where(Notam.notam_id == nid)).first():
        raise HTTPException(409, "NOTAM id exists")
    n = Notam(notam_id=nid, airport_id=a.id, category=body.category.upper(), subject=body.subject, text=body.text,
              valid_from_utc=body.valid_from_utc, valid_to_utc=body.valid_to_utc, severity=body.severity, runway=body.runway,
              active=body.active, data_source="MANUAL")
    db.add(n)
    _apply_notam_runway(db, a, body)
    db.flush()
    audit(db, user, "CREATE", "notam", n.id, {"notam_id": nid, "airport": a.icao}, request)
    db.commit()
    return serial.notam(n)


@router.put("/notams/{nid}")
def update_notam(nid: int, body: NotamIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("notams.write"))):
    n = db.get(Notam, nid)
    if not n:
        raise HTTPException(404, "NOTAM not found")
    a = get_airport(db, body.airport)
    n.airport_id, n.category, n.subject, n.text = a.id, body.category.upper(), body.subject, body.text
    n.valid_from_utc, n.valid_to_utc, n.severity, n.runway, n.active = body.valid_from_utc, body.valid_to_utc, body.severity, body.runway, body.active
    _apply_notam_runway(db, a, body)
    audit(db, user, "UPDATE", "notam", nid, body.model_dump(mode="json"), request)
    db.commit()
    return serial.notam(n)


@router.delete("/notams/{nid}")
def cancel_notam(nid: int, request: Request, db: Session = Depends(get_db), user: User = Depends(require("notams.write"))):
    n = db.get(Notam, nid)
    if not n:
        raise HTTPException(404, "NOTAM not found")
    n.active = False
    audit(db, user, "CANCEL", "notam", nid, None, request)
    db.commit()
    return {"cancelled": nid}
