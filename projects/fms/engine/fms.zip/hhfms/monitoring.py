"""Intelligent flight monitoring: rule- and statistics-based operational alerts.

Each run evaluates the current situation, creates new alerts (de-duplicated by
key) and auto-resolves alerts whose condition has cleared.
"""
from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import analytics, conflicts, weather
from .models import Aircraft, Airport, Flight, OperationalAlert, SystemConfig, WeatherRecord, utcnow


def _cfg(db: Session, key: str, default):
    row = db.get(SystemConfig, key)
    return row.value if row and row.value is not None else default


def evaluate(db: Session, now: datetime | None = None) -> list[dict]:
    """Return the list of alert candidates for the current situation."""
    now = now or utcnow()
    out: list[dict] = []
    abn = float(_cfg(db, "ops.abnormal_delay_min", 45))
    dur_pct = float(_cfg(db, "ops.unusual_duration_pct", 20))
    max_bh = float(_cfg(db, "ops.max_daily_block_hours", 14))
    min_bh = float(_cfg(db, "ops.min_daily_block_hours", 3))

    # ---- route delay statistics from the last 30 days (for z-scores)
    hist = analytics.flights_df(db, now - timedelta(days=30), now)
    stats = {}
    if not hist.empty:
        g = hist[hist["atd"].notna()].groupby("route")["dep_delay"]
        stats = {r: (float(s.mean()), float(s.std() or 1.0)) for r, s in g}
        blk = hist[hist["status"] == "ARRIVED"].groupby("route")["actual_block"]
        blk_stats = {r: (float(s.mean()), float(s.std() or 1.0)) for r, s in blk}
    else:
        blk_stats = {}

    # ---- abnormal delays (open flights in the next 12 h / in progress)
    open_f = db.scalars(select(Flight).where(
        Flight.std_utc >= now - timedelta(hours=12), Flight.std_utc <= now + timedelta(hours=12),
        Flight.status.notin_(("CANCELLED", "ARRIVED", "DIVERTED")),
    )).all()
    for f in open_f:
        dep = f.atd_utc or f.etd_utc
        if not dep:
            continue
        delay = (dep - f.std_utc).total_seconds() / 60
        route = f"{f.origin.icao}-{f.destination.icao}"
        mu, sd = stats.get(route, (10.0, 15.0))
        z = (delay - mu) / max(sd, 5.0)
        if delay >= abn or (delay >= 25 and z >= 2.5):
            sev = "CRITICAL" if delay >= 120 else "WARNING"
            out.append({
                "category": "DELAY", "severity": sev, "flight_id": f.id, "aircraft_id": f.aircraft_id,
                "title": f"{f.flight_number} {route} delayed {delay:.0f} min",
                "detail": f"Expected off-block {dep:%H:%M}Z vs STD {f.std_utc:%H:%M}Z. Route mean {mu:.0f} min (z={z:.1f}). "
                          f"Reason: {f.delay_reason or 'not yet coded'}.",
                "key": f"DELAY:{f.id}:{'C' if sev == 'CRITICAL' else 'W'}",
            })

    # ---- unusual durations (completed in the last 24 h)
    done = db.scalars(select(Flight).where(Flight.ata_utc >= now - timedelta(hours=24), Flight.status == "ARRIVED")).all()
    for f in done:
        sched = (f.sta_utc - f.std_utc).total_seconds() / 60
        act = (f.ata_utc - f.atd_utc).total_seconds() / 60 if f.atd_utc else None
        if act is None or sched <= 0:
            continue
        dev = (act - sched) / sched * 100
        route = f"{f.origin.icao}-{f.destination.icao}"
        mu, sd = blk_stats.get(route, (sched, sched * 0.08))
        z = (act - mu) / max(sd, 3.0)
        if abs(dev) >= dur_pct or abs(z) >= 3:
            out.append({
                "category": "DURATION", "severity": "WARNING" if abs(dev) >= dur_pct else "INFO", "flight_id": f.id,
                "aircraft_id": f.aircraft_id,
                "title": f"{f.flight_number} unusual block time {act:.0f} min ({dev:+.0f}% vs schedule)",
                "detail": f"Scheduled {sched:.0f} min, route mean {mu:.0f} +/- {sd:.0f} min (z={z:.1f}).",
                "key": f"DURATION:{f.id}",
            })

    # ---- scheduling conflicts in the next 48 h
    for c in conflicts.detect_conflicts(db, now - timedelta(hours=2), now + timedelta(hours=48)):
        if c["severity"] == "INFO":
            continue
        out.append({
            "category": "CONFLICT", "severity": c["severity"], "flight_id": c["flight_ids"][0],
            "title": f"{c['type'].replace('_', ' ').title()}: {', '.join(c['flights'][:2])}", "detail": c["message"],
            "key": f"CONFLICT:{c['type']}:{'-'.join(map(str, c['flight_ids']))}",
        })

    # ---- aircraft utilisation (today, scheduled)
    d0 = datetime.combine(now.date(), datetime.min.time())
    today = analytics.flights_df(db, d0, d0 + timedelta(days=1))
    for ac in db.scalars(select(Aircraft).where(Aircraft.operational_status == "ACTIVE")).all():
        part = today[(today["aircraft_id"] == ac.id) & (today["status"] != "CANCELLED")] if not today.empty else today
        bh = float(part["sched_block"].sum() / 60) if not part.empty else 0.0
        if bh > max_bh:
            out.append({"category": "UTILISATION", "severity": "WARNING", "aircraft_id": ac.id,
                        "title": f"{ac.registration} over-utilised: {bh:.1f} block hours planned today",
                        "detail": f"Exceeds the {max_bh:.0f} h planning limit; maintenance and crew margins reduced.",
                        "key": f"UTIL_HIGH:{ac.id}:{now.date()}"})
        elif bh < min_bh:
            out.append({"category": "UTILISATION", "severity": "INFO", "aircraft_id": ac.id,
                        "title": f"{ac.registration} under-utilised: {bh:.1f} block hours today",
                        "detail": "Serviceable aircraft with little or no flying - available as operational spare.",
                        "key": f"UTIL_LOW:{ac.id}:{now.date()}"})
        if ac.maintenance_status in ("DUE", "OVERDUE"):
            out.append({"category": "MAINTENANCE", "severity": "CRITICAL" if ac.maintenance_status == "OVERDUE" else "WARNING",
                        "aircraft_id": ac.id,
                        "title": f"{ac.registration} check {ac.maintenance_status.lower()} ({ac.hours_since_check:.0f}/{ac.check_interval_hours:.0f} FH)",
                        "detail": "Schedule the next A-check before the interval is exceeded.",
                        "key": f"MX:{ac.id}:{ac.maintenance_status}"})

    # ---- weather at airports with traffic in the next 6 h
    max_x = float(_cfg(db, "weather.max_crosswind_kt", 30))
    busy = {f.origin_id for f in open_f} | {f.destination_id for f in open_f}
    for ap in db.scalars(select(Airport).where(Airport.id.in_(busy))).all():
        wx = db.scalars(select(WeatherRecord).where(
            WeatherRecord.airport_id == ap.id, WeatherRecord.kind == "METAR", WeatherRecord.obs_time_utc <= now,
        ).order_by(WeatherRecord.obs_time_utc.desc())).first()
        if not wx or wx.obs_time_utc < now - timedelta(hours=3):
            continue
        d = weather.decode_metar(wx.raw)
        rw = weather.runway_analysis([{"designator": r.designator, "heading_deg": r.heading_deg, "length_m": r.length_m,
                                       "status": r.status} for r in ap.runways], d["wind_dir_deg"], d["wind_speed_kt"],
                                     d["wind_gust_kt"], max_x)
        for w in weather.warnings_for(ap.icao, d, max_x, rw):
            out.append({"category": "WEATHER", "severity": w["level"], "airport_id": ap.id,
                        "title": w["text"], "detail": wx.raw, "key": f"WX:{ap.id}:{w['code']}"})
    return out


def run(db: Session, now: datetime | None = None) -> dict:
    now = now or utcnow()
    cands = evaluate(db, now)
    keys = {c["key"] for c in cands}
    open_alerts = db.scalars(select(OperationalAlert).where(OperationalAlert.resolved.is_(False))).all()
    existing = {a.dedupe_key: a for a in open_alerts}
    created = 0
    for c in cands:
        if c["key"] in existing:
            a = existing[c["key"]]
            a.title, a.detail = c["title"], c["detail"]
            continue
        db.add(OperationalAlert(
            category=c["category"], severity=c["severity"], title=c["title"][:160], detail=c["detail"],
            flight_id=c.get("flight_id"), aircraft_id=c.get("aircraft_id"), airport_id=c.get("airport_id"),
            dedupe_key=c["key"], created_at=now,
        ))
        created += 1
    resolved = 0
    for a in open_alerts:
        if a.dedupe_key not in keys:
            a.resolved = True
            resolved += 1
    db.flush()
    return {"evaluated": len(cands), "created": created, "resolved": resolved}
