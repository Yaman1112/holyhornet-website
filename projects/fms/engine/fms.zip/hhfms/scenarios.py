"""Scenario simulation: what-if analysis of a day of operations.

A deterministic flight-level model runs twice - baseline and scenario - over
the same day. Each flight becomes ready at max(STD + own delay, inbound
arrival + minimum turnaround), then queues for a departure slot at its origin
and an arrival slot at its destination. Airport hourly capacity is shared with
background traffic from other operators. Disruptions alter capacities, tails,
cancellations or initial delays, and the difference is the consequence.
"""
from __future__ import annotations

import math
import random
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload, selectinload

from . import config, perf, weather
from .geo import distance_nm
from .models import Aircraft, Airport, Flight, FlightCrewAssignment, SystemConfig

MAX_DELAY_MIN = 300  # beyond this a flight is cancelled in the model


def _bg_profile(h: int) -> float:
    """Background (other operators) share of capacity used by hour of day (UTC, European pattern)."""
    if 5 <= h <= 8 or 15 <= h <= 18:
        return 0.82
    if 9 <= h <= 14 or 19 <= h <= 20:
        return 0.68
    if h in (4, 21, 22):
        return 0.4
    return 0.08


@dataclass
class Scenario:
    day: date
    traffic_increase_pct: float = 0.0
    traffic_airports: list[str] = field(default_factory=list)  # empty = all
    weather: list[dict] = field(default_factory=list)  # {airport, start_hour, end_hour, severity: MODERATE|SEVERE}
    runway_closures: list[dict] = field(default_factory=list)  # {airport, runway, start_hour, end_hour}
    aircraft_unavailable: list[dict] = field(default_factory=list)  # {registration, from_hour}
    cancel_flights: list[str] = field(default_factory=list)
    delayed_rotations: list[dict] = field(default_factory=list)  # {registration, delay_min}
    name: str = "Scenario"

    @classmethod
    def from_dict(cls, d: dict) -> "Scenario":
        day = d.get("day")
        day = date.fromisoformat(day) if isinstance(day, str) else (day or datetime.utcnow().date())
        return cls(
            day=day, traffic_increase_pct=float(d.get("traffic_increase_pct") or 0),
            traffic_airports=[a.upper() for a in d.get("traffic_airports") or []],
            weather=d.get("weather") or [], runway_closures=d.get("runway_closures") or [],
            aircraft_unavailable=d.get("aircraft_unavailable") or [],
            cancel_flights=[f.upper().replace(" ", "") for f in d.get("cancel_flights") or []],
            delayed_rotations=d.get("delayed_rotations") or [], name=d.get("name") or "Scenario",
        )


class _Airport:
    def __init__(self, ap: Airport):
        self.ap = ap
        open_rw = [r for r in ap.runways if r.status != "CLOSED"]
        self.n_rwy = max(1, len(open_rw))
        self.rwy = {r.designator: r for r in open_rw}
        self.dep_cap = {h: float(ap.capacity_dep_per_hour) for h in range(48)}
        self.arr_cap = {h: float(ap.capacity_arr_per_hour) for h in range(48)}
        self.bg_dep = {h: ap.capacity_dep_per_hour * _bg_profile(h % 24) for h in range(48)}
        self.bg_arr = {h: ap.capacity_arr_per_hour * _bg_profile(h % 24) for h in range(48)}
        self.base_dep = dict(self.dep_cap)
        self.base_arr = dict(self.arr_cap)
        self.used_dep: dict[int, float] = defaultdict(float)
        self.used_arr: dict[int, float] = defaultdict(float)
        self.taxi_extra = {h: 0.0 for h in range(48)}
        self.closed = {h: False for h in range(48)}

    def slot(self, t: datetime, base: datetime, arr: bool) -> datetime | None:
        """Earliest time >= t with capacity; None when no slot within MAX_DELAY_MIN."""
        h = int((t - base).total_seconds() // 3600)
        start = t
        while h < 48:
            if h < 0:
                h = 0
                start = base
                continue
            cap = (self.arr_cap if arr else self.dep_cap)[h]
            cap0 = (self.base_arr if arr else self.base_dep)[h]
            # other operators lose capacity in the same proportion (fair share of a reduced capacity)
            bg = (self.bg_arr if arr else self.bg_dep)[h] * (cap / cap0 if cap0 else 1.0)
            used = (self.used_arr if arr else self.used_dep)
            if not self.closed[h] and used[h] + bg + 1 <= cap:
                used[h] += 1
                # spread movements within the hour proportional to load
                frac = min(0.95, (used[h] + bg) / max(cap, 1))
                hour_start = base + timedelta(hours=h)
                slot_t = max(start, hour_start + timedelta(minutes=60 * frac * 0.5))
                if slot_t < start:
                    slot_t = start
                if (slot_t - t).total_seconds() / 60 > MAX_DELAY_MIN:
                    return None
                return slot_t
            h += 1
            start = base + timedelta(hours=h)
            if (start - t).total_seconds() / 60 > MAX_DELAY_MIN:
                return None
        return None


def _load(db: Session, day: date):
    d0 = datetime.combine(day, datetime.min.time())
    flights = db.scalars(
        select(Flight).options(joinedload(Flight.origin).selectinload(Airport.runways),
                               joinedload(Flight.destination).selectinload(Airport.runways),
                               joinedload(Flight.aircraft).joinedload(Aircraft.type), joinedload(Flight.aircraft_type),
                               selectinload(Flight.crew).joinedload(FlightCrewAssignment.crew_member))
        .where(Flight.std_utc >= d0, Flight.std_utc < d0 + timedelta(days=1)).order_by(Flight.std_utc)
    ).unique().all()
    airports = db.scalars(select(Airport).options(selectinload(Airport.runways))).all()
    return d0, flights, airports


def _run(d0: datetime, flights: list[Flight], airports: list[Airport], sc: Scenario | None, max_fdp: float) -> dict:
    aps = {a.id: _Airport(a) for a in airports}
    icao_to_id = {a.icao: a.id for a in airports}
    notes: list[str] = []
    if sc:
        mult = 1 + sc.traffic_increase_pct / 100
        for a in aps.values():
            if not sc.traffic_airports or a.ap.icao in sc.traffic_airports:
                for h in range(48):
                    a.bg_dep[h] *= mult
                    a.bg_arr[h] *= mult
        for w in sc.weather:
            a = aps.get(icao_to_id.get(str(w.get("airport", "")).upper()))
            if not a:
                continue
            sev = str(w.get("severity", "MODERATE")).upper()
            factor = {"MODERATE": 0.7, "SEVERE": 0.45, "EXTREME": 0.0}.get(sev, 0.7)
            for h in range(int(w.get("start_hour", 0)), int(w.get("end_hour", 24))):
                a.dep_cap[h] *= factor
                a.arr_cap[h] *= factor
                a.taxi_extra[h] = 6 if sev == "MODERATE" else 14
                if factor == 0:
                    a.closed[h] = True
        for rc in sc.runway_closures:
            a = aps.get(icao_to_id.get(str(rc.get("airport", "")).upper()))
            if not a:
                continue
            rwy = rc.get("runway")
            n_closed = a.n_rwy if rwy in (None, "", "ALL") else (1 if rwy in a.rwy else 0)
            remaining = max(0, a.n_rwy - n_closed)
            factor = 0.0 if remaining == 0 else (remaining / a.n_rwy) ** 0.7 if a.n_rwy > 1 else 0.0
            if a.n_rwy > 1 and remaining == 1:
                factor = max(factor, 0.55)  # single-runway mixed mode
            for h in range(int(rc.get("start_hour", 0)), int(rc.get("end_hour", 24))):
                a.dep_cap[h] *= factor
                a.arr_cap[h] *= factor
                if factor == 0:
                    a.closed[h] = True

    unavailable = {}
    delayed_tail = {}
    cancel = set()
    if sc:
        for u in sc.aircraft_unavailable:
            unavailable[str(u.get("registration", "")).upper()] = d0 + timedelta(hours=float(u.get("from_hour", 0)))
        for r in sc.delayed_rotations:
            delayed_tail[str(r.get("registration", "")).upper()] = float(r.get("delay_min", 60))
        cancel = set(sc.cancel_flights)

    # tail reassignment for unavailable aircraft
    tail_of: dict[int, str | None] = {f.id: (f.aircraft.registration if f.aircraft else None) for f in flights}
    swaps = []
    if unavailable:
        for reg, t_from in unavailable.items():
            affected = [f for f in flights if tail_of[f.id] == reg and f.std_utc >= t_from]
            if not affected:
                continue
            t_icao = affected[0].aircraft.type.icao if affected[0].aircraft else affected[0].aircraft_type.icao
            pool = [s for s in _SPARES.get(t_icao, []) if s not in unavailable and s not in [x[1] for x in swaps]]
            if pool:
                sp = pool[0]
                for f in affected:
                    tail_of[f.id] = sp
                swaps.append((reg, sp, len(affected)))
                notes.append(f"{reg} unavailable from {t_from:%H:%M}Z: {len(affected)} sectors re-planned on spare {sp} "
                             f"(ferry/positioning not modelled).")
            else:
                for f in affected:
                    cancel.add(f.flight_number)
                notes.append(f"{reg} unavailable from {t_from:%H:%M}Z: no spare {t_icao} - {len(affected)} sectors cancelled.")

    flying = {tail_of[f.id] for f in flights if tail_of[f.id]}
    for reg in list(delayed_tail):
        if reg not in flying:
            notes.append(f"{reg} has no flights on {d0:%d %b} - rotation delay not applied.")
    for reg in unavailable:
        if reg not in {f.aircraft.registration for f in flights if f.aircraft}:
            notes.append(f"{reg} has no flights on {d0:%d %b} - unavailability has no effect.")
    rng_cache: dict[int, float] = {}
    tail_in: dict[str, tuple[datetime, int]] = {}
    results = []
    hubs_pair_cancel: set[str] = set()
    for f in flights:
        reg = tail_of[f.id]
        r = random.Random(weather._h(config.settings.seed, "scen", f.id))
        own = rng_cache.setdefault(f.id, max(-3.0, r.expovariate(1 / 8.0) - 4.0))
        o, d = aps[f.origin_id], aps[f.destination_id]
        t = f.aircraft.type if f.aircraft else f.aircraft_type
        res = {"flight_id": f.id, "flight_number": f.flight_number, "route": f"{f.origin.icao}-{f.destination.icao}",
               "registration": reg, "std": f.std_utc, "sta": f.sta_utc, "pax": f.pax_booked, "status": "OPERATED",
               "reason": None, "dep_delay": 0.0, "arr_delay": 0.0, "reactionary": 0.0}
        if f.status == "CANCELLED" or f.flight_number in cancel or f.flight_number in hubs_pair_cancel:
            res["status"] = "CANCELLED"
            res["reason"] = "Already cancelled" if f.status == "CANCELLED" else "Cancelled in scenario"
            # cancel the paired return leg
            _pair_cancel(f, flights, hubs_pair_cancel)
            results.append(res)
            continue
        ready = f.std_utc + timedelta(minutes=own)
        if reg in delayed_tail:
            ready += timedelta(minutes=delayed_tail.pop(reg))
            res["reason"] = "Initial rotation delay"
        react = 0.0
        if reg and reg in tail_in:
            prev_in, mt = tail_in[reg]
            r2 = prev_in + timedelta(minutes=mt)
            if r2 > ready:
                react = (r2 - max(ready, f.std_utc)).total_seconds() / 60
                ready = r2
        h = int((ready - d0).total_seconds() // 3600)
        taxi_out = perf.TAXI_OUT_MIN + o.taxi_extra.get(max(0, min(47, h)), 0)
        off_req = ready + timedelta(minutes=taxi_out)
        off = o.slot(off_req, d0, arr=False)
        if off is None:
            res["status"] = "CANCELLED"
            res["reason"] = f"No departure slot at {f.origin.icao} within {MAX_DELAY_MIN // 60} h"
            _pair_cancel(f, flights, hubs_pair_cancel)
            results.append(res)
            continue
        out_t = off - timedelta(minutes=taxi_out)
        if out_t < ready:
            out_t = ready
        dist = distance_nm(f.origin.lat, f.origin.lon, f.destination.lat, f.destination.lon)
        air = perf.airborne_minutes(dist, t.cruise_ktas)
        on_req = off + timedelta(minutes=air)
        on = d.slot(on_req, d0, arr=True)
        if on is None:
            res["status"] = "DIVERTED"
            res["reason"] = f"No arrival capacity at {f.destination.icao} - diversion"
            on = on_req + timedelta(minutes=45)
        hold = (on - on_req).total_seconds() / 60
        hi = int((on - d0).total_seconds() // 3600)
        inn = on + timedelta(minutes=perf.TAXI_IN_MIN + d.taxi_extra.get(max(0, min(47, hi)), 0))
        res.update({
            "out": out_t, "off": off, "on": on, "in": inn,
            "dep_delay": max(0.0, (out_t - f.std_utc).total_seconds() / 60),
            "arr_delay": max(0.0, (inn - f.sta_utc).total_seconds() / 60),
            "reactionary": react, "holding": hold, "atc_wait": max(0.0, (off - off_req).total_seconds() / 60),
        })
        if res["status"] == "DIVERTED" and reg:
            tail_in[reg] = (inn + timedelta(minutes=180), t.min_turnaround_min)
        elif reg:
            mt = t.min_turnaround_min if f.destination_id != f.origin_id else 30
            tail_in[reg] = (inn, mt)
        results.append(res)

    # crew FDP exceedances under this scenario
    by_flight = {r["flight_id"]: r for r in results}
    crew_duty: dict[str, list[dict]] = defaultdict(list)
    for f in flights:
        rr = by_flight[f.id]
        if rr["status"] == "CANCELLED" or "out" not in rr:
            continue
        for c in f.crew:
            crew_duty[c.crew_member.employee_no].append(rr)
    fdp_viol = []
    for emp, legs in crew_duty.items():
        legs.sort(key=lambda r: r["out"])
        start = legs[0]["out"] - timedelta(minutes=60)
        end = legs[-1]["in"] + timedelta(minutes=30)
        hrs = (end - start).total_seconds() / 3600
        if hrs > max_fdp and len(legs) > 1:
            fdp_viol.append({"crew": emp, "fdp_hours": round(hrs, 1)})

    # airport load profile (for charts)
    profile = {}
    for a in aps.values():
        tot_used = sum(a.used_dep.values()) + sum(a.used_arr.values())
        if tot_used == 0:
            continue
        profile[a.ap.icao] = [
            {"hour": h, "dep_capacity": round(a.dep_cap[h], 1), "arr_capacity": round(a.arr_cap[h], 1),
             "background": round(a.bg_dep[h] + a.bg_arr[h], 1), "network": a.used_dep.get(h, 0) + a.used_arr.get(h, 0),
             "closed": a.closed[h]} for h in range(24)
        ]
    return {"flights": results, "fdp": fdp_viol, "profile": profile, "notes": notes}


def _pair_cancel(f: Flight, flights: list[Flight], out: set[str]) -> None:
    """When an outbound sector is cancelled, its return sector (same tail, next leg) is cancelled too."""
    if not f.aircraft_id:
        return
    nxt = [g for g in flights if g.aircraft_id == f.aircraft_id and g.std_utc > f.std_utc]
    if nxt and nxt[0].origin_id == f.destination_id and f.leg_seq % 2 == 1:
        out.add(nxt[0].flight_number)


_SPARES: dict[str, list[str]] = {}


def _summary(run: dict, thr: float) -> dict:
    fl = run["flights"]
    op = [r for r in fl if r["status"] != "CANCELLED"]
    canc = [r for r in fl if r["status"] == "CANCELLED"]
    div = [r for r in fl if r["status"] == "DIVERTED"]
    delayed = [r for r in op if r["dep_delay"] > thr]
    tot = sum(r["dep_delay"] for r in op)
    return {
        "flights": len(fl), "operated": len(op), "cancelled": len(canc), "diverted": len(div), "delayed": len(delayed),
        "total_delay_min": round(tot), "avg_delay_min": round(tot / len(op), 1) if op else 0,
        "otp_departure": round(sum(1 for r in op if r["dep_delay"] <= thr) / len(op) * 100, 1) if op else None,
        "otp_arrival": round(sum(1 for r in op if r["arr_delay"] <= thr) / len(op) * 100, 1) if op else None,
        "reactionary_delay_min": round(sum(r["reactionary"] for r in op)),
        "pax_affected": sum(r["pax"] for r in canc) + sum(r["pax"] for r in delayed),
        "pax_cancelled": sum(r["pax"] for r in canc),
        "crew_fdp_exceedances": len(run["fdp"]),
    }


def simulate(db: Session, params: dict) -> dict:
    sc = Scenario.from_dict(params)
    d0, flights, airports = _load(db, sc.day)
    if not flights:
        raise ValueError(f"No flights on {sc.day}")
    # spares = active aircraft without flights that day
    used = {f.aircraft_id for f in flights if f.aircraft_id}
    _SPARES.clear()
    for ac in db.scalars(select(Aircraft).options(joinedload(Aircraft.type)).where(Aircraft.operational_status == "ACTIVE")).all():
        if ac.id not in used:
            _SPARES.setdefault(ac.type.icao, []).append(ac.registration)
    thr_row = db.get(SystemConfig, "ops.on_time_threshold_min")
    thr = float(thr_row.value) if thr_row else 15
    fdp_row = db.get(SystemConfig, "crew.max_fdp_hours")
    max_fdp = float(fdp_row.value) if fdp_row else 13
    base = _run(d0, flights, airports, None, max_fdp)
    scen = _run(d0, flights, airports, sc, max_fdp)
    bs, ss = _summary(base, thr), _summary(scen, thr)
    delta = {k: (ss[k] - bs[k]) if isinstance(ss[k], (int, float)) and isinstance(bs[k], (int, float)) else None for k in ss}

    bmap = {r["flight_id"]: r for r in base["flights"]}
    changed = []
    for r in scen["flights"]:
        b = bmap[r["flight_id"]]
        if r["status"] != b["status"] or abs(r["dep_delay"] - b["dep_delay"]) >= 5 or r["registration"] != b["registration"]:
            changed.append({
                "flight_id": r["flight_id"], "flight_number": r["flight_number"], "route": r["route"],
                "std": r["std"].isoformat(), "registration": r["registration"], "baseline_registration": b["registration"],
                "baseline_status": b["status"], "status": r["status"], "baseline_delay": round(b["dep_delay"]),
                "delay": round(r["dep_delay"]), "delta": round(r["dep_delay"] - b["dep_delay"]), "reason": r["reason"],
                "pax": r["pax"],
            })
    changed.sort(key=lambda x: (x["status"] == "OPERATED", -x["delta"]))

    consequences = list(scen["notes"])
    if delta["cancelled"]:
        consequences.append(f"{delta['cancelled']:+d} cancellations ({ss['pax_cancelled'] - bs['pax_cancelled']:+,d} passengers without a flight).")
    if delta["total_delay_min"]:
        consequences.append(f"Total departure delay {delta['total_delay_min']:+,d} min; average {delta['avg_delay_min']:+.1f} min per operated flight.")
    if delta["otp_departure"] is not None and abs(delta["otp_departure"]) >= 0.1:
        consequences.append(f"Departure OTP {bs['otp_departure']}% -> {ss['otp_departure']}% ({delta['otp_departure']:+.1f} pts).")
    if delta["reactionary_delay_min"]:
        consequences.append(f"Reactionary (knock-on) delay {delta['reactionary_delay_min']:+,d} min through aircraft rotations.")
    if delta["diverted"]:
        consequences.append(f"{delta['diverted']:+d} diversions due to arrival capacity.")
    if delta["crew_fdp_exceedances"] > 0:
        consequences.append(f"{delta['crew_fdp_exceedances']} additional crew duties exceed the {max_fdp:.0f} h FDP limit - standby crew required.")
    if not consequences:
        consequences.append("No material operational impact detected for this scenario.")

    def ser(run):
        return {k: v for k, v in run.items() if k != "flights"}

    return {
        "scenario": {**params, "day": sc.day.isoformat()},
        "baseline": bs, "result": ss, "delta": delta, "consequences": consequences,
        "changed_flights": changed[:300], "airport_profiles": scen["profile"],
        "baseline_profiles": base["profile"], "crew_fdp": scen["fdp"],
        "disclaimer": "Model-based what-if estimate for planning discussion; not an operational forecast.",
    }
