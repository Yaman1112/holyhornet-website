"""Operational analytics (pandas). All delay figures are in minutes.

Definitions
* departure delay  = actual off-block (ATD) - STD
* arrival delay    = actual on-block (ATA) - STA
* on-time          = delay <= threshold (default 15 min), measured on operated flights
* completion rate  = operated (ARRIVED + DIVERTED + in progress) / (scheduled - not yet due)
* cancellation rate = CANCELLED / flights due
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from .models import Aircraft, AircraftType, Airport, DailyStat, Flight, SystemConfig, utcnow

ACTIVE = ("DEPARTED", "AIRBORNE", "LANDED")


def otp_threshold(db: Session) -> int:
    row = db.get(SystemConfig, "ops.on_time_threshold_min")
    return int(row.value) if row and row.value is not None else 15


def flights_df(
    db: Session,
    start: datetime,
    end: datetime,
    airport: str | None = None,
    aircraft: str | None = None,
    airline_id: int | None = None,
    route: str | None = None,
) -> pd.DataFrame:
    ap = {a.id: a.icao for a in db.scalars(select(Airport)).all()}
    q = select(
        Flight.id, Flight.flight_number, Flight.flight_date, Flight.airline_id, Flight.origin_id, Flight.destination_id,
        Flight.aircraft_id, Flight.aircraft_type_id, Flight.std_utc, Flight.sta_utc, Flight.atd_utc, Flight.takeoff_utc,
        Flight.landing_utc, Flight.ata_utc, Flight.status, Flight.pax_booked, Flight.delay_code, Flight.leg_seq,
        Flight.turnaround_min, Flight.data_source,
    ).where(Flight.std_utc >= start, Flight.std_utc < end)
    if airline_id:
        q = q.where(Flight.airline_id == airline_id)
    rows = db.execute(q).all()
    df = pd.DataFrame(rows, columns=[
        "id", "flight_number", "flight_date", "airline_id", "origin_id", "destination_id", "aircraft_id", "aircraft_type_id",
        "std", "sta", "atd", "takeoff", "landing", "ata", "status", "pax", "delay_code", "leg_seq", "turnaround_min",
        "data_source",
    ])
    if df.empty:
        return df
    df["origin"] = df["origin_id"].map(ap)
    df["destination"] = df["destination_id"].map(ap)
    regs = {a.id: a.registration for a in db.scalars(select(Aircraft)).all()}
    types = {t.id: t.icao for t in db.scalars(select(AircraftType)).all()}
    df["registration"] = df["aircraft_id"].map(regs)
    df["type"] = df["aircraft_type_id"].map(types)
    df["route"] = df["origin"] + "-" + df["destination"]
    for c in ("std", "sta", "atd", "takeoff", "landing", "ata"):
        df[c] = pd.to_datetime(df[c])
    df["dep_delay"] = (df["atd"] - df["std"]).dt.total_seconds() / 60
    df["arr_delay"] = (df["ata"] - df["sta"]).dt.total_seconds() / 60
    df["sched_block"] = (df["sta"] - df["std"]).dt.total_seconds() / 60
    df["actual_block"] = (df["ata"] - df["atd"]).dt.total_seconds() / 60
    df["airborne"] = (df["landing"] - df["takeoff"]).dt.total_seconds() / 60
    if airport:
        df = df[(df["origin"] == airport) | (df["destination"] == airport)]
    if aircraft:
        df = df[df["registration"] == aircraft]
    if route:
        df = df[df["route"] == route]
    return df


def _r(x, n=1):
    if x is None or (isinstance(x, float) and (np.isnan(x) or np.isinf(x))):
        return None
    return round(float(x), n)


def kpis(df: pd.DataFrame, threshold: int = 15, now: datetime | None = None) -> dict:
    now = now or utcnow()
    if df.empty:
        return {"total": 0, "completed": 0, "cancelled": 0, "diverted": 0, "active": 0, "scheduled": 0, "delayed": 0,
                "otp_departure": None, "otp_arrival": None, "avg_departure_delay": None, "avg_arrival_delay": None,
                "completion_rate": None, "cancellation_rate": None, "avg_block_min": None, "pax": 0, "flights_due": 0}
    due = df[df["std"] <= pd.Timestamp(now)]
    dep = df[df["atd"].notna()]
    arr = df[df["ata"].notna() & (df["status"] == "ARRIVED")]
    n_due = len(due)
    canc = int((df["status"] == "CANCELLED").sum())
    canc_due = int((due["status"] == "CANCELLED").sum())
    operated = int(due["status"].isin(("ARRIVED", "DIVERTED", *ACTIVE)).sum())
    return {
        "total": int(len(df)),
        "completed": int((df["status"] == "ARRIVED").sum()),
        "cancelled": canc,
        "diverted": int((df["status"] == "DIVERTED").sum()),
        "active": int(df["status"].isin(ACTIVE).sum()),
        "airborne": int((df["status"] == "AIRBORNE").sum()),
        "scheduled": int(df["status"].isin(("SCHEDULED", "BOARDING")).sum()),
        "delayed": int(((df["status"] == "DELAYED") | (df["dep_delay"] > threshold)).sum()),
        "flights_due": n_due,
        "otp_departure": _r((dep["dep_delay"] <= threshold).mean() * 100) if len(dep) else None,
        "otp_arrival": _r((arr["arr_delay"] <= threshold).mean() * 100) if len(arr) else None,
        "avg_departure_delay": _r(dep["dep_delay"].clip(lower=0).mean()) if len(dep) else None,
        "avg_arrival_delay": _r(arr["arr_delay"].clip(lower=0).mean()) if len(arr) else None,
        "completion_rate": _r(operated / n_due * 100) if n_due else None,
        "cancellation_rate": _r(canc_due / n_due * 100) if n_due else None,
        "avg_block_min": _r(arr["actual_block"].mean()) if len(arr) else None,
        "pax": int(df.loc[df["status"] != "CANCELLED", "pax"].sum()),
    }


def trends(df: pd.DataFrame, freq: str = "D", threshold: int = 15) -> list[dict]:
    if df.empty:
        return []
    rule = {"D": "D", "W": "W-MON", "M": "MS"}[freq]
    g = df.set_index("std").groupby(pd.Grouper(freq=rule))
    out = []
    for period, part in g:
        if part.empty:
            continue
        dep = part[part["atd"].notna()]
        arr = part[part["status"] == "ARRIVED"]
        out.append({
            "period": period.date().isoformat(),
            "flights": int(len(part)),
            "cancelled": int((part["status"] == "CANCELLED").sum()),
            "completed": int((part["status"] == "ARRIVED").sum()),
            "otp_departure": _r((dep["dep_delay"] <= threshold).mean() * 100) if len(dep) else None,
            "otp_arrival": _r((arr["arr_delay"] <= threshold).mean() * 100) if len(arr) else None,
            "avg_departure_delay": _r(dep["dep_delay"].clip(lower=0).mean()) if len(dep) else None,
            "avg_arrival_delay": _r(arr["arr_delay"].clip(lower=0).mean()) if len(arr) else None,
            "pax": int(part.loc[part["status"] != "CANCELLED", "pax"].sum()),
        })
    return out


def route_performance(df: pd.DataFrame, threshold: int = 15) -> list[dict]:
    if df.empty:
        return []
    out = []
    for route, part in df.groupby("route"):
        dep = part[part["atd"].notna()]
        arr = part[part["status"] == "ARRIVED"]
        out.append({
            "route": route, "flights": int(len(part)), "cancelled": int((part["status"] == "CANCELLED").sum()),
            "otp_departure": _r((dep["dep_delay"] <= threshold).mean() * 100) if len(dep) else None,
            "otp_arrival": _r((arr["arr_delay"] <= threshold).mean() * 100) if len(arr) else None,
            "avg_departure_delay": _r(dep["dep_delay"].clip(lower=0).mean()) if len(dep) else None,
            "avg_arrival_delay": _r(arr["arr_delay"].clip(lower=0).mean()) if len(arr) else None,
            "avg_sched_block": _r(part["sched_block"].mean()),
            "avg_actual_block": _r(arr["actual_block"].mean()) if len(arr) else None,
            "pax": int(part.loc[part["status"] != "CANCELLED", "pax"].sum()),
        })
    out.sort(key=lambda r: -r["flights"])
    return out


def airport_traffic(df: pd.DataFrame) -> list[dict]:
    if df.empty:
        return []
    live = df[df["status"] != "CANCELLED"]
    dep = live.groupby("origin").size()
    arr = live.groupby("destination").size()
    delay = live[live["atd"].notna()].groupby("origin")["dep_delay"].apply(lambda s: s.clip(lower=0).mean())
    aps = sorted(set(dep.index) | set(arr.index))
    out = [{"airport": a, "departures": int(dep.get(a, 0)), "arrivals": int(arr.get(a, 0)),
            "movements": int(dep.get(a, 0) + arr.get(a, 0)), "avg_departure_delay": _r(delay.get(a))} for a in aps]
    out.sort(key=lambda r: -r["movements"])
    return out


def delay_causes(df: pd.DataFrame) -> list[dict]:
    names = {"71": "Weather", "81": "ATFM / ATC", "93": "Reactionary (rotation)", "15": "Boarding", "13": "Passenger",
             "63": "Crew", "87": "Airport facilities", "41": "Technical"}
    if df.empty:
        return []
    d = df[(df["dep_delay"] > 5) & df["delay_code"].notna()]
    g = d.groupby("delay_code")["dep_delay"].agg(["count", "sum"])
    out = [{"code": k, "cause": names.get(k, k), "flights": int(v["count"]), "delay_minutes": int(v["sum"])} for k, v in g.iterrows()]
    out.sort(key=lambda r: -r["delay_minutes"])
    return out


def hourly_profile(df: pd.DataFrame) -> list[dict]:
    if df.empty:
        return []
    live = df[df["status"] != "CANCELLED"]
    dep = live.groupby(live["std"].dt.hour).size()
    arr = live.groupby(live["sta"].dt.hour).size()
    return [{"hour": h, "departures": int(dep.get(h, 0)), "arrivals": int(arr.get(h, 0))} for h in range(24)]


def aircraft_utilisation(db: Session, start: datetime, end: datetime) -> list[dict]:
    df = flights_df(db, start, end)
    days = max(1.0, (end - start).total_seconds() / 86400)
    out = []
    for ac in db.scalars(select(Aircraft).order_by(Aircraft.registration)).all():
        part = df[df["aircraft_id"] == ac.id] if not df.empty else df
        flown = part[part["ata"].notna()] if not part.empty else part
        block_h = float(flown["actual_block"].sum() / 60) if not flown.empty else 0.0
        air_h = float(flown["airborne"].sum() / 60) if not flown.empty else 0.0
        sched_h = float(part.loc[part["status"] != "CANCELLED", "sched_block"].sum() / 60) if not part.empty else 0.0
        out.append({
            "aircraft_id": ac.id, "registration": ac.registration, "type": ac.type.icao,
            "operational_status": ac.operational_status, "maintenance_status": ac.maintenance_status,
            "flights": int(len(flown)), "block_hours": round(block_h, 1), "airborne_hours": round(air_h, 1),
            "scheduled_block_hours": round(sched_h, 1), "block_hours_per_day": round(block_h / days, 2),
            "utilisation_pct": round(block_h / (days * 24) * 100, 1),
        })
    return out


def summary(db: Session, start: datetime, end: datetime, **filters) -> dict:
    thr = otp_threshold(db)
    df = flights_df(db, start, end, **filters)
    return {
        "range": {"start": start.isoformat(), "end": end.isoformat()},
        "threshold_min": thr,
        "kpis": kpis(df, thr),
        "daily": trends(df, "D", thr),
        "weekly": trends(df, "W", thr),
        "monthly": trends(df, "M", thr),
        "routes": route_performance(df, thr),
        "airports": airport_traffic(df),
        "delay_causes": delay_causes(df),
        "hourly": hourly_profile(df),
        "data_sources": df["data_source"].value_counts().to_dict() if not df.empty else {},
    }


def dashboard(db: Session, now: datetime | None = None) -> dict:
    now = now or utcnow()
    thr = otp_threshold(db)
    d0 = datetime.combine(now.date(), datetime.min.time())
    today = flights_df(db, d0, d0 + timedelta(days=1))
    k = kpis(today, thr, now)
    n_ac = len(db.scalars(select(Aircraft.id).where(Aircraft.operational_status != "STORED")).all())
    airborne = k.get("airborne", 0)
    hist = flights_df(db, d0 - timedelta(days=13), d0 + timedelta(days=1))
    return {
        "now": now.isoformat(),
        "today": k,
        "aircraft_total": n_ac,
        "aircraft_airborne": airborne,
        "aircraft_on_ground": max(0, n_ac - airborne),
        "hourly_today": hourly_profile(today),
        "trend_14d": trends(hist, "D", thr),
        "delay_causes_today": delay_causes(today),
        "airports_today": airport_traffic(today)[:10],
        "threshold_min": thr,
    }


def rebuild_daily_stats(db: Session, start: date, end: date) -> int:
    thr = otp_threshold(db)
    s = datetime.combine(start, datetime.min.time())
    e = datetime.combine(end, datetime.min.time()) + timedelta(days=1)
    df = flights_df(db, s, e)
    db.execute(delete(DailyStat).where(DailyStat.day >= start, DailyStat.day <= end))
    if df.empty:
        return 0
    rows = []
    df["day"] = df["std"].dt.date

    def agg(part: pd.DataFrame, day, icao: str) -> DailyStat:
        dep = part[part["atd"].notna()]
        arr = part[part["status"] == "ARRIVED"]
        return DailyStat(
            day=day, airport_icao=icao, flights=int(len(part)), completed=int(len(arr)),
            cancelled=int((part["status"] == "CANCELLED").sum()), diverted=int((part["status"] == "DIVERTED").sum()),
            on_time_dep=int((dep["dep_delay"] <= thr).sum()), on_time_arr=int((arr["arr_delay"] <= thr).sum()),
            avg_dep_delay=float(dep["dep_delay"].clip(lower=0).mean()) if len(dep) else 0.0,
            avg_arr_delay=float(arr["arr_delay"].clip(lower=0).mean()) if len(arr) else 0.0,
            block_hours=float(arr["actual_block"].sum() / 60) if len(arr) else 0.0,
            pax=int(part.loc[part["status"] != "CANCELLED", "pax"].sum()),
        )

    for day, part in df.groupby("day"):
        rows.append(agg(part, day, "ALL"))
        for icao, p2 in part.groupby("origin"):
            rows.append(agg(p2, day, icao))
    db.add_all(rows)
    db.flush()
    return len(rows)
