"""Start-up and background jobs (lifecycle simulation, weather, monitoring,
schedule horizon, statistics, automatic backups, model training)."""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import analytics, backup, config, migrations, ml, monitoring, ops, seed, weather
from .db import session_scope
from .models import Airport, SystemConfig, WeatherRecord, utcnow

log = logging.getLogger("hhfms.jobs")
_state = {"last_hour": None, "last_day": None, "last_monitor": 0.0, "training": False}
_stop = threading.Event()


def _cfg(db: Session, key: str, default):
    row = db.get(SystemConfig, key)
    return row.value if row and row.value is not None else default


def refresh_weather(db: Session, force: bool = False, now: datetime | None = None) -> dict:
    """Fill weather up to the current hour: live provider when enabled, simulator otherwise."""
    now = now or utcnow()
    hour = now.replace(minute=0, second=0, microsecond=0)
    last = db.scalar(select(func.max(WeatherRecord.obs_time_utc)).where(WeatherRecord.kind == "METAR",
                                                                         WeatherRecord.data_source == "SIMULATED"))
    start = (last + timedelta(hours=1)) if last else hour - timedelta(hours=48)
    start = max(start, hour - timedelta(days=config.settings.history_days))
    n = seed.seed_weather(db, start, hour) if start <= hour else 0
    live = 0
    if _cfg(db, "weather.live_enabled", False):
        aps = db.scalars(select(Airport)).all()
        icaos = [a.icao for a in aps]
        metars = weather.fetch_live_metars(icaos)
        tafs = weather.fetch_live_tafs(icaos) if metars else {}
        by = {a.icao: a for a in aps}
        for icao, raw in metars.items():
            a = by.get(icao)
            if not a:
                continue
            d = weather.decode_metar(raw)
            t = now.replace(second=0, microsecond=0)
            db.query(WeatherRecord).filter(WeatherRecord.airport_id == a.id, WeatherRecord.kind == "METAR",
                                           WeatherRecord.obs_time_utc == t).delete()
            db.add(WeatherRecord(
                airport_id=a.id, kind="METAR", obs_time_utc=t, raw=raw, wind_dir_deg=d["wind_dir_deg"],
                wind_speed_kt=d["wind_speed_kt"], wind_gust_kt=d["wind_gust_kt"], visibility_m=d["visibility_m"],
                temperature_c=d["temperature_c"], dewpoint_c=d["dewpoint_c"], qnh_hpa=d["qnh_hpa"],
                clouds=" ".join(f"{c}{b // 100:03d}" for c, b, _ in d["clouds"]) or "NSC", ceiling_ft=d["ceiling_ft"],
                phenomena=" ".join(d["phenomena"]), flight_category=d["flight_category"], severity=d["severity"],
                data_source="LIVE"))
            live += 1
        for icao, raw in tafs.items():
            a = by.get(icao)
            if a:
                t = now.replace(second=0, microsecond=0)
                db.query(WeatherRecord).filter(WeatherRecord.airport_id == a.id, WeatherRecord.kind == "TAF",
                                               WeatherRecord.obs_time_utc == t).delete()
                db.add(WeatherRecord(airport_id=a.id, kind="TAF", obs_time_utc=t, raw=raw, data_source="LIVE"))
        db.flush()
    return {"simulated_records": n, "live_metars": live, "live_enabled": bool(_cfg(db, "weather.live_enabled", False)),
            "note": "Live fetch returned no data (offline?) - simulated weather in use" if _cfg(db, "weather.live_enabled", False) and not live else None}


def startup() -> dict:
    """Migrate, seed on first run, catch up after downtime."""
    t0 = time.time()
    applied = migrations.migrate()
    info: dict = {"migrations_applied": applied}
    with session_scope() as db:
        if not seed.is_seeded(db):
            log.info("First start: generating demo dataset ...")
            info["seed"] = seed.seed_all(db)
    with session_scope() as db:
        now = utcnow()
        info["materialised"] = ops.ensure_horizon(db, now)
        refresh_weather(db, now=now)
        info["advanced"] = ops.advance(db, now)
        ops.update_maintenance_status(db, now)
        last_stat = db.execute(select(func.max(analytics.DailyStat.day))).scalar()
        if last_stat is None or last_stat < now.date():
            analytics.rebuild_daily_stats(db, (last_stat or now.date()) - timedelta(days=1), now.date())
    with session_scope() as db:
        monitoring.run(db)
    info["seconds"] = round(time.time() - t0, 1)
    if ml.load() is None and not config.settings.browser:
        threading.Thread(target=_train_bg, daemon=True).start()
    return info


def _train_bg():
    if _state["training"]:
        return
    _state["training"] = True
    try:
        with session_scope() as db:
            ml.train(db)
        log.info("Prediction models trained")
    except Exception as e:  # pragma: no cover
        log.warning("Model training failed: %s", e)
    finally:
        _state["training"] = False


def tick(now: datetime | None = None) -> None:
    now = now or utcnow()
    with session_scope() as db:
        ops.advance(db, now)
    hour = now.replace(minute=0, second=0, microsecond=0)
    if _state["last_hour"] != hour:
        with session_scope() as db:
            refresh_weather(db, now=now)
            ops.update_maintenance_status(db, now)
        _state["last_hour"] = hour
    if _state["last_day"] != now.date():
        with session_scope() as db:
            ops.ensure_horizon(db, now)
            analytics.rebuild_daily_stats(db, now.date() - timedelta(days=2), now.date())
            auto = _cfg(db, "backup.auto_daily", True)
            keep = int(_cfg(db, "backup.keep", 10))
        if auto and _state["last_day"] is not None and not config.settings.browser:
            try:
                backup.create_backup("auto")
                backup.prune(keep)
            except Exception as e:  # pragma: no cover
                log.warning("Automatic backup failed: %s", e)
        if _state["last_day"] is not None and now.weekday() == 0 and not config.settings.browser:
            threading.Thread(target=_train_bg, daemon=True).start()
        _state["last_day"] = now.date()
    if time.time() - _state["last_monitor"] > 120:
        with session_scope() as db:
            monitoring.run(db, now)
        _state["last_monitor"] = time.time()


def loop(period: float = 15.0) -> None:
    _state["last_monitor"] = time.time()
    _state["last_day"] = utcnow().date()
    _state["last_hour"] = utcnow().replace(minute=0, second=0, microsecond=0)
    while not _stop.wait(period):
        try:
            tick()
        except Exception as e:  # pragma: no cover
            log.exception("Background tick failed: %s", e)


def start_background() -> threading.Thread:
    _stop.clear()
    t = threading.Thread(target=loop, name="fms-jobs", daemon=True)
    t.start()
    return t


def stop_background() -> None:
    _stop.set()
