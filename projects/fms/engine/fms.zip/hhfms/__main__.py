"""Command line: python -m hhfms [serve|seed|reset|train|migrate|openapi|backup|create-user]"""
from __future__ import annotations

import argparse
import json
import logging
import sys


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="hhfms", description="HolyHornet Flight Management System backend")
    sub = p.add_subparsers(dest="cmd")
    s = sub.add_parser("serve", help="run the API server (default)")
    s.add_argument("--host")
    s.add_argument("--port", type=int)
    sub.add_parser("migrate", help="apply database migrations")
    sub.add_parser("seed", help="create the demo dataset if the database is empty")
    sub.add_parser("reset", help="DELETE the database and regenerate the demo dataset")
    sub.add_parser("train", help="train prediction models")
    o = sub.add_parser("openapi", help="write the OpenAPI schema to a file")
    o.add_argument("out")
    sub.add_parser("backup", help="create a database backup")
    cu = sub.add_parser("create-user", help="create a user")
    cu.add_argument("username")
    cu.add_argument("role", choices=["ADMIN", "OPS_MANAGER", "DISPATCHER", "ANALYST"])
    cu.add_argument("password")
    args = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    from . import config

    cmd = args.cmd or "serve"
    if cmd == "serve":
        import uvicorn

        from .main import create_app

        host = getattr(args, "host", None) or config.settings.host
        port = getattr(args, "port", None) or config.settings.port
        print(f"HH-FMS backend on http://{host}:{port}  (data: {config.settings.data_dir})", flush=True)
        uvicorn.run(create_app(), host=host, port=port, log_level="warning", ws="websockets-sansio")
        return 0
    from . import migrations
    from .db import reset_engine, session_scope

    if cmd == "migrate":
        print("applied:", migrations.migrate())
    elif cmd in ("seed", "reset"):
        if cmd == "reset":
            reset_engine()
            for ext in ("", "-wal", "-shm"):
                f = config.settings.data_dir / f"fms.db{ext}"
                if f.exists():
                    f.unlink()
            mp = config.settings.model_dir / "fms_models.joblib"
            if mp.exists():
                mp.unlink()
        from .jobs import startup

        print(json.dumps(startup(), indent=1, default=str))
    elif cmd == "train":
        migrations.migrate()
        from . import ml

        with session_scope() as db:
            res = ml.train(db)
        print(json.dumps(res["metrics"], indent=1))
    elif cmd == "openapi":
        from .main import create_app

        app = create_app(run_startup=False)
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(app.openapi(), fh, indent=1)
        print("written", args.out)
    elif cmd == "backup":
        from . import backup

        print(backup.create_backup("cli"))
    elif cmd == "create-user":
        migrations.migrate()
        from .models import User
        from .security import hash_password, password_problems

        probs = password_problems(args.password)
        if probs:
            print("password needs", ", ".join(probs))
            return 2
        with session_scope() as db:
            db.add(User(username=args.username.lower(), full_name=args.username, role=args.role,
                        password_hash=hash_password(args.password)))
        print("created", args.username)
    return 0


if __name__ == "__main__":
    sys.exit(main())
