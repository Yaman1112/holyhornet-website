"""Runtime configuration: paths, ports and secrets.

All values can be overridden with environment variables so the same code runs in
development, in tests (temporary data dir) and inside the packaged desktop app
(Electron passes FMS_DATA_DIR pointing at %APPDATA%/HolyHornet FMS).
"""
from __future__ import annotations

import os
import secrets
import sys
from dataclasses import dataclass, field
from pathlib import Path

APP_NAME = "HolyHornet Flight Management System"
APP_SHORT = "HH-FMS"
APP_VERSION = "1.0.0"


def _default_data_dir() -> Path:
    if os.environ.get("FMS_DATA_DIR"):
        return Path(os.environ["FMS_DATA_DIR"])
    if getattr(sys, "frozen", False):  # PyInstaller build without Electron
        base = Path(os.environ.get("APPDATA", Path.home())) / "HolyHornet FMS"
        return base
    return Path(__file__).resolve().parents[2] / "data"


def _static_dir() -> Path | None:
    if os.environ.get("FMS_STATIC_DIR"):
        p = Path(os.environ["FMS_STATIC_DIR"])
        return p if p.exists() else None
    if getattr(sys, "frozen", False):
        p = Path(getattr(sys, "_MEIPASS", ".")) / "web"
        return p if p.exists() else None
    p = Path(__file__).resolve().parents[2] / "frontend" / "dist"
    return p if p.exists() else None


@dataclass
class Settings:
    data_dir: Path = field(default_factory=_default_data_dir)
    host: str = os.environ.get("FMS_HOST", "127.0.0.1")
    port: int = int(os.environ.get("FMS_PORT", "8900"))
    seed: int = int(os.environ.get("FMS_SEED", "42"))
    history_days: int = int(os.environ.get("FMS_HISTORY_DAYS", "90"))
    future_days: int = int(os.environ.get("FMS_FUTURE_DAYS", "14"))
    demo_users: bool = os.environ.get("FMS_DEMO_USERS", "1") == "1"
    background_jobs: bool = os.environ.get("FMS_BACKGROUND", "1") == "1"
    browser: bool = os.environ.get("FMS_BROWSER", "0") == "1"  # Pyodide edition: no threads, no WAL
    token_ttl_min: int = int(os.environ.get("FMS_TOKEN_TTL_MIN", "720"))
    static_dir: Path | None = field(default_factory=_static_dir)

    @property
    def db_path(self) -> Path:
        return self.data_dir / "fms.db"

    @property
    def backup_dir(self) -> Path:
        return self.data_dir / "backups"

    @property
    def model_dir(self) -> Path:
        return self.data_dir / "models"

    @property
    def export_dir(self) -> Path:
        return self.data_dir / "exports"

    def ensure_dirs(self) -> None:
        for d in (self.data_dir, self.backup_dir, self.model_dir, self.export_dir):
            d.mkdir(parents=True, exist_ok=True)

    @property
    def secret_key(self) -> str:
        """Per-installation JWT signing key, created on first start."""
        env = os.environ.get("FMS_SECRET_KEY")
        if env:
            return env
        self.ensure_dirs()
        f = self.data_dir / ".secret_key"
        if not f.exists():
            f.write_text(secrets.token_urlsafe(48), encoding="utf-8")
        return f.read_text(encoding="utf-8").strip()


settings = Settings()


def reload_settings() -> Settings:
    global settings
    settings = Settings()
    return settings
