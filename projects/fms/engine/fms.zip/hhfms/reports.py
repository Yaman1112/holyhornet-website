"""Report rendering: CSV, Excel (openpyxl) and PDF (fpdf2)."""
from __future__ import annotations

import io
from datetime import datetime

import pandas as pd
from fpdf import FPDF

from .config import APP_NAME, APP_VERSION


def _latin(s) -> str:
    s = "" if s is None else str(s)
    return s.replace("–", "-").replace("—", "-").replace("→", "->").encode("latin-1", "replace").decode("latin-1")


def to_csv(rows: list[dict]) -> bytes:
    return pd.DataFrame(rows).to_csv(index=False).encode("utf-8-sig")


def to_excel(sheets: dict[str, list[dict] | pd.DataFrame]) -> bytes:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        for name, rows in sheets.items():
            df = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
            if df.empty:
                df = pd.DataFrame({"info": ["no data"]})
            for c in df.select_dtypes(include=["datetimetz"]).columns:
                df[c] = df[c].dt.tz_localize(None)
            df.to_excel(xw, sheet_name=name[:31], index=False)
            ws = xw.sheets[name[:31]]
            for i, col in enumerate(df.columns, start=1):
                width = min(45, max(10, len(str(col)) + 2, *(len(str(v)) + 2 for v in df[col].head(200))))
                ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = width
            ws.freeze_panes = "A2"
    return buf.getvalue()


class _PDF(FPDF):
    def __init__(self, title: str, banner: str | None = None):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.title_txt = title
        self.banner = banner
        self.set_auto_page_break(True, 15)
        self.set_margins(12, 14, 12)

    def header(self):
        self.set_fill_color(11, 23, 42)
        self.rect(0, 0, 210, 11, "F")
        self.set_text_color(255, 255, 255)
        self.set_font("Helvetica", "B", 9)
        self.set_xy(12, 3)
        self.cell(0, 5, _latin(f"{APP_NAME}  |  {self.title_txt}"))
        self.set_text_color(0, 0, 0)
        self.set_y(14)
        if self.banner:
            self.set_fill_color(255, 237, 213)
            self.set_text_color(154, 52, 18)
            self.set_font("Helvetica", "B", 7.5)
            self.multi_cell(0, 4, _latin(self.banner), fill=True, new_x="LMARGIN", new_y="NEXT")
            self.set_text_color(0, 0, 0)
            self.ln(1)

    def footer(self):
        self.set_y(-10)
        self.set_font("Helvetica", "", 7)
        self.set_text_color(110, 110, 110)
        self.cell(0, 5, _latin(f"Generated {datetime.utcnow():%Y-%m-%d %H:%M}Z  -  HH-FMS v{APP_VERSION}  -  page {self.page_no()}"), align="C")

    def heading(self, txt: str):
        self.ln(1)
        self.set_font("Helvetica", "B", 11)
        self.set_text_color(11, 23, 42)
        self.cell(0, 7, _latin(txt), new_x="LMARGIN", new_y="NEXT")
        self.set_draw_color(56, 189, 248)
        self.line(self.l_margin, self.get_y(), 210 - self.r_margin, self.get_y())
        self.ln(1.5)
        self.set_text_color(0, 0, 0)

    def para(self, txt: str, size: float = 8.5, mono: bool = False):
        self.set_font("Courier" if mono else "Helvetica", "", size)
        self.multi_cell(0, 4.2, _latin(txt), new_x="LMARGIN", new_y="NEXT")

    def kv(self, items: list[tuple[str, object]], cols: int = 3):
        self.set_font("Helvetica", "", 8)
        w = (210 - self.l_margin - self.r_margin) / cols
        for i, (k, v) in enumerate(items):
            self.set_font("Helvetica", "", 7)
            self.set_text_color(100, 116, 139)
            x, y = self.get_x(), self.get_y()
            self.cell(w, 3.5, _latin(k))
            self.set_xy(x, y + 3.5)
            self.set_font("Helvetica", "B", 9)
            self.set_text_color(0, 0, 0)
            self.cell(w, 5, _latin(v if v is not None else "-"))
            if (i + 1) % cols == 0:
                self.ln(6)
                self.set_x(self.l_margin)
            else:
                self.set_xy(x + w, y)
        if len(items) % cols:
            self.ln(9)

    def simple_table(self, rows: list[dict], cols: list[str] | None = None, max_rows: int = 400, widths: list[float] | None = None):
        if not rows:
            self.para("No data.")
            return
        cols = cols or list(rows[0].keys())
        avail = 210 - self.l_margin - self.r_margin
        widths = widths or [avail / len(cols)] * len(cols)
        self.set_font("Helvetica", "B", 7)
        self.set_fill_color(226, 232, 240)
        for c, w in zip(cols, widths):
            self.cell(w, 5, _latin(c.replace("_", " "))[:30], border=0, fill=True)
        self.ln()
        self.set_font("Helvetica", "", 7)
        for i, r in enumerate(rows[:max_rows]):
            if i % 2:
                self.set_fill_color(248, 250, 252)
            else:
                self.set_fill_color(255, 255, 255)
            for c, w in zip(cols, widths):
                v = r.get(c)
                if isinstance(v, float):
                    v = f"{v:,.1f}"
                self.cell(w, 4.4, _latin(v)[: int(w / 1.45)], fill=True)
            self.ln()
        if len(rows) > max_rows:
            self.para(f"... {len(rows) - max_rows} more rows (use Excel/CSV export for full data)")


def pdf_report(title: str, subtitle: str, sections: list[dict], banner: str | None = None) -> bytes:
    """sections: [{"heading": str, "kv": [(k, v)], "text": str, "table": rows, "columns": [...]}]"""
    pdf = _PDF(title, banner)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 9, _latin(title), new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(71, 85, 105)
    pdf.cell(0, 5, _latin(subtitle), new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(0, 0, 0)
    for s in sections:
        pdf.heading(s["heading"])
        if s.get("kv"):
            pdf.kv(s["kv"], s.get("kv_cols", 3))
        if s.get("text"):
            pdf.para(s["text"], mono=s.get("mono", False))
        if s.get("table") is not None:
            pdf.simple_table(s["table"], s.get("columns"), widths=s.get("widths"))
    return bytes(pdf.output())


def briefing_pdf(plan: dict, release: dict | None = None) -> bytes:
    f = plan["flight"]
    secs = [
        {"heading": "Flight", "kv": [
            ("Flight", f["flight_number"]), ("Callsign", f["callsign"]), ("Date", f["date"]),
            ("Route", f"{f['origin']} - {f['destination']}"), ("STD / STA (UTC)", f"{f['std'][11:16]} / {f['sta'][11:16]}"),
            ("ETD / ETA (UTC)", f"{f['etd'][11:16]} / {f['eta'][11:16]}"), ("Aircraft", f"{f['registration'] or '-'} ({f['type']})"),
            ("Passengers", f["pax"]), ("Assessment", plan["go_no_go"]),
        ]},
        {"heading": "Route", "kv": [
            ("Distance", f"{plan['route']['distance_nm']} NM"), ("Cruise", f"FL{plan['route']['cruise_fl']}"),
            ("Est. airborne / block", f"{plan['route']['est_airborne_min']} / {plan['route']['est_block_min']} min"),
            ("Initial track", f"{plan['route']['initial_track']:03d} deg"), ("Alternate", plan["alternate"]["icao"]),
            ("Alternate distance", f"{plan['alternate']['distance_nm']} NM"),
        ], "text": plan["route"]["text"], "mono": True},
        {"heading": "Fuel plan (kg)", "table": [
            {"item": k.replace("_fuel_kg", "").replace("_kg", "").replace("_", " ").upper(), "kg": f"{plan['fuel'][k]:,}"}
            for k in ("taxi_fuel_kg", "trip_fuel_kg", "contingency_fuel_kg", "alternate_fuel_kg", "final_reserve_kg", "extra_fuel_kg", "block_fuel_kg")
        ], "columns": ["item", "kg"], "widths": [60, 40],
         "text": f"{plan['fuel']['policy']}. Capacity {plan['fuel']['capacity_kg']:,} kg. Est. TOW {plan['weights']['est_tow_kg']:,} kg / MTOW {plan['weights']['mtow_kg']:,} kg."},
        {"heading": "Weather", "text": "\n\n".join(
            f"{w['role']} {w['icao']}\nMETAR {w.get('metar') or 'n/a'}\n{w.get('taf') or 'TAF n/a'}" for w in plan["weather"]), "mono": True},
        {"heading": "NOTAMs", "table": [{"id": n["id"], "ad": n["airport"], "sev": n["severity"], "subject": n["subject"], "valid": n["valid"]} for n in plan["notams"]],
         "columns": ["id", "ad", "sev", "subject", "valid"], "widths": [22, 14, 18, 100, 32]},
        {"heading": "Restrictions & warnings", "text": "\n".join(f"[{i['level']}] {i['text']}" for i in plan["restrictions"]) or "None identified."},
        {"heading": "Crew", "table": plan["crew"], "columns": ["role", "name", "employee_no"], "widths": [20, 80, 40]},
    ]
    if release:
        secs.append({"heading": "Dispatch release", "kv": [
            ("Status", release.get("status")), ("Prepared by", release.get("prepared_by")),
            ("Released by", release.get("released_by")), ("Released at", (release.get("released_at") or "-")[:16]),
        ], "text": "History:\n" + "\n".join(f"{h['time'][:16]}Z {h['user']}: {h['from']} -> {h['to']} {h.get('note') or ''}" for h in release.get("history") or [])})
    return pdf_report(f"Operational Flight Briefing {f['flight_number']}", f"{f['origin']}-{f['destination']}  {f['date']}", secs,
                      banner=plan["disclaimer"])
