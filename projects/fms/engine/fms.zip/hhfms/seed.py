"""Demo dataset generator (deterministic for a given FMS_SEED).

Creates reference data, schedules, crews, users, maintenance history, NOTAMs,
weather history and ~90 days of simulated flight history up to *now*, plus the
scheduled future horizon. All generated operational records are labelled
data_source = "SIMULATED".
"""
from __future__ import annotations

import random
import time as _time
from datetime import date, datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import config, ops, perf, refdata, weather
from .geo import distance_nm
from .models import (
    Aircraft,
    AircraftType,
    Airline,
    Airport,
    CrewMember,
    Flight,
    FlightSchedule,
    MaintenanceRecord,
    Notam,
    Route,
    Runway,
    SystemConfig,
    User,
    WeatherRecord,
    utcnow,
)
from .security import hash_password


def is_seeded(db: Session) -> bool:
    return (db.scalar(select(func.count()).select_from(Airport)) or 0) > 0


def seed_reference(db: Session) -> None:
    for icao, iata, name, cs, country, hub in refdata.AIRLINES:
        db.add(Airline(icao=icao, iata=iata, name=name, callsign=cs, country=country, hub_icao=hub))
    for (icao, iata, name, city, country, lat, lon, elev, tz, terms, ca, cd, mt, rwys) in refdata.AIRPORTS:
        ap = Airport(
            icao=icao, iata=iata, name=name, city=city, country=country, lat=lat, lon=lon, elevation_ft=elev,
            timezone=tz, terminals=terms, terminal_info=f"{terms} passenger terminal(s)", capacity_arr_per_hour=ca,
            capacity_dep_per_hour=cd, min_turnaround_min=mt,
        )
        for desig, length, width in rwys:
            first = desig.split("/")[0]
            hdg = int("".join(ch for ch in first if ch.isdigit())) * 10 % 360
            ap.runways.append(Runway(designator=desig, length_m=length, width_m=width, heading_deg=float(hdg or 360)))
        db.add(ap)
    for (icao, man, model, mtow, rng_km, ktas, fl, pax, fuel, burn, rwy, turn, cabin, wake) in refdata.AIRCRAFT_TYPES:
        db.add(AircraftType(
            icao=icao, manufacturer=man, model=model, mtow_kg=mtow, range_km=rng_km, cruise_ktas=ktas, cruise_fl=fl,
            pax_capacity=pax, fuel_capacity_kg=fuel, fuel_burn_kg_h=burn, min_runway_m=rwy, min_turnaround_min=turn,
            cabin_crew=cabin, wake_category=wake,
        ))
    db.flush()
    airlines = {a.icao: a for a in db.scalars(select(Airline)).all()}
    types = {t.icao: t for t in db.scalars(select(AircraftType)).all()}
    rng = random.Random(config.settings.seed)
    today = utcnow().date()
    for al, prefix, t, n in refdata.FLEET:
        for i in range(n):
            reg = prefix + chr(ord("A") + i)
            age_y = rng.uniform(0.5, 9)
            hours = round(age_y * 3300 * rng.uniform(0.8, 1.1), 1)
            db.add(Aircraft(
                registration=reg, type_id=types[t].id, airline_id=airlines[al].id, msn=str(rng.randint(1000, 12000)),
                delivery_date=today - timedelta(days=int(age_y * 365)), seats=types[t].pax_capacity,
                total_flight_hours=hours, total_cycles=int(hours / (2.1 if t not in ("B789", "A359") else 7.5)),
                hours_since_check=round(rng.uniform(60, 600), 1),
                check_interval_hours=750.0 if t not in ("B789", "A359") else 1000.0,
                base_icao=airlines[al].hub_icao or "EHAM",
            ))
    for key, (val, desc) in refdata.DEFAULT_CONFIG.items():
        db.add(SystemConfig(key=key, value=val, description=desc))
    db.flush()


def seed_schedules(db: Session) -> None:
    airports = {a.icao: a for a in db.scalars(select(Airport)).all()}
    airlines = {a.icao: a for a in db.scalars(select(Airline)).all()}
    types = {t.icao: t for t in db.scalars(select(AircraftType)).all()}
    routes: dict[tuple[str, str], Route] = {}

    def route(o: str, d: str, t: AircraftType) -> Route:
        if (o, d) not in routes:
            a, b = airports[o], airports[d]
            dist = distance_nm(a.lat, a.lon, b.lat, b.lon)
            r = Route(origin_id=a.id, destination_id=b.id, distance_nm=round(dist, 1),
                      typical_block_min=perf.scheduled_block_minutes(dist, t.cruise_ktas))
            db.add(r)
            db.flush()
            routes[(o, d)] = r
        return routes[(o, d)]

    today = utcnow().date()
    valid_from = today - timedelta(days=config.settings.history_days + 5)
    valid_to = today + timedelta(days=365)
    for line, al, fn_base, t_icao, first, dests in refdata.ROTATION_LINES:
        airline = airlines[al]
        hub = airline.hub_icao
        t = types[t_icao]
        cur = datetime.combine(today, datetime.strptime(first, "%H:%M").time())
        seq = 0
        fn = fn_base
        for dest in dests:
            for o, d in ((hub, dest), (dest, hub)):
                seq += 1
                a, b = airports[o], airports[d]
                dist = distance_nm(a.lat, a.lon, b.lat, b.lon)
                block = perf.scheduled_block_minutes(dist, t.cruise_ktas)
                r = route(o, d, t)
                db.add(FlightSchedule(
                    airline_id=airline.id, flight_number=f"{airline.iata}{fn}", route_id=r.id, aircraft_type_id=t.id,
                    days_of_week="1234567", std_utc=cur.strftime("%H:%M"), block_min=block, rotation_line=line,
                    leg_seq=seq, valid_from=valid_from, valid_to=valid_to,
                ))
                fn += 1
                arr = cur + timedelta(minutes=block)
                turn = t.min_turnaround_min + 10
                if t_icao in ("B789", "A359") and d != hub:
                    turn = 120
                nxt = arr + timedelta(minutes=turn)
                cur = nxt + timedelta(minutes=(5 - nxt.minute % 5) % 5)
    db.flush()


def seed_crew(db: Session) -> None:
    airlines = {a.icao: a for a in db.scalars(select(Airline)).all()}
    rng = random.Random(config.settings.seed + 7)
    # required pool per family = slots * stride (see ops._assign_crew)
    fam_lines: dict[str, list[str]] = {}
    fam_airline: dict[str, str] = {}
    for line, al, _, t, _, _ in refdata.ROTATION_LINES:
        fam = refdata.TYPE_FAMILY[t]
        fam_lines.setdefault(fam, []).append(line)
        fam_airline[fam] = al
    n = 1
    for fam, lines in fam_lines.items():
        longhaul = fam in ("B787", "A350")
        size = len(lines) * 2 * (3 if longhaul else 2)
        al = airlines[fam_airline[fam]]
        for role in ("CPT", "FO", "SCCM"):
            for _ in range(size + 1):  # +1 reserve
                db.add(CrewMember(
                    employee_no=f"{al.icao}{n:04d}", first_name=rng.choice(refdata.FIRST_NAMES),
                    last_name=rng.choice(refdata.LAST_NAMES), role=role, base_icao=al.hub_icao or "EHAM",
                    type_ratings=fam, airline_id=al.id,
                ))
                n += 1
    db.flush()


def seed_users(db: Session) -> None:
    if not config.settings.demo_users:
        return
    for username, full, role, pw in refdata.DEMO_USERS:
        db.add(User(username=username, full_name=full, role=role, password_hash=hash_password(pw)))
    db.flush()


def seed_maintenance(db: Session, now: datetime) -> None:
    rng = random.Random(config.settings.seed + 11)
    aircraft = db.scalars(select(Aircraft).order_by(Aircraft.registration)).all()
    for ac in aircraft:
        # past A-checks every ~5-6 weeks overnight, a few line maintenance/defects
        t = now - timedelta(days=config.settings.history_days) + timedelta(days=rng.randint(0, 30))
        while t < now + timedelta(days=config.settings.future_days):
            start = t.replace(hour=22, minute=0, second=0, microsecond=0)
            status = "COMPLETED" if start + timedelta(hours=8) < now else "PLANNED"
            db.add(MaintenanceRecord(
                aircraft_id=ac.id, kind="A-CHECK", description="Scheduled A-check (overnight)", start_utc=start,
                end_utc=start + timedelta(hours=8), status=status, station=ac.base_icao,
            ))
            t += timedelta(days=rng.randint(35, 45))
        for _ in range(rng.randint(1, 3)):
            start = now - timedelta(days=rng.uniform(1, config.settings.history_days), hours=0)
            start = start.replace(minute=0, second=0, microsecond=0)
            db.add(MaintenanceRecord(
                aircraft_id=ac.id, kind=rng.choice(["LINE", "DEFECT", "CABIN"]),
                description=rng.choice([
                    "Brake wear pin check, unit replaced", "APU start fault, igniter replaced", "Cabin PA amplifier replaced",
                    "Bird strike inspection - no damage", "Hydraulic leak at MLG, seal replaced", "Lavatory smoke detector replaced",
                    "Weather radar BITE fault, LRU swapped", "Tyre change #3 main wheel",
                ]), start_utc=start, end_utc=start + timedelta(hours=rng.randint(2, 6)), status="COMPLETED",
                station=ac.base_icao,
            ))
    # one narrow-body in a heavy check spanning today (exercises spare-tail logic)
    in_check = next(a for a in aircraft if a.registration.startswith("PH-HN") and a.registration.endswith("F"))
    db.add(MaintenanceRecord(
        aircraft_id=in_check.id, kind="C-CHECK", description="C-check at main base (heavy maintenance)",
        start_utc=(now - timedelta(days=3)).replace(hour=6, minute=0, second=0, microsecond=0),
        end_utc=(now + timedelta(days=9)).replace(hour=18, minute=0, second=0, microsecond=0),
        status="IN_PROGRESS", station="EHAM",
    ))
    db.flush()


def seed_notams(db: Session, now: datetime) -> None:
    ap = {a.icao: a for a in db.scalars(select(Airport)).all()}
    items = [
        ("EHAM", "RWY", "RWY 04/22 CLOSED", "RWY 04/22 CLSD DUE TO MAINT WI", "CAUTION", "04/22", -2, 20),
        ("EHAM", "TWY", "TWY B partially closed", "TWY B BTN B4 AND B6 CLSD. USE TWY A.", "INFO", None, -5, 12),
        ("EGLL", "AD", "Night restrictions", "NIGHT QUOTA RESTRICTIONS 2330-0600 LOCAL IN FORCE.", "INFO", None, -30, 300),
        ("LFPG", "NAV", "ILS 27R unserviceable", "ILS RWY 27R U/S. RNP APCH AVBL.", "CAUTION", "09L/27R", -1, 4),
        ("EDDF", "RWY", "RWY 18 departures only", "RWY 18 AVBL FOR DEP ONLY. NO LDG.", "INFO", "18/36", -60, 365),
        ("LSZH", "AIRSPACE", "Military exercise", "TEMPO RESERVED AREA LSR23 ACTIVE 0800-1600 UTC. EXPECT REROUTING.", "CAUTION", None, 0, 3),
        ("KJFK", "RWY", "RWY 13R/31L reduced length", "RWY 13R/31L TORA REDUCED BY 600M DUE TO WIP.", "CAUTION", "13R/31L", -4, 25),
        ("OMDB", "AD", "Apron congestion", "STAND ALLOCATION DELAYS POSSIBLE. CTC APRON 118.75 BEFORE ENGINE START.", "INFO", None, -2, 10),
        ("ENGM", "AD", "De-icing procedures", "DE-ICING PLATFORMS IN USE. EXPECT ADDITIONAL TAXI TIME 10-15 MIN.", "INFO", None, -10, 90),
        ("LTFM", "OBST", "Crane erected", "CRANE 152FT AGL 1.2NM N OF THR 35R LGTD.", "INFO", None, -15, 60),
        ("LGAV", "NAV", "VOR ATH unserviceable", "VOR/DME ATH U/S.", "CAUTION", None, 0, 6),
        ("ESSA", "RWY", "RWY 08/26 snow clearance", "RWY 08/26 CLSD INTERMITTENTLY FOR SNOW CLEARANCE.", "CAUTION", "08/26", -1, 30),
    ]
    for i, (icao, cat, subj, text, sev, rwy, d0, d1) in enumerate(items, start=1):
        db.add(Notam(
            notam_id=f"A{1000 + i}/{now.year % 100:02d}", airport_id=ap[icao].id, category=cat, subject=subj, text=text,
            valid_from_utc=(now + timedelta(days=d0)).replace(minute=0, second=0, microsecond=0),
            valid_to_utc=(now + timedelta(days=d1)).replace(minute=0, second=0, microsecond=0), severity=sev, runway=rwy,
        ))
    # runway 04/22 at EHAM closed by the NOTAM above
    for r in ap["EHAM"].runways:
        if r.designator == "04/22":
            r.status = "CLOSED"
    db.flush()


def seed_weather(db: Session, start: datetime, end: datetime) -> int:
    """Store hourly simulated METARs and 6-hourly TAFs between start and end."""
    airports = db.scalars(select(Airport)).all()
    rows = []
    t = start.replace(minute=0, second=0, microsecond=0)
    seed = config.settings.seed
    existing = {
        (a, k, o) for a, k, o in db.execute(
            select(WeatherRecord.airport_id, WeatherRecord.kind, WeatherRecord.obs_time_utc).where(
                WeatherRecord.obs_time_utc >= t, WeatherRecord.obs_time_utc <= end)
        ).all()
    }
    while t <= end:
        for a in airports:
            if (a.id, "METAR", t) not in existing:
                s = weather.simulate(a.icao, a.lat, a.lon, a.elevation_ft, t, seed)
                rows.append(wx_record(a.id, s))
            if t.hour % 6 == 0 and (a.id, "TAF", t) not in existing:
                rows.append(WeatherRecord(
                    airport_id=a.id, kind="TAF", obs_time_utc=t,
                    raw=weather.encode_taf(a.icao, a.lat, a.lon, a.elevation_ft, t, seed), severity=0.0,
                ))
        t += timedelta(hours=1)
    db.add_all(rows)
    db.flush()
    return len(rows)


def wx_record(airport_id: int, s: weather.WxState, source: str = "SIMULATED") -> WeatherRecord:
    return WeatherRecord(
        airport_id=airport_id, kind="METAR", obs_time_utc=s.time_utc, raw=s.metar(), wind_dir_deg=s.wind_dir,
        wind_speed_kt=s.wind_speed, wind_gust_kt=s.wind_gust, visibility_m=s.visibility_m, temperature_c=s.temperature,
        dewpoint_c=s.dewpoint, qnh_hpa=s.qnh, clouds=" ".join(f"{c}{b // 100:03d}" for c, b in s.clouds) or "NSC",
        ceiling_ft=s.ceiling_ft, phenomena=" ".join(s.phenomena), flight_category=s.flight_category,
        severity=s.severity, data_source=source,
    )


def seed_all(db: Session, now: datetime | None = None, verbose: bool = False) -> dict:
    t0 = _time.time()
    now = now or utcnow()
    seed_reference(db)
    seed_schedules(db)
    seed_crew(db)
    seed_users(db)
    seed_maintenance(db, now)
    seed_notams(db, now)
    ctx = ops.build_ctx(db)
    start = (now - timedelta(days=config.settings.history_days)).date()
    n = 0
    d = start
    while d <= (now + timedelta(days=config.settings.future_days)).date():
        n += ops.materialise_day(db, d, now, ctx)
        d += timedelta(days=1)
        if verbose and d.day == 1:
            print(f"  materialised to {d} ({n} flights)")
    db.flush()
    nwx = seed_weather(db, datetime.combine(start, datetime.min.time()), now)
    # walk lifecycle to now (history becomes ARRIVED/CANCELLED/DIVERTED with movements)
    flights = db.scalars(select(Flight).where(Flight.std_utc <= now + timedelta(hours=4))).all()
    for f in flights:
        ops.apply_lifecycle(db, f, now)
    for ac in db.scalars(select(Aircraft)).all():
        ops.recompute_hours_since_check(db, ac, now)
    # one regional jet close to its check limit (exercises maintenance alerts)
    near = db.scalars(select(Aircraft).where(Aircraft.registration.like("LN-PE%")).order_by(Aircraft.registration)).first()
    if near:
        near.hours_since_check = round(near.check_interval_hours * 0.97, 1)
    ops.update_maintenance_status(db, now)
    db.flush()
    from . import analytics

    analytics.rebuild_daily_stats(db, start, now.date())
    return {"flights": n, "weather_records": nwx, "seconds": round(_time.time() - t0, 1)}
