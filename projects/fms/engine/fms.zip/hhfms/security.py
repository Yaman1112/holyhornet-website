"""Authentication (PBKDF2 password hashing, JWT) and role-based access control."""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import re
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from . import config
from .db import get_db
from .models import AuditLog, User

ROLES = ("ADMIN", "OPS_MANAGER", "DISPATCHER", "ANALYST")
ROLE_LABELS = {
    "ADMIN": "Administrator",
    "OPS_MANAGER": "Operations Manager",
    "DISPATCHER": "Dispatcher",
    "ANALYST": "Analyst",
}

# permission -> roles allowed
PERMISSIONS: dict[str, set[str]] = {
    "read": set(ROLES),
    "flights.write": {"ADMIN", "OPS_MANAGER", "DISPATCHER"},
    "flights.delete": {"ADMIN", "OPS_MANAGER"},
    "schedule.write": {"ADMIN", "OPS_MANAGER"},
    "fleet.write": {"ADMIN", "OPS_MANAGER"},
    "airports.write": {"ADMIN", "OPS_MANAGER"},
    "crew.write": {"ADMIN", "OPS_MANAGER"},
    "dispatch.write": {"ADMIN", "OPS_MANAGER", "DISPATCHER"},
    "dispatch.release": {"ADMIN", "DISPATCHER"},
    "notams.write": {"ADMIN", "OPS_MANAGER", "DISPATCHER"},
    "weather.write": {"ADMIN", "OPS_MANAGER", "DISPATCHER"},
    "alerts.ack": {"ADMIN", "OPS_MANAGER", "DISPATCHER"},
    "analytics.run": {"ADMIN", "OPS_MANAGER", "ANALYST"},
    "scenarios.run": {"ADMIN", "OPS_MANAGER", "ANALYST", "DISPATCHER"},
    "ml.train": {"ADMIN", "ANALYST"},
    "data.import": {"ADMIN", "OPS_MANAGER"},
    "data.export": set(ROLES),
    "admin.users": {"ADMIN"},
    "admin.config": {"ADMIN"},
    "admin.backup": {"ADMIN"},
    "admin.audit": {"ADMIN", "OPS_MANAGER"},
}

_ITER = int(os.environ.get("FMS_PBKDF2_ITER", "210000"))


def hash_password(pw: str, iterations: int | None = None) -> str:
    it = iterations or _ITER
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, it)
    return f"pbkdf2_sha256${it}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(pw: str, stored: str) -> bool:
    try:
        algo, it, salt_b64, dk_b64 = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), base64.b64decode(salt_b64), int(it))
        return hmac.compare_digest(dk, base64.b64decode(dk_b64))
    except Exception:
        return False


def password_problems(pw: str) -> list[str]:
    p = []
    if len(pw) < 8:
        p.append("at least 8 characters")
    if not re.search(r"[A-Z]", pw):
        p.append("an upper-case letter")
    if not re.search(r"[a-z]", pw):
        p.append("a lower-case letter")
    if not re.search(r"[0-9]", pw):
        p.append("a digit")
    return p


def create_token(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user.username,
        "role": user.role,
        "iat": now,
        "exp": now + timedelta(minutes=config.settings.token_ttl_min),
        # invalidates tokens when the password changes
        "pwv": hashlib.sha256(user.password_hash.encode()).hexdigest()[:12],
    }
    return jwt.encode(payload, config.settings.secret_key, algorithm="HS256")


_bearer = HTTPBearer(auto_error=False)


def _user_from_token(token: str, db: Session) -> User:
    try:
        payload = jwt.decode(token, config.settings.secret_key, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired session")
    user = db.query(User).filter(User.username == payload.get("sub")).first()
    if not user or not user.active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not active")
    if payload.get("pwv") != hashlib.sha256(user.password_hash.encode()).hexdigest()[:12]:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session revoked")
    return user


def current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer), db: Session = Depends(get_db)
) -> User:
    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated", headers={"WWW-Authenticate": "Bearer"})
    return _user_from_token(creds.credentials, db)


def user_from_query_token(token: str, db: Session) -> User:
    return _user_from_token(token, db)


def require(permission: str):
    allowed = PERMISSIONS[permission]

    def dep(user: User = Depends(current_user)) -> User:
        if user.role not in allowed:
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Role {ROLE_LABELS.get(user.role, user.role)} may not perform '{permission}'")
        return user

    return dep


def permissions_for(role: str) -> list[str]:
    return sorted(p for p, roles in PERMISSIONS.items() if role in roles)


def audit(db: Session, user: User | str, action: str, entity: str, entity_id=None, detail: dict | None = None,
          request: Request | None = None) -> None:
    db.add(AuditLog(
        username=user if isinstance(user, str) else user.username,
        action=action, entity=entity, entity_id=None if entity_id is None else str(entity_id),
        detail=detail, ip=request.client.host if request and request.client else None,
    ))
