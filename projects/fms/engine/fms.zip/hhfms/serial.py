"""Entity -> JSON dict serializers."""
from __future__ import annotations

from datetime import date, datetime

from .models import Aircraft, AircraftType, Airport, CrewMember, Flight, MaintenanceRecord, Notam, OperationalAlert, User


def iso(v):
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return v


def flight(f: Flight, full: bool = False) -> dict:
    dep = f.atd_utc or f.etd_utc
    d = {
        "id": f.id, "flight_number": f.flight_number, "callsign": f.callsign, "flight_date": iso(f.flight_date),
        "airline_id": f.airline_id, "airline": f.airline.icao if f.airline else None,
        "origin": f.origin.icao, "origin_iata": f.origin.iata, "destination": f.destination.icao,
        "destination_iata": f.destination.iata, "alternate": f.alternate.icao if f.alternate else None,
        "aircraft_type": f.aircraft_type.icao, "aircraft_id": f.aircraft_id,
        "registration": f.aircraft.registration if f.aircraft else None,
        "rotation_line": f.rotation_line, "leg_seq": f.leg_seq,
        "std_utc": iso(f.std_utc), "sta_utc": iso(f.sta_utc), "etd_utc": iso(f.etd_utc), "eta_utc": iso(f.eta_utc),
        "atd_utc": iso(f.atd_utc), "takeoff_utc": iso(f.takeoff_utc), "landing_utc": iso(f.landing_utc), "ata_utc": iso(f.ata_utc),
        "status": f.status, "delay_code": f.delay_code, "delay_reason": f.delay_reason, "cancel_reason": f.cancel_reason,
        "dep_delay_min": round((dep - f.std_utc).total_seconds() / 60) if dep else None,
        "arr_delay_min": round(((f.ata_utc or f.eta_utc) - f.sta_utc).total_seconds() / 60) if (f.ata_utc or f.eta_utc) else None,
        "block_min": round((f.sta_utc - f.std_utc).total_seconds() / 60),
        "pax_booked": f.pax_booked, "turnaround_min": f.turnaround_min, "cruise_fl": f.cruise_fl,
        "data_source": f.data_source, "remarks": f.remarks,
    }
    if full:
        d["crew"] = [{"crew_id": c.crew_id, "role": c.role, "name": f"{c.crew_member.first_name} {c.crew_member.last_name}",
                      "employee_no": c.crew_member.employee_no} for c in f.crew]
        d["cabin_crew_count"] = f.cabin_crew_count
        d["route_text"] = f.route_text
        d["origin_name"] = f.origin.name
        d["destination_name"] = f.destination.name
        d["schedule_id"] = f.schedule_id
        d["created_at"] = iso(f.created_at)
        d["updated_at"] = iso(f.updated_at)
    return d


def aircraft_type(t: AircraftType) -> dict:
    return {c.name: getattr(t, c.name) for c in t.__table__.columns}


def aircraft(a: Aircraft) -> dict:
    return {
        "id": a.id, "registration": a.registration, "type_id": a.type_id, "type": a.type.icao,
        "manufacturer": a.type.manufacturer, "model": a.type.model, "airline": a.airline.icao if a.airline else None,
        "airline_id": a.airline_id, "msn": a.msn, "delivery_date": iso(a.delivery_date), "seats": a.seats or a.type.pax_capacity,
        "mtow_kg": a.type.mtow_kg, "range_km": a.type.range_km, "cruise_ktas": a.type.cruise_ktas,
        "pax_capacity": a.type.pax_capacity, "fuel_capacity_kg": a.type.fuel_capacity_kg,
        "operational_status": a.operational_status, "maintenance_status": a.maintenance_status, "base_icao": a.base_icao,
        "total_flight_hours": round(a.total_flight_hours, 1), "total_cycles": a.total_cycles,
        "hours_since_check": round(a.hours_since_check, 1), "check_interval_hours": a.check_interval_hours,
        "check_remaining_hours": round(a.check_interval_hours - a.hours_since_check, 1), "notes": a.notes,
        "data_source": a.data_source,
    }


def maintenance(m: MaintenanceRecord) -> dict:
    return {"id": m.id, "aircraft_id": m.aircraft_id, "registration": m.aircraft.registration if m.aircraft else None,
            "kind": m.kind, "description": m.description, "start_utc": iso(m.start_utc), "end_utc": iso(m.end_utc),
            "status": m.status, "station": m.station}


def airport(a: Airport, runways: bool = True) -> dict:
    d = {c.name: getattr(a, c.name) for c in a.__table__.columns}
    if runways:
        d["runways"] = [{"id": r.id, "designator": r.designator, "length_m": r.length_m, "width_m": r.width_m,
                         "heading_deg": r.heading_deg, "surface": r.surface, "ils": r.ils, "status": r.status} for r in a.runways]
        d["longest_runway_m"] = max((r.length_m for r in a.runways), default=0)
    return d


def crew(c: CrewMember) -> dict:
    return {"id": c.id, "employee_no": c.employee_no, "first_name": c.first_name, "last_name": c.last_name,
            "name": f"{c.first_name} {c.last_name}", "role": c.role, "base_icao": c.base_icao, "type_ratings": c.type_ratings,
            "airline_id": c.airline_id, "active": c.active}


def notam(n: Notam) -> dict:
    return {"id": n.id, "notam_id": n.notam_id, "airport_id": n.airport_id, "airport": n.airport.icao if n.airport else None,
            "category": n.category, "subject": n.subject, "text": n.text, "valid_from_utc": iso(n.valid_from_utc),
            "valid_to_utc": iso(n.valid_to_utc), "severity": n.severity, "runway": n.runway, "active": n.active,
            "data_source": n.data_source}


def alert(a: OperationalAlert) -> dict:
    return {"id": a.id, "created_at": iso(a.created_at), "category": a.category, "severity": a.severity, "title": a.title,
            "detail": a.detail, "flight_id": a.flight_id, "aircraft_id": a.aircraft_id, "airport_id": a.airport_id,
            "acknowledged": a.acknowledged, "acknowledged_by": a.acknowledged_by, "resolved": a.resolved}


def user(u: User) -> dict:
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "role": u.role, "active": u.active,
            "must_change_password": u.must_change_password, "last_login": iso(u.last_login), "created_at": iso(u.created_at)}
