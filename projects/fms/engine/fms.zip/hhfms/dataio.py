"""Data import (CSV, Excel, JSON, GeoJSON, SQLite) with validation, and templates."""
from __future__ import annotations

import io
import json
import sqlite3
import tempfile
from datetime import date, datetime, time, timedelta
from pathlib import Path

import pandas as pd
from pydantic import BaseModel, Field, ValidationError, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import ops, perf
from .geo import distance_nm
from .models import (
    Aircraft,
    AircraftType,
    Airline,
    Airport,
    Flight,
    FlightMovement,
    FlightSchedule,
    Route,
    Runway,
)

KINDS = ("flights", "aircraft", "airports", "movements", "schedules")

TEMPLATES: dict[str, list[dict]] = {
    "flights": [{"flight_number": "HH901", "date": "2026-12-01", "airline": "HHA", "origin": "EHAM", "destination": "LFPG",
                 "std_utc": "2026-12-01 09:15", "sta_utc": "2026-12-01 10:35", "aircraft_type": "A20N", "registration": "PH-HNA",
                 "pax_booked": 150, "status": "SCHEDULED"}],
    "aircraft": [{"registration": "PH-HNZ", "aircraft_type": "A20N", "airline": "HHA", "msn": "11234", "seats": 180,
                  "operational_status": "ACTIVE", "base": "EHAM", "total_flight_hours": 1250.5, "total_cycles": 610}],
    "airports": [{"icao": "EGKK", "iata": "LGW", "name": "London Gatwick", "city": "London", "country": "United Kingdom",
                  "lat": 51.1481, "lon": -0.1903, "elevation_ft": 202, "timezone": "Europe/London", "capacity_arr_per_hour": 28,
                  "capacity_dep_per_hour": 28, "runways": "08R/26L:3316;08L/26R:2565"}],
    "movements": [{"flight_number": "HH901", "date": "2026-10-01", "airline": "HHA", "origin": "EHAM", "destination": "LFPG",
                   "std_utc": "2026-10-01 09:15", "sta_utc": "2026-10-01 10:35", "atd_utc": "2026-10-01 09:27",
                   "takeoff_utc": "2026-10-01 09:41", "landing_utc": "2026-10-01 10:31", "ata_utc": "2026-10-01 10:39",
                   "aircraft_type": "A20N", "registration": "PH-HNA", "status": "ARRIVED", "pax_booked": 162}],
    "schedules": [{"flight_number": "HH903", "airline": "HHA", "origin": "EHAM", "destination": "EGLL", "aircraft_type": "A20N",
                   "days_of_week": "12345", "std_utc": "14:05", "valid_from": "2026-12-01", "valid_to": "2027-03-28",
                   "rotation_line": ""}],
}


def _dt(v) -> datetime | None:
    if v is None or (isinstance(v, float) and pd.isna(v)) or v == "":
        return None
    if isinstance(v, datetime):
        return v.replace(tzinfo=None)
    ts = pd.to_datetime(str(v), utc=True)
    return ts.tz_convert(None).to_pydatetime().replace(microsecond=0)


class _Base(BaseModel):
    model_config = {"extra": "ignore", "str_strip_whitespace": True, "populate_by_name": True}

    @field_validator("*", mode="before")
    @classmethod
    def _nan_to_none(cls, v):
        if isinstance(v, float) and pd.isna(v):
            return None
        return v


class FlightRow(_Base):
    flight_number: str = Field(min_length=3, max_length=8)
    flight_date: date | None = Field(default=None, alias="date")
    airline: str = Field(min_length=3, max_length=3)
    origin: str = Field(min_length=4, max_length=4)
    destination: str = Field(min_length=4, max_length=4)
    std_utc: datetime
    sta_utc: datetime
    aircraft_type: str
    registration: str | None = None
    pax_booked: int = Field(default=0, ge=0, le=900)
    status: str = "SCHEDULED"
    atd_utc: datetime | None = None
    takeoff_utc: datetime | None = None
    landing_utc: datetime | None = None
    ata_utc: datetime | None = None

    @field_validator("std_utc", "sta_utc", "atd_utc", "takeoff_utc", "landing_utc", "ata_utc", mode="before")
    @classmethod
    def _p(cls, v):
        return _dt(v)

    @field_validator("flight_number", "airline", "origin", "destination", "aircraft_type", mode="after")
    @classmethod
    def _up(cls, v):
        return v.upper().replace(" ", "")


class AircraftRow(_Base):
    registration: str = Field(min_length=3, max_length=10)
    aircraft_type: str
    airline: str | None = None
    msn: str | None = ""
    seats: int | None = Field(default=None, ge=1, le=900)
    operational_status: str = "ACTIVE"
    base: str = "EHAM"
    total_flight_hours: float = Field(default=0, ge=0)
    total_cycles: int = Field(default=0, ge=0)

    @field_validator("msn", mode="before")
    @classmethod
    def _s(cls, v):
        return "" if v is None else str(v)


class AirportRow(_Base):
    icao: str = Field(min_length=4, max_length=4)
    iata: str | None = None
    name: str
    city: str = ""
    country: str = ""
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    elevation_ft: int = 0
    timezone: str = "UTC"
    capacity_arr_per_hour: int = Field(default=30, ge=0, le=200)
    capacity_dep_per_hour: int = Field(default=30, ge=0, le=200)
    runways: str | None = None


class ScheduleRow(_Base):
    flight_number: str
    airline: str
    origin: str
    destination: str
    aircraft_type: str
    days_of_week: str = "1234567"
    std_utc: str
    valid_from: date
    valid_to: date
    rotation_line: str | None = ""

    @field_validator("days_of_week", mode="before")
    @classmethod
    def _dow(cls, v):
        v = str(v).split(".")[0]
        if not v or any(c not in "1234567" for c in v):
            raise ValueError("days_of_week must contain digits 1-7")
        return v

    @field_validator("std_utc", mode="before")
    @classmethod
    def _hhmm(cls, v):
        v = str(v)[:5]
        datetime.strptime(v, "%H:%M")
        return v


# --------------------------------------------------------------------------- parsing


def read_rows(content: bytes, filename: str, kind: str) -> list[dict]:
    name = filename.lower()
    if name.endswith(".csv"):
        df = pd.read_csv(io.BytesIO(content), dtype=str, keep_default_na=False)
        return [{k: (v if v != "" else None) for k, v in r.items()} for r in df.to_dict("records")]
    if name.endswith((".xlsx", ".xls")):
        df = pd.read_excel(io.BytesIO(content), sheet_name=0)
        return df.to_dict("records")
    if name.endswith(".geojson") or (name.endswith(".json") and b'"FeatureCollection"' in content[:2000]):
        gj = json.loads(content)
        rows = []
        for feat in gj.get("features", []):
            props = dict(feat.get("properties") or {})
            geom = feat.get("geometry") or {}
            if geom.get("type") == "Point":
                props.setdefault("lon", geom["coordinates"][0])
                props.setdefault("lat", geom["coordinates"][1])
            rows.append(props)
        return rows
    if name.endswith(".json"):
        data = json.loads(content)
        if isinstance(data, dict):
            data = data.get(kind) or data.get("rows") or data.get("data") or []
        return list(data)
    raise ValueError("Unsupported file type (use .csv, .xlsx, .json, .geojson or .db/.sqlite)")


# --------------------------------------------------------------------------- import


def _lookup(db: Session):
    return {
        "airports": {a.icao: a for a in db.scalars(select(Airport)).all()},
        "types": {t.icao: t for t in db.scalars(select(AircraftType)).all()},
        "airlines": {a.icao: a for a in db.scalars(select(Airline)).all()},
        "aircraft": {a.registration: a for a in db.scalars(select(Aircraft)).all()},
    }


def import_rows(db: Session, kind: str, rows: list[dict], dry_run: bool = False) -> dict:
    if kind not in KINDS:
        raise ValueError(f"Unknown import kind {kind}")
    L = _lookup(db)
    inserted = updated = 0
    errors: list[dict] = []
    for i, raw in enumerate(rows, start=1):
        try:
            with db.begin_nested():
                if kind == "airports":
                    r = AirportRow(**raw)
                    ap = L["airports"].get(r.icao.upper())
                    new = ap is None
                    if new:
                        ap = Airport(icao=r.icao.upper(), lat=r.lat, lon=r.lon, name=r.name)
                        db.add(ap)
                        L["airports"][ap.icao] = ap
                    for k in ("iata", "name", "city", "country", "lat", "lon", "elevation_ft", "timezone",
                              "capacity_arr_per_hour", "capacity_dep_per_hour"):
                        setattr(ap, k, getattr(r, k))
                    ap.data_source = "IMPORTED"
                    if r.runways:
                        ap.runways.clear()
                        db.flush()
                        for part in r.runways.split(";"):
                            desig, length = part.split(":")
                            first = desig.split("/")[0]
                            hdg = int("".join(c for c in first if c.isdigit()) or "36") * 10 % 360
                            ap.runways.append(Runway(designator=desig.strip(), length_m=int(float(length)), heading_deg=float(hdg or 360)))
                    inserted += new
                    updated += not new
                elif kind == "aircraft":
                    r = AircraftRow(**raw)
                    t = L["types"].get(r.aircraft_type.upper())
                    if not t:
                        raise ValueError(f"unknown aircraft_type {r.aircraft_type}")
                    reg = r.registration.upper()
                    ac = L["aircraft"].get(reg)
                    new = ac is None
                    if new:
                        ac = Aircraft(registration=reg, type_id=t.id)
                        db.add(ac)
                        L["aircraft"][reg] = ac
                    ac.type_id = t.id
                    al = L["airlines"].get((r.airline or "").upper())
                    ac.airline_id = al.id if al else ac.airline_id
                    ac.msn = r.msn or ""
                    ac.seats = r.seats or t.pax_capacity
                    ac.operational_status = r.operational_status.upper()
                    ac.base_icao = r.base.upper()
                    ac.total_flight_hours = r.total_flight_hours
                    ac.total_cycles = r.total_cycles
                    ac.data_source = "IMPORTED"
                    inserted += new
                    updated += not new
                elif kind in ("flights", "movements"):
                    r = FlightRow(**raw)
                    o, d = L["airports"].get(r.origin), L["airports"].get(r.destination)
                    if not o or not d:
                        raise ValueError(f"unknown airport {r.origin if not o else r.destination}")
                    if o.id == d.id:
                        raise ValueError("origin equals destination")
                    t = L["types"].get(r.aircraft_type)
                    if not t:
                        raise ValueError(f"unknown aircraft_type {r.aircraft_type}")
                    al = L["airlines"].get(r.airline)
                    if not al:
                        raise ValueError(f"unknown airline {r.airline}")
                    if r.sta_utc <= r.std_utc:
                        raise ValueError("sta_utc must be after std_utc")
                    ac = L["aircraft"].get((r.registration or "").upper()) if r.registration else None
                    if r.registration and not ac:
                        raise ValueError(f"unknown registration {r.registration}")
                    fdate = r.flight_date or r.std_utc.date()
                    f = db.scalars(select(Flight).where(Flight.flight_number == r.flight_number, Flight.flight_date == fdate)).first()
                    new = f is None
                    if new:
                        f = Flight(flight_number=r.flight_number, flight_date=fdate, airline_id=al.id,
                                   callsign=al.icao + r.flight_number[len(al.iata or ""):], origin_id=o.id, destination_id=d.id,
                                   aircraft_type_id=t.id, std_utc=r.std_utc, sta_utc=r.sta_utc)
                        db.add(f)
                    f.origin_id, f.destination_id, f.aircraft_type_id = o.id, d.id, t.id
                    f.std_utc, f.sta_utc = r.std_utc, r.sta_utc
                    f.aircraft_id = ac.id if ac else None
                    f.pax_booked = r.pax_booked
                    f.cabin_crew_count = t.cabin_crew
                    status = r.status.upper()
                    if kind == "movements":
                        f.atd_utc, f.takeoff_utc, f.landing_utc, f.ata_utc = r.atd_utc, r.takeoff_utc, r.landing_utc, r.ata_utc
                        if status == "SCHEDULED" and r.ata_utc:
                            status = "ARRIVED"
                        f.data_source = "IMPORTED"
                        f.sim_out_utc = None  # never simulated
                    else:
                        f.data_source = "IMPORTED" if status != "SCHEDULED" else "MANUAL"
                    f.status = status
                    db.flush()
                    if kind == "movements":
                        db.query(FlightMovement).filter(FlightMovement.flight_id == f.id).delete()
                        for ev, tt, ap in (("OUT", f.atd_utc, o.id), ("OFF", f.takeoff_utc, o.id), ("ON", f.landing_utc, d.id), ("IN", f.ata_utc, d.id)):
                            if tt:
                                db.add(FlightMovement(flight_id=f.id, event=ev, time_utc=tt, airport_id=ap, data_source="IMPORTED"))
                    elif f.status == "SCHEDULED":
                        ops.resimulate_flight(db, f)
                    inserted += new
                    updated += not new
                elif kind == "schedules":
                    r = ScheduleRow(**raw)
                    o, d = L["airports"].get(r.origin.upper()), L["airports"].get(r.destination.upper())
                    t = L["types"].get(r.aircraft_type.upper())
                    al = L["airlines"].get(r.airline.upper())
                    if not (o and d and t and al):
                        raise ValueError("unknown airport, aircraft_type or airline")
                    if r.valid_to < r.valid_from:
                        raise ValueError("valid_to before valid_from")
                    route = db.scalars(select(Route).where(Route.origin_id == o.id, Route.destination_id == d.id)).first()
                    dist = distance_nm(o.lat, o.lon, d.lat, d.lon)
                    if not route:
                        route = Route(origin_id=o.id, destination_id=d.id, distance_nm=round(dist, 1),
                                      typical_block_min=perf.scheduled_block_minutes(dist, t.cruise_ktas))
                        db.add(route)
                        db.flush()
                    db.add(FlightSchedule(airline_id=al.id, flight_number=r.flight_number.upper(), route_id=route.id,
                                          aircraft_type_id=t.id, days_of_week=r.days_of_week, std_utc=r.std_utc,
                                          block_min=perf.scheduled_block_minutes(dist, t.cruise_ktas),
                                          rotation_line=r.rotation_line or "", leg_seq=1, valid_from=r.valid_from,
                                          valid_to=r.valid_to))
                    inserted += 1
        except (ValidationError, ValueError, KeyError) as e:
            msg = "; ".join(f"{'.'.join(map(str, x['loc']))}: {x['msg']}" for x in e.errors()) if isinstance(e, ValidationError) else str(e)
            errors.append({"row": i, "error": msg})
    if dry_run:
        db.rollback()
    else:
        db.flush()
    return {"kind": kind, "rows": len(rows), "inserted": inserted, "updated": updated, "errors": errors[:500],
            "error_count": len(errors), "dry_run": dry_run}


def import_sqlite(db: Session, content: bytes, dry_run: bool = False) -> dict:
    """Import airports, aircraft and flights from another HH-FMS SQLite database/backup."""
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "import.db"
        p.write_bytes(content)
        con = sqlite3.connect(p)
        con.row_factory = sqlite3.Row
        try:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            res = {}
            if "airports" in tables:
                rows = [dict(r) for r in con.execute("SELECT * FROM airports")]
                rw = {}
                if "runways" in tables:
                    for r in con.execute("SELECT * FROM runways"):
                        rw.setdefault(r["airport_id"], []).append(f"{r['designator']}:{r['length_m']}")
                for r in rows:
                    r["runways"] = ";".join(rw.get(r["id"], [])) or None
                res["airports"] = import_rows(db, "airports", rows, dry_run=False)
            if "aircraft" in tables and "aircraft_types" in tables:
                types = {r["id"]: r["icao"] for r in con.execute("SELECT id, icao FROM aircraft_types")}
                airlines = {r["id"]: r["icao"] for r in con.execute("SELECT id, icao FROM airlines")} if "airlines" in tables else {}
                rows = []
                for r in con.execute("SELECT * FROM aircraft"):
                    d = dict(r)
                    d["aircraft_type"] = types.get(d["type_id"])
                    d["airline"] = airlines.get(d.get("airline_id"))
                    d["base"] = d.get("base_icao") or "EHAM"
                    rows.append(d)
                res["aircraft"] = import_rows(db, "aircraft", rows, dry_run=False)
            if "flights" in tables:
                aps = {r["id"]: r["icao"] for r in con.execute("SELECT id, icao FROM airports")}
                types = {r["id"]: r["icao"] for r in con.execute("SELECT id, icao FROM aircraft_types")}
                regs = {r["id"]: r["registration"] for r in con.execute("SELECT id, registration FROM aircraft")}
                airlines = {r["id"]: r["icao"] for r in con.execute("SELECT id, icao FROM airlines")}
                rows = []
                for r in con.execute("SELECT * FROM flights WHERE ata_utc IS NOT NULL OR status='CANCELLED' LIMIT 50000"):
                    d = dict(r)
                    rows.append({"flight_number": d["flight_number"], "date": d["flight_date"], "airline": airlines.get(d["airline_id"]),
                                 "origin": aps.get(d["origin_id"]), "destination": aps.get(d["destination_id"]),
                                 "std_utc": d["std_utc"], "sta_utc": d["sta_utc"], "atd_utc": d["atd_utc"],
                                 "takeoff_utc": d["takeoff_utc"], "landing_utc": d["landing_utc"], "ata_utc": d["ata_utc"],
                                 "aircraft_type": types.get(d["aircraft_type_id"]), "registration": regs.get(d["aircraft_id"]),
                                 "status": d["status"], "pax_booked": d["pax_booked"]})
                res["movements"] = import_rows(db, "movements", rows, dry_run=False)
        finally:
            con.close()
    if dry_run:
        db.rollback()
    return {"kind": "database", "results": res, "dry_run": dry_run}


def template_bytes(kind: str, fmt: str) -> tuple[bytes, str, str]:
    rows = TEMPLATES[kind]
    if fmt == "csv":
        return pd.DataFrame(rows).to_csv(index=False).encode("utf-8-sig"), "text/csv", f"{kind}_template.csv"
    if fmt == "xlsx":
        from .reports import to_excel

        return to_excel({kind: rows}), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", f"{kind}_template.xlsx"
    if fmt == "geojson" and kind == "airports":
        feats = [{"type": "Feature", "geometry": {"type": "Point", "coordinates": [r["lon"], r["lat"]]},
                  "properties": {k: v for k, v in r.items() if k not in ("lat", "lon")}} for r in rows]
        return json.dumps({"type": "FeatureCollection", "features": feats}, indent=2).encode(), "application/geo+json", "airports_template.geojson"
    return json.dumps(rows, indent=2, default=str).encode(), "application/json", f"{kind}_template.json"
