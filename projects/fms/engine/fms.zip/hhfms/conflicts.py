"""Scheduling conflict detection for aircraft, crew and airports."""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from . import perf
from .geo import distance_nm
from .models import Aircraft, Airport, Flight, FlightCrewAssignment, MaintenanceRecord, SystemConfig
from .refdata import TYPE_FAMILY


def _cfg(db: Session, key: str, default):
    row = db.get(SystemConfig, key)
    return row.value if row and row.value is not None else default


def _times(f: Flight) -> tuple[datetime, datetime]:
    dep = f.atd_utc or f.etd_utc or f.std_utc
    arr = f.ata_utc or f.eta_utc or (dep + (f.sta_utc - f.std_utc))
    return dep, arr


def _c(kind: str, sev: str, msg: str, flights: list[Flight], **extra) -> dict:
    return {
        "type": kind, "severity": sev, "message": msg,
        "flight_ids": [f.id for f in flights], "flights": [f"{f.flight_number} {f.flight_date}" for f in flights], **extra,
    }


def detect_conflicts(db: Session, start: datetime, end: datetime, flight_ids: set[int] | None = None) -> list[dict]:
    """Detect conflicts among non-cancelled flights departing in [start, end).

    A margin of one day on each side is loaded so rotations crossing the window
    edges are evaluated correctly. When `flight_ids` is given, only conflicts
    involving those flights are returned.
    """
    flights = db.scalars(
        select(Flight)
        .options(selectinload(Flight.crew).selectinload(FlightCrewAssignment.crew_member),
                 selectinload(Flight.aircraft).selectinload(Aircraft.type),
                 selectinload(Flight.origin).selectinload(Airport.runways),
                 selectinload(Flight.destination).selectinload(Airport.runways), selectinload(Flight.aircraft_type))
        .where(Flight.std_utc >= start - timedelta(days=1), Flight.std_utc < end + timedelta(days=1),
               Flight.status != "CANCELLED")
        .order_by(Flight.std_utc)
        .execution_options(populate_existing=True)
    ).all()
    in_window = {f.id for f in flights if start <= f.std_utc < end}
    out: list[dict] = []
    max_fdp = float(_cfg(db, "crew.max_fdp_hours", 13))
    min_rest = float(_cfg(db, "crew.min_rest_hours", 10))

    # ---------------- aircraft rotations
    by_ac: dict[int, list[Flight]] = defaultdict(list)
    for f in flights:
        if f.aircraft_id:
            by_ac[f.aircraft_id].append(f)
    for ac_id, fl in by_ac.items():
        fl.sort(key=lambda x: _times(x)[0])
        for a, b in zip(fl, fl[1:]):
            if a.status == "DIVERTED":
                continue
            a_dep, a_arr = _times(a)
            b_dep, _ = _times(b)
            gap = (b_dep - a_arr).total_seconds() / 60
            ac = a.aircraft
            reg = ac.registration if ac else str(ac_id)
            min_turn = (ac.type.min_turnaround_min if ac and ac.type else 30)
            if gap < 0:
                out.append(_c("AIRCRAFT_OVERLAP", "CRITICAL",
                              f"{reg}: {b.flight_number} departs {-gap:.0f} min before {a.flight_number} arrives", [a, b],
                              aircraft=reg))
            elif gap < min_turn and b.atd_utc is None:
                out.append(_c("TURNAROUND", "WARNING",
                              f"{reg}: only {gap:.0f} min ground time at {b.origin.icao} (minimum {min_turn})", [a, b],
                              aircraft=reg))
            if a.destination_id != b.origin_id and (b_dep - a_arr) < timedelta(hours=36):
                out.append(_c("CONTINUITY", "CRITICAL",
                              f"{reg}: arrives {a.destination.icao} but next flight {b.flight_number} departs {b.origin.icao}",
                              [a, b], aircraft=reg))

    # ---------------- aircraft status / maintenance / type / performance
    mx = db.scalars(select(MaintenanceRecord).where(
        MaintenanceRecord.status.in_(("PLANNED", "IN_PROGRESS")),
        MaintenanceRecord.kind.in_(("C-CHECK", "ENGINE", "DEFECT", "A-CHECK")),
        MaintenanceRecord.end_utc > start - timedelta(days=1), MaintenanceRecord.start_utc < end + timedelta(days=1),
    )).all()
    mx_by_ac: dict[int, list[MaintenanceRecord]] = defaultdict(list)
    for m in mx:
        mx_by_ac[m.aircraft_id].append(m)
    for f in flights:
        if f.id not in in_window or f.status in ("ARRIVED", "DIVERTED"):
            continue
        dep, arr = _times(f)
        if f.aircraft is None:
            out.append(_c("UNASSIGNED_AIRCRAFT", "WARNING", f"{f.flight_number}: no aircraft assigned", [f]))
        else:
            ac = f.aircraft
            if ac.operational_status in ("AOG", "STORED"):
                out.append(_c("AIRCRAFT_UNAVAILABLE", "CRITICAL", f"{f.flight_number}: {ac.registration} is {ac.operational_status}", [f],
                              aircraft=ac.registration))
            for m in mx_by_ac.get(ac.id, []):
                if m.start_utc < arr and m.end_utc > dep:
                    out.append(_c("MAINTENANCE", "CRITICAL",
                                  f"{f.flight_number}: {ac.registration} scheduled for {m.kind} {m.start_utc:%d %H:%M}-{m.end_utc:%d %H:%M}Z",
                                  [f], aircraft=ac.registration))
            if ac.type_id != f.aircraft_type_id:
                out.append(_c("TYPE_MISMATCH", "WARNING",
                              f"{f.flight_number}: planned {f.aircraft_type.icao} but {ac.registration} is {ac.type.icao}", [f],
                              aircraft=ac.registration))
                if (ac.seats or ac.type.pax_capacity) < f.pax_booked:
                    out.append(_c("CAPACITY", "CRITICAL",
                                  f"{f.flight_number}: {f.pax_booked} pax booked but {ac.registration} has {ac.seats} seats", [f]))
        t = f.aircraft.type if f.aircraft else f.aircraft_type
        dist = distance_nm(f.origin.lat, f.origin.lon, f.destination.lat, f.destination.lon)
        if not perf.range_ok(dist, t.range_km):
            out.append(_c("RANGE", "CRITICAL", f"{f.flight_number}: {dist:.0f} NM exceeds planning range of {t.icao}", [f]))
        for ap in (f.origin, f.destination):
            open_rw = [r.length_m for r in ap.runways if r.status != "CLOSED"]
            if not open_rw:
                out.append(_c("RUNWAY", "CRITICAL", f"{f.flight_number}: no open runway at {ap.icao}", [f]))
            elif max(open_rw) < t.min_runway_m:
                out.append(_c("RUNWAY", "CRITICAL", f"{f.flight_number}: longest open runway at {ap.icao} ({max(open_rw)} m) "
                                                    f"below {t.icao} requirement ({t.min_runway_m} m)", [f]))
            if ap.status == "CLOSED":
                out.append(_c("AIRPORT_CLOSED", "CRITICAL", f"{f.flight_number}: {ap.icao} is CLOSED", [f]))
        roles = {c.role for c in f.crew}
        if not {"CPT", "FO"} <= roles and f.status not in ("ARRIVED", "DIVERTED"):
            out.append(_c("CREW_MISSING", "WARNING", f"{f.flight_number}: cockpit crew incomplete ({', '.join(sorted(roles)) or 'none'})", [f]))

    # ---------------- crew
    by_crew: dict[int, list[Flight]] = defaultdict(list)
    crew_obj = {}
    for f in flights:
        for c in f.crew:
            by_crew[c.crew_id].append(f)
            crew_obj[c.crew_id] = c.crew_member
            fam = TYPE_FAMILY.get((f.aircraft.type.icao if f.aircraft else f.aircraft_type.icao), "")
            ratings = {r.strip() for r in (c.crew_member.type_ratings or "").split(",")}
            if f.id in in_window and fam and fam not in ratings:
                out.append(_c("CREW_RATING", "CRITICAL",
                              f"{c.crew_member.first_name} {c.crew_member.last_name} ({c.role}) not rated on {fam} for {f.flight_number}",
                              [f], crew=c.crew_member.employee_no))
    for cid, fl in by_crew.items():
        fl.sort(key=lambda x: _times(x)[0])
        cm = crew_obj[cid]
        name = f"{cm.first_name} {cm.last_name} ({cm.employee_no})"
        duty: list[Flight] = []
        for f in fl:
            if duty:
                prev = duty[-1]
                p_dep, p_arr = _times(prev)
                dep, _ = _times(f)
                gap_h = (dep - p_arr).total_seconds() / 3600
                if gap_h < 0:
                    out.append(_c("CREW_OVERLAP", "CRITICAL", f"{name}: assigned to overlapping flights {prev.flight_number} and {f.flight_number}",
                                  [prev, f], crew=cm.employee_no))
                if gap_h >= min_rest:
                    _check_fdp(duty, max_fdp, name, cm, out, in_window)
                    duty = []
                elif gap_h > 4 and gap_h < min_rest:
                    out.append(_c("CREW_REST", "WARNING",
                                  f"{name}: only {gap_h:.1f} h between {prev.flight_number} and {f.flight_number} (min rest {min_rest:.0f} h)",
                                  [prev, f], crew=cm.employee_no))
            duty.append(f)
        if duty:
            _check_fdp(duty, max_fdp, name, cm, out, in_window)

    if flight_ids is not None:
        out = [c for c in out if set(c["flight_ids"]) & flight_ids]
    else:
        out = [c for c in out if set(c["flight_ids"]) & in_window]
    # de-duplicate
    seen = set()
    uniq = []
    for c in out:
        k = (c["type"], tuple(c["flight_ids"]), c["message"])
        if k not in seen:
            seen.add(k)
            uniq.append(c)
    order = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
    uniq.sort(key=lambda c: (order.get(c["severity"], 3), c["type"]))
    return uniq


def _check_fdp(duty: list[Flight], max_fdp: float, name: str, cm, out: list, in_window: set[int]) -> None:
    if not duty:
        return
    start = _times(duty[0])[0] - timedelta(minutes=60)  # report time
    end = _times(duty[-1])[1] + timedelta(minutes=30)
    fdp = (end - start).total_seconds() / 3600
    if fdp > max_fdp and any(f.id in in_window for f in duty):
        out.append(_c("CREW_FDP", "WARNING", f"{name}: flight duty period {fdp:.1f} h exceeds {max_fdp:.0f} h",
                      duty, crew=cm.employee_no))
