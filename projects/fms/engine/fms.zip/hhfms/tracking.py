"""Flight position model for live tracking and historical playback.

Positions are *simulated* from the flight's OFF/ON times and a great-circle
route with a smooth lateral deviation and a climb/cruise/descent profile.
Every snapshot is labelled with its data source.
"""
from __future__ import annotations

import math
from datetime import datetime, timedelta

from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session, joinedload

from . import weather
from .geo import bearing_deg, distance_nm, intermediate, offset
from .models import Aircraft, Flight


def _profile(dur_min: float):
    climb = min(22.0, dur_min * 0.3)
    desc = min(28.0, dur_min * 0.35)
    cruise = max(0.0, dur_min - climb - desc)
    v_cl, v_cr, v_de = 0.62, 1.0, 0.68
    total = climb * v_cl + cruise * v_cr + desc * v_de
    return climb, cruise, desc, (v_cl, v_cr, v_de), total


def _along(tau: float, dur: float) -> tuple[float, float]:
    """(fraction of distance flown, relative speed) at tau minutes after takeoff."""
    climb, cruise, desc, (v1, v2, v3), total = _profile(dur)
    if tau <= climb:
        # speed ramps up linearly from 0.35 to v1*1.3 (avg ~v1)
        d = tau * v1
        v = v1
    elif tau <= climb + cruise:
        d = climb * v1 + (tau - climb) * v2
        v = v2
    else:
        t3 = min(tau - climb - cruise, desc)
        d = climb * v1 + cruise * v2 + t3 * v3
        v = v3 * (1 - 0.45 * t3 / max(desc, 1e-6))
    return min(1.0, d / total), v / (total / dur)


def _altitude(tau: float, dur: float, cruise_fl: int) -> float:
    climb, cruise, desc, _, _ = _profile(dur)
    top = cruise_fl * 100.0
    if tau <= climb:
        return top * (tau / climb) ** 0.75
    if tau <= climb + cruise:
        return top
    rem = max(0.0, dur - tau)
    return top * (rem / desc) ** 1.1


def flight_times(f: Flight) -> tuple[datetime | None, datetime | None]:
    off = f.takeoff_utc or f.sim_off_utc
    on = f.landing_utc or f.sim_on_utc
    return off, on


def dest_airport(f: Flight):
    if f.status == "DIVERTED" or (f.sim_divert and f.alternate is not None):
        return f.alternate or f.destination
    return f.destination


def position(f: Flight, t: datetime) -> dict | None:
    off, on = flight_times(f)
    if off is None or on is None or not (off <= t <= on):
        return None
    o = f.origin
    d = dest_airport(f)
    dur = (on - off).total_seconds() / 60
    tau = (t - off).total_seconds() / 60
    frac, rel_v = _along(tau, dur)
    dist = distance_nm(o.lat, o.lon, d.lat, d.lon)
    lat, lon = _point(f, o, d, frac, dist)
    lat2, lon2 = _point(f, o, d, min(1.0, frac + 0.002), dist)
    hdg = bearing_deg(lat, lon, lat2, lon2) if frac < 0.998 else bearing_deg(o.lat, o.lon, d.lat, d.lon)
    gs = dist / (dur / 60) * rel_v if dur > 0 else 0
    fl = f.cruise_fl or (f.aircraft_type.cruise_fl if f.aircraft_type else 350)
    alt = _altitude(tau, dur, fl)
    alt_next = _altitude(min(dur, tau + 1), dur, fl)
    return {
        "lat": round(lat, 5), "lon": round(lon, 5), "alt_ft": int(round(alt / 100) * 100), "gs_kt": int(round(gs)),
        "heading": int(round(hdg)) % 360, "vs_fpm": int(round((alt_next - alt) / 1)), "progress": round(frac, 4),
    }


def _point(f: Flight, o, d, frac: float, dist: float) -> tuple[float, float]:
    lat, lon = intermediate(o.lat, o.lon, d.lat, d.lon, frac)
    amp = min(30.0, 0.045 * dist) * (1 if weather._u("dev", f.flight_number) > 0.5 else -1)
    amp *= 0.4 + 0.6 * weather._u("amp", f.flight_number, str(f.flight_date))
    dev = amp * math.sin(math.pi * frac)
    if abs(dev) > 0.01:
        brg = bearing_deg(o.lat, o.lon, d.lat, d.lon) if frac < 0.5 else bearing_deg(lat, lon, d.lat, d.lon)
        lat, lon = offset(lat, lon, (brg + 90) % 360, dev)
    return lat, lon


def trajectory(f: Flight, until: datetime | None = None, step_s: int = 60) -> list[dict]:
    off, on = flight_times(f)
    if off is None or on is None:
        return []
    end = on if until is None else min(on, until)
    pts = []
    out_t = f.atd_utc or f.sim_out_utc
    if out_t and out_t < off:
        pts.append({"t": out_t.isoformat(), "lat": f.origin.lat, "lon": f.origin.lon, "alt_ft": 0, "gs_kt": 0, "heading": 0, "phase": "TAXI"})
    t = off
    while t <= end:
        p = position(f, t)
        if p:
            p["t"] = t.isoformat()
            p["phase"] = "CLIMB" if p["vs_fpm"] > 300 else ("DESCENT" if p["vs_fpm"] < -300 else "CRUISE")
            pts.append(p)
        t += timedelta(seconds=step_s)
    if end == on:
        p = position(f, on)
        if p:
            p["t"] = on.isoformat()
            p["phase"] = "LANDED"
            pts.append(p)
    return pts


def _flight_info(f: Flight) -> dict:
    d = dest_airport(f)
    return {
        "flight_id": f.id, "flight_number": f.flight_number, "callsign": f.callsign,
        "registration": f.aircraft.registration if f.aircraft else None,
        "type": f.aircraft_type.icao if f.aircraft_type else None,
        "origin": f.origin.icao, "destination": d.icao, "planned_destination": f.destination.icao,
        "std": f.std_utc.isoformat(), "sta": f.sta_utc.isoformat(),
        "atd": f.atd_utc.isoformat() if f.atd_utc else None,
        "eta": (f.eta_utc or f.sim_in_utc or f.sta_utc).isoformat(),
        "status": f.status, "airline_id": f.airline_id,
        "data_source": "SIMULATED" if f.data_source in ("SIMULATED", "MANUAL") else f.data_source,
    }


def _load(db: Session, t0: datetime, t1: datetime, live: bool):
    q = (
        select(Flight)
        .options(joinedload(Flight.origin), joinedload(Flight.destination), joinedload(Flight.alternate),
                 joinedload(Flight.aircraft), joinedload(Flight.aircraft_type))
        .where(Flight.status != "CANCELLED")
    )
    if live:
        q = q.where(Flight.status.in_(("DEPARTED", "AIRBORNE", "LANDED")))
    else:
        q = q.where(
            or_(and_(Flight.takeoff_utc.is_not(None), Flight.takeoff_utc <= t1, Flight.landing_utc >= t0),
                and_(Flight.takeoff_utc.is_(None), Flight.sim_off_utc <= t1, Flight.sim_on_utc >= t0))
        )
    return db.scalars(q).unique().all()


def snapshot(db: Session, t: datetime, live: bool = True) -> list[dict]:
    out = []
    for f in _load(db, t, t, live):
        p = position(f, t)
        if p is None:
            if not live:
                continue
            # departed but not yet airborne / landed and taxiing: show on the ground
            ap = f.origin if f.status == "DEPARTED" else dest_airport(f)
            p = {"lat": ap.lat, "lon": ap.lon, "alt_ft": 0, "gs_kt": 12, "heading": 0, "vs_fpm": 0,
                 "progress": 0.0 if f.status == "DEPARTED" else 1.0}
        out.append({**_flight_info(f), **p, "data_source": "SIMULATED" if live else "HISTORICAL"})
    return out


def playback(db: Session, t0: datetime, t1: datetime, step_s: int = 60, max_flights: int = 400) -> dict:
    """Frames for replaying all flights airborne in [t0, t1]."""
    flights = _load(db, t0, t1, live=False)[:max_flights]
    tracks = []
    for f in flights:
        pts = []
        off, on = flight_times(f)
        t = max(t0, off)
        end = min(t1, on)
        # align to step grid
        t = t0 + timedelta(seconds=math.ceil((t - t0).total_seconds() / step_s) * step_s)
        while t <= end:
            p = position(f, t)
            if p:
                pts.append([int((t - t0).total_seconds()), p["lat"], p["lon"], p["alt_ft"], p["gs_kt"], p["heading"]])
            t += timedelta(seconds=step_s)
        if pts:
            tracks.append({**_flight_info(f), "points": pts})
    return {"start": t0.isoformat(), "end": t1.isoformat(), "step_s": step_s, "tracks": tracks,
            "data_source": "HISTORICAL (simulated trajectory reconstruction)"}
