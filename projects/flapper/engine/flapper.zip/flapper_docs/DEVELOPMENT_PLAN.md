# Development plan and status

| Phase | Scope | Status (2026-11-15) |
|---|---|---|
| 0 Inspection & feasibility | audit, requirements, architecture, conventions, feasibility, risk register, plan | **Done** |
| 1 Digital aircraft model | parametric geometry, kinematics, four-bar, quasi-steady aero + structure, 6-DOF, RK4/DOPRI | **Done** (first milestone) |
| 2 Engineering digital twin | 3-D aircraft driven by sim state, linkage, internals, exploded view, live dashboard | **Done** (procedural geometry; GLB export pending) |
| 3 Aerodynamic research lab | cycle plots, 1-D/2-D captive and trim sweeps, experiment recording, comparison | **Done** |
| 4 Mechanical & electrical design | STEP/STL CAD, twist linkage, component selection, wiring, pinouts | **Partly done**: twist linkage designed; components selected from listings (rev 8, COMPONENT_SELECTION.md); CAD, wiring and pinouts open (pinouts only from the FC documentation) |
| 5 Flight control | cascaded controller, allocation analysis, step tests, estimator | **Partly done**: EKF, LQR/gain scheduling and roll effector study open |
| 6 Autonomous system | waypoints, loiter, RTH, health monitoring | **Partly done**: perception/AI module not started |
| 7 Hardware integration | firmware, drivers, HIL, bench mode with interlocks | Not started (intentionally) |
| 8 Experimental validation | test cards executed, model error quantified | Not started; templates ready |
| 9 Research-grade release | packaging (Docker), reports, roadmap | Not started |

## Next steps (priority order)

1. ~~**R-01**: Wagner unsteady lift~~ (done, us-bem-1.1). Next for R-01: unsteady vortex-lattice comparison of the cruise cycle; dynamic-stall delay.
2. ~~**D-01 / R-02**: twist linkage~~ (DS-02) and ~~co-optimisation~~ (DS-03, rev 3). Next: root-yoke friction; a variable-throw eccentric for high-speed efficiency; widen the stiffness bound once MECH-04 data exists.
3. ~~**R-04**: roll effector~~ (CS-02, rev 4) and ~~servo load path~~ (CS-03: differential bellcrank). Next: heading-gain scheduling; bench card ACT-02.
4. ~~**R-09**: wing-park~~ DS-04 detent (rev 5) found ineffective in the dynamic drive; replaced by the twist + hinge-spring release (DS-04b, rev 8). Next: release bench test MECH-07 (sear trigger force, reliability); parked-wing landing; gearbox-jam case.
5. ~~Motor/gear sizing~~ (DS-05, rev 6), ~~elastic energy storage~~ (DS-06, rev 7), ~~component selection~~ (rev 8: Scorpion SII-2205 on 3S at 30:1, Matek H743-WLITE, …). Next: gearbox design to η ≥ 0.9 and its bench measurement; pin assignment from the H743-WLITE documentation; second-source servo (ES9051 partly discontinued); parametric CAD export (STEP/STL/GLB).
6. EKF estimator; gain scheduling across 9–14 m/s.
7. Learning-based research module (RL in simulation), always compared with the deterministic baseline.
