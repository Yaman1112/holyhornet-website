# Flapping transmission trade study

Requirements driving the choice: about 5–7 Hz continuous flapping, ±30° stroke, hinge torque peaks about 1 N·m (simulated cruise cycle), low mass (< 35 g for gearbox + linkage), repairable, measurable.

| Concept | Complexity | Weight | Efficiency | Backlash | Vibration | Fatigue | Maintainability | Cost | Assessment |
|---|---|---|---|---|---|---|---|---|---|
| Crank-rocker (four-bar) | Low | Low | High (pin joints) | Low-moderate | Moderate (crank inertia) | Good | Good | Low | **Selected baseline** |
| Four-bar with adjustable ground pivot | Moderate | Moderate | High | Low | Moderate | Moderate | Moderate | Moderate | Upgrade path: in-flight mean/amplitude control (roll authority, R-04) |
| Cam + follower | Moderate | Moderate | Lower (sliding contact) | Low | Low | Wear-limited | Moderate | Moderate | Arbitrary stroke shape, but friction and wear at 5 Hz |
| Sector-gear drive | High | High | High | Moderate-high | Moderate | Good | Poor | High | Load reversal on the teeth at every stroke; backlash at reversal |
| Servo-assisted articulation | Moderate | Moderate | Low at 4–6 Hz | Servo-limited | Low | Poor (servo duty) | Good | Low | Bandwidth and heating limits at wingbeat frequency |

## Why the crank-rocker

* It can be computed in closed form, so loads, transmission angle and singularity proximity are known exactly (`mechanism.py`).
* With the synthesised geometry (r2 ≈ 8 mm crank, r3 ≈ 40 mm coupler, r4 = 16 mm lever with −30° bend, crank centre 30 mm below the hinge plane) the minimum transmission angle is **57°**. The linkage is a Grashof crank-rocker with no toggle. A first geometry (12 mm straight lever, crank 28 mm below) reached only 11°, close to a change-point mechanism. A geometry scan found the current layout.
* Downstroke fraction ≈ 0.503: the linkage is almost symmetric in time.
* **Dual counter-rotating cranks** give exact left/right symmetry. A **single crank pin** driving both couplers gives a **52°** top-of-stroke lag (computed), a large asymmetry that would excite roll and yaw, so it is rejected.

## Open items

* ~~Twist linkage (decision D-01)~~: designed in [studies/DS-02_TWIST_DRIVE.md](studies/DS-02_TWIST_DRIVE.md). It is a rotating LE torque tube with a pitch horn on the flap axis, driven by a push rod from a 1:1 idler eccentric, with a series torsion spring. Tracking is 0.91° RMS; adds 16 g.
* Bearings and pins sized from the coupler-force history (Mechanical workspace load case).
* Wing-park detent for glide (R-09).
