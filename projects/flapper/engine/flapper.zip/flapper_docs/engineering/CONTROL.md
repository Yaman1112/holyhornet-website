# Flight control

## Hierarchy

| Level | Function | Implementation |
|---|---|---|
| L1 actuator | wingbeat frequency per wing (first-order lag 0.15 s), stroke amplitude/mean per wing (if fitted), elevator/rudder ±25° | `model.py` drive, `control.py` limits |
| L2 attitude | pitch → elevator with pitch-rate damping; bank → rudder; yaw damper; bank → differential amplitude if fitted | `Controller.update` |
| L3 flight | altitude → pitch command (PI + vertical-speed damping); airspeed → frequency (PI); heading → bank command | `Controller.update` |
| L4 navigation | hold / waypoint / loiter / return-to-home / glide fail-safe; comms timeout; GNSS loss → dead reckoning | `Controller.navigate` |

**Signal conditioning.** The body oscillates at the wingbeat frequency (pitch about ±0.6° peak-to-peak in cruise). All feedback passes through a moving average over exactly one stroke period, which places notches at the wingbeat frequency and its harmonics. The controller therefore acts on cycle-mean motion.

**Estimation.** `truth` (simulated true state, for controller development) or `complementary`: gyro integration, accelerometer tilt correction with centripetal compensation (ω × V), GNSS-course yaw correction, barometric altitude, and airspeed dead reckoning when GNSS is lost. An EKF is planned.

## Envelope protection (added in DS-03)

Cruising near the stall-limited minimum speed leaves little lift for manoeuvres. Without protection, the altitude loop raised pitch during a climbing turn until the aircraft stalled (ground impact in a waypoint mission). The controller now gives **airspeed priority** below v_protect = 0.93 × commanded airspeed:
* the pitch command is reduced by 0.12 rad per m/s of speed deficit, and the altitude integrator may not wind up a climb
* the bank limit drops to 12° while protecting
* the commanded climb rate is capped at 1 m/s

The operating speed is 12 m/s: the lowest speed meeting the 1.15 g rule (stall ≤ 0.5) for revision 3. At 11 m/s revision 3 still completes a 90° turn and a climbing mission in closed loop, but its margin is below target (1.15 g stall 0.53).

## Direct roll control: differential twist (revision 4, study CS-02)

One servo trims both twist push rods in opposition, giving a left/right torque-tube pitch offset ("wing warping"). Law: δt = −20 °/rad × (φ_cmd − φ) + 8 °/(rad/s) × p, limited to ±10° and 600°/s. The rudder is a yaw damper only. Effectiveness: −2.48 N·m/rad of roll, which is 36× the rudder's, with proverse yaw. A differential stroke-mean effector was evaluated and rejected (it makes side force, not roll). See [studies/CS-02_ROLL_EFFECTOR.md](studies/CS-02_ROLL_EFFECTOR.md).

## Control allocation and authority

Baseline effectors: wingbeat frequency (both wings), elevator and rudder. The cycle-averaged effectiveness at 10 m/s (FEASIBILITY_RESULTS.md):

* frequency → axial force (≈ 1.5 m/s² per Hz), with a small pitch moment
* elevator → pitch moment and normal force
* rudder → yaw moment, with a small roll moment from the fin height

With three effectors for six rigid-body DOF the aircraft is **under-actuated**. Roll is reached only through yaw → sideslip → dihedral (the 5° mean stroke angle). The configuration exposes optional differential amplitude, frequency and mean effectors so the effect of real roll authority can be studied. The allocator and stability analysis only use effectors marked as fitted.

## Tuning studies

**CS-01: lateral gains** (raw output in `studies/CS-01_lateral_gain_scan_raw.txt`). A 2 × 2 × 2 × 2 grid over bank→rudder gain, roll-rate→rudder gain, yaw damper and heading gain, with 30 s runs and a 90° heading command. The original gains (1.2 / 0.15 / 0.25 / 0.9) produced a sustained ±25° rudder limit cycle. **Any non-zero roll-rate→rudder feedback produced 4–6° RMS roll oscillation**: the rudder acts on roll only through a lagged sideslip path, so rate feedback through it is destabilising. Selected: bank→rudder 0.6, roll-rate→rudder 0, yaw damper 0.25, heading 0.5. Result: 0.03° RMS roll and 0.02° mean heading error after the turn.

**Longitudinal.** Altitude hold 0.16 m RMS in calm air (20 s). In free flight the aircraft needed 5.5 Hz against the 5.12 Hz averaged trim, and the speed integrator absorbs the difference.

All gains are **simulation-tuned only**. They must be re-identified on hardware (HIL, then tethered tests).
