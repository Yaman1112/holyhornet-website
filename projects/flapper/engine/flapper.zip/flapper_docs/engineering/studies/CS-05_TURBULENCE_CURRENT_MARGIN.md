# CS-05: motor-current margin and strong turbulence (revision 9)

**Status:** simulation study. All numbers **SIMULATED** with the motor + gearbox + crank model
(`kinematics.drive = "motor_crank"`), 120 s runs, two turbulence seeds each.
Tool: `backend/tools/study_cs05_turbulence_margin.py` → `data/studies/cs05_turbulence_margin.json`.

## 1. Question

The rev-8 requirement envelope showed a 9.35 A battery-current peak in turbulence against the motor's 10 A
continuous rating. Motor current was not even logged, and with throttle below 1 it is higher than battery
current, so the margin could be worse than reported.

## 2. What the current actually does

Motor current is now recorded (`motor_i`). It is pulsed: it rises with every power half-stroke and drops to
zero when the wings back-drive the crank, so peak ≈ 2.4 × RMS. The 10 A ceiling (the ESC current limit in
the model) is reached only in those pulses. The listing's 10 A is a *continuous*, thermal rating; RMS stays at
2–4 A and the winding rise is 6–18 K over 120 s (thermal time constant ≈ 100 s, from estimated parameters).

Removing the 10 A cap changes airspeed and altitude holding very little: the cap is not what limits flight.

## 3. What actually fails: strong turbulence

At turbulence σ 1.5 m/s the rev-8 aircraft **hit the ground at 73 s** (seed 5). Cause, from the trace:
the wingbeat command sat at its 8 Hz cap 43% of the time, speed protection was active 78% of the time and the
mean stall fraction was 0.45. Gusts stall the wing, drag rises and speed falls, the speed loop runs out of
wingbeat command, and envelope protection trades altitude for speed. The motor was not the limit:
mean throttle 0.5, saturated 0.2% of the time.

## 4. Levers compared

| Variant | σ 1.0: lowest altitude (from 40 m) | σ 1.5: lowest altitude | σ 1.5: time at 10 A | σ 1.5: motor RMS | Calm cruise |
|---|---|---|---|---|---|
| rev 8 (30:1, 8 Hz cap) | 30–31 m | **ground impact** / 17 m | 9–11% | 4.0–4.2 A | 18.49 W |
| 34:1 only | 31–34 m | 6 m / 19 m | 2–4% | 3.2–3.6 A | 18.81 W |
| gust speed margin only | 33–35 m | 4 m / 24 m | 5–9% | 3.7–4.2 A | 18.49 W |
| **adopted: 34:1 + 10 Hz cap + gust margin** | **34–35 m** | **20 m / 27 m** | **2–3%** | **3.1–3.6 A** | **18.81 W** |

Also tried (exploratory runs, same conditions): a fixed 13 m/s airspeed (good in turbulence, but +1.8 W in
calm air) and a 10 Hz cap alone (avoided the crash but bottomed at 3.7 m).

## 5. Adopted design (rev 9)

* **Gearbox 34:1** (was 30:1). Lower motor torque per unit crank torque: time at the current limit falls about
  4×, RMS current about 20%, winding rise about a third. Cost +0.3 W (+1.7%) in cruise; endurance 18.3 →
  18.1 min. At the 20% reserve state of charge 14 m/s still holds with mean throttle 0.87 (no saturation),
  i.e. about 13% voltage headroom (30:1 had 0.77).
* **Wingbeat command cap 10 Hz** (was 8). Above about 8.5 Hz the 3S/34:1 drive is voltage-limited anyway, so
  this only stops the controller saturating before the motor does.
* **Adaptive turbulence speed margin.** The controller tracks the running standard deviation of the
  wingbeat-averaged airspeed (5 s time constant) and adds 1.5 × (σ̂ − 0.3 m/s), capped at +2 m/s, to the
  airspeed command. σ̂ reads about 0.7 × the turbulence σ; calm cruise and turns read 0.05–0.16 and a calm
  climbing mission 0.16 on average, so calm flight gets no margin. Speed protection stays tied to the base
  command. In σ 1.5 the margin averages +1.2 m/s.

The motor-failure release park (DS-04b) is unchanged on 34:1 (tests pass; park at 237°).

## 6. Limits

* σ 1.5 m/s at 12 m/s is strong turbulence for a 334 g aircraft; two seeds per case are a small sample, and
  the turbulence model (Gauss–Markov, 30 m length) is simple. An operating limit (σ ≤ 1.0 m/s with full margin;
  σ 1.5 m/s survivable but costly in altitude) is recorded as requirement PLT-09 and risk R-16.
* The 10 A cap stands for an ESC current limit that must actually be configured (AM32 supports one);
  the motor's burst rating is not published, so the model treats 10 A as hard.
* Gearbox efficiency (0.75) is still assumed; at 34:1 a two-stage spur box is still adequate.
* Tests: `test_gust_margin_zero_in_calm_and_positive_in_gusts` (estimator) and
  `test_survives_strong_turbulence_with_current_margin` (σ 1.5, 90 s, altitude stays above 10 m, < 5% of the
  time at the current limit; rev 8 crashed at 73 s).
