# DS-03: co-optimising the flapping stroke and the twist linkage (baseline revision 3)

Date 2026-11-14 · model us-bem-1.1 (unsteady lift, flexible wings) · all results simulated.
Data: `data/studies/ds03_cooptimise.json` (stage 1–2), `ds03b_manoeuvre.json` (stage 3), evaluation caches `ds03*_eval_cache.jsonl`.
Tool: `backend/tools/study_ds03_cooptimise.py` (`--manoeuvre` for stage 3).

## 1. Problem

Revision 2 made the driven twist real (DS-02) at a cost of +27% cruise power. Its stroke and twist parameters were chosen separately. This study optimises them together.

**Design variables (8):** stroke amplitude, stroke mean, crank-centre lateral offset (quick-return asymmetry), crank-centre height, wing-lever bend (stroke shape and transmission), driven-twist amplitude, twist phase lead, and series twist stiffness.

For every candidate, the four-bar and the twist linkage are **re-synthesised**, then checked:
* four-bar: Grashof crank-rocker, minimum transmission angle ≥ 40°, within the hinge stops
* twist linkage: closes; tracking ≤ 2° RMS; transmission ≥ 0.5
* trimmed level flight with stalled fraction ≤ 0.35

## 2. Stages

| Stage | Method | Objective | Result |
|---|---|---|---|
| 1 | 64-point Latin hypercube | P_elec at 10 m/s | only **1/64 feasible**. 14 failed the four-bar transmission limit; the rest passed all mechanics but failed trim or the stall limit. The good region is a narrow valley around matched twist phase. |
| 2 | compass/pattern search, 6 rounds | P_elec at 10 m/s | 21.69 → **17.69 W** (−18%), better at every speed 10–14 m/s |
| 3 | pattern search, 4 rounds, **plus manoeuvre constraint** | P_elec at 11 m/s, with a 1.15 g trim at 11 m/s and stall ≤ 0.5 | 19.73 → **18.55 W** |

A worker crash in the first attempt (the session ended mid-run) lost all results. The study is now **resumable**: every evaluation is appended to a cache, and a broken worker pool is rebuilt automatically.

## 3. Why stage 3 was needed: the stage-2 optimum could not manoeuvre

Robustness checks on the stage-2 optimum:

| Check | Result |
|---|---|
| Power under twist ±10%, lead ±5°, stiffness −15/+30% | robust: 17.5–18.3 W |
| Stall under lead +5° / mass +10% | **0.56 / 0.64** (optimum sits on the stall edge) |
| Lead −40° variant, 90° turn in closed-loop free flight | **ground impact** |
| **Revision 2 baseline**, 90° turn at 10 m/s | **ground impact** (speed decayed to 6.4 m/s) |
| Rev 2 / optimum, trim at 1.15 g, 10 m/s | **no trim** (stall 0.72 / 0.78) |

The root cause is that 10 m/s, the "best endurance" speed, is also the **minimum** trimmed speed. Cruising there leaves no lift for a bank. A level-flight power objective cannot see this, so the optimiser traded the margin away.

**Corrections:**
1. The operating speed becomes the lowest speed with a 1.15 g manoeuvre margin, which is **11 m/s**. Both designs trim at 1.15 g there.
2. Stage 3 re-optimises under that constraint.
3. The feasibility analysis now checks the 1.15 g margin at every speed and reports endurance only at speeds that have it.

## 4. Second finding: the controller needed envelope protection

The rounded stage-3 design passed the cruise and the 90° turn at 11 m/s, but **crashed in a waypoint mission** that combines turns with a 5 m climb. The altitude loop kept raising pitch while airspeed fell from 11 to 7 m/s.

Fix in `control.py`, which applies to every revision:
* **airspeed priority** below v_protect (0.93 × commanded speed): pitch command reduced 0.12 rad per m/s of deficit and the altitude integrator stopped
* bank limited to 12° while protecting
* climb rate capped at 1 m/s

With protection, revision 2, the exact stage-3 optimum and the selected design all complete the mission (protection active 2–3% of the time).

Simulator monitoring also gained hysteresis: the per-wingbeat stall warning had flooded the log (~60 identical entries in one turn).

## 5. Selected design (revision 3)

| Parameter | Rev 2 | Rev 3 |
|---|---|---|
| Stroke amplitude | 30° | **28°** |
| Crank-centre lateral offset | 0 | **−3 mm** (downstroke fraction 0.514) |
| Wing-lever bend | −30° | **−20.5°** |
| Driven tip twist | ±30° | **±21.75°** |
| Twist lead | −35° | **−28.75°** |
| Series twist stiffness | 1.0 N·m/rad | **0.6 N·m/rad** (search lower bound) |
| Operating speed | 10 m/s (no margin) | **12 m/s** (the 1.15 g rule; 11 m/s flies in closed loop but is marginal) |

Engineering choice: the exact stage-3 optimum has bend −18.75° and only **40.6°** transmission angle (0.6° margin). Revision 3 uses −20.5°, giving **42.9°**, at a cost of +0.12 W. Its 1.15 g stall fraction is **0.53**, slightly over the 0.5 target. I accepted that because the transmission angle is a hard mechanical limit (pin loads), while the stall threshold is a model-confidence heuristic, and the design still completes the turn and mission.

Twist linkage for revision 3: eccentric 5.5 mm, rod 35.3 mm; tracking 0.57° RMS (1.1° max); transmission 0.83.

| Speed | Rev 2 P_elec | **Rev 3 P_elec** |
|---|---|---|
| 11 m/s (operating) | 24.40 W | **18.67 W (−23.5%)** |
| 12 m/s | 28.22 W | ≈21.3 W |
| 14 m/s | 37.75 W | ≈28.3 W |
| 9 m/s | no trim | no trim |

### Endurance at the speeds that meet the 1.15 g rule (FEASIBILITY_RESULTS.md, automated)

| | Revision 2 | **Revision 3** |
|---|---|---|
| Lowest speed meeting the rule | 11 m/s | 12 m/s (11 m/s fails at stall 0.53, a consequence of choosing transmission margin) |
| Electrical power there | 24.4 W | **21.2 W** |
| Endurance / range | 15.3 min / 10.1 km | **17.7 min / 12.7 km (+16% endurance)** |

## 6. Caveats

* The stiffness ended at the 0.6 N·m/rad lower bound of the search. Softer might be better, but the elastic-twist model and spring design are least credible there. It must be measured (MECH-04).
* The stall margin is the binding aerodynamic constraint, and post-stall aerodynamics are the least reliable part of the model (no LEV or dynamic-stall model).
* All gains are simulated. Revision 3 has the same unverified assumptions as revision 2: estimated masses, the membrane twist distribution, and the motor model.
