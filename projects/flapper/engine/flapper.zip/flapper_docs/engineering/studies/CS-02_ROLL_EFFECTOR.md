# CS-02: direct roll effector (risk R-04, baseline revision 4)

Date 2026-11-14 · model us-bem-1.1 · revision-3 airframe at 12 m/s (operating speed) · closed-loop 6-DOF · all results simulated.
Tool: `backend/tools/study_cs02_roll_effector.py`. Data: `data/studies/cs02_roll_effector.json`, cache `cs02_eval_cache.jsonl`.

## 1. Problem

Revisions 1–3 have no direct roll effector. Bank is reached indirectly (rudder → sideslip → dihedral of the 5° mean stroke → roll). That path is slow, produces large sideslip, and leaves the aircraft under-actuated.

## 2. Which effectors are physically possible

With one crank driving both wings through fixed four-bars, **differential frequency** and **differential amplitude** are impossible without a variable-stroke drive. Two options remain buildable:

| Candidate | Mechanism |
|---|---|
| Differential stroke mean | a servo shifts each rocker pivot oppositely (wing mean angles change) |
| **Differential twist bias ("wing warping")** | one servo with a bellcrank lengthens one twist push rod and shortens the other, so the torque tubes get a ± pitch offset |

## 3. Control effectiveness (cycle-averaged, 12 m/s, per radian)

| Input | Roll moment [N·m] | Yaw moment [N·m] | Side accel. [m/s²] |
|---|---|---|---|
| Rudder | 0.069 | −0.49 | 4.53 |
| Differential stroke mean | −0.013 | +0.064 | −5.39 |
| **Differential twist** | **−2.48** | −0.11 (proverse) | −3.82 |

* Differential twist has **36× the rudder's roll authority**. Its yaw has the same sign as its roll (proverse), so the nose follows the bank.
* Differential stroke mean is **useless for roll**: 200× weaker than twist. Shifting a wing's mean angle tilts its lift sideways, producing side force rather than a rolling moment. **Rejected.**

## 4. Control law and gain scan

* Twist warping: δt = −K_φ (φ_cmd − φ) + K_p p, limited to ±10° and to a 600°/s servo slew rate.
* The rudder becomes a yaw damper only.
* 24-point scan (K_φ 10/20/40 °/rad, K_p 0/3, bank → rudder 0/0.3, heading gain 0.5/1.0) on a 90° heading change. Fastest: K_φ 20, heading gain 1.0, giving 4.55 s to 90%. No overshoot anywhere in the scan.

## 5. Closed-loop comparison (12 m/s)

The first comparison used heading gain 1.0 for twist and 0.5 for rudder. Twist then looked **worse** in gusts, which was a confound: a higher heading gain makes the aircraft bank harder for every gust-induced heading error. The comparison was repeated at matched heading gain:

| Scenario | Rudder-only | **Twist warping (heading gain 0.5, K_p 8): adopted** | Twist "agile" (heading gain 1.0) |
|---|---|---|---|
| 45° turn, time to 90% | 6.6 s | — | 2.9 s |
| 90° turn, time to 90% | 7.6 s | **5.8 s** | 4.7 s |
| 180° turn, time to 90% | 11.6 s | — | 8.6 s |
| Max sideslip in turns | 5.2° | **2.3°** | 2.3–2.7° |
| Lateral 3 m/s gust: max bank / roll RMS | 6.5° / 1.00° | **6.1° / 0.83°** | 9.2° / 1.46° |
| Turbulence σ 0.8 m/s: max bank / roll RMS | 5.1° / 1.55° | **4.3° / 1.12°** | 6.6° / 1.87° |
| Heading RMS in turbulence | 2.20° | 2.31° | 2.39° |
| Climbing waypoint mission | completed, sideslip 7.1° | completed, sideslip 3.0° | — |
| Mission electrical power | 23.3 W | 24.0 W | — |

Rudder-only can't reach the commanded 25° bank (18.5° max), which is the under-actuation in practice. (The 180° "overshoot" values in the raw log are an artefact of the ±180° heading wrap in the metric, not real overshoot.)

## 6. Decision (revision 4)

**Fit differential twist**: one 9 g-class servo plus a bellcrank on both twist push rods, +12 g (mass 330 g). Gains: K_φ 20 °/rad, K_p 8 °/(rad/s), heading gain 0.5, rudder as yaw damper.

Cost at 12 m/s: 21.41 W against 21.18 W (+1.1%, from the servo mass). The 1.15 g manoeuvre margin at 12 m/s is kept (stall 0.36). Endurance with margin: **17.5 min at 12 m/s** (rev 3: 17.7 min), range 12.6 km (FEASIBILITY_RESULTS.md).

## 7. Open items

* ~~**Servo load.**~~ Resolved in [CS-03](CS-03_TWIST_SERVO_LOAD_PATH.md): in a differential bellcrank the symmetric rod loads cancel, leaving < 2% of servo stall. Original concern: the push rods carry ±9 N cyclic loads at the wingbeat frequency (DS-02). A trim servo holding them sees about 0.07 N·m oscillating at 6 Hz. That is within micro-servo stall torque, but it causes wear and gear backlash. Prefer an irreversible drive (lead-screw / worm) or a bellcrank geometry that reacts the rod loads into the structure. To bench-test.
* The ±10° bias range and the 600°/s slew are assumptions about servo class.
* Gain scheduling between the adopted and agile heading gains (fast turns vs gust calm).
