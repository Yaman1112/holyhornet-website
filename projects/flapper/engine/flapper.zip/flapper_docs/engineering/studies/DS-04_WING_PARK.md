# DS-04: wing-park detent (risk R-09, baseline revision 5)

Date 2026-11-14 · model us-bem-1.1 · revision-4 airframe · closed-loop 6-DOF · motor failure at t = 5 s, start 120 m · all results simulated.
Tool: `backend/tools/study_ds04_wing_park.py`. Data: `data/studies/ds04_wing_park.json`, cache `ds04_eval_cache.jsonl`.

## 1. Problem

After loss of drive the wings stop at whatever stroke phase the crank reaches. Revision 1 departed after a motor failure. This study asks two questions: how often is an arbitrary stop fatal, and where should a detent park the wings?

## 2. Model

* **Detent:** after drive loss, a spring-roller detent on the crank shaft captures the back-drivable crank (spring-damper about the park angle, 4 Hz, ζ 0.7). Wing stroke and twist follow from the four-bar and twist linkage at that angle.
* **Glide controller (improved):** pitch holds the glide speed (nose down when slow), the roll servo holds heading, and the rudder damps yaw.
* **Holding torque:** the torque the parked wings exert on the crank, computed by virtual work (flap hinge torque × dφ/dθ + twist torque × dθ_twist/dθ). The old power/Ω form was singular when the crank stopped; it was replaced.

## 3. Results: calm-air glide by stop angle

| Park angle | Outcome | L/D | Speed [m/s] | Stroke [°] | Holding torque [N·m] |
|---|---|---|---|---|---|
| 0, 30 | **ground impact** | — | — | — | — |
| 60 | glide | 4.7 | 11.8 | −23 | 0.04 |
| 90 | glide | 6.7 | 10.0 | −19.5 | 0.12 |
| 120 | glide | 7.6 | 8.3 | −9.3 | 0.27 |
| 150 | deep-stall "parachute" | 1.7 | 6.7 | +4.4 | 0.29 |
| 180 | **ground impact** | — | — | — | — |
| 210 | **loss of control** | — | — | — | — |
| 240 | glide | 6.6 | 8.2 | +33 | 0.004 |
| 270 | glide | 6.0 | 10.4 | +28.6 | 0.10 |
| 300 | glide | 4.2 | 11.9 | +19.3 | 0.05 |
| 330 | **ground impact** | — | — | — | — |

**Without a detent, about half the possible stop angles lose the aircraft** (5 of 12 fatal, plus one deep stall).

## 4. Robustness: lateral 2 m/s gust and a 90° turn in the glide

| Angle | Gust: max roll / stall | Glide turn |
|---|---|---|
| 90 | 7.9° / 0.02 | ✓ |
| 120 | 13.3° / 0.25 | ✓ |
| 225 | **ground impact** | **ground impact** |
| 240 | 18.0° / 0.35 | **✗**: rolled to 69°, full stall, spun to the reverse heading |
| 255 | 12.2° / 0.07 | ✓ |
| 270 | 9.8° / 0.05 | ✓ |
| ±15° checks: 75, 105, 285 | 6.6–9.4° / ≤ 0.06 | ✓ all |

240° looked best in calm air (self-locking: holding torque ≈ 0 at the four-bar top dead point), but it **sits on a cliff**: 225° crashes, and 240° itself fails the glide turn. Self-locking alone is the wrong criterion; the park angle needs survivable neighbours for detent tolerance.

## 5. Decision (revision 5)

**Park at 270°** (wings +28.6°, dihedral), robust across ±15° (255–285°: L/D 5.1–6.8, all gust and turn cases pass).

The 90° band glides about 10% better (L/D 5.7–7.4) but was rejected because:
* it needs twice the holding torque (up to 0.22 vs 0.11 N·m)
* it parks the wings in 19.5° of anhedral, giving less lateral stability and wingtips that strike the ground first in a belly landing

**Detent sizing:**
* Worst holding torque in the 255–285° band is 0.108 N·m. Capture must also overcome the reflected motor and gear drag, 0.076 N·m (no-load current torque × 36:1), so the **capacity is 0.2 N·m**.
* An always-engaged roller would store about 0.07 J per pass. At 25% hysteresis and 6 Hz that is about 0.1 W mechanical (≈ 0.3 W electrical, +1.4%) plus ±0.2 N·m of torque ripple. It is therefore **centrifugally disengaged**: a flyweight lifts the roller above about 1 Hz crank speed, so there is no cost in powered flight, and it re-engages on spin-down.
* Mass +6 g (336 g total). Endurance with margin: **17.4 min at 12 m/s** (rev 4: 17.5 min), range 12.5 km.

**Result:** a motor failure now ends in a controlled glide (L/D ≈ 6, 10.4 m/s, about 1.7 m/s sink) with heading control through the roll servo. The undetented design had roughly a 50% chance of losing the aircraft.

## 6. Open items

* The capture dynamics are idealised; real spin-down depends on gear friction, cogging and aero torque. Bench-test the capture from 6 Hz (new test card MECH-07).
* Centrifugal latch reliability and the threshold speed.
* Landing with the wings parked at +28.6° dihedral (flare authority).
* The detent cannot help if the crank or linkage itself jams (joint failure remains unrecoverable).
