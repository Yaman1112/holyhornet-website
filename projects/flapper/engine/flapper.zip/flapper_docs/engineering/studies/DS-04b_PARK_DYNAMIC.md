# DS-04b: wing park in the dynamic drive model (revision 8)

**Status:** design study in simulation. Nothing built or measured. All numbers are **SIMULATED** with the
motor + gearbox + crank model (`kinematics.drive = "motor_crank"`) unless stated.
Tool: `backend/tools/study_ds04b_park_dynamic.py` → `data/studies/ds04b_park_dynamic.json`.

## 1. How it was found

During component selection (rev 8) the motor-failure case was rerun on the dynamic drive model. The aircraft
"completed" but lost 117 m in 25 s (glide L/D 2.5). The same happens on revision 7. The DS-04 detent had only
been verified on the prescribed drive, where capture at the park angle is **kinematic** (an ideal spring-damper
with unlimited torque), so it could not fail there.

## 2. What actually happens after drive loss

* The crank stops within about 0.1 s, less than one revolution. It never spins down through a chosen park
  angle, so no detent, flyweight or ratchet at 270° can catch it (a one-tooth ratchet pawl was modelled and never
  seated).
* The hinge springs (DS-06, k 1.0 N·m/rad, neutral −5°) then pull the wings to their neutral: the crank settles
  at ≈ 357° with the stroke at −5° and the **driven twist frozen at −22° (nose-down)**. Lift is negative there, so
  aerodynamics holds the state too. Glide L/D 2.5, sink 4.75 m/s.
* The holding torque the aero and springs put on a stopped crank is 0.2 N·m at 270° and up to 0.5 N·m past it.
  The DS-04 cam detent (0.35 N·m peak) parks 14–53° off target. Its centrifugal disengage at 1 Hz is not
  physically possible: a flyweight on the crank shaft at 1 Hz produces millinewtons.

## 3. Hinge-spring tuning alone (part A)

| k [N·m/rad], neutral | Rest crank | Glide L/D | 12 m/s power | 14 m/s |
|---|---|---|---|---|
| 1.0, −5° (rev 7/8) | 357° | 2.5 | 18.23 W | 23.8 W, 5.3 A |
| 1.0, +5° | 336° | 2.8 | 18.50 W | 24.6 W |
| 1.0, +15° | 300° | 4.2 | 18.97 W | 25.5 W, 9.6 A |
| 1.0, +25° | 243° | 6.7 | 21.09 W | 10.4 A (over the motor limit) |
| 0.5, +15° | 244° | 6.8 | 19.06 W | 25.8 W, 9.8 A |
| none | 241° | 6.6 | 18.55 W | **fails**: only 12.2 m/s |

Tuning trades top speed or current margin for the glide. Without springs the wings park well (lift carries them
up to the top-of-stroke dead centre, where the four-bar reacts the load), but 14 m/s is lost.

## 4. Release on failure (part B)

Idea: keep the springs and the driven twist for powered flight, and **release** them when the flight controller
declares motor failure. Release forced at failure time + delay, 3 failure phases × 2 speeds:

| Released | Delay 0.1–0.6 s | Rest crank | Glide L/D |
|---|---|---|---|
| nothing | — | 355° / 27° | 2.5 |
| springs only | 0.1–0.6 s | 241° in 3 of 18 cases (only with 0.1 s delay), else 355° / 27° | 6.6 or 2.5 |
| twist only | any | 322° / 325° / 160° | 5.6–6.6 |
| **twist + springs** | **any** | **237° in every case** | **6.0 (12 m/s), 5.45 (14 m/s)** |

Releasing only the springs leaves the frozen nose-down twist, which keeps the bad state stable. Releasing both
gives one deterministic park, insensitive to the delay. That matters because the failure detector needs about
0.8 s (0.5 s average plus 0.3 s persistence, so that in-stroke speed ripple cannot trip it).

## 5. Adopted design (rev 8)

**One EMAX ES9051 servo moves a release bar that trips two sears:**

1. The idler-eccentric end of both twist push rods is freed, so the torque tubes return to zero driven twist.
   The roll bellcrank still acts on the rods, so differential twist roll control remains in the glide.
2. The ground anchor of both hinge springs is freed.

Mass 5.6 g (servo 4.1 g listing, bar and sears 1.5 g estimate), replacing the 7 g detent. Release is
irreversible in flight. The FC commands it only after declaring motor failure, and the controller is already
in the glide mode by then. No flapping-time power cost.

Part C, real detector (SIMULATED):

| Case | Rest crank | Glide L/D | Glide speed | Altitude lost (25 s) |
|---|---|---|---|---|
| straight, 12 m/s | 237° | 6.04 | 10.1 m/s | 42 m |
| straight, 14 m/s | 237° | 5.45 | 11.2 m/s | 50 m |
| failure mid 90° turn | 237° | 6.04 | 10.2 m/s | 38 m, turn completed |
| 90° heading change in glide | 237° | 6.04 | 10.1 m/s | 45 m |
| turbulence σ 1 m/s | 237° | 5.77 | 10.2 m/s (min 8.7) | 53 m |

The prescribed drive now holds the crank at the same 237° (the idealisation matches the physics), with the
same L/D.

## 6. Limits and tests

* The twist and spring sears are concepts. Trigger force, release reliability, and whether the freed rod can
  snag are all unverified. Bench test MECH-07 is rewritten for the release.
* If the release fails to actuate, the outcome is the 2.5 L/D descent: controlled, but steep. Risk R-09 stays
  open at a reduced score until the hardware is tested.
* A gearbox **jam** (crank locked mid-stroke) is not covered by any crank-side park mechanism; the twist release
  still neutralises the twist.
* Tests: `test_release_parks_wings_in_dynamic_drive` (12 and 14 m/s, crank within 5° of 237°, L/D > 5) and
  `test_without_release_the_dynamic_park_is_poor` (guards against a kinematic park model hiding this again).
