# DS-02: driven-twist mechanism design (decision D-02)

Date 2026-11-14 · model us-bem-1.1 (unsteady, flexible) · trimmed level flight at 10 m/s · all results simulated.
Raw data: `data/studies/ds02_twist_shape.json` (`backend/tools/study_ds02_twist_shape.py`).

## 1. Question

Decision D-01 showed the aircraft only flies with a driven twist of ±30° at the tip, nose-down on the downstroke. D-01 assumed an ideal harmonic twist that grows *linearly* from root to tip. This study asks:

1. Which twist distribution can a simple mechanism produce?
2. What does turning the ideal into a real linkage cost?

## 2. Twist distribution: tip-driven vs root feathering

Driven twist shape: θ_d(r) = TA(t)·(w₀ + (1 − w₀) r/R). Here w₀ = 0 is tip-driven linear twist, and w₀ = 1 is uniform feathering of the whole wing about its spar, which a root pitch horn alone would give. 24 trims:

| w₀ | best TA / lead | f [Hz] | P_mech [W] | P_elec [W] | max stalled fraction |
|---|---|---|---|---|---|
| 0 (tip-driven) | 30° / −20° | 5.54 | **4.61** | **17.1** | 0.12 |
| 0.5 | 20° / −20° | 6.08 | 7.92 | 23.4 | 0.53 |
| 1 (root feathering) | 15° / −20° | 7.20 | 14.9 | 37.4 | 0.71 |

Root feathering is about 3× worse. The inboard wing has almost no plunge velocity, so pitching it as far as the tip drives it to negative lift and stall. A +10° lead was worse than −20° in every case. **The mechanism must produce twist that grows toward the tip.**

## 3. Concept selected: rotating leading-edge torque tube

* The leading-edge spar is a **torque tube** (6/5 mm, ±45° roll-wrapped CFRP; G ≈ 20 GPa *estimated*) carried by a **2-DOF root yoke**: flap about body x, pitch about the spar axis.
* The **tip rib is bonded** to the tube; inner battens pivot freely on it, so the membrane spreads the twist roughly linearly from root (0) to tip. The model's w₀ = 0 shape is an idealisation of this, to be confirmed by MECH-04.
* A **pitch horn** (15 mm, pointing aft) sits **on the flap axis**, so flapping does not move it at zero pitch (first-order flap-pitch decoupling). A ball-jointed **push rod** drives it from an **eccentric on a 1:1 idler shaft** geared to the crank and placed under the hinge.
* A **root torsion spring in series** sets the tip-twist compliance (series-elastic twist drive, see §5).

Rejected alternatives: root feathering (§2); a tip actuator such as a servo or cable (mass and power out at the tip, plus slow servo bandwidth at 5–6 Hz); and an eccentric on the main crank centreline. The last was the first synthesis attempt: the rod ran diagonally and the linkage reached a **0.06 transmission factor and 8° RMS tracking error**.

## 4. Linkage synthesis (`hhflapper/twistlinkage.py`)

The spatial loop closure |H(φ, p) − E(θ)| = L is solved for the tube pitch p at each crank angle, using the *actual* four-bar flap angle φ(θ). The eccentric radius, phase and rod length are fitted to the D-01 harmonic target by least squares.

| Quantity | Value |
|---|---|
| Horn / eccentric radius / rod length | 15.0 / 7.2 / 35.5 mm |
| Idler centre | under the hinge, 35 mm below the hinge plane |
| Tracking error vs target | **0.91° RMS, 1.75° max** |
| Tube pitch range | −31.3° … +30.0° |
| Minimum transmission factor | 0.72 (1 = ideal) |
| Residual flap→pitch coupling | ≤ 0.36 rad/rad (included exactly) |
| Peak rod force (cruise) | 8.9 N |
| Peak tube torque | 0.110 N·m |
| Tube wind-up / shear at peak | 2.0° / 5.0 MPa (an order of magnitude below CFRP shear strength) |
| Added mass | +12 g hardware (estimate) + 2 g per wing for the tube = **+16 g (302 → 318 g)** |

A geometry scan over idler height (−25 … −50 mm) and horn length (12–20 mm) gave 0.74–1.85° RMS. The selected point balances fit against rod length and packaging.

## 5. Twist compliance: why a series spring

The ideal-twist studies assumed a soft twist stiffness (0.5 N·m/rad), which produced about 12° of *passive* elastic twist in phase with the load. A rigid torque tube (GJ/R ≈ 3.1 N·m/rad) removes most of it:

| Variant (10 m/s) | f [Hz] | P_mech [W] | P_elec [W] | stall |
|---|---|---|---|---|
| Ideal harmonic twist, k = 0.5, 302 g (rev 1 baseline) | 5.54 | 4.61 | 17.05 | 0.12 |
| + linkage mass (318 g) | 5.55 | 4.63 | 17.71 | 0.16 |
| + rigid tube k = 3.1 | 5.53 | 6.05 | 21.44 | 0.29 |
| **real linkage + four-bar stroke, k = 3.1** | 5.69 | 6.86 | 22.62 | 0.59 |
| real linkage, k = 0.5, lead −35° | 5.46 | 6.17 | 20.03 | 0.52 |
| **real linkage, k = 1.0, lead −35° (selected)** | 5.37 | 6.92 | **21.69** | **0.29** |

**Decision D-02:** baseline revision 2 uses the real linkage (`twist_source = linkage`, four-bar stroke), lead −35° and a series-elastic tip stiffness of 1.0 N·m/rad. k = 0.5 would save about 8% electrical power, but puts half the wing post-stall during the cycle, where the model is least trustworthy.

Spring sizing (first estimate): k_total = 1.0 with the tube at 3.1 means a root spring of about 1.5 N·m/rad, deflecting about 4° at peak torque. That is roughly 2 coils of 1.5 mm music wire on a 6 mm mandrel, or a flexure. It must be measured (MECH-04).

## 6. Consequence

Making the twist real costs about **+27% electrical power at cruise** (17.1 → 21.7 W) against the idealised D-01 result. The endurance numbers in FEASIBILITY_RESULTS.md are regenerated for revision 2.

Open items:
* Membrane twist distribution with a torque tube (is it really linear?): test MECH-04.
* Root-yoke friction and the pitch-bearing life.
* Spring fatigue at about 20 000 cycles per hour.
* The four-bar stroke costs more than the sinusoid used in DS-01 (22.6 vs 21.4 W). Co-optimising the four-bar and twist linkage is the next design step.
