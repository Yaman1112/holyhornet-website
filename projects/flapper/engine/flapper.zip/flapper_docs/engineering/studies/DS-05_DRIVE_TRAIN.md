# DS-05: flapping motor, gear ratio and drive-train losses (baseline revision 6)

Date 2026-11-14 · revision 5 airframe · all results simulated. **The motor family uses generic scaling estimates anchored to the original 28 g assumption, not product data.**
Tools: `backend/tools/study_ds05_drive.py` (quasi-static sweep), `study_ds05b_dynamic_drive.py` (dynamic motor-crank simulation).
Data: `data/studies/ds05_drive.json`, `ds05b_dynamic_drive.json`.

## 1. Quasi-static sweep: motor size × gear ratio × stages

With winding resistance R = K_t²/K_m², the cycle-mean electrical power p = (τ_m + τ₀)²/K_m² + (τ_m + τ₀)·ω **does not depend on K_v**. K_v only has to fit the pack voltage, so it is chosen at the 2S voltage limit.

Swept: motor mass 16–48 g (K_m ∝ m^a with a = 0.8/1.0/1.2; τ₀ ∝ m; thermal resistance ∝ m^−0.6), gear ratio 6–100:1, with 1–3 stages (η = 0.866 per stage). The aircraft-mass penalty uses the measured elasticity of 0.75. Each candidate is evaluated on the trimmed crank-torque waveforms at 12 m/s (1 g and 1.15 g) and 14 m/s.

* **Consistency:** the drive model reproduces the trim's 21.54 W exactly.
* **The optimum is flat.** The best design is a 20 g motor at 50:1, giving 21.2 W (−1.6%, mostly from 8 g less mass, at the 60 K thermal limit). The current 28 g motor's best ratio is 38:1 at 21.53 W, against 21.54 W at 36:1. The result is insensitive to the scaling exponent. **Motor size and ratio are not the lever.**

## 2. Where the cruise power goes (12 m/s, 21.54 W)

| Item | W |
|---|---|
| Useful mean crank power | 8.45 |
| Back-driven crank work (torque negative 25% of the cycle, no regeneration) | 1.32 |
| Gearbox loss (η 0.75, conservative estimate) | **3.26** |
| Motor no-load drag (friction + iron) | **2.81** |
| Copper loss | 1.82 |
| ESC | 1.54 |
| Avionics | 2.35 |

Perfectly smoothed crank torque would give 18.7 W (−13%).

## 3. Feasibility error found: K_v 1800 is voltage-starved

At the voltage limit the required K_v is about 2500 rpm/V. The dynamic motor-crank simulation (new ESC crank-speed governor, PI on the measured crank frequency) confirms it. With K_v 1800 the throttle saturates **21% of the time at cruise** and **79% at a 14 m/s command**, where the aircraft only reaches 12.8 m/s. The quasi-static prescribed-frequency model could not show this, because it assumes the crank speed is always achieved.

## 4. Dynamic comparison (12 m/s, last 10 s of 20 s closed-loop flights, matched airspeed 11.9 m/s)

| Variant | Throttle saturation | Crank-speed ripple (p-p) | P_elec |
|---|---|---|---|
| a. K_v 1800 (rev 5) | 21% | 4.8 Hz | 18.5 W |
| b. same motor rewound, K_v 2500 | 0% | 4.9 Hz | 19.3 W |
| c. b + gearbox η 0.90 | 0% | 4.9 Hz | **16.3 W (−15%)** |
| d. b + motor-shaft flywheel (4× rotor inertia, +8 g) | 0% | **1.7 Hz** | 18.6 W (−4%) |

The dynamic model gives about 10% less power than the quasi-static estimate, because rotor inertia stores back-driven work. Reported baseline numbers stay on the conservative quasi-static model.

## 5. Decisions (revision 6)

* **Rewind the motor to K_v 2500** (R 0.130 Ω, i₀ 0.555 A by scaling; same size and mass). This is required for voltage headroom.
* **Fit a motor-shaft flywheel** (+8 g; 4× rotor inertia): −65% crank-speed ripple, −4% power, smoother loads for the IMU and structure.
* **Raise the wingbeat command limit from 7 to 8 Hz.** At 7 Hz it capped the 14 m/s case at 13.3 m/s; revision 6 reaches 13.9 m/s, unsaturated.
* **Keep 36:1** (the optimum is flat).
* **Gearbox efficiency target η ≥ 0.90** (two precision stages): the largest single lever (−15%). It is *not* banked in the baseline (still 0.75) until a gearbox is measured (test ACT-01).

Revision 6 at 12 m/s: 344 g; quasi-static 21.8 W (**17.2 min / 12.4 km**, conservative; the dynamic 18.8 W would imply ≈ 20 min); dynamic 18.8 W, no saturation; 1.15 g stall 0.45 (≤ 0.5, margin narrowing: watch mass growth).

## 6. Open items

* Measure gearbox efficiency and motor no-load current (ACT-01). These two estimates dominate the losses.
* Elastic energy storage (a spring tuned to wing resonance) could address the back-driven work and torque ripple more fundamentally than a flywheel. Not modelled yet.
* Regenerative ESC braking during back-driven phases: small (≤ 1.3 W available).
