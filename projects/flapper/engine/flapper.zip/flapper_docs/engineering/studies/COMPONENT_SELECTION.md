# Component selection (revision 8)

**Status:** design selection from published listings. Nothing has been bought, weighed, assembled or
measured. Every value below is labelled **listing** (manufacturer or retailer page, retrieved 2026-11-15),
**datasheet**, **estimate** (not published; our assumption) or **simulated**.

Tools: `backend/tools/component_requirements.py` (requirement envelope), `backend/tools/study_motor_candidates.py`
(quasi-static motor screen on 2S and 3S), `backend/tools/study_cs04_drive_pack.py` (dynamic pack and gear-ratio sweep).
Data: `data/studies/component_requirements.json`, `motor_candidates.json`, `cs04_drive_pack.json`.

## 1. Requirements from the simulation

Extracted by `component_requirements.py` from closed-loop simulations of revision 8 (cruise 12 m/s, 14 m/s,
90° turn, turbulence, gust). **SIMULATED.**

| Quantity | Simulated peak | Selected part | Margin |
|---|---|---|---|
| Body acceleration | 4.65 g (turbulence) | ICM-42688-P (±16 g) | 3.4× |
| Body rate | 110 °/s (gust) | ICM-42688-P (±2000 °/s) | 18× |
| Battery current | 1.45 A cruise mean; 5.3 A at 14 m/s; 9.35 A transient in turbulence (rev 8) → 7.25 A (rev 9, CS-05) | Tattu 75C (30C derated = 19.5 A) | 2.1× |
| Motor current | pulsed, peak ≈ 2.4 × RMS; RMS 2–4 A | Scorpion 10 A continuous | rev 9: at the 10 A limit ≤ 3% of the time even at σ 1.5 m/s (CS-05) |
| Motor speed | 18 200 rpm | Kv 1585 × 12.6 V ≈ 20 000 rpm no-load | 1.1× |
| Winding temperature rise | 2.6 K over a 25 s run (thermal model estimated) | — | not a design driver over short runs; bench-measure |
| Twist push-rod torque | 0.30 N·m | carried by the linkage (CS-03) | — |
| Elevator deflection / hinge moment | 18° / ≈ 0.005 N·m | ES9051, 0.078 N·m stall | ≈ 15× |
| Rudder deflection | 9.6° | ES9051 | — |

## 2. Flapping motor and pack

Rule from the brief: *do not choose a motor solely on its advertised maximum power.* Each motor was
evaluated on the simulated crank-torque waveforms with its published Kv, Rm and Io, and the gear ratio was
re-matched for each motor and pack.

### 2.1 Quasi-static screen

Candidates: Scorpion SII-2205-1585KV V2, Hacker A10-12S, Scorpion M-2205-2350KV (data in
`study_motor_candidates.py`). The SII-2205 has the best motor constant (Km) and the lowest no-load torque,
so it wins on cruise power despite being the heaviest (35.4 g). The M-2205 (Rm 0.775 Ω) and A10-12S
(Io 1.0 A) lose on copper and no-load losses respectively.

The screen originally used a 15 A current cap. The Scorpion listing gives **10 A max continuous**, and the
screen cannot see within-stroke current surges, so the decision was moved to a dynamic simulation.

### 2.2 Dynamic sweep (decisive)

Motor + gearbox + crank model with the ESC PI crank-speed governor and the 10 A limit
(`study_cs04_drive_pack.py`). **SIMULATED.**

| Pack, ratio | 12 m/s cruise | 14 m/s | Climbing mission (110 s) |
|---|---|---|---|
| 2S 1000 mAh, 21:1 | 19.70 W, 8.3 A peak | **fails**: 8.95 m/s, throttle saturated 32%, current-limited | current-limited (10.5 A demanded); an earlier run on the rev-7 park ended in ground impact |
| 3S 650 mAh, 26:1 | 18.42 W | 24.91 W, 8.1 A | completed; current-limited |
| **3S 650 mAh, 30:1** | **18.48 W, 3.7 A** | **24.04 W, 5.3 A** | **completed, 18.78 W, peak 5.4 A, no saturation** |
| 3S 650 mAh, 34:1 | 18.80 W | 24.25 W | completed, 19.09 W |

Why 2S fails: with Kv 1585 the 2S voltage caps the gear ratio (the crank must still reach ~7 Hz at
14 m/s), and a low ratio raises motor torque and current. Between the voltage ceiling and the 10 A current
ceiling there is no room on 2S. On 3S the ratio can rise to 30:1, which halves the current.

**Selected: Scorpion SII-2205-1585KV V2 on 3S with a 30:1 gearbox (rev 8), raised to 34:1 in rev 9 for current margin in turbulence ([CS-05](CS-05_TURBULENCE_CURRENT_MARGIN.md)).** The listing gives "Max Lipo Cell 3s",
10 A and 110 W max continuous: a full 3S pack (12.6 V) is **at** the motor's voltage rating, with no further
margin. The simulated peak of 5.4 A is 54% of the current rating.

### 2.3 Safety bug found during selection

With the Scorpion at 19:1 on 2S at 14 m/s, the crank speed ripples between 4.8 and 10 Hz within each
stroke. The failure monitor compared the instantaneous crank speed with 30% of a wrongly computed command
(`throttle × 6`), tripped "motor failed", commanded a glide, and the aircraft crashed. Fixed in
`simulator._health`: 0.5 s averaged crank speed against the real wingbeat command, held for 0.3 s.
Regression test: `test_no_false_motor_failure_detection_under_crank_speed_ripple`.

## 3. Bill of materials (rev 8)

| Function | Part | Mass [g] | Basis | Key data | Source |
|---|---|---|---|---|---|
| Flapping motor | Scorpion SII-2205-1585KV V2 | 35.4 | listing | Kv 1585, Rm 0.182 Ω, Io 0.47 A @10 V, 10 A / 110 W max cont., max 3S | [gravesrc.com](https://www.gravesrc.com/scorpion-2205-1585-v2-brushless-outrunner-motor.html), [scorpionsystem.com](https://www.scorpionsystem.com/catalog/aeroplane/motors_1/s-22_v2/SII-2205-1585KV) |
| Gearbox + crank | custom 2-stage 34:1 (rev 9; 30:1 in rev 8) | 32.0 | estimate | efficiency 0.75 assumed | — (to be designed and measured) |
| ESC | Holybro Tekko32 F4 45A (AM32) | 5.8 | listing | 2–6S, DShot, telemetry | [readymaderc.com](https://www.readymaderc.com/products/details/87186-holybro-tekko32-f4-45a-esc-am32) |
| Battery | Tattu 650 mAh 3S1P 75C, XT30 | 59.0 | listing | 11.1 V nominal; design limit derated to 30C | [getfpv.com](https://www.getfpv.com/tattu-650mah-3s1p-75c-11-1v-lipo-battery-pack-with-xt30-plug.html); alternative [Overlander 3S 650 50C, 57 g](https://overlander.co.uk/650mah-11-1v-3s-50c-lipo-battery.html) |
| Flight controller | Matek H743-WLITE | 22.0 | listing | ICM-42688-P, DPS310, 6.8–30 V input, 2–6S | [mateksys.com](https://www.mateksys.com/?p=10289) |
| GNSS + compass | Matek M10Q-5883 | 8.0 | listing (7.5–8 g) | u-blox M10 | [pyrodrone.com](https://pyrodrone.com/products/matek-m10q-5883-gps-module-gps-compass) |
| RC + telemetry | RadioMaster RP1 V2 (ExpressLRS) | 2.2 | listing | CRSF; no native MAVLink confirmed | [radiomasterrc.com](https://radiomasterrc.com/collections/receivers/products/rp1-expresslrs-2-4ghz-nano-receiver) |
| Airspeed | Matek ASPD-4525 + pitot | 5.5 | listing (3.5 g) + estimate (2 g) | MS4525DO, I²C | [rotorvillage.ca](https://rotorvillage.ca/matek-digital-airspeed-sensor-aspd-4525) |
| Tail servos | 2 × EMAX ES9051 | 8.2 | listing | 4.1 g, 0.8 kgf·cm, 0.09 s/60° @4.8 V | [servodatabase.com](https://servodatabase.com/servo/emax/es9051) |
| Roll (twist) servo | EMAX ES9051 + bellcrank | 7.1 | listing + estimate | CS-03 load < 2% of stall | as above |
| Wing-angle encoders | 2 × AS5048A + magnets | 2.0 | datasheet + estimate | 14-bit, SPI/PWM | [AS5048A datasheet](https://cdn.sparkfun.com/assets/e/d/e/1/d/AS5048_DS000298_4-00.pdf) |
| Wing-park release | EMAX ES9051 + release bar, two sears | 5.6 | listing + estimate | trips twist rods and hinge-spring anchors on failure (DS-04b) | as above |
| Structure, wings, tail, linkages, springs, wiring | — | 140.5 | estimate | — | design estimates (DS-02/06, CS-02/03) |
| **Total** | | **333.3** | | CG x +3.4 mm | `massprops.py` |

Mass grew from 302 g (rev 1 estimate) to 333.3 g (+10%), mostly the heavier real motor, flight controller and
the 3S pack; this is within the 15% growth allowance of R-03.

## 4. Electrical compatibility

| Check | Result |
|---|---|
| Pack voltage vs motor | 3S (9.9–12.6 V) = listing maximum "3s": allowed, no margin |
| Pack vs ESC | 2–6S: ok |
| Pack vs flight controller input | 6.8–30 V: ok |
| Peak current vs motor | 5.4 A simulated vs 10 A continuous: ok |
| Peak current vs pack | 5.4 A ≈ 8C vs 30C derated design limit: ok |
| Servo supply | **open**: confirm the FC BEC rail voltage against the ES9051 rating |
| Encoder interface | **open**: confirm a free SPI bus or timer-capture inputs on the H743-WLITE |
| Pin assignment | **not defined**: to be taken from the Matek documentation only, never assumed |

## 5. Limits and what must be measured

- The motor's thermal resistance (6.9 K/W) and heat capacity (15 J/K) are **not published**; they are
  mass-scaled estimates. Measure winding temperature on the bench (ACT-01).
- Gearbox efficiency (0.75) is assumed and is the largest single loss (DS-05).
- Listing masses vary between retailers (M10Q: 7.5 vs 8 g); weigh every part on receipt (R-03).
- One retailer lists the ES9051 as discontinued: identify a second-source 4–5 g servo.
- The RP1 V2 gives CRSF telemetry only; a MAVLink ground-station link needs a different radio or a mirror.

## 6. Wing-park fail-safe found broken, and fixed (DS-04b)

Rerunning motor failure on the dynamic drive showed the rev 5–7 detent never worked outside the kinematic
prescribed-drive model (glide L/D 2.5, the same on rev 7). It was replaced by a servo-tripped release of the twist
push rods and hinge-spring anchors (park at 237°, L/D 5.45–6.0). Full study: [DS-04b](DS-04b_PARK_DYNAMIC.md).

## 7. Verification of revision 8 (SIMULATED)

Store revision HF1-BASELINE rev 8. Full suite 56/56 (`data/validation/latest.json`).

| Check | Prescribed drive | Motor-crank drive |
|---|---|---|
| Trim 12 m/s (1 g) | 5.87 Hz, α 0.9°, stall 0.22, 19.9 W (quasi-static) | — |
| Trim 12 m/s at 1.15 g | converged, stall 0.43 (≤ 0.5 rule) | — |
| Trim 14 m/s | converged, stall 0.14 | — |
| Closed-loop cruise 12 m/s | 21.8 W, alt error 0.3 m | **18.5 W**, 3.7 A peak, no saturation |
| 14 m/s | 13.93 m/s, 28.9 W | 13.92 m/s, **24.0 W**, 5.3 A, no saturation |
| 90° turn | completed, 90° | completed, 90° |
| Climbing waypoint mission (110 s) | completed, loiter | completed, 18.8 W, 5.4 A |
| Motor failure at 120 m | park 237°, glide, 40 m lost in 25 s | park 237°, glide, 42 m lost in 25 s |
| Endurance / range at 12 m/s (feasibility report) | 18.3 min / 13.2 km, quasi-static, conservative | — |

The prescribed drive's power is the quasi-static estimate, about 15% above the dynamic model. The mission shows a
transient stall-blend warning in the initial climb (60–70% for one wingbeat, < 1% of the flight); revision 7 shows
the same, so it is not caused by this change.
