# DS-06: elastic energy storage at the wing hinges (baseline revision 7)

Date 2026-11-14 · revision 6 airframe · all results simulated. Spring energy density (CFRP leaf, 300 J/kg) and hysteresis (3% of peak energy per stroke) are **estimates**.
Tools: `backend/tools/study_ds06_hinge_spring.py`. Data: `data/studies/ds06_hinge_spring.json`, `ds06_hinge_spring_ext.json`.

## 1. Idea

The drive reverses each wing twice per beat. A spring in parallel with the drive at each hinge (actuator torque = required + k(φ − φ_n)) can:
1. cancel the wing's inertial torque near resonance, where k ≈ I·Ω² ≈ 1.33 N·m/rad per wing
2. with a preload (neutral angle φ_n), balance the steady upward lift moment

It is internal to the airframe, so aerodynamics and trim are unchanged.

## 2. Quasi-static sweep (trimmed cycles, spring mass included)

| k [N·m/rad] | neutral vs mean | 12 m/s | 1.15 g | 14 m/s | Back-driven work | Spring mass (both wings) |
|---|---|---|---|---|---|---|
| 0 | — | 21.76 W | 23.54 W | 28.60 W | 1.35 W | 0 |
| **1.0** | **−10°** | **20.06 W** | 21.53 W | 26.89 W | 0.33 W | 3.5 g |
| 1.25 | −10° | 20.05 W | 21.45 W | 26.88 W | 0.26 W | 3.8 g |
| 1.0 | 0° | 20.47 W | 22.08 W | 27.13 W | 0.47 W | 2.8 g |
| 1.5 | +10° | 23.21 W | 25.20 W | 28.63 W | 1.44 W | 4.2 g |
| 3.0 | 0° | 25.16 W | 26.39 W | 30.35 W | 2.38 W | 4.4 g |

The optimum is a broad basin (k 0.75–1.25, neutral −10° to −15°: 20.05–20.2 W), bracketing the inertial resonance. The **preload direction matters as much as the stiffness**: a preload in the wrong direction (+10°) is worse at every stiffness. The quasi-static estimate is −8%.

## 3. Dynamic verification changed the decision

The quasi-static model treats back-driven crank work as lost. In the dynamic motor-crank simulation, rotor (and flywheel) inertia stores that energy. Results at matched airspeed:

| Energy buffer | Mass | 12 m/s | 14 m/s | Crank-speed ripple |
|---|---|---|---|---|
| None | 336.0 g | 19.32 W | **23.15 W** | 4.9 Hz |
| Flywheel (rev 6) | 344.0 g | 18.76 W | 24.63 W | 1.75 Hz |
| **Hinge spring only (rev 7)** | **339.5 g** | **18.32 W** | 23.79 W | 1.86 Hz |
| Spring + flywheel | 347.5 g | 19.49 W | 25.58 W | 0.73 Hz |

* The flywheel and the spring do **the same job** (buffering the stroke energy, kinetically or elastically). Stacking them only adds mass and hysteresis: +3.9%.
* **Spring instead of flywheel** is best at cruise (−2.3% vs revision 6, −5.2% vs no buffer), 4.5 g lighter, with similar ripple reduction.
* At 14 m/s, no buffer at all is best: crank-speed ripple alters stroke timing favourably at high speed. This aero-drive coupling is worth a later study.
* An analysis slip was caught here: the first "no flywheel" runs had zeroed the 28 g *motor* (wrong component index) instead of the flywheel. They were spotted from the mass column and re-run.

## 4. Interaction with the wing-park detent

When parked, the spring pulls the wings toward neutral, raising the crank holding torque. In the parked glide across 255–285° it reaches 0.114 / 0.175 / 0.224 N·m (was ≤ 0.108). With 0.076 N·m of motor/gear drag the worst case is about 0.30 N·m, so the **detent capacity is raised from 0.2 to 0.35 N·m** (+1 g). Glide performance is unchanged (L/D 5.1–6.8).

## 5. Decision (revision 7)

* CFRP leaf hinge springs: k = 1.0 N·m/rad per wing, neutral −5° (10° below the mean stroke); about 1.75 g each including mount.
* **Motor flywheel removed** (it was added in revision 6).
* Detent capacity 0.35 N·m.
* Mass 340.5 g. Dynamic cruise 18.3 W. Conservative quasi-static endurance with margin: **18.9 min / 13.6 km at 12 m/s** (rev 6: 17.2 min). The quasi-static model credits the springs more (−9%) than the dynamic simulation (−2.3%), because it treats back-driven work as lost.

## 6. Caveats

* The benefit (2–3% dynamic, 8% quasi-static) is within the uncertainty of the hysteresis and energy-density estimates. Both models agree on the direction, but the magnitude needs a bench measurement: hinge torque with and without springs on the restrained mechanism (MECH-05).
* Spring fatigue: about 21 000 cycles per hour at about 0.33 J peak per wing. Choose a fatigue-rated layup, and test (MECH-06).
* Next: look at the high-speed ripple benefit; a stiffness that can be adjusted in flight.
