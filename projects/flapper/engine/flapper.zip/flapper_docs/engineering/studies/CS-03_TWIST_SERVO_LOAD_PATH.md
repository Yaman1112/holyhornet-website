# CS-03: load path of the differential-twist (roll) servo

Date 2026-11-14 · revision 5 at 12 m/s · closed-loop 6-DOF · all results simulated.
Tool: `backend/tools/study_cs03_twist_servo_load.py`. Data: `data/studies/cs03_twist_servo_load.json`.

## 1. Question

The twist push rods carry forces that reverse at every wingbeat (~6.2 Hz). CS-02 left open whether the roll servo, which trims both rods, would be worn out by holding them.

## 2. Method

* Rod force F = τ_twist / (dℓ/dp). The twist-drive torque per wing is recorded in the simulation; the rod-length sensitivity dℓ/dp (−12.5 … −14.7 mm/rad) comes from the solved spatial linkage at each crank angle.
* Servo arm r = 3.7 mm: ±10° of twist bias needs ±2.4 mm of rod-length change at ±40° servo throw.
* Scenarios: cruise, turbulence (σ 0.8 m/s), 90° turn, lateral 3 m/s gust.
* Micro-servo reference (9 g class, estimate): stall about 0.15 N·m; continuous duty about 30% of stall.

## 3. Loads

| Scenario | Rod force peak / 6 Hz amplitude | Inline servo per rod: peak / RMS | **Differential bellcrank servo: peak / RMS** | Bellcrank pivot load |
|---|---|---|---|---|
| Cruise | 11.5 N / 3.2 N | 0.043 / 0.022 N·m | **0.000 / 0.000 N·m** | 23.0 N |
| Turbulence | 12.6 N / 0.9 N | 0.046 / 0.022 N·m | **0.0024 / 0.0005 N·m** | 24.9 N |
| 90° turn | 11.7 N / 1.8 N | 0.043 / 0.022 N·m | **0.0013 / 0.0003 N·m** | 23.4 N |
| Lateral gust | 11.6 N / 2.2 N | 0.043 / 0.022 N·m | **0.0027 / 0.0003 N·m** | 23.1 N |

* **Inline servos** (one in each rod) would carry about 30% of stall torque at peak, reversing about 22 000 times an hour: a wear and gear-backlash problem, and two servos.
* **Differential bellcrank:** the two rods load opposite arms, so the servo sees only r·(F_L − F_R). Both wings are mirror images driven at the same crank angle, so the symmetric flapping loads **cancel**. The servo carries under 2% of stall (only the antisymmetric part from roll commands and gusts), with a negligible 6 Hz component (0.00003 N·m). The bellcrank **pivot** reacts the sum, 23–25 N peak, which sets its bearing.
* **Sensitivity to rigging asymmetry:** a 10% left/right load mismatch (tolerances, unequal rod lengths) leaves about 0.1 × r × F ≈ 0.004 N·m (≈ 3% of stall). Still acceptable.

## 4. Slew-rate sensitivity (irreversible lead-screw option)

| Servo slew | 90° turn t90 | Gust roll RMS | Turbulence roll RMS |
|---|---|---|---|
| 600°/s (micro servo) | 5.84 s | 0.89° | 1.30° |
| 200°/s | 5.84 s | 0.89° | 1.30° |
| 100°/s | 5.84 s | 0.89° | 1.30° |
| 50°/s | 5.85 s | 0.88° | 1.30° |

The control law uses at most 6.6° of bias and moves it slowly, so roll handling is insensitive to slew rate down to 50°/s. An irreversible lead-screw drive (fail-fixed, no back-driving) therefore costs **no handling**, only mass and complexity.

## 5. Decision

**Differential bellcrank with a standard micro servo** (`actuators.roll_servo_arrangement = differential_bellcrank`), as already budgeted (+12 g). Design notes:
* Size the bellcrank pivot bearing for 25 N (plus margin for asymmetric rigging).
* Equal left/right rod geometry is what keeps the servo unloaded. Specify a rigging tolerance and check it on the bench (ACT-02).
* Keep the **lead-screw drive as a fail-fixed upgrade**: if a servo or its power is lost, a back-drivable bellcrank can drift under asymmetric loads, which the bench test must quantify.

A regression test (`test_symmetric_twist_rod_loads_cancel_in_differential_bellcrank`) checks that left and right drive torques are equal in symmetric flight, and that a twist bias breaks the symmetry.
