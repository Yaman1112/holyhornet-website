# Aerodynamic and structural model (us-bem-1.1, rom-1.0)

## What is modelled

**Blade-element strips.** Each wing has 10 strips (configurable 3–40), clustered toward the tip. Each strip carries:

1. **Local relative flow** from body translation, body rotation (ω × r), stroke motion (rotation about the hinge), bending velocity and wind.
2. **Pitch-rate effect**: the normal flow is evaluated at the ¾-chord point, so the twist rate adds θ̇·c/2 (the quasi-steady Theodorsen pitch-rate term).
3. **Section coefficients**: an attached thin-wing model blended into flat-plate post-stall coefficients (sigmoid blend at α_stall, default 14°):
   * Attached: C_L = a₃D(α − α₀), C_D = c_d0 + C_L²/(π e AR), with a₃D from Helmbold for the mirrored wing pair.
   * Post-stall: C_L = 2 sin α cos α, C_D = c_d0 + 2 sin²α.
   * α₀ = −2·camber, C_m,c/4 = −π·camber.
4. **Added mass**: a normal force −ρπc²/4·dr·a_n from the stroke acceleration. The bending acceleration's added mass is moved into the modal inertia.
5. **Unsteady circulatory lift (default, `aerodynamics.unsteady`)**: every strip carries two lag states implementing the Wagner indicial function in the R.T. Jones approximation φ(s) = 1 − 0.165e^(−0.0455s) − 0.335e^(−0.3s), with s = 2Vt/c:
   * ż_i = α_in − b_i (2V/c) z_i
   * α_eff = α + (1 − s_stall)·[−(A₁+A₂)α_in + A₁b₁(2V/c)z₁ + A₂b₂(2V/c)z₂], where α_in = α − α₀ (clipped to ±1 rad)
   * The circulatory force acts normal to the *effective* inflow (leading-edge-suction argument). The lag is faded out in the post-stall blend.
   * Setting `unsteady = False` gives the previous quasi-steady model (qs-bem-1.0) for comparison.
6. **Driven twist**: θ = θ₀(r) + (θ_driven(t) + ψ_elastic(t))·r/R, with θ_driven = TA cos(θ_stroke + lead).

**Structure (reduced-order, per wing).**

* Bending mode with w = β r²/R. Stiffness k = 4EI/R from the spar EI. Modal mass is Σm(r²/R)² plus added mass.
* Torsion mode with θ_el = ψ r/R about the elastic axis (default 8% chord, near the leading-edge spar). It is driven by the aerodynamic moment about the elastic axis, the camber moment and the chordwise mass-offset inertia.
* Viscous modal damping ζ.
* Default modal frequencies: bending ≈ 19 Hz and torsion ≈ 32 Hz, about 3–6× the wingbeat.

**Rigid-body coupling.** Wing aerodynamic forces and moments, and the first-order inertial reaction of the moving wing mass on the fuselage (−Σ m a_rel), act on a single rigid body with constant inertia.

**Tail.** Horizontal and vertical surfaces are single elements using the same coefficient model. Downwash at the tail is ε = (2a/πAR)·α_body. Elevator and rudder add a·τ·δ in the attached regime.

## Assumptions and limitations (read before using results)

| # | Limitation | Consequence |
|---|---|---|
| A1 | Wake memory is 2-D linear (Wagner) per strip: no 3-D wake, no stroke-to-stroke wake capture, no tip-vortex interaction | Resolved to first order in us-bem-1.1 (thrust lag verified against Theodorsen–Garrick). 3-D wake effects remain unquantified; a vortex-lattice comparison is the next check. |
| A2 | No leading-edge-vortex lift enhancement or dynamic-stall delay | Post-stall loads are uncertain. The model is conservative on lift where it stalls, and the stalled fraction is reported. |
| A3 | Strip theory with average 3-D corrections (Helmbold slope, Oswald factor); no spanwise flow, no tip-vortex model | Spanwise load distribution is approximate. |
| A4 | Membrane camber is fixed in sign | Upstroke loads are not well represented for membranes that invert camber. |
| A5 | Two structural modes per wing; linear stiffness | Large deflections and membrane wrinkling are not represented. |
| A6 | Constant rigid-body inertia; wing inertial reaction is first-order (relative acceleration only) | Body oscillation amplitude is approximate. |
| A7 | No wing-wing or wing-tail wake interaction beyond the mean downwash | Tail effectiveness during the cycle is approximate. |
| A8 | Captive and trim analyses freeze the body over a cycle (averaging) | Trim differs slightly from free flight. In free flight the aircraft settled at 5.5 Hz against a 5.12 Hz averaged trim. |

**Validity range** (where warnings fire in the simulator): k ≤ 0.35, stalled fraction ≤ 0.6, airspeed ≥ 0.8 × trim speed, attitude within ±80° roll / ±60° pitch.

## Verification (automated, `tests/test_physics.py`)

* Wagner impulsive start: lift begins at 50% of steady (Jones) and reaches φ(40 semichords) within 2%.
* **Theodorsen–Garrick plunge check**: the unsteady/quasi-steady thrust ratio for small-amplitude plunge equals |C(k)|² within 0.04 at k = 0.09 and 0.28. Across k = 0.05–0.38 the model gives 0.840/0.725/0.598/0.504/0.438 against Garrick's 0.852/0.734/0.579/0.487/0.429. The power ratio tracks F(k), as Garrick predicts.
* Non-flapping glide lift within 3% of ½ρV²S·a₃D·α; drag within 5% of c_d0 + induced.
* Symmetric flapping gives zero mean side force, roll and yaw (to 1e−8).
* Small-amplitude flapping gives positive thrust scaling with (A f)² (quasi-steady plunge theory).
* Rigid-wing energy balance: cycle-mean hinge power equals power delivered to the air within 1%.
* Gravity-only acceleration in vacuum; bending-mode free vibration at √(k/J)·√(1−ζ²) within 5%.

## Planned extensions

1. ~~Unsteady lift via Wagner indicial response~~ (done, us-bem-1.1).
2. Dynamic-stall delay (Beddoes-Leishman-lite).
3. Comparison against an unsteady vortex-lattice or CFD case for the cruise cycle.
4. Measured wing-twist and thrust data from a restrained-mechanism balance test (test card MECH-05).
