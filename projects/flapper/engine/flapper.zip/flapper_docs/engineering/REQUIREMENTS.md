# System requirements (v0.1)

Verification methods: **A** analysis, **S** simulation, **T** automated test, **I** inspection, **H** hardware test.
Status reflects release 0.1.0. "Met (sim)" means met in simulation only.

## Platform

| ID | Requirement | Target (configurable) | Method | Status |
|---|---|---|---|---|
| PLT-01 | Bird-inspired two-wing flapping aircraft; flapping is the primary propulsion | yes | I | Met (model) |
| PLT-02 | Wingspan | 600–1000 mm (baseline 900) | I | Met (config) |
| PLT-03 | Fuselage length | 350–600 mm (baseline 480) | I | Met (config) |
| PLT-04 | All-up mass traceable to an itemised budget with stated basis | every item has a basis | I, T | Met (estimates) |
| PLT-05 | Sustained level flight at a trimmed speed | trim exists | S | Met (sim): 10–14 m/s (rev 2, real twist linkage) |
| PLT-06 | Endurance | ≥ 10 min with 20% reserve | A, S | Met (sim est. 17.7 min at 12 m/s with manoeuvre margin, rev 3); unvalidated |
| PLT-07 | Hand-launchable minimum speed | ≤ 7 m/s | S | **Not met**: 10 m/s (risk R-06) |
| PLT-08 | Glide fail-safe after loss of flapping | controlled descent | S, T | Met (sim, rev 8, DS-04b) in the **dynamic** drive model: twist + hinge-spring release, park at 237°, L/D 5.45–6.0, glide turns and turbulence σ 1 m/s. (Rev 5–7 claim withdrawn: it held only with the kinematic park model) |
| PLT-09 | Survive turbulence without altitude loss to the ground | σ 1.0 m/s: < 10 m altitude loss; σ 1.5 m/s: no ground contact over 120 s | S, T | Met (sim, rev 9, CS-05): σ 1.0 loses ≤ 6 m, σ 1.5 bottoms at 20–27 m from 40 m (rev 8 hit the ground at 73 s). Two seeds, simple turbulence model |

## Aerodynamics and mechanism

| ID | Requirement | Method | Status |
|---|---|---|---|
| AER-01 | Time-varying aerodynamic model of each wing (no fixed-wing assumption) | T | Met |
| AER-02 | Independent left/right wing kinematics and geometry | T | Met |
| AER-03 | Flexible-wing model (bending + twist) shown in the digital twin | T, I | Met |
| AER-04 | Assumptions, limitations and validity range documented and enforced by warnings | I | Met (AERO_MODEL.md, simulator monitor) |
| MEC-01 | Rotary → flapping transmission with interference, transmission-angle and travel checks | T | Met (four-bar) |
| MEC-02 | Minimum transmission angle ≥ 40° | A | Met: 57° |
| MEC-03 | Left/right synchronisation quantified | A | Met: 0° (dual), 52° top-of-stroke lag (single pin) |
| MEC-04 | Motor/gear sized from simulated loads, not advertised power | A, S | Met (design, rev 8): Scorpion SII-2205-1585KV V2 selected from published Kv/Rm/Io, 3S, 30:1 (rev 8) → 34:1 (rev 9, CS-05), verified in the dynamic motor-crank sim with its 10 A limit (cruise, 14 m/s, climbing mission; peak 5.4 A). See COMPONENT_SELECTION.md |
| MEC-07 | Gearbox efficiency | A | Target η ≥ 0.90 (DS-05: −15% power); baseline still assumes 0.75 |
| MEC-05 | Parametric CAD (STEP/STL) | I | **Open** (Phase 4) |
| MEC-06 | Driven twist mechanism (from D-01) | A, T | Met (design): torque tube + push rod, 0.91° RMS vs target, transmission ≥ 0.72 (DS-02). Hardware open |

## Flight dynamics, control, autonomy

| ID | Requirement | Method | Status |
|---|---|---|---|
| FD-01 | Nonlinear 6-DOF, quaternion attitude | T | Met |
| FD-02 | RK4 and adaptive RK; convergence and error monitoring | T | Met |
| FD-03 | Multi-rate (physics / control / sensors / output) | I | Met |
| FD-04 | Trim and linear stability analysis with validity check | T | Met (averaging validity reported) |
| CTL-01 | Layered controller (actuator / attitude / flight / navigation) | S | Met |
| CTL-02 | Altitude hold error < 2 m in calm air | T | Met (sim): 0.16 m RMS |
| CTL-05 | Manoeuvre margin: a 1.15 g trim exists at the operating speed; 90° turn and climbing waypoint mission complete in closed loop | S, T | Met (sim) at 12 m/s (rev 3, stall 0.30); at 11 m/s closed-loop turn and mission pass but stall 0.53 > 0.5 |
| CTL-07 | Direct roll authority (R-04) | A, S, T | Met (sim, rev 4): differential twist, 90° turn 5.8 s vs 7.6 s rudder-only |
| CTL-06 | Envelope protection: airspeed priority near the minimum speed | T | Met |
| CTL-03 | Control allocation that respects the actual effectors; under-actuation reported | A | Met |
| CTL-04 | Learned controllers compared with the deterministic baseline | — | Not started (research module) |
| AUT-01 | Waypoint navigation, loiter, return-to-home, sensor-health monitoring | S | Met (sim) |
| AUT-02 | AI perception separated from the flight-critical loop | I | Architecture only |

## Data, safety, verification

| ID | Requirement | Method | Status |
|---|---|---|---|
| DAT-01 | Versioned configurations; immutable revisions | T | Met |
| DAT-02 | Every result records configuration, model version (source hash) and conditions | T | Met |
| DAT-03 | Historical results never modified by model updates | T | Met (append-only annotations) |
| DAT-04 | CSV/JSON export | I | Met |
| DAT-05 | Measured / estimated / simulated values visibly distinguished | I | Met (labels everywhere) |
| SAF-01 | Simulation, bench and flight modes separated; no silent transition to hardware | I | Met (no hardware path exists) |
| SAF-02 | Emergency stop, watchdog, current/temperature monitors before any bench test | — | Specified (SAFETY.md), not built |
| VV-01 | Automated tests for important calculations | T | Met (verification suite) |
| VV-02 | Staged hardware test plan with formal test cards | I | Met (TEST_CARDS.md) |
