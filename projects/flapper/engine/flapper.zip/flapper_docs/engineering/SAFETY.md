# Safety and engineering governance

## Operating modes

| Mode | Purpose | Status in 0.1.0 |
|---|---|---|
| Simulation | all engineering analysis | **only mode implemented** |
| Bench | restrained hardware (mechanism, wings, electronics) | not implemented |
| Flight | free flight | not implemented |

The software contains **no hardware interface**: no serial, CAN or radio driver and no actuator command path. `/api/health` reports `hardware_interfaces: none`. A transition from simulation to physical actuation therefore cannot happen silently.

## Requirements for enabling bench mode (Phase 7)

1. Explicit operator arming in the UI, with a typed confirmation, plus a physical arming switch.
2. A hardware-state check before arming: E-stop loop closed, mechanism guard fitted (interlock switch), current limit configured in the ESC, encoders reading, battery voltage in range.
3. A separate actuator-enable line, driven by the real-time controller, that the high-level computer cannot assert.
4. A watchdog on the real-time controller. Missed heartbeats cut the motor and centre the servos.
5. Monitors with trip limits derived from **measured** capability: motor current, winding temperature, battery voltage and current, vibration (IMU RMS), encoder/command mismatch.
6. Every bench run executes against a signed test card (TEST_CARDS.md) and is logged with its configuration revision.

## Physical testing

Flight tests require a passed readiness review, an appropriate operating area, safety procedures, trained personnel and the authorisations applicable in the operating jurisdiction. **No regulatory compliance or certification is claimed.** Identifying the applicable rules is an open action (R-13).

## Configuration control

* Configurations are immutable revisions. Experiments store the full configuration and model source hash.
* Simulated, estimated and measured data are labelled in the UI, in exports and in stored records.
* Simulation success is not evidence of physical flight capability.
