# Coordinate frames, sign conventions and governing equations

## Frames

| Frame | Axes | Origin |
|---|---|---|
| Inertial | NED: x north, y east, z down (flat, non-rotating Earth) | launch point |
| Body | FRD: x forward, y right wing, z down | aircraft CG with wings at mean stroke |
| Datum | FRD axes, used for configuration geometry | wing-hinge line, root-LE plane |
| Wing (per side) | x forward, y outboard (σ = +1 right, −1 left), z down, before stroke rotation | hinge |
| Section | e_c along chord (LE direction), e_n normal (up for the flat wing), e_s span | strip quarter chord |
| Wind (diagnostics) | x along the flight path relative to air; lift ⟂ in the body x-z plane | CG |
| Frontal mechanism plane | y outboard, z_u up | hinge plane |
| 3-D view (three.js) | X = x, Y = −z, Z = y | |

## Attitude

* Quaternion q = [w, x, y, z] (Hamilton, scalar first) rotates body → NED: v_ned = R(q) v_b.
* q̇ = ½ q ⊗ [0, ω_b]. Renormalised after every integrator step; the drift before renormalisation is monitored and reported.
* Euler angles (ZYX: yaw ψ, pitch θ, roll φ) are produced **only for display**.

## Signs

| Quantity | Positive sense |
|---|---|
| Stroke angle φ | wing tip up (both wings) |
| Twist θ (section pitch) | nose (leading edge) up |
| Bending β | tip deflects up; w(r) = β r²/R |
| Elevator δe | trailing edge down (nose-down moment) |
| Rudder δr | trailing edge left (nose-left yaw moment) |
| α | relative wind from below |
| Hinge torque τ | in the φ sense (raising the wing) |

## Units

SI throughout. Angles are radians internally; configuration fields ending in `_deg` are degrees.

## Governing equations

Kinematics, sinusoidal profile (other profiles in `kinematics.py`):

* φ(t) = φ₀ + A sin(2πft + δ)
* φ̇ = 2πfA cos(2πft + δ)
* φ̈ = −(2πf)² A sin(2πft + δ)

Implemented through the stroke phase state: θ̇ = Ω, φ = φ₀ + A g(θ), φ̇ = A g′ Ω, φ̈ = A (g″Ω² + g′Ω̇).

Relative flow at a wing strip (velocity of the air relative to the section):

  u = w_b − (v_b + ω_b × r + v_wing,rel)

This is the source formula V_rel = V_aircraft + ω × r − V_wind with the sign flipped to "air relative to wing".

Strip loads (quasi-steady): L = ½ρV²c·dr·C_L(α) ⟂ flow, D = ½ρV²c·dr·C_D(α) ∥ flow, plus added mass −ρπc²/4·dr·a_n e_n and the camber moment ½ρV²c²dr·C_m0.

Rigid body:

* m v̇_b = F_b − m (ω_b × v_b)
* I ω̇ + ω × (I ω) = M
* ṗ = R(q) v_b

F_b = Σ wing strips + wing inertial reaction + horizontal/vertical tail + fuselage drag + gravity Rᵀ[0,0,mg] (+ wind via the relative velocity).

Energy: E = P_avg t; endurance t = E_usable / P_avg. Battery current solves P = (V_oc − I R_int) I.

Four-bar closure: D = O₄ − A, K = (|D|² + r₄² − r₃²)/(2r₄), φ = atan2(D_z, D_y) − γ ± acos(K/|D|).
