# Phase 0: repository audit

Date: 2026-11-14. Scope: the `Desktop/Systems` workspace.

## What exists in the workspace

The `Systems` folder is shared by several HolyHornet projects, each owned by a separate development session:

| Folder | Project | Relevant to Flapper? |
|---|---|---|
| `src/swarm_*`, `frontend/` | UAV swarm platform | No (multirotor swarm) |
| `src/uav_lab`, `uav_lab_web/` | single-drone SLAM lab | Pattern only (FastAPI + Next.js + engine split) |
| `moving_ecosystem/` | launch/recovery from moving platforms | No |
| `falcon_intelligence/` | falcon monitoring | No |
| `skygrid/` | fleet platform | Pattern only (same Next 16 / R3F / Recharts stack) |
| `aicn/` | animal intelligence | No |

**No ornithopter, flapping-wing, aerodynamic or mechanism code existed.** Nothing was reusable at the physics level. The multirotor/quadrotor models elsewhere assume thrust vectors from rotors and cannot represent wing kinematics.

## Decisions

* HolyHornet Flapper is built **self-contained in `Systems/flapper/`** so it does not touch other sessions' files. The only shared file edited is `.claude/launch.json` (two entries: `flapper-api` port 8760, `flapper-web` port 3660).
* The technology stack reuses what the workspace already proves out: Python 3.14 + NumPy/SciPy + FastAPI/Pydantic (shared `.venv`), Next.js 16 + React 19 + React Three Fiber + Recharts + Tailwind 4.
* **Deviations from the suggested stack**, each with a reason:
  * **Storage**: append-only JSON files, not PostgreSQL. Configurations and experiments are immutable documents; files give exact reproducibility with no service to run. The `store.py` interface is narrow, so moving to PostgreSQL later is contained.
  * **No Redis or Docker yet.** One process serves analyses and live simulation; Docker packaging is planned in Phase 9.
  * **CAD**: no FreeCAD or OpenSCAD is installed in this environment. Parametric geometry is generated in code (3-D model, linkage), and STEP/STL export is a Phase 4 deliverable.
  * **Monorepo layout**: adapted (see ARCHITECTURE.md). The Python engine is one package, `hhflapper`, whose modules mirror the suggested `simulation/`, `control/`, `mechanical/` and `electronics/` areas. Splitting one tightly coupled physics model across many top-level packages would add import plumbing without adding separation.

## Missing components (at start)

All of them: requirements, architecture, models, simulation, control, UI, tests and documentation. The status of each is now tracked in REQUIREMENTS.md and DEVELOPMENT_PLAN.md.
