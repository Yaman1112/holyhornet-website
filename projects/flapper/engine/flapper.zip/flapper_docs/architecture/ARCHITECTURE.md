# Architecture

## System architecture (physical, planned)

```
 Battery 2S ─ power module (V/I) ─┬─ ESC ─ motor ─ gearbox ─ crank ─┬─ four-bar L ─ left wing hinge
                                   │                                  ├─ four-bar R ─ right wing hinge
                                   │                                  └─ twist linkage L/R (D-01)
                                   ├─ regulators ─ real-time MCU ─┬─ IMU / baro / airspeed
                                   │                              ├─ wing encoders, motor RPM, temp
                                   │                              ├─ tail servos (elevator, rudder)
                                   │                              └─ telemetry radio, GNSS
                                   └─ (optional) high-level computer ─ camera / perception / logging
```

The time-critical loop (sensors → estimator → controller → ESC/servos) runs on the real-time controller. The high-level computer only sends set-points and cannot drive actuators directly.

## Software architecture (this repository)

```
flapper/
├── backend/
│   ├── hhflapper/                  Python engine (simulation-only)
│   │   ├── config.py               Pydantic configuration (aircraft, environment, simulation, faults)
│   │   ├── frames.py               quaternions, DCMs, Euler (display)           ── simulation/numerical
│   │   ├── geometry.py, massprops.py  wing strips, mass budget, inertia         ── mechanical/
│   │   ├── kinematics.py           stroke profiles                               ── simulation/kinematics
│   │   ├── mechanism.py            four-bar synthesis, closure, loads (Sim A)   ── mechanical/transmission
│   │   ├── aero.py, model.py       strip aerodynamics, structure, 6-DOF RHS (Sim B/C) ── simulation/
│   │   ├── environment.py          ISA, wind, gusts, turbulence (Sim G)         ── simulation/environment
│   │   ├── power.py                battery, motor, endurance                    ── electronics/power
│   │   ├── sensors.py              simulated sensors (Sim E)                    ── electronics/sensors
│   │   ├── control.py              estimator, cascaded controller, missions (Sim D/F) ── control/, autonomy/
│   │   ├── integrators.py          RK4, Dormand-Prince                           ── simulation/numerical
│   │   ├── analysis.py             captive cycles, trim, linearisation, PBH controllability
│   │   ├── simulator.py            multi-rate loop, faults (Sim H), monitors, outcomes
│   │   ├── research.py             parameter sweeps (research engine)            ── experiments/
│   │   ├── feasibility.py          mass/energy/gear studies
│   │   ├── store.py                append-only configs and experiments           ── shared/schemas
│   │   ├── version.py              model versions + source hash
│   │   └── api/app.py              FastAPI: REST, background jobs, live WebSocket
│   ├── tests/                      verification suite (pytest)
│   └── tools/                      feasibility_report.py, run_validation.py
├── web/                            Next.js 16 + React Three Fiber + Recharts (14 workspaces)
├── data/                           configs/, experiments/, studies/, validation/ (generated)
└── docs/                           this documentation
```

### Interfaces

* **Engine ↔ API**: plain Python calls. Long computations (simulation, sweeps, stability, envelope) run as background jobs (`POST /api/jobs/*`, poll `GET /api/jobs/{id}`).
* **API ↔ web**: JSON over HTTP. Every request carries a configuration reference (stored id + revision) or an unsaved draft. The live digital twin uses the WebSocket `/api/live` and streams 100 Hz state samples, batched at about 30 Hz.
* **Configuration**: one Pydantic schema (`AircraftConfig`) shared by every module. Its JSON schema is exposed at `/api/schema/aircraft`.

## Simulation architecture

| Rate | Process |
|---|---|
| 500 Hz (dt = 2 ms, RK4) or adaptive DOPRI5(4) | full RHS: stroke, strips, structure, tail, rigid body, drive, battery, thermal |
| 100 Hz | sensors (sample-and-hold), estimator, controller, mission manager, turbulence update, fault injection, monitors, recording |
| 5 Hz | GNSS |
| per wingbeat | controller feedback averaged over exactly one stroke period |

The **captive** mode (body states frozen, wings and structure integrated) provides cycle averages for trim, linearisation and sweeps. The **free-flight** mode integrates everything.

Simulations A–H map to: A `mechanism.analyse`, B `research.cycle_study/sweep`, C `simulator` + `analysis`, D `control.Controller`, E `sensors`, F `control` navigation, G `environment` + scenarios, H `simulator` faults.

## Model management

`version.py` records a package version, per-submodel version strings and a SHA-256 over all engine sources. Every stored experiment embeds it together with the full configuration. Configuration revisions are written with exclusive-create semantics (`open(..., "x")`), so they cannot be overwritten.
