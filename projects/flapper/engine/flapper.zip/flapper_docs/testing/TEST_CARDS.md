# Verification matrix and test cards

## Software verification (automated)

`python backend/tools/run_validation.py` runs `backend/tests` and writes `data/validation/latest.json`, which the Validation workspace displays.

| Area | Tests |
|---|---|
| Frames / quaternions | Euler↔quaternion round trip, DCM orthonormality vs ZYX product, q̇ vs finite rotation, degenerate norm rejected |
| Kinematics | spec formulas φ, φ̇, φ̈ vs finite differences; profile derivatives (sinusoid, asymmetric, table); asymmetric(0.5) ≡ sinusoid; downstroke fraction |
| Integrators | torque-free rigid body conserves H and energy (Dzhanibekov case); RK4 order ≈ 4; Dormand-Prince meets tolerance |
| Mass / power | budget sums; inertia SPD; ballast at CG keeps the CG; battery P = VI root; E = Pt; t = E/P; motor energy balance |
| Aerodynamics | glide lift and drag vs finite-wing theory; symmetry; thrust ∝ (Af)²; rigid-wing energy balance; Wagner impulsive start vs Jones φ(s); plunge thrust ratio vs Theodorsen–Garrick |C(k)|² |
| Structure | bending-mode frequency in vacuum |
| Twist linkage | spatial loop closure; tracking < 2° RMS; transmission > 0.5; horn on flap axis decoupled; twist shapes; energy balance including twist drive; hardware in mass budget |
| Mechanism | loop closure; synthesis hits amplitude and mean; Grashof; transmission angle > 40°; single-pin asymmetry; table derivatives |
| Drive | motor-crank model spins up from rest and draws charge |
| System | trim is an equilibrium; closed-loop altitude/speed hold; motor failure gives glide or honest loss (no fake recovery); stuck wing not reported nominal |
| Data | config revisions append-only; experiment results immutable; annotations preserved |
| API | simulation-only health; summary/cycle; validation errors (422); docs path traversal blocked |

---

## Hardware test cards (templates: none executed)

Every card has the fields: objective, equipment, preconditions, configuration, procedure, expected result, pass criteria, fail criteria, emergency stop conditions, observed results, deviations and sign-off. **Observed results stay empty until a test is actually run.** Results are never invented.

### ELEC-01: Electronics bench test
* **Objective:** verify the power tree, regulators, MCU boot, sensor buses and telemetry with no motor connected.
* **Equipment:** bench PSU with current limit, multimeter, oscilloscope, laptop.
* **Preconditions:** schematic reviewed; parts selected against datasheets; ESC disconnected from the motor.
* **Configuration:** config revision under test; firmware hash.
* **Procedure:** 1) power from the PSU at the pack voltage, 0.5 A limit; 2) measure the 5 V / 3.3 V rails; 3) read each sensor; 4) telemetry heartbeat; 5) watchdog trip test.
* **Expected:** rails within ±3%; all sensors respond; heartbeat loss is detected within the configured timeout.
* **Pass:** all of the above. **Fail:** any rail out of tolerance, any bus error, watchdog not tripping.
* **Emergency stop:** PSU current limit reached, smoke or heat.
* **Observed results:** — **Deviations:** — **Sign-off:** —

### SENS-01: Sensor calibration
* **Objective:** determine IMU biases and scale factors, baro noise, pitot zero and encoder offsets. Replace the simulated sensor parameters with measured ones.
* **Procedure:** six-position IMU test; 10 min static log; pitot zero in still air; encoder sweep against a protractor jig.
* **Pass:** calibration residuals below the values assumed in `SensorConfig`, or the configuration updated with measured values (new revision).
* **Observed results:** —

### ACT-01: Actuator bench test
* **Objective:** motor + ESC on the gearbox without wings; measure the no-load current and speed vs throttle; servo travel and rate.
* **Emergency stop:** E-stop, current above limit, temperature above 80 °C.
* **Pass:** no-load current within 30% of the assumed 0.4 A; measured Kv recorded.
* **Observed results:** —

### ACT-02: Roll-servo load path and drift
* **Objective:** measure servo current (torque) and twist-bias drift with the mechanism flapping at cruise frequency, restrained, in still air and in a wind stream; with the servo powered and unpowered.
* **Pass:** powered servo current within continuous rating with < 5% of it at the wingbeat frequency (CS-03 predicts < 2% of stall); unpowered drift < 1° in 60 s. If the drift test fails, fit the lead-screw drive.
* **Observed results:** —

### MECH-04: Static twist and bending test
* **Objective:** measure wing tip twist and bending under known loads to replace the estimated `torsion_k` and `spar_EI`.
* **Procedure:** clamp the wing root; hang masses at the 25% and 50% chord points at 75% span; photograph the deflection.
* **Pass:** stiffness values derived with uncertainty; new configuration revision.

### MECH-05: Restrained mechanism + wing balance test
* **Objective:** wings flapping on a load cell / balance in still air and in a wind stream; measure mean thrust, lift and electrical power vs frequency.
* **Preconditions:** guard fitted, E-stop wired, ACT-01 passed.
* **Expected:** compare with captive-cycle predictions (Aerodynamics workspace, same configuration revision).
* **Pass:** data recorded with uncertainty; model error quantified in the Flight Data workspace. *The model is not expected to match within 10%: this test is how R-01 is quantified.*
* **Emergency stop:** abnormal noise, coupler deflection, current > limit, temperature > limit.

### MECH-07: Wing-park release (rev 8, DS-04b; replaces the detent card)
* **Objective:** with the mechanism restrained in a wind stream (≥ 10 m/s), wings fitted, flapping at the cruise frequency: cut motor power, let the FC failure detector command the release servo, and record the crank stop angle, the twist-tube angle after release, the hinge-spring anchor state and the time from power cut to release. Repeat 20 times at random crank phases, plus 10 bench releases under the full in-flight spring preload to measure sear trigger force.
* **Pass:** every release completes (both sears), the crank settles within ±10° of the simulated 237° rest, the driven twist reads within ±2° of zero, release within 1.0 s of power cut, sear trigger force below 50% of the ES9051 stall force at the servo arm, and no release ever triggered while flapping (detector false-alarm check over 30 min of flapping including frequency steps).
* **Emergency stop:** standard mechanism-test conditions.
* **Observed results:** —

### MECH-06: Endurance / fatigue run
* **Objective:** 2 h continuous flapping at the cruise frequency; inspect hinges, pins and membrane every 15 min.

### VIB-01: Vibration test
* **Objective:** IMU spectra at the mounting point while flapping (restrained); confirm that the anti-alias filtering and the wingbeat-synchronous averaging work.

### PWR-01: Power system test
* **Objective:** fly the simulated cruise power profile on the real pack with an electronic load; compare voltage sag and capacity with the model.

### HIL-01: Hardware-in-the-loop
* **Objective:** real flight controller in the loop with the simulator (sensor emulation in, actuator commands out). Repeat the Simulation Lab scenarios, including the failure cases.

### GND-01: Ground integrated system test
* **Objective:** complete aircraft, restrained, all systems live; RF range check; fail-safe triggers.

### FRR-01: Flight-test readiness review
* **Objective:** formal review of all previous results, the risk register, the operating area, procedures and authorisations. **No flight without a signed review.**
