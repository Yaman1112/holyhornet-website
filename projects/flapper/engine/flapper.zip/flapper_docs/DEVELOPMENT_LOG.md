# Development log

## 2026-11-15: CS-05 current margin and strong turbulence (baseline revision 9)

* Motor current now recorded (`motor_i`). It is pulsed (peak ≈ 2.4 × RMS); the 10 A limit was reached only in pulses, RMS 2–4 A, winding rise 6–18 K over 120 s. Uncapping it barely changes flight: the cap was not the problem.
* **Strong turbulence was.** At σ 1.5 m/s rev 8 hit the ground at 73 s: gust stall (mean stall fraction 0.45), wingbeat command at the 8 Hz cap 43% of the time, speed protection 78% of the time. Throttle averaged 0.5, so the motor was not the limit.
* Levers compared over 2 seeds × σ 1.0/1.5 × 120 s (new tool `study_cs05_turbulence_margin.py`): 34:1 alone, gust margin alone, fixed 13 m/s, 10 Hz cap alone, combinations.
* **Revision 9:** gearbox 34:1, wingbeat cap 10 Hz, adaptive turbulence speed margin in the controller (1.5 × (σ̂ − 0.3), ≤ +2 m/s, from the running std of the cycle-averaged airspeed; zero in calm air). σ 1.5: lowest altitude 20–27 m, current limit 2–3% of the time; σ 1.0: ≤ 6 m loss. Cruise +1.7% (18.1 min / 13.0 km). 14 m/s holds at 20% SoC (throttle 0.87).
* New requirement PLT-09 and risk R-16; tests for the gust estimator and for σ 1.5 survival; 58 pass.

## 2026-11-15: Component selection and DS-04b wing park (baseline revision 8)

* Requirement envelope extracted from closed-loop simulations (`component_requirements.py`).
* Motor screen on published Kv/Rm/Io (Scorpion SII-2205-1585KV V2, Hacker A10-12S, Scorpion M-2205-2350KV): the SII-2205 has the best Km and lowest no-load torque.
* **Quasi-static screen was not enough.** It used a 15 A cap; the listing says 10 A. In the dynamic motor-crank simulation the Scorpion on 2S at 21:1 was current-limited and could not hold 14 m/s (8.95 m/s, throttle saturated); the mission needed current limiting. 3S at 26/30/34:1 all pass; 30:1 is clean (mission 18.8 W, peak 5.4 A). New tool `study_cs04_drive_pack.py`.
* **Safety bug:** the motor-failure detector compared instantaneous crank speed with a wrong command (throttle × 6) and tripped on in-stroke ripple (4.8–10 Hz at 14 m/s), commanding a glide that crashed. Now 0.5 s average against the real wingbeat command, 0.3 s persistence; regression test.
* Parts: Tekko32 F4 ESC, Matek H743-WLITE, M10Q-5883, RP1 V2, ASPD-4525, EMAX ES9051 ×4, AS5048A encoders, Tattu 650 mAh 3S 75C. Masses from listings, labelled; motor thermal resistance and gearbox efficiency remain estimates. Pinouts not defined.
* **DS-04b, the fail-safe was broken.** Motor failure on the motor-crank drive lost 117 m in 25 s (L/D 2.5), the same on rev 7. The detent's capture was kinematic in the prescribed drive. Physically the crank stops within 0.1 s, never spins down through the park angle, and the hinge springs pull it to ~357° with the twist frozen nose-down. A physical cam detent, a one-tooth ratchet pawl, a park angle at the dead centre and hinge-spring retuning were all modelled and rejected (see the study). Releasing only the springs works in 3 of 18 cases; releasing the twist drive *and* the springs parks the crank at 237° in every case (any phase, delay 0.1–0.6 s, 12/14 m/s, turns, turbulence): L/D 5.45–6.0.
* Park model: `ParkConfig.mechanism = "release"` (servo + release bar + two sears, 5.6 g); the simulator trips it when the FC declares failure; the prescribed drive's idealised capture now uses the same 237°. New tool `study_ds04b_park_dynamic.py`; tests for the dynamic park and for the poor no-release case. Test card MECH-07 rewritten.
* **Revision 8:** 333.3 g, 18.3 min / 13.2 km at 12 m/s (quasi-static), 56/56 tests.

## 2026-11-14: DS-06 elastic energy storage (baseline revision 7)

* Hinge-spring model: parallel spring in the actuator torque, hysteresis as equivalent damping, mass from peak stored energy.
* Quasi-static sweep (11 stiffnesses × 5 preloads × 3 operating points): broad optimum at k ≈ 1.0, neutral 10° below the mean stroke, −8%. The preload direction matters as much as k.
* **Dynamic simulation reversed the stacking decision.** Flywheel and spring both buffer stroke energy; together they cost +3.9%. Spring *instead of* flywheel: −2.3% at cruise, 4.5 g lighter.
* Slip caught: wrong component index zeroed the motor instead of the flywheel; spotted from the masses and re-run.
* Detent capacity raised to 0.35 N·m (the springs raise parked holding torque to 0.22 N·m + drag).
* **Revision 7:** hinge springs, no flywheel, 340.5 g. New test (springs lower crank RMS and back-driving; mean power conserved). 54 pass.

## 2026-11-14: DS-05 drive train (baseline revision 6)

* Quasi-static sweep (motor mass 16–48 g × ratio 6–100 × 1–3 stages; generic scaling laws): the optimum is flat (−1.6% at best). Motor and ratio are not the lever.
* Loss breakdown at cruise: gearbox 3.3 W, no-load 2.8 W, copper 1.8 W, ESC 1.5 W, back-driven work 1.3 W, avionics 2.4 W.
* **Feasibility error found:** K_v 1800 is voltage-starved on 2S (dynamic sim: throttle saturated 21% at cruise, 79% at 14 m/s; only 12.8 m/s reachable). The prescribed-frequency model could not show it.
* New ESC crank-speed governor (PI) for the motor-crank drive; throttle recorded.
* **Revision 6:** K_v 2500 rewind, motor-shaft flywheel (+8 g, ripple −65%, −4% power), wingbeat cap 8 Hz. 344 g; reaches 13.9 m/s unsaturated. Gearbox η ≥ 0.9 set as a target (−15%), not banked.
* New test: dynamic motor-crank drive reaches 14 m/s without throttle saturation.

## 2026-11-14: CS-03 roll-servo load path

* Per-wing twist-drive torques recorded; rod forces from the solved linkage sensitivity dℓ/dp.
* Rod forces peak 11.5–12.6 N and reverse at 6.2 Hz. Inline servos would carry ~30% of stall continuously. In the **differential bellcrank** the symmetric loads cancel: servo < 2% of stall, 6 Hz component ≈ 0; the pivot takes 23–25 N.
* Roll handling is insensitive to servo slew down to 50°/s, so an irreversible lead screw costs no handling and is kept as a fail-fixed upgrade.
* Config records the arrangement; new regression test for the load cancellation; bench card ACT-02.

## 2026-11-14: DS-04 wing-park detent (baseline revision 5)

* Detent model (crank capture after drive loss), parked-wing holding torque by virtual work (the power/Ω form was singular when the crank stopped), and a speed-holding glide law.
* **DS-04:** 12 park angles plus gust, glide-turn and ±15° tolerance runs. ~50% of arbitrary stop angles are fatal. 240° (self-locking at the four-bar top dead point) looked best in calm air but sits on a cliff: 225° crashes and 240° spins in a glide turn. **Chose 270°** (+28.6° dihedral; robust 255–285°; holding torque ≤ 0.11 N·m) over the 90° band (10% better L/D but twice the torque and tips-down wings).
* Detent capacity 0.2 N·m (holding + reflected motor drag); centrifugally disengaged so there is no flapping cost; +6 g (336 g).
* 2 new tests (park capture and glide ratio; detent capacity vs holding torque across the band). 51 pass. Test card MECH-07 added.

## 2026-11-14: CS-02 direct roll effector (baseline revision 4)

* New control input u[9]: differential twist bias on the torque tubes (servo + bellcrank on both twist push rods). Actuator flag, servo slew limit, servo mass in the budget, lateral control law, and a manual override in the twin.
* Effectiveness at 12 m/s: differential twist −2.48 N·m/rad of roll (36× rudder, proverse yaw); differential stroke mean −0.013 (useless: side force, not roll), so it was rejected.
* 24-point gain scan, then a 12-case closed-loop comparison. An apparent gust-rejection deficit was a heading-gain confound; at matched gain, twist warping beats rudder-only on turns (5.8 vs 7.6 s, half the sideslip), gusts and turbulence (−28% roll RMS).
* **Revision 4:** differential twist fitted, 330 g, 21.4 W at 12 m/s (+1.1%), 1.15 g margin kept.
* 2 new tests (effectiveness and sign; turn-time improvement with an evidence-based threshold); 49 pass.

## 2026-11-14: DS-03 co-optimisation, manoeuvre margin, envelope protection (baseline revision 3)

* 8-variable co-optimisation of the four-bar and twist linkage (both re-synthesised per candidate): Latin hypercube (1/64 feasible: a narrow aerodynamic valley), then pattern search. 10 m/s: 21.69 → 17.69 W.
* **Closed-loop validation overturned the 10 m/s design point.** Revision 2 itself crashes in a 90° turn at 10 m/s (no 1.15 g trim; 10 m/s is the minimum speed). The operating speed is now 11 m/s, and the study was repeated with a 1.15 g constraint: 18.55 W.
* **Waypoint-mission crash** (climb + turn) exposed a controller with no stall protection. Added airspeed priority, a reduced bank limit and a climb-rate cap. Revision 2 and revision 3 now both complete the mission.
* Stall warning hysteresis (it had flickered every wingbeat). The feasibility report checks the 1.15 g margin per speed.
* **Revision 3:** amplitude 28°, crank −3 mm, lever bend −20.5° (transmission 42.9°, chosen over the 40.6° optimum for margin), twist ±21.75° / −28.75°, k = 0.6. 18.7 W at 11 m/s (−23.5% vs revision 2). With the strict 1.15 g rule the operating speed is **12 m/s: 21.2 W, 17.7 min** (revision 2's margined point: 11 m/s, 15.3 min).
* Study tooling: resumable evaluation cache and broken-pool recovery, after a session ended mid-run and lost a first attempt.
* Tests: 47 (new: 1.15 g margin, closed-loop turn plus climbing mission, envelope protection).

## 2026-11-14: twist drive designed (DS-02, decision D-02, baseline revision 2)

* Generalised the driven-twist model: spanwise shape w₀ + (1 − w₀) r/R. The twist-drive torque now comes from a generalised-force balance (J_dd, J_dψ, Q_d), and the air-power diagnostic includes pitch work.
* **DS-02 (24 trims):** root feathering (w₀ = 1) needs about 3× the power of tip-growing twist and stalls heavily. The mechanism must twist the tip.
* **Mechanism:** a rotating LE torque tube with a 2-DOF root yoke, a pitch horn on the flap axis and a push rod from a 1:1 idler eccentric (`twistlinkage.py`: spatial closure solve, least-squares synthesis, transmission, coupling, loads, tube check). The first attempt, with the eccentric on the crank centreline, reached a 0.06 transmission factor and 8° RMS error; moving the eccentric under the hinge gives 0.91° RMS and transmission ≥ 0.72. Rod force 8.9 N, tube wind-up 2.0°, +16 g.
* A rigid torque tube removes the beneficial passive twist (+30% power). A **series torsion spring** sets the tip compliance to 1.0 N·m/rad, chosen over 0.5 to keep the stalled fraction at 0.29.
* **Baseline revision 2** (rev 1 kept): real linkage twist, four-bar stroke, lead −35°, wing 20 g. It trims 10–14 m/s (no trim at 9 m/s); cruise 21.7 W (+27% vs ideal twist); endurance 17.2 min.
* Envelope sweep bug: passing the previous point as the guess skipped the quasi-steady seed, so 12–13 m/s falsely failed to trim. The seed is now a lazy fallback after a supplied guess fails.
* 4 new tests (linkage closure/tracking/transmission, horn decoupling, twist shapes + energy balance including the twist drive, mass budget); 44/44 pass. 3-D view, Mechanical page and Design page updated.

## 2026-11-14: R-01 unsteady aerodynamics (model us-bem-1.1)

* Added Wagner indicial lift (R.T. Jones two-pole approximation) as 2 lag states per strip (40 states for 20 strips). The circulatory force acts normal to the effective inflow. Default on; `aerodynamics.unsteady = False` restores qs-bem-1.0.
* **Validation:** the small-amplitude plunge thrust ratio (unsteady/QS) matches Garrick's |C(k)|² within 1–4% for k = 0.05–0.38. Impulsive-start lift begins at 50% and follows the Jones φ(s). Three new automated tests; 40/40 pass.
* **Result:** trim needs +8–10% wingbeat frequency (5.12 → 5.54 Hz at 10 m/s); mechanical power +1–2%, electrical +6–8%. Free flight at 10 m/s settles at 5.87 Hz. Altitude hold 0.14 m RMS. The engine still runs 1.7× faster than real time.
* **Numerics:** the slow Wagner pole (≈0.17 s, about one wingbeat) left the warm-started captive cycle unsettled and made the trim residuals noisy; trims at 9/10/12/14 m/s failed. Fixed with two extra settling cycles plus seeding from the quasi-steady trim (×1.08 frequency). Trim takes 10–20 s.
* Stored experiment EXP-20261114-0001 was run with qs-bem-1.0 and keeps that model version; it is not rewritten.
* R-01 is downgraded from 16 to 12. 3-D wake, LEV and dynamic stall remain open.

## 2026-11-14: release 0.1.0 (Phases 0–3, parts of 5–6)

**Phase 0.** Audited the shared `Systems` workspace: there was no flapping-wing code, and the multirotor projects there are not reusable at the physics level. Built the project self-contained in `flapper/`. Wrote the requirements, architecture, conventions and risk register.

**Engine.**
* Frames and quaternions, kinematic profiles (sinusoid, asymmetric, table, linkage), four-bar synthesis with closure, transmission angle, Grashof and load checks.
* Blade-element quasi-steady aerodynamics (attached/post-stall blend, added mass, pitch-rate term). Two-mode flexible wing (bending + torsion). Tail and fuselage.
* 6-DOF rigid body with the wing inertial reaction. Prescribed or DC-motor/crank drive. LiPo battery with internal resistance; motor thermal model.
* RK4 and Dormand-Prince integrators with quaternion-drift and error monitoring.
* Captive (wind-tunnel) cycles, trim, finite-difference linearisation, PBH controllability.
* Simulated sensors, complementary estimator, cascaded controller with wingbeat-synchronous averaging, mission manager (hold/waypoints/loiter/RTH/glide).
* Eleven fault types, envelope monitors and outcome classification. Append-only configuration and experiment store with model source hashes.

**Findings that changed the design.**
1. *Linkage near toggle.* The first four-bar geometry reached an 11° minimum transmission angle. A geometry scan selected a 16 mm lever with −30° bend and the crank 30 mm below the hinge plane: 57° minimum transmission angle.
2. *Trim failure at the RK4 limit.* The trim search visited ~0.3 Hz, where the cycle step exceeded the structural-mode stability limit and the run diverged. The captive cycle now sub-steps to keep ω·h ≤ 0.8, and the frequency is bounded below at 1 Hz.
3. *DS-01: no thrust with plain flapping.* The model was verified (glide, thrust ∝ (Af)², energy balance), so the shortfall is physical: outer-wing stall. **Decision D-01: driven spanwise twist ±30°.** The trim envelope is now 9–14 m/s.
4. *Rigid-wing pre-solve removed from trim.* Rigid wings stall, so their trim solution is unrelated to the flexible one. Trim now solves directly on the aeroelastic cycle with warm-started structural states (~6–10 s).
5. *Twist-drive power.* Added the inertial forcing of the driven twist on the torsion mode, and the actuator power reflected to the crank.
6. *CS-01: lateral limit cycle.* Roll-rate → rudder feedback destabilises the rudder-only lateral loop. Retuned the gains.
7. *Motor failure.* The wings freeze at an arbitrary stroke angle and the simulated aircraft departs. New requirement: a wing-park mechanism (R-09).
8. *Controllability.* The Kalman-rank test reported 3/8 because of numerical swamping by the fast roll mode. It was replaced with the PBH test: 8/8.

**Web.** 14 workspaces. The live digital twin streams 100 Hz simulation state over WebSocket; the engine runs at ≈1.7–1.9× real time. Every chart has units, an explanation, a source label and CSV export.

**Verification.** 37 automated tests pass (`tools/run_validation.py`).

**Not done.** CAD export, component selection, wiring/pinouts, twist linkage design, unsteady aerodynamics, EKF, AI perception, hardware integration, Docker packaging.
