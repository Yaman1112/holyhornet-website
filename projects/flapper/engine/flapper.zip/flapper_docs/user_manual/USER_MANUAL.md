# User manual

## Run

```
# engine API (port 8760)
cd flapper/backend
python -m uvicorn hhflapper.api.app:app --port 8760

# web workspace (port 3660)
cd flapper/web
npm install
npm run dev
```

Open http://localhost:3660. The API URL can be changed in **Settings**.

Tests and reports:

```
cd flapper/backend
python -m pytest -q                 # verification suite
python tools/run_validation.py      # writes data/validation/latest.json (Validation page)
python tools/feasibility_report.py  # regenerates docs/engineering/FEASIBILITY_RESULTS.md (~3 min)
```

## Workspaces

| # | Workspace | What it does |
|---|---|---|
| 01 | Overview | configuration summary, cruise trim, 3-D replay of the simulated trimmed cycle, mass budget |
| 02 | Aircraft Design | edit parameters into a draft (used everywhere immediately); see which analyses need recalculation; save as a new revision; set all-up mass |
| 03 | Mechanical System | four-bar animation, stroke/transmission-angle plots, hinge/crank/coupler loads from the trim cycle, actuation requirement, trade study |
| 04 | Aerodynamics | wingbeat-cycle forces, power, twist, deflection at any airspeed/α; captive and trim parameter sweeps (stored as experiments) |
| 05 | Flight Dynamics | trim, linearised modes + eigenvalue plot, control effectiveness, envelope/power/endurance, gear-ratio study |
| 06 | Flight Control | architecture, gains, step/gust tests with rise time, overshoot and settling |
| 07 | Electronics | block diagram, power budget, simulated sensor set, requirements for component selection |
| 08 | Digital Twin | **live** 6-DOF simulation: start/pause/stop/reset/replay, time scale, commands, manual overrides, fault injection, telemetry, CSV export |
| 09 | Simulation Lab | scenario library (dynamics, sensors, mission, environment, 10 failure cases) with assessment |
| 10 | Research Experiments | stored experiments, comparison of up to 4 runs, append-only conclusions, CSV/JSON export |
| 11 | Flight Data | import a measured CSV log and compute model error against a stored run |
| 12 | Validation | verification test results, model validation status, hardware test plan |
| 13 | Documentation | these documents |
| 14 | Settings | API URL, operating mode (simulation only), conventions |

## Data labels

**SIMULATED**: output of the model. **ESTIMATED**: engineering estimate. **MEASURED**: imported physical data. **CFG**: configured value. Nothing in a fresh installation is measured.
