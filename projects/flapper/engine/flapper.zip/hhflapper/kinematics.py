"""Wingbeat kinematics.

The stroke angle of each wing is phi = phi0 + A * g(theta), where theta is the
stroke phase (state variable, theta_dot = Omega = 2 pi f) and g is a normalised
periodic shape in [-1, 1]:

  sinusoid    g = sin(theta)                  -> phi = phi0 + A sin(2 pi f t + delta)
  asymmetric  piecewise-cosine with downstroke fraction tau (tau = 0.5 == sinusoid)
  table       one recorded period, periodic cubic spline
  mechanism   phi(theta) from the four-bar linkage (see mechanism.py)

With theta_dot = Omega and Omega_dot known:
  phi_dot  = A g'(theta) Omega
  phi_ddot = A (g''(theta) Omega^2 + g'(theta) Omega_dot)
"""
from __future__ import annotations

import math

import numpy as np
from scipy.interpolate import CubicSpline

TWO_PI = 2 * math.pi
GRID = 2048


# ---- closed-form reference (used by tests and documentation) ----------------

def phi_sin(t, f, A, phi0=0.0, delta=0.0):
    return phi0 + A * np.sin(TWO_PI * f * t + delta)


def phi_dot_sin(t, f, A, delta=0.0):
    return TWO_PI * f * A * np.cos(TWO_PI * f * t + delta)


def phi_ddot_sin(t, f, A, delta=0.0):
    return -((TWO_PI * f) ** 2) * A * np.sin(TWO_PI * f * t + delta)


# ---- profiles ---------------------------------------------------------------

class Profile:
    """Normalised periodic stroke shape g(theta) with first/second derivative."""

    name = "base"

    def eval(self, theta: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        raise NotImplementedError


class SinusoidProfile(Profile):
    name = "sinusoid"

    def eval(self, theta):
        s = np.sin(theta)
        c = np.cos(theta)
        return s, c, -s


class AsymmetricProfile(Profile):
    """Downstroke occupies fraction `tau` of the period. Top of stroke at theta = pi/2."""

    name = "asymmetric"

    def __init__(self, tau: float):
        self.tau = float(tau)

    def eval(self, theta):
        tau = self.tau
        s = np.mod(np.asarray(theta, dtype=float) - math.pi / 2, TWO_PI) / TWO_PI
        down = s < tau
        u_d = np.pi * s / tau
        u_u = np.pi * (s - tau) / (1 - tau)
        g = np.where(down, np.cos(u_d), -np.cos(u_u))
        dg = np.where(down, -np.sin(u_d) / (2 * tau), np.sin(u_u) / (2 * (1 - tau)))
        ddg = np.where(down, -np.cos(u_d) / (2 * tau) ** 2, np.cos(u_u) / (2 * (1 - tau)) ** 2)
        return g, dg, ddg


class GridProfile(Profile):
    """Dense pre-tabulated periodic profile (table data or linkage output)."""

    name = "grid"

    def __init__(self, g: np.ndarray, dg: np.ndarray, ddg: np.ndarray, name: str = "grid"):
        self.g, self.dg, self.ddg = g, dg, ddg
        self.th = np.linspace(0, TWO_PI, len(g), endpoint=False)
        self.n = len(g)
        self.name = name

    def eval(self, theta):
        x = np.mod(theta, TWO_PI) / TWO_PI * self.n
        i0 = np.floor(x).astype(int) % self.n
        i1 = (i0 + 1) % self.n
        w = x - np.floor(x)
        return (
            self.g[i0] * (1 - w) + self.g[i1] * w,
            self.dg[i0] * (1 - w) + self.dg[i1] * w,
            self.ddg[i0] * (1 - w) + self.ddg[i1] * w,
        )

    @classmethod
    def from_samples(cls, values: list[float] | np.ndarray, name="table") -> "GridProfile":
        v = np.asarray(values, dtype=float)
        if len(v) < 4:
            raise ValueError("a recorded stroke table needs at least 4 samples per period")
        th = np.linspace(0, TWO_PI, len(v), endpoint=False)
        cs = CubicSpline(np.append(th, TWO_PI), np.append(v, v[0]), bc_type="periodic")
        tg = np.linspace(0, TWO_PI, GRID, endpoint=False)
        return cls(cs(tg), cs(tg, 1), cs(tg, 2), name=name)


def make_profile(kin, mechanism_tables=None, side: int = 1) -> Profile:
    if kin.profile == "sinusoid":
        return SinusoidProfile()
    if kin.profile == "asymmetric":
        return AsymmetricProfile(kin.downstroke_fraction)
    if kin.profile == "table":
        return GridProfile.from_samples(kin.table)
    if kin.profile == "mechanism":
        if mechanism_tables is None:
            raise ValueError("mechanism profile requires linkage tables")
        return mechanism_tables[side]
    raise ValueError(kin.profile)


def reduced_frequency(f: float, chord: float, V: float) -> float:
    """k = pi f c / V (based on mean chord). Quasi-steady theory degrades for k > ~0.1-0.3."""
    return math.pi * f * chord / max(V, 1e-6)


def strouhal(f: float, tip_excursion_pp: float, V: float) -> float:
    """St = f * (peak-to-peak tip excursion) / V. Efficient animal flight sits near 0.2-0.4."""
    return f * tip_excursion_pp / max(V, 1e-6)
