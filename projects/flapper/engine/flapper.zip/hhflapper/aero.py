"""Section aerodynamic coefficients.

Quasi-steady model blended between attached thin-wing behaviour and a
flat-plate post-stall model (Viterna-style blend). Used for every wing strip
and for the tail surfaces.

  attached:   CL = a3d (alpha - alpha0)
              CD = cd0 + CL^2 / (pi e AR)
  post-stall: CL = 2 sin(ae) cos(ae)
              CD = cd0 + 2 sin^2(ae)
  blend weight s = 1 / (1 + exp(-M (|ae| - alpha_stall)))

alpha0 = -2 * camber (thin-airfoil, parabolic camber). Cm_c/4 = -pi * camber.

LIMITATIONS (documented in docs/engineering/AERO_MODEL.md): no wake memory
(Wagner/Theodorsen lift deficiency), no leading-edge-vortex lift enhancement,
no spanwise flow, membrane camber does not reverse on the upstroke, 3-D effects
only through the Helmbold slope and induced-drag factor of each wing.
"""
from __future__ import annotations

import math

import numpy as np

BLEND_SHARPNESS = 30.0  # 1/rad


def coefficients(alpha: np.ndarray, a3d: float, k_ind: float, cd0: float, alpha0: float, stall: float):
    ae = alpha - alpha0
    s = 1.0 / (1.0 + np.exp(-BLEND_SHARPNESS * (np.abs(ae) - stall)))
    cl_att = a3d * ae
    cd_att = cd0 + k_ind * cl_att * cl_att
    sa = np.sin(ae)
    ca = np.cos(ae)
    cl_fp = 2.0 * sa * ca
    cd_fp = cd0 + 2.0 * sa * sa
    cl = (1 - s) * cl_att + s * cl_fp
    cd = (1 - s) * cd_att + s * cd_fp
    return cl, cd, s


def alpha_zero_lift(camber: float) -> float:
    return -2.0 * camber


def cm_quarter_chord(camber: float) -> float:
    return -math.pi * camber
