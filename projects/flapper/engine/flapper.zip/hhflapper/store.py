"""Versioned configuration and experiment storage (JSON files, append-only).

Configuration revisions are immutable: saving creates revision N+1.
Experiment results are immutable: a record can gain annotations (conclusions,
limitations) whose history is kept, but its configuration, model version,
conditions and results are never rewritten - not even when the model changes.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import pathlib
import re
import threading

from .config import AircraftConfig
from .version import model_version

ROOT = pathlib.Path(os.environ.get("HHFLAPPER_DATA", pathlib.Path(__file__).resolve().parents[2] / "data"))
_LOCK = threading.Lock()


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def _safe(s: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_\-]{1,64}", s):
        raise ValueError("ids may contain letters, digits, '-' and '_' only")
    return s


def _write_new(path: pathlib.Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "x", encoding="utf-8") as fh:  # 'x' refuses to overwrite
        json.dump(data, fh, indent=1, default=float)


# ---------------------------------------------------------------- configs
def config_dir() -> pathlib.Path:
    return ROOT / "configs"


def list_configs() -> list[dict]:
    out = []
    d = config_dir()
    if not d.exists():
        return out
    for cdir in sorted(d.iterdir()):
        revs = sorted(cdir.glob("rev-*.json"), key=lambda p: int(p.stem.split("-")[1]))
        if not revs:
            continue
        latest = json.loads(revs[-1].read_text(encoding="utf-8"))
        out.append({"config_id": cdir.name, "latest_revision": latest["revision"], "name": latest["name"],
                    "author": latest["author"], "created": latest["created"], "revisions": len(revs),
                    "validation_status": latest["validation_status"]})
    return out


def get_config(config_id: str, revision: int | None = None) -> AircraftConfig:
    cdir = config_dir() / _safe(config_id)
    revs = sorted(cdir.glob("rev-*.json"), key=lambda p: int(p.stem.split("-")[1]))
    if not revs:
        raise KeyError(config_id)
    path = cdir / f"rev-{revision}.json" if revision else revs[-1]
    if not path.exists():
        raise KeyError(f"{config_id} rev {revision}")
    return AircraftConfig.model_validate_json(path.read_text(encoding="utf-8"))


def save_config(cfg: AircraftConfig) -> AircraftConfig:
    with _LOCK:
        cdir = config_dir() / _safe(cfg.config_id)
        revs = sorted(cdir.glob("rev-*.json"), key=lambda p: int(p.stem.split("-")[1])) if cdir.exists() else []
        nxt = int(revs[-1].stem.split("-")[1]) + 1 if revs else 1
        data = cfg.model_dump()
        data["revision"] = nxt
        data["created"] = _now()
        _write_new(cdir / f"rev-{nxt}.json", data)
        return AircraftConfig.model_validate(data)


def ensure_baseline() -> None:
    if not (config_dir() / "HF1-BASELINE").exists():
        save_config(AircraftConfig())


# ------------------------------------------------------------ experiments
def exp_dir() -> pathlib.Path:
    return ROOT / "experiments"


def new_experiment_id() -> str:
    day = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d")
    existing = list(exp_dir().glob(f"EXP-{day}-*.json")) if exp_dir().exists() else []
    return f"EXP-{day}-{len(existing) + 1:04d}"


def save_experiment(meta: dict, config: AircraftConfig, conditions: dict, results: dict) -> dict:
    with _LOCK:
        eid = new_experiment_id()
        rec = {
            "id": eid,
            "created": _now(),
            "objective": meta.get("objective", ""),
            "hypothesis": meta.get("hypothesis", ""),
            "kind": meta.get("kind", ""),
            "author": meta.get("author", "unspecified"),
            "model_version": model_version(),
            "config_ref": {"config_id": config.config_id, "revision": config.revision},
            "config": config.model_dump(),
            "conditions": conditions,
            "results": results,
            "data_label": "SIMULATED",
            "annotations": [],
            "limitations": meta.get("limitations", [
                "Quasi-steady aerodynamics without wake memory",
                "Reduced-order (2-mode) wing structure",
                "No physical validation data exists for this configuration",
            ]),
        }
        _write_new(exp_dir() / f"{eid}.json", rec)
        return rec


def list_experiments() -> list[dict]:
    if not exp_dir().exists():
        return []
    out = []
    for p in sorted(exp_dir().glob("EXP-*.json"), reverse=True):
        r = json.loads(p.read_text(encoding="utf-8"))
        out.append({k: r[k] for k in ("id", "created", "objective", "hypothesis", "kind", "config_ref")} |
                   {"source_sha256": r["model_version"]["source_sha256"][:12],
                    "conclusion": (r["annotations"][-1]["conclusions"] if r["annotations"] else "")})
    return out


def get_experiment(eid: str) -> dict:
    p = exp_dir() / f"{_safe(eid)}.json"
    if not p.exists():
        raise KeyError(eid)
    return json.loads(p.read_text(encoding="utf-8"))


def annotate_experiment(eid: str, conclusions: str, limitations: str = "", author: str = "unspecified") -> dict:
    """Append an annotation. Results are not touched; the previous annotations remain."""
    with _LOCK:
        p = exp_dir() / f"{_safe(eid)}.json"
        rec = json.loads(p.read_text(encoding="utf-8"))
        rec["annotations"].append({"at": _now(), "author": author, "conclusions": conclusions, "limitations": limitations})
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(rec, indent=1, default=float), encoding="utf-8")
        tmp.replace(p)
        return rec
