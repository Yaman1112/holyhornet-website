"""Cycle-averaged analysis: captive (wind-tunnel) wingbeat cycles, trim,
linearisation and stability, control effectiveness.

Averaging assumption: the wingbeat is much faster than the rigid-body modes, so
the body sees the cycle-mean forces. `averaging_validity` reports the ratio of
wingbeat frequency to the fastest body mode; below ~3 the averaged stability
results should not be trusted (use the time-domain 6-DOF simulation instead).
"""
from __future__ import annotations

import math

import numpy as np
from scipy.optimize import least_squares

from .config import AircraftConfig, clone
from .environment import Environment
from .frames import euler_to_quat
from .model import NX, Model

BODY = slice(0, 13)


def analysis_model(cfg: AircraftConfig, env: Environment | None = None) -> Model:
    """Model used for cycle analysis. A motor-driven crank is replaced by a speed-controlled
    crank with the same linkage shape, so the cycle is exactly periodic."""
    c = clone(cfg)
    if c.kinematics.drive == "motor_crank":
        c.kinematics.drive = "prescribed"
        c.kinematics.profile = "mechanism"
    return Model(c, env)


def body_state(model: Model, V: float, alpha: float, beta: float = 0.0, gamma: float = 0.0,
               rates=(0.0, 0.0, 0.0), roll: float = 0.0, altitude: float = 40.0) -> np.ndarray:
    x = np.zeros(model.nx)
    x[2] = -altitude
    x[3] = V * math.cos(alpha) * math.cos(beta)
    x[4] = V * math.sin(beta)
    x[5] = V * math.sin(alpha) * math.cos(beta)
    x[6:10] = euler_to_quat(roll, alpha + gamma, 0.0)
    x[10:13] = rates
    return x


def captive_cycle(model: Model, x_body: np.ndarray, u: np.ndarray, n: int = 64, record: bool = False,
                  settle_cycles: int | None = None, struct0: np.ndarray | None = None) -> dict:
    """Hold the airframe fixed (body states frozen) and run whole wingbeat cycles.

    Equivalent to a wind-tunnel test on a balance. Structural states are integrated so the
    flexible wing reaches its periodic response before the recorded cycle.
    """
    f = float(np.mean(u[0:2]))
    x = x_body.copy()
    k = model.cfg.kinematics
    x[13] = math.radians(k.left.phase_deg)
    x[14] = math.radians(k.right.phase_deg)
    x[15:17] = 2 * math.pi * u[0:2]
    if struct0 is not None:
        x[model.dyn_idx] = struct0
    if f <= 1e-6:
        dx, d = model.evaluate(0.0, x, u, full=True)
        return _summarise([dx], [d], [0.0], model, u, record)
    T = 1.0 / f
    structural = model.cfg.structure.enabled or model.unsteady  # has internal dynamic states
    if settle_cycles is None:
        settle_cycles = ((1 if struct0 is not None else 2) + (2 if model.unsteady else 0)) if structural else 0
    sub = 1
    if structural:
        # keep omega_max * h <= 0.8 for RK4 on the structural modes
        w_max = float(np.sqrt(np.max(np.concatenate([model.k_beta / model.J_beta, model.k_psi / model.J_psi]))))
        if model.unsteady:
            V0 = float(np.linalg.norm(x_body[3:6])) + 2 * math.pi * f * 0.6 * model.wing_info[1].semi_span
            w_max = max(w_max, model.cfg.aerodynamics.wagner_b2 * 2 * V0 / float(model.s_c.min()))
        sub = max(1, math.ceil((T / n) * w_max / 0.8))
    h = T / (n * sub)

    def rhs(t, xx):
        d = model.evaluate(t, xx, u)
        d[BODY] = 0.0
        d[25:28] = 0.0
        return d

    def step(t, x):
        k1 = rhs(t, x)
        k2 = rhs(t + h / 2, x + h / 2 * k1)
        k3 = rhs(t + h / 2, x + h / 2 * k2)
        k4 = rhs(t + h, x + h * k3)
        return x + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

    t = 0.0
    if structural:
        for _ in range(settle_cycles * n * sub):
            x = step(t, x)
            t += h
    dxs, ds, ts = [], [], []
    for i in range(n):
        dx, d = model.evaluate(t, x, u, full=True)
        if not np.all(np.isfinite(dx)):
            raise FloatingPointError("captive cycle diverged (non-finite state)")
        dxs.append(dx)
        ds.append(d)
        ts.append(t)
        if structural:
            for _ in range(sub):
                x = step(t, x)
                t += h
        else:
            x = x.copy()
            x[13:15] += 2 * math.pi * u[0:2] * h
            t += h
    out = _summarise(dxs, ds, ts, model, u, record)
    out["struct_end"] = x[model.dyn_idx].copy()
    return out


def _summarise(dxs, ds, ts, model: Model, u, record: bool) -> dict:
    DX = np.array(dxs)
    mean_dx = DX.mean(axis=0)
    g = lambda key: np.array([d[key] for d in ds])  # noqa: E731
    pm = np.array([d["p_mech"] for d in ds])
    lift = g("lift_total")
    thrust = g("thrust_total")
    wl = g("wing_lift")
    wt = g("wing_thrust")
    p_mech_total = pm.sum(axis=1)
    p_pos = np.maximum(pm, 0).sum(axis=1)
    V = ds[0]["airspeed"]
    out = {
        "mean_body_accel": mean_dx[3:6].tolist(),
        "mean_ang_accel": mean_dx[10:13].tolist(),
        "mean_lift": float(lift.mean()),
        "mean_thrust": float(thrust.mean()),
        "mean_wing_lift": float(wl.mean()),
        "mean_wing_thrust": float(wt.mean()),
        "mean_profile_induced_drag": float(np.mean([d["left"]["profile_induced_drag"] + d["right"]["profile_induced_drag"] for d in ds])),
        "mean_p_mech": float(p_mech_total.mean()),
        "mean_p_mech_positive": float(p_pos.mean()),
        "mean_p_aero": float(np.mean(g("p_aero_wings"))),
        "mean_p_elec_total": float(np.mean(g("p_total"))),
        "mean_motor_current": float(np.mean(g("motor_current"))),
        "peak_hinge_torque": float(np.abs(np.array([d["hinge_torque"] for d in ds])).max()),
        "rms_crank_torque": float(np.sqrt(np.mean(g("crank_torque") ** 2))),
        "peak_crank_torque": float(np.abs(g("crank_torque")).max()),
        "max_tip_deflection": float(np.abs(np.array([d["tip_deflection"] for d in ds])).max()),
        "max_tip_twist_deg": float(np.degrees(np.abs(np.array([d["tip_twist"] for d in ds])).max())),
        "max_stall_fraction": float(max(max(d["left"]["stall_fraction"], d["right"]["stall_fraction"]) for d in ds)),
        "airspeed": V,
        "frequency_hz": float(np.mean(u[0:2])),
        "weight": model.mass * 9.80665,
    }
    pw = out["mean_p_mech"]
    out["propulsive_efficiency"] = (out["mean_wing_thrust"] * V / pw) if pw > 1e-6 and out["mean_wing_thrust"] > 0 else None
    out["equivalent_lift_to_drag"] = (out["mean_wing_lift"] * V / pw) if pw > 1e-6 else None
    dsum = out["mean_profile_induced_drag"]
    out["lift_to_drag"] = out["mean_wing_lift"] / dsum if dsum > 1e-9 else None
    if record:
        phi = np.array([d["phi"] for d in ds])
        out["series"] = {
            "t": (np.array(ts) - ts[0]).tolist(),
            "phase_deg": (np.array(ts) - ts[0]) * out["frequency_hz"] * 360,
            "phi_left_deg": np.degrees(phi[:, 0]).tolist(),
            "phi_right_deg": np.degrees(phi[:, 1]).tolist(),
            "phid_left": np.array([d["phid"][0] for d in ds]).tolist(),
            "phid_right": np.array([d["phid"][1] for d in ds]).tolist(),
            "lift": lift.tolist(),
            "thrust": thrust.tolist(),
            "wing_lift": wl.tolist(),
            "wing_thrust": wt.tolist(),
            "drag": [d["left"]["profile_induced_drag"] + d["right"]["profile_induced_drag"] for d in ds],
            "lift_left": [d["left"]["lift"] for d in ds],
            "lift_right": [d["right"]["lift"] for d in ds],
            "p_mech": p_mech_total.tolist(),
            "p_aero": g("p_aero_wings").tolist(),
            "hinge_torque_left": [float(d["hinge_torque"][0]) for d in ds],
            "hinge_torque_right": [float(d["hinge_torque"][1]) for d in ds],
            "crank_torque": g("crank_torque").tolist(),
            "tip_deflection_mm": [float(d["tip_deflection"][1] * 1000) for d in ds],
            "tip_twist_deg": [float(math.degrees(d["tip_twist"][1])) for d in ds],
            "twist_total_left_deg": [float(math.degrees(d["tip_twist"][0] + d["driven_twist"][0])) for d in ds],
            "twist_total_right_deg": [float(math.degrees(d["tip_twist"][1] + d["driven_twist"][1])) for d in ds],
            "tip_deflection_left_mm": [float(d["tip_deflection"][0] * 1000) for d in ds],
            "p_twist": [float(np.sum(d["p_twist"])) for d in ds],
            "twist_torque_right": [float(d["twist_drive_torque"][1]) for d in ds],
            "twist_drive_right_deg": [float(math.degrees(d["driven_twist"][1])) for d in ds],
            "alpha75_right_deg": [d["right"]["alpha_75_deg"] for d in ds],
            "pitch_moment": [float(dx[11] * model.I[1, 1]) for dx in dxs],
        }
        out["series"]["phase_deg"] = out["series"]["phase_deg"].tolist()
    return out


# ------------------------------------------------------------------------ trim
def trim(cfg: AircraftConfig, V: float, gamma: float = 0.0, model: Model | None = None, n: int = 40,
         guess=None) -> dict:
    """Steady wings-level trim at airspeed V and flight-path angle gamma.

    Unknowns: angle of attack, wingbeat frequency (both wings), elevator.
    Residuals: cycle-mean body accelerations ax, az and pitch acceleration.

    Solved on the full aeroelastic cycle (flexible wings when enabled). Structural states are
    warm-started from the previous residual evaluation so each evaluation settles in one cycle.
    A rigid-wing pre-solve is NOT used: without twist the outer wing stalls and the rigid
    problem has a different (often non-existent) solution.
    """
    m = model or analysis_model(cfg)
    u0 = m.default_controls()
    c_ref = m.wing_info[1].mac
    scale_q = m.I[1, 1] / (m.mass * c_ref)
    warm = {"xs": None}

    def make_resid(mod, use_warm):
        def resid(z):
            a, f, de = z
            u = u0.copy()
            u[0:2] = f
            u[6] = de
            xb = body_state(mod, V, a, gamma=gamma)
            cyc = captive_cycle(mod, xb, u, n=n, struct0=warm["xs"] if use_warm else None)
            if use_warm:
                warm["xs"] = cyc["struct_end"]
            ax, _, az = cyc["mean_body_accel"]
            return np.array([ax, az, cyc["mean_ang_accel"][1] * scale_q])
        return resid

    r_main = make_resid(m, True)
    lo = np.array([math.radians(-6), 1.0, math.radians(-cfg.tail.elevator_max_deg)])
    hi = np.array([math.radians(25), 15.0, math.radians(cfg.tail.elevator_max_deg)])
    starts = [guess] if guess is not None else []
    def qs_seed():
        # seed from the (much cheaper) quasi-steady trim: unsteady trim differs by ~10% in frequency
        qc = clone(m.cfg)
        qc.aerodynamics.unsteady = False
        q = trim(qc, V, gamma, model=Model(qc, m.env), n=n)
        if q["converged"]:
            return [math.radians(q["alpha_deg"]), q["frequency_hz"] * 1.08, math.radians(q["elevator_deg"])]
        return None

    # the quasi-steady seed is evaluated lazily, after a supplied guess (e.g. the previous sweep point) fails
    if m.unsteady:
        starts.append("qs")
    starts += [[math.radians(4), cfg.kinematics.right.frequency_hz, 0.0], [math.radians(8), 5.0, math.radians(-5)],
               [math.radians(1), 3.0, math.radians(3)]]
    best = None
    for z0 in starts:
        if isinstance(z0, str):
            z0 = qs_seed()
            if z0 is None:
                continue
        z0 = np.clip(z0, lo + 1e-6, hi - 1e-6)
        sol = least_squares(r_main, z0, bounds=(lo, hi), x_scale=[0.05, 1.0, 0.05], diff_step=1e-3,
                            xtol=1e-7, ftol=1e-9, max_nfev=40)
        if best is None or sol.cost < best.cost:
            best = sol
        if math.sqrt(2 * sol.cost) < 1e-4:
            break
    z = best.x
    fun = best.fun
    stage = "flexible" if cfg.structure.enabled else "rigid"
    a, f, de = z
    u = u0.copy()
    u[0:2] = f
    u[6] = de
    xb = body_state(m, V, a, gamma=gamma)
    cyc = captive_cycle(m, xb, u, n=n, record=True, struct0=warm["xs"])
    res_norm = float(np.linalg.norm(fun))
    at_bound = [name for name, v, l, h in zip(("alpha", "frequency", "elevator"), z, lo, hi)
                if abs(v - l) < 1e-4 * max(1, abs(l)) or abs(v - h) < 1e-4 * max(1, abs(h))]
    ok = res_norm < 0.02 and not at_bound
    return {
        "airspeed": V,
        "gamma_deg": math.degrees(gamma),
        "converged": bool(ok),
        "solver_stage": stage,
        "residual_norm": res_norm,
        "at_bounds": at_bound,
        "alpha_deg": math.degrees(a),
        "pitch_deg": math.degrees(a + gamma),
        "frequency_hz": float(f),
        "elevator_deg": math.degrees(de),
        "controls": u.tolist(),
        "state": xb.tolist(),
        "struct_state": (warm["xs"].tolist() if warm["xs"] is not None else None),
        "cycle": {k: v for k, v in cyc.items() if k != "struct_end"},
        "power_mech_w": cyc["mean_p_mech"],
        "power_elec_w": cyc["mean_p_elec_total"],
        "reduced_frequency": math.pi * f * m.wing_info[1].mac / V,
    }


def trim_sweep(cfg: AircraftConfig, speeds, gamma: float = 0.0) -> list[dict]:
    m = analysis_model(cfg)
    out = []
    guess = None
    for V in speeds:
        r = trim(cfg, float(V), gamma, model=m, guess=guess)
        if r["converged"]:
            guess = [math.radians(r["alpha_deg"]), r["frequency_hz"], math.radians(r["elevator_deg"])]
        r.pop("cycle")
        out.append(r)
    return out


# ------------------------------------------------------------- linearisation
LIN_STATES = ["u", "v", "w", "p", "q", "r", "roll", "pitch"]
STEPS = [0.1, 0.1, 0.1, 0.03, 0.03, 0.03, 0.01, 0.01]


def _avg_rhs(m: Model, z: np.ndarray, u: np.ndarray, n: int) -> np.ndarray:
    uu, vv, ww, p, q, r, ph, th = z
    x = np.zeros(m.nx)
    x[2] = -40.0
    x[3:6] = [uu, vv, ww]
    x[6:10] = euler_to_quat(ph, th, 0.0)
    x[10:13] = [p, q, r]
    cyc = captive_cycle(m, x, u, n=n)
    a = cyc["mean_body_accel"]
    al = cyc["mean_ang_accel"]
    phd = p + (q * math.sin(ph) + r * math.cos(ph)) * math.tan(th)
    thd = q * math.cos(ph) - r * math.sin(ph)
    return np.array([a[0], a[1], a[2], al[0], al[1], al[2], phd, thd])


def control_inputs(cfg: AircraftConfig) -> list[tuple[str, int, float]]:
    """(name, index into u, perturbation) of the effectors that exist on this airframe."""
    a = cfg.actuators
    out = [("frequency", -1, 0.1)]
    if a.elevator:
        out.append(("elevator", 6, math.radians(2)))
    if a.rudder:
        out.append(("rudder", 7, math.radians(2)))
    if a.differential_amplitude:
        out.append(("diff_amplitude", -2, math.radians(2)))
    if a.differential_frequency:
        out.append(("diff_frequency", -3, 0.1))
    if a.differential_mean:
        out.append(("diff_mean", -4, math.radians(2)))
    if a.differential_twist:
        out.append(("diff_twist", -5, math.radians(2)))
    return out


def _apply_input(u: np.ndarray, idx: int, d: float) -> np.ndarray:
    u = np.concatenate([u, np.zeros(max(0, 10 - len(u)))])
    if idx == -1:
        u[0:2] += d
    elif idx == -2:
        u[2] -= d / 2
        u[3] += d / 2
    elif idx == -3:
        u[0] -= d / 2
        u[1] += d / 2
    elif idx == -4:
        u[4] -= d / 2
        u[5] += d / 2
    elif idx == -5:
        u[9] += d
    else:
        u[idx] += d
    return u


def linearise(cfg: AircraftConfig, V: float, trim_result: dict | None = None, n: int = 48) -> dict:
    m = analysis_model(cfg)
    tr = trim_result or trim(cfg, V, model=m, n=n)
    a = math.radians(tr["alpha_deg"])
    z0 = np.array([V * math.cos(a), 0.0, V * math.sin(a), 0, 0, 0, 0.0, math.radians(tr["pitch_deg"])])
    u0 = np.array(tr["controls"])
    A = np.zeros((8, 8))
    for j, hstep in enumerate(STEPS):
        dz = np.zeros(8)
        dz[j] = hstep
        A[:, j] = (_avg_rhs(m, z0 + dz, u0, n) - _avg_rhs(m, z0 - dz, u0, n)) / (2 * hstep)
    inputs = control_inputs(cfg)
    B = np.zeros((8, len(inputs)))
    for j, (_, idx, d) in enumerate(inputs):
        B[:, j] = (_avg_rhs(m, z0, _apply_input(u0, idx, d), n) - _avg_rhs(m, z0, _apply_input(u0, idx, -d), n)) / (2 * d)
    return {"trim": {k: v for k, v in tr.items() if k != "cycle"}, "A": A, "B": B,
            "states": LIN_STATES, "inputs": [i[0] for i in inputs], "model": m}


def _classify(vec: np.ndarray, lam: complex) -> str:
    mag = np.abs(vec)
    mag = mag / (mag.max() + 1e-12)
    lon = mag[[0, 2, 4, 7]].sum()
    lat = mag[[1, 3, 5, 6]].sum()
    osc = abs(lam.imag) > 1e-6
    if lon >= lat:
        if osc:
            return "short period" if mag[4] + mag[2] > mag[0] + mag[7] else "phugoid"
        return "longitudinal real mode"
    if osc:
        return "dutch roll"
    return "roll subsidence" if mag[3] > 0.5 and abs(lam.real) > 1.0 else "spiral"


def stability(cfg: AircraftConfig, V: float, trim_result: dict | None = None) -> dict:
    lin = linearise(cfg, V, trim_result)
    A, B = lin["A"], lin["B"]
    lam, vec = np.linalg.eig(A)
    modes = []
    seen = set()
    for i, l in enumerate(lam):
        key = (round(l.real, 6), round(abs(l.imag), 6))
        if key in seen:
            continue
        seen.add(key)
        wn = abs(l)
        zeta = -l.real / wn if wn > 1e-9 else None
        name = _classify(vec[:, i], l)
        if abs(l) < 1e-3:
            name = "neutral (heading/altitude-like)"
        modes.append({
            "name": name,
            "real": float(l.real),
            "imag": float(abs(l.imag)),
            "wn_rad_s": float(wn),
            "zeta": float(zeta) if zeta is not None else None,
            "stable": bool(l.real < 0),
            "time_to_half_or_double_s": float(math.log(2) / abs(l.real)) if abs(l.real) > 1e-9 else None,
            "dominant_states": [LIN_STATES[k] for k in np.argsort(-np.abs(vec[:, i]))[:3]],
        })
    n = A.shape[0]
    # PBH test: (A, B) is controllable iff rank [A - lambda I, B] = n for every eigenvalue.
    # (The Kalman matrix [B AB ... A^(n-1)B] is numerically useless here: the fast roll mode
    # makes A^7 B dominate and swamps the rank tolerance.)
    uncontrollable = []
    for l in lam:
        M = np.hstack([A - l * np.eye(n), B]) if B.size else A - l * np.eye(n)
        s = np.linalg.svd(M, compute_uv=False)
        if s[-1] < 1e-6 * max(1.0, s[0]):
            uncontrollable.append(complex(l))
    rank = n - len({(round(z.real, 6), round(abs(z.imag), 6)) for z in uncontrollable})
    f_wb = lin["trim"]["frequency_hz"]
    fastest = max((m["wn_rad_s"] for m in modes), default=0) / (2 * math.pi)
    ratio = f_wb / fastest if fastest > 1e-9 else math.inf
    m = lin["model"]
    eff = []
    for j, name in enumerate(lin["inputs"]):
        col = B[:, j]
        eff.append({
            "input": name,
            "d_ax": float(col[0]), "d_ay": float(col[1]), "d_az": float(col[2]),
            "d_roll_moment": float(col[3] * m.I[0, 0]), "d_pitch_moment": float(col[4] * m.I[1, 1]),
            "d_yaw_moment": float(col[5] * m.I[2, 2]),
        })
    axes = {
        "roll": any(abs(e["d_roll_moment"]) > 1e-4 for e in eff),
        "pitch": any(abs(e["d_pitch_moment"]) > 1e-4 for e in eff),
        "yaw": any(abs(e["d_yaw_moment"]) > 1e-4 for e in eff),
        "axial": any(abs(e["d_ax"]) > 1e-3 for e in eff),
    }
    warnings = []
    if ratio < 3:
        warnings.append(f"wingbeat/body-mode frequency ratio {ratio:.1f} < 3: averaged linear model unreliable")
    if not lin["trim"]["converged"]:
        warnings.append("trim did not converge; linearisation is about a non-equilibrium point")
    if rank < n:
        warnings.append(f"controllability matrix rank {rank} < {n}: some states cannot be steered by the available effectors")
    if len(lin["inputs"]) < 4:
        warnings.append(f"{len(lin['inputs'])} independent effectors for 6 rigid-body DOF: the aircraft is under-actuated; "
                        "roll is reached only through yaw-roll coupling (dihedral effect) unless a differential wing input exists")
    return {
        "trim": lin["trim"],
        "A": A.tolist(),
        "B": B.tolist(),
        "states": LIN_STATES,
        "inputs": lin["inputs"],
        "modes": modes,
        "controllability_rank": rank,
        "n_states": n,
        "control_effectiveness": eff,
        "axes_with_direct_authority": axes,
        "wingbeat_to_fastest_mode_ratio": ratio,
        "warnings": warnings,
        "assumption": "cycle-averaged dynamics; valid when wingbeat frequency >> body-mode frequencies",
    }
