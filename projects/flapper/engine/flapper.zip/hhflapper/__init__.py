"""HolyHornet Flapper - bio-inspired flapping-wing UAV engineering model.

Simulation only. Nothing in this package talks to hardware.
"""
import os as _os

# Small matrices: multi-threaded BLAS only adds overhead and makes parallel runs slow.
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    _os.environ.setdefault(_v, "1")

from .version import __version__, model_version  # noqa: E402

__all__ = ["__version__", "model_version"]
