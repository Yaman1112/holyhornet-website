"""Browser edition bridge: the unmodified FastAPI application inside Pyodide (CPython on WebAssembly).

The web worker calls ``boot()`` once, then ``request(method, path, headers_json, body)`` for every HTTP call and
``ws_open / ws_send / ws_close`` for the digital-twin live link. Requests go through the full ASGI stack
(validation, models, file store) exactly as on a server; only the transport differs (postMessage instead of TCP).
Differences from the local server:

* Pyodide has no threads. Background jobs start right after the POST returns and run inside the worker; their
  progress is pushed to the page with ``postMessage``. While one runs, other requests wait.
* The live WebSocket is emulated over postMessage; the simulation advances inside the worker.
* Trims of the shipped baseline configuration and the two slowest analyses at their default inputs (feasibility
  envelope sweep, stability at 10-14 m/s) were computed natively with the same code at build time and are loaded
  from ``precomputed.json``. Anything else is computed live, in the browser (slower than the native engine).
* The data store lives in the worker's memory: saved configurations and experiments last until the page reloads.
"""
from __future__ import annotations

import asyncio
import json
import os

_app = None
_main = None
_pre_jobs: dict = {}
_ws: dict = {}


def _post(msg: dict):
    try:
        import js  # Pyodide: the worker's global scope

        js.postMessage(js.JSON.parse(json.dumps(msg)))
    except Exception:  # not in a browser (tests)
        pass


# ------------------------------------------------------------ trim cache
def encode(o):
    """JSON-safe encoding that round-trips numpy arrays (pickles are not portable across numpy versions)."""
    import numpy as np

    if isinstance(o, np.ndarray):
        return {"__nd__": o.tolist(), "dtype": str(o.dtype)}
    if isinstance(o, dict):
        return {"__dict__": [[encode(k), encode(v)] for k, v in o.items()]} if any(not isinstance(k, str) for k in o) else \
            {k: encode(v) for k, v in o.items()}
    if isinstance(o, tuple):
        return {"__tuple__": [encode(v) for v in o]}
    if isinstance(o, list):
        return [encode(v) for v in o]
    if isinstance(o, np.generic):
        return o.item()
    return o


def decode(o):
    import numpy as np

    if isinstance(o, dict):
        if "__nd__" in o:
            return np.array(o["__nd__"], dtype=o["dtype"])
        if "__tuple__" in o:
            return tuple(decode(v) for v in o["__tuple__"])
        if "__dict__" in o:
            return {decode(k): decode(v) for k, v in o["__dict__"]}
        return {k: decode(v) for k, v in o.items()}
    if isinstance(o, list):
        return [decode(v) for v in o]
    return o


def export_trim_cache() -> list:
    from . import simulator

    return [[list(k), encode(v)] for k, v in simulator._TRIM_CACHE.items()]


def import_trim_cache(rows: list) -> int:
    from . import simulator

    for k, v in rows:
        simulator._TRIM_CACHE[(k[0], k[1])] = decode(v)
    return len(rows)


# ------------------------------------------------------------ jobs
class _DeferredPool:
    """Replaces the ThreadPoolExecutor: run the job on the event loop after the HTTP response is sent."""

    def submit(self, fn, *args):
        asyncio.get_event_loop().call_later(0.05, lambda: fn(*args))


def _install_progress_push():
    """Wrap api.submit so job progress is pushed to the page (the page cannot poll while a job blocks the worker)."""
    main = _main
    orig = main.submit

    def submit(kind, fn, *args):
        holder = {}

        def wrapped(progress, *a):
            jid = holder["id"]
            last = [-1.0]

            def prog(p):
                progress(p)
                if p - last[0] >= 0.01 or p >= 1.0:
                    last[0] = p
                    _post({"type": "progress", "job": jid, "p": round(float(p), 3)})

            try:
                return fn(prog, *a)
            finally:  # always clear the page's busy state, also on error
                _post({"type": "progress", "job": jid, "p": 1.0})

        out = orig(kind, wrapped, *args)
        holder["id"] = out["job_id"]
        return out

    main.submit = submit


def _canon(raw: bytes) -> str:
    try:
        return json.dumps(json.loads(raw or b"{}"), sort_keys=True, separators=(",", ":"))
    except Exception:
        return ""


def _precomputed_job(p: str, raw: bytes):
    hit = _pre_jobs.get(p, {}).get(_canon(raw))
    if hit is None:
        return None
    import time
    import uuid

    jid = uuid.uuid4().hex[:12]
    _main.JOBS[jid] = {"id": jid, "kind": p.rsplit("/", 1)[-1], "status": "done", "progress": 1.0, "started": time.time(),
                       "result": hit, "error": None, "elapsed_s": 0.0,
                       "note": "precomputed at build time with the same code (browser edition)"}
    return {"status": 200, "headers": {"content-type": "application/json"}, "body": json.dumps({"job_id": jid}).encode()}


# ------------------------------------------------------------ boot
def boot(data_dir: str, docs_dir: str, precomputed_path: str = "") -> dict:
    global _app, _main, _pre_jobs
    import time

    t = time.time()
    os.environ["HHFLAPPER_DATA"] = data_dir
    os.environ["HHFLAPPER_BROWSER"] = "1"
    import anyio.to_thread

    async def _inline(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):
        return func(*args)

    anyio.to_thread.run_sync = _inline

    async def _to_thread(func, *args, **kw):
        return func(*args, **kw)

    asyncio.to_thread = _to_thread
    import pathlib

    from . import store
    from .api import app as main

    _main = main
    main.POOL = _DeferredPool()
    main.DOCS = pathlib.Path(docs_dir)
    _install_progress_push()
    store.ensure_baseline()
    n_trim = 0
    if precomputed_path and os.path.exists(precomputed_path):
        with open(precomputed_path, encoding="utf-8") as f:
            pre = json.load(f)
        n_trim = import_trim_cache(pre.get("trims", []))
        _pre_jobs = pre.get("jobs", {})
    _app = main.app
    return {"ok": True, "boot_s": round(time.time() - t, 1), "trims": n_trim,
            "precomputed_jobs": sum(len(v) for v in _pre_jobs.values()),
            "configs": len(store.list_configs()), "experiments": len(store.list_experiments())}


# ------------------------------------------------------------ http
async def request(method: str, path: str, headers_json: str = "{}", body=None) -> dict:
    if _app is None:
        raise RuntimeError("call boot() first")
    headers = json.loads(headers_json or "{}")
    p, _, qs = path.partition("?")
    raw = bytes(body) if body is not None and type(body).__name__ != "JsNull" else b""
    if method.upper() == "POST":
        hit = _precomputed_job(p, raw)
        if hit is not None:
            return hit
    hdrs = [(k.lower().encode(), str(v).encode()) for k, v in headers.items()]
    hdrs.append((b"host", b"flapper.local"))
    if raw:
        hdrs.append((b"content-length", str(len(raw)).encode()))
    from urllib.parse import unquote

    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(), "scheme": "http",
             "path": unquote(p), "raw_path": p.encode(), "query_string": qs.encode(), "root_path": "", "headers": hdrs,
             "client": ("browser", 0), "server": ("flapper.local", 80)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": raw, "more_body": False}
        await asyncio.Event().wait()  # never: request bodies are sent in one piece

    out = {"status": 500, "headers": {}, "body": b""}
    chunks = []

    async def send(msg):
        if msg["type"] == "http.response.start":
            out["status"] = msg["status"]
            out["headers"] = {k.decode(): v.decode() for k, v in msg.get("headers", [])}
        elif msg["type"] == "http.response.body":
            chunks.append(msg.get("body", b""))

    await _app(scope, receive, send)
    out["body"] = b"".join(chunks)
    return out


# ------------------------------------------------------------ websocket (live twin)
def ws_open(sid: str, path: str = "/api/live"):
    """Run the app's WebSocket endpoint as a task; messages go to the page as {type:"ws", sid, ...}."""
    q: asyncio.Queue = asyncio.Queue()
    q.put_nowait({"type": "websocket.connect"})

    async def receive():
        return await q.get()

    async def send(msg):
        t = msg["type"]
        if t == "websocket.accept":
            _post({"type": "ws", "sid": sid, "event": "open"})
        elif t == "websocket.send":
            _post({"type": "ws", "sid": sid, "event": "message", "data": msg.get("text") or (msg.get("bytes") or b"").decode()})
        elif t == "websocket.close":
            _post({"type": "ws", "sid": sid, "event": "close"})

    scope = {"type": "websocket", "asgi": {"version": "3.0"}, "scheme": "ws", "path": path, "raw_path": path.encode(),
             "query_string": b"", "root_path": "", "headers": [(b"host", b"flapper.local")], "client": ("browser", 0),
             "server": ("flapper.local", 80), "subprotocols": []}

    async def run():
        try:
            await _app(scope, receive, send)
        finally:
            _ws.pop(sid, None)
            _post({"type": "ws", "sid": sid, "event": "close"})

    _ws[sid] = (q, asyncio.ensure_future(run()))


def ws_send(sid: str, text: str):
    if sid in _ws:
        _ws[sid][0].put_nowait({"type": "websocket.receive", "text": text})


def ws_close(sid: str):
    if sid in _ws:
        q, task = _ws.pop(sid)
        q.put_nowait({"type": "websocket.disconnect", "code": 1000})
        task.cancel()
