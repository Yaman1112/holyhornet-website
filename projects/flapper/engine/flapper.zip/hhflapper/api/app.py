"""HolyHornet Flapper API (FastAPI).

Simulation mode only. There is deliberately no endpoint that commands hardware:
bench and flight modes do not exist in this release (see docs/engineering/SAFETY.md).
"""
from __future__ import annotations

import asyncio
import csv
import io
import json
import math
import pathlib
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Optional

import numpy as np
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from .. import mechanism, store, twistlinkage
from ..analysis import stability, trim
from ..config import AircraftConfig, Fault, SimulationConfig, apply_overrides
from ..feasibility import feasibility, geometry_summary
from ..massprops import mass_properties
from ..research import PARAMS, cycle_study, sweep
from ..simulator import Simulation, cached_trim
from ..version import model_version

DOCS = pathlib.Path(__file__).resolve().parents[3] / "docs"
from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(_app):
    store.ensure_baseline()
    yield


app = FastAPI(title="HolyHornet Flapper API", version=model_version()["package"], lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
POOL = ThreadPoolExecutor(max_workers=3)
JOBS: dict[str, dict] = {}
OPERATING_MODE = "simulation"


def clean(o: Any) -> Any:
    """JSON-safe conversion (numpy, NaN -> None)."""
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.ndarray):
        return clean(o.tolist())
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return f if math.isfinite(f) else None
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o


class ConfigRef(BaseModel):
    config_id: Optional[str] = None
    revision: Optional[int] = None
    config: Optional[dict] = None  # unsaved draft from the design workspace
    overrides: dict = {}


def resolve(ref: ConfigRef | None) -> AircraftConfig:
    if ref is None:
        return store.get_config("HF1-BASELINE")
    if ref.config is not None:
        cfg = AircraftConfig.model_validate(ref.config)
    else:
        try:
            cfg = store.get_config(ref.config_id or "HF1-BASELINE", ref.revision)
        except KeyError:
            raise HTTPException(404, "configuration not found")
    if ref.overrides:
        try:
            cfg = apply_overrides(cfg, ref.overrides)
        except (ValueError, KeyError) as e:
            raise HTTPException(422, str(e))
    return cfg


# ------------------------------------------------------------------ meta
@app.get("/api/health")
def health():
    return {"ok": True, "mode": OPERATING_MODE, "hardware_interfaces": "none (simulation-only build)",
            "model_version": model_version()}


@app.get("/api/schema/aircraft")
def aircraft_schema():
    return AircraftConfig.model_json_schema()


@app.get("/api/schema/simulation")
def simulation_schema():
    return SimulationConfig.model_json_schema()


@app.get("/api/defaults")
def defaults():
    return {"aircraft": AircraftConfig().model_dump(), "simulation": SimulationConfig().model_dump(),
            "sweep_parameters": PARAMS, "fault_kinds": list(Fault.model_fields["kind"].annotation.__args__)}


# --------------------------------------------------------------- configs
@app.get("/api/configs")
def configs():
    return store.list_configs()


@app.get("/api/configs/{config_id}")
def config_get(config_id: str, revision: Optional[int] = None):
    try:
        return store.get_config(config_id, revision).model_dump()
    except (KeyError, ValueError):
        raise HTTPException(404, "configuration not found")


@app.post("/api/configs")
def config_save(body: dict):
    try:
        cfg = AircraftConfig.model_validate(body)
        return store.save_config(cfg).model_dump()
    except ValueError as e:
        raise HTTPException(422, str(e))


# ------------------------------------------------------ quick analyses
@app.post("/api/analysis/summary")
def summary(ref: ConfigRef):
    cfg = resolve(ref)
    mp = mass_properties(cfg)
    tw = twistlinkage.analyse(cfg, n=60)["summary"] if cfg.kinematics.twist_amplitude_deg > 0 else None
    return clean({"geometry": geometry_summary(cfg), "mass_budget": mp.table(), "cg": mp.cg, "inertia": mp.inertia,
                  "mechanism": mechanism.analyse(cfg, n=90)["summary"], "twist_linkage": tw, "config": cfg.model_dump()})


class CycleReq(BaseModel):
    ref: ConfigRef = ConfigRef()
    airspeed: float = 12.0
    alpha_deg: float = 2.0


@app.post("/api/analysis/cycle")
def cycle(req: CycleReq):
    cfg = resolve(req.ref)
    return clean(cycle_study(cfg, req.airspeed, req.alpha_deg))


class MechReq(BaseModel):
    ref: ConfigRef = ConfigRef()
    with_loads: bool = True
    airspeed: float = 12.0


@app.post("/api/analysis/mechanism")
def mech(req: MechReq):
    cfg = resolve(req.ref)
    loads = None
    if req.with_loads:
        tr = cached_trim(cfg, req.airspeed)
        s = tr["cycle"]["series"]
        loads = {"theta_deg": [p % 360 for p in s["phase_deg"]], "left": s["hinge_torque_left"],
                 "right": s["hinge_torque_right"]}
        if cfg.kinematics.right.phase_deg:
            loads["theta_deg"] = [(p + cfg.kinematics.right.phase_deg) % 360 for p in s["phase_deg"]]
    out = mechanism.analyse(cfg, n=180, hinge_torque=loads)
    out["load_case"] = f"trimmed level flight at {req.airspeed} m/s (simulated)" if loads else None
    if cfg.kinematics.twist_amplitude_deg > 0:
        tq = None
        if req.with_loads:
            s = tr["cycle"]["series"]
            tq = {"theta_deg": loads["theta_deg"], "torque": s["twist_torque_right"]}
        tw = twistlinkage.analyse(cfg, n=180, twist_torque=tq)
        if tq:
            tw["tube"] = twistlinkage.tube_check(cfg, tw["summary"]["peak_twist_torque_Nm"])
            tw["summary"]["tube_windup_deg"] = tw["tube"]["windup_deg_at_peak"]
            tw["summary"]["tube_shear_MPa"] = tw["tube"]["shear_stress_MPa"]
        out["twist"] = tw
    return clean(out)


class TrimReq(BaseModel):
    ref: ConfigRef = ConfigRef()
    airspeed: float = 12.0
    gamma_deg: float = 0.0


@app.post("/api/analysis/trim")
def trim_ep(req: TrimReq):
    cfg = resolve(req.ref)
    if req.gamma_deg == 0:
        return clean(cached_trim(cfg, req.airspeed))
    return clean(trim(cfg, req.airspeed, math.radians(req.gamma_deg)))


# ------------------------------------------------------------------ jobs
def submit(kind: str, fn, *args) -> dict:
    jid = uuid.uuid4().hex[:12]
    job = {"id": jid, "kind": kind, "status": "running", "progress": 0.0, "started": time.time(), "result": None,
           "error": None}
    JOBS[jid] = job

    def progress(p):
        job["progress"] = round(float(p), 3)

    def run():
        try:
            job["result"] = clean(fn(progress, *args))
            job["status"] = "done"
            job["progress"] = 1.0
        except Exception as e:  # report, never hide
            job["status"] = "error"
            job["error"] = f"{type(e).__name__}: {e}"
            job["trace"] = traceback.format_exc()[-2000:]
        job["elapsed_s"] = round(time.time() - job["started"], 2)

    POOL.submit(run)
    if len(JOBS) > 200:
        for k in list(JOBS)[:50]:
            JOBS.pop(k, None)
    return {"job_id": jid}


@app.get("/api/jobs/{jid}")
def job(jid: str):
    if jid not in JOBS:
        raise HTTPException(404, "unknown job")
    return JOBS[jid]


class SimReq(BaseModel):
    ref: ConfigRef = ConfigRef()
    simulation: dict = {}
    save: bool = False
    objective: str = ""
    hypothesis: str = ""


@app.post("/api/jobs/simulate")
def job_sim(req: SimReq):
    cfg = resolve(req.ref)
    sc = SimulationConfig.model_validate(req.simulation)

    def fn(progress):
        r = Simulation(cfg, sc).run(progress)
        if req.save:
            summary = {k: r[k] for k in ("assessment", "metrics", "warnings", "events", "integrator", "trim")}
            rec = store.save_experiment({"objective": req.objective or "flight simulation", "hypothesis": req.hypothesis,
                                         "kind": "simulation"}, cfg, sc.model_dump(), clean({**summary, "series": r["series"]}))
            r["experiment_id"] = rec["id"]
        return r

    return submit("simulate", fn)


class SweepReq(BaseModel):
    ref: ConfigRef = ConfigRef()
    param: str
    values: list[float]
    mode: str = "captive"
    airspeed: float = 12.0
    alpha_deg: float = 2.0
    param2: Optional[str] = None
    values2: Optional[list[float]] = None
    save: bool = False
    objective: str = ""
    hypothesis: str = ""


@app.post("/api/jobs/sweep")
def job_sweep(req: SweepReq):
    cfg = resolve(req.ref)
    if req.param not in PARAMS or (req.param2 and req.param2 not in PARAMS):
        raise HTTPException(422, "unknown sweep parameter")
    n = len(req.values) * (len(req.values2) if req.values2 else 1)
    if n > 60:
        raise HTTPException(422, "sweep limited to 60 points per job")

    def fn(progress):
        r = sweep(cfg, req.param, req.values, req.mode, req.airspeed, req.alpha_deg, req.param2, req.values2)
        if req.save:
            rec = store.save_experiment({"objective": req.objective or f"{req.mode} sweep of {req.param}",
                                         "hypothesis": req.hypothesis, "kind": f"sweep-{req.mode}"}, cfg,
                                        req.model_dump(exclude={"ref", "save"}), clean(r))
            r["experiment_id"] = rec["id"]
        return r

    return submit("sweep", fn)


class SpeedReq(BaseModel):
    ref: ConfigRef = ConfigRef()
    airspeed: float = 12.0
    speeds: Optional[list[float]] = None


@app.post("/api/jobs/stability")
def job_stab(req: SpeedReq):
    cfg = resolve(req.ref)
    return submit("stability", lambda progress: stability(cfg, req.airspeed, cached_trim(cfg, req.airspeed)))


@app.post("/api/jobs/feasibility")
def job_feas(req: SpeedReq):
    cfg = resolve(req.ref)
    return submit("feasibility", lambda progress: feasibility(cfg, req.speeds))


# ----------------------------------------------------------- experiments
@app.get("/api/experiments")
def experiments():
    return store.list_experiments()


@app.get("/api/experiments/{eid}")
def experiment(eid: str):
    try:
        return store.get_experiment(eid)
    except (KeyError, ValueError):
        raise HTTPException(404, "experiment not found")


class Annotation(BaseModel):
    conclusions: str
    limitations: str = ""
    author: str = "unspecified"


@app.post("/api/experiments/{eid}/annotate")
def annotate(eid: str, a: Annotation):
    try:
        return store.annotate_experiment(eid, a.conclusions, a.limitations, a.author)
    except (KeyError, ValueError, FileNotFoundError):
        raise HTTPException(404, "experiment not found")


@app.get("/api/experiments/{eid}/csv", response_class=PlainTextResponse)
def experiment_csv(eid: str):
    rec = experiment(eid)
    res = rec["results"]
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([f"# {rec['id']} | SIMULATED | model {rec['model_version']['package']} "
                f"src {rec['model_version']['source_sha256'][:12]} | config {rec['config_ref']}"])
    if "series" in res:
        keys = list(res["series"].keys())
        w.writerow(keys)
        for i in range(len(res["series"]["t"])):
            w.writerow([res["series"][k][i] for k in keys])
    elif "rows" in res:
        keys = sorted({k for r in res["rows"] for k in r if k != "point"})
        pk = list(res["rows"][0]["point"].keys())
        w.writerow(pk + keys)
        for r in res["rows"]:
            w.writerow([r["point"][k] for k in pk] + [r.get(k) for k in keys])
    return buf.getvalue()


# ------------------------------------------------------------ flight data
class CompareReq(BaseModel):
    experiment_id: str
    csv_text: str
    label: str = "imported flight log"


@app.post("/api/flightdata/compare")
def compare(req: CompareReq):
    """Compare a user-imported measured log against a stored simulation run.

    The CSV needs a 't' column (s) plus any of the simulation channel names.
    """
    rec = experiment(req.experiment_id)
    sim = rec["results"].get("series")
    if not sim:
        raise HTTPException(422, "experiment has no time series")
    rows = list(csv.DictReader(io.StringIO(req.csv_text)))
    if not rows or "t" not in rows[0]:
        raise HTTPException(422, "CSV must have a header row with a 't' column")
    meas = {k: np.array([float(r[k]) if r[k] not in ("", None) else np.nan for r in rows]) for k in rows[0]}
    ts = np.asarray(sim["t"])
    out = {}
    for k, v in meas.items():
        if k == "t" or k not in sim or isinstance(sim[k][0], str):
            continue
        pred = np.interp(meas["t"], ts, np.asarray(sim[k], dtype=float))
        ok = np.isfinite(v) & (meas["t"] >= ts[0]) & (meas["t"] <= ts[-1])
        if ok.sum() < 2:
            continue
        e = v[ok] - pred[ok]
        out[k] = {"n": int(ok.sum()), "rms_error": float(np.sqrt(np.mean(e ** 2))), "bias": float(e.mean()),
                  "max_abs_error": float(np.abs(e).max()), "t": meas["t"][ok].tolist(), "measured": v[ok].tolist(),
                  "predicted": pred[ok].tolist()}
    return clean({"label": req.label, "measured_source": "MEASURED (user-imported, unverified provenance)",
                  "predicted_source": f"SIMULATED ({rec['id']})", "channels": out,
                  "unmatched_columns": [k for k in meas if k != "t" and k not in out]})


# ------------------------------------------------------- docs, validation
@app.get("/api/docs")
def docs_list():
    return [{"path": p.relative_to(DOCS).as_posix(), "title": p.stem.replace("_", " ")}
            for p in sorted(DOCS.rglob("*.md"))]


@app.get("/api/docs/{path:path}", response_class=PlainTextResponse)
def doc(path: str):
    p = (DOCS / path).resolve()
    if DOCS.resolve() not in p.parents or p.suffix != ".md" or not p.exists():
        raise HTTPException(404, "document not found")
    return p.read_text(encoding="utf-8")


@app.get("/api/validation")
def validation():
    p = store.ROOT / "validation" / "latest.json"
    if not p.exists():
        return {"available": False, "note": "run tools/run_validation.py to produce a verification report"}
    return json.loads(p.read_text(encoding="utf-8"))


# ------------------------------------------------------------- live sim
LIVE_KEYS = ["t", "north", "east", "alt", "qw", "qx", "qy", "qz", "roll_deg", "pitch_deg", "yaw_deg", "airspeed",
             "alpha_deg", "beta_deg", "phi_left_deg", "phi_right_deg", "phid_left", "phid_right", "twist_left_deg", "crank_deg", "twist_drive_deg",
             "twist_right_deg", "defl_left_mm", "defl_right_mm", "freq_left", "freq_right", "elevator_deg", "rudder_deg",
             "lift", "thrust", "wing_lift", "lift_left", "lift_right", "p_mech", "p_elec", "battery_v", "battery_i",
             "soc", "energy_wh", "motor_rpm", "motor_temp_rise", "vd", "cmd_alt", "cmd_speed", "cmd_heading_deg", "mode",
             "stall_frac", "hinge_torque_left", "hinge_torque_right", "imu_az", "pitot", "baro_alt"]


@app.websocket("/api/live")
async def live(ws: WebSocket):
    await ws.accept()
    sim: Simulation | None = None
    running = False
    scale = 1.0
    sent_w = sent_e = 0
    lock = threading.Lock()

    async def build(msg: dict) -> Simulation:
        cfg = resolve(ConfigRef.model_validate(msg.get("ref", {})))
        sc = SimulationConfig.model_validate({**msg.get("simulation", {}), "duration": 600, "output_hz": 100})
        await ws.send_json({"type": "status", "msg": "trimming aircraft (cycle-averaged solve)..."})
        return await asyncio.to_thread(Simulation, cfg, sc)

    async def receiver():
        nonlocal sim, running, scale, sent_w, sent_e
        while True:
            msg = await ws.receive_json()
            kind = msg.get("type")
            try:
                if kind == "start":
                    s = await build(msg)
                    with lock:
                        sim = s
                        sent_w = sent_e = 0
                        running = True
                    await ws.send_json(clean({"type": "started", "trim": {k: v for k, v in s.trim.items() if k not in ("cycle", "state")},
                                              "mass": s.model.mass, "model_version": model_version(),
                                              "geometry": geometry_summary(s.ac)}))
                elif kind == "pause":
                    running = False
                elif kind == "resume":
                    running = sim is not None
                elif kind == "stop":
                    running = False
                    sim = None
                    await ws.send_json({"type": "stopped"})
                elif kind == "scale":
                    scale = max(0.05, min(4.0, float(msg.get("value", 1.0))))
                elif kind == "targets" and sim:
                    for k in ("altitude", "airspeed"):
                        if msg.get(k) is not None:
                            sim.ctrl.targets[k] = float(msg[k])
                    if msg.get("heading_deg") is not None:
                        sim.ctrl.targets["heading"] = math.radians(float(msg["heading_deg"]))
                        if sim.ctrl.mode == "waypoint":
                            sim.ctrl.mode = "hold"
                elif kind == "manual" and sim:
                    for k, v in msg.get("values", {}).items():
                        if v is None:
                            sim.manual.pop(k, None)
                        else:
                            sim.manual[k] = v
                elif kind == "fault" and sim:
                    sim.faults_pending.append(Fault(time=sim.t, kind=msg["kind"], magnitude=msg.get("magnitude", 1.0)))
            except HTTPException as e:
                await ws.send_json({"type": "error", "msg": e.detail})
            except Exception as e:
                await ws.send_json({"type": "error", "msg": f"{type(e).__name__}: {e}"})

    async def stepper():
        nonlocal sent_w, sent_e, running
        last = time.perf_counter()
        sim_debt = 0.0
        while True:
            await asyncio.sleep(1 / 30)
            now = time.perf_counter()
            dt_wall = now - last
            last = now
            s = sim
            if not running or s is None:
                continue
            sim_debt = min(sim_debt + dt_wall * scale, 0.25)
            n = int(sim_debt * s.sc.control_hz)
            if n <= 0:
                continue
            sim_debt -= n / s.sc.control_hz

            def advance():
                rows = []
                t0 = time.perf_counter()
                for _ in range(n):
                    r = s.step()
                    if r is not None:
                        rows.append({k: r[k] for k in LIVE_KEYS})
                    if s.terminated:
                        break
                return rows, time.perf_counter() - t0

            rows, comp = await asyncio.to_thread(advance)
            new_w = s.warnings[sent_w:]
            new_e = s.events[sent_e:]
            sent_w, sent_e = len(s.warnings), len(s.events)
            await ws.send_json(clean({"type": "frames", "rows": rows, "warnings": new_w, "events": new_e,
                                      "terminated": s.terminated, "assessment": s.assess() if s.terminated else None,
                                      "realtime_capacity": (n / s.sc.control_hz) / comp if comp > 0 else None,
                                      "faults_active": s.faults_active}))
            if s.terminated:
                running = False

    try:
        await asyncio.gather(receiver(), stepper())
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
