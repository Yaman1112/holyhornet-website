"""Atmosphere and wind.

ISA troposphere density; steady wind + discrete (1 - cos) gusts evaluated
continuously; Gauss-Markov turbulence updated at the controller rate and held
between updates (zero-order hold keeps the RK4 right-hand side smooth).
"""
from __future__ import annotations

import math

import numpy as np

from .config import EnvironmentConfig

G0 = 9.80665
RHO0 = 1.225
T0 = 288.15


def isa_density(h_m: float, dT: float = 0.0) -> float:
    h = max(min(h_m, 11000.0), -500.0)
    T = T0 - 0.0065 * h + dT
    p = 101325.0 * (1 - 2.25577e-5 * h) ** 5.25588
    return p / (287.05287 * T)


class Environment:
    def __init__(self, cfg: EnvironmentConfig):
        self.cfg = cfg
        self.steady = np.array([cfg.wind_north, cfg.wind_east, cfg.wind_down], dtype=float)
        self.turb = np.zeros(3)
        self.rng = np.random.default_rng(cfg.seed)
        self.density_scale = 1.0

    def density(self, alt_m: float) -> float:
        return isa_density(self.cfg.altitude_ref_m + alt_m, self.cfg.temperature_offset_c) * self.density_scale

    def wind_ned(self, t: float) -> np.ndarray:
        w = self.steady + self.turb
        for g in self.cfg.gusts:
            if g.start <= t <= g.start + g.duration:
                s = 0.5 * (1 - math.cos(2 * math.pi * (t - g.start) / g.duration))
                w = w + s * np.array([g.north, g.east, g.down])
        return w

    def update_turbulence(self, dt: float, airspeed: float) -> None:
        sig = self.cfg.turbulence_sigma
        if sig <= 0:
            return
        tau = self.cfg.turbulence_length / max(airspeed, 1.0)
        a = math.exp(-dt / tau)
        self.turb = a * self.turb + sig * math.sqrt(1 - a * a) * self.rng.standard_normal(3)
