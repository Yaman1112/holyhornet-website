"""Aerodynamic research engine (Simulation B) and parameter sweeps.

Two sweep modes:
  captive : wind-tunnel cycle at fixed airspeed / body angle (no trim). Shows how a
            parameter changes the cycle forces and power at one operating point.
  trim    : re-trim the aircraft at each point. Shows what the change costs in
            level flight (frequency, angle of attack, elevator, power).
"""
from __future__ import annotations

import math

import numpy as np

from .analysis import analysis_model, body_state, captive_cycle, trim
from .config import AircraftConfig, apply_overrides

PARAMS = {
    "frequency_hz": {"label": "Wingbeat frequency", "unit": "Hz", "key": "stroke.frequency_hz", "modes": ["captive"]},
    "amplitude_deg": {"label": "Stroke amplitude", "unit": "deg", "key": "stroke.amplitude_deg", "modes": ["captive", "trim"]},
    "stroke_mean_deg": {"label": "Mean stroke angle", "unit": "deg", "key": "stroke.mean_deg", "modes": ["captive", "trim"]},
    "twist_amplitude_deg": {"label": "Driven tip twist", "unit": "deg", "key": "kinematics.twist_amplitude_deg", "modes": ["captive", "trim"]},
    "twist_phase_deg": {"label": "Twist phase lead", "unit": "deg", "key": "kinematics.twist_phase_deg", "modes": ["captive", "trim"]},
    "downstroke_fraction": {"label": "Downstroke fraction", "unit": "-", "key": "kinematics.downstroke_fraction", "modes": ["captive", "trim"]},
    "airspeed": {"label": "Airspeed", "unit": "m/s", "key": None, "modes": ["captive", "trim"]},
    "alpha_deg": {"label": "Body angle of attack", "unit": "deg", "key": None, "modes": ["captive"]},
    "total_mass": {"label": "All-up mass", "unit": "kg", "key": "total_mass", "modes": ["trim"]},
    "semi_span": {"label": "Semi-span (each wing)", "unit": "m", "key": "wings.semi_span", "modes": ["captive", "trim"]},
    "chord_scale": {"label": "Chord scale (area)", "unit": "x", "key": None, "modes": ["captive", "trim"]},
    "wing_mass": {"label": "Wing mass (each)", "unit": "kg", "key": "wings.mass", "modes": ["captive", "trim"]},
    "torsion_k": {"label": "Twist stiffness", "unit": "N m/rad", "key": "structure.torsion_k", "modes": ["captive", "trim"]},
    "spar_EI": {"label": "Spar bending stiffness", "unit": "N m^2", "key": "structure.spar_EI", "modes": ["captive", "trim"]},
    "air_density": {"label": "Air density", "unit": "kg/m^3", "key": None, "modes": ["captive", "trim"]},
}

METRICS = ["mean_lift", "mean_thrust", "mean_wing_lift", "mean_wing_thrust", "mean_p_mech", "mean_p_elec_total",
           "propulsive_efficiency", "equivalent_lift_to_drag", "lift_to_drag", "max_stall_fraction",
           "max_tip_twist_deg", "max_tip_deflection", "peak_hinge_torque", "rms_crank_torque"]


def _configure(cfg: AircraftConfig, point: dict) -> tuple[AircraftConfig, dict]:
    ov = {}
    extra = {}
    for name, val in point.items():
        spec = PARAMS[name]
        if spec["key"]:
            ov[spec["key"]] = val
        elif name == "chord_scale":
            ov["wings.root_chord"] = cfg.wing_right.root_chord * val
            ov["wings.tip_chord"] = cfg.wing_right.tip_chord * val
        else:
            extra[name] = val
    return (apply_overrides(cfg, ov) if ov else cfg), extra


def cycle_study(cfg: AircraftConfig, V: float = 10.0, alpha_deg: float = 2.0, overrides: dict | None = None,
                n: int = 72) -> dict:
    c = apply_overrides(cfg, overrides) if overrides else cfg
    m = analysis_model(c)
    u = m.default_controls()
    res = captive_cycle(m, body_state(m, V, math.radians(alpha_deg)), u, n=n, record=True)
    res.pop("struct_end", None)
    k = math.pi * res["frequency_hz"] * m.wing_info[1].mac / V
    R = c.wing_right.semi_span + c.hinge.y_offset
    A = math.radians(c.kinematics.right.amplitude_deg)
    st = res["frequency_hz"] * 2 * R * math.sin(A) / V
    res["reduced_frequency"] = k
    res["strouhal"] = st
    res["validity"] = []
    if k > 0.3:
        res["validity"].append(f"k = {k:.2f} > 0.3: unsteady wake effects (not modelled) become significant")
    if res["max_stall_fraction"] > 0.5:
        res["validity"].append("large post-stall fraction: quasi-steady post-stall coefficients are uncertain")
    res["conditions"] = {"airspeed": V, "alpha_deg": alpha_deg, "rho": m.env.density(40.0)}
    return res


def sweep(cfg: AircraftConfig, param: str, values: list[float], mode: str = "captive", V: float = 10.0,
          alpha_deg: float = 2.0, param2: str | None = None, values2: list[float] | None = None) -> dict:
    if mode not in PARAMS[param]["modes"]:
        raise ValueError(f"parameter {param} is not meaningful in {mode} mode")
    grid2 = values2 if param2 else [None]
    rows = []
    guess = None
    for v2 in grid2:
        for v in values:
            point = {param: v}
            if param2:
                point[param2] = v2
            c, extra = _configure(cfg, point)
            Vp = extra.get("airspeed", V)
            row = {"point": point}
            try:
                if mode == "captive":
                    m = analysis_model(c)
                    if "air_density" in extra:
                        m.env.density_scale = extra["air_density"] / m.env.density(40.0)
                    a = math.radians(extra.get("alpha_deg", alpha_deg))
                    cyc = captive_cycle(m, body_state(m, Vp, a), m.default_controls(), n=40)
                    row.update({k: cyc.get(k) for k in METRICS})
                    row["mean_ax"], _, row["mean_az"] = cyc["mean_body_accel"]
                else:
                    m = analysis_model(c)
                    if "air_density" in extra:
                        m.env.density_scale = extra["air_density"] / m.env.density(40.0)
                    tr = trim(c, Vp, model=m, guess=guess)
                    if tr["converged"]:
                        guess = [math.radians(tr["alpha_deg"]), tr["frequency_hz"], math.radians(tr["elevator_deg"])]
                    cyc = tr["cycle"]
                    row.update({k: cyc.get(k) for k in METRICS})
                    row.update({"trim_converged": tr["converged"], "alpha_deg": tr["alpha_deg"],
                                "frequency_hz": tr["frequency_hz"], "elevator_deg": tr["elevator_deg"],
                                "reduced_frequency": tr["reduced_frequency"], "mass": m.mass})
            except Exception as e:  # keep the sweep going; record the failure honestly
                row["error"] = str(e)
            rows.append(row)
    return {"param": param, "values": values, "param2": param2, "values2": values2, "mode": mode,
            "airspeed": V, "alpha_deg": alpha_deg, "rows": rows,
            "units": {param: PARAMS[param]["unit"], **({param2: PARAMS[param2]["unit"]} if param2 else {})},
            "data_label": "SIMULATED (quasi-steady model) - not a measurement"}
