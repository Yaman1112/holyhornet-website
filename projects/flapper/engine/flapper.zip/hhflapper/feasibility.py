"""First-order mass, power and energy feasibility (Phase 0).

All numbers derive from the configured estimates and the simulation model.
They are design-stage predictions, not measured performance.
"""
from __future__ import annotations

import math

import numpy as np

from .analysis import analysis_model, trim, trim_sweep
from .config import AircraftConfig, clone
from .geometry import wing_summary
from .massprops import mass_properties
from .power import cell_ocv, endurance_s, motor_quasi_static, usable_energy_wh

MANOEUVRE_N = 1.15


def geometry_summary(cfg: AircraftConfig) -> dict:
    wl, wr = wing_summary(cfg.wing_left), wing_summary(cfg.wing_right)
    span = 2 * (cfg.hinge.y_offset + max(wl.semi_span, wr.semi_span))
    S = wl.area + wr.area
    mp = mass_properties(cfg)
    W = mp.mass * 9.80665
    mac = wr.mac
    # static margin estimate (classical, mean-wing-position, no flapping)
    t = cfg.tail
    from .geometry import helmbold_slope

    a_w = wr.lift_slope
    a_t = helmbold_slope(t.h_span ** 2 / t.h_area)
    deps = 2 * a_w / (math.pi * wr.aspect_ratio)
    x_ac = wr.ac_x
    l_t = t.h_arm + (x_ac - mp.cg[0])  # wing AC to tail AC (x forward)
    x_np = x_ac - (t.h_area * l_t / (S * mac)) * (a_t / a_w) * (1 - deps) * mac
    sm = (mp.cg[0] - x_np) / mac
    return {
        "wingspan_m": span,
        "wing_area_m2": S,
        "mac_m": mac,
        "aspect_ratio": span ** 2 / S,
        "taper": wr.taper,
        "mass_kg": mp.mass,
        "cg_x_m": float(mp.cg[0]),
        "wing_loading_n_m2": W / S,
        "inertia_kg_m2": mp.inertia.tolist(),
        "horizontal_tail_volume": t.h_area * t.h_arm / (S * mac),
        "vertical_tail_volume": t.v_area * t.v_arm / (S * span),
        "static_margin_mac": sm,
        "static_margin_note": "classical fixed-wing estimate at mean stroke; flapping changes it - see stability analysis",
        "reynolds_at_10ms": 1.225 * 10 * mac / 1.81e-5,
    }


def gear_ratio_study(cfg: AircraftConfig, trim_result: dict, ratios=None) -> dict:
    """Electrical power over one trimmed cycle for a range of gear ratios (motor held fixed)."""
    ratios = ratios or list(np.arange(10, 81, 2.0))
    cyc = trim_result["cycle"]["series"]
    tau = np.asarray(cyc["crank_torque"])
    f = trim_result["frequency_hz"]
    Om = 2 * math.pi * f
    rows = []
    for N in ratios:
        m = clone(cfg).motor
        m.gear_ratio = float(N)
        pts = [motor_quasi_static(m, float(tq), Om) for tq in tau]
        p = np.mean([q["p_elec"] for q in pts])
        v = max(q["voltage"] for q in pts)
        i = max(q["current"] for q in pts)
        rows.append({"gear_ratio": float(N), "p_elec_motor_w": float(p), "peak_voltage_v": float(v), "peak_current_a": float(i),
                     "feasible_on_pack": bool(v <= cfg.battery.cells * cell_ocv(0.2) * 0.95 and i <= m.max_current)})
    feas = [r for r in rows if r["feasible_on_pack"]]
    best = min(feas or rows, key=lambda r: r["p_elec_motor_w"])
    return {"rows": rows, "best": best, "current_ratio": cfg.motor.gear_ratio,
            "note": "quasi-static DC motor model; no regeneration; voltage limit = pack at 20% SoC with 5% ESC headroom"}


def feasibility(cfg: AircraftConfig, speeds=None) -> dict:
    speeds = speeds or [8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0]
    geo = geometry_summary(cfg)
    mp = mass_properties(cfg)
    sweep = trim_sweep(cfg, speeds)
    ok = [r for r in sweep if r["converged"]]
    av = cfg.avionics
    p_av = av.flight_computer_w + av.sensors_w + av.telemetry_w + av.servos_w + (av.camera_w if av.camera_enabled else 0)
    e_wh = usable_energy_wh(cfg.battery)
    for r in sweep:
        if r["converged"]:
            r["endurance_min"] = endurance_s(e_wh, r["power_elec_w"]) / 60
            r["range_km"] = r["endurance_min"] * 60 * r["airspeed"] / 1000
    # manoeuvre margin: a trimmed n = 1.15 condition (mass x 1.15, ~30 deg bank) with stall <= 0.5.
    # Cruising at the stall-limited minimum speed leaves no lift for turns (found in DS-03).
    from .massprops import set_total_mass

    heavy = set_total_mass(cfg, mp.mass * MANOEUVRE_N)
    for r in sweep:
        if r["converged"]:
            h = trim(heavy, r["airspeed"], model=analysis_model(heavy))
            r["manoeuvre_margin"] = bool(h["converged"] and h["cycle"]["max_stall_fraction"] <= 0.5)
            r["manoeuvre_stall"] = h["cycle"]["max_stall_fraction"]
        else:
            r["manoeuvre_margin"] = False
    ok_m = [r for r in ok if r["manoeuvre_margin"]]
    best_end = max(ok_m or ok, key=lambda r: r["endurance_min"]) if ok else None
    best_range = max(ok_m or ok, key=lambda r: r["range_km"]) if ok else None
    best_end_no_margin = max(ok, key=lambda r: r["endurance_min"]) if ok else None
    cruise = trim(cfg, best_end["airspeed"], model=analysis_model(cfg)) if best_end else None
    gears = gear_ratio_study(cfg, cruise) if cruise else None
    b = cfg.battery
    peak_current = max((r["power_elec_w"] for r in ok), default=0) / (b.cells * 3.6)
    risks = []
    if not ok:
        risks.append("no trimmed level flight found in the speed range: configuration is not feasible as specified")
    else:
        vmin = min(r["airspeed"] for r in ok)
        if vmin > speeds[0]:
            risks.append(f"no trim below {vmin:.0f} m/s: minimum flight speed is high for hand launch")
    if ok and not ok_m:
        risks.append(f"no trimmed speed has a {MANOEUVRE_N} g manoeuvre margin: the aircraft cannot hold altitude in a 30 deg turn")
    elif ok and min(r["airspeed"] for r in ok_m) > min(r["airspeed"] for r in ok):
        risks.append(f"lowest speed with {MANOEUVRE_N} g margin is {min(r['airspeed'] for r in ok_m):.0f} m/s "
                     f"(minimum trim {min(r['airspeed'] for r in ok):.0f} m/s): do not cruise at the minimum speed")
    if cruise and cruise["cycle"]["max_stall_fraction"] > 0.3:
        risks.append("part of the wing is post-stall during the cruise cycle: quasi-steady predictions are uncertain")
    if cruise and cruise["reduced_frequency"] > 0.25:
        if cfg.aerodynamics.unsteady:
            risks.append(f"cruise reduced frequency k = {cruise['reduced_frequency']:.2f}: Wagner lag modelled; 3-D wake, LEV and dynamic stall are not")
        else:
            risks.append(f"cruise reduced frequency k = {cruise['reduced_frequency']:.2f}: quasi-steady model selected, unsteady effects not modelled")
    if gears and gears["best"]["gear_ratio"] != cfg.motor.gear_ratio:
        risks.append(f"gear ratio {cfg.motor.gear_ratio:.0f}:1 is not the electrical optimum ({gears['best']['gear_ratio']:.0f}:1) for the assumed motor")
    return {
        "geometry": geo,
        "mass_budget": mp.table(),
        "total_mass_kg": mp.mass,
        "avionics_power_w": p_av,
        "usable_energy_wh": e_wh,
        "trim_sweep": sweep,
        "best_endurance": {k: best_end[k] for k in ("airspeed", "power_elec_w", "power_mech_w", "endurance_min", "frequency_hz", "alpha_deg")} if best_end else None,
        "best_endurance_without_margin": {k: best_end_no_margin[k] for k in ("airspeed", "power_elec_w", "endurance_min")} if best_end_no_margin else None,
        "manoeuvre_load_factor": MANOEUVRE_N,
        "best_range": {k: best_range[k] for k in ("airspeed", "power_elec_w", "range_km", "endurance_min")} if best_range else None,
        "cruise_cycle": {k: v for k, v in cruise["cycle"].items() if k != "series"} if cruise else None,
        "gear_ratio_study": gears,
        "battery_peak_c_rate": peak_current / b.capacity_ah,
        "risks": risks,
        "data_label": "ESTIMATED from configured parameters and the simulation model",
    }
