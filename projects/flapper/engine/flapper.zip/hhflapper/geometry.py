"""Parametric wing geometry and blade-element strip discretisation."""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .config import WingGeometry


@dataclass
class WingSummary:
    semi_span: float
    area: float  # one wing [m^2]
    mac: float  # mean aerodynamic chord [m]
    mac_le_x: float  # x of MAC leading edge relative to datum [m]
    mac_y: float  # spanwise station of MAC from hinge [m]
    aspect_ratio: float  # of the mirrored pair (2R)^2 / (2S)
    taper: float
    lift_slope: float  # Helmbold 3-D lift slope [1/rad]
    ac_x: float  # quarter-MAC x relative to datum


def helmbold_slope(ar: float) -> float:
    """Helmbold finite-wing lift-curve slope (valid for low/moderate AR, unswept)."""
    return 2 * math.pi * ar / (2 + math.sqrt(ar * ar + 4))


def wing_summary(w: WingGeometry) -> WingSummary:
    R, cr, ct = w.semi_span, w.root_chord, w.tip_chord
    lam = ct / cr
    area = 0.5 * (cr + ct) * R
    mac = 2.0 / 3.0 * cr * (1 + lam + lam * lam) / (1 + lam)
    mac_y = R / 3.0 * (1 + 2 * lam) / (1 + lam)
    mac_le_x = w.le_root_x - mac_y * math.tan(math.radians(w.sweep_deg))
    ar = (2 * R) ** 2 / (2 * area)
    return WingSummary(
        semi_span=R,
        area=area,
        mac=mac,
        mac_le_x=mac_le_x,
        mac_y=mac_y,
        aspect_ratio=ar,
        taper=lam,
        lift_slope=helmbold_slope(ar),
        ac_x=mac_le_x - 0.25 * mac,
    )


@dataclass
class Strips:
    """Strip properties for one wing in its own (un-flapped) frame.

    r      : spanwise station of strip midpoint from the hinge [m]
    dr     : strip width [m]
    c      : local chord [m]
    x_le   : x of local leading edge relative to datum [m]
    theta0 : geometric pitch (incidence minus washout) [rad]
    mass   : strip mass [kg]
    """

    r: np.ndarray
    dr: np.ndarray
    c: np.ndarray
    x_le: np.ndarray
    theta0: np.ndarray
    mass: np.ndarray


def make_strips(w: WingGeometry) -> Strips:
    n = w.n_strips
    R = w.semi_span
    # cosine-clustered toward the tip where the flapping velocity is highest
    s = 0.5 * (1 - np.cos(np.linspace(0, math.pi, n + 1)))
    s = 0.5 * s + 0.5 * np.linspace(0, 1, n + 1)
    edges = s * R
    r = 0.5 * (edges[1:] + edges[:-1])
    dr = np.diff(edges)
    c = w.root_chord + (w.tip_chord - w.root_chord) * r / R
    x_le = w.le_root_x - r * math.tan(math.radians(w.sweep_deg))
    theta0 = np.radians(w.incidence_deg - w.washout_deg * r / R)
    area = c * dr
    mass = w.mass * area / area.sum()
    return Strips(r=r, dr=dr, c=c, x_le=x_le, theta0=theta0, mass=mass)
