"""Multi-rate 6-DOF simulation (Simulations C-H).

Rates:
  physics      dt (default 2 ms, RK4) or adaptive Dormand-Prince between control ticks
  sensors / estimator / controller   control_hz (default 100 Hz, zero-order hold)
  GNSS         sensors.gnss_rate_hz
  recording    output_hz

The 3-D digital twin is driven from the recorded *simulation state* (stroke
angle, twist, deflection, attitude), never from a separate animation clock.
"""
from __future__ import annotations

import math
import time

import numpy as np

from .analysis import analysis_model, trim
from .config import AircraftConfig, SimulationConfig
from .control import Controller, Estimator
from .environment import Environment
from .frames import euler_to_quat, quat_to_euler
from .integrators import IntegratorStats, dopri_integrate, rk4_step
from .model import Model
from .sensors import SensorSuite
from .version import model_version

_TRIM_CACHE: dict = {}


def cached_trim(cfg: AircraftConfig, V: float) -> dict:
    key = (cfg.model_dump_json(exclude={"created", "notes", "author", "name"}), round(V, 3))
    if key not in _TRIM_CACHE:
        _TRIM_CACHE[key] = trim(cfg, V, model=analysis_model(cfg))
        if len(_TRIM_CACHE) > 64:
            _TRIM_CACHE.pop(next(iter(_TRIM_CACHE)))
    return _TRIM_CACHE[key]


class Simulation:
    def __init__(self, aircraft: AircraftConfig, sim: SimulationConfig, trim_result: dict | None = None):
        self.ac = aircraft
        self.sc = sim
        self.env = Environment(sim.environment)
        self.model = Model(aircraft, self.env)
        self.stats = IntegratorStats()
        self.warnings: list[dict] = []
        self._active_warn: set = set()
        self._cleared_at: dict = {}
        import collections

        self._stall_hist = collections.deque()
        self.t = 0.0
        self.terminated = None
        self.manual: dict = {}
        self.wall_time = 0.0

        tr = trim_result
        if tr is None and sim.trim_initial:
            tr = cached_trim(aircraft, sim.initial_airspeed)
        if tr is None or not tr.get("converged"):
            self.warn(0.0, "trim", "no converged trim at the initial airspeed; starting from configured stroke "
                      "parameters (expect a transient)", "warning")
            u0 = self.model.default_controls()
            tr = {"airspeed": sim.initial_airspeed, "alpha_deg": 3.0, "pitch_deg": 3.0, "frequency_hz": float(u0[1]),
                  "elevator_deg": 0.0, "controls": u0.tolist(), "struct_state": None, "converged": False}
        self.trim = tr
        u = np.array(tr["controls"], dtype=float)
        if self.model.drive == "motor_crank":
            u[8] = 0.6
        x = self.model.initial_state(altitude=sim.initial_altitude, airspeed=sim.initial_airspeed,
                                     pitch=math.radians(tr["pitch_deg"]), heading=math.radians(sim.initial_heading_deg), u=u)
        a = math.radians(tr["alpha_deg"])
        x[3] = sim.initial_airspeed * math.cos(a)
        x[5] = sim.initial_airspeed * math.sin(a)
        ss = tr.get("struct_state")
        if ss is not None and len(ss) == len(self.model.dyn_idx):
            x[self.model.dyn_idx] = ss
        self.x = x
        self.u = u
        self.sensors = SensorSuite(aircraft.sensors)
        self.est = Estimator(sim.controller.estimator, x)
        self.ctrl = Controller(sim.controller, tr, aircraft.actuators, aircraft.kinematics, sim.control_hz)
        if self.model.drive == "motor_crank":
            # initialise the governor integrator near the back-EMF-limited throttle for the trim frequency
            from .power import cell_ocv
            v_oc = aircraft.battery.cells * cell_ocv(1.0)
            om = 2 * math.pi * tr["frequency_hz"] * aircraft.motor.gear_ratio
            self.ctrl.thr_i = min(1.0, (self.model.ke * om + 3.0 * aircraft.motor.resistance) / v_oc)
        self.ctrl.last_heartbeat = 0.0
        self.faults_pending = sorted(sim.faults, key=lambda f: f.time)
        self.faults_active: list[dict] = []
        self.health = {"motor_failed": False, "comms_lost": False, "gnss_valid": True, "wing_asymmetry": False}
        self.rec: dict[str, list] = {}
        self.events = self.ctrl.events
        self.out_every = max(1, int(round(sim.control_hz / sim.output_hz)))
        self.tick = 0
        self.h_adapt = sim.dt
        self.lost_control_time = 0.0
        self.last = {}

    # ----------------------------------------------------------------- utils
    REARM_S = 3.0  # a cleared warning cannot re-fire for this long (prevents per-wingbeat flicker)

    def warn(self, t, kind, msg, level="warning"):
        if kind in self._active_warn:
            return
        if t - self._cleared_at.get(kind, -1e9) < self.REARM_S:
            self._active_warn.add(kind)  # still the same episode: re-activate silently
            return
        self._active_warn.add(kind)
        self.warnings.append({"t": round(t, 3), "kind": kind, "level": level, "msg": msg})

    def clear_warn(self, kind):
        if kind in self._active_warn:
            self._active_warn.discard(kind)
            self._cleared_at[kind] = self.t

    def _apply_faults(self):
        while self.faults_pending and self.faults_pending[0].time <= self.t + 1e-9:
            f = self.faults_pending.pop(0)
            k, mag = f.kind, f.magnitude
            m = self.model
            d = self.last
            if k == "motor_failure":
                m.faults["motor_failure"] = True
            elif k in ("wing_stuck_left", "wing_stuck_right"):
                side = 0 if k.endswith("left") else 1
                m.faults[k] = float(d["phi"][side]) if d else 0.0
            elif k == "joint_failure_right":
                m.faults[k] = True
            elif k == "asymmetric_amplitude":
                m.faults[k] = float(mag if mag < 1 else 0.7)
            elif k == "battery_sag":
                m.faults[k] = float(mag if mag < 1 else 0.85)
            elif k == "imu_gyro_bias":
                self.sensors.extra_gyro_bias = np.radians(np.full(3, mag if mag != 1.0 else 3.0))
            elif k == "gnss_loss":
                self.sensors.gnss_ok = False
            elif k == "comms_loss":
                self.health["comms_lost"] = True
            elif k == "vibration":
                self.sensors.vibration = mag if mag > 1 else 15.0
            elif k == "airspeed_sensor_block":
                self.sensors.airspeed_ok = False
            self.faults_active.append({"t": round(self.t, 3), "kind": k, "magnitude": mag})
            self.events.append({"t": round(self.t, 3), "level": "fault", "msg": f"FAULT INJECTED: {k}"})

    def _record(self, d: dict, meas: dict, est: dict, info: dict):
        x = self.x
        r, p, y = quat_to_euler(x[6:10])
        from .frames import quat_to_dcm

        vn = quat_to_dcm(x[6:10]) @ x[3:6]
        tw = d.get("driven_twist", np.zeros(2)) + d["tip_twist"]
        row = {
            "t": self.t,
            "north": x[0], "east": x[1], "alt": -x[2],
            "qw": x[6], "qx": x[7], "qy": x[8], "qz": x[9],
            "roll_deg": math.degrees(r), "pitch_deg": math.degrees(p), "yaw_deg": math.degrees(y),
            "p": x[10], "q": x[11], "r": x[12],
            "vn": vn[0], "ve": vn[1], "vd": vn[2],
            "airspeed": d["airspeed"], "alpha_deg": d["alpha_deg"], "beta_deg": d["beta_deg"],
            "phi_left_deg": math.degrees(d["phi"][0]), "phi_right_deg": math.degrees(d["phi"][1]),
            "phid_left": d["phid"][0], "phid_right": d["phid"][1],
            "crank_deg": math.degrees(x[14]) % 360.0,
            "crank_hold_torque": d.get("crank_hold_torque", 0.0),
            "park_torque": d.get("park_torque", 0.0),
            "park_state": 1 if self.model.springs_released else 0,
            "twist_torque_left": float(d.get("twist_drive_torque", np.zeros(2))[0]),
            "twist_torque_right": float(d.get("twist_drive_torque", np.zeros(2))[1]),
            "twist_bias_deg": math.degrees(float(self.u[9])) if len(self.u) > 9 else 0.0,
            "freq_left": d["freq_hz"][0], "freq_right": d["freq_hz"][1],
            "twist_left_deg": math.degrees(tw[0]), "twist_right_deg": math.degrees(tw[1]),
            "twist_drive_deg": math.degrees(d.get("driven_twist", np.zeros(2))[1]),
            "defl_left_mm": d["tip_deflection"][0] * 1000, "defl_right_mm": d["tip_deflection"][1] * 1000,
            "elevator_deg": d["tail"]["elevator_deg"], "rudder_deg": d["tail"]["rudder_deg"],
            "lift": d["lift_total"], "thrust": d["thrust_total"], "wing_lift": d["wing_lift"],
            "lift_left": d["left"]["lift"], "lift_right": d["right"]["lift"],
            "p_mech": float(np.sum(d["p_mech"])), "p_elec": d["p_total"],
            "hinge_torque_left": d["hinge_torque"][0], "hinge_torque_right": d["hinge_torque"][1],
            "battery_v": d["battery_voltage"], "battery_i": d["battery_current"], "soc": d["battery_soc"],
            "energy_wh": x[26] / 3600, "motor_rpm": d["motor_rpm"], "motor_temp_rise": x[27],
            "motor_i": d["motor_current"],
            "imu_ax": meas["accel"][0], "imu_ay": meas["accel"][1], "imu_az": meas["accel"][2],
            "gyro_p": meas["gyro"][0], "gyro_q": meas["gyro"][1], "gyro_r": meas["gyro"][2],
            "baro_alt": meas["baro_alt"], "pitot": meas["airspeed"],
            "est_roll_deg": math.degrees(est["roll"]), "est_pitch_deg": math.degrees(est["pitch"]),
            "est_yaw_deg": math.degrees(est["yaw"]), "est_alt": est["alt"],
            "cmd_alt": info.get("altitude_cmd", float("nan")), "cmd_speed": info.get("airspeed_cmd", float("nan")),
            "cmd_heading_deg": info.get("heading_cmd_deg", float("nan")),
            "cmd_pitch_deg": info.get("theta_cmd_deg", float("nan")),
            "cmd_bank_deg": info.get("bank_cmd_deg", float("nan")),
            "cmd_freq": float(self.u[1]),
            "gust_sigma": info.get("gust_sigma", 0.0), "gust_margin": info.get("gust_margin", 0.0),
            "throttle": float(self.u[8]) if len(self.u) > 8 else 0.0,
            "mode": info.get("mode", "open-loop"),
            "stall_frac": max(d["left"]["stall_fraction"], d["right"]["stall_fraction"]),
        }
        for k, v in row.items():
            self.rec.setdefault(k, []).append(v if isinstance(v, str) else float(v))
        return row

    def _monitor(self, d: dict):
        t = self.t
        x = self.x
        r, p, _ = quat_to_euler(x[6:10])
        if -x[2] <= 0.0:
            self.terminated = "ground_impact"
            self.events.append({"t": round(t, 3), "level": "critical", "msg": "ground impact"})
            return
        if abs(r) > math.radians(80) or abs(p) > math.radians(60):
            self.lost_control_time += 1.0 / self.sc.control_hz
            self.warn(t, "attitude", f"attitude beyond envelope (roll {math.degrees(r):.0f}, pitch {math.degrees(p):.0f} deg)", "critical")
            if self.lost_control_time > 1.5:
                self.terminated = "loss_of_control"
                self.events.append({"t": round(t, 3), "level": "critical", "msg": "loss of control (attitude out of envelope > 1.5 s)"})
                return
        else:
            self.lost_control_time = 0.0
            self.clear_warn("attitude")
        V = d["airspeed"]
        vt = self.trim["airspeed"]
        if V < 0.8 * vt:
            self.warn(t, "low_speed", f"airspeed {V:.1f} m/s below 80% of trim speed: outside trimmed envelope")
        elif V > 0.85 * vt:
            self.clear_warn("low_speed")
        f = float(np.mean(d["freq_hz"]))
        k = math.pi * f * self.model.wing_info[1].mac / max(V, 0.1)
        if k > 0.35:
            self.warn(t, "reduced_frequency", f"reduced frequency {k:.2f} > 0.35: quasi-steady aerodynamics outside validity range")
        # stall judged on the worst value over the last wingbeat, with hysteresis (on > 0.6, off < 0.5 for 2 s)
        self._stall_hist.append((t, max(d["left"]["stall_fraction"], d["right"]["stall_fraction"])))
        while self._stall_hist and self._stall_hist[0][0] < t - 2.0:
            self._stall_hist.popleft()
        f_now = max(float(np.mean(d["freq_hz"])), 0.5)
        beat_max = max(s for ts, s in self._stall_hist if ts >= t - 1.0 / f_now)
        if beat_max > 0.6:
            self.warn(t, "stall", f"wing sections stalled ({beat_max:.0%} post-stall blend in the last wingbeat): model confidence low")
        elif max(s for _, s in self._stall_hist) < 0.5:
            self.clear_warn("stall")
        if d["battery_power_limited"]:
            self.warn(t, "battery_power", "battery cannot deliver the demanded power", "critical")
        soc = d["battery_soc"]
        if soc < 1 - self.ac.battery.usable_fraction:
            self.warn(t, "battery_reserve", f"battery below reserve (SoC {soc*100:.0f}%)", "critical")
        if d["battery_voltage"] / self.ac.battery.cells < self.ac.battery.min_cell_voltage:
            self.warn(t, "cell_voltage", "cell voltage below minimum under load", "critical")
        if soc <= 0.01:
            self.terminated = "battery_depleted"
        if x[27] + 25 > self.ac.motor.max_temp_c:
            self.warn(t, "motor_temp", "motor winding temperature above limit", "critical")
        if d["motor_current"] > self.ac.motor.max_current * 0.98:
            self.warn(t, "motor_current", "motor current at limit")
        if self.stats.max_quat_drift > 1e-3:
            self.warn(t, "numerics", f"quaternion drift {self.stats.max_quat_drift:.1e} per step: reduce dt")
        travel = math.radians(self.ac.hinge.max_travel_deg)
        if np.any(np.abs(d["phi"]) > travel):
            self.warn(t, "hinge_stop", "stroke angle beyond the mechanical hinge stop")

    def _health(self, meas: dict):
        # Motor/drive failure detection. The crank speed swings strongly within each stroke (several Hz
        # peak-to-peak at high load), so the instantaneous value must not be used: average over 0.5 s and
        # require the low reading to persist 0.3 s. (A single in-stroke dip once triggered a false glide
        # fail-safe and a crash, found during component selection.)
        gear = self.ac.motor.gear_ratio
        crank_hz = meas["motor_rpm"] / gear / 60.0
        commanded = float(np.mean(self.u[0:2]))  # wingbeat command in both drive models
        if not hasattr(self, "_crank_hist"):
            import collections

            self._crank_hist = collections.deque()
            self._low_since = None
        self._crank_hist.append((self.t, crank_hz))
        while self._crank_hist and self._crank_hist[0][0] < self.t - 0.5:
            self._crank_hist.popleft()
        crank_avg = float(np.mean([c for _, c in self._crank_hist]))
        self._crank_avg = crank_avg
        low = commanded > 1.0 and crank_avg < 0.3 * commanded and self.t > 0.5
        if low:
            self._low_since = self.t if self._low_since is None else self._low_since
            if self.t - self._low_since >= 0.3 and not self.health["motor_failed"]:
                self.health["motor_failed"] = True
        else:
            self._low_since = None
        gn = meas["gnss"]
        valid = bool(gn and gn.get("valid"))
        if self.health["gnss_valid"] and not valid:
            self.events.append({"t": round(self.t, 3), "level": "warning", "msg": "GNSS invalid: navigating by dead reckoning"})
        self.health["gnss_valid"] = valid
        if not self.health["comms_lost"]:
            self.ctrl.last_heartbeat = self.t

    def _park_logic(self):
        """Wing park by release (DS-04b): once the FC declares motor failure it commands the release servo;
        after release_delay_s the sears free the twist push rods and the hinge-spring anchors (irreversible)."""
        pk = self.ac.park
        if not (pk.enabled and pk.mechanism == "release") or self.model.springs_released:
            return
        if self.health["motor_failed"]:
            if getattr(self, "_release_cmd_t", None) is None:
                self._release_cmd_t = self.t
                self.events.append({"t": round(self.t, 3), "level": "info", "msg": "wing-park: release commanded"})
            if self.t - self._release_cmd_t >= pk.release_delay_s - 1e-9:
                self.model.springs_released = True
                self.model.twist_released = True
                self.events.append({"t": round(self.t, 3), "level": "info",
                                    "msg": "wing-park: twist drive and hinge springs released"})

    # ------------------------------------------------------------------ step
    def step(self) -> dict | None:
        if self.terminated:
            return None
        sc = self.sc
        Tc = 1.0 / sc.control_hz
        self._apply_faults()
        _, d = self.model.evaluate(self.t, self.x, self.u, full=True)
        self.last = d
        meas = self.sensors.sample(self.t, self.x, d)
        self._health(meas)
        self._park_logic()
        est = self.est.update(Tc, self.x, meas, d)
        self.env.update_turbulence(Tc, d["airspeed"])
        if sc.controller.enabled and not self.manual.get("open_loop"):
            u, info = self.ctrl.update(self.t, est, float(np.mean(d["freq_hz"])), self.health)
        else:
            u = np.array(self.trim["controls"], dtype=float)
            info = {"mode": "open-loop"}
        for key, idx in (("elevator_deg", 6), ("rudder_deg", 7)):
            if key in self.manual:
                u[idx] = math.radians(self.manual[key])
        if "frequency_hz" in self.manual:
            u[0:2] = self.manual["frequency_hz"]
        if "amplitude_deg" in self.manual:
            u[2:4] = math.radians(self.manual["amplitude_deg"])
        if "twist_bias_deg" in self.manual and len(u) > 9:
            u[9] = math.radians(self.manual["twist_bias_deg"])
        if "throttle" in self.manual:
            u[8] = self.manual["throttle"]
        self.u = u
        row = None
        if self.tick % self.out_every == 0:
            row = self._record(d, meas, est, info)
        self._monitor(d)
        if self.terminated:
            return row
        f = lambda t, x: self.model.evaluate(t, x, self.u)  # noqa: E731
        try:
            if sc.integrator == "rk4":
                n = max(1, int(round(Tc / sc.dt)))
                h = Tc / n
                for i in range(n):
                    self.x = rk4_step(f, self.t + i * h, self.x, h, self.stats)
            else:
                self.x, self.h_adapt = dopri_integrate(f, self.t, self.x, self.t + Tc, self.h_adapt, sc.rtol, sc.atol,
                                                       self.stats, h_max=Tc)
        except FloatingPointError as e:
            self.terminated = "numerical_failure"
            self.events.append({"t": round(self.t, 3), "level": "critical", "msg": f"numerical failure: {e}"})
            return row
        if not np.all(np.isfinite(self.x)):
            self.terminated = "numerical_failure"
            self.events.append({"t": round(self.t, 3), "level": "critical", "msg": "non-finite state"})
        self.t = round(self.t + Tc, 9)
        self.tick += 1
        return row

    def run(self, progress=None) -> dict:
        t0 = time.perf_counter()
        n = int(round(self.sc.duration * self.sc.control_hz))
        for i in range(n):
            self.step()
            if self.terminated:
                break
            if progress and i % 100 == 0:
                progress(self.t / self.sc.duration)
        self.wall_time = time.perf_counter() - t0
        return self.result()

    # --------------------------------------------------------------- result
    def assess(self) -> dict:
        rec = self.rec
        out = self.terminated or "completed"
        faults = [f["kind"] for f in self.faults_active]
        verdict = "nominal"
        if out != "completed":
            verdict = "unrecoverable within the current design envelope"
        elif faults:
            t = np.array(rec["t"])
            last = t > t[-1] - 5
            alt_err = np.abs(np.array(rec["alt"])[last] - np.array(rec["cmd_alt"])[last])
            vd = np.array(rec["vd"])[last].mean()
            if "glide" in rec["mode"]:
                verdict = "controlled glide descent (no powered recovery); landing site required"
            elif np.nanmax(alt_err) < 10 and abs(vd) < 1.5:
                verdict = "contained: altitude held within 10 m for the final 5 s"
            else:
                verdict = "degraded: still airborne at end of run but not holding the commanded state"
        return {"outcome": out, "verdict": verdict, "faults": self.faults_active}

    def metrics(self) -> dict:
        rec = self.rec
        if not rec:
            return {}
        t = np.array(rec["t"])
        alt = np.array(rec["alt"])
        cmd = np.array(rec["cmd_alt"])
        settled = t > min(t[-1], 5.0) if t[-1] > 6 else t >= 0
        pe = np.array(rec["p_elec"])
        return {
            "duration_s": float(t[-1]),
            "altitude_rms_error_m": float(np.sqrt(np.nanmean((alt[settled] - cmd[settled]) ** 2))) if np.isfinite(cmd).any() else None,
            "altitude_max_error_m": float(np.nanmax(np.abs(alt[settled] - cmd[settled]))) if np.isfinite(cmd).any() else None,
            "airspeed_mean": float(np.mean(rec["airspeed"])),
            "airspeed_rms_error": float(np.sqrt(np.nanmean((np.array(rec["airspeed"]) - np.array(rec["cmd_speed"])) ** 2))),
            "roll_rms_deg": float(np.sqrt(np.mean(np.array(rec["roll_deg"]) ** 2))),
            "pitch_oscillation_pp_deg": float(np.ptp(np.array(rec["pitch_deg"])[settled])),
            "mean_p_elec_w": float(pe.mean()),
            "mean_p_mech_w": float(np.mean(rec["p_mech"])),
            "energy_used_wh": float(rec["energy_wh"][-1]),
            "soc_end": float(rec["soc"][-1]),
            "mean_frequency_hz": float(np.mean(rec["freq_right"])),
            "max_motor_temp_rise_k": float(np.max(rec["motor_temp_rise"])),
            "distance_m": float(np.sum(np.hypot(np.diff(rec["north"]), np.diff(rec["east"])))),
            "real_time_factor": float(t[-1] / self.wall_time) if self.wall_time > 0 else None,
        }

    def result(self) -> dict:
        return {
            "model_version": model_version(),
            "aircraft": {"config_id": self.ac.config_id, "revision": self.ac.revision, "name": self.ac.name},
            "simulation": self.sc.model_dump(),
            "trim": {k: v for k, v in self.trim.items() if k not in ("cycle", "state")},
            "assessment": self.assess(),
            "metrics": self.metrics(),
            "warnings": self.warnings,
            "events": self.events,
            "integrator": self.stats.as_dict(),
            "series": self.rec,
            "data_label": "SIMULATED - not a measurement",
        }
