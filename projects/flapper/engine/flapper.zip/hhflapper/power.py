"""Electrical power: battery, motor and endurance relations.

Battery open-circuit voltage uses a *generic* LiPo discharge-curve shape (typical
of published cell curves, not a specific product). The terminal voltage
includes the internal resistance drop, so high currents reduce usable energy -
the model does not assume the label capacity is available at every load.
"""
from __future__ import annotations

import math

import numpy as np

from .config import BatteryConfig, MotorConfig

_SOC = np.array([0.0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00])
_OCV = np.array([3.27, 3.61, 3.69, 3.73, 3.77, 3.79, 3.82, 3.87, 3.92, 3.98, 4.06, 4.20])


def cell_ocv(soc: float) -> float:
    return float(np.interp(soc, _SOC, _OCV))


def battery_current(p_load: float, v_oc: float, r_int: float) -> tuple[float, float, bool]:
    """Solve P = (Voc - I R) I for the smaller root. Returns (I, V_terminal, power_limited)."""
    p = max(p_load, 0.0)
    disc = v_oc * v_oc - 4 * r_int * p
    if disc < 0:
        i = v_oc / (2 * r_int)
        return i, v_oc - i * r_int, True
    i = (v_oc - math.sqrt(disc)) / (2 * r_int)
    return i, v_oc - i * r_int, False


def motor_constants(m: MotorConfig) -> tuple[float, float]:
    """(Ke [V s/rad], Kt [N m/A]) from Kv."""
    ke = 1.0 / (m.kv_rpm_per_v * 2 * math.pi / 60.0)
    return ke, ke


def motor_quasi_static(m: MotorConfig, crank_torque: float, crank_speed: float) -> dict:
    """Motor operating point needed to supply `crank_torque` at `crank_speed` through the gearbox.

    No regeneration: when the wing back-drives the crank (negative torque) the ESC is assumed to
    freewheel and draw only no-load current.
    """
    ke, kt = motor_constants(m)
    w_m = m.gear_ratio * crank_speed
    if crank_torque >= 0:
        tau_m = crank_torque / (m.gear_ratio * m.gear_efficiency)
    else:
        tau_m = 0.0
    i = tau_m / kt + m.no_load_current
    v = i * m.resistance + ke * w_m
    return {"motor_speed_rad_s": w_m, "motor_torque": tau_m, "current": i, "voltage": v, "p_elec": v * i,
            "copper_loss": i * i * m.resistance}


def usable_energy_wh(b: BatteryConfig, mean_current: float | None = None) -> float:
    """Usable energy [Wh] integrating the OCV curve down to the usable fraction, minus I^2 R loss."""
    soc = np.linspace(1.0, 1.0 - b.usable_fraction, 200)
    v = np.array([cell_ocv(s) for s in soc]) * b.cells
    if mean_current:
        v = v - mean_current * b.cell_resistance * b.cells
    # uniform SoC grid -> mean voltage times the charge drawn
    return float(np.mean(v) * b.capacity_ah * b.usable_fraction)


def endurance_s(e_usable_wh: float, p_avg_w: float) -> float:
    """t = E_usable / P_avg."""
    return e_usable_wh * 3600.0 / p_avg_w if p_avg_w > 0 else math.inf


def energy_j(p_avg_w: float, t_s: float) -> float:
    """E = P_avg t."""
    return p_avg_w * t_s
