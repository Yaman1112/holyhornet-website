"""Mass budget, centre of gravity and inertia tensor.

Inertia is built from point masses (components), the strip masses of both wings
at their mean stroke angle, a slender-rod fuselage shell and the tail. It is
held constant during simulation (the wings move, but carry ~10 % of the mass;
the time-varying part is reported as a modelling limitation).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from .config import AircraftConfig, Component, clone
from .geometry import make_strips


@dataclass
class MassItem:
    name: str
    category: str
    mass: float
    pos: np.ndarray
    basis: str


@dataclass
class MassProperties:
    mass: float
    cg: np.ndarray  # relative to datum
    inertia: np.ndarray  # about CG, body axes [kg m^2]
    items: list[MassItem] = field(default_factory=list)

    def table(self) -> list[dict]:
        return [
            {
                "name": i.name,
                "category": i.category,
                "mass_g": round(i.mass * 1000, 2),
                "x": round(float(i.pos[0]), 4),
                "y": round(float(i.pos[1]), 4),
                "z": round(float(i.pos[2]), 4),
                "fraction": round(i.mass / self.mass, 4) if self.mass else 0,
                "basis": i.basis,
            }
            for i in self.items
        ]


def _wing_items(cfg: AircraftConfig) -> list[tuple[str, np.ndarray, np.ndarray]]:
    out = []
    for side, w, stroke in (("left", cfg.wing_left, cfg.kinematics.left), ("right", cfg.wing_right, cfg.kinematics.right)):
        sg = -1.0 if side == "left" else 1.0
        st = make_strips(w)
        phi = math.radians(stroke.mean_deg)
        x = st.x_le - w.chordwise_cg * st.c
        y = sg * (cfg.hinge.y_offset + st.r * math.cos(phi))
        z = cfg.hinge.z - st.r * math.sin(phi)
        out.append((side, st.mass, np.stack([x, y, z], axis=1)))
    return out


def mass_properties(cfg: AircraftConfig) -> MassProperties:
    items: list[MassItem] = []
    for c in cfg.components:
        if c.enabled and c.mass > 0:
            items.append(MassItem(c.name, c.category, c.mass, np.array([c.x, c.y, c.z]), c.basis))
    items.append(MassItem("battery", "power", cfg.battery.mass, np.array([0.10, 0.0, 0.02]),
                          f"{cfg.battery.cells}S {cfg.battery.capacity_ah*1000:.0f} mAh {cfg.battery.chemistry}, estimate"))
    items.append(MassItem("tail assembly", "structure", cfg.tail.mass,
                          np.array([-cfg.tail.h_arm, 0.0, cfg.tail.h_z]), "estimate: foam/film surfaces + CF rods"))
    if cfg.kinematics.twist_amplitude_deg > 0 and cfg.twist_linkage.hardware_mass > 0:
        items.append(MassItem("twist linkage (horns, rods, idler eccentric, pitch bearings)", "propulsion",
                              cfg.twist_linkage.hardware_mass, np.array([0.03, 0.0, 0.025]),
                              "estimate: 2 x (horn 1 g, rod 1.5 g, 2 ball links 1 g, pitch bearing pair 1.5 g) + idler gear/eccentric 2 g"))
    a = cfg.actuators
    for flag, label in ((a.differential_twist, "roll servo: differential twist (bellcrank on both push rods)"),
                        (a.differential_mean, "roll servo: differential stroke mean (rocker-pivot shift)")):
        if flag:
            items.append(MassItem(label, "actuation", a.roll_servo_mass + 0.003, np.array([0.0, 0.0, 0.02]),
                                  "estimate: 9 g-class micro servo + 3 g bellcrank/links"))
    hs = cfg.hinge_spring
    if hs.enabled and hs.stiffness_Nm_per_rad > 0:
        import math as _m
        for st, sg in ((cfg.kinematics.left, -1), (cfg.kinematics.right, 1)):
            dmax = _m.radians(st.amplitude_deg + abs(st.mean_deg - hs.neutral_deg))
            e_peak = 0.5 * hs.stiffness_Nm_per_rad * dmax ** 2
            mass = hs.mount_mass + e_peak / hs.energy_density_J_per_kg
            items.append(MassItem(f"hinge spring ({'left' if sg < 0 else 'right'})", "propulsion", mass,
                                  np.array([0.0, sg * cfg.hinge.y_offset, cfg.hinge.z]),
                                  f"estimate: CFRP leaf sized for {e_peak:.3f} J at {hs.energy_density_J_per_kg:.0f} J/kg + mount"))
    if cfg.park.enabled and cfg.park.mass > 0:
        if cfg.park.mechanism == "release":
            items.append(MassItem("wing-park release: servo (EMAX ES9051) + twist and spring sears", "propulsion", cfg.park.mass,
                                  np.array([0.02, 0.0, 0.02]), "servo 4.1 g listing + release bar/sears 1.5 g estimate"))
        else:
            items.append(MassItem("wing-park detent (cam lobe, roller, spring)", "propulsion", cfg.park.mass,
                                  np.array([0.02, 0.0, 0.02]), "estimate"))
    wing_pts = _wing_items(cfg)
    for side, m, pts in wing_pts:
        tot = float(m.sum())
        cgw = (m[:, None] * pts).sum(axis=0) / tot
        items.append(MassItem(f"{side} wing", "wing", tot, cgw, "estimate: CF spars + film membrane, see WingGeometry.mass"))

    M = sum(i.mass for i in items)
    cg = sum(i.mass * i.pos for i in items) / M
    I = np.zeros((3, 3))

    def add_point(m: float, p: np.ndarray) -> None:
        nonlocal I
        r = p - cg
        I += m * (np.dot(r, r) * np.eye(3) - np.outer(r, r))

    for i in items:
        if i.category == "wing":
            continue
        add_point(i.mass, i.pos)
    # distributed fuselage shell: slender rod along x
    fus = next((i for i in items if i.name == "fuselage structure"), None)
    if fus is not None:
        L = cfg.fuselage.length
        I[1, 1] += fus.mass * L * L / 12
        I[2, 2] += fus.mass * L * L / 12
    for _, m, pts in wing_pts:
        for mi, p in zip(m, pts):
            add_point(float(mi), p)
    return MassProperties(mass=M, cg=cg, inertia=I, items=items)


def set_total_mass(cfg: AircraftConfig, total: float) -> AircraftConfig:
    """Adjust the ballast item (at the current CG) so that the all-up mass equals `total`."""
    out = clone(cfg)
    ballast = next((c for c in out.components if c.category == "ballast"), None)
    if ballast is None:
        ballast = Component(name="ballast", category="ballast", mass=0.0, basis="user adjustable")
        out.components.append(ballast)
    ballast.mass = 0.0
    mp = mass_properties(out)
    extra = total - mp.mass
    if extra < 0:
        raise ValueError(f"requested mass {total:.3f} kg is below the empty build estimate {mp.mass:.3f} kg")
    ballast.mass = extra
    ballast.x, ballast.y, ballast.z = (float(v) for v in mp.cg)
    ballast.enabled = True
    return out
