"""Numerical integration: fixed-step RK4 and adaptive Dormand-Prince 5(4).

Controls are held constant over a step (zero-order hold from the controller).
The quaternion is renormalised after every step; the drift before
renormalisation is reported so numerical health can be monitored.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

Q = slice(6, 10)


def _renorm(x: np.ndarray) -> float:
    n = math.sqrt(float(x[Q] @ x[Q]))
    if not math.isfinite(n) or n < 1e-9:
        raise FloatingPointError("quaternion collapsed")
    x[Q] /= n
    return abs(n - 1.0)


@dataclass
class IntegratorStats:
    steps: int = 0
    rejected: int = 0
    rhs_evals: int = 0
    max_quat_drift: float = 0.0
    max_error_estimate: float = 0.0
    min_dt: float = math.inf
    max_dt: float = 0.0
    notes: list = field(default_factory=list)

    def as_dict(self):
        return {k: (v if not isinstance(v, float) or math.isfinite(v) else None) for k, v in self.__dict__.items()}


def rk4_step(f, t: float, x: np.ndarray, h: float, stats: IntegratorStats | None = None) -> np.ndarray:
    k1 = f(t, x)
    k2 = f(t + h / 2, x + h / 2 * k1)
    k3 = f(t + h / 2, x + h / 2 * k2)
    k4 = f(t + h, x + h * k3)
    xn = x + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
    d = _renorm(xn)
    if stats is not None:
        stats.steps += 1
        stats.rhs_evals += 4
        stats.max_quat_drift = max(stats.max_quat_drift, d)
        stats.min_dt = min(stats.min_dt, h)
        stats.max_dt = max(stats.max_dt, h)
    return xn


# Dormand-Prince coefficients
_C = [0, 1 / 5, 3 / 10, 4 / 5, 8 / 9, 1, 1]
_A = [
    [],
    [1 / 5],
    [3 / 40, 9 / 40],
    [44 / 45, -56 / 15, 32 / 9],
    [19372 / 6561, -25360 / 2187, 64448 / 6561, -212 / 729],
    [9017 / 3168, -355 / 33, 46732 / 5247, 49 / 176, -5103 / 18656],
    [35 / 384, 0, 500 / 1113, 125 / 192, -2187 / 6784, 11 / 84],
]
_B5 = np.array([35 / 384, 0, 500 / 1113, 125 / 192, -2187 / 6784, 11 / 84, 0])
_B4 = np.array([5179 / 57600, 0, 7571 / 16695, 393 / 640, -92097 / 339200, 187 / 2100, 1 / 40])


def dopri_integrate(f, t0: float, x0: np.ndarray, t1: float, h0: float, rtol: float, atol: float,
                    stats: IntegratorStats, h_max: float | None = None) -> tuple[np.ndarray, float]:
    """Integrate from t0 to t1 adaptively. Returns (x(t1), last accepted step size)."""
    t, x, h = t0, x0.copy(), h0
    h_max = h_max or (t1 - t0)
    while t < t1 - 1e-12:
        h = min(h, t1 - t, h_max)
        k = []
        for i in range(7):
            xi = x.copy()
            for j, a in enumerate(_A[i]):
                if a:
                    xi += h * a * k[j]
            k.append(f(t + _C[i] * h, xi))
        K = np.array(k)
        x5 = x + h * (_B5 @ K)
        x4 = x + h * (_B4 @ K)
        stats.rhs_evals += 7
        sc = atol + rtol * np.maximum(np.abs(x), np.abs(x5))
        err = math.sqrt(float(np.mean(((x5 - x4) / sc) ** 2)))
        if err <= 1.0 or h < 1e-7:
            t += h
            x = x5
            d = _renorm(x)
            stats.steps += 1
            stats.max_quat_drift = max(stats.max_quat_drift, d)
            stats.max_error_estimate = max(stats.max_error_estimate, err)
            stats.min_dt = min(stats.min_dt, h)
            stats.max_dt = max(stats.max_dt, h)
            fac = 0.9 * (1.0 / max(err, 1e-10)) ** 0.2
            h *= min(4.0, max(0.2, fac))
        else:
            stats.rejected += 1
            h *= max(0.2, 0.9 * (1.0 / err) ** 0.25)
    return x, h
