"""Crank-rocker (four-bar) flapping transmission.

Frontal plane (y outboard of the right wing, zu up), origin on the hinge plane:
  O4 = (hinge_y, 0)                wing hinge (rocker pivot)
  C  = (cy, cz)                    crank centre (output of the gearbox)
  A  = C + r2 (cos t, sin t)       crank pin
  B  = O4 - r4 (cos(phi+g), sin(phi+g))   end of the wing-root lever (inboard of hinge)
  |B - A| = r3                     coupler (connecting rod)

phi is the stroke angle, positive tip-up. Solving the loop closure for phi:
  D = O4 - A,  K = (|D|^2 + r4^2 - r3^2) / (2 r4)
  phi = atan2(Dz, Dy) - g +/- acos(K / |D|)
The linkage only assembles where |K| <= |D| for every crank angle.

Left wing: "dual_counter_rotating" gears give an exact mirror image;
"single_pin" drives both coupler rods from one crank pin, so the left side sees
the pin at the mirrored angle (pi - t) and runs with a phase/shape asymmetry.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.optimize import least_squares

from .config import AircraftConfig, MechanismConfig
from .kinematics import GRID, GridProfile

TWO_PI = 2 * math.pi


@dataclass
class FourBar:
    hinge_y: float
    cy: float
    cz: float
    r2: float
    r3: float
    r4: float
    gamma: float
    branch: int = -1

    def closure(self, t: np.ndarray):
        Ay = self.cy + self.r2 * np.cos(t)
        Az = self.cz + self.r2 * np.sin(t)
        Dy = self.hinge_y - Ay
        Dz = 0.0 - Az
        Dn = np.hypot(Dy, Dz)
        K = (Dn * Dn + self.r4 ** 2 - self.r3 ** 2) / (2 * self.r4)
        return Ay, Az, Dy, Dz, Dn, K

    def assembles(self, t: np.ndarray) -> bool:
        *_, Dn, K = self.closure(t)
        return bool(np.all(np.abs(K) <= Dn * (1 - 1e-9)))

    def phi(self, t: np.ndarray, branch: int | None = None) -> np.ndarray:
        b = self.branch if branch is None else branch
        Ay, Az, Dy, Dz, Dn, K = self.closure(t)
        ratio = np.clip(K / Dn, -1.0, 1.0)
        ph = np.arctan2(Dz, Dy) - self.gamma + b * np.arccos(ratio)
        return np.unwrap(ph) if np.ndim(ph) else ph

    def points(self, t: np.ndarray):
        Ay, Az, *_ = self.closure(t)
        ph = self.phi(t)
        By = self.hinge_y - self.r4 * np.cos(ph + self.gamma)
        Bz = -self.r4 * np.sin(ph + self.gamma)
        return Ay, Az, By, Bz, ph

    def transmission_angle(self, t: np.ndarray) -> np.ndarray:
        """Angle between coupler and rocker lever at B [rad]. 90 deg ideal; near 0/180 = toggle."""
        Ay, Az, By, Bz, _ = self.points(t)
        u = np.stack([Ay - By, Az - Bz])
        v = np.stack([self.hinge_y - By, 0.0 - Bz])
        cosm = (u * v).sum(0) / (np.linalg.norm(u, axis=0) * np.linalg.norm(v, axis=0))
        return np.arccos(np.clip(cosm, -1, 1))

    def grashof(self) -> dict:
        r1 = math.hypot(self.hinge_y - self.cy, self.cz)
        links = sorted([r1, self.r2, self.r3, self.r4])
        s, l, p, q = links[0], links[3], links[1], links[2]
        return {
            "ground_r1": r1,
            "grashof": s + l <= p + q,
            "crank_is_shortest": abs(s - self.r2) < 1e-12,
            "margin": (p + q) - (s + l),
        }


def _pick_branch(fb: FourBar, target_mean: float) -> int:
    t = np.linspace(0, TWO_PI, 361)
    best, bb = None, -1
    for b in (-1, 1):
        ph = fb.phi(t, b)
        err = abs(float(np.mean(ph)) - target_mean)
        if best is None or err < best:
            best, bb = err, b
    return bb


def synthesize(mc: MechanismConfig, hinge_y: float, amplitude: float, mean: float) -> FourBar:
    """Choose crank radius r2 and coupler length r3 so that the right wing strokes
    between mean - amplitude and mean + amplitude."""
    t = np.linspace(0, TWO_PI, 721)
    g = math.radians(mc.lever_bend_deg)
    r4 = mc.lever_length
    B0y = hinge_y - r4 * math.cos(mean + g)
    B0z = -r4 * math.sin(mean + g)
    r3_0 = math.hypot(B0y - mc.crank_center_y, B0z - mc.crank_center_z)
    r2_0 = max(r4 * math.sin(amplitude), 1e-4)

    def resid(v, branch):
        fb = FourBar(hinge_y, mc.crank_center_y, mc.crank_center_z, v[0], v[1], r4, g, branch)
        Ay, Az, Dy, Dz, Dn, K = fb.closure(t)
        pen = np.maximum(np.abs(K) - Dn * 0.999, 0).sum() * 100
        ph = fb.phi(t)
        return [ph.max() - (mean + amplitude) + pen, ph.min() - (mean - amplitude) + pen]

    best = None
    for branch in (-1, 1):
        sol = least_squares(resid, [r2_0, r3_0], args=(branch,), bounds=([1e-4, 1e-3], [0.05, 0.2]), xtol=1e-12, ftol=1e-12)
        if best is None or sol.cost < best[0].cost:
            best = (sol, branch)
    sol, branch = best
    return FourBar(hinge_y, mc.crank_center_y, mc.crank_center_z, sol.x[0], sol.x[1], r4, g, branch)


def build_linkages(cfg: AircraftConfig) -> tuple[FourBar, FourBar]:
    """Right and left (mirrored-frame) linkages."""
    mc = cfg.mechanism
    hy = cfg.hinge.y_offset
    st = cfg.kinematics.right
    if mc.synthesize:
        right = synthesize(mc, hy, math.radians(st.amplitude_deg), math.radians(st.mean_deg))
    else:
        right = FourBar(hy, mc.crank_center_y, mc.crank_center_z, mc.crank_radius, mc.coupler_length,
                        mc.lever_length, math.radians(mc.lever_bend_deg))
        right.branch = _pick_branch(right, math.radians(st.mean_deg))
    left = FourBar(hy, -mc.crank_center_y if mc.layout == "single_pin" else mc.crank_center_y, mc.crank_center_z,
                   right.r2, right.r3, right.r4, right.gamma, right.branch)
    return right, left


def left_angle(cfg: AircraftConfig, t: np.ndarray) -> np.ndarray:
    """Crank angle as seen in the left wing's mirrored frame."""
    ph = math.radians(cfg.mechanism.pin_phase_deg)
    if cfg.mechanism.layout == "single_pin":
        return math.pi - t + ph
    return t + ph


def mechanism_tables(cfg: AircraftConfig) -> dict[int, GridProfile]:
    """phi(theta) tables for both wings as functions of the crank angle. index 0 = left, 1 = right."""
    right, left = build_linkages(cfg)
    t = np.linspace(0, TWO_PI, GRID, endpoint=False)
    h = TWO_PI / GRID
    out = {}
    for side, fb, tt in ((1, right, t), (0, left, left_angle(cfg, t))):
        ph = fb.phi(tt)
        ph = ph - TWO_PI * np.round((ph.mean()) / TWO_PI)
        d1 = (np.roll(ph, -1) - np.roll(ph, 1)) / (2 * h)
        d2 = (np.roll(ph, -1) - 2 * ph + np.roll(ph, 1)) / (h * h)
        out[side] = GridProfile(ph, d1, d2, name="mechanism")
    return out


def analyse(cfg: AircraftConfig, n: int = 360, hinge_torque: dict | None = None) -> dict:
    """Simulation A: linkage motion, constraints and (optionally) loads over one crank revolution.

    hinge_torque: optional {"theta": [...], "left": [...], "right": [...]} actuator torque at the
    wing hinge [N m] (from a captive aerodynamic cycle) used to compute coupler and crank loads.
    """
    right, left = build_linkages(cfg)
    t = np.linspace(0, TWO_PI, n, endpoint=False)
    res: dict = {"crank_deg": np.degrees(t).tolist()}
    limits = math.radians(cfg.hinge.max_travel_deg)
    summary: dict = {}
    for name, fb, tt in (("right", right, t), ("left", left, left_angle(cfg, t))):
        ok = fb.assembles(tt)
        Ay, Az, By, Bz, ph = fb.points(tt)
        ph = ph - TWO_PI * np.round(ph.mean() / TWO_PI)
        mu = fb.transmission_angle(tt)
        dph = np.gradient(ph, t)
        down = dph < 0
        res[name] = {
            "phi_deg": np.degrees(ph).tolist(),
            "transmission_deg": np.degrees(mu).tolist(),
            "dphi_dtheta": dph.tolist(),
            "A": np.stack([Ay, Az], 1).round(6).tolist(),
            "B": np.stack([By, Bz], 1).round(6).tolist(),
        }
        summary[name] = {
            "assembles": ok,
            "phi_max_deg": float(np.degrees(ph.max())),
            "phi_min_deg": float(np.degrees(ph.min())),
            "amplitude_deg": float(np.degrees(ph.max() - ph.min()) / 2),
            "mean_deg": float(np.degrees((ph.max() + ph.min()) / 2)),
            "downstroke_fraction": float(down.mean()),
            "min_transmission_deg": float(np.degrees(min(mu.min(), math.pi - mu.max()))),
            "within_travel_limits": bool(np.all(np.abs(ph) <= limits)),
            **fb.grashof(),
        }
    summary["links_m"] = {"r2_crank": right.r2, "r3_coupler": right.r3, "r4_lever": right.r4,
                          "ground_r1": right.grashof()["ground_r1"]}
    summary["layout"] = cfg.mechanism.layout
    phase_r = np.degrees(t[np.argmax(res["right"]["phi_deg"])])
    phase_l = np.degrees(t[np.argmax(res["left"]["phi_deg"])])
    summary["left_right_top_of_stroke_lag_deg"] = float((phase_l - phase_r + 180) % 360 - 180)
    warnings = []
    for s in ("left", "right"):
        if not summary[s]["assembles"]:
            warnings.append(f"{s} linkage cannot assemble over the full crank revolution")
        if summary[s]["min_transmission_deg"] < 40:
            warnings.append(f"{s} transmission angle drops to {summary[s]['min_transmission_deg']:.0f} deg (<40 deg: high pin loads, near toggle)")
        if not summary[s]["within_travel_limits"]:
            warnings.append(f"{s} wing exceeds the {cfg.hinge.max_travel_deg:.0f} deg hinge stop")
        if not (summary[s]["grashof"] and summary[s]["crank_is_shortest"]):
            warnings.append(f"{s} linkage is not a Grashof crank-rocker")
    if abs(summary["left_right_top_of_stroke_lag_deg"]) > 2:
        warnings.append(f"left/right top-of-stroke lag {summary['left_right_top_of_stroke_lag_deg']:.1f} deg (asymmetric wingbeat -> roll/yaw excitation)")
    summary["warnings"] = warnings

    if hinge_torque is not None:
        th = np.radians(np.asarray(hinge_torque["theta_deg"]))
        loads = {}
        crank_total = np.zeros_like(t)
        for name, idx in (("right", 1), ("left", 0)):
            tau = np.interp(t, th, np.asarray(hinge_torque[name]), period=TWO_PI)
            dph = np.asarray(res[name]["dphi_dtheta"])
            mu = np.radians(np.asarray(res[name]["transmission_deg"]))
            coupler = np.abs(tau) / (right.r4 * np.maximum(np.abs(np.sin(mu)), 1e-3))
            crank = tau * dph
            crank_total += crank
            loads[name] = {"hinge_torque": tau.tolist(), "coupler_force": coupler.tolist(), "crank_torque": crank.tolist()}
            summary[name]["peak_coupler_force_N"] = float(coupler.max())
            summary[name]["peak_hinge_torque_Nm"] = float(np.abs(tau).max())
        loads["crank_total"] = crank_total.tolist()
        summary["peak_crank_torque_Nm"] = float(np.abs(crank_total).max())
        summary["rms_crank_torque_Nm"] = float(np.sqrt(np.mean(crank_total ** 2)))
        res["loads"] = loads
    res["summary"] = summary
    return res
