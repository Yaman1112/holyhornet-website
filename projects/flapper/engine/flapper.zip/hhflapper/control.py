"""Flight control (Simulation D/F): estimator, layered controller, mission manager.

Layering (see docs/engineering/CONTROL.md):
  L1 actuator   : wingbeat frequency/amplitude per wing, elevator, rudder (limits + rates)
  L2 attitude   : pitch -> elevator; bank -> rudder (+ differential amplitude if fitted); yaw damper
  L3 flight     : altitude -> pitch command; airspeed -> wingbeat frequency; heading -> bank command
  L4 navigation : waypoints, loiter, return-to-home, glide fail-safe

The body oscillates at the wingbeat frequency. Feedback signals pass through a
wingbeat-synchronous moving average (window = one stroke period) so the
controller acts on cycle-mean motion instead of fighting the flapping itself.
Baseline gains were tuned in simulation only.
"""
from __future__ import annotations

import collections
import math

import numpy as np

from .config import ControllerConfig
from .frames import quat_to_dcm, quat_to_euler, wrap_pi


class CycleAverager:
    """Moving average over exactly one wingbeat period (notches the wingbeat and its harmonics)."""

    def __init__(self, rate_hz: float):
        self.rate = rate_hz
        self.buf: collections.deque = collections.deque()
        self.sum = None

    def update(self, value: np.ndarray, freq_hz: float) -> np.ndarray:
        n = int(round(self.rate / freq_hz)) if freq_hz > 0.5 else int(self.rate / 2)
        n = max(1, min(n, int(self.rate)))
        v = np.asarray(value, dtype=float)
        self.buf.append(v)
        self.sum = v.copy() if self.sum is None else self.sum + v
        while len(self.buf) > n:
            self.sum -= self.buf.popleft()
        return self.sum / len(self.buf)


class Estimator:
    """'truth' passes the simulated true state; 'complementary' fuses simulated sensors.

    Complementary filter: gyro integration corrected toward the accelerometer tilt
    (with centripetal compensation using airspeed) and toward GNSS course for yaw.
    Altitude from barometer, vertical speed blended baro/accelerometer, position from
    GNSS with airspeed dead-reckoning when GNSS is lost.
    """

    def __init__(self, mode: str, x0: np.ndarray):
        self.mode = mode
        r, p, y = quat_to_euler(x0[6:10])
        self.att = np.array([r, p, y])
        self.alt = -x0[2]
        self.vz = 0.0
        self.pos = x0[0:3].copy()
        self.k_tilt = 0.3
        self.k_yaw = 0.2

    def update(self, dt: float, x: np.ndarray, meas: dict, true_diag: dict) -> dict:
        if self.mode == "truth":
            r, p, y = quat_to_euler(x[6:10] / np.linalg.norm(x[6:10]))
            R = quat_to_dcm(x[6:10] / np.linalg.norm(x[6:10]))
            vn = R @ x[3:6]
            return {"roll": r, "pitch": p, "yaw": y, "p": x[10], "q": x[11], "r": x[12], "alt": -x[2],
                    "vz_up": -vn[2], "airspeed": true_diag["airspeed"], "north": x[0], "east": x[1],
                    "gnss_valid": True, "source": "truth (simulation)"}
        g = meas["gyro"]
        roll, pitch, yaw = self.att
        # Euler kinematics with gyro
        cr, sr = math.cos(roll), math.sin(roll)
        tp = math.tan(pitch)
        roll += dt * (g[0] + (g[1] * sr + g[2] * cr) * tp)
        pitch += dt * (g[1] * cr - g[2] * sr)
        yaw += dt * (g[1] * sr + g[2] * cr) / max(math.cos(pitch), 0.1)
        # tilt from accelerometer, compensating centripetal acceleration w x V
        V = max(meas["airspeed"], 0.0)
        a = meas["accel"] - np.cross(g, np.array([V, 0.0, 0.0]))
        roll_a = math.atan2(-a[1], -a[2])
        pitch_a = math.atan2(a[0], math.hypot(a[1], a[2]))
        roll += self.k_tilt * dt * wrap_pi(roll_a - roll)
        pitch += self.k_tilt * dt * (pitch_a - pitch)
        gn = meas["gnss"]
        gnss_valid = bool(gn and gn.get("valid"))
        if gnss_valid:
            vn = gn["vel"]
            if math.hypot(vn[0], vn[1]) > 3.0:
                course = math.atan2(vn[1], vn[0])
                yaw += self.k_yaw * dt * wrap_pi(course - yaw)
            self.pos[0:2] += 0.5 * (np.array(gn["pos"][0:2]) - self.pos[0:2]) * min(1.0, dt * 5)
        else:
            self.pos[0] += dt * V * math.cos(yaw)
            self.pos[1] += dt * V * math.sin(yaw)
        self.att = np.array([wrap_pi(roll), pitch, wrap_pi(yaw)])
        # altitude: baro with a simple complementary vertical-speed estimate
        alt_prev = self.alt
        self.alt += 0.2 * (meas["baro_alt"] - self.alt)
        self.vz += 0.1 * ((self.alt - alt_prev) / dt - self.vz)
        return {"roll": self.att[0], "pitch": self.att[1], "yaw": self.att[2], "p": g[0], "q": g[1], "r": g[2],
                "alt": self.alt, "vz_up": self.vz, "airspeed": meas["airspeed"], "north": self.pos[0],
                "east": self.pos[1], "gnss_valid": gnss_valid, "source": "complementary filter on simulated sensors"}


class Controller:
    def __init__(self, cfg: ControllerConfig, trim: dict, actuators, kin, rate_hz: float, home=(0.0, 0.0)):
        self.c = cfg
        self.trim = trim
        self.act = actuators
        self.kin = kin
        self.dt = 1.0 / rate_hz
        self.avg = CycleAverager(rate_hz)
        self.i_alt = 0.0
        self.i_speed = 0.0
        self.mode = "waypoint" if cfg.waypoints else "hold"
        self.wp_index = 0
        self.home = home
        self.targets = {"altitude": cfg.altitude_cmd, "airspeed": cfg.airspeed_cmd or trim["airspeed"],
                        "heading": math.radians(cfg.heading_cmd_deg)}
        self.last_heartbeat = 0.0
        self.events: list[dict] = []
        self.motor_failed_detected = False
        self.v_mean = None  # running mean / variance of the cycle-averaged airspeed (gust estimate, CS-05)
        self.v_var = 0.0
        self.gust_margin = 0.0

    def log(self, t, msg, level="info"):
        self.events.append({"t": round(t, 3), "level": level, "msg": msg})

    def navigate(self, t: float, est: dict, health: dict) -> None:
        c = self.c
        if health.get("motor_failed") and self.mode != "glide":
            self.mode = "glide"
            self.log(t, "motor/flapping failure detected: switching to glide fail-safe (no powered recovery)", "critical")
        if self.mode not in ("glide", "rth") and t - self.last_heartbeat > c.comms_timeout_s and health.get("comms_lost"):
            self.mode = "rth"
            self.log(t, f"telemetry link lost > {c.comms_timeout_s:.0f} s: return-to-home", "warning")
        n, e = est["north"], est["east"]
        if self.mode == "waypoint":
            wp = c.waypoints[self.wp_index]
            dn, de = wp.north - n, wp.east - e
            if math.hypot(dn, de) < c.waypoint_radius:
                self.log(t, f"waypoint {self.wp_index + 1} reached")
                self.wp_index += 1
                if self.wp_index >= len(c.waypoints):
                    self.mode = "loiter"
                    self.loiter_center = (wp.north, wp.east)
                    self.log(t, "mission complete: loiter")
                    return
                wp = c.waypoints[self.wp_index]
                dn, de = wp.north - n, wp.east - e
            self.targets["heading"] = math.atan2(de, dn)
            self.targets["altitude"] = wp.altitude
            if wp.airspeed:
                self.targets["airspeed"] = wp.airspeed
        elif self.mode in ("loiter", "rth"):
            cn, ce = getattr(self, "loiter_center", self.home) if self.mode == "loiter" else self.home
            dn, de = n - cn, e - ce
            dist = math.hypot(dn, de)
            radial = math.atan2(de, dn)
            # steer to the circle tangent (clockwise) with radial correction
            err = (dist - c.loiter_radius) / c.loiter_radius
            self.targets["heading"] = wrap_pi(radial + math.pi / 2 + max(-1.0, min(1.0, err)) * 1.0)

    def update(self, t: float, est: dict, freq_now: float, health: dict) -> tuple[np.ndarray, dict]:
        c = self.c
        tr = self.trim
        self.navigate(t, est, health)
        sig = np.array([est["roll"], est["pitch"], est["p"], est["q"], est["r"], est["vz_up"], est["airspeed"]])
        roll, pitch, p, q, r, vz, V = self.avg.update(sig, max(freq_now, 0.5))
        alt = est["alt"]
        yaw = est["yaw"]
        u = np.array(tr["controls"], dtype=float)
        if len(u) < 10:
            u = np.concatenate([u, np.zeros(10 - len(u))])

        # L3 altitude -> pitch command
        e_alt = self.targets["altitude"] - alt
        if self.mode == "glide":
            # glide: hold the trim airspeed with pitch (nose down when slow), no powered recovery exists
            v_g = self.targets["airspeed"]
            theta_cmd = math.radians(tr["pitch_deg"] + c.glide_pitch_offset_deg) + c.k_glide_speed * (V - v_g)
        else:
            self.i_alt = max(-0.15, min(0.15, self.i_alt + c.k_alt_i * e_alt * self.dt))
            theta_cmd = math.radians(tr["pitch_deg"]) + c.k_alt * e_alt - c.k_vz * vz + self.i_alt
        lim = math.radians(c.pitch_limit_deg)
        # envelope protection: below v_protect, airspeed has priority over altitude
        v_prot = c.v_protect if c.v_protect is not None else 0.93 * self.targets["airspeed"]
        self.protecting = V < v_prot and self.mode != "glide"
        if self.protecting:
            theta_cmd -= c.k_v_protect * (v_prot - V)
            self.i_alt = min(self.i_alt, 0.0)  # do not wind up a climb demand while slow
        # climb-rate limit: the pitch command may not ask for more than climb_rate_limit
        if vz > c.climb_rate_limit:
            theta_cmd = min(theta_cmd, math.radians(tr["pitch_deg"]))
        theta_cmd = max(-lim, min(lim, theta_cmd))
        # L2 pitch -> elevator (+ TE down = nose down)
        de = math.radians(tr["elevator_deg"]) - c.k_theta * (theta_cmd - pitch) + c.k_q * q
        # turbulence estimate: running std of the cycle-averaged airspeed -> speed margin (CS-05)
        a_g = min(1.0, self.dt / c.gust_window_s)
        if self.v_mean is None:
            self.v_mean = V
        self.v_mean += a_g * (V - self.v_mean)
        self.v_var += a_g * ((V - self.v_mean) ** 2 - self.v_var)
        self.gust_sigma = math.sqrt(max(self.v_var, 0.0))
        self.gust_margin = min(c.gust_margin_max, c.gust_margin_gain * max(self.gust_sigma - c.gust_sigma_floor, 0.0))
        # L3 airspeed -> frequency
        e_v = self.targets["airspeed"] + self.gust_margin - V
        if self.mode == "glide":
            f = 0.0
        else:
            self.i_speed = max(-1.5, min(1.5, self.i_speed + c.k_speed_i * e_v * self.dt))
            f = tr["frequency_hz"] + c.k_speed * e_v + self.i_speed
            f = max(c.freq_min_hz, min(c.freq_max_hz, f))
        # L3 heading -> bank command
        e_psi = wrap_pi(self.targets["heading"] - yaw)
        blim = math.radians(c.bank_limit_deg)
        if getattr(self, "protecting", False):
            blim = min(blim, math.radians(c.bank_limit_protect_deg))
        bank_cmd = max(-blim, min(blim, c.k_heading * e_psi))
        # L2 lateral: rudder (+ TE left = nose left). Bank right needs nose right -> negative rudder.
        dr = -c.k_bank_rudder * (bank_cmd - roll) + c.k_p_rudder * p + c.k_r_damper * r
        u[0:2] = f
        if self.act.differential_amplitude:
            dA = -math.radians(c.k_bank_amp) * (bank_cmd - roll) + math.radians(c.k_p_amp) * p
            dA = max(-math.radians(10), min(math.radians(10), dA))
            u[2] = math.radians(self.kin.left.amplitude_deg) - dA / 2
            u[3] = math.radians(self.kin.right.amplitude_deg) + dA / 2
        roll_fx = self.act.differential_twist or self.act.differential_mean
        if roll_fx:
            # with a direct roll effector the rudder only coordinates / damps yaw
            dr = -c.k_bank_rudder_with_roll_effector * (bank_cmd - roll) + c.k_r_damper * r
            lim = math.radians(c.roll_effector_limit_deg)
            step = math.radians(self.act.roll_servo_rate_dps) * self.dt
        if self.act.differential_twist:
            # + bias = right wing nose-up = more right-wing lift = roll LEFT; so bank right needs negative bias
            cmd = -math.radians(c.k_bank_twist) * (bank_cmd - roll) + math.radians(c.k_p_twist) * p
            cmd = max(-lim, min(lim, cmd))
            prev = getattr(self, "_dt_twist", 0.0)
            self._dt_twist = prev + max(-step, min(step, cmd - prev))
            u[9] = self._dt_twist
        if self.act.differential_mean:
            cmd = -math.radians(c.k_bank_mean) * (bank_cmd - roll) + math.radians(c.k_p_mean) * p
            cmd = max(-lim, min(lim, cmd))
            prev = getattr(self, "_dt_mean", 0.0)
            self._dt_mean = prev + max(-step, min(step, cmd - prev))
            u[4] = math.radians(self.kin.left.mean_deg) - self._dt_mean / 2
            u[5] = math.radians(self.kin.right.mean_deg) + self._dt_mean / 2
        u[6] = de if self.act.elevator else 0.0
        u[7] = dr if self.act.rudder else 0.0
        # motor-crank drive: ESC governor holds the commanded crank frequency (PI on measured frequency)
        e_f = f - freq_now
        if not hasattr(self, "thr_i"):
            self.thr_i = 0.6
        if self.mode != "glide":
            self.thr_i = max(0.0, min(1.0, self.thr_i + c.k_gov_i * e_f * self.dt))
        u[8] = max(0.0, min(1.0, self.thr_i + c.k_gov_p * e_f)) if self.mode != "glide" else 0.0
        self.throttle_saturated = u[8] >= 0.999
        info = {"mode": self.mode + (" (speed protection)" if getattr(self, "protecting", False) else ""), "theta_cmd_deg": math.degrees(theta_cmd), "bank_cmd_deg": math.degrees(bank_cmd),
                "heading_cmd_deg": math.degrees(self.targets["heading"]), "altitude_cmd": self.targets["altitude"],
                "airspeed_cmd": self.targets["airspeed"] + self.gust_margin, "wp_index": self.wp_index,
                "gust_sigma": getattr(self, "gust_sigma", 0.0), "gust_margin": self.gust_margin,
                "filtered": {"roll": roll, "pitch": pitch, "airspeed": V, "vz": vz}}
        return u, info
