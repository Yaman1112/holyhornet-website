"""Model versioning for reproducibility.

Every stored result records `__version__`, the per-submodel versions below and a
SHA-256 over the package source, so a result can always be traced to the exact
code that produced it.
"""
from __future__ import annotations

import functools
import hashlib
import pathlib

__version__ = "0.1.0"

MODEL_VERSIONS = {
    "kinematics": "kin-1.0 (sinusoid / asymmetric / table / four-bar)",
    "mechanism": "fourbar-1.0 (planar crank-rocker, rigid links, frictionless pins)",
    "aerodynamics": "us-bem-1.1 (blade element + Wagner/Jones circulatory lag per strip + added mass + pitch-rate; qs-bem-1.0 when unsteady=False)",
    "structure": "rom-1.0 (1 bending + 1 torsion mode per wing)",
    "dynamics": "6dof-quat-1.0 (rigid body, constant inertia, first-order wing inertial reaction)",
    "drive": "drive-1.0 (prescribed-frequency actuator or DC motor + gearbox + crank)",
    "power": "pwr-1.0 (LiPo OCV curve + internal resistance, no regeneration)",
    "sensors": "sens-1.0 (white noise + constant bias, sample-and-hold)",
    "control": "cascade-pid-1.0",
}


@functools.lru_cache(maxsize=1)
def source_hash() -> str:
    root = pathlib.Path(__file__).parent
    h = hashlib.sha256()
    for p in sorted(root.rglob("*.py")):
        if "api" in p.parts or p.name == "browser.py":  # transport layers, not model code
            continue
        h.update(p.relative_to(root).as_posix().encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def model_version() -> dict:
    return {"package": __version__, "source_sha256": source_hash(), "submodels": MODEL_VERSIONS}
