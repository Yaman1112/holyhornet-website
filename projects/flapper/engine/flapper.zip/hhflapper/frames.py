"""Coordinate frames and attitude mathematics.

Conventions (see docs/engineering/CONVENTIONS.md):
  * Inertial frame: local NED (x north, y east, z down), flat non-rotating Earth.
  * Body frame: FRD (x forward, y right wing, z down), origin at the aircraft CG
    with wings at their mean stroke position.
  * Quaternion q = [w, x, y, z] (Hamilton, scalar first) rotates body -> NED:
        v_ned = R(q) @ v_body
  * Euler angles are ZYX (yaw psi, pitch theta, roll phi) and are produced only
    for display / operator interpretation. Integration uses quaternions.
"""
from __future__ import annotations

import math

import numpy as np

QUAT_NORM_TOL = 1e-6


def quat_normalize(q: np.ndarray) -> np.ndarray:
    n = math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3])
    if not math.isfinite(n) or n < 1e-12:
        raise FloatingPointError("quaternion norm is zero or not finite")
    return q / n


def quat_to_dcm(q: np.ndarray) -> np.ndarray:
    """Rotation matrix body -> NED for a unit quaternion."""
    w, x, y, z = q
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
            [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
            [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
        ]
    )


def quat_derivative(q: np.ndarray, omega_b: np.ndarray) -> np.ndarray:
    """q_dot = 0.5 * q (x) [0, omega] for body-frame angular velocity."""
    w, x, y, z = q
    p, qq, r = omega_b
    return 0.5 * np.array(
        [
            -x * p - y * qq - z * r,
            w * p + y * r - z * qq,
            w * qq - x * r + z * p,
            w * r + x * qq - y * p,
        ]
    )


def quat_multiply(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array(
        [
            aw * bw - ax * bx - ay * by - az * bz,
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
        ]
    )


def euler_to_quat(roll: float, pitch: float, yaw: float) -> np.ndarray:
    """ZYX Euler angles [rad] -> quaternion (body -> NED)."""
    cr, sr = math.cos(roll / 2), math.sin(roll / 2)
    cp, sp = math.cos(pitch / 2), math.sin(pitch / 2)
    cy, sy = math.cos(yaw / 2), math.sin(yaw / 2)
    return np.array(
        [
            cr * cp * cy + sr * sp * sy,
            sr * cp * cy - cr * sp * sy,
            cr * sp * cy + sr * cp * sy,
            cr * cp * sy - sr * sp * cy,
        ]
    )


def quat_to_euler(q: np.ndarray) -> tuple[float, float, float]:
    """Quaternion -> (roll, pitch, yaw) [rad], ZYX. Display only."""
    w, x, y, z = q
    roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    s = 2 * (w * y - z * x)
    pitch = math.copysign(math.pi / 2, s) if abs(s) >= 1 else math.asin(s)
    yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    return roll, pitch, yaw


def rot_x(a: float) -> np.ndarray:
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def wrap_pi(a: float) -> float:
    return (a + math.pi) % (2 * math.pi) - math.pi
