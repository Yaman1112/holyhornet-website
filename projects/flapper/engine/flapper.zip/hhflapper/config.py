"""Aircraft, environment and simulation configuration.

Every numeric default is an *estimate* for the HF-1 research baseline. The
`basis` strings say where each estimate comes from. Nothing here is a measured
value: there is no hardware yet. Units are SI unless the field name says
otherwise (``*_deg`` in degrees, ``*_hz`` in hertz, ``*_ah`` in amp-hours).
"""
from __future__ import annotations

import copy
import datetime as _dt
from typing import Literal, Optional

from pydantic import BaseModel, Field


class Component(BaseModel):
    name: str
    category: str
    mass: float = Field(ge=0, description="kg")
    x: float = Field(0.0, description="m, forward of datum (datum = wing hinge line, root LE plane)")
    y: float = 0.0
    z: float = Field(0.0, description="m, down positive")
    basis: str = "estimate"
    enabled: bool = True


class WingGeometry(BaseModel):
    semi_span: float = Field(0.42, gt=0.05, lt=1.5, description="hinge-to-tip span of one wing [m]")
    root_chord: float = Field(0.20, gt=0.02, lt=0.6)
    tip_chord: float = Field(0.10, gt=0.0, lt=0.6)
    le_root_x: float = Field(0.05, description="x of the root leading edge relative to datum [m]")
    sweep_deg: float = Field(0.0, ge=-30, le=45, description="leading-edge sweep")
    incidence_deg: float = Field(4.0, ge=-10, le=20, description="root geometric pitch relative to body x")
    washout_deg: float = Field(3.0, ge=-10, le=20, description="linear geometric twist, tip nose-down")
    camber: float = Field(0.03, ge=0, le=0.12, description="max camber / chord (membrane under load)")
    mass: float = Field(0.020, gt=0, lt=0.3, description="kg, one wing: 6/5 mm CFRP torque tube (5.6 g) + battens + membrane (estimate)")
    chordwise_cg: float = Field(0.35, ge=0.05, le=0.8, description="mass centre as fraction of chord from LE")
    n_strips: int = Field(10, ge=3, le=40)
    cd0: float = Field(0.03, ge=0.005, le=0.2, description="section profile drag (membrane, low Re)")
    oswald: float = Field(0.85, ge=0.4, le=1.0)
    stall_deg: float = Field(14.0, ge=5, le=30)


class AeroConfig(BaseModel):
    """Unsteady (circulatory) lift: Wagner indicial response, R.T. Jones two-pole approximation
    phi(s) = 1 - A1 exp(-b1 s) - A2 exp(-b2 s), s = 2 V t / c (semichords travelled)."""
    unsteady: bool = Field(True, description="Wagner lift lag on every strip; False = quasi-steady (qs-bem-1.0)")
    wagner_A1: float = 0.165
    wagner_b1: float = 0.0455
    wagner_A2: float = 0.335
    wagner_b2: float = 0.300


class StructureConfig(BaseModel):
    enabled: bool = True
    spar_EI: float = Field(1.0, gt=0, description="leading-edge spar bending stiffness [N m^2]")
    torsion_k: float = Field(0.6, gt=0, description="series-elastic twist stiffness at the tip [N m/rad]: root torsion spring in series with the torque tube (D-02; 0.6 from co-optimisation DS-03); measure with MECH-04")
    elastic_axis: float = Field(0.08, ge=0, le=0.5, description="twist axis, fraction of chord from LE")
    bending_zeta: float = Field(0.05, ge=0, le=1)
    torsion_zeta: float = Field(0.08, ge=0, le=1)


class HingeConfig(BaseModel):
    y_offset: float = Field(0.03, ge=0, le=0.2, description="lateral hinge offset from centreline [m]")
    z: float = Field(-0.01, description="hinge height (down +) relative to datum [m]")
    max_travel_deg: float = Field(55.0, description="mechanical stop, |phi| limit")


class Stroke(BaseModel):
    frequency_hz: float = Field(5.0, ge=0, le=20)
    amplitude_deg: float = Field(28.0, ge=0, le=60, description="stroke amplitude (28 deg from DS-03)")
    mean_deg: float = Field(5.0, ge=-30, le=30, description="mean stroke angle phi0 (acts as dihedral)")
    phase_deg: float = Field(0.0, ge=-360, le=360, description="delta in phi = phi0 + A sin(2 pi f t + delta)")


class KinematicsConfig(BaseModel):
    drive: Literal["prescribed", "motor_crank"] = "prescribed"
    profile: Literal["sinusoid", "asymmetric", "table", "mechanism"] = Field("mechanism", description="stroke shape; mechanism = four-bar output (baseline since D-02)")
    left: Stroke = Stroke()
    right: Stroke = Stroke()
    downstroke_fraction: float = Field(0.5, ge=0.2, le=0.8, description="asymmetric profile only")
    table: list[float] = Field(default_factory=list, description="one recorded period of normalised stroke in [-1, 1]")
    frequency_time_constant: float = Field(0.15, gt=0, description="prescribed-drive frequency lag [s]")
    twist_amplitude_deg: float = Field(21.75, ge=0, le=45, description="driven tip twist amplitude (linear along span); 0 = passive only. DS-01 needed ~30 deg (ideal); DS-03 co-optimum 21.75 deg")
    twist_source: Literal["harmonic", "linkage"] = Field("linkage", description="harmonic = ideal TA cos(theta+lead); linkage = solved torque-tube push-rod linkage")
    twist_root_fraction: float = Field(0.0, ge=0, le=1, description="driven-twist spanwise shape w0 + (1-w0) r/R: 0 = tip-driven linear twist, 1 = uniform root feathering")
    twist_phase_deg: float = Field(-28.75, ge=-180, le=180, description="lead of the twist relative to nose-down at mid-downstroke")


class MechanismConfig(BaseModel):
    layout: Literal["dual_counter_rotating", "single_pin"] = "dual_counter_rotating"
    crank_center_y: float = Field(-0.003, description="frontal-plane crank centre, lateral [m] (-3 mm: quick-return 0.514, DS-03)")
    crank_center_z: float = Field(-0.030, description="frontal-plane crank centre height, up + [m]")
    lever_length: float = Field(0.016, gt=0.002, le=0.06, description="wing-root lever arm r4 [m]")
    lever_bend_deg: float = Field(-20.5, description="lever bend; DS-03 (min transmission angle 42.9 deg, limit 40)")
    crank_radius: float = Field(0.006, gt=0.0005, le=0.05, description="r2 [m]")
    coupler_length: float = Field(0.031, gt=0.005, le=0.15, description="r3 [m]")
    pin_phase_deg: float = 0.0
    synthesize: bool = Field(True, description="solve r2, r3 for the right-wing stroke amplitude/mean")


class TwistLinkageConfig(BaseModel):
    """Rotating leading-edge torque tube + root pitch horn + push rod from a crank-shaft eccentric (D-01/DS-02)."""
    ecc_y: float = Field(0.03, description="eccentric (1:1 idler shaft) centre, lateral, frontal plane [m]; under the hinge")
    ecc_z: float = Field(-0.035, description="eccentric centre height, z_u up from the hinge plane [m]")
    horn_length: float = Field(0.015, gt=0.003, le=0.05, description="pitch horn arm, on the flap axis, pointing aft [m]")
    tube_od: float = Field(0.006, gt=0.002, le=0.02, description="torque-tube outer diameter [m]")
    tube_id: float = Field(0.005, ge=0.0, le=0.019, description="torque-tube inner diameter [m]")
    tube_shear_modulus: float = Field(20e9, gt=0, description="Pa; estimate for +/-45 deg roll-wrapped CFRP tube (measure: MECH-04)")
    tube_density: float = Field(1550.0, gt=0)
    hardware_mass: float = Field(0.012, ge=0, description="kg, both sides: horns, rods, ball links, pitch bearings, eccentric (estimate)")


class HingeSpringConfig(BaseModel):
    """Elastic energy storage (DS-06): a spring at each wing hinge, in parallel with the drive.
    Actuator torque = required hinge torque + k (phi - phi_n). Internal to the airframe: it does not change
    aerodynamics or body dynamics, only what the crank and motor must supply."""
    enabled: bool = Field(True, description="fitted since rev 7 (DS-06), replacing the motor flywheel")
    stiffness_Nm_per_rad: float = Field(1.0, ge=0, description="per wing; DS-06 optimum basin 0.75-1.25 (wing-inertia resonance ~1.33)")
    neutral_deg: float = Field(-5.0, description="spring-neutral stroke angle: 10 deg below the mean stroke, preload balancing the mean lift moment")
    energy_density_J_per_kg: float = Field(300.0, gt=0, description="usable fatigue-rated energy density, CFRP leaf (estimate)")
    mount_mass: float = Field(0.001, ge=0, description="kg per wing")
    hysteresis: float = Field(0.03, ge=0, le=0.5, description="fraction of peak stored energy lost per stroke (estimate)")


class ParkConfig(BaseModel):
    """Wing park after loss of drive (risk R-09): the wings must stop in a known, good glide configuration.

    release (rev 8, DS-04b): when the flight controller declares motor failure, one small servo moves a release
    bar that trips two sears: one frees the idler-eccentric end of both twist push rods (driven twist returns to
    zero; the roll bellcrank still acts), the other frees the ground anchor of both hinge springs. Aerodynamic lift
    then carries the wings up and the crank settles by itself near the top-of-stroke dead centre (~237 deg),
    where the four-bar reacts the wing loads: glide L/D 6.0 at 12 m/s, 5.45 at 14 m/s (motor-crank model),
    for release delays 0.1-0.6 s and any failure phase. Without release the crank stops within ~0.1 s and
    the springs pull it to ~357 deg with the twist frozen nose-down (L/D 2.5); releasing only the springs
    leaves that state stable in 15 of 18 tested cases.
    cam_detent (rev 5-7, DS-04): spring roller on a cam, centrifugally disengaged. Found unworkable in DS-04b:
    the crank stops within ~0.1 s of drive loss and never spins down through the park angle, a 1 Hz flyweight
    cannot lift the roller, and the detent is too weak to hold against the hinge springs.
    The prescribed drive idealises the park as a kinematic capture at crank_deg; motor_crank resolves it."""
    enabled: bool = Field(True, description="fitted since rev 5 (DS-04)")
    mechanism: Literal["release", "cam_detent"] = Field("release", description="rev 8: twist + hinge-spring release (DS-04b)")
    crank_deg: float = Field(237.0, description="park crank angle: natural rest after release (near top dead centre, DS-04b); the prescribed drive holds it kinematically")
    release_delay_s: float = Field(0.1, ge=0, description="servo + sear actuation after failure is declared (estimate)")
    capture_hz: float = Field(4.0, gt=0, description="prescribed-drive idealised capture dynamics, natural frequency")
    capture_zeta: float = Field(0.7, gt=0)
    detent_torque_Nm: float = Field(0.35, ge=0, description="cam_detent only: capacity at the crank (DS-04/DS-06)")
    lobe_deg: float = Field(40.0, gt=0, description="cam_detent only")
    hysteresis: float = Field(0.25, ge=0, le=1, description="cam_detent only: fraction of detent spring energy lost per pass (estimate)")
    centrifugal_disengage_hz: float = Field(1.0, ge=0, description="cam_detent only: roller lifted above this crank speed (0 = always engaged)")
    mass: float = Field(0.0056, ge=0, description="kg: release servo EMAX ES9051 4.1 g (listing) + release bar and two sears 1.5 g (estimate)")


class TailConfig(BaseModel):
    h_area: float = Field(0.022, gt=0)
    h_span: float = Field(0.25, gt=0)
    h_arm: float = Field(0.32, gt=0, description="CG to horizontal-tail aerodynamic centre [m]")
    h_z: float = Field(-0.01)
    h_incidence_deg: float = 0.0
    elevator_tau: float = Field(0.5, ge=0, le=1, description="flap effectiveness d(alpha)/d(delta)")
    elevator_max_deg: float = 25.0
    v_area: float = Field(0.012, gt=0)
    v_height: float = Field(0.12, gt=0)
    v_arm: float = Field(0.32, gt=0)
    v_z: float = Field(-0.05)
    rudder_tau: float = Field(0.5, ge=0, le=1)
    rudder_max_deg: float = 25.0
    cd0: float = 0.02
    mass: float = Field(0.015, ge=0)


class FuselageConfig(BaseModel):
    length: float = Field(0.48, gt=0.1, le=1.2)
    cda: float = Field(0.0015, ge=0, description="drag area Cd*A [m^2]")


class MotorConfig(BaseModel):
    kv_rpm_per_v: float = Field(1585.0, gt=0, description="Scorpion SII-2205-1585KV V2 (listing; rated 2-3S). Component selection: 3S with a re-matched 30:1 gearbox (2S is voltage/current squeezed, fails 14 m/s dynamically)")
    resistance: float = Field(0.182, gt=0, description="winding resistance [ohm], Scorpion listing Rm")
    no_load_current: float = Field(0.47, ge=0, description="A @10 V, Scorpion listing Io")
    max_current: float = Field(10.0, gt=0, description="A, Scorpion listing max continuous current")
    rotor_inertia: float = Field(2e-7, gt=0, description="kg m^2, rotor only (rev 7: flywheel replaced by hinge springs, DS-06)")
    gear_ratio: float = Field(34.0, gt=1, description="34:1 on 3S (CS-05): vs 30:1, 4x less time at the 10 A limit and -20% RMS current in turbulence for +1.7% cruise power; holds 14 m/s at 20% SoC (throttle 0.87)")
    gear_efficiency: float = Field(0.75, gt=0.1, le=1)
    crank_inertia: float = Field(2e-6, gt=0, description="crank-side gear + crank inertia [kg m^2]")
    esc_efficiency: float = Field(0.92, gt=0.3, le=1)
    thermal_resistance: float = Field(6.9, gt=0, description="winding-to-ambient [K/W]; NOT published, mass-scaled estimate for the 35 g motor")
    thermal_capacity: float = Field(15.0, gt=0, description="J/K; NOT published, estimate ~0.45 J/(g K) x 35 g")
    max_temp_c: float = 100.0
    mass: float = Field(0.0354, ge=0, description="kg, listing; informational (mass budget uses the component list)")


class BatteryConfig(BaseModel):
    chemistry: str = "LiPo"
    cells: int = Field(3, ge=1, le=6, description="3S: motor rated 2-3S, ESC 2-6S, FC 6.8-30 V input")
    capacity_ah: float = Field(0.65, gt=0.05, le=10)
    cell_resistance: float = Field(0.02, gt=0)
    usable_fraction: float = Field(0.8, gt=0.1, le=1.0, description="reserve kept for landing / cell health")
    max_c_rate: float = Field(30.0, gt=0, description="derated design limit; listing states 75C continuous")
    min_cell_voltage: float = 3.3
    mass: float = Field(0.059, gt=0, description="Tattu 650 mAh 3S1P 75C XT30: 59 g (getfpv.com listing, retrieved 2026-11-15); Overlander 3S 650 50C lists 57 g")


class AvionicsPower(BaseModel):
    flight_computer_w: float = 0.8
    sensors_w: float = 0.35
    telemetry_w: float = 0.6
    servos_w: float = 0.6
    camera_w: float = 1.0
    camera_enabled: bool = False


class ActuatorSet(BaseModel):
    """Which control effectors physically exist. Allocation honours this."""
    elevator: bool = True
    rudder: bool = True
    differential_amplitude: bool = False
    differential_frequency: bool = False
    differential_mean: bool = False
    differential_twist: bool = Field(True, description="servo trims the twist push rods: left/right twist bias (wing warping); fitted since rev 4 (CS-02)")
    roll_servo_arrangement: Literal["differential_bellcrank", "inline_per_rod", "bellcrank_lead_screw"] = Field(
        "differential_bellcrank", description="CS-03: one servo on a differential bellcrank; symmetric rod loads cancel at the servo")
    roll_servo_rate_dps: float = Field(600.0, gt=0, description="roll-effector servo slew limit [deg/s]; CS-03: no handling penalty down to 50 deg/s")
    roll_servo_mass: float = Field(0.0041, ge=0, description="kg: EMAX ES9051 (4.1 g listing); CS-03 load < 2% of its 0.08 N m stall")


class SensorConfig(BaseModel):
    gyro_noise: float = Field(0.003, description="rad/s, 1-sigma per sample at control rate")
    gyro_bias: float = Field(0.004, description="rad/s, 1-sigma initial bias")
    accel_noise: float = Field(0.05, description="m/s^2 1-sigma")
    accel_bias: float = Field(0.05)
    baro_noise: float = Field(0.3)
    airspeed_noise: float = Field(0.25)
    gnss_rate_hz: float = 5.0
    gnss_pos_noise: float = 1.2
    gnss_vel_noise: float = 0.1
    encoder_resolution_deg: float = 0.35
    seed: int = 1


def default_components() -> list[Component]:
    est = "estimate: typical hobby-class item of this function; replace with datasheet/scale weight"
    return [
        Component(name="fuselage structure", category="structure", mass=0.055, x=-0.05, z=0.0, basis="estimate: CF tube boom + printed PETG bulkheads"),
        Component(name="flapping motor: Scorpion SII-2205-1585KV V2", category="propulsion", mass=0.0354, x=0.06, z=0.01,
                  basis="retailer/manufacturer listing, retrieved 2026-11-15: 35.4 g, Kv 1585, Rm 0.182 ohm, Io 0.47 A @10 V (gravesrc.com)"),
        Component(name="gearbox + crank", category="propulsion", mass=0.032, x=0.02, z=0.02, basis="estimate: two-stage spur reduction, nylon gears, steel pins"),
        Component(name="motor-shaft flywheel", category="propulsion", mass=0.008, x=0.06, z=0.01, basis="DS-05b option; removed in rev 7 (hinge springs do the job lighter, DS-06)", enabled=False),
        Component(name="ESC: Holybro Tekko32 F4 45A (AM32)", category="electronics", mass=0.0058, x=0.04, z=0.0,
                  basis="retailer/manufacturer listing, retrieved 2026-11-15: 5.8 g net, 2-6S, telemetry to FC (oversized current rating; lightest with confirmed telemetry)"),
        Component(name="flight controller: Matek H743-WLITE", category="electronics", mass=0.022, x=0.0, z=0.0,
                  basis="retailer/manufacturer listing, retrieved 2026-11-15: 22 g incl. USB/buzzer adapter (mateksys.com); ICM-42688-P, DPS310, 7 UART, 12 PWM, 6.8-30 V input"),
        Component(name="GNSS + compass: Matek M10Q-5883", category="electronics", mass=0.008, x=0.01, z=-0.02,
                  basis="retailer/manufacturer listing, retrieved 2026-11-15: ~8 g (listings conflict 7.5/8 g), u-blox M10, 5 Hz UBX"),
        Component(name="RC link + telemetry: RadioMaster RP1 V2 (ExpressLRS)", category="electronics", mass=0.0022, x=-0.04, z=0.0,
                  basis="retailer/manufacturer listing, retrieved 2026-11-15: 2.2 g incl. antenna (radiomasterrc.com); CRSF to FC, 10 mW telemetry (no native MAVLink confirmed)"),
        Component(name="airspeed: Matek ASPD-4525 + pitot", category="electronics", mass=0.0055, x=0.15, z=0.0,
                  basis="retailer/manufacturer listing, retrieved 2026-11-15: 3.5 g board (MS4525DO, I2C) + ~2 g pitot/tubing (estimate)"),
        Component(name="tail servos: 2x EMAX ES9051", category="actuation", mass=0.0082, x=-0.20, z=0.0,
                  basis="retailer/manufacturer listing, retrieved 2026-11-15: 4.1 g each, 0.8 kgf cm, 0.09 s/60 deg @4.8 V (plastic gears; one retailer lists it discontinued)"),
        Component(name="wing-angle encoders: 2x AS5048A + magnets", category="electronics", mass=0.002, x=0.0, z=0.0,
                  basis="AS5048A datasheet: 14-bit (0.022 deg), SPI/PWM; board + magnet mass estimated 1 g each"),
        Component(name="wiring + connectors", category="electronics", mass=0.015, x=0.02, z=0.0, basis="estimate: ~5% of all-up mass"),
        Component(name="camera", category="payload", mass=0.010, x=0.16, z=0.01, basis=est, enabled=False),
        Component(name="ballast", category="ballast", mass=0.0, x=0.0, z=0.0, basis="user adjustable"),
    ]


class AircraftConfig(BaseModel):
    config_id: str = "HF1-BASELINE"
    revision: int = 1
    name: str = "HF-1 research baseline"
    author: str = "HolyHornet engineering"
    created: str = Field(default_factory=lambda: _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"))
    validation_status: str = "unvalidated: simulation only, no physical measurements"
    notes: str = ""
    wing_left: WingGeometry = WingGeometry()
    wing_right: WingGeometry = WingGeometry()
    aerodynamics: AeroConfig = AeroConfig()
    structure: StructureConfig = StructureConfig()
    hinge: HingeConfig = HingeConfig()
    kinematics: KinematicsConfig = KinematicsConfig()
    mechanism: MechanismConfig = MechanismConfig()
    twist_linkage: TwistLinkageConfig = TwistLinkageConfig()
    park: ParkConfig = ParkConfig()
    hinge_spring: HingeSpringConfig = HingeSpringConfig()
    tail: TailConfig = TailConfig()
    fuselage: FuselageConfig = FuselageConfig()
    motor: MotorConfig = MotorConfig()
    battery: BatteryConfig = BatteryConfig()
    avionics: AvionicsPower = AvionicsPower()
    actuators: ActuatorSet = ActuatorSet()
    sensors: SensorConfig = SensorConfig()
    components: list[Component] = Field(default_factory=default_components)
    assumptions: list[str] = Field(
        default_factory=lambda: [
            "All masses are estimates of hobby-class components; no part is selected or weighed.",
            "Aerodynamics: quasi-steady blade-element model with added mass; no wake memory (see AERO_MODEL.md).",
            "Structure: one bending and one torsion mode per wing (reduced-order).",
            "Rigid-body inertia is evaluated at the mean wing position and held constant.",
        ]
    )


class Gust(BaseModel):
    start: float
    duration: float = 1.0
    north: float = 0.0
    east: float = 0.0
    down: float = 0.0


class EnvironmentConfig(BaseModel):
    altitude_ref_m: float = Field(0.0, description="altitude of the NED origin above sea level")
    temperature_offset_c: float = 0.0
    wind_north: float = 0.0
    wind_east: float = 0.0
    wind_down: float = 0.0
    turbulence_sigma: float = Field(0.0, ge=0, description="m/s, Gauss-Markov turbulence")
    turbulence_length: float = Field(30.0, gt=0)
    gusts: list[Gust] = Field(default_factory=list)
    seed: int = 7


class Waypoint(BaseModel):
    north: float
    east: float
    altitude: float = 40.0
    airspeed: Optional[float] = None


class ControllerConfig(BaseModel):
    enabled: bool = True
    estimator: Literal["truth", "complementary"] = "truth"
    altitude_cmd: float = 40.0
    airspeed_cmd: Optional[float] = None
    heading_cmd_deg: float = 0.0
    waypoints: list[Waypoint] = Field(default_factory=list)
    waypoint_radius: float = 15.0
    loiter_radius: float = 25.0
    comms_timeout_s: float = 5.0
    # gains (tuned in simulation only, see docs/engineering/CONTROL.md)
    k_alt: float = 0.035
    k_vz: float = 0.06
    k_alt_i: float = 0.004
    pitch_limit_deg: float = 15.0
    k_theta: float = 1.2
    k_q: float = 0.18
    k_speed: float = 0.35
    k_speed_i: float = 0.12
    freq_min_hz: float = 1.5
    freq_max_hz: float = Field(10.0, description="wingbeat command limit; 10 Hz (CS-05): the 8 Hz cap saturated 40% of the time in strong turbulence. Above ~8.5 Hz the 3S/34:1 drive is voltage-limited anyway")
    k_heading: float = 0.5
    bank_limit_deg: float = 25.0
    k_bank_rudder: float = 0.6
    k_p_rudder: float = 0.0  # roll-rate->rudder destabilised the lateral loop in study CS-01
    k_r_damper: float = 0.25
    k_bank_amp: float = 25.0
    k_p_amp: float = 4.0
    rate_filter_hz: float = 2.0
    # envelope protection (airspeed priority near the stall-limited minimum speed)
    v_protect: Optional[float] = Field(None, description="protection speed [m/s]; default 0.93 x commanded airspeed")
    k_v_protect: float = Field(0.12, description="pitch-command reduction per m/s below v_protect [rad/(m/s)]")
    bank_limit_protect_deg: float = 12.0
    glide_pitch_offset_deg: float = Field(-4.0, description="glide base pitch relative to the powered trim pitch")
    k_gov_p: float = Field(0.08, description="motor-crank governor: throttle per Hz of crank-frequency error")
    k_gov_i: float = Field(0.4, description="motor-crank governor: integral gain [1/(Hz s)]")
    k_glide_speed: float = Field(0.05, description="glide: pitch-up per m/s above the glide speed [rad/(m/s)]")
    # direct roll effectors (used only when fitted; gains tuned in study CS-02)
    k_bank_twist: float = Field(20.0, description="differential twist per rad of bank error [deg/rad]")
    k_p_twist: float = Field(8.0, description="differential twist per rad/s of roll rate [deg/(rad/s)] (CS-02)")
    k_bank_mean: float = Field(20.0, description="differential stroke mean per rad of bank error [deg/rad]")
    k_p_mean: float = Field(3.0, description="differential stroke mean per rad/s of roll rate [deg/(rad/s)]")
    roll_effector_limit_deg: float = 10.0
    k_bank_rudder_with_roll_effector: float = Field(0.0, description="bank->rudder gain when a direct roll effector is fitted")
    climb_rate_limit: float = Field(1.0, description="max commanded climb rate via altitude loop [m/s]")
    # turbulence speed margin (CS-05): fly faster when the cycle-averaged airspeed fluctuates, to keep gust stall margin
    gust_margin_gain: float = Field(1.5, ge=0, description="added airspeed per m/s of airspeed std above gust_sigma_floor (CS-05; estimate reads ~0.7 x turbulence sigma)")
    gust_sigma_floor: float = Field(0.3, ge=0, description="airspeed std [m/s] treated as calm: calm cruise/turns 0.05-0.16, calm climbing mission mean 0.16 (CS-05)")
    gust_margin_max: float = Field(2.0, ge=0, description="cap on the added airspeed [m/s]")
    gust_window_s: float = Field(5.0, gt=0, description="time constant of the running airspeed mean/variance [s]")


class Fault(BaseModel):
    time: float
    kind: Literal[
        "motor_failure",
        "wing_stuck_left",
        "wing_stuck_right",
        "asymmetric_amplitude",
        "imu_gyro_bias",
        "gnss_loss",
        "comms_loss",
        "battery_sag",
        "vibration",
        "joint_failure_right",
        "airspeed_sensor_block",
    ]
    magnitude: float = 1.0


class SimulationConfig(BaseModel):
    duration: float = Field(20.0, gt=0, le=600)
    dt: float = Field(0.002, gt=1e-5, le=0.02)
    integrator: Literal["rk4", "dopri45"] = "rk4"
    rtol: float = 1e-5
    atol: float = 1e-7
    control_hz: float = 100.0
    output_hz: float = 100.0
    initial_altitude: float = 40.0
    initial_airspeed: float = Field(12.0, description="operating speed: lowest speed meeting the 1.15 g manoeuvre rule (stall <= 0.5) for rev 3")
    initial_heading_deg: float = 0.0
    trim_initial: bool = True
    controller: ControllerConfig = ControllerConfig()
    environment: EnvironmentConfig = EnvironmentConfig()
    faults: list[Fault] = Field(default_factory=list)
    seed: int = 1


def clone(cfg: AircraftConfig) -> AircraftConfig:
    return AircraftConfig.model_validate(copy.deepcopy(cfg.model_dump()))


def apply_overrides(cfg: AircraftConfig, overrides: dict) -> AircraftConfig:
    """Apply dotted-path overrides, e.g. {"kinematics.left.frequency_hz": 5}.

    Special keys: "wings.<field>" sets both wings, "stroke.<field>" sets both
    strokes, "total_mass" sets ballast so the all-up mass matches.
    """
    data = cfg.model_dump()
    for key, value in overrides.items():
        if key.startswith("wings."):
            f = key.split(".", 1)[1]
            data["wing_left"][f] = value
            data["wing_right"][f] = value
            continue
        if key.startswith("stroke."):
            f = key.split(".", 1)[1]
            data["kinematics"]["left"][f] = value
            data["kinematics"]["right"][f] = value
            continue
        if key == "total_mass":
            continue
        node = data
        parts = key.split(".")
        for p in parts[:-1]:
            node = node[int(p)] if isinstance(node, list) else node[p]
        node[parts[-1]] = value
    out = AircraftConfig.model_validate(data)
    if "total_mass" in overrides:
        from .massprops import set_total_mass

        out = set_total_mass(out, float(overrides["total_mass"]))
    return out
