"""HolyHornet Flapper physical model: one right-hand-side function for the
coupled wing / structure / drive / rigid-body / battery system.

State vector x (28):
   0:3   p      position NED [m]
   3:6   v      body velocity FRD [m/s]
   6:10  q      attitude quaternion body->NED
  10:13  w      body angular rate [rad/s]
  13:15  theta  stroke phase (left, right) [rad]   (motor_crank: both = crank angle)
  15:17  Omega  stroke phase rate [rad/s]
  17:19  beta   bending mode (tip deflection = beta * R) [-]
  19:21  beta_dot
  21:23  psi    tip twist, nose-up + [rad]
  23:25  psi_dot
  25     charge drawn from the battery [Ah]
  26     energy drawn from the battery [J]
  27     motor winding temperature rise [K]

Control vector u (9):
   0:2  stroke frequency command (L, R) [Hz]    (prescribed drive)
   2:4  stroke amplitude (L, R) [rad]
   4:6  stroke mean angle (L, R) [rad]
   6    elevator [rad] (+ trailing edge down)
   7    rudder [rad]   (+ trailing edge left)
   8    throttle [0..1] (motor_crank drive)
   9    differential twist bias [rad] (+ = right wing nose-up, left nose-down; servo on the twist push rods)

Translational:  m (v_dot + w x v) = F
Rotational:     I w_dot + w x (I w) = M
Kinematic:      q_dot = 1/2 q (x) [0, w],   p_dot = R(q) v
"""
from __future__ import annotations

import math

import numpy as np

from . import aero
from .config import AircraftConfig
from .environment import G0, Environment
from .frames import quat_derivative, quat_to_dcm
from .geometry import make_strips, wing_summary
from .kinematics import make_profile
from .massprops import mass_properties
from .mechanism import mechanism_tables
from .power import battery_current, cell_ocv, motor_constants

NX = 28
NU = 10
SIDES = ("left", "right")
RHO_REF = 1.225


class Model:
    def __init__(self, cfg: AircraftConfig, env: Environment | None = None):
        from .config import EnvironmentConfig

        self.cfg = cfg
        self.env = env or Environment(EnvironmentConfig())
        self.mp = mass_properties(cfg)
        self.mass = self.mp.mass
        self.cg = self.mp.cg
        self.I = self.mp.inertia
        self.Iinv = np.linalg.inv(self.I)
        self.faults: dict = {}
        self.twist_released = False  # wing-park: twist drive decoupled (set by the simulator, DS-04b)
        self.springs_released = False  # wing-park: hinge-spring anchors freed (set by the simulator, DS-04b)
        self._build_wings()
        self.n_strips = len(self.s_r)
        self.unsteady = bool(cfg.aerodynamics.unsteady)
        self.nx = NX + (2 * self.n_strips if self.unsteady else 0)
        # indices of the internal dynamic states (structure + Wagner lags) that captive cycles settle
        self.dyn_idx = np.r_[17:25, NX:self.nx]
        self._build_tail()
        self._build_drive()

    # ------------------------------------------------------------------ build
    def _build_wings(self) -> None:
        cfg = self.cfg
        cg = self.cg
        cols = {k: [] for k in ("side", "sig", "r", "dr", "c", "xq", "dxm", "theta0", "m", "a3d", "kind", "cd0",
                                "a0", "stall", "cm0", "R", "hy", "xea", "xcg")}
        self.wing_info = []
        for s, w in enumerate((cfg.wing_left, cfg.wing_right)):
            sig = -1.0 if s == 0 else 1.0
            st = make_strips(w)
            ws = wing_summary(w)
            self.wing_info.append(ws)
            n = len(st.r)
            ea = cfg.structure.elastic_axis
            cols["side"].append(np.full(n, s))
            cols["sig"].append(np.full(n, sig))
            cols["r"].append(st.r)
            cols["dr"].append(st.dr)
            cols["c"].append(st.c)
            cols["xq"].append(st.x_le - 0.25 * st.c - cg[0])
            cols["dxm"].append(-(w.chordwise_cg - 0.25) * st.c)
            cols["theta0"].append(st.theta0)
            cols["m"].append(st.mass)
            cols["a3d"].append(np.full(n, ws.lift_slope))
            cols["kind"].append(np.full(n, 1.0 / (math.pi * w.oswald * ws.aspect_ratio)))
            cols["cd0"].append(np.full(n, w.cd0))
            cols["a0"].append(np.full(n, aero.alpha_zero_lift(w.camber)))
            cols["stall"].append(np.full(n, math.radians(w.stall_deg)))
            cols["cm0"].append(np.full(n, aero.cm_quarter_chord(w.camber)))
            cols["R"].append(np.full(n, w.semi_span))
            cols["hy"].append(np.full(n, sig * cfg.hinge.y_offset - cg[1]))
            cols["xea"].append(np.full(n, ea))
            cols["xcg"].append(np.full(n, w.chordwise_cg))
        for k, v in cols.items():
            setattr(self, "s_" + k, np.concatenate(v))
        self.s_side = self.s_side.astype(int)
        self.hz = self.cfg.hinge.z - cg[2]
        self.b_shape = self.s_r ** 2 / self.s_R  # bending shape w = beta * r^2 / R
        self.t_shape = self.s_r / self.s_R  # twist shape theta = psi * r / R
        self.am_coef = math.pi / 4 * self.s_c ** 2 * self.s_dr  # added mass per unit density
        self.area_total = sum(wi.area for wi in self.wing_info)
        m, b, t, c = self.s_m, self.b_shape, self.t_shape, self.s_c
        st = self.cfg.structure
        d_cg = (self.s_xcg - self.s_xea) * c
        self.J_beta = np.bincount(self.s_side, m * b * b + RHO_REF * self.am_coef * b * b, minlength=2)
        I_th = m * (c * c / 12 + d_cg * d_cg)  # strip pitch inertia about the elastic axis
        w0 = self.cfg.kinematics.twist_root_fraction
        self.d_shape = w0 + (1 - w0) * t  # driven-twist spanwise shape
        self.J_psi = np.bincount(self.s_side, t * t * I_th, minlength=2)
        self.J_dd = np.bincount(self.s_side, self.d_shape ** 2 * I_th, minlength=2)
        self.J_dpsi = np.bincount(self.s_side, self.d_shape * t * I_th, minlength=2)
        self.J_cpl = np.bincount(self.s_side, m * self.s_r * b, minlength=2)
        self.I_hinge = np.bincount(self.s_side, m * self.s_r ** 2, minlength=2)
        R = np.array([self.cfg.wing_left.semi_span, self.cfg.wing_right.semi_span])
        self.k_beta = 4 * st.spar_EI / R
        self.c_beta = 2 * st.bending_zeta * np.sqrt(self.k_beta * self.J_beta)
        self.k_psi = np.full(2, st.torsion_k)
        self.c_psi = 2 * st.torsion_zeta * np.sqrt(self.k_psi * self.J_psi)
        self.d_cg = d_cg

    def _build_tail(self) -> None:
        t = self.cfg.tail
        cg = self.cg
        self.ph = np.array([-t.h_arm, 0.0, t.h_z - cg[2]])
        self.pv = np.array([-t.v_arm, 0.0, t.v_z - cg[2]])
        self.ar_h = t.h_span ** 2 / t.h_area
        self.ar_v = 2 * t.v_height ** 2 / t.v_area  # fin on a body acts like a mirrored surface
        from .geometry import helmbold_slope

        self.a_h = helmbold_slope(self.ar_h)
        self.a_v = helmbold_slope(self.ar_v)
        wl = self.wing_info[1]
        self.deps_dalpha = 2 * wl.lift_slope / (math.pi * wl.aspect_ratio)
        ih = math.radians(t.h_incidence_deg)
        self.h_ec = np.array([math.cos(ih), 0.0, -math.sin(ih)])
        self.h_en = np.array([-math.sin(ih), 0.0, -math.cos(ih)])

    def _build_drive(self) -> None:
        cfg = self.cfg
        kin = cfg.kinematics
        self.drive = kin.drive
        prof_name = "mechanism" if kin.drive == "motor_crank" else kin.profile
        self.mech = mechanism_tables(cfg) if prof_name == "mechanism" else None
        if prof_name == "mechanism":
            self.profiles = [self.mech[0], self.mech[1]]
        else:
            self.profiles = [make_profile(kin), make_profile(kin)]
        self.profile_name = prof_name
        # driven twist from the solved torque-tube linkage (tables in crank angle)
        self.twist_tables = None
        self.twist_offset = 0.0
        if kin.twist_source == "linkage" and kin.twist_amplitude_deg > 0:
            from .twistlinkage import stroke_reference, twist_tables

            self.twist_tables = twist_tables(cfg)
            if prof_name != "mechanism":
                # align the crank-angle table with a sinusoidal stroke phase (top of stroke at pi/2)
                th = np.linspace(0, 2 * math.pi, 720, endpoint=False)
                _, th_top = stroke_reference(cfg, th)
                self.twist_offset = th_top - math.pi / 2
        self.mean_design = np.radians([kin.left.mean_deg, kin.right.mean_deg])
        self.ke, self.kt = motor_constants(cfg.motor)
        b = cfg.battery
        self.r_batt = b.cell_resistance * b.cells
        av = cfg.avionics
        self.p_avionics = av.flight_computer_w + av.sensors_w + av.telemetry_w + av.servos_w + (
            av.camera_w if av.camera_enabled else 0.0)

    # ---------------------------------------------------------------- helpers
    def default_controls(self) -> np.ndarray:
        k = self.cfg.kinematics
        return np.array([k.left.frequency_hz, k.right.frequency_hz, math.radians(k.left.amplitude_deg),
                         math.radians(k.right.amplitude_deg), math.radians(k.left.mean_deg),
                         math.radians(k.right.mean_deg), 0.0, 0.0, 0.6, 0.0])

    def initial_state(self, altitude: float = 40.0, airspeed: float = 8.0, pitch: float = 0.0, heading: float = 0.0,
                      u: np.ndarray | None = None) -> np.ndarray:
        from .frames import euler_to_quat

        u = self.default_controls() if u is None else u
        x = np.zeros(self.nx)
        x[2] = -altitude
        x[3] = airspeed * math.cos(pitch)
        x[5] = airspeed * math.sin(pitch)
        x[6:10] = euler_to_quat(0.0, pitch, heading)
        k = self.cfg.kinematics
        x[13] = math.radians(k.left.phase_deg)
        x[14] = math.radians(k.right.phase_deg)
        x[15:17] = 2 * math.pi * u[0:2]
        if self.drive == "motor_crank":
            x[13] = x[14]
            x[15:17] = 2 * math.pi * u[1]
        return x

    def stroke(self, th: np.ndarray, Om: np.ndarray, Omd: np.ndarray, u: np.ndarray):
        phi = np.empty(2)
        dphi = np.empty(2)  # d phi / d theta
        ddphi = np.empty(2)
        for s in (0, 1):
            g, dg, ddg = self.profiles[s].eval(th[s])
            if self.profile_name == "mechanism":
                A, m0 = 1.0, u[4 + s] - self.mean_design[s]
            else:
                A, m0 = u[2 + s], u[4 + s]
            phi[s] = m0 + A * g
            dphi[s] = A * dg
            ddphi[s] = A * ddg
        phid = dphi * Om
        phidd = ddphi * Om * Om + dphi * Omd
        for s, key in ((0, "wing_stuck_left"), (1, "wing_stuck_right")):
            if key in self.faults:
                phi[s] = self.faults[key]
                phid[s] = 0.0
                phidd[s] = 0.0
                dphi[s] = 0.0
        if "joint_failure_right" in self.faults:
            phi[1] = math.radians(-45.0)
            phid[1] = phidd[1] = dphi[1] = 0.0
        return phi, phid, phidd, dphi

    def driven_twist(self, th: np.ndarray, Om: np.ndarray, u: np.ndarray | None = None):
        """Driven tip twist (nose-up +) and its rate. Nose-down during the downstroke for phase 0.

        With phi = phi0 + A sin(theta), phi_dot ~ cos(theta), so tw = TA cos(theta + lead)
        is most nose-down at mid-downstroke (theta = pi)."""
        k = self.cfg.kinematics
        bias = float(u[9]) if (u is not None and len(u) > 9) else 0.0
        if k.twist_amplitude_deg <= 0:
            tw, twd, twdd, dtw = np.zeros(2), np.zeros(2), np.zeros(2), np.zeros(2)
        elif self.twist_tables is not None:
            tw, twd, twdd, dtw = np.empty(2), np.empty(2), np.empty(2), np.empty(2)
            for s in (0, 1):
                g, dg, ddg = self.twist_tables[s].eval(th[s] + self.twist_offset)
                tw[s], twd[s], twdd[s], dtw[s] = g, dg * Om[s], ddg * Om[s] * Om[s], dg
        else:
            TA = math.radians(k.twist_amplitude_deg)
            ph = th + math.radians(k.twist_phase_deg)
            tw = TA * np.cos(ph)
            dtw = -TA * np.sin(ph)
            twd = dtw * Om
            twdd = -TA * np.cos(ph) * Om * Om
        if self.twist_released:
            # wing park (DS-04b): the idler-eccentric end of the twist push rods is decoupled, the torque tubes
            # return to zero driven twist; the roll bellcrank still acts on the rods
            tw, twd, twdd, dtw = np.zeros(2), np.zeros(2), np.zeros(2), np.zeros(2)
        # differential twist bias (wing warping): a constant pitch offset of each torque tube
        tw = tw + np.array([-bias / 2, bias / 2])
        for s, key in ((0, "wing_stuck_left"), (1, "wing_stuck_right")):
            if key in self.faults:
                tw[s] = twd[s] = twdd[s] = dtw[s] = 0.0
        self._dtw_dtheta = dtw  # d(twist)/d(stroke phase), for crank torque by virtual work
        return tw, twd, twdd

    # ------------------------------------------------------------------- RHS
    def evaluate(self, t: float, x: np.ndarray, u: np.ndarray, full: bool = False):
        cfg = self.cfg
        v = x[3:6]
        q = x[6:10]
        qn = q / math.sqrt(q @ q)
        w = x[10:13]
        th = x[13:15]
        Om = x[15:17]
        be = x[17:19]
        bed = x[19:21]
        ps = x[21:23]
        psd = x[23:25]
        R = quat_to_dcm(qn)
        rho = self.env.density(-x[2])
        wind_b = R.T @ self.env.wind_ned(t)

        # ---- drive / stroke
        if self.drive == "prescribed":
            fcmd = u[0:2].copy()
            if "motor_failure" in self.faults:
                fcmd[:] = 0.0
            Omd = (2 * math.pi * fcmd - Om) / cfg.kinematics.frequency_time_constant
            if "motor_failure" in self.faults and cfg.park.enabled and (cfg.park.mechanism != "release" or self.springs_released):
                # detent captures the back-drivable crank at the park angle (spring-damper about the lobe)
                wn = 2 * math.pi * cfg.park.capture_hz
                e = np.mod(th - math.radians(cfg.park.crank_deg) + math.pi, 2 * math.pi) - math.pi
                Omd = -wn * wn * e - 2 * cfg.park.capture_zeta * wn * Om
        else:
            Omd = np.zeros(2)  # resolved below from the motor equation
        phi, phid, phidd, dphi = self.stroke(th, Om, Omd, u)
        tw_act, twd_act, twdd_act = self.driven_twist(th, Om, u)
        if "asymmetric_amplitude" in self.faults:
            k = self.faults["asymmetric_amplitude"]
            phi[1] = u[5] + (phi[1] - u[5]) * k
            phid[1] *= k
            phidd[1] *= k
            dphi[1] *= k

        if not cfg.structure.enabled:
            be = bed = ps = psd = np.zeros(2)

        sd = self.s_side
        sig = self.s_sig
        r = self.s_r
        c = self.s_c
        PHI, PHID, PHIDD = phi[sd], phid[sd], phidd[sd]
        BE, BED = be[sd], bed[sd]
        PSe, PSDe = ps[sd], psd[sd]  # elastic twist (shape r/R)
        TWd, TWDd = tw_act[sd], twd_act[sd]  # driven twist (shape d_shape)

        a = -sig * PHI
        ad = -sig * PHID
        add = -sig * PHIDD
        ca, sa = np.cos(a), np.sin(a)
        yw = sig * r
        zw = -BE * self.b_shape
        zdw = -BED * self.b_shape
        Y = ca * yw - sa * zw
        Z = sa * yw + ca * zw
        px = self.s_xq
        py = self.s_hy + Y
        pz = self.hz + Z
        vry = -ad * Z - sa * zdw
        vrz = ad * Y + ca * zdw
        ary = -add * Z - ad * ad * Y - 2 * ad * ca * zdw
        arz = add * Y - ad * ad * Z - 2 * ad * sa * zdw

        al = -sig * (PHI + 2 * BE * r / self.s_R)
        cal, sal = np.cos(al), np.sin(al)
        theta = self.s_theta0 + PSe * self.t_shape + TWd * self.d_shape
        ct, st = np.cos(theta), np.sin(theta)
        ecx, ecy, ecz = ct, st * sal, -st * cal
        enx, eny, enz = -st, ct * sal, -ct * cal

        wx, wy, wz = w
        ux = wind_b[0] - (v[0] + wy * pz - wz * py)
        uy = wind_b[1] - (v[1] + wz * px - wx * pz + vry)
        uz = wind_b[2] - (v[2] + wx * py - wy * px + vrz)
        uc = ux * ecx + uy * ecy + uz * ecz
        un = ux * enx + uy * eny + uz * enz + (PSDe * self.t_shape + TWDd * self.d_shape) * c * 0.5
        V2 = uc * uc + un * un + 1e-12
        Vs = np.sqrt(V2)
        alpha = np.arctan2(un, -uc)
        if self.unsteady:
            # Wagner lag on the circulatory angle of attack (applied in the attached regime only)
            ac = cfg.aerodynamics
            n = self.n_strips
            z1 = x[NX:NX + n]
            z2 = x[NX + n:NX + 2 * n]
            kk = 2.0 * Vs / c
            a_in = np.clip(alpha - self.s_a0, -1.0, 1.0)
            d_alpha = -(ac.wagner_A1 + ac.wagner_A2) * a_in + ac.wagner_A1 * ac.wagner_b1 * kk * z1                 + ac.wagner_A2 * ac.wagner_b2 * kk * z2
            d_alpha = np.clip(d_alpha, -0.5, 0.5)
            s_qs = 1.0 / (1.0 + np.exp(-aero.BLEND_SHARPNESS * (np.abs(alpha - self.s_a0) - self.s_stall)))
            alpha_c = alpha + (1.0 - s_qs) * d_alpha
            dz1 = a_in - ac.wagner_b1 * kk * z1
            dz2 = a_in - ac.wagner_b2 * kk * z2
        else:
            alpha_c = alpha
        cl, cd, sblend = aero.coefficients(alpha_c, self.s_a3d, self.s_kind, self.s_cd0, self.s_a0, self.s_stall)
        qd = 0.5 * rho * V2
        qa = qd * c * self.s_dr
        dc, dn = uc / Vs, un / Vs
        # lift dir l = dn ec - dc en ; drag dir d = dc ec + dn en
        Lm = qa * cl
        Dm = qa * cd
        if self.unsteady:
            # circulatory force acts normal to the effective (lagged) inflow, so the lift tilt
            # (leading-edge-suction thrust) follows the lagged incidence as in Garrick's theory
            dcl, dnl = -np.cos(alpha_c), np.sin(alpha_c)
        else:
            dcl, dnl = dc, dn
        fLx = Lm * (dnl * ecx - dcl * enx)
        fLy = Lm * (dnl * ecy - dcl * eny)
        fLz = Lm * (dnl * ecz - dcl * enz)
        fDx = Dm * (dc * ecx + dn * enx)
        fDy = Dm * (dc * ecy + dn * eny)
        fDz = Dm * (dc * ecz + dn * enz)
        a_n = ary * eny + arz * enz
        am = rho * self.am_coef * a_n
        fAx, fAy, fAz = -am * enx, -am * eny, -am * enz
        Fx = fLx + fDx + fAx
        Fy = fLy + fDy + fAy
        Fz = fLz + fDz + fAz
        msec = qd * c * c * self.s_dr * self.s_cm0  # about k = (0, cal, sal)

        F_w = np.array([Fx.sum(), Fy.sum(), Fz.sum()])
        M_w = np.array([
            (py * Fz - pz * Fy).sum(),
            (pz * Fx - px * Fz).sum() + (msec * cal).sum(),
            (px * Fy - py * Fx).sum() + (msec * sal).sum(),
        ])
        # wing inertial reaction on the fuselage (first order, relative acceleration only)
        m = self.s_m
        pmx = px + self.s_dxm
        miy, miz = m * ary, m * arz
        F_in = np.array([0.0, -miy.sum(), -miz.sum()])
        M_in = -np.array([(py * miz - pz * miy).sum(), (-pmx * miz).sum(), (pmx * miy).sum()])

        # ---- structure (bending + torsion per wing)
        eupy, eupz = sa, -ca
        fn_circ = (fLx + fDx) * enx + (fLy + fDy) * eny + (fLz + fDz) * enz
        arm_c = (0.25 - self.s_xea) * c
        arm_a = (0.5 - self.s_xea) * c
        pitch_load = msec - arm_c * fn_circ - arm_a * (-am) + m * self.d_cg * a_n  # nose-up moment per strip
        Qp = np.bincount(sd, self.t_shape * pitch_load, minlength=2)
        Qd = np.bincount(sd, self.d_shape * pitch_load, minlength=2)
        aero_pitch = msec - arm_c * fn_circ - arm_a * (-am)  # aerodynamic part only (for power diagnostics)
        if cfg.structure.enabled:
            Qb = np.bincount(sd, self.b_shape * ((Fy - miy) * eupy + (Fz - miz) * eupz), minlength=2)
            bedd = (Qb - self.c_beta * bed - self.k_beta * be) / self.J_beta
            # psi is the elastic twist relative to the driven base twist
            psdd = (Qp - self.c_psi * psd - self.k_psi * ps - self.J_dpsi * twdd_act) / self.J_psi
        else:
            bedd = np.zeros(2)
            psdd = np.zeros(2)
        # generalised torque the twist drive applies (nose-up +) and the power it draws
        twist_drive_torque = self.J_dd * twdd_act + self.J_dpsi * psdd - Qd
        p_twist = twist_drive_torque * twd_act

        # ---- actuator torque at each hinge (phi sense) and mechanical power
        tau_el = -sig * (Y * (miz - Fz) - Z * (miy - Fy))
        tau = np.bincount(sd, tau_el, minlength=2) + self.J_cpl * bedd
        hs = cfg.hinge_spring
        if hs.enabled and hs.stiffness_Nm_per_rad > 0 and not self.springs_released:
            # parallel hinge spring: the actuator must additionally supply k (phi - phi_n); hysteresis as
            # equivalent viscous damping that dissipates `hysteresis` x peak energy per stroke
            k_s = hs.stiffness_Nm_per_rad
            spring_torque = k_s * (phi - math.radians(hs.neutral_deg))
            c_h = hs.hysteresis * k_s / (math.pi * max(float(np.mean(np.abs(Om))), 1.0))
            tau = tau + spring_torque + c_h * phid
        else:
            spring_torque = np.zeros(2)
        p_mech = tau * phid

        # ---- tail
        u_cg = wind_b - v
        Vcg = math.sqrt(u_cg @ u_cg) + 1e-12
        alpha_b = math.atan2(-u_cg[2], -u_cg[0])
        beta_b = math.asin(max(-1.0, min(1.0, -u_cg[1] / Vcg)))
        F_t, M_t, tail_diag = self._tail(rho, wind_b, v, w, u, alpha_b)
        # fuselage drag at CG
        F_f = 0.5 * rho * cfg.fuselage.cda * Vcg * u_cg
        F_g = R.T @ np.array([0.0, 0.0, self.mass * G0])

        F = F_w + F_in + F_t + F_f + F_g
        M = M_w + M_in + M_t
        dx = np.zeros(self.nx)
        if self.unsteady:
            dx[NX:NX + self.n_strips] = dz1
            dx[NX + self.n_strips:] = dz2
        dx[0:3] = R @ v
        dx[3:6] = F / self.mass - np.cross(w, v)
        dx[6:10] = quat_derivative(q, w)
        dx[10:13] = self.Iinv @ (M - np.cross(w, self.I @ w))

        # ---- drive + battery
        mc = cfg.motor
        bc = cfg.battery
        soc = 1.0 - x[25] / bc.capacity_ah
        v_oc = bc.cells * cell_ocv(max(soc, 0.0))
        if "battery_sag" in self.faults:
            v_oc *= self.faults["battery_sag"]
        r_b = self.r_batt * (3.0 if "battery_sag" in self.faults else 1.0)
        # flap torque reflected to the crank, plus the twist drive (assumed crank-driven torsion linkage)
        tau_crank = float((tau * dphi).sum())
        if self.cfg.kinematics.twist_amplitude_deg > 0:
            # virtual work: twist-drive torque times d(twist)/d(crank); well defined when the crank stops
            tau_crank += float((twist_drive_torque * self._dtw_dtheta).sum())
        if self.drive == "prescribed":
            dx[13:15] = Om
            dx[15:17] = Omd
            om_c = float(np.mean(Om))
            w_m = mc.gear_ratio * om_c
            tau_m = tau_crank / (mc.gear_ratio * mc.gear_efficiency) if tau_crank > 0 else 0.0
            i_m = tau_m / self.kt + mc.no_load_current
            v_m = i_m * mc.resistance + self.ke * abs(w_m)
            p_motor = v_m * i_m
            throttle = None
        else:
            thr = 0.0 if "motor_failure" in self.faults else min(max(u[8], 0.0), 1.0)
            om_c = float(Om[1])
            w_m = mc.gear_ratio * om_c
            v_t = v_oc
            i_m = 0.0
            for _ in range(3):  # fixed point on the battery terminal voltage
                i_m = (thr * v_t - self.ke * w_m) / mc.resistance
                i_m = min(max(i_m, 0.0), mc.max_current)
                _, v_t, _ = battery_current(thr * v_t * i_m / mc.esc_efficiency + self.p_avionics, v_oc, r_b)
            tau_m = self.kt * max(i_m - mc.no_load_current, 0.0)
            v_m = thr * v_t
            p_motor = v_m * i_m
            dp = dphi
            J_eff = mc.rotor_inertia * mc.gear_ratio ** 2 + mc.crank_inertia + float((self.I_hinge * dp * dp).sum())
            tau_park = 0.0
            if thr == 0.0:
                # unpowered: motor no-load (bearing + iron) torque reflected through the gearbox, smoothed Coulomb
                tau_park -= self.kt * mc.no_load_current * mc.gear_ratio * math.tanh(om_c / 0.5)
            pk = cfg.park
            if pk.enabled and pk.mechanism == "cam_detent":
                # cam detent (DS-04 concept, evaluated in DS-04b): spring roller on an eccentric cam on the crank shaft, single well at the
                # park angle, torque -T sin(e) with finite capacity T, plus hysteresis (friction in the roller and
                # spring: a fraction of |T sin e| opposing motion). centrifugal_disengage_hz = 0: always engaged.
                fd = pk.centrifugal_disengage_hz
                if fd > 0:
                    f_c = abs(om_c) / (2 * math.pi)
                    engaged = 1.0 / (1.0 + math.exp(min((f_c - fd) / (0.1 * fd), 50.0)))
                else:
                    engaged = 1.0
                e_pk = (float(th[1]) - math.radians(pk.crank_deg) + math.pi) % (2 * math.pi) - math.pi
                tdet = pk.detent_torque_Nm * math.sin(e_pk)
                tau_park -= engaged * (tdet + pk.hysteresis * abs(tdet) * math.tanh(om_c / 0.5))
            self._tau_park = tau_park
            Omd_c = (mc.gear_ratio * mc.gear_efficiency * tau_m - tau_crank + tau_park) / J_eff
            dx[13:15] = om_c
            dx[15:17] = Omd_c
            throttle = thr
        p_total = p_motor / mc.esc_efficiency + self.p_avionics
        i_b, v_t, limited = battery_current(p_total, v_oc, r_b)
        dx[17:19] = bed
        dx[19:21] = bedd
        dx[21:23] = psd
        dx[23:25] = psdd
        if not cfg.structure.enabled:
            dx[17:25] = 0.0
        dx[25] = i_b / 3600.0
        dx[26] = v_t * i_b
        dx[27] = (i_m * i_m * mc.resistance - x[27] / mc.thermal_resistance) / mc.thermal_capacity
        if not full:
            return dx

        # ---- diagnostics (wind axes at CG)
        ca_b, sa_b = math.cos(alpha_b), math.sin(alpha_b)
        xw = -u_cg / Vcg
        zl = np.array([sa_b, 0.0, -ca_b])  # lift direction (up, in body x-z plane)
        res = {}
        for s in (0, 1):
            sel = sd == s
            Fs = np.array([Fx[sel].sum(), Fy[sel].sum(), Fz[sel].sum()])
            FLs = np.array([fLx[sel].sum(), fLy[sel].sum(), fLz[sel].sum()])
            FDs = np.array([fDx[sel].sum(), fDy[sel].sum(), fDz[sel].sum()])
            res[SIDES[s]] = {
                "lift": float(Fs @ zl),
                "thrust": float(Fs @ xw),
                "thrust_from_lift": float(FLs @ xw),
                "profile_induced_drag": float(-(FDs @ xw)),
                "side_force": float(Fs[1]),
                "alpha_75_deg": float(np.degrees(np.interp(0.75, (r / self.s_R)[sel], alpha[sel]))),
                "stall_fraction": float(sblend[sel].mean()),
            }
        # power the flapping motion delivers to the air: -sum(F_aero . v_rel)
        p_aero = float(-(Fy * vry + Fz * vrz).sum())
        # plus work done on the air through section pitching (driven + elastic twist rates)
        p_aero -= float((aero_pitch * (TWDd * self.d_shape + PSDe * self.t_shape)).sum())
        res.update(
            {
                "t": t,
                "rho": rho,
                "airspeed": Vcg,
                "alpha_deg": math.degrees(alpha_b),
                "beta_deg": math.degrees(beta_b),
                "phi": phi.copy(),
                "phid": phid.copy(),
                "phidd": phidd.copy(),
                "dphi_dtheta": dphi.copy(),
                "freq_hz": Om / (2 * math.pi),
                "tip_deflection": be * np.array([cfg.wing_left.semi_span, cfg.wing_right.semi_span]),
                "tip_twist": ps.copy(),
                "hinge_torque": tau,
                "hinge_spring_torque": spring_torque,
                "p_mech": p_mech + p_twist,
                "p_flap": p_mech,
                "p_twist": p_twist,
                "driven_twist": tw_act,
                "twist_drive_torque": twist_drive_torque,
                "p_aero_wings": p_aero,
                "crank_torque": tau_crank,
                "crank_hold_torque": tau_crank,  # torque the wings exert on a stopped crank (detent must react it)
                "park_torque": getattr(self, "_tau_park", 0.0) if self.drive == "motor_crank" else 0.0,
                "motor_rpm": abs(w_m) * 60 / (2 * math.pi),
                "motor_current": i_m,
                "motor_voltage": v_m,
                "motor_power_elec": p_motor,
                "throttle": throttle,
                "battery_current": i_b,
                "battery_voltage": v_t,
                "battery_soc": soc,
                "battery_power_limited": limited,
                "p_total": p_total,
                "F_wing": F_w,
                "M_wing": M_w,
                "F_inertial": F_in,
                "F_tail": F_t,
                "M_tail": M_t,
                "F_fuselage": F_f,
                "F_total_aero": F_w + F_t + F_f,
                "lift_total": float((F_w + F_t + F_f) @ zl),
                "thrust_total": float((F_w + F_t + F_f) @ xw),
                "wing_lift": float(F_w @ zl),
                "wing_thrust": float(F_w @ xw),
                "tail": tail_diag,
                "specific_force": dx[3:6] + np.cross(w, v) - R.T @ np.array([0.0, 0.0, G0]),
                "strips": {"alpha": alpha, "cl": cl, "Fx": Fx, "Fy": Fy, "Fz": Fz, "px": px, "py": py, "pz": pz},
                "strip_count": len(r),
            }
        )
        return dx, res

    def _tail(self, rho, wind_b, v, w, u, alpha_b):
        t = self.cfg.tail
        out = np.zeros(3)
        mom = np.zeros(3)
        diag = {}
        de = max(-1.0, min(1.0, u[6] / math.radians(t.elevator_max_deg))) * math.radians(t.elevator_max_deg)
        dr = max(-1.0, min(1.0, u[7] / math.radians(t.rudder_max_deg))) * math.radians(t.rudder_max_deg)
        # horizontal
        p = self.ph
        uu = wind_b - (v + np.cross(w, p))
        uc = uu @ self.h_ec
        un = uu @ self.h_en
        Vt = math.hypot(uc, un) + 1e-12
        un -= self.deps_dalpha * alpha_b * Vt
        Vt = math.hypot(uc, un) + 1e-12
        a_t = math.atan2(un, -uc)
        cl, cd, s = aero.coefficients(np.array(a_t), self.a_h, 1 / (math.pi * 0.8 * self.ar_h), t.cd0, 0.0, math.radians(15))
        cl = float(cl) + (1 - float(s)) * self.a_h * t.elevator_tau * de
        q = 0.5 * rho * Vt * Vt * t.h_area
        dc, dn = uc / Vt, un / Vt
        f = q * (cl * (dn * self.h_ec - dc * self.h_en) + float(cd) * (dc * self.h_ec + dn * self.h_en))
        out += f
        mom += np.cross(p, f)
        diag["h_alpha_deg"] = math.degrees(a_t)
        diag["h_force"] = f.tolist()
        diag["elevator_deg"] = math.degrees(de)
        # vertical
        p = self.pv
        ec = np.array([1.0, 0.0, 0.0])
        en = np.array([0.0, 1.0, 0.0])
        uu = wind_b - (v + np.cross(w, p))
        uc = uu @ ec
        un = uu @ en
        Vt = math.hypot(uc, un) + 1e-12
        a_v = math.atan2(un, -uc)
        cl, cd, s = aero.coefficients(np.array(a_v), self.a_v, 1 / (math.pi * 0.8 * self.ar_v), t.cd0, 0.0, math.radians(15))
        cl = float(cl) + (1 - float(s)) * self.a_v * t.rudder_tau * dr
        q = 0.5 * rho * Vt * Vt * t.v_area
        dc, dn = uc / Vt, un / Vt
        f = q * (cl * (dn * ec - dc * en) + float(cd) * (dc * ec + dn * en))
        out += f
        mom += np.cross(p, f)
        diag["v_alpha_deg"] = math.degrees(a_v)
        diag["v_force"] = f.tolist()
        diag["rudder_deg"] = math.degrees(dr)
        return out, mom, diag
