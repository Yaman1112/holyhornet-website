"""Driven-twist transmission (decision D-01, study DS-02): rotating leading-edge torque tube.

Concept
  * The leading-edge spar is a torque tube in a pitch bearing at the flap hinge (2-DOF root yoke:
    flap about body x, pitch about the spar axis). The tip rib is bonded to the tube; inner
    battens pivot freely on it, so the membrane spreads the twist ~linearly from root (0) to tip.
  * A pitch horn of length h, mounted on the tube ON the flap axis and pointing aft, is driven by a
    ball-jointed push rod (length L) from an eccentric (radius r_t, phase psi0) on the main crank shaft.
    Putting the horn on the flap axis removes first-order flap-pitch coupling.

Geometry (datum FRD; frontal-plane coordinates as in mechanism.py, z_u up from the hinge plane):
  horn end   H(phi, p) = (x_le - h cos p,  hy + h sin(phi) sin p,  hz + h cos(phi) sin p)
  eccentric  E(theta)  = (x_le - h,  ey + r_t cos(theta+psi0),  hz - (ez + r_t sin(theta+psi0)))
             on a 1:1 idler shaft geared to the crank, centred under the hinge so the rod runs
             along the horn motion (a first design with the eccentric on the crank centreline
             reached a 0.06 transmission factor and 8 deg RMS tracking error).
  closure    |H - E| = L      -> solved for the tube pitch p (= tip twist, nose-up +) at each crank angle.

The flap angle phi(theta) comes from the four-bar, so pitch-flap coupling that remains is exact.
Loads: rod force F = tau / (u_rod . dH/dp), where tau is the twist-drive torque (generalised force on
the tip-twist coordinate, from model.py) and u_rod the unit rod direction.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.optimize import brentq, least_squares

from .config import AircraftConfig
from .kinematics import GRID, GridProfile
from .mechanism import TWO_PI, build_linkages

P_LIM = math.radians(75.0)


@dataclass
class TwistLinkage:
    x_le: float
    hy: float
    hz: float
    cy: float
    cz: float
    h: float
    r_t: float
    psi0: float
    L: float

    def horn(self, phi, p):
        return np.array([self.x_le - self.h * math.cos(p), self.hy + self.h * math.sin(phi) * math.sin(p),
                         self.hz + self.h * math.cos(phi) * math.sin(p)])

    def ecc(self, theta):
        a = theta + self.psi0
        return np.array([self.x_le - self.h, self.cy + self.r_t * math.cos(a),
                         self.hz - (self.cz + self.r_t * math.sin(a))])

    def gap(self, theta, phi, p):
        return float(np.linalg.norm(self.horn(phi, p) - self.ecc(theta)) - self.L)

    def _roots(self, g, lo, hi, n):
        grid = np.linspace(lo, hi, n)
        vals = np.array([g(p) for p in grid])
        out = []
        for j in range(n - 1):
            if vals[j] == 0 or vals[j] * vals[j + 1] < 0:
                out.append(brentq(g, grid[j], grid[j + 1], xtol=1e-12))
        return out

    def solve(self, thetas, phis, p_start: float = 0.0):
        """Tube pitch p for each crank angle, following one assembly branch by continuation
        (local bracket around the previous solution, full search as a fallback).
        Returns (p, ok); ok is False where the linkage cannot close."""
        out = np.full(len(thetas), np.nan)
        prev = p_start
        for i, (th, ph) in enumerate(zip(thetas, phis)):
            g = lambda p: self.gap(th, ph, p)  # noqa: E731
            roots = self._roots(g, max(-P_LIM, prev - 0.35), min(P_LIM, prev + 0.35), 8) if i else []
            if not roots:
                roots = self._roots(g, -P_LIM, P_LIM, 61)
            if roots:
                prev = min(roots, key=lambda r: abs(r - prev))
                out[i] = prev
        return out, bool(np.all(np.isfinite(out)))


def stroke_reference(cfg: AircraftConfig, thetas: np.ndarray) -> tuple[np.ndarray, float]:
    """Right-wing stroke angle from the four-bar and the crank angle of top-of-stroke."""
    right, _ = build_linkages(cfg)
    phi = right.phi(thetas)
    phi = phi - TWO_PI * np.round(phi.mean() / TWO_PI)
    return phi, float(thetas[int(np.argmax(phi))])


def target_twist(cfg: AircraftConfig, thetas: np.ndarray, th_top: float) -> np.ndarray:
    """Harmonic target used by the aerodynamic design (D-01): TA cos(stroke phase + lead),
    with stroke phase = pi/2 at top of stroke (so the twist is most nose-down at mid-downstroke)."""
    k = cfg.kinematics
    return math.radians(k.twist_amplitude_deg) * np.cos(thetas - th_top + math.pi / 2 + math.radians(k.twist_phase_deg))


def _make(cfg: AircraftConfig, v) -> TwistLinkage:
    tl = cfg.twist_linkage
    return TwistLinkage(x_le=cfg.wing_right.le_root_x, hy=cfg.hinge.y_offset, hz=cfg.hinge.z,
                        cy=tl.ecc_y, cz=tl.ecc_z, h=tl.horn_length,
                        r_t=v[0], psi0=v[1], L=v[2])


_CACHE: dict = {}


def _key(cfg: AircraftConfig) -> str:
    import json

    return json.dumps([cfg.twist_linkage.model_dump(), cfg.mechanism.model_dump(), cfg.hinge.model_dump(),
                       cfg.kinematics.right.model_dump(), cfg.kinematics.twist_amplitude_deg,
                       cfg.kinematics.twist_phase_deg, cfg.wing_right.le_root_x], sort_keys=True)


def synthesize(cfg: AircraftConfig, n: int = 90) -> tuple[TwistLinkage, dict]:
    """Choose eccentric radius, phase and rod length so the tube pitch follows the D-01 target (cached)."""
    k = (_key(cfg), n)
    if k not in _CACHE:
        _CACHE[k] = _synthesize(cfg, n)
        if len(_CACHE) > 64:
            _CACHE.pop(next(iter(_CACHE)))
    link, fit = _CACHE[k]
    return TwistLinkage(**link.__dict__), dict(fit)


def _synthesize(cfg: AircraftConfig, n: int = 90) -> tuple[TwistLinkage, dict]:
    th = np.linspace(0, TWO_PI, n, endpoint=False)
    phi, th_top = stroke_reference(cfg, th)
    tgt = target_twist(cfg, th, th_top)
    h = cfg.twist_linkage.horn_length
    TA = math.radians(cfg.kinematics.twist_amplitude_deg)
    r0 = h * math.sin(TA)
    # rod length so that p = 0 when the eccentric is at mid-height
    E0 = np.array([0.0, cfg.twist_linkage.ecc_y, -cfg.twist_linkage.ecc_z])
    H0 = np.array([0.0, cfg.hinge.y_offset, 0.0])
    L0 = float(np.linalg.norm(H0 - E0))

    def resid(v):
        link = _make(cfg, v)
        p, ok = link.solve(th, phi)
        bad = ~np.isfinite(p)
        p = np.where(bad, 0.0, p)
        return np.concatenate([(p - tgt), bad.astype(float) * 2.0])

    best = None
    for psi in np.linspace(0, TWO_PI, 6, endpoint=False):
        sol = least_squares(resid, [r0, psi, L0], bounds=([0.002, -10, 0.01], [0.03, 10, 0.12]), xtol=1e-10,
                            ftol=1e-10, max_nfev=200)
        if best is None or sol.cost < best.cost:
            best = sol
    link = _make(cfg, best.x)
    link.psi0 = float((link.psi0 + math.pi) % TWO_PI - math.pi)
    p, ok = link.solve(th, phi)
    err = np.degrees(p - tgt)
    return link, {"rms_error_deg": float(np.sqrt(np.nanmean(err ** 2))), "max_error_deg": float(np.nanmax(np.abs(err))),
                  "closes": ok}


def twist_tables(cfg: AircraftConfig) -> dict[int, GridProfile]:
    """Driven tip twist as a periodic function of the crank angle, for both wings (mirror image)."""
    link, _ = synthesize(cfg)
    th = np.linspace(0, TWO_PI, 360, endpoint=False)
    phi, _ = stroke_reference(cfg, th)
    p, ok = link.solve(th, phi)
    if not ok:
        raise ValueError("twist linkage does not close over the full crank revolution")
    prof = GridProfile.from_samples(p, name="twist-linkage")
    return {0: prof, 1: prof}


def analyse(cfg: AircraftConfig, n: int = 180, twist_torque: dict | None = None) -> dict:
    """Kinematics, transmission quality and (optionally) loads of the twist linkage over one revolution.

    twist_torque: {"theta_deg": [...], "torque": [...]} right-wing twist-drive torque [N m] (nose-up +).
    """
    link, fit = synthesize(cfg)
    th = np.linspace(0, TWO_PI, n, endpoint=False)
    phi, th_top = stroke_reference(cfg, th)
    p, ok = link.solve(th, phi)
    tgt = target_twist(cfg, th, th_top)
    # transmission: projection of the horn velocity on the rod direction (1 = ideal, 0 = toggle)
    trans, arm, Hs, Es = [], [], [], []
    for i in range(n):
        H = link.horn(phi[i], p[i])
        E = link.ecc(th[i])
        u = (H - E) / np.linalg.norm(H - E)
        dH = (link.horn(phi[i], p[i] + 1e-6) - H) / 1e-6
        trans.append(abs(float(u @ dH)) / np.linalg.norm(dH))
        arm.append(float(u @ dH))
        Hs.append(H.tolist())
        Es.append(E.tolist())
    trans = np.array(trans)
    arm = np.array(arm)
    # coupling: pitch change caused by flap alone, at fixed eccentric position (finite difference)
    coupling = []
    for i in range(0, n, max(1, n // 36)):
        p1, _ = link.solve([th[i]], [phi[i] + 0.01], p_start=float(p[i]))
        coupling.append(float((p1[0] - p[i]) / 0.01))
    res = {
        "crank_deg": np.degrees(th).tolist(),
        "pitch_deg": np.degrees(p).tolist(),
        "target_deg": np.degrees(tgt).tolist(),
        "phi_deg": np.degrees(phi).tolist(),
        "transmission": trans.tolist(),
        "horn": Hs,
        "eccentric": Es,
    }
    summ = {
        "horn_length_m": link.h,
        "eccentric_radius_m": link.r_t,
        "eccentric_phase_deg": math.degrees(link.psi0),
        "rod_length_m": link.L,
        "closes": ok,
        "fit_rms_error_deg": fit["rms_error_deg"],
        "fit_max_error_deg": fit["max_error_deg"],
        "pitch_range_deg": [float(np.degrees(np.nanmin(p))), float(np.degrees(np.nanmax(p)))],
        "min_transmission": float(np.nanmin(trans)),
        "max_flap_pitch_coupling": float(np.max(np.abs(coupling))),
    }
    warnings = []
    if not ok:
        warnings.append("twist linkage cannot close over the full revolution")
    if summ["min_transmission"] < 0.5:
        warnings.append(f"rod/horn transmission drops to {summ['min_transmission']:.2f} (<0.5): high rod force, near toggle")
    if summ["fit_max_error_deg"] > 5:
        warnings.append(f"linkage deviates up to {summ['fit_max_error_deg']:.1f} deg from the harmonic D-01 target")
    if twist_torque is not None:
        tq = np.interp(th, np.radians(np.asarray(twist_torque["theta_deg"])), np.asarray(twist_torque["torque"]), period=TWO_PI)
        F = tq / np.where(np.abs(arm) < 1e-4, np.sign(arm + 1e-12) * 1e-4, arm)
        res["rod_force_N"] = F.tolist()
        res["twist_torque_Nm"] = tq.tolist()
        summ["peak_rod_force_N"] = float(np.max(np.abs(F)))
        summ["peak_twist_torque_Nm"] = float(np.max(np.abs(tq)))
    summ["warnings"] = warnings
    res["summary"] = summ
    return res


def tube_check(cfg: AircraftConfig, peak_torque: float) -> dict:
    """Torque-tube wind-up and stress at the peak twist-drive torque (thin-walled circular tube)."""
    tl = cfg.twist_linkage
    do, di = tl.tube_od, tl.tube_id
    J = math.pi * (do ** 4 - di ** 4) / 32
    GJ = tl.tube_shear_modulus * J
    R = cfg.wing_right.semi_span
    windup = peak_torque * R / GJ
    tau = peak_torque * (do / 2) / J
    return {"GJ_Nm2": GJ, "windup_deg_at_peak": math.degrees(windup), "shear_stress_MPa": tau / 1e6,
            "tube_mass_per_wing_g": tl.tube_density * math.pi * (do ** 2 - di ** 2) / 4 * R * 1000,
            "torsion_stiffness_tip_Nm_per_rad": GJ / R}
