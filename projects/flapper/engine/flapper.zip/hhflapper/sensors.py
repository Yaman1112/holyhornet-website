"""Simulated sensors (Simulation E). Every output is labelled SIMULATED.

White noise + constant bias, sampled at the controller rate (GNSS at its own
rate, sample-and-hold). Values are typical consumer-MEMS class numbers, not a
datasheet of a selected part.
"""
from __future__ import annotations

import math

import numpy as np

from .config import SensorConfig
from .frames import quat_to_dcm


class SensorSuite:
    SOURCE = "simulated"

    def __init__(self, cfg: SensorConfig):
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)
        self.gyro_bias = self.rng.normal(0, cfg.gyro_bias, 3)
        self.accel_bias = self.rng.normal(0, cfg.accel_bias, 3)
        self.extra_gyro_bias = np.zeros(3)
        self.vibration = 1.0
        self.gnss_ok = True
        self.airspeed_ok = True
        self.last_gnss_t = -1e9
        self.gnss = None

    def sample(self, t: float, x: np.ndarray, d: dict) -> dict:
        c = self.cfg
        rng = self.rng
        w = x[10:13]
        R = quat_to_dcm(x[6:10] / np.linalg.norm(x[6:10]))
        gyro = w + self.gyro_bias + self.extra_gyro_bias + rng.normal(0, c.gyro_noise * self.vibration, 3)
        accel = d["specific_force"] + self.accel_bias + rng.normal(0, c.accel_noise * self.vibration, 3)
        baro = -x[2] + rng.normal(0, c.baro_noise)
        pitot = d["airspeed"] * math.cos(math.radians(d["alpha_deg"])) * math.cos(math.radians(d["beta_deg"]))
        pitot = pitot + rng.normal(0, c.airspeed_noise) if self.airspeed_ok else 0.0
        if t - self.last_gnss_t >= 1.0 / c.gnss_rate_hz - 1e-9:
            self.last_gnss_t = t
            if self.gnss_ok:
                self.gnss = {
                    "valid": True,
                    "pos": (x[0:3] + rng.normal(0, c.gnss_pos_noise, 3) * np.array([1, 1, 1.8])).tolist(),
                    "vel": (R @ x[3:6] + rng.normal(0, c.gnss_vel_noise, 3)).tolist(),
                    "t": t,
                }
            else:
                self.gnss = {"valid": False, "t": t}
        res = math.radians(c.encoder_resolution_deg)
        enc = np.round(np.asarray(d["phi"]) / res) * res
        return {
            "source": self.SOURCE,
            "t": t,
            "gyro": gyro,
            "accel": accel,
            "baro_alt": baro,
            "airspeed": pitot,
            "gnss": self.gnss,
            "encoder_phi": enc,
            "motor_rpm": d["motor_rpm"] + rng.normal(0, 5),
            "battery_v": d["battery_voltage"] + rng.normal(0, 0.01),
            "battery_i": d["battery_current"] + rng.normal(0, 0.02),
            "motor_temp_rise": float(x[27]),
        }
