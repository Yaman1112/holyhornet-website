# Validation report — HolyHornet Counter-UAS Intelligence

Generated 2026-11-15T19:19:04+00:00 by `python -m hhcuas.evaluation.campaign` · hhcuas 0.1.0

> **Scope.** Every number below was measured by running this software on **simulated** scenes (laboratory result). No real sensor data and no field trials are included. The simulation's sensor and scene models are simplified (see docs/algorithms/SIMULATION.md), so absolute values do not transfer to real equipment; the report is evidence that the evaluation machinery works and shows how the implemented algorithms respond to controlled changes.

Method: each row is the mean over the listed seeds of one sensor + detector + tracker pipeline. Detection metrics use the UAV mode (birds, aircraft and insects are distractors). Tracking metrics are class-agnostic. `n/m` = not measured.

## 1. Models under test

| model | kind | trained on | patches | val. patch accuracy | sha256 |
|---|---|---|---|---|---|
| classical-contrast | classical | — | — | — | — |
| classical-motion | classical | — | — | — | — |
| cnn-day | cnn | eo (simulated, seeds 10000..10169) | 26711 | 0.986 | aa2bfef80422… |
| cnn-lowlight | cnn | lowlight (simulated, seeds 10000..10169) | 17372 | 0.961 | 20ce32b7abd5… |
| cnn-multi | cnn | eo/lowlight/thermal (simulated, seeds 10000..10112) | 41048 | 0.962 | f91be8566a1b… |
| cnn-thermal | cnn | thermal (simulated, seeds 10000..10169) | 18587 | 0.953 | bed00080ec3b… |

Training scenes use seeds ≥ 10000 and validation scenes ≥ 20000; all evaluation below uses seeds 1–3, so no evaluated frame was trained on. Train and evaluation scenes do come from the same procedural generator (in-distribution).

## 2. Daylight detection by background and lighting

Daylight detection by background and lighting. Seeds [1, 2, 3]. Scenario A: one 0.6 m multirotor at 120 m and one 2 m fixed-wing at 336 m crossing the field of view.

| background / lighting | sensor | pipeline | Precision | Recall | F1 | AP | FP/frame | Det. latency s | Det. continuity |
|---|---|---|---|---|---|---|---|---|---|
| clear_sky / sunny | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| clear_sky / sunny | eo-1 | classical-motion / kalman-gated | 1.000 | 0.996 | 0.998 | 0.996 | 0.000 | 0.03 | 0.996 |
| clear_sky / sunny | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| clear_sky / sunny | eo-1 | cnn-multi / kalman-gated | 0.999 | 0.998 | 0.999 | 1.000 | 0.001 | 0.02 | 0.998 |
| clear_sky / overcast | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| clear_sky / overcast | eo-1 | classical-motion / kalman-gated | 1.000 | 0.996 | 0.998 | 0.996 | 0.000 | 0.03 | 0.996 |
| clear_sky / overcast | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| clear_sky / overcast | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| clear_sky / backlit | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| clear_sky / backlit | eo-1 | classical-motion / kalman-gated | 0.817 | 0.987 | 0.894 | 0.979 | 0.421 | 0.03 | 0.987 |
| clear_sky / backlit | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| clear_sky / backlit | eo-1 | cnn-multi / kalman-gated | 0.998 | 0.998 | 0.998 | 1.000 | 0.004 | 0.02 | 0.998 |
| cloudy / sunny | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| cloudy / sunny | eo-1 | classical-motion / kalman-gated | 0.999 | 0.996 | 0.997 | 0.996 | 0.001 | 0.03 | 0.996 |
| cloudy / sunny | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| cloudy / sunny | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| cloudy / overcast | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| cloudy / overcast | eo-1 | classical-motion / kalman-gated | 1.000 | 0.996 | 0.998 | 0.996 | 0.000 | 0.03 | 0.996 |
| cloudy / overcast | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| cloudy / overcast | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| cloudy / backlit | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| cloudy / backlit | eo-1 | classical-motion / kalman-gated | 0.859 | 0.991 | 0.920 | 0.987 | 0.310 | 0.03 | 0.992 |
| cloudy / backlit | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| cloudy / backlit | eo-1 | cnn-multi / kalman-gated | 0.999 | 0.998 | 0.999 | 1.000 | 0.001 | 0.02 | 0.998 |
| urban / sunny | eo-1 | classical-contrast / kalman-gated | 1.000 | 0.665 | 0.795 | 0.665 | 0.000 | 0.10 | 0.651 |
| urban / sunny | eo-1 | classical-motion / kalman-gated | 1.000 | 0.963 | 0.981 | 0.963 | 0.000 | 0.03 | 0.962 |
| urban / sunny | eo-1 | cnn-day / kalman-gated | 1.000 | 0.736 | 0.846 | 0.747 | 0.000 | 0.09 | 0.725 |
| urban / sunny | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.738 | 0.847 | 0.747 | 0.000 | 0.09 | 0.727 |
| urban / overcast | eo-1 | classical-contrast / kalman-gated | 0.996 | 0.560 | 0.717 | 0.560 | 0.004 | 2.29 | 0.542 |
| urban / overcast | eo-1 | classical-motion / kalman-gated | 0.997 | 0.932 | 0.963 | 0.932 | 0.006 | 0.03 | 0.930 |
| urban / overcast | eo-1 | cnn-day / kalman-gated | 1.000 | 0.632 | 0.773 | 0.637 | 0.000 | 1.41 | 0.617 |
| urban / overcast | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.632 | 0.772 | 0.636 | 0.000 | 1.43 | 0.617 |
| urban / backlit | eo-1 | classical-contrast / kalman-gated | 0.450 | 0.539 | 0.487 | 0.539 | 1.333 | 1.96 | 0.521 |
| urban / backlit | eo-1 | classical-motion / kalman-gated | 0.874 | 0.976 | 0.922 | 0.957 | 0.268 | 0.03 | 0.977 |
| urban / backlit | eo-1 | cnn-day / kalman-gated | 0.995 | 0.609 | 0.755 | 0.619 | 0.006 | 0.41 | 0.593 |
| urban / backlit | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.607 | 0.755 | 0.615 | 0.000 | 0.39 | 0.591 |
| coastal / sunny | eo-1 | classical-contrast / kalman-gated | 0.102 | 1.000 | 0.186 | 1.000 | 16.774 | 0.00 | 1.000 |
| coastal / sunny | eo-1 | classical-motion / kalman-gated | 0.047 | 0.996 | 0.090 | 0.993 | 38.400 | 0.03 | 0.996 |
| coastal / sunny | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| coastal / sunny | eo-1 | cnn-multi / kalman-gated | 0.982 | 0.998 | 0.990 | 1.000 | 0.035 | 0.02 | 0.998 |
| coastal / overcast | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| coastal / overcast | eo-1 | classical-motion / kalman-gated | 1.000 | 0.996 | 0.998 | 0.996 | 0.000 | 0.03 | 0.996 |
| coastal / overcast | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| coastal / overcast | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| coastal / backlit | eo-1 | classical-contrast / kalman-gated | 0.069 | 1.000 | 0.130 | 0.994 | 25.443 | 0.00 | 1.000 |
| coastal / backlit | eo-1 | classical-motion / kalman-gated | 0.046 | 0.991 | 0.089 | 0.987 | 38.733 | 0.03 | 0.992 |
| coastal / backlit | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| coastal / backlit | eo-1 | cnn-multi / kalman-gated | 0.977 | 0.998 | 0.987 | 1.000 | 0.044 | 0.02 | 0.998 |
| vegetation / sunny | eo-1 | classical-contrast / kalman-gated | 1.000 | 0.793 | 0.882 | 0.793 | 0.000 | 0.00 | 0.785 |
| vegetation / sunny | eo-1 | classical-motion / kalman-gated | 0.999 | 0.948 | 0.973 | 0.948 | 0.001 | 0.03 | 0.946 |
| vegetation / sunny | eo-1 | cnn-day / kalman-gated | 1.000 | 0.837 | 0.910 | 0.839 | 0.000 | 0.02 | 0.830 |
| vegetation / sunny | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.835 | 0.908 | 0.838 | 0.000 | 0.02 | 0.828 |
| vegetation / overcast | eo-1 | classical-contrast / kalman-gated | 1.000 | 0.784 | 0.876 | 0.784 | 0.000 | 0.00 | 0.775 |
| vegetation / overcast | eo-1 | classical-motion / kalman-gated | 1.000 | 0.963 | 0.981 | 0.963 | 0.000 | 0.03 | 0.962 |
| vegetation / overcast | eo-1 | cnn-day / kalman-gated | 1.000 | 0.818 | 0.898 | 0.820 | 0.000 | 0.02 | 0.811 |
| vegetation / overcast | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.816 | 0.897 | 0.819 | 0.000 | 0.02 | 0.808 |
| vegetation / backlit | eo-1 | classical-contrast / kalman-gated | 1.000 | 0.795 | 0.883 | 0.795 | 0.000 | 0.00 | 0.786 |
| vegetation / backlit | eo-1 | classical-motion / kalman-gated | 0.830 | 0.981 | 0.899 | 0.967 | 0.383 | 0.03 | 0.982 |
| vegetation / backlit | eo-1 | cnn-day / kalman-gated | 1.000 | 0.838 | 0.911 | 0.842 | 0.000 | 0.02 | 0.832 |
| vegetation / backlit | eo-1 | cnn-multi / kalman-gated | 0.999 | 0.836 | 0.909 | 0.841 | 0.001 | 0.02 | 0.830 |
| open_field / sunny | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| open_field / sunny | eo-1 | classical-motion / kalman-gated | 1.000 | 0.996 | 0.998 | 0.996 | 0.000 | 0.03 | 0.996 |
| open_field / sunny | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| open_field / sunny | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| open_field / overcast | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| open_field / overcast | eo-1 | classical-motion / kalman-gated | 1.000 | 0.996 | 0.998 | 0.996 | 0.000 | 0.03 | 0.996 |
| open_field / overcast | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| open_field / overcast | eo-1 | cnn-multi / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| open_field / backlit | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 1.000 | 0.000 | 0.00 | 1.000 |
| open_field / backlit | eo-1 | classical-motion / kalman-gated | 0.835 | 0.991 | 0.906 | 0.987 | 0.374 | 0.03 | 0.992 |
| open_field / backlit | eo-1 | cnn-day / kalman-gated | 1.000 | 0.998 | 0.999 | 1.000 | 0.000 | 0.02 | 0.998 |
| open_field / backlit | eo-1 | cnn-multi / kalman-gated | 0.999 | 0.998 | 0.998 | 1.000 | 0.003 | 0.02 | 0.998 |

## 3. Haze

Daylight detection versus haze (visibility). Seeds [1, 2, 3]. 

| visibility (m) | sensor | pipeline | Recall | F1 | AP | Target SNR |
|---|---|---|---|---|---|---|
| 20000 m | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 21.7 |
| 20000 m | eo-1 | cnn-day / kalman-gated | 0.998 | 0.999 | 1.000 | 21.7 |
| 8000 m | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 19.8 |
| 8000 m | eo-1 | cnn-day / kalman-gated | 0.998 | 0.999 | 1.000 | 19.8 |
| 4000 m | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 16.9 |
| 4000 m | eo-1 | cnn-day / kalman-gated | 0.998 | 0.999 | 1.000 | 16.9 |
| 2000 m | eo-1 | classical-contrast / kalman-gated | 1.000 | 1.000 | 1.000 | 12.5 |
| 2000 m | eo-1 | cnn-day / kalman-gated | 0.998 | 0.999 | 1.000 | 12.5 |
| 1000 m | eo-1 | classical-contrast / kalman-gated | 0.520 | 0.684 | 0.520 | 6.8 |
| 1000 m | eo-1 | cnn-day / kalman-gated | 0.524 | 0.688 | 0.527 | 6.8 |
| 500 m | eo-1 | classical-contrast / kalman-gated | 0.000 | 0.000 | 0.000 | 3.3 |
| 500 m | eo-1 | cnn-day / kalman-gated | 0.410 | 0.581 | 0.417 | 3.3 |

## 4. Apparent target size

Detection versus range / apparent target size. Seeds [1, 2, 3]. Fixed-wing range is 2.8x the listed multirotor range. size_px is the mean apparent span of both targets mid-run.

| multirotor range (m) | sensor | pipeline | Size px | Recall | F1 | AP | FP/frame |
|---|---|---|---|---|---|---|---|
| 50 m | eo-1 | classical-contrast / kalman-gated | 16.5 | 0.991 | 0.995 | 0.991 | 0.000 |
| 50 m | eo-1 | cnn-day / kalman-gated | 16.5 | 1.000 | 1.000 | 1.000 | 0.000 |
| 50 m | ir-1 | classical-contrast / kalman-gated | 8.3 | 0.966 | 0.982 | 0.966 | 0.000 |
| 50 m | ir-1 | cnn-thermal / kalman-gated | 8.3 | 0.997 | 0.998 | 1.000 | 0.001 |
| 80 m | eo-1 | classical-contrast / kalman-gated | 9.6 | 1.000 | 1.000 | 1.000 | 0.000 |
| 80 m | eo-1 | cnn-day / kalman-gated | 9.6 | 0.997 | 0.999 | 1.000 | 0.000 |
| 80 m | ir-1 | classical-contrast / kalman-gated | 4.8 | 0.865 | 0.923 | 0.865 | 0.000 |
| 80 m | ir-1 | cnn-thermal / kalman-gated | 4.8 | 0.957 | 0.978 | 0.958 | 0.000 |
| 120 m | eo-1 | classical-contrast / kalman-gated | 6.4 | 1.000 | 1.000 | 1.000 | 0.000 |
| 120 m | eo-1 | cnn-day / kalman-gated | 6.4 | 0.998 | 0.999 | 1.000 | 0.000 |
| 120 m | ir-1 | classical-contrast / kalman-gated | 3.2 | 0.629 | 0.729 | 0.629 | 0.000 |
| 120 m | ir-1 | cnn-thermal / kalman-gated | 3.2 | 0.607 | 0.742 | 0.832 | 0.000 |
| 180 m | eo-1 | classical-contrast / kalman-gated | 4.3 | 1.000 | 1.000 | 1.000 | 0.000 |
| 180 m | eo-1 | cnn-day / kalman-gated | 4.3 | 0.998 | 0.999 | 1.000 | 0.000 |
| 180 m | ir-1 | classical-contrast / kalman-gated | 2.1 | 0.398 | 0.479 | 0.398 | 0.000 |
| 180 m | ir-1 | cnn-thermal / kalman-gated | 2.1 | 0.038 | 0.073 | 0.428 | 0.000 |
| 260 m | eo-1 | classical-contrast / kalman-gated | 2.9 | 0.997 | 0.998 | 0.997 | 0.000 |
| 260 m | eo-1 | cnn-day / kalman-gated | 2.9 | 0.865 | 0.928 | 1.000 | 0.000 |
| 260 m | ir-1 | classical-contrast / kalman-gated | 1.5 | 0.195 | 0.274 | 0.195 | 0.000 |
| 260 m | ir-1 | cnn-thermal / kalman-gated | 1.5 | 0.009 | 0.018 | 0.202 | 0.000 |
| 400 m | eo-1 | classical-contrast / kalman-gated | 1.9 | 0.150 | 0.246 | 0.150 | 0.000 |
| 400 m | eo-1 | cnn-day / kalman-gated | 1.9 | 0.082 | 0.151 | 0.728 | 0.000 |
| 400 m | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.000 | 0.000 | 0.000 | 0.000 |
| 400 m | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.001 | 0.002 | 0.003 | 0.000 |
| 600 m | eo-1 | classical-contrast / kalman-gated | 1.3 | 0.000 | 0.000 | 0.000 | 0.000 |
| 600 m | eo-1 | cnn-day / kalman-gated | 1.3 | 0.000 | 0.000 | 0.009 | 0.000 |
| 600 m | ir-1 | classical-contrast / kalman-gated | 0.6 | 0.000 | 0.000 | 0.000 | 0.000 |
| 600 m | ir-1 | cnn-thermal / kalman-gated | 0.6 | 0.000 | 0.000 | 0.000 | 0.000 |

## 5. Low-light: illuminance sweep by sensor

Detection versus scene illuminance by sensor modality. Seeds [1, 2, 3]. Same geometry at every illuminance. Thermal imagery does not depend on visible illuminance in this model; its row varies only through the lighting preset's effect on background temperatures.

| scene illuminance (lux) | sensor | pipeline | Gain | Exposure s | Target SNR | Precision | Recall | F1 | FP/frame | Track continuity |
|---|---|---|---|---|---|---|---|---|---|---|
| 10000 lux | eo-1 | cnn-day / kalman-gated | 1.0 | 0.00018 | 19.6 | 1.000 | 0.998 | 0.999 | 0.000 | 0.993 |
| 10000 lux | eo-1 | classical-contrast / kalman-gated | 1.0 | 0.00018 | 19.6 | 1.000 | 1.000 | 1.000 | 0.000 | 0.996 |
| 10000 lux | ll-1 | cnn-day / kalman-gated | 1.0 | 0.00013 | 19.7 | 1.000 | 0.998 | 0.999 | 0.000 | 0.995 |
| 10000 lux | ll-1 | cnn-lowlight / kalman-gated | 1.0 | 0.00013 | 19.7 | 1.000 | 1.000 | 1.000 | 0.000 | 0.996 |
| 10000 lux | ll-1 | cnn-lowlight+denoise+clahe / kalman-gated | 1.0 | 0.00013 | 19.7 | 1.000 | 0.427 | 0.598 | 0.000 | 0.538 |
| 10000 lux | ll-1 | classical-contrast / kalman-gated | 1.0 | 0.00013 | 19.7 | 1.000 | 1.000 | 1.000 | 0.000 | 0.996 |
| 10000 lux | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.00800 | 73.3 | 0.999 | 0.583 | 0.736 | 0.001 | 0.993 |
| 10000 lux | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.00800 | 73.3 | 1.000 | 0.981 | 0.990 | 0.000 | 0.949 |
| 400 lux | eo-1 | cnn-day / kalman-gated | 1.0 | 0.00440 | 19.9 | 1.000 | 0.998 | 0.999 | 0.000 | 0.993 |
| 400 lux | eo-1 | classical-contrast / kalman-gated | 1.0 | 0.00440 | 19.9 | 1.000 | 1.000 | 1.000 | 0.000 | 0.991 |
| 400 lux | ll-1 | cnn-day / kalman-gated | 1.0 | 0.00063 | 19.1 | 1.000 | 0.998 | 0.999 | 0.000 | 0.994 |
| 400 lux | ll-1 | cnn-lowlight / kalman-gated | 1.0 | 0.00063 | 19.1 | 1.000 | 1.000 | 1.000 | 0.000 | 0.996 |
| 400 lux | ll-1 | cnn-lowlight+denoise+clahe / kalman-gated | 1.0 | 0.00063 | 19.1 | 1.000 | 0.431 | 0.602 | 0.000 | 0.566 |
| 400 lux | ll-1 | classical-contrast / kalman-gated | 1.0 | 0.00063 | 19.1 | 1.000 | 1.000 | 1.000 | 0.000 | 0.996 |
| 400 lux | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.00800 | 73.3 | 0.999 | 0.583 | 0.736 | 0.001 | 0.993 |
| 400 lux | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.00800 | 73.3 | 1.000 | 0.981 | 0.990 | 0.000 | 0.949 |
| 40 lux | eo-1 | cnn-day / kalman-gated | 4.0 | 0.01667 | 7.7 | 1.000 | 0.999 | 1.000 | 0.000 | 0.993 |
| 40 lux | eo-1 | classical-contrast / kalman-gated | 4.0 | 0.01667 | 7.7 | 1.000 | 1.000 | 1.000 | 0.000 | 0.990 |
| 40 lux | ll-1 | cnn-day / kalman-gated | 1.0 | 0.00950 | 17.9 | 1.000 | 0.999 | 1.000 | 0.000 | 0.993 |
| 40 lux | ll-1 | cnn-lowlight / kalman-gated | 1.0 | 0.00950 | 17.9 | 1.000 | 1.000 | 1.000 | 0.000 | 0.996 |
| 40 lux | ll-1 | cnn-lowlight+denoise+clahe / kalman-gated | 1.0 | 0.00950 | 17.9 | 1.000 | 0.422 | 0.593 | 0.000 | 0.558 |
| 40 lux | ll-1 | classical-contrast / kalman-gated | 1.0 | 0.00950 | 17.9 | 1.000 | 1.000 | 1.000 | 0.000 | 0.991 |
| 40 lux | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.618 | 0.752 | 0.000 | 0.839 |
| 40 lux | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.664 | 0.766 | 0.000 | 0.552 |
| 10 lux | eo-1 | cnn-day / kalman-gated | 16.0 | 0.01667 | 3.6 | 0.999 | 0.999 | 0.999 | 0.001 | 0.991 |
| 10 lux | eo-1 | classical-contrast / kalman-gated | 16.0 | 0.01667 | 3.6 | 1.000 | 1.000 | 1.000 | 0.000 | 0.976 |
| 10 lux | ll-1 | cnn-day / kalman-gated | 1.1 | 0.03333 | 12.0 | 1.000 | 0.997 | 0.999 | 0.000 | 0.989 |
| 10 lux | ll-1 | cnn-lowlight / kalman-gated | 1.1 | 0.03333 | 12.0 | 1.000 | 1.000 | 1.000 | 0.000 | 0.991 |
| 10 lux | ll-1 | cnn-lowlight+denoise+clahe / kalman-gated | 1.1 | 0.03333 | 12.0 | 1.000 | 0.448 | 0.618 | 0.000 | 0.614 |
| 10 lux | ll-1 | classical-contrast / kalman-gated | 1.1 | 0.03333 | 12.0 | 1.000 | 1.000 | 1.000 | 0.000 | 0.991 |
| 10 lux | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.618 | 0.752 | 0.000 | 0.839 |
| 10 lux | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.664 | 0.766 | 0.000 | 0.552 |
| 1 lux | eo-1 | cnn-day / kalman-gated | 16.0 | 0.01667 | 0.7 | 0.027 | 0.021 | 0.024 | 1.485 | 0.116 |
| 1 lux | eo-1 | classical-contrast / kalman-gated | 16.0 | 0.01667 | 0.7 | 0.713 | 0.009 | 0.017 | 0.004 | 0.000 |
| 1 lux | ll-1 | cnn-day / kalman-gated | 11.4 | 0.03333 | 3.8 | 1.000 | 0.986 | 0.993 | 0.000 | 0.991 |
| 1 lux | ll-1 | cnn-lowlight / kalman-gated | 11.4 | 0.03333 | 3.8 | 1.000 | 0.999 | 0.999 | 0.000 | 0.991 |
| 1 lux | ll-1 | cnn-lowlight+denoise+clahe / kalman-gated | 11.4 | 0.03333 | 3.8 | 0.993 | 0.439 | 0.607 | 0.006 | 0.753 |
| 1 lux | ll-1 | classical-contrast / kalman-gated | 11.4 | 0.03333 | 3.8 | 1.000 | 1.000 | 1.000 | 0.000 | 0.980 |
| 1 lux | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.618 | 0.752 | 0.000 | 0.839 |
| 1 lux | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.664 | 0.766 | 0.000 | 0.552 |
| 0.2 lux | eo-1 | cnn-day / kalman-gated | 16.0 | 0.01667 | 0.2 | 0.000 | 0.000 | 0.000 | 0.117 | 0.000 |
| 0.2 lux | eo-1 | classical-contrast / kalman-gated | 16.0 | 0.01667 | 0.2 | n/m | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.2 lux | ll-1 | cnn-day / kalman-gated | 57.0 | 0.03333 | 1.6 | 0.810 | 0.837 | 0.823 | 0.374 | 0.990 |
| 0.2 lux | ll-1 | cnn-lowlight / kalman-gated | 57.0 | 0.03333 | 1.6 | 0.989 | 0.868 | 0.925 | 0.018 | 0.990 |
| 0.2 lux | ll-1 | cnn-lowlight+denoise+clahe / kalman-gated | 57.0 | 0.03333 | 1.6 | 0.917 | 0.450 | 0.603 | 0.076 | 0.841 |
| 0.2 lux | ll-1 | classical-contrast / kalman-gated | 57.0 | 0.03333 | 1.6 | 1.000 | 0.900 | 0.947 | 0.000 | 0.332 |
| 0.2 lux | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.618 | 0.752 | 0.000 | 0.839 |
| 0.2 lux | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.664 | 0.766 | 0.000 | 0.552 |
| 0.05 lux | eo-1 | cnn-day / kalman-gated | 16.0 | 0.01667 | 0.0 | 0.000 | 0.000 | 0.000 | 0.093 | 0.000 |
| 0.05 lux | eo-1 | classical-contrast / kalman-gated | 16.0 | 0.01667 | 0.0 | n/m | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.05 lux | ll-1 | cnn-day / kalman-gated | 64.0 | 0.03333 | 0.8 | 0.048 | 0.113 | 0.067 | 4.400 | 0.338 |
| 0.05 lux | ll-1 | cnn-lowlight / kalman-gated | 64.0 | 0.03333 | 0.8 | 0.424 | 0.062 | 0.107 | 0.203 | 0.162 |
| 0.05 lux | ll-1 | cnn-lowlight+denoise+clahe / kalman-gated | 64.0 | 0.03333 | 0.8 | 0.183 | 0.079 | 0.110 | 0.657 | 0.198 |
| 0.05 lux | ll-1 | classical-contrast / kalman-gated | 64.0 | 0.03333 | 0.8 | 0.477 | 0.026 | 0.048 | 0.046 | 0.000 |
| 0.05 lux | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.618 | 0.752 | 0.000 | 0.839 |
| 0.05 lux | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.664 | 0.766 | 0.000 | 0.552 |
| 0.01 lux | eo-1 | cnn-day / kalman-gated | 16.0 | 0.01667 | 0.0 | 0.000 | 0.000 | 0.000 | 0.156 | 0.000 |
| 0.01 lux | eo-1 | classical-contrast / kalman-gated | 16.0 | 0.01667 | 0.0 | n/m | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.01 lux | ll-1 | cnn-day / kalman-gated | 64.0 | 0.03333 | 0.3 | 0.000 | 0.000 | 0.000 | 0.228 | 0.000 |
| 0.01 lux | ll-1 | cnn-lowlight / kalman-gated | 64.0 | 0.03333 | 0.3 | 0.000 | 0.000 | 0.000 | 0.008 | 0.000 |
| 0.01 lux | ll-1 | cnn-lowlight+denoise+clahe / kalman-gated | 64.0 | 0.03333 | 0.3 | 0.011 | 0.001 | 0.001 | 0.138 | 0.000 |
| 0.01 lux | ll-1 | classical-contrast / kalman-gated | 64.0 | 0.03333 | 0.3 | n/m | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.01 lux | ir-1 | cnn-thermal / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.618 | 0.752 | 0.000 | 0.839 |
| 0.01 lux | ir-1 | classical-contrast / kalman-gated | 1.0 | 0.00800 | 147.1 | 1.000 | 0.664 | 0.766 | 0.000 | 0.552 |

## 6. Thermal versus visible by environment

Thermal versus visible detection by environment. Seeds [1, 2, 3]. 

| environment | sensor | pipeline | Target SNR | Precision | Recall | F1 | FP/frame |
|---|---|---|---|---|---|---|---|
| clear sky, day | ir-1 | cnn-thermal / kalman-gated | 149.4 | 0.998 | 0.844 | 0.915 | 0.003 |
| clear sky, day | ir-1 | classical-contrast / kalman-gated | 149.4 | 1.000 | 1.000 | 1.000 | 0.000 |
| clear sky, day | eo-1 | cnn-day / kalman-gated | 21.7 | 1.000 | 0.998 | 0.999 | 0.000 |
| broken cloud, day | ir-1 | cnn-thermal / kalman-gated | 147.1 | 1.000 | 0.607 | 0.742 | 0.000 |
| broken cloud, day | ir-1 | classical-contrast / kalman-gated | 147.1 | 1.000 | 0.629 | 0.729 | 0.000 |
| broken cloud, day | eo-1 | cnn-day / kalman-gated | 21.6 | 1.000 | 0.998 | 0.999 | 0.000 |
| urban skyline, sunny | ir-1 | cnn-thermal / kalman-gated | 149.4 | 1.000 | 0.251 | 0.392 | 0.000 |
| urban skyline, sunny | ir-1 | classical-contrast / kalman-gated | 149.4 | 0.813 | 0.224 | 0.295 | 0.333 |
| urban skyline, sunny | eo-1 | cnn-day / kalman-gated | 11.0 | 1.000 | 0.736 | 0.846 | 0.000 |
| urban skyline, night | ir-1 | cnn-thermal / kalman-gated | 83.4 | 1.000 | 0.346 | 0.513 | 0.000 |
| urban skyline, night | ir-1 | classical-contrast / kalman-gated | 83.4 | 1.000 | 0.319 | 0.483 | 0.000 |
| urban skyline, night | eo-1 | cnn-day / kalman-gated | 0.6 | 0.002 | 0.011 | 0.004 | 9.561 |
| vegetation, overcast | ir-1 | cnn-thermal / kalman-gated | 73.3 | 1.000 | 0.420 | 0.592 | 0.000 |
| vegetation, overcast | ir-1 | classical-contrast / kalman-gated | 73.3 | 1.000 | 0.515 | 0.680 | 0.000 |
| vegetation, overcast | eo-1 | cnn-day / kalman-gated | 21.9 | 1.000 | 0.818 | 0.898 | 0.000 |
| coastal, sunny | ir-1 | cnn-thermal / kalman-gated | 149.4 | 1.000 | 0.670 | 0.797 | 0.000 |
| coastal, sunny | ir-1 | classical-contrast / kalman-gated | 149.4 | 0.999 | 0.762 | 0.855 | 0.001 |
| coastal, sunny | eo-1 | cnn-day / kalman-gated | 21.4 | 1.000 | 0.998 | 0.999 | 0.000 |

## 7. Thermal contrast reduction

Thermal detection versus scene-contrast reduction. Seeds [1, 2, 3]. Scale multiplies all apparent-temperature differences before sensor noise (fog, rain, fouled optics).

| thermal contrast scale | sensor | pipeline | Target SNR | Recall | F1 | HOTA |
|---|---|---|---|---|---|---|
| x1 | ir-1 | cnn-thermal / kalman-gated | 174.6 | 0.636 | 0.764 | 0.756 |
| x1 | ir-1 | classical-contrast / kalman-gated | 174.6 | 0.665 | 0.664 | 0.500 |
| x0.5 | ir-1 | cnn-thermal / kalman-gated | 87.3 | 0.560 | 0.695 | 0.727 |
| x0.5 | ir-1 | classical-contrast / kalman-gated | 87.3 | 0.463 | 0.496 | 0.365 |
| x0.25 | ir-1 | cnn-thermal / kalman-gated | 43.7 | 0.289 | 0.408 | 0.439 |
| x0.25 | ir-1 | classical-contrast / kalman-gated | 43.7 | 0.166 | 0.221 | 0.000 |
| x0.1 | ir-1 | cnn-thermal / kalman-gated | 17.5 | 0.001 | 0.001 | 0.000 |
| x0.1 | ir-1 | classical-contrast / kalman-gated | 17.5 | 0.000 | 0.000 | 0.000 |
| x0.05 | ir-1 | cnn-thermal / kalman-gated | 8.7 | 0.000 | 0.000 | 0.000 |
| x0.05 | ir-1 | classical-contrast / kalman-gated | 8.7 | 0.000 | 0.000 | 0.000 |
| x0.02 | ir-1 | cnn-thermal / kalman-gated | 3.5 | 0.000 | 0.000 | 0.000 |
| x0.02 | ir-1 | classical-contrast / kalman-gated | 3.5 | 0.000 | 0.000 | 0.000 |

## 8. High-speed targets: speed

High-speed targets: tracking versus target speed (30 fps, 150 m). Seeds [1, 2, 3]. 

| target speed (m/s) | sensor | pipeline | px/frame | Recall | HOTA | IDF1 | Track init s | Track continuity | Frag. | Pos. RMSE px | Conf. std |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 10 m/s | eo-1 | cnn-day / sort | 2.7 | 1.000 | 0.882 | 0.998 | 0.03 | 0.996 | 0.0 | 0.82 | 0.040 |
| 10 m/s | eo-1 | cnn-day / bytetrack | 2.7 | 1.000 | 0.882 | 0.998 | 0.03 | 0.996 | 0.0 | 0.82 | 0.040 |
| 10 m/s | eo-1 | cnn-day / kalman-gated | 2.7 | 1.000 | 0.882 | 0.998 | 0.03 | 0.996 | 0.0 | 0.82 | 0.040 |
| 10 m/s | eo-1 | classical-contrast / kalman-gated | 2.7 | 1.000 | 0.892 | 0.987 | 0.20 | 0.973 | 0.0 | 0.79 | 0.019 |
| 10 m/s | eo-1 | classical-motion / kalman-gated | 2.7 | 0.867 | 0.412 | 0.992 | 0.03 | 0.990 | 0.7 | 8.17 | 0.030 |
| 20 m/s | eo-1 | cnn-day / sort | 5.3 | 1.000 | 0.862 | 0.987 | 0.10 | 0.975 | 0.0 | 0.80 | 0.041 |
| 20 m/s | eo-1 | cnn-day / bytetrack | 5.3 | 1.000 | 0.869 | 0.992 | 0.07 | 0.983 | 0.0 | 0.81 | 0.042 |
| 20 m/s | eo-1 | cnn-day / kalman-gated | 5.3 | 1.000 | 0.869 | 0.992 | 0.07 | 0.983 | 0.0 | 0.81 | 0.042 |
| 20 m/s | eo-1 | classical-contrast / kalman-gated | 5.3 | 1.000 | 0.894 | 0.987 | 0.10 | 0.975 | 0.0 | 0.80 | 0.029 |
| 20 m/s | eo-1 | classical-motion / kalman-gated | 5.3 | 1.000 | 0.914 | 0.990 | 0.07 | 0.983 | 0.0 | 0.32 | 0.036 |
| 40 m/s | eo-1 | cnn-day / sort | 10.6 | 1.000 | 0.000 | 0.000 | n/m | 0.000 | 0.0 | n/m | n/m |
| 40 m/s | eo-1 | cnn-day / bytetrack | 10.6 | 1.000 | 0.883 | 0.984 | 0.07 | 0.969 | 0.0 | 0.73 | 0.056 |
| 40 m/s | eo-1 | cnn-day / kalman-gated | 10.6 | 1.000 | 0.883 | 0.984 | 0.07 | 0.969 | 0.0 | 0.73 | 0.056 |
| 40 m/s | eo-1 | classical-contrast / kalman-gated | 10.6 | 1.000 | 0.880 | 0.978 | 0.09 | 0.956 | 0.0 | 0.73 | 0.036 |
| 40 m/s | eo-1 | classical-motion / kalman-gated | 10.6 | 1.000 | 0.911 | 0.984 | 0.07 | 0.969 | 0.0 | 0.42 | 0.048 |
| 60 m/s | eo-1 | cnn-day / sort | 15.9 | 0.986 | 0.000 | 0.000 | n/m | 0.000 | 0.0 | n/m | n/m |
| 60 m/s | eo-1 | cnn-day / bytetrack | 15.9 | 0.986 | 0.752 | 0.807 | 0.08 | 0.634 | 0.0 | 0.54 | 0.064 |
| 60 m/s | eo-1 | cnn-day / kalman-gated | 15.9 | 0.986 | 0.876 | 0.975 | 0.08 | 0.951 | 0.0 | 0.65 | 0.066 |
| 60 m/s | eo-1 | classical-contrast / kalman-gated | 15.9 | 1.000 | 0.879 | 0.976 | 0.07 | 0.952 | 0.0 | 0.69 | 0.044 |
| 60 m/s | eo-1 | classical-motion / kalman-gated | 15.9 | 1.000 | 0.898 | 0.978 | 0.07 | 0.957 | 0.0 | 0.51 | 0.056 |
| 90 m/s | eo-1 | cnn-day / sort | 23.9 | 1.000 | 0.000 | 0.000 | n/m | 0.000 | 0.0 | n/m | n/m |
| 90 m/s | eo-1 | cnn-day / bytetrack | 23.9 | 1.000 | 0.000 | 0.000 | n/m | 0.000 | 0.0 | n/m | n/m |
| 90 m/s | eo-1 | cnn-day / kalman-gated | 23.9 | 1.000 | 0.880 | 0.969 | 0.07 | 0.939 | 0.0 | 0.60 | 0.078 |
| 90 m/s | eo-1 | classical-contrast / kalman-gated | 23.9 | 1.000 | 0.863 | 0.965 | 0.08 | 0.929 | 0.0 | 0.65 | 0.055 |
| 90 m/s | eo-1 | classical-motion / kalman-gated | 23.9 | 1.000 | 0.886 | 0.969 | 0.07 | 0.939 | 0.0 | 0.47 | 0.067 |
| 120 m/s | eo-1 | cnn-day / sort | 31.8 | 0.990 | 0.000 | 0.000 | n/m | 0.000 | 0.0 | n/m | n/m |
| 120 m/s | eo-1 | cnn-day / bytetrack | 31.8 | 0.990 | 0.000 | 0.000 | n/m | 0.000 | 0.0 | n/m | n/m |
| 120 m/s | eo-1 | cnn-day / kalman-gated | 31.8 | 0.990 | 0.860 | 0.953 | 0.08 | 0.909 | 0.0 | 0.56 | 0.091 |
| 120 m/s | eo-1 | classical-contrast / kalman-gated | 31.8 | 1.000 | 0.856 | 0.958 | 0.07 | 0.918 | 0.0 | 0.63 | 0.062 |
| 120 m/s | eo-1 | classical-motion / kalman-gated | 31.8 | 1.000 | 0.861 | 0.958 | 0.07 | 0.918 | 0.0 | 0.53 | 0.076 |
| 150 m/s | eo-1 | cnn-day / sort | 39.8 | 1.000 | 0.000 | 0.000 | n/m | 0.000 | 0.0 | n/m | n/m |
| 150 m/s | eo-1 | cnn-day / bytetrack | 39.8 | 1.000 | 0.000 | 0.000 | n/m | 0.000 | 0.0 | n/m | n/m |
| 150 m/s | eo-1 | cnn-day / kalman-gated | 39.8 | 1.000 | 0.847 | 0.954 | 0.06 | 0.911 | 0.0 | 0.78 | 0.110 |
| 150 m/s | eo-1 | classical-contrast / kalman-gated | 39.8 | 1.000 | 0.840 | 0.954 | 0.06 | 0.911 | 0.0 | 0.80 | 0.070 |
| 150 m/s | eo-1 | classical-motion / kalman-gated | 39.8 | 1.000 | 0.833 | 0.954 | 0.06 | 0.911 | 0.0 | 0.79 | 0.087 |

## 9. High-speed targets: frame rate

High-speed targets: tracking versus frame rate (60 m/s, 150 m). Seeds [1, 2, 3]. 

| frame rate (fps) | sensor | pipeline | px/frame | Recall | HOTA | Track init s | Track continuity | Frag. |
|---|---|---|---|---|---|---|---|---|
| 7.5 fps | eo-1 | cnn-day / sort | 63.7 | 0.972 | 0.000 | n/m | 0.000 | 0.0 |
| 7.5 fps | eo-1 | cnn-day / bytetrack | 63.7 | 0.972 | 0.000 | n/m | 0.000 | 0.0 |
| 7.5 fps | eo-1 | cnn-day / kalman-gated | 63.7 | 0.972 | 0.757 | 0.31 | 0.806 | 0.0 |
| 15 fps | eo-1 | cnn-day / sort | 31.8 | 0.986 | 0.000 | n/m | 0.000 | 0.0 |
| 15 fps | eo-1 | cnn-day / bytetrack | 31.8 | 0.986 | 0.000 | n/m | 0.000 | 0.0 |
| 15 fps | eo-1 | cnn-day / kalman-gated | 31.8 | 0.986 | 0.840 | 0.16 | 0.902 | 0.0 |
| 30 fps | eo-1 | cnn-day / sort | 15.9 | 0.986 | 0.000 | n/m | 0.000 | 0.0 |
| 30 fps | eo-1 | cnn-day / bytetrack | 15.9 | 0.986 | 0.752 | 0.08 | 0.634 | 0.0 |
| 30 fps | eo-1 | cnn-day / kalman-gated | 15.9 | 0.986 | 0.876 | 0.08 | 0.951 | 0.0 |
| 60 fps | eo-1 | cnn-day / sort | 8.0 | 0.993 | 0.764 | 0.06 | 0.644 | 0.0 |
| 60 fps | eo-1 | cnn-day / bytetrack | 8.0 | 0.993 | 0.900 | 0.04 | 0.975 | 0.0 |
| 60 fps | eo-1 | cnn-day / kalman-gated | 8.0 | 0.993 | 0.900 | 0.04 | 0.975 | 0.0 |

## 10. Motion-blur sensitivity

Motion-blur sensitivity: detection versus exposure time (60 m/s, 150 m). Seeds [1, 2, 3]. Exposure is forced; gain/iris keep image brightness constant, so the change is blur, not exposure level.

| exposure time (s) | sensor | pipeline | Blur px | Target SNR | Recall | F1 | HOTA |
|---|---|---|---|---|---|---|---|
| 1/4000 s | eo-1 | classical-contrast / kalman-gated | 0.1 | 21.7 | 1.000 | 1.000 | 0.881 |
| 1/4000 s | eo-1 | cnn-day / kalman-gated | 0.1 | 21.7 | 0.986 | 0.993 | 0.877 |
| 1/4000 s | eo-1 | classical-motion / kalman-gated | 0.1 | 21.7 | 1.000 | 0.983 | 0.898 |
| 1/1000 s | eo-1 | classical-contrast / kalman-gated | 0.4 | 21.7 | 1.000 | 1.000 | 0.882 |
| 1/1000 s | eo-1 | cnn-day / kalman-gated | 0.4 | 21.7 | 0.986 | 0.993 | 0.878 |
| 1/1000 s | eo-1 | classical-motion / kalman-gated | 0.4 | 21.7 | 1.000 | 0.981 | 0.900 |
| 1/250 s | eo-1 | classical-contrast / kalman-gated | 1.6 | 18.2 | 1.000 | 1.000 | 0.890 |
| 1/250 s | eo-1 | cnn-day / kalman-gated | 1.6 | 18.2 | 0.981 | 0.991 | 0.883 |
| 1/250 s | eo-1 | classical-motion / kalman-gated | 1.6 | 18.2 | 1.000 | 0.997 | 0.900 |
| 1/125 s | eo-1 | classical-contrast / kalman-gated | 3.3 | 14.4 | 1.000 | 1.000 | 0.892 |
| 1/125 s | eo-1 | cnn-day / kalman-gated | 3.3 | 14.4 | 0.976 | 0.986 | 0.917 |
| 1/125 s | eo-1 | classical-motion / kalman-gated | 3.3 | 14.4 | 1.000 | 1.000 | 0.896 |
| 1/62 s | eo-1 | classical-contrast / kalman-gated | 6.5 | 9.7 | 1.000 | 1.000 | 0.918 |
| 1/62 s | eo-1 | cnn-day / kalman-gated | 6.5 | 9.7 | 0.296 | 0.456 | 0.893 |
| 1/62 s | eo-1 | classical-motion / kalman-gated | 6.5 | 9.7 | 1.000 | 1.000 | 0.913 |
| 1/30 s | eo-1 | classical-contrast / kalman-gated | 13.5 | 5.8 | 0.564 | 0.713 | 0.000 |
| 1/30 s | eo-1 | cnn-day / kalman-gated | 13.5 | 5.8 | 0.000 | 0.000 | 0.839 |
| 1/30 s | eo-1 | classical-motion / kalman-gated | 13.5 | 5.8 | 1.000 | 1.000 | 0.880 |

## 11. Multiple targets

Multiple targets: tracker comparison. Seeds [1, 2, 3]. 

| scenario | sensor | pipeline | Recall | HOTA | MOTA | MOTP | IDF1 | ID sw. | Frag. | False tracks | False UAV tracks |
|---|---|---|---|---|---|---|---|---|---|---|---|
| scenario D | eo-1 | cnn-day / sort | 0.994 | 0.945 | 0.991 | 0.958 | 0.976 | 0.3 | 0.3 | 0.0 | 0.0 |
| scenario D | eo-1 | cnn-day / bytetrack | 0.994 | 0.957 | 0.990 | 0.958 | 0.995 | 0.0 | 0.3 | 0.0 | 0.0 |
| scenario D | eo-1 | cnn-day / kalman-gated | 0.994 | 0.956 | 0.990 | 0.958 | 0.995 | 0.0 | 0.3 | 0.0 | 0.0 |
| scenario D | eo-1 | classical-contrast / kalman-gated | 0.997 | 0.957 | 0.989 | 0.953 | 0.994 | 0.0 | 0.3 | 0.0 | 0.0 |

## 12. Partial occlusion

Partial occlusion: track recovery versus occluder width. Seeds [1, 2, 3]. Hidden time grows with occluder width; the multirotor passes behind a building at 60 m, the fixed-wing behind a tree at 45 m.

| occluder width (m) | sensor | pipeline | HOTA | IDF1 | ID sw. | Occl. | Same ID after | Re-acq. s | Track continuity |
|---|---|---|---|---|---|---|---|---|---|
| 2 m | eo-1 | cnn-day / sort | 0.516 | 0.488 | 4.0 | 4.0 | 0.0 | 0.28 | 0.856 |
| 2 m | eo-1 | cnn-day / bytetrack | 0.676 | 0.725 | 2.0 | 4.0 | 2.0 | 0.24 | 0.864 |
| 2 m | eo-1 | cnn-day / kalman-gated | 0.839 | 0.933 | 0.0 | 4.0 | 4.0 | 0.21 | 0.874 |
| 4 m | eo-1 | cnn-day / sort | 0.510 | 0.503 | 5.0 | 4.0 | 0.0 | 0.29 | 0.830 |
| 4 m | eo-1 | cnn-day / bytetrack | 0.512 | 0.501 | 4.0 | 4.0 | 0.0 | 0.25 | 0.839 |
| 4 m | eo-1 | cnn-day / kalman-gated | 0.821 | 0.926 | 0.0 | 4.0 | 4.0 | 0.17 | 0.863 |
| 6 m | eo-1 | cnn-day / sort | 0.490 | 0.490 | 4.0 | 4.0 | 0.0 | 0.27 | 0.800 |
| 6 m | eo-1 | cnn-day / bytetrack | 0.490 | 0.490 | 4.0 | 4.0 | 0.0 | 0.26 | 0.800 |
| 6 m | eo-1 | cnn-day / kalman-gated | 0.790 | 0.905 | 0.0 | 4.0 | 4.0 | 0.19 | 0.827 |
| 8 m | eo-1 | cnn-day / sort | 0.310 | 0.286 | 5.0 | 4.0 | 0.0 | 0.24 | 0.742 |
| 8 m | eo-1 | cnn-day / bytetrack | 0.312 | 0.287 | 4.0 | 4.0 | 0.0 | 0.28 | 0.742 |
| 8 m | eo-1 | cnn-day / kalman-gated | 0.495 | 0.517 | 0.0 | 4.0 | 4.0 | 0.16 | 0.784 |
| 10 m | eo-1 | cnn-day / sort | 0.433 | 0.511 | 4.3 | 4.0 | 0.0 | 0.27 | 0.648 |
| 10 m | eo-1 | cnn-day / bytetrack | 0.434 | 0.510 | 4.0 | 4.0 | 0.0 | 0.25 | 0.650 |
| 10 m | eo-1 | cnn-day / kalman-gated | 0.629 | 0.781 | 1.0 | 4.0 | 3.0 | 0.20 | 0.684 |
| 12 m | eo-1 | cnn-day / sort | 0.357 | 0.479 | 4.0 | 4.0 | 0.0 | 0.23 | 0.485 |
| 12 m | eo-1 | cnn-day / bytetrack | 0.359 | 0.475 | 3.7 | 4.0 | 0.0 | 0.23 | 0.494 |
| 12 m | eo-1 | cnn-day / kalman-gated | 0.356 | 0.492 | 3.7 | 4.0 | 0.0 | 0.21 | 0.513 |

## 13. False-positive evaluation

False-positive evaluation: birds, insects, aircraft and background clutter. Seeds [1, 2, 3]. 6 birds, 12 insects, 2 distant aircraft and one UAV per run.

| background | sensor | pipeline | Precision | Recall | F1 | AP | FP/frame | Frames w/ FP | False UAV tracks |
|---|---|---|---|---|---|---|---|---|---|
| cloudy | eo-1 | classical-contrast / kalman-gated | 0.192 | 0.985 | 0.321 | 0.203 | 4.192 | 0.932 | 0.0 |
| cloudy | eo-1 | classical-motion / kalman-gated | 0.131 | 0.989 | 0.231 | 0.225 | 6.523 | 0.936 | 0.0 |
| cloudy | eo-1 | cnn-day / kalman-gated | 0.994 | 0.989 | 0.992 | 0.996 | 0.006 | 0.006 | 0.0 |
| cloudy | eo-1 | cnn-multi / kalman-gated | 0.987 | 0.990 | 0.988 | 0.995 | 0.013 | 0.012 | 0.0 |
| urban | eo-1 | classical-contrast / kalman-gated | 0.232 | 0.985 | 0.373 | 0.261 | 3.400 | 0.890 | 0.0 |
| urban | eo-1 | classical-motion / kalman-gated | 0.128 | 0.989 | 0.227 | 0.236 | 6.669 | 0.937 | 0.0 |
| urban | eo-1 | cnn-day / kalman-gated | 0.993 | 0.989 | 0.991 | 0.995 | 0.007 | 0.007 | 0.0 |
| urban | eo-1 | cnn-multi / kalman-gated | 0.982 | 0.990 | 0.986 | 0.995 | 0.018 | 0.017 | 0.0 |
| coastal | eo-1 | classical-contrast / kalman-gated | 0.049 | 0.985 | 0.093 | 0.197 | 19.003 | 1.000 | 0.0 |
| coastal | eo-1 | classical-motion / kalman-gated | 0.021 | 0.989 | 0.042 | 0.220 | 44.790 | 0.983 | 0.0 |
| coastal | eo-1 | cnn-day / kalman-gated | 0.989 | 0.989 | 0.989 | 0.995 | 0.011 | 0.011 | 0.0 |
| coastal | eo-1 | cnn-multi / kalman-gated | 0.946 | 0.990 | 0.967 | 0.993 | 0.057 | 0.053 | 0.0 |
| vegetation | eo-1 | classical-contrast / kalman-gated | 0.224 | 0.985 | 0.362 | 0.249 | 3.604 | 0.872 | 0.0 |
| vegetation | eo-1 | classical-motion / kalman-gated | 0.127 | 0.989 | 0.225 | 0.236 | 6.764 | 0.919 | 0.0 |
| vegetation | eo-1 | cnn-day / kalman-gated | 0.994 | 0.989 | 0.992 | 0.995 | 0.006 | 0.006 | 0.0 |
| vegetation | eo-1 | cnn-multi / kalman-gated | 0.987 | 0.990 | 0.988 | 0.995 | 0.013 | 0.013 | 0.0 |

False-positive causes (count over all backgrounds and seeds):

| detector | aircraft | background | bird | insect |
|---|---|---|---|---|
| classical-contrast | 436 | 13339 | 10787 | 2618 |
| classical-motion | 557 | 42460 | 12443 | 2812 |
| cnn-day | 0 | 0 | 24 | 2 |
| cnn-multi | 0 | 36 | 52 | 3 |

## 14. Sensor degradation

Sensor degradation: detection and tracking under injected faults. Seeds [1, 2, 3]. 

| fault | sensor | pipeline | Recall | F1 | HOTA | IDF1 | Track continuity | Frag. | Pos. RMSE px |
|---|---|---|---|---|---|---|---|---|---|
| baseline | eo-1 | cnn-day / kalman-gated | 0.996 | 0.998 | 0.946 | 0.996 | 0.993 | 0.0 | 0.47 |
| baseline | ir-1 | cnn-thermal / kalman-gated | 0.636 | 0.764 | 0.756 | 0.804 | 0.826 | 5.3 | 0.51 |
| noise x3 | eo-1 | cnn-day / kalman-gated | 0.998 | 0.998 | 0.946 | 0.996 | 0.993 | 0.0 | 0.47 |
| noise x3 | ir-1 | cnn-thermal / kalman-gated | 0.583 | 0.718 | 0.744 | 0.790 | 0.825 | 5.3 | 0.52 |
| noise x6 | eo-1 | cnn-day / kalman-gated | 0.987 | 0.980 | 0.941 | 0.996 | 0.992 | 0.3 | 0.48 |
| noise x6 | ir-1 | cnn-thermal / kalman-gated | 0.486 | 0.607 | 0.726 | 0.762 | 0.824 | 6.3 | 0.54 |
| 15 fps | eo-1 | cnn-day / kalman-gated | 0.994 | 0.997 | 0.940 | 0.991 | 0.984 | 0.0 | 0.44 |
| 15 fps | ir-1 | cnn-thermal / kalman-gated | 0.634 | 0.762 | 0.747 | 0.800 | 0.817 | 3.7 | 0.57 |
| 7.5 fps | eo-1 | cnn-day / kalman-gated | 1.000 | 1.000 | 0.930 | 0.985 | 0.975 | 0.0 | 0.40 |
| 7.5 fps | ir-1 | cnn-thermal / kalman-gated | 0.592 | 0.729 | 0.727 | 0.792 | 0.801 | 2.3 | 0.63 |
| 20 % frame loss | eo-1 | cnn-day / kalman-gated | 0.996 | 0.998 | 0.943 | 0.995 | 0.991 | 0.0 | 0.48 |
| 20 % frame loss | ir-1 | cnn-thermal / kalman-gated | 0.621 | 0.752 | 0.749 | 0.799 | 0.820 | 5.0 | 0.53 |
| 50 % frame loss | eo-1 | cnn-day / kalman-gated | 0.999 | 0.999 | 0.931 | 0.989 | 0.978 | 0.0 | 0.49 |
| 50 % frame loss | ir-1 | cnn-thermal / kalman-gated | 0.608 | 0.743 | 0.741 | 0.792 | 0.809 | 3.3 | 0.58 |
| 1 s dropout | eo-1 | cnn-day / kalman-gated | 0.995 | 0.998 | 0.944 | 0.995 | 0.992 | 0.0 | 0.47 |
| 1 s dropout | ir-1 | cnn-thermal / kalman-gated | 0.629 | 0.759 | 0.752 | 0.805 | 0.824 | 5.3 | 0.52 |
| 2.5 s dropout | eo-1 | cnn-day / kalman-gated | 0.994 | 0.997 | 0.942 | 0.994 | 0.990 | 0.0 | 0.46 |
| 2.5 s dropout | ir-1 | cnn-thermal / kalman-gated | 0.625 | 0.756 | 0.648 | 0.709 | 0.823 | 5.0 | 0.49 |
| timestamp jitter 10 ms | eo-1 | cnn-day / kalman-gated | 0.996 | 0.998 | 0.907 | 0.996 | 0.993 | 0.0 | 0.73 |
| timestamp jitter 10 ms | ir-1 | cnn-thermal / kalman-gated | 0.624 | 0.753 | 0.747 | 0.803 | 0.824 | 6.0 | 0.57 |
| timestamp jitter 30 ms | eo-1 | cnn-day / kalman-gated | 0.996 | 0.998 | 0.842 | 0.995 | 0.993 | 0.0 | 1.26 |
| timestamp jitter 30 ms | ir-1 | cnn-thermal / kalman-gated | 0.624 | 0.753 | 0.725 | 0.797 | 0.824 | 6.0 | 0.73 |

## 15. Sensor fusion

Sensor fusion: sensor subsets and injected faults. Seeds [1, 2, 3]. Coverage and RMSE are for confirmed 3-D fused tracks on UAV targets. Camera-only co-located configurations cannot produce range, so their coverage is zero by design and their tracks are reported as bearing-only.

| configuration | sensor | pipeline | 3-D coverage | Pos. RMSE m | Init s | False tracks | ID sw. | Bearing-only tracks | Disagreement events | Out-of-seq. |
|---|---|---|---|---|---|---|---|---|---|---|
| all sensors | all | fusion | 0.960 | 2.36 | 0.47 | 1.0 | 0.3 | 0.3 | 0.3 | 0 |
| radar only | radar-1 | fusion | 0.846 | 7.46 | 1.78 | 0.0 | 0.0 | 0.0 | 0.0 | 0 |
| EO + radar | eo-1+radar-1 | fusion | 0.952 | 2.36 | 0.55 | 1.0 | 0.3 | 0.1 | 0.7 | 0 |
| thermal + radar | ir-1+radar-1 | fusion | 0.934 | 2.73 | 0.77 | 0.7 | 0.3 | 0.3 | 0.0 | 0 |
| EO + thermal (co-located) | eo-1+ir-1 | fusion | 0.000 | n/m | n/m | 0.0 | 0.0 | 4.4 | 0.0 | 0 |
| radar + acoustic + RF | radar-1+acoustic-1+rf-1 | fusion | 0.894 | 7.96 | 1.20 | 0.7 | 0.7 | 0.0 | 0.0 | 0 |
| radar dropout 2.5 s | all | fusion | 0.951 | 2.91 | 0.47 | 0.0 | 0.0 | 0.2 | 1.7 | 0 |
| camera latency 0.3 s | all | fusion | 0.916 | 4.09 | 0.80 | 1.0 | 0.0 | 0.8 | 5.7 | 237 |
| camera latency 1.0 s | all | fusion | 0.358 | 14.37 | 5.03 | 0.7 | 0.0 | 0.1 | 3.0 | 54 |
| timestamp jitter 30 ms | all | fusion | 0.951 | 2.07 | 0.47 | 0.7 | 0.0 | 0.3 | 0.7 | 163 |
| two cameras 150 m apart (no radar) | eo-1+eo-2 | fusion | 0.491 | 2.43 | 1.32 | 1.7 | 3.0 | 0.7 | 3.3 | 0 |
| EO boresight error 1.0 deg + radar | eo-1+radar-1 | fusion | 0.953 | 4.34 | 0.55 | 0.3 | 0.3 | 0.1 | 1.0 | 0 |

## 16. Processing latency and computational performance

Measured on the development workstation (CPU inference, ONNX Runtime, 2 threads; several pipelines share one process). GPU utilisation and network bandwidth were not measured.

| run | detect ms | track ms | end-to-end ms | p95 ms | fps | peak RSS MB |
|---|---|---|---|---|---|---|
| G false-positive / cloudy | eo-1 | cnn-day / kalman-gated | 10.86 | 0.491 | 11.35 | 13.06 | 88 | 285 |
| G false-positive / cloudy | eo-1 | classical-contrast / kalman-gated | 8.61 | 0.802 | 9.42 | 11.04 | 106 | 285 |
| E partial occlusion / 10 m structures | eo-1 | cnn-day / kalman-gated | 17.10 | 0.167 | 17.27 | 19.84 | 58 | 303 |
| D multiple targets | eo-1 | cnn-day / bytetrack | 11.22 | 0.411 | 11.64 | 13.30 | 86 | 283 |
| D multiple targets | eo-1 | cnn-day / kalman-gated | 11.44 | 0.487 | 11.93 | 13.61 | 84 | 283 |
| C high-speed / 60 m/s @ 150 m / 30 fps | eo-1 | cnn-day / kalman-gated | 9.62 | 0.168 | 9.79 | 12.15 | 102 | 277 |
| C high-speed / 60 m/s @ 150 m / 30 fps | eo-1 | cnn-day / sort | 9.45 | 0.100 | 9.55 | 11.82 | 105 | 277 |
| B low-light / night_urban | ir-1 | cnn-thermal / kalman-gated | 2.63 | 0.157 | 2.79 | 3.38 | 358 | 239 |
| B low-light / night_urban | ll-1 | cnn-day / kalman-gated | 26.55 | 0.692 | 27.24 | 29.56 | 37 | 337 |
| B low-light / night_urban | ll-1 | cnn-lowlight / kalman-gated | 26.36 | 0.299 | 26.66 | 30.29 | 38 | 337 |
| B low-light / night_urban | eo-1 | cnn-day / kalman-gated | 25.95 | 5.777 | 31.73 | 35.25 | 32 | 275 |
| A daylight / urban / sunny | eo-1 | cnn-day / kalman-gated | 12.58 | 0.284 | 12.87 | 14.35 | 78 | 205 |
| A daylight / cloudy / sunny | eo-1 | classical-contrast / kalman-gated | 8.41 | 0.271 | 8.68 | 9.66 | 115 | 193 |
| A daylight / cloudy / sunny | eo-1 | cnn-day / kalman-gated | 9.64 | 0.319 | 9.96 | 10.99 | 100 | 193 |

## 17. What this report does not show

- No field data: performance on real cameras, thermal cores or radars is unknown.
- The classifier was trained and tested on the same procedural scene generator; the sim-to-real gap is not assessed.
- The YOLO-ONNX adapter, the live camera adapter, Docker deployment and PostgreSQL storage were not exercised.
- Radar, acoustic and RF observations are statistical simulations, not signal-level models.
