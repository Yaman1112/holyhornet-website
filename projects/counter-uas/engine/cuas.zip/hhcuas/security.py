"""Authentication, role-based access control, organisation separation and audit logging.

- Passwords: scrypt (stdlib) with a per-user random salt.
- Tokens: JWT HS256 (PyJWT), 8 h expiry. The signing key comes from CUAS_JWT_SECRET or,
  in development, from a random key generated on first start and stored under data/secrets/.
- No credential is hard-coded. The first administrator's password comes from
  CUAS_ADMIN_PASSWORD or is generated randomly and written once to
  data/secrets/bootstrap_admin.json (git-ignored) for the operator to read and then delete.
- Audit log: append-only table with a SHA-256 hash chain so tampering is detectable.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from datetime import datetime, timedelta, timezone

import jwt

from . import paths
from .store import connect

ROLES = ("viewer", "analyst", "researcher", "admin")
RANK = {r: i for i, r in enumerate(ROLES)}
TOKEN_HOURS = 8
_lock = threading.Lock()
_fail: dict[str, list[float]] = {}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, org TEXT NOT NULL, role TEXT NOT NULL,
  salt TEXT NOT NULL, pw_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, username TEXT, org TEXT, action TEXT NOT NULL,
  resource TEXT, detail TEXT, ip TEXT, prev_hash TEXT, hash TEXT NOT NULL);
"""


def _secret() -> str:
    s = os.environ.get("CUAS_JWT_SECRET")
    if s:
        return s
    paths.SECRETS.mkdir(parents=True, exist_ok=True)
    f = paths.SECRETS / "jwt.key"
    if not f.exists():
        f.write_text(secrets.token_urlsafe(48))
    return f.read_text().strip()


def _hash(pw: str, salt: bytes) -> str:
    return hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32).hex()


def init():
    with _lock, connect() as con:
        con.executescript(SCHEMA)
        n = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if n == 0:
        pw = os.environ.get("CUAS_ADMIN_PASSWORD")
        generated = pw is None
        if generated:
            pw = secrets.token_urlsafe(14)
        org = os.environ.get("CUAS_DEFAULT_ORG", "holyhornet")
        create_user("admin", pw, "admin", org)
        if generated:
            paths.SECRETS.mkdir(parents=True, exist_ok=True)
            (paths.SECRETS / "bootstrap_admin.json").write_text(json.dumps(dict(
                username="admin", password=pw, org=org, note="Generated on first start. Sign in, change it, then delete this file.")))
        audit("system", org, "bootstrap", "users/admin", "initial administrator created" + (" (generated password)" if generated else ""))


def validate_password(pw: str):
    if len(pw) < 10:
        raise ValueError("password must be at least 10 characters")


def create_user(username: str, password: str, role: str, org: str) -> dict:
    if role not in ROLES:
        raise ValueError("unknown role")
    if not username.replace("_", "").replace("-", "").replace(".", "").isalnum() or not org.replace("_", "").replace("-", "").isalnum():
        raise ValueError("username and organisation must be alphanumeric")
    validate_password(password)
    salt = secrets.token_bytes(16)
    with _lock, connect() as con:
        con.execute("INSERT INTO users (username, org, role, salt, pw_hash, created) VALUES (?,?,?,?,?,?)",
                    (username, org, role, salt.hex(), _hash(password, salt), datetime.now(timezone.utc).isoformat(timespec="seconds")))
    return get_user(username)


def get_user(username: str) -> dict | None:
    with connect() as con:
        r = con.execute("SELECT id, username, org, role, active, created FROM users WHERE username=?", (username,)).fetchone()
    return dict(r) if r else None


def list_users(org: str) -> list[dict]:
    with connect() as con:
        return [dict(r) for r in con.execute("SELECT id, username, org, role, active, created FROM users WHERE org=? ORDER BY id", (org,))]


def update_user(username: str, org: str, role: str | None = None, active: bool | None = None, password: str | None = None) -> dict | None:
    u = get_user(username)
    if not u or u["org"] != org:
        return None
    with _lock, connect() as con:
        if role is not None:
            if role not in ROLES:
                raise ValueError("unknown role")
            con.execute("UPDATE users SET role=? WHERE username=?", (role, username))
        if active is not None:
            con.execute("UPDATE users SET active=? WHERE username=?", (1 if active else 0, username))
        if password is not None:
            validate_password(password)
            salt = secrets.token_bytes(16)
            con.execute("UPDATE users SET salt=?, pw_hash=? WHERE username=?", (salt.hex(), _hash(password, salt), username))
    return get_user(username)


def login(username: str, password: str, ip: str = "") -> str | None:
    key = f"{username}|{ip}"
    now = time.time()
    _fail[key] = [t for t in _fail.get(key, []) if now - t < 300]
    if len(_fail[key]) >= 5:
        audit(username, None, "login_blocked", "auth", "too many failed attempts", ip)
        raise PermissionError("too many failed attempts; try again in a few minutes")
    with connect() as con:
        r = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    ok = bool(r) and r["active"] and hmac.compare_digest(_hash(password, bytes.fromhex(r["salt"])), r["pw_hash"])
    if not ok:
        if not r:
            _hash(password, b"0" * 16)          # equalise timing for unknown users
        _fail[key].append(now)
        audit(username, r["org"] if r else None, "login_failed", "auth", "", ip)
        return None
    _fail.pop(key, None)
    audit(username, r["org"], "login", "auth", "", ip)
    exp = datetime.now(timezone.utc) + timedelta(hours=TOKEN_HOURS)
    return jwt.encode(dict(sub=username, org=r["org"], role=r["role"], exp=exp), _secret(), algorithm="HS256")


def verify(token: str) -> dict | None:
    try:
        c = jwt.decode(token, _secret(), algorithms=["HS256"])
    except jwt.PyJWTError:
        return None
    u = get_user(c.get("sub", ""))
    if not u or not u["active"]:
        return None
    return u                                   # role and org always come from the database, not the token


def allowed(user: dict, min_role: str) -> bool:
    return RANK[user["role"]] >= RANK[min_role]


def audit(username: str | None, org: str | None, action: str, resource: str = "", detail: str = "", ip: str = ""):
    ts = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
    with _lock, connect() as con:
        con.executescript(SCHEMA)
        prev = con.execute("SELECT hash FROM audit ORDER BY id DESC LIMIT 1").fetchone()
        prev_hash = prev["hash"] if prev else ""
        h = hashlib.sha256("|".join([prev_hash, ts, username or "", org or "", action, resource, detail, ip]).encode()).hexdigest()
        con.execute("INSERT INTO audit (ts, username, org, action, resource, detail, ip, prev_hash, hash) VALUES (?,?,?,?,?,?,?,?,?)",
                    (ts, username, org, action, resource, detail[:500], ip, prev_hash, h))


def audit_log(org: str, limit: int = 300) -> list[dict]:
    with connect() as con:
        return [dict(r) for r in con.execute("SELECT id, ts, username, org, action, resource, detail, ip FROM audit WHERE org=? ORDER BY id DESC LIMIT ?", (org, limit))]


def verify_audit_chain() -> dict:
    with connect() as con:
        rows = con.execute("SELECT * FROM audit ORDER BY id").fetchall()
    prev = ""
    for r in rows:
        h = hashlib.sha256("|".join([prev, r["ts"], r["username"] or "", r["org"] or "", r["action"], r["resource"] or "", r["detail"] or "", r["ip"] or ""]).encode()).hexdigest()
        if r["prev_hash"] != prev or r["hash"] != h:
            return dict(valid=False, entries=len(rows), first_bad_id=r["id"])
        prev = r["hash"]
    return dict(valid=True, entries=len(rows), first_bad_id=None)
