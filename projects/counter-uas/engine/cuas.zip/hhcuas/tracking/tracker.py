"""Multi-object tracking in image coordinates.

One engine, three documented configurations:

  sort          IoU association on raw boxes, 1-frame coast (Bewley et al. 2016 behaviour)
  bytetrack     two-stage association (high- then low-score detections), IoU on boxes
                inflated to 16 px, 1 s coast (Zhang et al. 2022, adapted for tiny boxes)
  kalman-gated  Mahalanobis-gated nearest-neighbour association on the predicted
                position, two-stage, 3 s coast with covariance growth (re-acquisition)

State is a constant-velocity Kalman filter over the box centre in PIXELS. Velocity is
therefore apparent (px/s). Nothing here estimates range or real-world speed: that needs
calibration plus a ranging sensor and is done only in `sensor_fusion`.

Every lifecycle decision is logged as an event with a human-readable reason.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import linear_sum_assignment

from .. import CNN_CLASSES, UAV_CLASSES
from ..detection.base import Detection
from ..evaluation.matching import inflate, iou

H = np.array([[1.0, 0, 0, 0], [0, 1.0, 0, 0]])


@dataclass
class TrackerConfig:
    name: str = "kalman-gated"
    cost: str = "maha"               # 'maha' | 'iou'
    two_stage: bool = True
    high_thr: float = 0.5
    low_thr: float = 0.2
    n_init: int = 3
    max_lost_frames: int = 90
    reacq_min_frames: int = 3
    accel_sigma: float = 250.0       # px/s^2
    init_vel_sigma: float = 600.0    # px/s
    gate: float = 13.8               # chi-square, 2 dof, 99.9 %
    max_dist_px: float = 160.0
    iou_min: float = 0.1
    iou_inflate: float = 0.0
    merge: bool = True


PRESETS = {
    "sort": TrackerConfig(name="sort", cost="iou", two_stage=False, max_lost_frames=1, iou_inflate=0.0, merge=False),
    "bytetrack": TrackerConfig(name="bytetrack", cost="iou", two_stage=True, max_lost_frames=30, iou_inflate=16.0, merge=False),
    "kalman-gated": TrackerConfig(name="kalman-gated"),
}


@dataclass(eq=False)
class Track:
    id: int
    x: np.ndarray
    P: np.ndarray
    w: float
    h: float
    t_first: float
    t_last: float
    frame_first: int
    hits: int = 1
    age: int = 1
    lost: int = 0
    confirmed: bool = False
    score_ema: float = 0.0
    conf: float = 0.0
    status: str = "new_detection"
    reacq_hold: int = 0
    probs: np.ndarray | None = None
    n_probs: int = 0
    label: str = "unknown"
    merge_cnt: dict = field(default_factory=dict)
    history: list = field(default_factory=list)

    @property
    def box(self):
        return (self.x[0] - self.w / 2, self.x[1] - self.h / 2, self.x[0] + self.w / 2, self.x[1] + self.h / 2)

    @property
    def cls(self) -> str:
        if self.probs is None or self.n_probs == 0:
            return self.label
        p = self.probs / self.n_probs
        k = int(np.argmax(p[:-1]))
        return CNN_CLASSES[k] if p[k] >= 0.4 else "unknown"

    @property
    def uav_prob(self):
        if self.probs is None or self.n_probs == 0:
            return None
        return float((self.probs[0] + self.probs[1]) / self.n_probs)


class Tracker:
    def __init__(self, cfg: TrackerConfig | str = "kalman-gated"):
        self.cfg = PRESETS[cfg] if isinstance(cfg, str) else cfg
        self.reset()

    def reset(self):
        self.tracks: list[Track] = []
        self.finished: list[Track] = []
        self.events: list[dict] = []
        self._next = 1
        self._t = None
        self._frame = -1

    # ------------------------------------------------------------ Kalman
    def _predict(self, tr: Track, dt: float):
        F = np.eye(4); F[0, 2] = F[1, 3] = dt
        q = self.cfg.accel_sigma ** 2
        Q = np.zeros((4, 4))
        Q[0, 0] = Q[1, 1] = q * dt ** 4 / 4
        Q[0, 2] = Q[2, 0] = Q[1, 3] = Q[3, 1] = q * dt ** 3 / 2
        Q[2, 2] = Q[3, 3] = q * dt ** 2
        tr.x = F @ tr.x
        tr.P = F @ tr.P @ F.T + Q

    @staticmethod
    def _R(d: Detection) -> np.ndarray:
        s = max(1.0, 0.25 * max(d.w, d.h))
        return np.eye(2) * s * s

    def _update(self, tr: Track, d: Detection):
        z = np.array([d.cx, d.cy])
        S = H @ tr.P @ H.T + self._R(d)
        K = tr.P @ H.T @ np.linalg.inv(S)
        tr.x = tr.x + K @ (z - H @ tr.x)
        tr.P = (np.eye(4) - K @ H) @ tr.P
        tr.w += 0.4 * (d.w - tr.w); tr.h += 0.4 * (d.h - tr.h)

    # ------------------------------------------------------------ association
    def _cost(self, tr: Track, d: Detection) -> float | None:
        c = self.cfg
        if c.cost == "iou":
            a, b = tr.box, (d.x1, d.y1, d.x2, d.y2)
            if c.iou_inflate:
                a, b = inflate(a, c.iou_inflate), inflate(b, c.iou_inflate)
            v = iou(a, b)
            return 1 - v if v >= c.iou_min else None
        y = np.array([d.cx, d.cy]) - tr.x[:2]
        if math.hypot(*y) > c.max_dist_px:
            return None
        S = tr.P[:2, :2] + self._R(d)
        d2 = float(y @ np.linalg.solve(S, y))
        if d2 > c.gate:
            return None
        ratio = max(d.w, d.h, 1.0) / max(tr.w, tr.h, 1.0)
        return d2 + 2.0 * abs(math.log(ratio))

    def _cost_matrix(self, tracks: list[Track], dets: list[Detection], big: float) -> np.ndarray:
        """All track-detection costs at once (same definition as `_cost`, vectorised).
        Pairs outside the gate get `big`."""
        c = self.cfg
        D = np.array([(d.x1, d.y1, d.x2, d.y2) for d in dets], float)            # (M,4)
        if c.cost == "iou":
            T = np.array([tr.box for tr in tracks], float)                         # (N,4)
            if c.iou_inflate:
                def infl(B):
                    cx, cy = (B[:, 0] + B[:, 2]) / 2, (B[:, 1] + B[:, 3]) / 2
                    w = np.maximum(B[:, 2] - B[:, 0], c.iou_inflate); h = np.maximum(B[:, 3] - B[:, 1], c.iou_inflate)
                    return np.stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], 1)
                T, D = infl(T), infl(D)
            ix = np.clip(np.minimum(T[:, None, 2], D[None, :, 2]) - np.maximum(T[:, None, 0], D[None, :, 0]), 0, None)
            iy = np.clip(np.minimum(T[:, None, 3], D[None, :, 3]) - np.maximum(T[:, None, 1], D[None, :, 1]), 0, None)
            inter = ix * iy
            at = (T[:, 2] - T[:, 0]) * (T[:, 3] - T[:, 1]); ad = (D[:, 2] - D[:, 0]) * (D[:, 3] - D[:, 1])
            union = at[:, None] + ad[None] - inter
            v = np.where(inter > 0, inter / np.where(union > 0, union, 1.0), 0.0)
            return np.where(v >= c.iou_min, 1 - v, big)
        dw, dh = D[:, 2] - D[:, 0], D[:, 3] - D[:, 1]
        dc = np.stack([(D[:, 0] + D[:, 2]) / 2, (D[:, 1] + D[:, 3]) / 2], 1)
        r2 = np.maximum(1.0, 0.25 * np.maximum(dw, dh)) ** 2                       # measurement variance per detection
        X = np.array([tr.x[:2] for tr in tracks])
        P = np.array([(tr.P[0, 0], tr.P[0, 1], tr.P[1, 1]) for tr in tracks])
        ts = np.array([max(tr.w, tr.h, 1.0) for tr in tracks])
        y0 = dc[None, :, 0] - X[:, None, 0]; y1 = dc[None, :, 1] - X[:, None, 1]
        sa = P[:, None, 0] + r2[None]; sb = P[:, None, 1] + 0.0 * r2[None]; sd = P[:, None, 2] + r2[None]   # S = P_xy + R
        d2 = (sd * y0 * y0 - 2 * sb * y0 * y1 + sa * y1 * y1) / (sa * sd - sb * sb)                           # y' S^-1 y
        ok = (np.hypot(y0, y1) <= c.max_dist_px) & (d2 <= c.gate)
        cost = d2 + 2.0 * np.abs(np.log(np.maximum(np.maximum(dw, dh), 1.0)[None] / ts[:, None]))
        return np.where(ok, cost, big)

    def _assign(self, tracks: list[Track], dets: list[Detection]):
        if not tracks or not dets:
            return [], list(range(len(tracks))), list(range(len(dets)))
        BIG = 1e6
        C = self._cost_matrix(tracks, dets, BIG)
        r, c = linear_sum_assignment(C)
        m = [(i, j, C[i, j]) for i, j in zip(r, c) if C[i, j] < BIG]
        mi, mj = {i for i, _, _ in m}, {j for _, j, _ in m}
        return m, [i for i in range(len(tracks)) if i not in mi], [j for j in range(len(dets)) if j not in mj]

    def _event(self, tr: Track, kind: str, reason: str, **data):
        self.events.append(dict(t=round(self._t, 4), frame=self._frame, track_id=tr.id, type=kind, reason=reason, **data))

    # ------------------------------------------------------------ step
    def step(self, dets: list[Detection], t: float, frame: int | None = None) -> list[dict]:
        c = self.cfg
        dt = 1 / 30 if self._t is None else max(t - self._t, 1e-3)
        self._t = t
        self._frame = frame if frame is not None else self._frame + 1
        for tr in self.tracks:
            self._predict(tr, dt)
            tr.age += 1
        high = [d for d in dets if d.score >= c.high_thr] if c.two_stage else [d for d in dets if d.score >= c.low_thr]
        low = [d for d in dets if c.low_thr <= d.score < c.high_thr] if c.two_stage else []

        m1, un_t, un_d = self._assign(self.tracks, high)
        matched = [(self.tracks[i], high[j], cost, "high-score") for i, j, cost in m1]
        rest = [self.tracks[i] for i in un_t]
        if low:
            # low-score detections may only extend tracks that were just being tracked; a long-coasting
            # track must be re-acquired by a confident detection, otherwise static clutter steals identities
            cand = [tr for tr in rest if tr.confirmed and tr.lost <= 2]
            m2, un2, _ = self._assign(cand, low)
            matched += [(cand[i], low[j], cost, "low-score (second stage)") for i, j, cost in m2]
            got = {id(cand[i]) for i, _, _ in m2}
            rest = [tr for tr in rest if id(tr) not in got]

        for tr, d, cost, stage in matched:
            gap = tr.lost
            self._update(tr, d)
            tr.hits += 1; tr.lost = 0; tr.t_last = t
            tr.score_ema = d.score if tr.hits == 1 else tr.score_ema + 0.3 * (d.score - tr.score_ema)
            if d.probs:
                p = np.array([d.probs[k] for k in CNN_CLASSES])
                tr.probs = p if tr.probs is None else tr.probs + p
                tr.n_probs += 1
            else:
                tr.label = d.cls
            if not tr.confirmed:
                if tr.hits >= c.n_init:
                    tr.confirmed = True; tr.status = "confirmed"
                    self._event(tr, "confirmed", f"{tr.hits} associated detections in {tr.age} frames (needs {c.n_init})")
                else:
                    tr.status = "new_detection"
            elif gap >= c.reacq_min_frames:
                tr.status = "reacquired"; tr.reacq_hold = 5
                self._event(tr, "reacquired", f"{stage} detection fell inside the predicted gate after {gap} missed frames "
                                              f"({'d²' if c.cost == 'maha' else '1-IoU'}={cost:.2f}); identity kept", gap_frames=gap)
            elif tr.reacq_hold > 0:
                tr.reacq_hold -= 1; tr.status = "reacquired"
            else:
                tr.status = "tracking"

        keep: list[Track] = []
        rest_ids = {id(tr) for tr in rest}
        for tr in self.tracks:
            if id(tr) in rest_ids:
                tr.lost += 1
                if not tr.confirmed:
                    if tr.lost >= 2:
                        tr.status = "completed"
                        self._event(tr, "terminated", "tentative track not supported by further detections (likely noise or clutter)")
                        self.finished.append(tr)
                        continue
                elif tr.lost > c.max_lost_frames:
                    tr.status = "completed"
                    self._event(tr, "terminated", f"no associated detection for {tr.lost} frames (limit {c.max_lost_frames})")
                    self.finished.append(tr)
                    continue
                elif tr.confirmed:
                    if tr.status != "temporarily_lost":
                        self._event(tr, "lost", "no detection inside the association gate; coasting on the motion model")
                    tr.status = "temporarily_lost"
            keep.append(tr)
        self.tracks = keep

        for j in un_d:
            d = high[j]
            x = np.array([d.cx, d.cy, 0.0, 0.0])
            P = np.diag([self._R(d)[0, 0], self._R(d)[0, 0], c.init_vel_sigma ** 2, c.init_vel_sigma ** 2])
            tr = Track(id=self._next, x=x, P=P, w=d.w, h=d.h, t_first=t, t_last=t, frame_first=self._frame, score_ema=d.score, label=d.cls)
            if d.probs:
                tr.probs = np.array([d.probs[k] for k in CNN_CLASSES]); tr.n_probs = 1
            self._next += 1
            self.tracks.append(tr)
            self._event(tr, "created", f"detection (score {d.score:.2f}, {d.cls}) matched no existing track", x=round(d.cx, 1), y=round(d.cy, 1))

        if c.merge:
            self._merge()

        out = []
        for tr in self.tracks:
            tr.conf = float(tr.score_ema * min(1.0, tr.hits / (c.n_init + 2)) * math.exp(-tr.lost * dt / 0.7))
            b = tr.box
            rec = dict(id=tr.id, x1=round(b[0], 1), y1=round(b[1], 1), x2=round(b[2], 1), y2=round(b[3], 1),
                       vx=round(float(tr.x[2]), 1), vy=round(float(tr.x[3]), 1), conf=round(tr.conf, 3), status=tr.status,
                       cls=tr.cls, uav_prob=None if tr.uav_prob is None else round(tr.uav_prob, 3), hits=tr.hits, lost=tr.lost,
                       sigma_px=round(float(math.sqrt(max(tr.P[0, 0] + tr.P[1, 1], 0) / 2)), 2))
            tr.history.append((round(t, 4), self._frame, round(float(tr.x[0]), 1), round(float(tr.x[1]), 1), tr.status, rec["conf"]))
            out.append(rec)
        return out

    def _merge(self):
        live = [tr for tr in self.tracks if tr.confirmed and tr.lost == 0]
        if len(live) < 2:
            return
        X = np.array([tr.x for tr in live])
        size = np.array([max(tr.w, tr.h) for tr in live])
        dist = np.hypot(X[:, None, 0] - X[None, :, 0], X[:, None, 1] - X[None, :, 1])
        dvel = np.hypot(X[:, None, 2] - X[None, :, 2], X[:, None, 3] - X[None, :, 3])
        flag = (dist < np.maximum(4.0, 0.5 * (size[:, None] + size[None]) / 2)) & (dvel < 40.0)
        index = {tr.id: k for k, tr in enumerate(live)}
        drop = set()
        for a, b in np.argwhere(np.triu(flag, 1)):
            A, B = live[a], live[b]
            old, new = (A, B) if A.id < B.id else (B, A)
            old.merge_cnt[new.id] = old.merge_cnt.get(new.id, 0) + 1
            if old.merge_cnt[new.id] >= 5 and new.id not in drop:
                drop.add(new.id)
                new.status = "completed"
                self._event(new, "merged", f"overlapped track {old.id} with matching velocity for 5 frames; merged into the older track",
                            into=old.id)
                self.finished.append(new)
        for k, tr in enumerate(live):                      # reset counters of pairs that no longer overlap
            for other in [o for o in tr.merge_cnt if o in index and not flag[k, index[o]]]:
                del tr.merge_cnt[other]
        if drop:
            self.tracks = [tr for tr in self.tracks if tr.id not in drop]

    # ------------------------------------------------------------ summaries
    def summaries(self) -> list[dict]:
        out = []
        for tr in sorted(self.finished + self.tracks, key=lambda z: z.id):
            if not tr.confirmed:
                continue
            n = len(tr.history)
            upd = sum(1 for h in tr.history if h[4] in ("new_detection", "confirmed", "tracking", "reacquired"))
            final = tr.status if tr in self.finished else ("temporarily_lost" if tr.lost else "tracking")
            out.append(dict(
                id=tr.id, first_t=round(tr.t_first, 3), last_t=round(tr.t_last, 3), frames=n, updates=upd,
                continuity=round(upd / n, 3) if n else None, status=final, cls=tr.cls,
                classified=tr.cls in UAV_CLASSES + ("bird", "aircraft"),
                uav_prob=None if tr.uav_prob is None else round(tr.uav_prob, 3),
                det_conf=round(tr.score_ema, 3), max_conf=round(max((h[5] for h in tr.history), default=0.0), 3),
                history=tr.history))
        return out
