"""Research assistant: answers questions from stored evaluation data only.

This is a deterministic, evidence-grounded query engine (intent matching +
computation over the experiment store). Every answer lists the records it used
and their data origin. It does not call a language model, and it has no
ability to command sensors or authorise any response — it only reads results.
"""
from __future__ import annotations

import re
from collections import defaultdict

import numpy as np

from . import store

RESPONSE_WORDS = ("engage", "neutrali", "shoot", "jam ", "jamming on", "intercept the", "take down", "destroy", "fire ", "launch", "authorize", "authorise", "attack", "disable the drone")


def _f(v, nd=2):
    return "not measured" if v is None else f"{v:.{nd}f}"


def _sweeps(org):
    out = {}
    for r in store.list_experiments(org, kind="sweep"):
        e = store.load(r["id"], org)
        if e and e.get("study") and e["study"] not in out:
            out[e["study"]] = e
    return out


def _pipes(org):
    return [r for r in store.list_experiments(org, kind="pipeline") if r["summary"].get("recall") is not None or r["summary"].get("hota") is not None]


def _origin(recs) -> str:
    o = sorted({r.get("origin") for r in recs if r.get("origin")})
    return ", ".join(o) if o else "none"


def _ans(text, evidence=None, sources=None, caveats=None, origin="simulated"):
    return dict(answer=text, evidence=evidence or [], sources=sources or [], caveats=caveats or [], data_origin=origin)


def best_sensor(org, q):
    sw = _sweeps(org)
    ev, src = [], []
    by = defaultdict(list)
    for key in ("thermal_env", "lowlight", "size"):
        if key in sw:
            src.append(sw[key]["id"])
            for r in sw[key]["series"]:
                if r["detector"].startswith("cnn") and r["enhance"] == "none" and r.get("f1") is not None:
                    by[(key, r["sensor_kind"], r["detector"])].append(r["f1"])
    if not by:
        return _ans("No sensor-comparison study is stored yet. Run the low-light, thermal or size study in Simulation Lab.")
    for (key, kind, det), v in sorted(by.items()):
        ev.append(dict(study=key, sensor=kind, detector=det, mean_f1=round(float(np.mean(v)), 3), conditions=len(v)))
    lines = []
    for key in ("thermal_env", "lowlight", "size"):
        rows = [e for e in ev if e["study"] == key]
        if rows:
            b = max(rows, key=lambda e: e["mean_f1"])
            lines.append(f"- **{key}**: best mean F1 = {b['mean_f1']:.2f} with the **{b['sensor']}** sensor ({b['detector']}), averaged over {b['conditions']} conditions.")
    return _ans("Best-performing sensor depends on the conditions — there is no single winner:\n" + "\n".join(lines) +
                "\n\nThe per-condition rows in the evidence table show where each modality fails.", ev, src,
                ["Means are over the conditions each study happened to include; they are not weighted by operational relevance.",
                 "Simulated sensors: relative behaviour is indicative, absolute values are not."])


def low_light(org, q):
    sw = _sweeps(org).get("lowlight")
    if not sw:
        return _ans("The low-light study has not been run yet.")
    by = defaultdict(dict)
    for r in sw["series"]:
        by[r["label"]][r["x"]] = r
    ev, lines = [], []
    for label, pts in by.items():
        xs = sorted(pts)
        hi, lo = pts[xs[-1]], pts[xs[0]]
        half = next((x for x in sorted(xs, reverse=True) if (pts[x]["f1"] or 0) < 0.5 * (hi["f1"] or 0)), None)
        ev.append(dict(pipeline=label, f1_at_max_lux=hi["f1"], f1_at_min_lux=lo["f1"], lux_where_f1_halves=half,
                       fp_per_frame_at_1_lux=pts.get(1, {}).get("fp_per_frame")))
        if hi["f1"]:
            lines.append(f"- {label}: F1 {_f(hi['f1'])} at {xs[-1]:g} lux → {_f(lo['f1'])} at {xs[0]:g} lux" +
                         (f"; drops below half at ≈{half:g} lux" if half is not None else "; never drops below half"))
    return _ans("Effect of illuminance on detection (same geometry at every level):\n" + "\n".join(lines), ev, [sw["id"]],
                ["Thermal rows change only through background temperature presets, not illuminance.",
                 "Night scenes include lit windows, which act as point-like clutter for visible sensors."])


def lowest_fp(org, q):
    sw = _sweeps(org).get("clutter")
    rows = []
    if sw:
        by = defaultdict(list)
        for r in sw["series"]:
            by[r["detector"]].append(r)
        for det, rs in by.items():
            rows.append(dict(detector=det, fp_per_frame=round(float(np.mean([r["fp_per_frame"] for r in rs])), 3),
                             recall=round(float(np.mean([r["recall"] for r in rs if r["recall"] is not None])), 3), source="clutter study"))
        src = [sw["id"]]
    else:
        by = defaultdict(list)
        for r in _pipes(org):
            if r["summary"].get("fp_per_frame") is not None:
                by[r["detector"]].append(r["summary"])
        rows = [dict(detector=d, fp_per_frame=round(float(np.mean([s["fp_per_frame"] for s in v])), 3),
                     recall=round(float(np.mean([s["recall"] for s in v if s["recall"] is not None] or [0])), 3), source=f"{len(v)} experiments") for d, v in by.items()]
        src = []
    if not rows:
        return _ans("No detection experiments are stored yet.")
    rows.sort(key=lambda r: r["fp_per_frame"])
    b = rows[0]
    return _ans(f"**{b['detector']}** had the lowest false-positive rate: {b['fp_per_frame']:.3f} false positives per frame at recall {b['recall']:.2f}. "
                "Compare the recall column — a detector can reach a low false-positive rate simply by detecting less.", rows, src,
                ["False positives are counted in UAV mode: anything reported as a UAV candidate that is not a UAV."])


def track_init(org, q):
    rows, src = [], []
    by = defaultdict(list)
    for r in _pipes(org):
        if r["summary"].get("track_init_s") is not None:
            by[(r["detector"], r["tracker"])].append(r["summary"]["track_init_s"]); src.append(r["id"])
    for (d, t), v in sorted(by.items()):
        rows.append(dict(detector=d, tracker=t, mean_track_initiation_s=round(float(np.mean(v)), 3), max_s=round(float(np.max(v)), 3), experiments=len(v)))
    sw = _sweeps(org).get("highspeed_speed")
    if sw:
        src.append(sw["id"])
        for r in sw["series"]:
            rows.append(dict(detector=r["detector"], tracker=r["tracker"], condition=f"high-speed {r['x_text']}",
                             mean_track_initiation_s=None if r["track_init_s"] is None else round(r["track_init_s"], 3), never_tracked=len(r["never_tracked"])))
    if not rows:
        return _ans("No tracking experiments are stored yet.")
    v = [r["mean_track_initiation_s"] for r in rows if r.get("experiments") and r["mean_track_initiation_s"] is not None]
    txt = (f"Across stored single-run experiments, track initiation (first visible frame → first confirmed track) averaged "
           f"**{np.mean(v):.2f} s** (range {np.min(v):.2f}–{np.max(v):.2f} s). " if v else "")
    return _ans(txt + "Confirmation needs 3 associated detections, so the floor is about 3 frame periods plus any detection latency. "
                "High-speed rows show where initiation fails entirely (never_tracked > 0).", rows, src[:12])


def lost_targets(org, q):
    rows, src = [], []
    for r in _pipes(org)[:25]:
        e = store.load(r["id"], org)
        if not e or "events" not in e:
            continue
        lost = defaultdict(lambda: dict(lost=0, reacquired=0))
        for ev in e["events"]:
            if ev["type"] in ("lost", "reacquired"):
                lost[ev["track_id"]][ev["type"]] += 1
        occ = e["metrics"]["tracking"]["occlusion"]["events"]
        if lost or occ:
            src.append(r["id"])
            for o in occ:
                rows.append(dict(experiment=r["id"], target=o["gt"], hidden_s=round(o["hidden_s"], 2), tracked_before=o["tracked_before"],
                                 reacquired=o["reacquired"], same_id=o["same_id"], reacquire_s=None if o["reacquire_s"] is None else round(o["reacquire_s"], 2)))
            if not occ:
                rows.append(dict(experiment=r["id"], target="(no occlusion)", tracks_temporarily_lost=len(lost),
                                 reacquired=sum(1 for v in lost.values() if v["reacquired"])))
    if not rows:
        return _ans("No stored experiment contains a temporarily lost track.")
    occ = [r for r in rows if "hidden_s" in r and r["tracked_before"]]
    txt = (f"{len(occ)} tracked targets were hidden by occluders in the stored runs; {sum(r['reacquired'] for r in occ)} were re-acquired and "
           f"{sum(r['same_id'] for r in occ)} kept the same track ID. " if occ else "")
    return _ans(txt + "Rows list each temporarily lost target and whether its identity survived.", rows, src)


def motion_blur(org, q):
    sw = _sweeps(org)
    b = sw.get("highspeed_blur")
    if not b:
        return _ans("The motion-blur study has not been run yet.")
    rows = [dict(pipeline=r["label"], exposure=r["x_text"], blur_px=round(r["blur_px"] or 0, 1), recall=r["recall"], f1=r["f1"], hota=r["hota"]) for r in b["series"]]
    by = defaultdict(list)
    for r in b["series"]:
        by[r["detector"]].append(r)
    lines = []
    for det, rs in by.items():
        rs.sort(key=lambda r: r["x"])
        lines.append(f"- {det}: recall {_f(rs[0]['recall'])} at {rs[0]['blur_px']:.1f} px blur → {_f(rs[-1]['recall'])} at {rs[-1]['blur_px']:.1f} px blur")
    return _ans("Motion blur versus detection (60 m/s target at 150 m, exposure forced, brightness held constant):\n" + "\n".join(lines) +
                "\n\nBlur spreads the target's contrast over more pixels, which lowers the peak response the detectors rely on.", rows, [b["id"]])


def best_continuity(org, q):
    rows = [r for r in _pipes(org) if r["summary"].get("track_continuity") is not None]
    if not rows:
        return _ans("No tracking experiments are stored yet.")
    rows.sort(key=lambda r: (-r["summary"]["track_continuity"], -(r["summary"].get("hota") or 0)))
    ev = [dict(experiment=r["id"], name=r["name"], track_continuity=round(r["summary"]["track_continuity"], 3), hota=r["summary"].get("hota"),
               id_switches=r["summary"].get("id_switches"), origin=r["origin"]) for r in rows[:8]]
    b = rows[0]
    return _ans(f"Best tracking continuity: **{b['name']}** (`{b['id']}`) with {b['summary']['track_continuity']:.3f} of visible UAV frames covered by a confirmed track "
                f"(HOTA {_f(b['summary'].get('hota'))}).", ev, [r["id"] for r in rows[:8]],
                ["Experiments differ in difficulty; the highest continuity is usually the easiest scenario, not the best algorithm."], _origin(rows[:8]))


def fp_causes(org, q):
    tot = defaultdict(int); by_det = defaultdict(lambda: defaultdict(int)); src = []
    sw = _sweeps(org)
    for key in ("clutter", "daylight", "lowlight"):
        if key in sw:
            src.append(sw[key]["id"])
            for r in sw[key]["series"]:
                for c, n in r["fp_causes"].items():
                    tot[c] += n; by_det[r["detector"]][c] += n
    if not tot:
        for r in _pipes(org):
            for c, n in (r["summary"].get("fp_causes") or {}).items():
                tot[c] += n; by_det[r["detector"]][c] += n
            src.append(r["id"])
    if not tot:
        return _ans("No false positives are recorded in the stored experiments.")
    n = sum(tot.values())
    order = sorted(tot.items(), key=lambda kv: -kv[1])
    ev = [dict(cause=c, count=k, share=round(k / n, 3)) for c, k in order]
    ev += [dict(detector=d, **{c: k for c, k in v.items()}) for d, v in by_det.items()]
    expl = dict(bird="birds reported as UAV candidates", background="background structure or sensor noise (cloud edges, building detail, lit windows, glint)",
                insect="insects close to the lens", aircraft="distant aircraft", duplicate="second detection on an already-matched UAV")
    return _ans("Main causes of false detections (UAV mode), all stored studies combined:\n" +
                "\n".join(f"- **{c}** — {k} ({k / n:.0%}): {expl.get(c, c)}" for c, k in order), ev, src[:12])


def overview(org, q):
    rows = store.list_experiments(org)
    kinds = defaultdict(int)
    for r in rows:
        kinds[r["kind"]] += 1
    return _ans("I answer from stored evaluation results only. Questions I can answer:\n"
                "- Which sensor achieved the best detection performance?\n- How did low-light conditions affect detection?\n"
                "- Which model had the lowest false-positive rate?\n- How long did track initiation take?\n- Which targets were temporarily lost?\n"
                "- How did motion blur affect performance?\n- Which experiment had the best tracking continuity?\n- What were the main causes of false detections?\n\n"
                f"The store currently holds {len(rows)} records ({', '.join(f'{v} {k}' for k, v in kinds.items()) or 'none'}).",
                [dict(kind=k, records=v) for k, v in kinds.items()], [], [], _origin(rows))


INTENTS = [
    (r"false.?(positive|alarm|detect).*(cause|why|reason|source)|cause.*false|why.*false", fp_causes),
    (r"lowest.*false|false.?positive rate|fewest false|which model.*false", lowest_fp),
    (r"low.?light|night|dark|illumin|lux", low_light),
    (r"blur|exposure", motion_blur),
    (r"initiat|how long.*track|time to track|confirm", track_init),
    (r"lost|occlu|re.?acqui|disappear", lost_targets),
    (r"continuity|best track|most stable", best_continuity),
    (r"sensor|thermal|radar|modality|camera", best_sensor),
]


def ask(org: str, question: str) -> dict:
    q = question.lower().strip()
    if any(w in q for w in RESPONSE_WORDS):
        return _ans("I can't do that. This assistant only analyses stored evaluation results. It cannot authorise, initiate or recommend "
                    "a defensive response, and the platform contains no engagement functions. Any real-world response is a separately "
                    "authorised, human-supervised decision outside this software.", caveats=["Request declined by design (analysis-only assistant)."], origin="none")
    for pat, fn in INTENTS:
        if re.search(pat, q):
            a = fn(org, q)
            a["intent"] = fn.__name__
            return a
    a = overview(org, q)
    a["intent"] = "overview"
    return a
