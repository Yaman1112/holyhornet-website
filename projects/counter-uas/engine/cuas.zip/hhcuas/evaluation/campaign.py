"""Reproducible evaluation studies (sweeps) and the validation campaign.

    python -m hhcuas.evaluation.campaign            # full campaign -> experiment store + data/reports
    python -m hhcuas.evaluation.campaign --quick    # one seed, fewer points (used by tests/CI)

Each study is a function returning a `sweep` record: one row per
(condition, sensor, pipeline), averaged over the listed seeds. Every row is a
measurement of this software on SIMULATED scenes; nothing is a field result.
"""
from __future__ import annotations

import argparse
import math
import time

import numpy as np

from .. import ORIGIN_SIMULATED, __version__, store
from ..pipeline import PipelineSpec, run_camera
from ..sensor_fusion.engine import FusionConfig
from ..sensor_fusion.run import run_fusion
from ..simulation.scenarios import build_scenario
from ..simulation.world import Simulator

P = PipelineSpec
KEYS = ("precision", "recall", "f1", "ap", "fnr", "fp_per_frame", "false_alarm_frame_rate", "detection_latency_s", "detection_continuity",
        "object_recall", "hota", "deta", "assa", "mota", "motp", "idf1", "id_switches", "fragmentations", "track_init_s",
        "track_continuity", "occlusions", "occlusion_same_id", "occlusion_reacquired", "reacquire_s", "conf_stability",
        "center_rmse_px", "n_tracks", "false_tracks", "false_uav_tracks", "detect_ms", "track_ms", "e2e_ms", "processing_fps",
        "fusion_coverage", "fusion_rmse_m", "fusion_init_s", "fusion_false_tracks", "fusion_id_switches")


def _agg(rows: list[dict]) -> dict:
    out = {}
    for k in KEYS:
        v = [r[k] for r in rows if r.get(k) is not None]
        if v:
            out[k] = float(np.mean(v))
            if k in ("recall", "f1", "hota", "precision"):
                out[k + "_min"], out[k + "_max"] = float(np.min(v)), float(np.max(v))
        else:
            out[k] = None
    causes: dict = {}
    for r in rows:
        for c, n in (r.get("fp_causes") or {}).items():
            causes[c] = causes.get(c, 0) + n
    out["fp_causes"] = causes
    for k in ("tp", "fp", "fn", "positives", "frames"):
        out[k] = int(sum(r.get(k) or 0 for r in rows))
    out["never_detected"] = sorted({f"{x}@seed{r['_seed']}" for r in rows for x in (r.get("never_detected") or [])})
    out["never_tracked"] = sorted({f"{x}@seed{r['_seed']}" for r in rows for x in (r.get("never_tracked") or [])})
    return out


def sweep(study: str, name: str, scenario: str, points: list[tuple], cams: dict[str, list[PipelineSpec]], seeds=(1, 2, 3),
          x_label: str = "", notes: str = "", extra=None, log=print, progress=None) -> dict:
    """points: [(x, x_text, scenario_params)], cams: camera id -> pipelines to run on it."""
    series = []
    t0 = time.time()
    total = len(points) * len(seeds)
    done = 0
    for x, xt, params in points:
        acc: dict = {}
        meta = {}
        for seed in seeds:
            cfg = build_scenario(scenario, seed=seed, **params)
            sim = Simulator(cfg)
            for cam_id, specs in cams.items():
                if cam_id not in [c.id for c in cfg.cameras]:
                    continue
                for spec, res in zip(specs, run_camera(cfg, cam_id, specs, sim=sim, keep_frames=False)):
                    s = store.summarize(res); s["_seed"] = seed
                    acc.setdefault((cam_id, spec.label), []).append(s)
                    fr0 = sim.render(cam_id, sim.n_frames(cam_id) // 2, with_image=True)
                    snr = [g["snr"] for g in fr0.gt if not g["is_clutter"]]
                    meta[(cam_id, spec.label)] = dict(sensor=cam_id, sensor_kind=res["sensor_kind"], detector=spec.detector, tracker=spec.tracker,
                                                      enhance=spec.enhance, exposure_s=res["exposure_s"], gain=res["gain"],
                                                      target_snr_mid=float(np.mean(snr)) if snr else None,
                                                      blur_px=float(np.mean([g["blur_px"] for g in fr0.gt if not g["is_clutter"]])) if snr else None,
                                                      size_px=float(np.mean([g["size_px"] for g in fr0.gt if not g["is_clutter"]])) if snr else None)
            done += 1
            if progress:
                progress(done / total)
        for key, rows in acc.items():
            row = dict(x=x, x_text=xt, label=f"{key[0]} · {key[1]}", n_seeds=len(rows), **meta[key], **_agg(rows))
            if extra:
                row.update(extra(x, params))
            series.append(row)
        log(f"  [{study}] {xt}: " + ", ".join(f"{r['label'].split(' · ')[1].split(' / ')[0]}@{r['sensor']} F1={_f(r['f1'])}" for r in series[-len(acc):]))
    return dict(kind="sweep", origin=ORIGIN_SIMULATED, study=study, name=name, scenario=scenario, x_label=x_label, notes=notes,
                seeds=list(seeds), series=series, software=dict(hhcuas=__version__), sensor="-", sensor_kind="-", detector="-",
                tracker="-", enhance="-", seed=seeds[0], elapsed_s=round(time.time() - t0, 1))


def _f(v):
    return "n/a" if v is None else f"{v:.2f}"


BGS = ["clear_sky", "cloudy", "urban", "coastal", "vegetation", "open_field"]
DAY = ["sunny", "overcast", "backlit"]
KG = "kalman-gated"


def study_daylight(seeds, quick=False, **kw):
    bgs, lights = (BGS[:3], DAY[:2]) if quick else (BGS, DAY)
    pts = [(f"{b}/{l}", f"{b} / {l}", dict(background=b, lighting=l)) for b in bgs for l in lights]
    return sweep("daylight", "Daylight detection by background and lighting", "A", pts,
                 {"eo-1": [P("classical-contrast", KG), P("classical-motion", KG), P("cnn-day", KG), P("cnn-multi", KG)]}, seeds,
                 x_label="background / lighting", extra=lambda x, p: dict(background=p["background"], lighting=p["lighting"]),
                 notes="Scenario A: one 0.6 m multirotor at 120 m and one 2 m fixed-wing at 336 m crossing the field of view.", **kw)


def study_haze(seeds, quick=False, **kw):
    vis = [20000, 2000, 500] if quick else [20000, 8000, 4000, 2000, 1000, 500]
    pts = [(v, f"{v} m", dict(background="clear_sky", visibility_m=v)) for v in vis]
    return sweep("haze", "Daylight detection versus haze (visibility)", "A", pts,
                 {"eo-1": [P("classical-contrast", KG), P("cnn-day", KG)]}, seeds, x_label="visibility (m)", **kw)


def study_size(seeds, quick=False, **kw):
    rng = [60, 150, 400] if quick else [50, 80, 120, 180, 260, 400, 600]
    pts = [(r, f"{r} m", dict(background="cloudy", range_m=r, sensors=("eo", "thermal"))) for r in rng]
    return sweep("size", "Detection versus range / apparent target size", "A", pts,
                 {"eo-1": [P("classical-contrast", KG), P("cnn-day", KG)], "ir-1": [P("classical-contrast", KG), P("cnn-thermal", KG)]},
                 seeds, x_label="multirotor range (m)", notes="Fixed-wing range is 2.8x the listed multirotor range. size_px is the mean apparent span of both targets mid-run.", **kw)


def study_lowlight(seeds, quick=False, **kw):
    lux = [10000, 1, 0.05] if quick else [10000, 400, 40, 10, 1, 0.2, 0.05, 0.01]
    pts = [(l, f"{l:g} lux", dict(lighting="night_urban" if l < 400 else "overcast", illuminance_lux=l, background="cloudy")) for l in lux]
    return sweep("lowlight", "Detection versus scene illuminance by sensor modality", "B", pts, {
        "eo-1": [P("cnn-day", KG), P("classical-contrast", KG)],
        "ll-1": [P("cnn-day", KG), P("cnn-lowlight", KG), P("cnn-lowlight", KG, "denoise+clahe"), P("classical-contrast", KG)],
        "ir-1": [P("cnn-thermal", KG), P("classical-contrast", KG)],
    }, seeds, x_label="scene illuminance (lux)",
        notes="Same geometry at every illuminance. Thermal imagery does not depend on visible illuminance in this model; "
              "its row varies only through the lighting preset's effect on background temperatures.", **kw)


def study_thermal_env(seeds, quick=False, **kw):
    envs = [("clear sky, day", dict(background="clear_sky", lighting="sunny")),
            ("broken cloud, day", dict(background="cloudy", lighting="sunny")),
            ("urban skyline, sunny", dict(background="urban", lighting="sunny")),
            ("urban skyline, night", dict(background="urban", lighting="night_urban")),
            ("vegetation, overcast", dict(background="vegetation", lighting="overcast")),
            ("coastal, sunny", dict(background="coastal", lighting="sunny"))]
    if quick:
        envs = envs[:3]
    pts = [(n, n, dict(sensors=("eo", "thermal"), **p)) for n, p in envs]
    return sweep("thermal_env", "Thermal versus visible detection by environment", "A", pts,
                 {"ir-1": [P("cnn-thermal", KG), P("classical-contrast", KG)], "eo-1": [P("cnn-day", KG)]}, seeds,
                 x_label="environment", **kw)


def study_thermal_contrast(seeds, quick=False, **kw):
    sc = [1.0, 0.1, 0.02] if quick else [1.0, 0.5, 0.25, 0.1, 0.05, 0.02]
    pts = [(s, f"x{s:g}", dict(thermal_contrast_scale=s)) for s in sc]
    return sweep("thermal_contrast", "Thermal detection versus scene-contrast reduction", "F", pts,
                 {"ir-1": [P("cnn-thermal", KG), P("classical-contrast", KG)]}, seeds, x_label="thermal contrast scale",
                 notes="Scale multiplies all apparent-temperature differences before sensor noise (fog, rain, fouled optics).", **kw)


def study_highspeed(seeds, quick=False, **kw):
    sp = [20, 60, 120] if quick else [10, 20, 40, 60, 90, 120, 150]
    fx = 320 / math.tan(math.radians(15))
    pts = [(s, f"{s} m/s", dict(speed_mps=s, range_m=150)) for s in sp]
    return sweep("highspeed_speed", "High-speed targets: tracking versus target speed (30 fps, 150 m)", "C", pts,
                 {"eo-1": [P("cnn-day", "sort"), P("cnn-day", "bytetrack"), P("cnn-day", KG), P("classical-contrast", KG), P("classical-motion", KG)]},
                 seeds, x_label="target speed (m/s)",
                 extra=lambda x, p: dict(px_per_frame=fx * x / 150 / 30, deg_per_s=math.degrees(x / 150)), **kw)


def study_highspeed_fps(seeds, quick=False, **kw):
    fps = [10, 30] if quick else [7.5, 15, 30, 60]
    fx = 320 / math.tan(math.radians(15))
    pts = [(f, f"{f:g} fps", dict(speed_mps=60, range_m=150, fps=f)) for f in fps]
    return sweep("highspeed_fps", "High-speed targets: tracking versus frame rate (60 m/s, 150 m)", "C", pts,
                 {"eo-1": [P("cnn-day", "sort"), P("cnn-day", "bytetrack"), P("cnn-day", KG)]}, seeds, x_label="frame rate (fps)",
                 extra=lambda x, p: dict(px_per_frame=fx * 60 / 150 / x), **kw)


def study_blur(seeds, quick=False, **kw):
    ex = [0.0005, 0.02] if quick else [0.00025, 0.001, 0.004, 0.008, 0.016, 0.033]
    fx = 320 / math.tan(math.radians(15))
    pts = [(e, f"1/{round(1 / e)} s", dict(speed_mps=60, range_m=150, exposure_s=e)) for e in ex]
    return sweep("highspeed_blur", "Motion-blur sensitivity: detection versus exposure time (60 m/s, 150 m)", "C", pts,
                 {"eo-1": [P("classical-contrast", KG), P("cnn-day", KG), P("classical-motion", KG)]}, seeds, x_label="exposure time (s)",
                 extra=lambda x, p: dict(blur_px_nominal=fx * 60 / 150 * x),
                 notes="Exposure is forced; gain/iris keep image brightness constant, so the change is blur, not exposure level.", **kw)


def study_multi(seeds, quick=False, **kw):
    pts = [("D", "scenario D", dict())]
    return sweep("multi_target", "Multiple targets: tracker comparison", "D", pts,
                 {"eo-1": [P("cnn-day", "sort"), P("cnn-day", "bytetrack"), P("cnn-day", KG), P("classical-contrast", KG)]},
                 seeds, x_label="scenario", **kw)


def study_occlusion(seeds, quick=False, **kw):
    ws = [4, 10] if quick else [2, 4, 6, 8, 10, 12]
    pts = [(w, f"{w} m", dict(occluder_width_m=w, background="cloudy", lighting="sunny")) for w in ws]
    return sweep("occlusion", "Partial occlusion: track recovery versus occluder width", "E", pts,
                 {"eo-1": [P("cnn-day", "sort"), P("cnn-day", "bytetrack"), P("cnn-day", KG)]}, seeds, x_label="occluder width (m)",
                 notes="Hidden time grows with occluder width; the multirotor passes behind a building at 60 m, the fixed-wing behind a tree at 45 m.", **kw)


def study_clutter(seeds, quick=False, **kw):
    bg = ["cloudy"] if quick else ["cloudy", "urban", "coastal", "vegetation"]
    pts = [(b, b, dict(background=b)) for b in bg]
    return sweep("clutter", "False-positive evaluation: birds, insects, aircraft and background clutter", "G", pts,
                 {"eo-1": [P("classical-contrast", KG), P("classical-motion", KG), P("cnn-day", KG), P("cnn-multi", KG)]}, seeds,
                 x_label="background", notes="6 birds, 12 insects, 2 distant aircraft and one UAV per run.", **kw)


def study_degradation(seeds, quick=False, **kw):
    pts = [("baseline", "baseline", dict()),
           ("noise x3", "noise x3", dict(noise_mult=3.0)), ("noise x6", "noise x6", dict(noise_mult=6.0)),
           ("15 fps", "15 fps", dict(fps=15)), ("7.5 fps", "7.5 fps", dict(fps=7.5)),
           ("20 % frame loss", "20 % frame loss", dict(frame_drop_prob=0.2)), ("50 % frame loss", "50 % frame loss", dict(frame_drop_prob=0.5)),
           ("1 s dropout", "1 s dropout", dict(dropout_s=1.0)), ("2.5 s dropout", "2.5 s dropout", dict(dropout_s=2.5)),
           ("timestamp jitter 10 ms", "timestamp jitter 10 ms", dict(timestamp_jitter_s=0.01)),
           ("timestamp jitter 30 ms", "timestamp jitter 30 ms", dict(timestamp_jitter_s=0.03))]
    if quick:
        pts = pts[:2] + pts[7:8]
    return sweep("degradation", "Sensor degradation: detection and tracking under injected faults", "F", pts,
                 {"eo-1": [P("cnn-day", KG)], "ir-1": [P("cnn-thermal", KG)]}, seeds, x_label="fault", **kw)


def study_fusion(seeds, quick=False, log=print, progress=None):
    """Sensor-subset ablation and fault sensitivity for the fusion engine (Scenario H / F)."""
    subsets = [("all sensors", None), ("radar only", ["radar-1"]), ("EO + radar", ["eo-1", "radar-1"]),
               ("thermal + radar", ["ir-1", "radar-1"]), ("EO + thermal (co-located)", ["eo-1", "ir-1"]),
               ("radar + acoustic + RF", ["radar-1", "acoustic-1", "rf-1"])]
    faults = [("radar dropout 2.5 s", "F", dict(dropout_s=2.5), None), ("camera latency 0.3 s", "F", dict(latency_s=0.3), None),
              ("camera latency 1.0 s", "F", dict(latency_s=1.0), None),
              ("timestamp jitter 30 ms", "F", dict(timestamp_jitter_s=0.03), None)]
    if quick:
        subsets, faults = subsets[:3], faults[:1]
    series, t0 = [], time.time()
    cases = [(n, "H", {}, s) for n, s in subsets] + faults + [("two cameras 150 m apart (no radar)", "H", dict(second_camera=True), ["eo-1", "eo-2"])]
    cases.append(("EO boresight error 1.0 deg + radar", "H", dict(_calib=1.0), ["eo-1", "radar-1"]))
    for n_case, (name, key, params, use) in enumerate(cases):
        rows = []
        for seed in seeds:
            p = dict(params); calib = p.pop("_calib", None)
            cfg = build_scenario(key, seed=seed, **p)
            if calib:
                cfg.cameras[0].calib_bias_deg = (calib, 0.0)
            res = run_fusion(cfg, sensors=use, detectors={"eo_day": "cnn-day"})
            s = store.summarize(res); s["_seed"] = seed
            s["bearing_only"] = float(np.mean([len(x["bearing_only"]) for x in res["snapshots"]]))
            s["late_dropped"] = res["metrics"]["engine"]["late_dropped"]; s["out_of_sequence"] = res["metrics"]["engine"]["out_of_sequence"]
            s["disagreements"] = sum(1 for e in res["events"] if e["type"] == "sensor_disagreement")
            rows.append(s)
        row = dict(x=name, x_text=name, label="fusion", sensor="+".join(use) if use else "all", sensor_kind="fusion", detector="per-modality cnn",
                   tracker=KG, enhance="none", n_seeds=len(rows), **_agg(rows))
        for k in ("bearing_only", "late_dropped", "out_of_sequence", "disagreements"):
            row[k] = float(np.mean([r[k] for r in rows]))
        row["range_supported"] = row["fusion_coverage"] is not None and row["fusion_coverage"] > 0
        series.append(row)
        log(f"  [fusion] {name}: coverage={_f(row['fusion_coverage'])} rmse={_f(row['fusion_rmse_m'])} m false={_f(row['fusion_false_tracks'])}")
        if progress:
            progress((n_case + 1) / len(cases))
    return dict(kind="sweep", origin=ORIGIN_SIMULATED, study="fusion", name="Sensor fusion: sensor subsets and injected faults", scenario="H",
                x_label="configuration", seeds=list(seeds), series=series, software=dict(hhcuas=__version__), sensor="-", sensor_kind="-",
                detector="-", tracker="-", enhance="-", seed=seeds[0], elapsed_s=round(time.time() - t0, 1),
                notes="Coverage and RMSE are for confirmed 3-D fused tracks on UAV targets. Camera-only co-located configurations cannot "
                      "produce range, so their coverage is zero by design and their tracks are reported as bearing-only.")


STUDIES = {
    "daylight": study_daylight, "haze": study_haze, "size": study_size, "lowlight": study_lowlight,
    "thermal_env": study_thermal_env, "thermal_contrast": study_thermal_contrast, "highspeed_speed": study_highspeed,
    "highspeed_fps": study_highspeed_fps, "highspeed_blur": study_blur, "multi_target": study_multi,
    "occlusion": study_occlusion, "clutter": study_clutter, "degradation": study_degradation, "fusion": study_fusion,
}

# Showcase runs stored with full per-frame results for replay in the UI (demonstration set).
SHOWCASE = [
    ("A", dict(background="cloudy"), "eo-1", [P("cnn-day", KG), P("classical-contrast", KG)]),
    ("A", dict(background="urban"), "eo-1", [P("cnn-day", KG)]),
    ("B", dict(lighting="night_urban"), "eo-1", [P("cnn-day", KG)]),
    ("B", dict(lighting="night_urban"), "ll-1", [P("cnn-lowlight", KG), P("cnn-day", KG)]),
    ("B", dict(lighting="night_urban"), "ir-1", [P("cnn-thermal", KG)]),
    ("C", dict(speed_mps=60), "eo-1", [P("cnn-day", KG), P("cnn-day", "sort")]),
    ("D", dict(), "eo-1", [P("cnn-day", KG), P("cnn-day", "bytetrack")]),
    ("E", dict(background="cloudy", lighting="sunny"), "eo-1", [P("cnn-day", KG)]),
    ("G", dict(), "eo-1", [P("cnn-day", KG), P("classical-contrast", KG)]),
]


def run_campaign(org: str = "holyhornet", quick: bool = False, only: list[str] | None = None, log=print, tag: str = "campaign") -> list[str]:
    seeds = (1,) if quick else (1, 2, 3)
    ids = []
    if not only:
        store.delete_tag(org, tag)
    for name, fn in STUDIES.items():
        if only and name not in only:
            continue
        log(f"[campaign] study {name}")
        res = fn(seeds, quick=quick, log=log)
        for r in store.list_experiments(org, kind="sweep", tag=tag):
            if r["name"] == res["name"]:
                store.delete(r["id"], org)
        ids.append(store.save(res, org, "campaign", [tag, f"study:{name}"]))
    if not only or "showcase" in only:
        log("[campaign] showcase runs")
        for key, params, cam, specs in SHOWCASE:
            cfg = build_scenario(key, seed=1, **params)
            for res in run_camera(cfg, cam, specs):
                ids.append(store.save(res, org, "campaign", [tag, "showcase"]))
        cfg = build_scenario("H", seed=1)
        ids.append(store.save(run_fusion(cfg, detectors={"eo_day": "cnn-day"}), org, "campaign", [tag, "showcase"]))
    return ids


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--org", default="holyhornet")
    ap.add_argument("--threads", type=int, default=0, help="limit OpenCV threads (use when running several campaign processes in parallel)")
    a = ap.parse_args()
    if a.threads:
        import cv2
        cv2.setNumThreads(a.threads)
    t0 = time.time()
    ids = run_campaign(a.org, a.quick, a.only)
    print(f"[campaign] {len(ids)} records in {time.time() - t0:.0f} s")
    from .reports import write_validation_report
    print("[campaign] report:", write_validation_report(a.org))


if __name__ == "__main__":
    main()
