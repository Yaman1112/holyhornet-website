"""Report generation: single-experiment reports, comparison reports and the
campaign validation report. Every number is read from stored results; missing
values are printed as "not measured"."""
from __future__ import annotations

import html
import re
from datetime import datetime, timezone

from .. import __version__, paths, store

NM = "n/m"

COLS = {
    "precision": ("Precision", 3), "recall": ("Recall", 3), "f1": ("F1", 3), "ap": ("AP", 3), "fnr": ("FN rate", 3),
    "fp_per_frame": ("FP/frame", 3), "false_alarm_frame_rate": ("Frames w/ FP", 3), "detection_latency_s": ("Det. latency s", 2),
    "detection_continuity": ("Det. continuity", 3), "hota": ("HOTA", 3), "mota": ("MOTA", 3), "motp": ("MOTP", 3), "idf1": ("IDF1", 3),
    "id_switches": ("ID sw.", 1), "fragmentations": ("Frag.", 1), "track_init_s": ("Track init s", 2),
    "track_continuity": ("Track continuity", 3), "center_rmse_px": ("Pos. RMSE px", 2), "conf_stability": ("Conf. std", 3),
    "occlusions": ("Occl.", 1), "occlusion_same_id": ("Same ID after", 1), "reacquire_s": ("Re-acq. s", 2),
    "false_tracks": ("False tracks", 1), "false_uav_tracks": ("False UAV tracks", 1), "detect_ms": ("Detect ms", 2),
    "track_ms": ("Track ms", 2), "e2e_ms": ("End-to-end ms", 2), "processing_fps": ("Proc. fps", 0),
    "fusion_coverage": ("3-D coverage", 3), "fusion_rmse_m": ("Pos. RMSE m", 2), "fusion_init_s": ("Init s", 2),
    "fusion_false_tracks": ("False tracks", 1), "fusion_id_switches": ("ID sw.", 1), "bearing_only": ("Bearing-only tracks", 1),
    "size_px": ("Size px", 1), "blur_px": ("Blur px", 1), "target_snr_mid": ("Target SNR", 1), "px_per_frame": ("px/frame", 1),
    "gain": ("Gain", 1), "exposure_s": ("Exposure s", 5), "disagreements": ("Disagreement events", 1),
    "out_of_sequence": ("Out-of-seq.", 0), "late_dropped": ("Late dropped", 0),
}


def fmt(v, nd=3):
    if v is None:
        return NM
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, (int, float)):
        return f"{v:.{nd}f}"
    return str(v)


def table(headers: list[str], rows: list[list]) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def sweep_table(sw: dict, cols: list[str], labels: list[str] | None = None, sensors: list[str] | None = None) -> str:
    rows = []
    for r in sw["series"]:
        pipe = r["label"].split(" · ", 1)[-1]
        if labels and not any(pipe.startswith(l) for l in labels):
            continue
        if sensors and r["sensor"] not in sensors:
            continue
        rows.append([r["x_text"], r["sensor"], pipe] + [fmt(r.get(c), COLS[c][1]) for c in cols])
    return table([sw.get("x_label") or "condition", "sensor", "pipeline"] + [COLS[c][0] for c in cols], rows)


def experiment_report_md(e: dict) -> str:
    s = e.get("summary") or store.summarize(e)
    L = [f"# Experiment report — {e.get('name')}", "",
         f"- **Experiment id:** `{e.get('id')}`  ·  created {e.get('created')}",
         f"- **Data origin:** **{str(e.get('origin')).upper()}**" + (" (laboratory simulation — not a field result)" if e.get("origin") == "simulated" else ""),
         f"- **Scenario:** {e.get('scenario')} — seed {e.get('seed')} — config hash `{e.get('config_hash')}`",
         f"- **Sensor:** {e.get('sensor')} ({e.get('sensor_kind')})  ·  **Detector:** {e.get('detector')}  ·  **Tracker:** {e.get('tracker')}  ·  **Enhancement:** {e.get('enhance')}",
         f"- **Software:** hhcuas {e.get('software', {}).get('hhcuas')}", "", "## Recorded conditions", ""]
    L.append(table(["condition", "value"], [[k, v] for k, v in (e.get("conditions") or {}).items()]))
    if "recall" in s:
        L += ["", "## Detection (UAV mode)", "", table(["metric", "value"], [
            ["Precision", fmt(s["precision"])], ["Recall", fmt(s["recall"])], ["F1", fmt(s["f1"])], ["Average precision", fmt(s["ap"])],
            ["False-negative rate", fmt(s["fnr"])], ["False positives per frame", fmt(s["fp_per_frame"])],
            ["Frames with a false positive", fmt(s["false_alarm_frame_rate"])], ["Detection latency (mean, s)", fmt(s["detection_latency_s"])],
            ["Never detected", ", ".join(s["never_detected"]) or "none"], ["Minimum apparent size with recall ≥ 0.5 (px)", fmt(s["min_size_px"], 0)],
            ["Detection continuity", fmt(s["detection_continuity"])], ["TP / FP / FN", f"{s['tp']} / {s['fp']} / {s['fn']}"],
            ["False-positive causes", ", ".join(f"{k}: {v}" for k, v in s["fp_causes"].items()) or "none"]])]
        d = e["metrics"]["detection"]["uav"]
        L += ["", "Recall by apparent size:", "", table(["size", "n", "recall"], [[b["bin"], b["n"], fmt(b["recall"])] for b in d["recall_by_size"]])]
    if "hota" in s:
        L += ["", "## Tracking (class-agnostic)", "", table(["metric", "value"], [
            ["HOTA", fmt(s["hota"])], ["DetA / AssA", f"{fmt(s['deta'])} / {fmt(s['assa'])}"], ["MOTA", fmt(s["mota"])], ["MOTP (similarity)", fmt(s["motp"])],
            ["IDF1", fmt(s["idf1"])], ["Identity switches", fmt(s["id_switches"], 0)], ["Fragmentations", fmt(s["fragmentations"], 0)],
            ["Track initiation, UAV mean (s)", fmt(s["track_init_s"], 2)], ["Track continuity, UAV mean", fmt(s["track_continuity"])],
            ["Occlusions with a track before / re-acquired / same ID", f"{s['occlusions']} / {s['occlusion_reacquired']} / {s['occlusion_same_id']}"],
            ["Position RMSE (px)", fmt(s["center_rmse_px"], 2)], ["Confidence stability (std)", fmt(s["conf_stability"])],
            ["Confirmed tracks / false tracks / false UAV tracks", f"{s['n_tracks']} / {s['false_tracks']} / {s['false_uav_tracks']}"]])]
    if "e2e_ms" in s:
        L += ["", "## Timing and system", "", table(["metric", "value"], [
            ["Detection (ms/frame)", fmt(s["detect_ms"], 2)], ["Tracking (ms/frame)", fmt(s["track_ms"], 3)],
            ["End-to-end processing (ms, mean / p95)", f"{fmt(s['e2e_ms'], 2)} / {fmt(s['e2e_p95_ms'], 2)}"],
            ["Processing throughput (fps)", fmt(s["processing_fps"], 0)], ["Process CPU (%)", fmt(s.get("cpu_percent"), 0)],
            ["Peak memory (MB)", fmt(s.get("rss_mb"), 0)], ["GPU usage", "not measured (CPU inference)"],
            ["Network bandwidth", "not measured (offline run)"]])]
    if "fusion_coverage" in s:
        f = e["metrics"]["fusion"]
        L += ["", "## Sensor fusion", "", table(["target", "class", "3-D coverage", "position RMSE m", "initiation s"],
              [[k, v["cls"], fmt(v["coverage"]), fmt(v["position_rmse_m"], 2), fmt(v["initiation_s"], 2)] for k, v in f["per_target"].items()])]
        L += ["", table(["sensor", "kind", "measurements", "UAV recall", "provides"],
                        [[k, v["kind"], v["measurements"], fmt(v.get("recall")), v["provides"]] for k, v in e["metrics"]["per_sensor"].items()])]
    L += ["", "---", "Laboratory result on simulated data unless the data origin above says otherwise. "
          "This platform is a research and evaluation tool, not a certified counter-UAS system."]
    return "\n".join(L)


def comparison(rows: list[dict]) -> dict:
    """rows: experiment index rows (with summary). Returns table + best-of per metric."""
    keys = [("recall", 1), ("precision", 1), ("f1", 1), ("ap", 1), ("fp_per_frame", -1), ("fnr", -1), ("detection_latency_s", -1),
            ("hota", 1), ("mota", 1), ("idf1", 1), ("id_switches", -1), ("fragmentations", -1), ("track_init_s", -1),
            ("track_continuity", 1), ("center_rmse_px", -1), ("e2e_ms", -1), ("processing_fps", 1)]
    out_rows, best = [], {}
    for r in rows:
        s = r["summary"]
        out_rows.append(dict(id=r["id"], name=r["name"], origin=r["origin"], scenario=r["scenario"], sensor=r["sensor"], sensor_kind=r["sensor_kind"],
                             detector=r["detector"], tracker=r["tracker"], enhance=r["enhance"], seed=r["seed"],
                             **{k: s.get(k) for k, _ in keys}, fp_causes=s.get("fp_causes"), conditions=s.get("conditions")))
    for k, sign in keys:
        v = [(r[k], r["id"]) for r in out_rows if r.get(k) is not None]
        if v:
            best[k] = (max(v) if sign > 0 else min(v))[1]
    same_scene = len({(r["scenario"], r["seed"], r["conditions"].get("background") if r["conditions"] else None) for r in out_rows}) == 1
    return dict(rows=out_rows, best=best, metrics=[k for k, _ in keys], comparable=same_scene,
                caveat=None if same_scene else "These experiments differ in scenario, seed or environment; differences are not attributable to the model or sensor alone.")


def comparison_md(cmp: dict) -> str:
    cols = ["recall", "precision", "f1", "ap", "fp_per_frame", "hota", "mota", "idf1", "id_switches", "track_init_s", "track_continuity", "e2e_ms"]
    rows = []
    for r in cmp["rows"]:
        rows.append([f"`{r['id']}`", r["origin"], r["scenario"], r["sensor"], r["detector"], r["tracker"]] +
                    [("**" + fmt(r[c], COLS[c][1]) + "**") if cmp["best"].get(c) == r["id"] and len(cmp["rows"]) > 1 else fmt(r[c], COLS[c][1]) for c in cols])
    L = ["# Comparison report", "", f"Generated {datetime.now(timezone.utc).isoformat(timespec='seconds')} · hhcuas {__version__}", ""]
    if cmp["caveat"]:
        L += [f"> **Caution:** {cmp['caveat']}", ""]
    L += [table(["experiment", "origin", "scen.", "sensor", "detector", "tracker"] + [COLS[c][0] for c in cols], rows), "",
          "Bold = best value in the column. All values are measured; `n/m` = not measured."]
    return "\n".join(L)


def md_to_html(md: str, title: str = "HolyHornet Counter-UAS Intelligence — report") -> str:
    """Minimal Markdown renderer (headings, tables, lists, bold, code, quotes) for self-contained exports."""
    def inline(t):
        t = html.escape(t)
        t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
        return re.sub(r"`(.+?)`", r"<code>\1</code>", t)
    out, lines, i = [], md.split("\n"), 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")]); i += 1
            out.append("<table><thead><tr>" + "".join(f"<th>{inline(c)}</th>" for c in rows[0]) + "</tr></thead><tbody>" +
                       "".join("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>" for r in rows[2:]) + "</tbody></table>")
            continue
        m = re.match(r"(#+) (.*)", ln)
        if m:
            out.append(f"<h{len(m.group(1))}>{inline(m.group(2))}</h{len(m.group(1))}>")
        elif ln.startswith("- "):
            out.append(f"<li>{inline(ln[2:])}</li>")
        elif ln.startswith("> "):
            out.append(f"<blockquote>{inline(ln[2:])}</blockquote>")
        elif ln.strip() == "---":
            out.append("<hr>")
        elif ln.strip():
            out.append(f"<p>{inline(ln)}</p>")
        i += 1
    css = ("body{font:14px/1.5 system-ui,sans-serif;max-width:1100px;margin:32px auto;padding:0 16px;color:#16202b}"
           "table{border-collapse:collapse;margin:12px 0;font-size:12.5px}th,td{border:1px solid #c9d3dc;padding:4px 8px;text-align:left}"
           "th{background:#eef3f7}code{background:#eef3f7;padding:1px 4px;border-radius:3px}blockquote{border-left:3px solid #c98a00;margin:8px 0;padding:4px 12px;background:#fff8e6}"
           "h1{font-size:22px}h2{font-size:17px;margin-top:28px;border-bottom:1px solid #c9d3dc;padding-bottom:4px}")
    return f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(title)}</title><style>{css}</style></head><body>{''.join(out)}</body></html>"


def _sw(org: str) -> dict:
    out = {}
    for r in store.list_experiments(org, kind="sweep", tag="campaign"):
        e = store.load(r["id"], org)
        if e and e.get("study") not in out:
            out[e["study"]] = e
    return out


def write_validation_report(org: str = "holyhornet") -> str:
    sw = _sw(org)
    from ..detection.registry import list_models
    L = ["# Validation report — HolyHornet Counter-UAS Intelligence", "",
         f"Generated {datetime.now(timezone.utc).isoformat(timespec='seconds')} by `python -m hhcuas.evaluation.campaign` · hhcuas {__version__}", "",
         "> **Scope.** Every number below was measured by running this software on **simulated** scenes (laboratory result). "
         "No real sensor data and no field trials are included. The simulation's sensor and scene models are simplified "
         "(see docs/algorithms/SIMULATION.md), so absolute values do not transfer to real equipment; the report is evidence that "
         "the evaluation machinery works and shows how the implemented algorithms respond to controlled changes.", "",
         "Method: each row is the mean over the listed seeds of one sensor + detector + tracker pipeline. Detection metrics use "
         "the UAV mode (birds, aircraft and insects are distractors). Tracking metrics are class-agnostic. `n/m` = not measured.", ""]
    L += ["## 1. Models under test", "", table(["model", "kind", "trained on", "patches", "val. patch accuracy", "sha256"], [
        [m["name"], m["kind"], "/".join(m["card"]["modalities"]) + " (simulated, seeds " + m["card"]["training"]["seeds"] + ")" if "card" in m else "—",
         m["card"]["training"]["patches"] if "card" in m else "—", fmt(m["card"]["validation"]["patch_accuracy"]) if "card" in m else "—",
         (m["card"]["sha256"][:12] + "…") if "card" in m else "—"] for m in list_models()]), "",
        "Training scenes use seeds ≥ 10000 and validation scenes ≥ 20000; all evaluation below uses seeds 1–3, so no evaluated frame was trained on. "
        "Train and evaluation scenes do come from the same procedural generator (in-distribution).", ""]
    sec = [
        ("daylight", "2. Daylight detection by background and lighting", ["precision", "recall", "f1", "ap", "fp_per_frame", "detection_latency_s", "detection_continuity"], None),
        ("haze", "3. Haze", ["recall", "f1", "ap", "target_snr_mid"], None),
        ("size", "4. Apparent target size", ["size_px", "recall", "f1", "ap", "fp_per_frame"], None),
        ("lowlight", "5. Low-light: illuminance sweep by sensor", ["gain", "exposure_s", "target_snr_mid", "precision", "recall", "f1", "fp_per_frame", "track_continuity"], None),
        ("thermal_env", "6. Thermal versus visible by environment", ["target_snr_mid", "precision", "recall", "f1", "fp_per_frame"], None),
        ("thermal_contrast", "7. Thermal contrast reduction", ["target_snr_mid", "recall", "f1", "hota"], None),
        ("highspeed_speed", "8. High-speed targets: speed", ["px_per_frame", "recall", "hota", "idf1", "track_init_s", "track_continuity", "fragmentations", "center_rmse_px", "conf_stability"], None),
        ("highspeed_fps", "9. High-speed targets: frame rate", ["px_per_frame", "recall", "hota", "track_init_s", "track_continuity", "fragmentations"], None),
        ("highspeed_blur", "10. Motion-blur sensitivity", ["blur_px", "target_snr_mid", "recall", "f1", "hota"], None),
        ("multi_target", "11. Multiple targets", ["recall", "hota", "mota", "motp", "idf1", "id_switches", "fragmentations", "false_tracks", "false_uav_tracks"], None),
        ("occlusion", "12. Partial occlusion", ["hota", "idf1", "id_switches", "occlusions", "occlusion_same_id", "reacquire_s", "track_continuity"], None),
        ("clutter", "13. False-positive evaluation", ["precision", "recall", "f1", "ap", "fp_per_frame", "false_alarm_frame_rate", "false_uav_tracks"], None),
        ("degradation", "14. Sensor degradation", ["recall", "f1", "hota", "idf1", "track_continuity", "fragmentations", "center_rmse_px"], None),
        ("fusion", "15. Sensor fusion", ["fusion_coverage", "fusion_rmse_m", "fusion_init_s", "fusion_false_tracks", "fusion_id_switches", "bearing_only", "disagreements", "out_of_sequence"], None),
    ]
    for key, title, cols, labels in sec:
        L += [f"## {title}", ""]
        if key not in sw:
            L += ["_Study not run._", ""]
            continue
        s = sw[key]
        L += [f"{s['name']}. Seeds {s['seeds']}. {s.get('notes') or ''}", "", sweep_table(s, cols, labels), ""]
        if key == "clutter":
            agg: dict = {}
            for r in s["series"]:
                pipe = r["label"].split(" · ", 1)[-1].split(" / ")[0]
                for c, n in r["fp_causes"].items():
                    agg.setdefault(pipe, {}).setdefault(c, 0); agg[pipe][c] += n
            causes = sorted({c for v in agg.values() for c in v})
            L += ["False-positive causes (count over all backgrounds and seeds):", "",
                  table(["detector"] + causes, [[p] + [v.get(c, 0) for c in causes] for p, v in agg.items()]), ""]
    timing = []
    for r in store.list_experiments(org, kind="pipeline", tag="showcase"):
        s = r["summary"]
        timing.append([r["name"], fmt(s.get("detect_ms"), 2), fmt(s.get("track_ms"), 3), fmt(s.get("e2e_ms"), 2), fmt(s.get("e2e_p95_ms"), 2),
                       fmt(s.get("processing_fps"), 0), fmt(s.get("rss_mb"), 0)])
    L += ["## 16. Processing latency and computational performance", "",
          "Measured on the development workstation (CPU inference, ONNX Runtime, 2 threads; several pipelines share one process). "
          "GPU utilisation and network bandwidth were not measured.", "",
          table(["run", "detect ms", "track ms", "end-to-end ms", "p95 ms", "fps", "peak RSS MB"], timing), "",
          "## 17. What this report does not show", "",
          "- No field data: performance on real cameras, thermal cores or radars is unknown.",
          "- The classifier was trained and tested on the same procedural scene generator; the sim-to-real gap is not assessed.",
          "- The YOLO-ONNX adapter, the live camera adapter, Docker deployment and PostgreSQL storage were not exercised.",
          "- Radar, acoustic and RF observations are statistical simulations, not signal-level models.", ""]
    md = "\n".join(L)
    for p in (paths.REPORTS / "VALIDATION_REPORT.md", paths.REPO / "docs" / "validation" / "VALIDATION_REPORT.md"):
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(md, encoding="utf-8")
    return str(paths.REPO / "docs" / "validation" / "VALIDATION_REPORT.md")
