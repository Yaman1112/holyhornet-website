"""Multi-object tracking metrics: CLEAR-MOT (MOTA/MOTP/IDSW/fragmentation),
IDF1 and HOTA, plus track-initiation, continuity and occlusion-recovery measures.

Evaluation is class-agnostic: ground truth is every non-insect object that is at
least 30 % visible. Tracks sitting on mostly-occluded objects or insects are
ignored rather than counted as false positives. Only confirmed tracks that were
updated in the frame count as tracker output (coasting predictions do not).

Similarity is IoU on boxes inflated to a 16 px minimum side (see matching.py).
HOTA follows Luiten et al. 2021 / TrackEval: global-alignment-weighted Hungarian
matching, averaged over localisation thresholds alpha = 0.05..0.95.
"""
from __future__ import annotations

from collections import Counter, defaultdict

import numpy as np
from scipy.optimize import linear_sum_assignment

from .. import UAV_CLASSES
from .matching import center_dist, match_point, similarity_matrix

VIS_MIN = 0.3
SIM_THR = 0.3
OUTPUT_STATUSES = ("confirmed", "tracking", "reacquired")
ALPHAS = np.arange(0.05, 0.99, 0.05)


def _prepare(frames: list[dict]):
    """-> list of (t, idx, gts, trs, sim) after removing ignore regions."""
    out = []
    for fr in frames:
        if fr.get("dropped"):
            continue
        gts = [g for g in fr["gt"] if g["cls"] != "insect" and g["vis"] >= VIS_MIN]
        ign = [g for g in fr["gt"] if g["cls"] == "insect" or g["vis"] < VIS_MIN]
        trs = [t for t in fr["tracks"] if t["status"] in OUTPUT_STATUSES]
        if ign and trs:
            sim_g = similarity_matrix(gts, trs) if gts else np.zeros((0, len(trs)))
            keep = []
            for j, t in enumerate(trs):
                on_gt = sim_g.shape[0] > 0 and sim_g[:, j].max() >= SIM_THR
                if on_gt or not any(match_point(t, g) for g in ign):
                    keep.append(t)
            trs = keep
        out.append((fr["t"], fr["idx"], gts, trs, similarity_matrix(gts, trs)))
    return out


def clear_mot(prep) -> dict:
    last: dict[str, int] = {}          # gt id -> track id of last match
    was_tracked: dict[str, bool] = {}
    seen_tracked: dict[str, bool] = {}
    n_gt = fp = fn = idsw = frag = 0
    sims, dists = [], []
    gt_frames, gt_hit = Counter(), Counter()
    pairs_per_frame = []
    for t, idx, gts, trs, sim in prep:
        n_gt += len(gts)
        m: dict[int, int] = {}
        used_t: set[int] = set()
        tid_index = {tr["id"]: j for j, tr in enumerate(trs)}
        # keep previous correspondences that are still valid (standard CLEAR rule)
        for i, g in enumerate(gts):
            j = tid_index.get(last.get(g["id"], -1))
            if j is not None and sim[i, j] >= SIM_THR:
                m[i] = j; used_t.add(j)
        rest_g = [i for i in range(len(gts)) if i not in m]
        rest_t = [j for j in range(len(trs)) if j not in used_t]
        if rest_g and rest_t:
            sub = sim[np.ix_(rest_g, rest_t)]
            r, c = linear_sum_assignment(-sub)
            for a, b in zip(r, c):
                if sub[a, b] >= SIM_THR:
                    m[rest_g[a]] = rest_t[b]
        pairs = []
        for i, g in enumerate(gts):
            gid = g["id"]
            gt_frames[gid] += 1
            if i in m:
                tid = trs[m[i]]["id"]
                if gid in last and last[gid] != tid:
                    idsw += 1
                last[gid] = tid
                gt_hit[gid] += 1
                sims.append(sim[i, m[i]])
                dists.append(center_dist(g["bbox"], (trs[m[i]]["x1"], trs[m[i]]["y1"], trs[m[i]]["x2"], trs[m[i]]["y2"])))
                if seen_tracked.get(gid) and not was_tracked.get(gid, False):
                    frag += 1
                was_tracked[gid] = True; seen_tracked[gid] = True
                pairs.append((gid, tid, g, trs[m[i]]))
            else:
                fn += 1
                was_tracked[gid] = False
        fp += len(trs) - len(m)
        pairs_per_frame.append((t, idx, pairs))
    ratios = [gt_hit[g] / gt_frames[g] for g in gt_frames]
    return dict(
        gt_boxes=n_gt, fp=fp, fn=fn, id_switches=idsw, fragmentations=frag,
        mota=(1 - (fn + fp + idsw) / n_gt) if n_gt else None,
        motp=float(np.mean(sims)) if sims else None,
        mean_center_error_px=float(np.mean(dists)) if dists else None,
        rmse_center_px=float(np.sqrt(np.mean(np.square(dists)))) if dists else None,
        mostly_tracked=sum(r >= 0.8 for r in ratios), mostly_lost=sum(r <= 0.2 for r in ratios),
        gt_tracks=len(ratios), _pairs=pairs_per_frame, _coverage={g: gt_hit[g] / gt_frames[g] for g in gt_frames},
    )


def idf1(prep) -> dict:
    gt_ids, tr_ids = {}, {}
    cnt = defaultdict(int)
    g_n, t_n = Counter(), Counter()
    for _, _, gts, trs, sim in prep:
        for g in gts:
            g_n[g["id"]] += 1; gt_ids.setdefault(g["id"], len(gt_ids))
        for t in trs:
            t_n[t["id"]] += 1; tr_ids.setdefault(t["id"], len(tr_ids))
        for i, g in enumerate(gts):
            for j, t in enumerate(trs):
                if sim[i, j] >= SIM_THR:
                    cnt[(g["id"], t["id"])] += 1
    G, T = len(gt_ids), len(tr_ids)
    tot_g, tot_t = sum(g_n.values()), sum(t_n.values())
    if not G or not T:
        return dict(idf1=0.0 if tot_g else None, idtp=0, idfp=tot_t, idfn=tot_g)
    M = np.zeros((G, T))
    for (g, t), n in cnt.items():
        M[gt_ids[g], tr_ids[t]] = n
    r, c = linear_sum_assignment(-M)
    idtp = int(M[r, c].sum())
    return dict(idf1=2 * idtp / (tot_g + tot_t) if tot_g + tot_t else None, idtp=idtp, idfp=tot_t - idtp, idfn=tot_g - idtp)


def hota(prep) -> dict:
    gt_ids, tr_ids = {}, {}
    for _, _, gts, trs, _ in prep:
        for g in gts:
            gt_ids.setdefault(g["id"], len(gt_ids))
        for t in trs:
            tr_ids.setdefault(t["id"], len(tr_ids))
    G, T = len(gt_ids), len(tr_ids)
    n_gt = sum(len(p[2]) for p in prep); n_tr = sum(len(p[3]) for p in prep)
    if n_gt == 0:
        return dict(hota=None, deta=None, assa=None, loca=None)
    if G == 0 or T == 0:
        return dict(hota=0.0, deta=0.0, assa=0.0, loca=None)
    pot = np.zeros((G, T)); g_cnt = np.zeros(G); t_cnt = np.zeros(T)
    for _, _, gts, trs, sim in prep:
        gi = [gt_ids[g["id"]] for g in gts]; ti = [tr_ids[t["id"]] for t in trs]
        g_cnt[gi] += 1; t_cnt[ti] += 1
        if gi and ti:
            den = sim.sum(0)[None] + sim.sum(1)[:, None] - sim
            pot[np.ix_(gi, ti)] += np.where(den > 0, sim / np.maximum(den, 1e-12), 0)
    galign = pot / np.maximum(g_cnt[:, None] + t_cnt[None] - pot, 1e-12)
    A = len(ALPHAS)
    tp = np.zeros(A); loc = np.zeros(A)
    mc = np.zeros((A, G, T))
    for _, _, gts, trs, sim in prep:
        if not gts or not trs:
            continue
        gi = np.array([gt_ids[g["id"]] for g in gts]); ti = np.array([tr_ids[t["id"]] for t in trs])
        r, c = linear_sum_assignment(-(galign[np.ix_(gi, ti)] * sim))
        s = sim[r, c]
        for a, alpha in enumerate(ALPHAS):
            ok = s >= alpha - 1e-9
            tp[a] += ok.sum(); loc[a] += s[ok].sum()
            mc[a, gi[r[ok]], ti[c[ok]]] += 1
    fn = n_gt - tp; fp = n_tr - tp
    deta = tp / np.maximum(tp + fn + fp, 1)
    assa = np.zeros(A)
    for a in range(A):
        ass = mc[a] / np.maximum(g_cnt[:, None] + t_cnt[None] - mc[a], 1)
        assa[a] = (mc[a] * ass).sum() / max(tp[a], 1)
    h = np.sqrt(deta * assa)
    return dict(hota=float(h.mean()), deta=float(deta.mean()), assa=float(assa.mean()),
                loca=float((loc / np.maximum(tp, 1)).mean()), hota_at_0_5=float(h[9]))


def _runs(flags: list[bool]):
    """-> list of (start, end_exclusive, value)"""
    out, s = [], 0
    for i in range(1, len(flags) + 1):
        if i == len(flags) or flags[i] != flags[s]:
            out.append((s, i, flags[s])); s = i
    return out


def evaluate_tracking(frames: list[dict]) -> dict:
    prep = _prepare(frames)
    cm = clear_mot(prep)
    pairs = cm.pop("_pairs"); coverage = cm.pop("_coverage")
    res = dict(clear=cm, **idf1(prep), **hota(prep))

    # ---- per-object timelines
    by_gid: dict[str, dict] = defaultdict(lambda: dict(t=[], vis=[], tid=[], cls=None))
    for fr in frames:
        if fr.get("dropped"):
            continue
        for g in fr["gt"]:
            if g["cls"] == "insect":
                continue
            d = by_gid[g["id"]]
            d["t"].append(fr["t"]); d["vis"].append(g["vis"] >= VIS_MIN); d["tid"].append(None); d["cls"] = g["cls"]
    pos = {gid: {t: k for k, t in enumerate(d["t"])} for gid, d in by_gid.items()}
    conf_by_tid = defaultdict(list); cls_votes = defaultdict(Counter); tid_match = Counter()
    for t, idx, ps in pairs:
        for gid, tid, g, tr in ps:
            by_gid[gid]["tid"][pos[gid][t]] = tid
            tid_match[(tid, g["cls"])] += 1
            if g["cls"] in UAV_CLASSES:
                conf_by_tid[tid].append(tr.get("conf", 0.0))
            cls_votes[gid][tr.get("cls", "unknown")] += 1
    init, cont, dom, occl = {}, {}, {}, []
    for gid, d in by_gid.items():
        vis_idx = [k for k, v in enumerate(d["vis"]) if v]
        if not vis_idx:
            continue
        first = next((k for k in vis_idx if d["tid"][k] is not None), None)
        init[gid] = (d["t"][first] - d["t"][vis_idx[0]]) if first is not None else None
        tids = [d["tid"][k] for k in vis_idx if d["tid"][k] is not None]
        cont[gid] = len(tids) / len(vis_idx)
        dom[gid] = (Counter(tids).most_common(1)[0][1] / len(vis_idx)) if tids else 0.0
        runs = _runs(d["vis"])
        for n, (a, b, v) in enumerate(runs):
            if v or n == 0 or n == len(runs) - 1 or b - a < 3:
                continue                         # an occlusion = hidden run of >= 3 frames between visible runs
            before = next((d["tid"][k] for k in range(a - 1, runs[n - 1][0] - 1, -1) if d["tid"][k] is not None), None)
            after_k = next((k for k in range(b, runs[n + 1][1]) if d["tid"][k] is not None), None)
            after = d["tid"][after_k] if after_k is not None else None
            occl.append(dict(gt=gid, hidden_s=d["t"][b - 1] - d["t"][a], tracked_before=before is not None,
                             reacquired=after is not None, same_id=before is not None and before == after,
                             reacquire_s=(d["t"][after_k] - d["t"][b]) if after_k is not None else None))
    # ---- track-level class behaviour
    tracks_seen = Counter(); track_cls = {}
    for _, _, _, trs, _ in prep:                 # tracks on ignore regions (insects, occluded objects) already removed
        for tr in trs:
            tracks_seen[tr["id"]] += 1; track_cls[tr["id"]] = tr.get("cls", "unknown")
    false_tracks = [tid for tid, n in tracks_seen.items()
                    if sum(v for (t2, _), v in tid_match.items() if t2 == tid) < 0.5 * n]
    false_uav = [tid for tid in tracks_seen if track_cls.get(tid) in UAV_CLASSES and
                 sum(v for (t2, c), v in tid_match.items() if t2 == tid and c in UAV_CLASSES) < 0.5 * tracks_seen[tid]]
    uav_gids = [g for g, d in by_gid.items() if d["cls"] in UAV_CLASSES and cls_votes[g]]
    cls_ok = [cls_votes[g].most_common(1)[0][0] in UAV_CLASSES for g in uav_gids]
    inits = [v for g, v in init.items() if v is not None and by_gid[g]["cls"] in UAV_CLASSES]
    occ_tracked = [o for o in occl if o["tracked_before"]]
    stab = [float(np.std(v)) for v in conf_by_tid.values() if len(v) >= 5]
    res.update(
        track_initiation_s=dict(per_target=init, mean_uav=float(np.mean(inits)) if inits else None,
                                max_uav=float(np.max(inits)) if inits else None,
                                never_tracked=[g for g, v in init.items() if v is None]),
        continuity=dict(per_target=cont, dominant_id_fraction=dom,
                        mean=float(np.mean(list(cont.values()))) if cont else None,
                        mean_uav=float(np.mean([v for g, v in cont.items() if by_gid[g]["cls"] in UAV_CLASSES]))
                        if any(by_gid[g]["cls"] in UAV_CLASSES for g in cont) else None),
        occlusion=dict(events=occl, n=len(occ_tracked), reacquired=sum(o["reacquired"] for o in occ_tracked),
                       same_id=sum(o["same_id"] for o in occ_tracked),
                       mean_reacquire_s=float(np.mean([o["reacquire_s"] for o in occ_tracked if o["reacquire_s"] is not None]))
                       if any(o["reacquire_s"] is not None for o in occ_tracked) else None),
        confidence_stability_std=float(np.mean(stab)) if stab else None,
        n_tracks=len(tracks_seen), false_tracks=len(false_tracks), false_uav_tracks=len(false_uav),
        uav_track_class_accuracy=float(np.mean(cls_ok)) if cls_ok else None,
        coverage=coverage,
    )
    return res
