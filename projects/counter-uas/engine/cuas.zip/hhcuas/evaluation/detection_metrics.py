"""Detection metrics computed from stored per-frame detections and ground truth.

Two evaluation modes:
  uav     positives are UAV-class objects; birds, aircraft and insects are distractors.
          Detections are ranked by `uav_score` (detectors that cannot classify are
          ranked by objectness, i.e. everything they report is a UAV candidate).
  object  positives are all aerial objects except insects (class-agnostic detection).

"False-positive rate" for a detector has no true-negative count, so two
well-defined quantities are reported instead: false positives per frame and the
fraction of frames containing at least one false positive.
"""
from __future__ import annotations

from collections import Counter, defaultdict

import numpy as np

from .. import UAV_CLASSES
from .matching import center_dist, match_point

VIS_MIN = 0.3
SIZE_BINS = [(0, 3), (3, 5), (5, 8), (8, 12), (12, 20), (20, 1e9)]
SNR_BINS = [(0, 2), (2, 4), (4, 8), (8, 16), (16, 1e9)]


def _rank(d: dict, mode: str) -> float:
    if mode == "uav" and d.get("uav_score") is not None:
        return d["uav_score"]
    return d["score"]


def _bin_label(lo, hi, unit=""):
    return f"{lo:g}–{hi:g}{unit}" if hi < 1e8 else f"≥{lo:g}{unit}"


def evaluate_detection(frames: list[dict], mode: str = "uav", thr: float = 0.5) -> dict:
    records = []                 # (score, kind, cause)
    npos = 0
    n_frames = 0
    first_vis: dict[str, float] = {}
    first_tp: dict[str, float] = {}
    per_id = defaultdict(lambda: dict(vis=0, det=0, gap=0, max_gap=0))
    size_hit, size_n = Counter(), Counter()
    snr_hit, snr_n = Counter(), Counter()
    fp_frames = 0
    causes = Counter()
    confusion = defaultdict(Counter)
    tp_op = fp_op = 0

    for fr in frames:
        if fr.get("dropped"):
            continue
        n_frames += 1
        gts = fr["gt"]
        is_pos = [(g["cls"] in UAV_CLASSES) if mode == "uav" else (g["cls"] != "insect") for g in gts]
        pos = [i for i, g in enumerate(gts) if is_pos[i] and g["vis"] >= VIS_MIN]
        ign = [i for i, g in enumerate(gts) if (is_pos[i] and g["vis"] < VIS_MIN) or (mode == "object" and g["cls"] == "insect")]
        dis = [i for i, g in enumerate(gts) if not is_pos[i] and i not in ign]
        npos += len(pos)
        dets = sorted(fr["dets"], key=lambda d: -_rank(d, mode))
        taken: set[int] = set()
        matched_op: set[int] = set()
        frame_fp = False
        for d in dets:
            s = _rank(d, mode)
            best, bd = None, 1e9
            for i in pos:
                if i in taken or not match_point(d, gts[i]):
                    continue
                dist = center_dist((d["x1"], d["y1"], d["x2"], d["y2"]), gts[i]["bbox"])
                if dist < bd:
                    best, bd = i, dist
            if best is not None:
                taken.add(best)
                records.append((s, "tp", ""))
                if s >= thr:
                    matched_op.add(best); tp_op += 1
                continue
            if any(match_point(d, gts[i]) for i in ign):
                continue
            cause = "background"
            if any(match_point(d, gts[i]) for i in pos):
                cause = "duplicate"
            else:
                for i in dis:
                    if match_point(d, gts[i]):
                        cause = gts[i]["cls"]
                        break
            records.append((s, "fp", cause))
            if s >= thr:
                fp_op += 1; causes[cause] += 1; frame_fp = True
        fp_frames += frame_fp
        # per-object bookkeeping at the operating point
        for i in pos:
            g = gts[i]
            hit = i in matched_op
            pid = per_id[g["id"]]
            pid["vis"] += 1
            first_vis.setdefault(g["id"], fr["t"])
            if hit:
                pid["det"] += 1; pid["gap"] = 0
                first_tp.setdefault(g["id"], fr["t"])
            else:
                pid["gap"] += 1; pid["max_gap"] = max(pid["max_gap"], pid["gap"])
            for k, (lo, hi) in enumerate(SIZE_BINS):
                if lo <= g["size_px"] < hi:
                    size_n[k] += 1; size_hit[k] += hit
            for k, (lo, hi) in enumerate(SNR_BINS):
                if lo <= g.get("snr", 0) < hi:
                    snr_n[k] += 1; snr_hit[k] += hit
        # classification confusion (object level, any class)
        for g in gts:
            if g["vis"] < VIS_MIN or g["cls"] == "insect":
                continue
            cand = [d for d in dets if d["score"] >= min(thr, 0.5) and match_point(d, g)]
            confusion[g["cls"]][max(cand, key=lambda d: d["score"])["cls"] if cand else "missed"] += 1

    # ---- AP (all-point interpolation over the pooled ranking)
    records.sort(key=lambda r: -r[0])
    tps = np.cumsum([r[1] == "tp" for r in records]) if records else np.array([])
    fps = np.cumsum([r[1] == "fp" for r in records]) if records else np.array([])
    ap, curve, best_f1, best_thr = 0.0, [], 0.0, None
    if npos and len(records):
        rec = tps / npos
        prec = tps / np.maximum(tps + fps, 1)
        mrec = np.concatenate([[0], rec, [rec[-1]]]); mpre = np.concatenate([[1], prec, [0]])
        for i in range(len(mpre) - 2, -1, -1):
            mpre[i] = max(mpre[i], mpre[i + 1])
        ap = float(np.sum((mrec[1:] - mrec[:-1]) * mpre[1:]))
        f1 = 2 * prec * rec / np.maximum(prec + rec, 1e-12)
        k = int(np.argmax(f1)); best_f1, best_thr = float(f1[k]), float(records[k][0])
        step = max(1, len(records) // 80)
        curve = [dict(recall=round(float(rec[i]), 4), precision=round(float(prec[i]), 4), score=round(float(records[i][0]), 4))
                 for i in range(0, len(records), step)]
    fn = npos - tp_op
    precision = tp_op / (tp_op + fp_op) if tp_op + fp_op else None
    recall = tp_op / npos if npos else None
    f1v = (2 * precision * recall / (precision + recall)) if precision and recall else (0.0 if npos else None)
    lat = [first_tp[i] - first_vis[i] for i in first_vis if i in first_tp]
    never = [i for i in first_vis if i not in first_tp]
    size_recall = [dict(bin=_bin_label(lo, hi, " px"), n=size_n[k], recall=(size_hit[k] / size_n[k]) if size_n[k] else None)
                   for k, (lo, hi) in enumerate(SIZE_BINS)]
    min_size = next((SIZE_BINS[k][0] for k in range(len(SIZE_BINS)) if size_n[k] >= 10 and size_hit[k] / size_n[k] >= 0.5), None)
    return dict(
        mode=mode, threshold=thr, frames=n_frames, positives=npos, tp=tp_op, fp=fp_op, fn=fn,
        precision=precision, recall=recall, f1=f1v, average_precision=ap if npos else None,
        false_negative_rate=(fn / npos) if npos else None,
        fp_per_frame=fp_op / n_frames if n_frames else None,
        false_alarm_frame_rate=fp_frames / n_frames if n_frames else None,
        fp_causes=dict(causes), best_f1=best_f1, best_f1_threshold=best_thr,
        detection_latency_s=dict(mean=float(np.mean(lat)) if lat else None, median=float(np.median(lat)) if lat else None,
                                 max=float(np.max(lat)) if lat else None, never_detected=never, n=len(lat)),
        min_apparent_size_px=min_size, recall_by_size=size_recall,
        recall_by_snr=[dict(bin=_bin_label(lo, hi), n=snr_n[k], recall=(snr_hit[k] / snr_n[k]) if snr_n[k] else None)
                       for k, (lo, hi) in enumerate(SNR_BINS)],
        continuity={i: dict(detected_fraction=v["det"] / v["vis"] if v["vis"] else None, longest_gap_frames=v["max_gap"],
                            visible_frames=v["vis"]) for i, v in per_id.items()},
        detection_continuity=(float(np.mean([v["det"] / v["vis"] for v in per_id.values() if v["vis"]])) if per_id else None),
        confusion={k: dict(v) for k, v in confusion.items()},
        pr_curve=curve,
    )
