"""Detection-to-truth and track-to-truth matching rules.

Small aerial targets are often only a few pixels wide, where plain IoU is
unstable (a one-pixel offset halves it). Two documented rules are used:

match_point  detection matching: centre distance <= max(6 px, 0.75 x larger GT side) OR IoU >= 0.3
similarity   tracking similarity: IoU after inflating both boxes to a minimum side of 16 px
"""
from __future__ import annotations

import numpy as np

MIN_SIDE = 16.0


def _box(o):
    if isinstance(o, dict):
        return o["bbox"] if "bbox" in o else (o["x1"], o["y1"], o["x2"], o["y2"])
    return (o.x1, o.y1, o.x2, o.y2)


def iou(a, b) -> float:
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0])); iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    if inter <= 0:
        return 0.0
    return inter / ((a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter)


def center_dist(a, b) -> float:
    return float(np.hypot((a[0] + a[2] - b[0] - b[2]) / 2, (a[1] + a[3] - b[1] - b[3]) / 2))


def match_point(det, gt) -> bool:
    d, g = _box(det), _box(gt)
    tol = max(6.0, 0.75 * max(g[2] - g[0], g[3] - g[1]))
    return center_dist(d, g) <= tol or iou(d, g) >= 0.3


def inflate(b, min_side: float = MIN_SIDE):
    cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
    w, h = max(b[2] - b[0], min_side), max(b[3] - b[1], min_side)
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def similarity(a, b) -> float:
    return iou(inflate(_box(a)), inflate(_box(b)))


def similarity_matrix(gts: list, trs: list) -> np.ndarray:
    m = np.zeros((len(gts), len(trs)))
    for i, g in enumerate(gts):
        gb = inflate(_box(g))
        for j, t in enumerate(trs):
            m[i, j] = iou(gb, inflate(_box(t)))
    return m
