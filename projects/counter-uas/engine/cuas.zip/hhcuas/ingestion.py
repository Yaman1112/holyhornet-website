"""Frame sources: recorded video, image folders and live cameras.

All sources yield objects compatible with the pipeline core (`run_stream`):
idx, t, t_stamp, image, gt, dropped. Each source declares its data origin so
results are never confused with simulation.

CameraSource wraps cv2.VideoCapture (USB index, RTSP/HTTP URL). It is provided as
the live-sensor adapter; it has NOT been exercised against hardware in this release.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np

from . import ORIGIN_IMPORTED, ORIGIN_LIVE

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
VIDEO_EXT = {".mp4", ".avi", ".mov", ".mkv"}


@dataclass
class SourceFrame:
    idx: int
    t: float
    t_stamp: float
    image: np.ndarray | None
    gt: list = field(default_factory=list)
    dropped: bool = False
    origin: str = ORIGIN_IMPORTED


class VideoFileSource:
    origin = ORIGIN_IMPORTED

    def __init__(self, path: str | Path, annotations: dict[int, list] | None = None, max_frames: int | None = None):
        self.path = str(path)
        cap = cv2.VideoCapture(self.path)
        if not cap.isOpened():
            raise ValueError(f"cannot open video {path}")
        self.fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        self.n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); self.height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cap.release()
        if max_frames:
            self.n = min(self.n, max_frames)
        self.ann = annotations or {}

    def __iter__(self):
        cap = cv2.VideoCapture(self.path)
        try:
            for i in range(self.n):
                ok, img = cap.read()
                if not ok:
                    break
                t = (i + 1) / self.fps
                yield SourceFrame(i, t, t, img, self.ann.get(i, []))
        finally:
            cap.release()

    def frame(self, i: int) -> np.ndarray | None:
        cap = cv2.VideoCapture(self.path)
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ok, img = cap.read()
        cap.release()
        return img if ok else None


class ImageFolderSource:
    origin = ORIGIN_IMPORTED

    def __init__(self, files: list[Path], annotations: dict[int, list] | None = None, fps: float = 30.0):
        self.files, self.ann, self.fps, self.n = files, annotations or {}, fps, len(files)

    def __iter__(self):
        for i, f in enumerate(self.files):
            img = cv2.imread(str(f), cv2.IMREAD_UNCHANGED)
            if img is not None and img.ndim == 3 and img.shape[2] == 4:
                img = img[:, :, :3]
            if img is not None and img.dtype != np.uint8:
                img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            t = (i + 1) / self.fps
            yield SourceFrame(i, t, t, img, self.ann.get(i, []), dropped=img is None)


class CameraSource:
    """Live camera / network stream. origin = live_sensor."""
    origin = ORIGIN_LIVE

    def __init__(self, device: int | str = 0, max_frames: int = 300):
        self.device, self.n = device, max_frames
        self.fps = 30.0

    def __iter__(self):
        import time
        cap = cv2.VideoCapture(self.device)
        if not cap.isOpened():
            raise RuntimeError(f"camera {self.device!r} is not available")
        self.fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        t0 = time.time()
        try:
            for i in range(self.n):
                ok, img = cap.read()
                t = time.time() - t0
                yield SourceFrame(i, t, t, img if ok else None, [], dropped=not ok, origin=ORIGIN_LIVE)
        finally:
            cap.release()
