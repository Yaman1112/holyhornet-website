"""Experiment pipeline: sensor frames -> (enhancement) -> detector -> tracker -> metrics.

Several detector/tracker combinations can share one rendered frame stream, so
comparisons always see byte-identical input.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np

try:
    import psutil
except ImportError:                              # browser edition: no process metrics
    psutil = None

from . import ORIGIN_SIMULATED, __version__
from .detection.enhance import Enhancer
from .detection.registry import build_detector, default_threshold
from .evaluation.detection_metrics import evaluate_detection
from .evaluation.tracking_metrics import evaluate_tracking
from .simulation.config import ScenarioConfig
from .simulation.world import Simulator
from .tracking.tracker import Tracker


@dataclass
class PipelineSpec:
    detector: str = "classical-contrast"
    tracker: str = "kalman-gated"
    enhance: str = "none"
    threshold: float | None = None

    @property
    def label(self) -> str:
        e = "" if self.enhance == "none" else f"+{self.enhance}"
        return f"{self.detector}{e} / {self.tracker}"


def _stats(v: list[float]) -> dict:
    if not v:
        return dict(mean=None, p50=None, p95=None, max=None)
    a = np.asarray(v)
    return dict(mean=float(a.mean()), p50=float(np.percentile(a, 50)), p95=float(np.percentile(a, 95)), max=float(a.max()))


def conditions(cfg: ScenarioConfig, cam_id: str) -> dict:
    env, cam = cfg.environment, cfg.camera(cam_id)
    d = cam.degradation
    return dict(background=env.background, lighting=env.lighting, illuminance_lux=env.lux, visibility_m=env.visibility_m,
                cloud_cover=env.cloud_cover, ambient_temp_c=env.ambient_temp_c, wind_mps=env.wind_mps,
                sensor_kind=cam.kind, resolution=[cam.width, cam.height], hfov_deg=cam.hfov_deg, fps=cam.fps,
                noise_mult=d.noise_mult, frame_drop_prob=d.frame_drop_prob, dropouts=d.dropouts,
                timestamp_jitter_s=d.timestamp_jitter_s, latency_s=d.latency_s, thermal_contrast_scale=d.thermal_contrast_scale)


def run_stream(frame_iter, n: int, fps: float, specs: list[PipelineSpec], progress=None):
    """Core loop shared by simulated, imported and live sources. `frame_iter` yields
    objects with idx, t, t_stamp, image, gt, dropped (see simulation.world.Frame)."""
    proc = psutil.Process() if psutil else None
    if proc:
        proc.cpu_percent(None)
    st = [dict(det=build_detector(s.detector), trk=Tracker(s.tracker), enh=Enhancer(s.enhance), frames=[],
               t_det=[], t_trk=[], t_enh=[], thr=s.threshold if s.threshold is not None else default_threshold(s.detector))
          for s in specs]
    t_render, rss, info = [], [], dict(exposure=0.0, gain=1.0)
    t_wall = time.perf_counter()
    it = iter(frame_iter)
    i = 0
    while True:
        t0 = time.perf_counter()
        fr = next(it, None)
        if fr is None:
            break
        t_render.append((time.perf_counter() - t0) * 1e3)
        info["exposure"], info["gain"] = getattr(fr, "exposure_s", 0.0), getattr(fr, "gain", 1.0)
        for s in st:
            rec = dict(idx=fr.idx, t=round(fr.t, 5), t_stamp=round(fr.t_stamp, 5), dropped=fr.dropped, gt=fr.gt)
            if fr.dropped or fr.image is None:
                rec["dets"] = []
                a = time.perf_counter()
                rec["tracks"] = s["trk"].step([], fr.t_stamp, fr.idx)
                s["t_trk"].append((time.perf_counter() - a) * 1e3)
            else:
                a = time.perf_counter()
                img = s["enh"](fr.image)
                b = time.perf_counter()
                dets = s["det"].detect(img, fr.t_stamp)
                c = time.perf_counter()
                rec["tracks"] = s["trk"].step(dets, fr.t_stamp, fr.idx)
                d = time.perf_counter()
                rec["dets"] = [x.to_dict() for x in dets]
                s["t_enh"].append((b - a) * 1e3); s["t_det"].append((c - b) * 1e3 + getattr(s["det"], "shared_ms", 0.0)); s["t_trk"].append((d - c) * 1e3)
            s["frames"].append(rec)
        if i % 30 == 0:
            if proc:
                rss.append(proc.memory_info().rss / 1e6)
            if progress and n:
                progress(min(1.0, i / n))
        i += 1
    wall = time.perf_counter() - t_wall
    cpu = proc.cpu_percent(None) if proc else None
    out = []
    for spec, s in zip(specs, st):
        frames = s["frames"]
        e2e = [a + b + c for a, b, c in zip(s["t_enh"], s["t_det"], s["t_trk"])]
        timing = dict(
            enhance_ms=_stats(s["t_enh"]), detect_ms=_stats(s["t_det"]), track_ms=_stats(s["t_trk"]), end_to_end_ms=_stats(e2e),
            processing_fps=(1000.0 / np.mean(e2e)) if e2e else None, sensor_fps=fps,
            realtime_factor=(1000.0 / np.mean(e2e) / fps) if e2e and fps else None,
            note="Compute time of enhancement + detection + tracking per frame, measured on this machine. "
                 "Frame acquisition (simulation rendering or file decoding) is excluded.")
        out.append(dict(
            detector=spec.detector, tracker=spec.tracker, enhance=spec.enhance, threshold=s["thr"],
            exposure_s=info["exposure"], gain=info["gain"], software=dict(hhcuas=__version__),
            metrics=dict(
                detection=dict(uav=evaluate_detection(frames, "uav", s["thr"]), object=evaluate_detection(frames, "object", min(s["thr"], 0.5))),
                tracking=evaluate_tracking(frames), timing=timing,
                system=dict(cpu_percent_process=cpu, rss_mb_peak=max(rss) if rss else None, cpu_count=psutil.cpu_count() if psutil else None,
                            gpu="not used (CPU inference via ONNX Runtime); GPU utilisation not measured",
                            network="not applicable (offline run); live-stream bandwidth is reported by the live feed",
                            throughput_frames_per_s_incl_acquisition=i / wall if wall else None,
                            acquisition_ms_mean=float(np.mean(t_render)) if t_render else None, shared_run=len(specs),
                            note="CPU % and memory are for the whole process, shared by all pipelines evaluated in the same run.")),
            tracks=s["trk"].summaries(), events=s["trk"].events, frames=frames))
    if progress:
        progress(1.0)
    return out


def run_camera(cfg: ScenarioConfig, cam_id: str, specs: list[PipelineSpec], progress=None, sim: Simulator | None = None,
               keep_frames: bool = True) -> list[dict]:
    """Run every spec on one simulated camera's frame stream. Returns one result dict per spec."""
    sim = sim or Simulator(cfg)
    cam = cfg.camera(cam_id)
    out = run_stream(sim.frames(cam_id), sim.n_frames(cam_id), cam.fps, specs, progress)
    for spec, res in zip(specs, out):
        res.update(origin=ORIGIN_SIMULATED, kind="pipeline", name=f"{cfg.name} | {cam_id} | {spec.label}",
                   scenario=cfg.scenario, scenario_name=cfg.name, seed=cfg.seed, config=cfg.model_dump(mode="json"),
                   config_hash=cfg.config_hash(), sensor=cam_id, sensor_kind=cam.kind, conditions=conditions(cfg, cam_id))
        res["metrics"]["timing"]["configured_sensor_latency_s"] = cam.degradation.latency_s
        if not keep_frames:
            res.pop("frames")
    return out
