"""Filesystem locations. Override the data root with CUAS_DATA_DIR."""
from __future__ import annotations

import os
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
DATA = Path(os.environ.get("CUAS_DATA_DIR", REPO / "data"))
MODELS = Path(os.environ.get("CUAS_MODELS_DIR", DATA / "models"))
EXPERIMENTS = DATA / "experiments"
DATASETS = DATA / "datasets"
ANNOTATIONS = DATA / "annotations"
REPORTS = DATA / "reports"
SECRETS = DATA / "secrets"
DB = DATA / "cuas.sqlite3"

for _p in (DATA, MODELS, EXPERIMENTS, DATASETS, ANNOTATIONS, REPORTS):
    _p.mkdir(parents=True, exist_ok=True)
