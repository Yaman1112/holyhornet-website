"""HolyHornet Counter-UAS Intelligence — research and evaluation platform.

Detection, identification, tracking and technology evaluation only.
No engagement, guidance or neutralisation functionality exists in this package.
"""

__version__ = "0.1.0"

# Classes of simulated/annotated objects.
OBJECT_CLASSES = ("multirotor", "fixed_wing", "bird", "aircraft", "insect")
# Classes of interest for the "UAV" evaluation mode.
UAV_CLASSES = ("multirotor", "fixed_wing")
# Output classes of the patch classifier.
CNN_CLASSES = ("multirotor", "fixed_wing", "bird", "aircraft", "clutter")
# Labels a detector may emit.
DETECTION_LABELS = (
    "multirotor", "fixed_wing", "bird", "aircraft",
    "small_aerial_object", "large_aerial_object", "unknown",
)

# Data-origin labels. Every frame, measurement, experiment and report carries one.
ORIGIN_SIMULATED = "simulated"
ORIGIN_IMPORTED = "imported_dataset"
ORIGIN_LIVE = "live_sensor"
