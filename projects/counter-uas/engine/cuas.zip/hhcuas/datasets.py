"""Dataset management: import, provenance, versioning, quality checks, leakage-safe splits,
annotation editing and evaluation of detectors on imported data.

Supported layouts
  image folder   *.jpg|png with YOLO labels (<stem>.txt: `class cx cy w h`, normalised) beside the
                 images or in a sibling `labels/` directory; optional classes.txt
  video file     one .mp4/.avi with optional `<stem>.json` annotations:
                 {"classes": [...], "frames": {"12": [{"id": "a", "cls": "multirotor", "bbox": [x1,y1,x2,y2]}]}}

A dataset version is the SHA-256 over its item hashes and labels, so any change to
images or annotations produces a new version id.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import cv2
import numpy as np

from . import OBJECT_CLASSES, ORIGIN_IMPORTED, __version__, paths
from .ingestion import IMAGE_EXT, VIDEO_EXT, ImageFolderSource, VideoFileSource
from .pipeline import PipelineSpec, run_stream

MAX_ZIP_BYTES = 2 * 1024 ** 3
MAX_ZIP_FILES = 50000


def _dir(org: str, ds_id: str) -> Path:
    if not ds_id.replace("-", "").replace("_", "").isalnum():
        raise ValueError("invalid dataset id")
    return paths.DATASETS / org / ds_id


def _sha(p: Path) -> str:
    h = hashlib.sha1()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_extract(zip_path: Path, dest: Path):
    """Zip extraction with path-traversal, size and count limits."""
    dest = dest.resolve()
    with zipfile.ZipFile(zip_path) as z:
        infos = z.infolist()
        if len(infos) > MAX_ZIP_FILES or sum(i.file_size for i in infos) > MAX_ZIP_BYTES:
            raise ValueError("archive too large")
        for i in infos:
            target = (dest / i.filename).resolve()
            if dest not in target.parents and target != dest:
                raise ValueError(f"unsafe path in archive: {i.filename}")
            if i.is_dir():
                continue
            if Path(i.filename).suffix.lower() not in IMAGE_EXT | VIDEO_EXT | {".txt", ".json"}:
                continue                              # ignore anything that is not data
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(i) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)


def _read_yolo(txt: Path, w: int, h: int, classes: list[str]) -> list[dict]:
    out = []
    for k, ln in enumerate(txt.read_text().splitlines()):
        p = ln.split()
        if len(p) < 5:
            continue
        c = int(float(p[0])); cx, cy, bw, bh = (float(v) for v in p[1:5])
        out.append(dict(id=f"{txt.stem}-{k}", cls=classes[c] if c < len(classes) else f"class_{c}",
                        bbox=[(cx - bw / 2) * w, (cy - bh / 2) * h, (cx + bw / 2) * w, (cy + bh / 2) * h]))
    return out


def import_dataset(org: str, src: str | Path, name: str, meta: dict, user: str = "system") -> dict:
    """Copy data from `src` (folder or video file) into the dataset store and build its manifest."""
    src = Path(src)
    if not src.exists():
        raise FileNotFoundError(str(src))
    ds_id = datetime.now(timezone.utc).strftime("ds%Y%m%d%H%M%S") + hashlib.sha1(name.encode()).hexdigest()[:4]
    d = _dir(org, ds_id)
    (d / "files").mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        shutil.copytree(src, d / "files", dirs_exist_ok=True)
    else:
        shutil.copy2(src, d / "files" / src.name)
        if src.with_suffix(".json").exists():
            shutil.copy2(src.with_suffix(".json"), d / "files" / src.with_suffix(".json").name)
    return _build_manifest(org, ds_id, name, meta, user)


def import_zip(org: str, zip_path: Path, name: str, meta: dict, user: str = "system") -> dict:
    ds_id = datetime.now(timezone.utc).strftime("ds%Y%m%d%H%M%S") + hashlib.sha1(name.encode()).hexdigest()[:4]
    d = _dir(org, ds_id)
    (d / "files").mkdir(parents=True, exist_ok=True)
    try:
        safe_extract(zip_path, d / "files")
        return _build_manifest(org, ds_id, name, meta, user)
    except Exception:
        shutil.rmtree(d, ignore_errors=True)
        raise


def _build_manifest(org: str, ds_id: str, name: str, meta: dict, user: str) -> dict:
    d = _dir(org, ds_id)
    root = d / "files"
    files = sorted(p for p in root.rglob("*") if p.is_file())
    videos = [p for p in files if p.suffix.lower() in VIDEO_EXT]
    images = [p for p in files if p.suffix.lower() in IMAGE_EXT]
    classes = list(meta.get("classes") or [])
    cf = next((p for p in files if p.name == "classes.txt"), None)
    if cf and not classes:
        classes = [c.strip() for c in cf.read_text().splitlines() if c.strip()]
    items, labels = [], {}
    kind = "video" if videos and not images else "images"
    if kind == "video":
        v = videos[0]
        src = VideoFileSource(v)
        ann_file = v.with_suffix(".json")
        ann = json.loads(ann_file.read_text()) if ann_file.exists() else {}
        classes = classes or ann.get("classes") or list(OBJECT_CLASSES)
        for i in range(src.n):
            labels[str(i)] = ann.get("frames", {}).get(str(i), [])
            items.append(dict(i=i, file=v.relative_to(root).as_posix(), frame=i, w=src.width, h=src.height, group=v.stem, sha1=None))
        fps, fmt = src.fps, "hhcuas-json" if ann else "none"
        content = _sha(v)
    else:
        classes = classes or list(OBJECT_CLASSES)
        fmt = "none"
        for i, p in enumerate(images):
            img = cv2.imread(str(p), cv2.IMREAD_UNCHANGED)
            h, w = (img.shape[:2] if img is not None else (0, 0))
            txt = p.with_suffix(".txt")
            if not txt.exists():
                alt = p.parent.parent / "labels" / (p.stem + ".txt")
                txt = alt if alt.exists() else txt
            labels[str(i)] = _read_yolo(txt, w, h, classes) if txt.exists() and w else None
            if txt.exists():
                fmt = "yolo-txt"
            rel = p.relative_to(root)
            group = rel.parts[0] if len(rel.parts) > 1 else p.stem.rsplit("_", 1)[0]
            items.append(dict(i=i, file=rel.as_posix(), frame=None, w=w, h=h, group=group, sha1=_sha(p), readable=img is not None))
        fps = float(meta.get("fps") or 30.0)
        content = hashlib.sha1("".join(it["sha1"] for it in items).encode()).hexdigest()
    (d / "labels.json").write_text(json.dumps(labels))
    man = dict(
        id=ds_id, org=org, name=name, kind=kind, origin=ORIGIN_IMPORTED, created=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        imported_by=user, source=meta.get("source", ""), license=meta.get("license", ""), usage_permissions=meta.get("usage_permissions", ""),
        collection_conditions=meta.get("collection_conditions", ""), sensor_type=meta.get("sensor_type", "unknown"),
        simulated_source=bool(meta.get("simulated_source", False)), annotation_format=fmt, classes=classes, fps=fps,
        n_items=len(items), items=items, content_sha=content, splits=None, quality=None, software=dict(hhcuas=__version__))
    man["version"] = _version(man, labels)
    (d / "manifest.json").write_text(json.dumps(man))
    return man


def _version(man: dict, labels: dict) -> str:
    return hashlib.sha256((man["content_sha"] + json.dumps(labels, sort_keys=True)).encode()).hexdigest()[:12]


def load(org: str, ds_id: str) -> dict | None:
    p = _dir(org, ds_id) / "manifest.json"
    return json.loads(p.read_text()) if p.exists() else None


def load_labels(org: str, ds_id: str) -> dict:
    return json.loads((_dir(org, ds_id) / "labels.json").read_text())


def save_manifest(man: dict):
    (_dir(man["org"], man["id"]) / "manifest.json").write_text(json.dumps(man))


def list_datasets(org: str) -> list[dict]:
    out = []
    base = paths.DATASETS / org
    if base.exists():
        for p in sorted(base.glob("*/manifest.json"), reverse=True):
            m = json.loads(p.read_text())
            m.pop("items", None)
            out.append(m)
    return out


def delete(org: str, ds_id: str) -> bool:
    d = _dir(org, ds_id)
    if not d.exists():
        return False
    shutil.rmtree(d)
    return True


def set_labels(org: str, ds_id: str, item: int, objs: list[dict], user: str) -> dict:
    man = load(org, ds_id)
    labels = load_labels(org, ds_id)
    clean = []
    for k, o in enumerate(objs):
        x1, y1, x2, y2 = (float(v) for v in o["bbox"])
        clean.append(dict(id=str(o.get("id") or f"m{item}-{k}"), cls=str(o["cls"]), bbox=[min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)]))
    labels[str(item)] = clean
    (_dir(org, ds_id) / "labels.json").write_text(json.dumps(labels))
    man["version"] = _version(man, labels)
    man["annotation_format"] = man["annotation_format"] if man["annotation_format"] != "none" else "hhcuas-json"
    man["last_annotated_by"] = user
    man["quality"] = None
    save_manifest(man)
    return man


def item_image(org: str, ds_id: str, item: int) -> np.ndarray | None:
    man = load(org, ds_id)
    if not man or not 0 <= item < man["n_items"]:
        return None
    it = man["items"][item]
    p = _dir(org, ds_id) / "files" / it["file"]
    if man["kind"] == "video":
        return VideoFileSource(p).frame(it["frame"])
    return cv2.imread(str(p), cv2.IMREAD_COLOR)


# ------------------------------------------------------------------ quality
def quality_check(org: str, ds_id: str) -> dict:
    man = load(org, ds_id)
    labels = load_labels(org, ds_id)
    issues = defaultdict(list)
    cls_n, sizes = Counter(), []
    seen: dict[str, int] = {}
    n_boxes = 0
    for it in man["items"]:
        i = it["i"]
        if it.get("readable") is False:
            issues["unreadable_file"].append(i)
        if it.get("sha1"):
            if it["sha1"] in seen:
                issues["duplicate_image"].append(i)
            seen.setdefault(it["sha1"], i)
        lab = labels.get(str(i))
        if lab is None:
            issues["missing_label_file"].append(i)
            continue
        if not lab:
            issues["no_objects"].append(i)
        for o in lab:
            n_boxes += 1
            x1, y1, x2, y2 = o["bbox"]
            cls_n[o["cls"]] += 1
            sizes.append(max(x2 - x1, y2 - y1))
            if x1 < -1 or y1 < -1 or x2 > it["w"] + 1 or y2 > it["h"] + 1:
                issues["box_out_of_bounds"].append(i)
            if x2 - x1 < 2 or y2 - y1 < 2:
                issues["box_under_2px"].append(i)
            if o["cls"] not in man["classes"]:
                issues["unknown_class"].append(i)
    q = dict(
        checked=datetime.now(timezone.utc).isoformat(timespec="seconds"), items=man["n_items"], boxes=n_boxes,
        class_counts=dict(cls_n), issues={k: dict(count=len(set(v)), examples=sorted(set(v))[:10]) for k, v in issues.items()},
        box_size_px=dict(min=float(np.min(sizes)), median=float(np.median(sizes)), max=float(np.max(sizes))) if sizes else None,
        annotated_fraction=sum(1 for it in man["items"] if labels.get(str(it["i"])) is not None) / max(man["n_items"], 1),
        provenance_complete=all(man.get(k) for k in ("source", "license", "usage_permissions")),
        notes=["'no_objects' may be valid negatives; review rather than delete.",
               "Video datasets have one group (the video), so they cannot be split without leakage."] )
    man["quality"] = q
    save_manifest(man)
    return q


# ------------------------------------------------------------------ splits
def make_splits(org: str, ds_id: str, fractions=(0.7, 0.15, 0.15), seed: int = 0) -> dict:
    """Group-wise split: all items of a group (sequence / sub-folder) go to the same split,
    and exact-duplicate images are forced into the same split, so nothing leaks."""
    man = load(org, ds_id)
    groups = defaultdict(list)
    for it in man["items"]:
        groups[it["group"]].append(it["i"])
    # merge groups that share duplicate images
    owner: dict[str, str] = {}
    parent = {g: g for g in groups}

    def find(g):
        while parent[g] != g:
            g = parent[g]
        return g
    for it in man["items"]:
        if it.get("sha1"):
            if it["sha1"] in owner:
                parent[find(it["group"])] = find(owner[it["sha1"]])
            else:
                owner[it["sha1"]] = it["group"]
    merged = defaultdict(list)
    for g, idx in groups.items():
        merged[find(g)] += idx
    keys = sorted(merged)
    rng = np.random.default_rng(seed)
    rng.shuffle(keys)
    total = man["n_items"]
    names = ("train", "val", "test")
    out = {n: [] for n in names}
    target = [f * total for f in fractions]
    for g in keys:
        k = int(np.argmax([target[j] - len(out[names[j]]) for j in range(3)]))
        out[names[k]] += merged[g]
    sha_split = defaultdict(set)
    grp_split = defaultdict(set)
    for n in names:
        for i in out[n]:
            it = man["items"][i]
            grp_split[it["group"]].add(n)
            if it.get("sha1"):
                sha_split[it["sha1"]].add(n)
    leak = dict(groups_in_multiple_splits=sum(len(v) > 1 for v in grp_split.values()),
                duplicate_images_across_splits=sum(len(v) > 1 for v in sha_split.values()))
    man["splits"] = dict(seed=seed, fractions=list(fractions), method="group-wise, duplicate-aware", n_groups=len(keys),
                         sizes={n: len(out[n]) for n in names}, indices={n: sorted(out[n]) for n in names}, leakage=leak,
                         warning="Only one group: a leakage-free split is impossible; all items are in one split." if len(keys) < 2 else None)
    save_manifest(man)
    return man["splits"]


# ------------------------------------------------------------------ evaluation
def evaluate(org: str, ds_id: str, specs: list[PipelineSpec], split: str | None = None, max_items: int | None = None, progress=None) -> list[dict]:
    man = load(org, ds_id)
    labels = load_labels(org, ds_id)
    root = _dir(org, ds_id) / "files"
    idx = list(range(man["n_items"]))
    if split and man.get("splits"):
        idx = man["splits"]["indices"][split]
    if max_items:
        idx = idx[:max_items]

    def gt_for(i):
        out = []
        for o in labels.get(str(i)) or []:
            b = o["bbox"]
            out.append(dict(id=o["id"], cls=o["cls"], bbox=b, cx=(b[0] + b[2]) / 2, cy=(b[1] + b[3]) / 2,
                            size_px=max(b[2] - b[0], b[3] - b[1]), range_m=None, vis=1.0, snr=0.0, blur_px=0.0, is_clutter=False))
        return out
    if man["kind"] == "video":
        src = VideoFileSource(root / man["items"][0]["file"], {i: gt_for(i) for i in idx}, max_frames=max(idx) + 1 if idx else 0)
    else:
        src = ImageFolderSource([root / man["items"][i]["file"] for i in idx], {k: gt_for(i) for k, i in enumerate(idx)}, man["fps"])
    annotated = sum(1 for i in idx if labels.get(str(i)) is not None)
    res = run_stream(src, len(idx), src.fps, specs, progress)
    for spec, r in zip(specs, res):
        r.update(origin=ORIGIN_IMPORTED, kind="pipeline", name=f"{man['name']} | {spec.label}", scenario="dataset",
                 scenario_name=man["name"], seed=None, config=None, config_hash=man["version"], sensor=man["sensor_type"],
                 sensor_kind=man["sensor_type"], dataset=dict(id=ds_id, name=man["name"], version=man["version"], split=split,
                                                              simulated_source=man["simulated_source"], items=len(idx), annotated_items=annotated,
                                                              license=man["license"], source=man["source"]),
                 conditions=dict(sensor_kind=man["sensor_type"], collection_conditions=man["collection_conditions"], fps=man["fps"],
                                 background="recorded", lighting="recorded"))
        if annotated == 0:
            r["metrics"]["note"] = "Dataset has no annotations: accuracy metrics are undefined; only detections, tracks and timing are meaningful."
    return res


# ------------------------------------------------------------------ export of simulated runs
def export_simulation(cfg, cam_id: str, out_dir: Path) -> Path:
    """Write a simulated camera run as MP4 + annotation JSON (for exercising the import path).
    The video is lossy-compressed, like real recordings."""
    from .simulation.world import Simulator
    sim = Simulator(cfg)
    cam = cfg.camera(cam_id)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"sim_{cfg.scenario}_{cam_id}_seed{cfg.seed}"
    vw = cv2.VideoWriter(str(out_dir / f"{stem}.mp4"), cv2.VideoWriter_fourcc(*"mp4v"), cam.fps, (cam.width, cam.height))
    frames = {}
    for fr in sim.frames(cam_id):
        img = fr.image if fr.image.ndim == 3 else cv2.cvtColor(fr.image, cv2.COLOR_GRAY2BGR)
        vw.write(img)
        frames[str(fr.idx)] = [dict(id=g["id"], cls=g["cls"], bbox=g["bbox"]) for g in fr.gt if g["vis"] >= 0.3 and g["cls"] != "insect"]
    vw.release()
    (out_dir / f"{stem}.json").write_text(json.dumps(dict(classes=list(OBJECT_CLASSES), frames=frames,
                                                         note="SIMULATED source exported by hhcuas", config=cfg.model_dump(mode="json"))))
    return out_dir / f"{stem}.mp4"


# Public datasets worth evaluating next. Nothing is downloaded by this software; licences must be
# checked at the source before any use, and the entries below are pointers, not endorsements.
CANDIDATE_DATASETS = [
    dict(name="Anti-UAV (RGB + thermal IR video)", modality="visible + thermal", use="single-object tracking, day/night", licence="check source — research use terms"),
    dict(name="Drone-vs-Bird Detection Challenge", modality="visible video", use="UAV vs bird discrimination at long range", licence="check source — challenge agreement required"),
    dict(name="Det-Fly", modality="visible images (air-to-air)", use="small-UAV detection across backgrounds", licence="check source"),
    dict(name="MAV-VID", modality="visible video", use="UAV detection", licence="check source"),
    dict(name="DUT Anti-UAV", modality="visible images + video", use="detection and tracking", licence="check source"),
]
