"""Experiment store: SQLite index + gzip JSON payloads.

Each experiment belongs to one organisation; every read is filtered by org.
Payloads carry their data origin (simulated / imported_dataset / live_sensor).
"""
from __future__ import annotations

import gzip
import json
import sqlite3
import threading
import uuid
from datetime import datetime, timezone

import numpy as np

from . import paths

_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS experiments (
  id TEXT PRIMARY KEY, org TEXT NOT NULL, created TEXT NOT NULL, created_by TEXT, kind TEXT, origin TEXT,
  name TEXT, scenario TEXT, seed INTEGER, sensor TEXT, sensor_kind TEXT, detector TEXT, tracker TEXT, enhance TEXT,
  config_hash TEXT, tags TEXT, summary TEXT);
CREATE INDEX IF NOT EXISTS ix_exp_org ON experiments(org, created);
"""


def connect() -> sqlite3.Connection:
    con = sqlite3.connect(paths.DB, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    return con


def init():
    with _lock, connect() as con:
        con.executescript(SCHEMA)


class _Enc(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, np.bool_):
            return bool(o)
        return super().default(o)


def dumps(o) -> str:
    return json.dumps(_clean(o), cls=_Enc)


def _clean(o):
    """Replace NaN/inf with None so the payload is strict JSON."""
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (float, np.floating)):
        v = float(o)
        return v if np.isfinite(v) else None
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.ndarray):
        return _clean(o.tolist())
    return o


def summarize(res: dict) -> dict:
    """Small metric digest stored in the index and used by comparison tables and the assistant."""
    m = res.get("metrics", {})
    s: dict = dict(conditions=res.get("conditions", {}))
    if "detection" in m:
        d, o = m["detection"]["uav"], m["detection"]["object"]
        s.update(precision=d["precision"], recall=d["recall"], f1=d["f1"], ap=d["average_precision"], fnr=d["false_negative_rate"],
                 fp_per_frame=d["fp_per_frame"], false_alarm_frame_rate=d["false_alarm_frame_rate"], fp_causes=d["fp_causes"],
                 detection_latency_s=d["detection_latency_s"]["mean"], never_detected=d["detection_latency_s"]["never_detected"],
                 min_size_px=d["min_apparent_size_px"], detection_continuity=d["detection_continuity"],
                 object_recall=o["recall"], object_precision=o["precision"], frames=d["frames"], positives=d["positives"],
                 tp=d["tp"], fp=d["fp"], fn=d["fn"])
    if "tracking" in m:
        t = m["tracking"]
        s.update(hota=t["hota"], deta=t["deta"], assa=t["assa"], mota=t["clear"]["mota"], motp=t["clear"]["motp"], idf1=t["idf1"],
                 id_switches=t["clear"]["id_switches"], fragmentations=t["clear"]["fragmentations"],
                 track_init_s=t["track_initiation_s"]["mean_uav"], track_continuity=t["continuity"]["mean_uav"],
                 never_tracked=t["track_initiation_s"]["never_tracked"],
                 occlusions=t["occlusion"]["n"], occlusion_same_id=t["occlusion"]["same_id"], occlusion_reacquired=t["occlusion"]["reacquired"],
                 reacquire_s=t["occlusion"]["mean_reacquire_s"], conf_stability=t["confidence_stability_std"],
                 center_rmse_px=t["clear"]["rmse_center_px"], n_tracks=t["n_tracks"], false_tracks=t["false_tracks"],
                 false_uav_tracks=t["false_uav_tracks"])
    if "timing" in m:
        tm = m["timing"]
        s.update(detect_ms=tm["detect_ms"]["mean"], track_ms=tm["track_ms"]["mean"], e2e_ms=tm["end_to_end_ms"]["mean"],
                 e2e_p95_ms=tm["end_to_end_ms"]["p95"], processing_fps=tm["processing_fps"])
    if "system" in m:
        s.update(cpu_percent=m["system"]["cpu_percent_process"], rss_mb=m["system"]["rss_mb_peak"])
    if "fusion" in m:
        f = m["fusion"]
        s.update(fusion_coverage=f["uav_coverage"], fusion_rmse_m=f["uav_position_rmse_m"], fusion_init_s=f["uav_initiation_s"],
                 fusion_false_tracks=f["false_tracks"], fusion_id_switches=f["id_switches"], fusion_never_tracked=f["uav_never_tracked"],
                 per_sensor=m.get("per_sensor"))
    if "series" in res:
        s["series_points"] = len(res["series"]); s["study"] = res.get("study")
    return s


def save(res: dict, org: str, user: str = "system", tags: list[str] | None = None) -> str:
    init()
    eid = res.get("id") or datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
    res["id"] = eid
    res["created"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    res["org"] = org
    res["tags"] = tags or res.get("tags") or []
    res["summary"] = _clean(summarize(res))
    d = paths.EXPERIMENTS / org
    d.mkdir(parents=True, exist_ok=True)
    with gzip.open(d / f"{eid}.json.gz", "wt", encoding="utf-8") as f:
        f.write(dumps(res))
    with _lock, connect() as con:
        con.execute("INSERT OR REPLACE INTO experiments VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (eid, org, res["created"], user, res.get("kind"), res.get("origin"), res.get("name"), res.get("scenario"),
                     res.get("seed"), res.get("sensor"), res.get("sensor_kind"), res.get("detector"), res.get("tracker"),
                     res.get("enhance"), res.get("config_hash"), json.dumps(res["tags"]), json.dumps(res["summary"])))
    return eid


def _row(r) -> dict:
    d = dict(r)
    d["tags"] = json.loads(d["tags"] or "[]")
    d["summary"] = json.loads(d["summary"] or "{}")
    return d


def list_experiments(org: str, kind: str | None = None, tag: str | None = None, limit: int = 2000) -> list[dict]:
    init()
    with connect() as con:
        q, a = "SELECT * FROM experiments WHERE org=?", [org]
        if kind:
            q += " AND kind=?"; a.append(kind)
        rows = [_row(r) for r in con.execute(q + " ORDER BY created DESC, id DESC LIMIT ?", a + [limit])]
    return [r for r in rows if not tag or tag in r["tags"]]


def load(eid: str, org: str) -> dict | None:
    if "/" in eid or "\\" in eid or ".." in eid:
        return None
    p = paths.EXPERIMENTS / org / f"{eid}.json.gz"
    if not p.exists():
        return None
    with gzip.open(p, "rt", encoding="utf-8") as f:
        return json.load(f)


def delete(eid: str, org: str) -> bool:
    if "/" in eid or "\\" in eid or ".." in eid:
        return False
    p = paths.EXPERIMENTS / org / f"{eid}.json.gz"
    if not p.exists():
        return False
    p.unlink()
    with _lock, connect() as con:
        con.execute("DELETE FROM experiments WHERE id=? AND org=?", (eid, org))
    return True


def delete_tag(org: str, tag: str) -> int:
    n = 0
    for r in list_experiments(org, tag=tag):
        n += delete(r["id"], org)
    return n


def reindex(org: str) -> int:
    """Rebuild the index rows of one organisation from the payload files on disk
    (used when a data directory is restored or shipped without its database)."""
    init()
    d = paths.EXPERIMENTS / org
    n = 0
    if not d.exists():
        return 0
    with _lock, connect() as con:
        con.execute("DELETE FROM experiments WHERE org=?", (org,))
        for p in sorted(d.glob("*.json.gz")):
            with gzip.open(p, "rt", encoding="utf-8") as f:
                res = json.load(f)
            con.execute("INSERT OR REPLACE INTO experiments VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (res["id"], org, res["created"], "seed", res.get("kind"), res.get("origin"), res.get("name"), res.get("scenario"),
                         res.get("seed"), res.get("sensor"), res.get("sensor_kind"), res.get("detector"), res.get("tracker"),
                         res.get("enhance"), res.get("config_hash"), json.dumps(res.get("tags") or []), json.dumps(res.get("summary") or {})))
            n += 1
    return n
