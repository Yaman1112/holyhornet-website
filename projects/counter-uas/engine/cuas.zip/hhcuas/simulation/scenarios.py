"""Scenario library A–H plus the randomised generator used for training data.

Seed policy (keeps training and evaluation data separate):
  1–999        evaluation campaign and user experiments
  2000–2999    automated tests
  10000–19999  detector training data
  20000–29999  detector validation data (model selection)
"""
from __future__ import annotations

import math
from typing import Callable

import numpy as np

from .config import (BearingSensorSpec, ClutterSpec, Degradation, Environment, Occluder, RadarSpec,
                     ScenarioConfig, TargetSpec, eo_day, eo_lowlight, thermal)

CAM_Z = 2.0


def crossing(id: str, cls: str, range_m: float, speed: float, el_deg: float = 9.0, direction: int = 1,
             hfov_deg: float = 30.0, frac: float = 1.05, t_start: float = 0.0, climb: float = 0.0,
             approach: float = 0.0, **kw) -> TargetSpec:
    """Target crossing the field of view of a north-looking camera at the origin."""
    half = range_m * math.tan(math.radians(hfov_deg) / 2) * frac
    z = CAM_Z + range_m * math.tan(math.radians(el_deg))
    return TargetSpec(id=id, cls=cls, p0=(-direction * half, range_m, z),
                      vel=(direction * speed, -approach, climb), t_start=t_start, **kw)


def _cams(sensors: list[str], **kw):
    make = {"eo": lambda: eo_day("eo-1", **kw), "lowlight": lambda: eo_lowlight("ll-1", **kw),
            "thermal": lambda: thermal("ir-1", **{k: v for k, v in kw.items() if k not in ("width", "height")})}
    return [make[s]() for s in sensors if s in make]


def scenario_a(seed=1, background="clear_sky", lighting="sunny", visibility_m=20000.0, cloud_cover=0.4,
               range_m=120.0, speed_mps=8.0, n_birds=0, sensors=("eo",), duration_s=8.0, **_) -> ScenarioConfig:
    return ScenarioConfig(
        name=f"A daylight / {background} / {lighting}", scenario="A", seed=seed, duration_s=duration_s,
        description="UAVs against a selectable daytime background. Measures detection accuracy and latency.",
        environment=Environment(background=background, lighting=lighting, visibility_m=visibility_m, cloud_cover=cloud_cover),
        cameras=_cams(list(sensors)),
        targets=[crossing("uav-1", "multirotor", range_m, speed_mps, el_deg=10.0, span_m=0.6, weave_amp_m=1.5),
                 crossing("uav-2", "fixed_wing", range_m * 2.8, speed_mps * 2.6, el_deg=5.0, direction=-1, t_start=0.5)],
        clutter=ClutterSpec(n_birds=n_birds))


def scenario_b(seed=1, lighting="night_urban", background="urban", illuminance_lux=None, range_m=120.0,
               speed_mps=8.0, lights=False, duration_s=8.0, **_) -> ScenarioConfig:
    cfg = scenario_a(seed=seed, background=background, lighting=lighting, range_m=range_m, speed_mps=speed_mps,
                     sensors=("eo", "lowlight", "thermal"), duration_s=duration_s)
    cfg.environment.illuminance_lux = illuminance_lux
    for t in cfg.targets:
        t.lights = lights
    cfg.name, cfg.scenario = f"B low-light / {lighting}", "B"
    cfg.description = "The Scenario A targets under reduced illumination, seen by a day camera, a low-light camera and an LWIR camera."
    return cfg


def scenario_c(seed=1, speed_mps=60.0, range_m=150.0, fps=30.0, width=640, exposure_s=None, background="cloudy",
               lighting="sunny", noise_mult=1.0, cls="fixed_wing", span_m=1.6, sensors=("eo",), duration_s=8.0, **_) -> ScenarioConfig:
    height = int(round(width * 0.75))
    cams = _cams(list(sensors), fps=fps, width=width, height=height, fixed_exposure_s=exposure_s,
                 degradation=Degradation(noise_mult=noise_mult))
    cross_t = 2 * range_m * math.tan(math.radians(15)) * 1.05 / max(speed_mps, 1e-3)
    n = max(1, min(4, int(duration_s / (cross_t + 0.6))))
    tg = [crossing(f"fast-{i + 1}", cls, range_m * (1 + 0.15 * i), speed_mps, el_deg=(6.0, 12.0, 9.0, 15.0)[i],
                   direction=1 if i % 2 == 0 else -1, t_start=0.3 + i * (duration_s - 0.3) / n, span_m=span_m,
                   climb=(0.0, -2.0, 3.0, 0.0)[i]) for i in range(n)]
    return ScenarioConfig(
        name=f"C high-speed / {speed_mps:g} m/s @ {range_m:g} m / {fps:g} fps", scenario="C", seed=seed, duration_s=duration_s,
        description="Simulated fast passes across the field of view. Measures motion-related detection and tracking degradation.",
        environment=Environment(background=background, lighting=lighting), cameras=cams, targets=tg)


def scenario_d(seed=1, background="cloudy", lighting="sunny", n_birds=2, sensors=("eo",), duration_s=10.0, **_) -> ScenarioConfig:
    tg = [
        crossing("uav-1", "multirotor", 110, 7, el_deg=8.0, span_m=0.6),
        crossing("uav-2", "multirotor", 140, 9, el_deg=8.6, direction=-1, span_m=0.6),      # crosses uav-1
        crossing("uav-3", "fixed_wing", 320, 22, el_deg=13.0, t_start=1.0),
        crossing("uav-4", "fixed_wing", 380, 20, el_deg=4.5, direction=-1, t_start=2.0, weave_amp_m=6),
        TargetSpec(id="uav-5", cls="multirotor", traj="hover", p0=(18.0, 130.0, 2 + 130 * math.tan(math.radians(14))), span_m=0.6),
    ]
    return ScenarioConfig(
        name="D multiple targets", scenario="D", seed=seed, duration_s=duration_s,
        description="Five UAVs at once including two crossing paths, plus birds. Evaluates association and identity management.",
        environment=Environment(background=background, lighting=lighting), cameras=_cams(list(sensors)),
        targets=tg, clutter=ClutterSpec(n_birds=n_birds))


def scenario_e(seed=1, background="urban", lighting="overcast", occluder_width_m=10.0, sensors=("eo",), duration_s=10.0, **_) -> ScenarioConfig:
    return ScenarioConfig(
        name=f"E partial occlusion / {occluder_width_m:g} m structures", scenario="E", seed=seed, duration_s=duration_s,
        description="Targets pass behind a building and a tree. Measures track continuity and recovery.",
        environment=Environment(background=background, lighting=lighting), cameras=_cams(list(sensors)),
        targets=[crossing("uav-1", "multirotor", 120, 8, el_deg=9.0, span_m=0.6),
                 crossing("uav-2", "fixed_wing", 300, 20, el_deg=5.5, direction=-1, t_start=1.0)],
        occluders=[Occluder(az_deg=-8.0, range_m=60, width_m=occluder_width_m, height_m=26, kind="building"),
                   Occluder(az_deg=8.0, range_m=45, width_m=occluder_width_m * 0.8, height_m=16, kind="tree")])


def scenario_f(seed=1, noise_mult=1.0, fps=30.0, frame_drop_prob=0.0, thermal_contrast_scale=1.0,
               dropout_s=0.0, timestamp_jitter_s=0.0, latency_s=0.0, background="cloudy", lighting="sunny",
               duration_s=10.0, **_) -> ScenarioConfig:
    deg = Degradation(noise_mult=noise_mult, frame_drop_prob=frame_drop_prob, thermal_contrast_scale=thermal_contrast_scale,
                      dropouts=[(3.0, 3.0 + dropout_s)] if dropout_s > 0 else [], timestamp_jitter_s=timestamp_jitter_s,
                      latency_s=latency_s)
    cfg = scenario_h(seed=seed, background=background, lighting=lighting, duration_s=duration_s, fps=fps)
    for c in cfg.cameras:
        c.degradation = deg.model_copy()
    for r in cfg.radars:
        r.degradation = Degradation(dropouts=deg.dropouts, timestamp_jitter_s=timestamp_jitter_s, latency_s=latency_s)
    cfg.name, cfg.scenario = "F sensor degradation", "F"
    cfg.description = "Scenario H scene with configurable noise, frame-rate, thermal-contrast, dropout, timestamp and latency faults."
    return cfg


def scenario_g(seed=1, background="cloudy", lighting="sunny", n_birds=6, n_insects=12, n_aircraft=2,
               sensors=("eo",), duration_s=10.0, **_) -> ScenarioConfig:
    return ScenarioConfig(
        name=f"G false-positive / {background}", scenario="G", seed=seed, duration_s=duration_s,
        description="One UAV among birds, insects, distant aircraft, drifting cloud and background clutter. Measures false alarms and classification errors.",
        environment=Environment(background=background, lighting=lighting, cloud_cover=0.6), cameras=_cams(list(sensors)),
        targets=[crossing("uav-1", "multirotor", 130, 7, el_deg=10.0, span_m=0.6, weave_amp_m=1.0)],
        clutter=ClutterSpec(n_birds=n_birds, n_insects=n_insects, n_aircraft=n_aircraft))


def scenario_h(seed=1, background="cloudy", lighting="sunny", duration_s=12.0, fps=30.0, second_camera=False, **_) -> ScenarioConfig:
    cams = _cams(["eo", "thermal"], fps=fps)
    if lighting.startswith("night") or lighting == "dusk":
        cams = _cams(["lowlight", "thermal"], fps=fps)
    if second_camera:
        az = math.degrees(math.atan2(-150.0, 150.0))
        cams.append(eo_day("eo-2", pos=(150.0, 0.0, 2.0), az_deg=az, el_deg=8.0, fps=fps))
    return ScenarioConfig(
        name=f"H multi-sensor / {lighting}", scenario="H", seed=seed, duration_s=duration_s,
        description="Visible, thermal, simulated radar, acoustic and RF-bearing observations of the same targets.",
        environment=Environment(background=background, lighting=lighting), cameras=cams,
        radars=[RadarSpec()],
        bearing_sensors=[BearingSensorSpec(id="acoustic-1", kind="acoustic", pos=(-10.0, 5.0, 2.0)),
                         BearingSensorSpec(id="rf-1", kind="rf", pos=(8.0, -4.0, 4.0), range_max_m=800.0, sigma_az_deg=6.0, pd=0.85, rate_hz=1.0)],
        targets=[crossing("uav-1", "multirotor", 140, 7, el_deg=10.0, span_m=0.6, approach=3.0),
                 crossing("uav-2", "fixed_wing", 330, 20, el_deg=6.0, direction=-1, t_start=1.0, approach=6.0)],
        clutter=ClutterSpec(n_birds=1))


def _p(name, kind, default, **kw):
    return dict(name=name, type=kind, default=default, **kw)


_BG = ["clear_sky", "cloudy", "urban", "coastal", "vegetation", "open_field"]
_DAY = ["sunny", "overcast", "backlit"]
_NIGHT = ["dusk", "night_urban", "night_moon", "night_dark"]

SCENARIOS: dict[str, dict] = {
    "A": dict(title="Daylight detection", build=scenario_a, default_sensor="eo-1", params=[
        _p("background", "choice", "clear_sky", choices=_BG), _p("lighting", "choice", "sunny", choices=_DAY),
        _p("visibility_m", "number", 20000, min=300, max=40000), _p("range_m", "number", 120, min=40, max=600),
        _p("speed_mps", "number", 8, min=0, max=40), _p("n_birds", "int", 0, min=0, max=10)]),
    "B": dict(title="Low-light detection", build=scenario_b, default_sensor="ll-1", params=[
        _p("lighting", "choice", "night_urban", choices=_NIGHT + _DAY), _p("background", "choice", "urban", choices=_BG),
        _p("range_m", "number", 120, min=40, max=600), _p("lights", "bool", False)]),
    "C": dict(title="High-speed target", build=scenario_c, default_sensor="eo-1", params=[
        _p("speed_mps", "number", 60, min=5, max=150), _p("range_m", "number", 150, min=40, max=800),
        _p("fps", "number", 30, min=5, max=120), _p("width", "int", 640, min=320, max=1280),
        _p("exposure_s", "number", None, min=0.0001, max=0.05), _p("noise_mult", "number", 1, min=0.5, max=8),
        _p("background", "choice", "cloudy", choices=_BG), _p("lighting", "choice", "sunny", choices=_DAY + _NIGHT)]),
    "D": dict(title="Multiple targets", build=scenario_d, default_sensor="eo-1", params=[
        _p("background", "choice", "cloudy", choices=_BG), _p("n_birds", "int", 2, min=0, max=10)]),
    "E": dict(title="Partial occlusion", build=scenario_e, default_sensor="eo-1", params=[
        _p("occluder_width_m", "number", 10, min=2, max=40), _p("background", "choice", "urban", choices=_BG)]),
    "F": dict(title="Sensor degradation", build=scenario_f, default_sensor="eo-1", params=[
        _p("noise_mult", "number", 1, min=0.5, max=10), _p("fps", "number", 30, min=3, max=60),
        _p("frame_drop_prob", "number", 0, min=0, max=0.9), _p("thermal_contrast_scale", "number", 1, min=0.02, max=1),
        _p("dropout_s", "number", 0, min=0, max=5), _p("timestamp_jitter_s", "number", 0, min=0, max=0.2),
        _p("latency_s", "number", 0, min=0, max=2)]),
    "G": dict(title="False-positive evaluation", build=scenario_g, default_sensor="eo-1", params=[
        _p("background", "choice", "cloudy", choices=_BG), _p("n_birds", "int", 6, min=0, max=20),
        _p("n_insects", "int", 12, min=0, max=40), _p("n_aircraft", "int", 2, min=0, max=5)]),
    "H": dict(title="Multi-sensor comparison", build=scenario_h, default_sensor="eo-1", params=[
        _p("lighting", "choice", "sunny", choices=_DAY + _NIGHT), _p("background", "choice", "cloudy", choices=_BG),
        _p("second_camera", "bool", False)]),
}


def build_scenario(key: str, seed: int = 1, **params) -> ScenarioConfig:
    if key not in SCENARIOS:
        raise KeyError(f"unknown scenario {key!r}")
    build: Callable = SCENARIOS[key]["build"]
    return build(seed=seed, **{k: v for k, v in params.items() if v is not None})


def random_training_scenario(seed: int, modality: str = "eo") -> ScenarioConfig:
    """Randomised scene for building detector training/validation sets.
    modality: 'eo' (daylight), 'lowlight' (dusk/night, low-light camera) or 'thermal'."""
    rng = np.random.default_rng([seed, 31337])
    bg = str(rng.choice(_BG))
    if modality == "lowlight":
        lighting = str(rng.choice(_NIGHT))
    else:
        lighting = str(rng.choice(_DAY + (_NIGHT if modality == "thermal" else [])))
    env = Environment(background=bg, lighting=lighting, cloud_cover=float(rng.uniform(0, 0.9)),
                      visibility_m=float(rng.choice([3000, 8000, 20000, 30000])),
                      ambient_temp_c=float(rng.uniform(2, 32)), cloud_base_delta_k=float(rng.uniform(-12, -2)))
    cams = _cams([modality])
    tg = []
    for i in range(int(rng.integers(2, 5))):
        cls = str(rng.choice(["multirotor", "multirotor", "fixed_wing"]))
        span = float(rng.uniform(0.4, 1.0)) if cls == "multirotor" else float(rng.uniform(1.2, 3.0))
        size_px = float(rng.uniform(3.0, 22.0))
        r = cams[0].fx * span / size_px
        sp = float(rng.uniform(0, 14)) if cls == "multirotor" else float(rng.uniform(12, 35))
        tg.append(crossing(f"uav-{i + 1}", cls, r, sp, el_deg=float(rng.uniform(0.5, 17)), direction=int(rng.choice([-1, 1])),
                           frac=float(rng.uniform(0.2, 1.0)), t_start=float(rng.uniform(0, 1.0)), span_m=span,
                           weave_amp_m=float(rng.uniform(0, 3)), climb=float(rng.uniform(-1.5, 1.5))))
    occ = []
    for _ in range(int(rng.integers(0, 3))):
        kind = str(rng.choice(["building", "tree"]))
        r = float(rng.uniform(35, 90))
        occ.append(Occluder(az_deg=float(rng.uniform(-13, 13)), range_m=r, width_m=float(rng.uniform(4, 18)),
                            height_m=float(rng.uniform(0.12, 0.4)) * r, kind=kind))
    return ScenarioConfig(name=f"train-{modality}-{seed}", scenario="train", seed=seed, duration_s=3.0, environment=env,
                          cameras=cams, targets=tg, occluders=occ,
                          clutter=ClutterSpec(n_birds=int(rng.integers(1, 5)), n_insects=int(rng.integers(0, 6)),
                                              n_aircraft=int(rng.integers(0, 3))))
