"""Simulated aerial objects: kinematics and silhouette sprites."""
from __future__ import annotations

import math
import zlib
from functools import lru_cache

import cv2
import numpy as np

from .config import TargetSpec

SPRITE_N = 256          # master sprite resolution
SPRITE_SPAN = 240.0     # pixels spanned by the object's largest dimension


def _phase(spec: TargetSpec, k: int) -> float:
    return (zlib.crc32(f"{spec.id}:{k}".encode()) % 10000) / 10000.0 * 2 * math.pi


def position(spec: TargetSpec, t) -> np.ndarray:
    """World position (ENU metres) at time(s) t. Returns (N,3)."""
    t = np.atleast_1d(np.asarray(t, dtype=np.float64))
    tau = t - spec.t_start
    p0 = np.asarray(spec.p0, dtype=np.float64)
    v = np.asarray(spec.vel, dtype=np.float64)
    if spec.traj == "hover":
        p = np.repeat(p0[None], len(t), 0)
        for k, amp in enumerate((0.35, 0.2, 0.25)):
            p[:, k] += amp * np.sin(2 * math.pi * tau / (3.1 + 1.7 * k) + _phase(spec, k))
        return p
    if spec.traj == "orbit":
        ang = 2 * math.pi * tau / spec.orbit_period_s + _phase(spec, 0)
        p = p0[None] + v[None] * tau[:, None]
        p[:, 0] += spec.orbit_radius_m * np.cos(ang)
        p[:, 1] += spec.orbit_radius_m * np.sin(ang)
        return p
    p = p0[None] + v[None] * tau[:, None]
    if spec.weave_amp_m:
        hv = np.array([v[0], v[1], 0.0])
        n = np.linalg.norm(hv)
        lat = np.array([-hv[1], hv[0], 0.0]) / n if n > 1e-6 else np.array([1.0, 0, 0])
        w = 2 * math.pi / spec.weave_period_s
        p += lat[None] * (spec.weave_amp_m * np.sin(w * tau + _phase(spec, 0)))[:, None]
        p[:, 2] += 0.3 * spec.weave_amp_m * np.sin(1.7 * w * tau + _phase(spec, 1))
    return p


def velocity(spec: TargetSpec, t: float) -> np.ndarray:
    h = 1e-3
    return (position(spec, t + h)[0] - position(spec, t - h)[0]) / (2 * h)


def active(spec: TargetSpec, t: float, duration: float) -> bool:
    return spec.t_start <= t <= (spec.t_end if spec.t_end is not None else duration)


# ----------------------------------------------------------------- sprites
def _canvas():
    return np.zeros((SPRITE_N, SPRITE_N), np.uint8)


def _multirotor() -> np.ndarray:
    c = _canvas()
    cx = cy = SPRITE_N // 2
    r = int(SPRITE_SPAN / 2 - 44)
    rot = _canvas()
    for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        px, py = int(cx + sx * r * 0.72), int(cy + sy * r * 0.72)
        cv2.line(c, (cx, cy), (px, py), 255, 11, cv2.LINE_AA)
        cv2.circle(rot, (px, py), 44, 115, -1, cv2.LINE_AA)       # blurred prop disc
        cv2.circle(c, (px, py), 11, 255, -1, cv2.LINE_AA)
    cv2.circle(c, (cx, cy), 30, 255, -1, cv2.LINE_AA)
    c = np.maximum(c, rot)
    # oblique view: squash vertically, add landing gear
    sq = cv2.resize(c, (SPRITE_N, SPRITE_N // 2), interpolation=cv2.INTER_AREA)
    out = _canvas()
    y0 = SPRITE_N // 4
    out[y0:y0 + SPRITE_N // 2] = sq
    cv2.line(out, (cx - 26, cy + 8), (cx - 34, cy + 40), 255, 6, cv2.LINE_AA)
    cv2.line(out, (cx + 26, cy + 8), (cx + 34, cy + 40), 255, 6, cv2.LINE_AA)
    return out


def _fixed_wing() -> np.ndarray:
    c = _canvas()
    cx = cy = SPRITE_N // 2
    cv2.ellipse(c, (cx, cy), (78, 9), 0, 0, 360, 255, -1, cv2.LINE_AA)            # fuselage (+x = nose)
    wing = np.array([[cx + 22, cy - 120], [cx + 22, cy + 120], [cx - 8, cy + 120], [cx - 14, cy - 120]])
    cv2.fillConvexPoly(c, wing, 255, cv2.LINE_AA)
    tail = np.array([[cx - 62, cy - 36], [cx - 62, cy + 36], [cx - 78, cy + 36], [cx - 78, cy - 36]])
    cv2.fillConvexPoly(c, tail, 255, cv2.LINE_AA)
    return c


def _aircraft() -> np.ndarray:
    c = _canvas()
    cx = cy = SPRITE_N // 2
    cv2.ellipse(c, (cx, cy), (120, 10), 0, 0, 360, 255, -1, cv2.LINE_AA)
    for s in (1, -1):
        wing = np.array([[cx + 22, cy], [cx - 40, cy + s * 104], [cx - 58, cy + s * 104], [cx - 18, cy]])
        cv2.fillConvexPoly(c, wing, 255, cv2.LINE_AA)
        tail = np.array([[cx - 96, cy], [cx - 116, cy + s * 36], [cx - 122, cy + s * 36], [cx - 110, cy]])
        cv2.fillConvexPoly(c, tail, 255, cv2.LINE_AA)
    return c


def _bird(phase: float) -> np.ndarray:
    c = _canvas()
    cx = cy = SPRITE_N // 2
    flap = math.sin(phase)                       # -1 (down) .. 1 (up)
    half = 120 * (0.45 + 0.55 * abs(math.cos(phase * 0.5 + 0.4)))
    droop = -42 * flap                            # wing-tip sweep along body axis
    cv2.ellipse(c, (cx, cy), (40, 13), 0, 0, 360, 255, -1, cv2.LINE_AA)
    for s in (1, -1):
        wing = np.array([[cx + 16, cy], [cx + 6 + droop * 0.5, cy + s * half * 0.55],
                         [cx - 6 + droop, cy + s * half], [cx - 18, cy]], np.int32)
        cv2.fillConvexPoly(c, wing, 255, cv2.LINE_AA)
    return c


def _insect() -> np.ndarray:
    c = _canvas()
    cv2.circle(c, (SPRITE_N // 2, SPRITE_N // 2), 90, 255, -1, cv2.LINE_AA)
    return cv2.GaussianBlur(c, (0, 0), 30)


N_BIRD_PHASES = 8


@lru_cache(maxsize=None)
def sprite_pyramid(cls: str, phase_idx: int = 0) -> tuple[tuple[np.ndarray, float], ...]:
    """Returns ((alpha float32, span_px), ...) from coarse to fine."""
    if cls == "multirotor":
        m = _multirotor()
    elif cls == "fixed_wing":
        m = _fixed_wing()
    elif cls == "aircraft":
        m = _aircraft()
    elif cls == "bird":
        m = _bird(2 * math.pi * phase_idx / N_BIRD_PHASES)
    else:
        m = _insect()
    m = m.astype(np.float32) / 255.0
    levels = []
    for n in (16, 32, 64, 128):
        levels.append((cv2.resize(m, (n, n), interpolation=cv2.INTER_AREA), SPRITE_SPAN * n / SPRITE_N))
    levels.append((m, SPRITE_SPAN))
    return tuple(levels)


def render_alpha(cls: str, phase_idx: int, uv: np.ndarray, size_px: float, angle: float,
                 width: int, height: int, ss: int = 4):
    """Rasterise an object's coverage (alpha) integrated over the exposure.

    uv: (K,2) continuous image positions sampled across the exposure (motion blur).
    Returns (x0, y0, alpha[h,w], total_alpha_including_offscreen) or None when fully off-frame.
    """
    half = size_px / 2 + 2
    x0 = int(math.floor(uv[:, 0].min() - half)); x1 = int(math.ceil(uv[:, 0].max() + half)) + 1
    y0 = int(math.floor(uv[:, 1].min() - half)); y1 = int(math.ceil(uv[:, 1].max() + half)) + 1
    if x1 <= 0 or y1 <= 0 or x0 >= width or y0 >= height:
        return None
    w, h = x1 - x0, y1 - y0
    if w > 1200 or h > 1200:
        return None
    pyr = sprite_pyramid(cls, phase_idx)
    need = size_px * ss
    spr, span = pyr[-1]
    for s, sp in pyr:
        if sp >= need:
            spr, span = s, sp
            break
    sc = need / span
    c, s_ = sc * math.cos(angle), sc * math.sin(angle)
    ctr = (spr.shape[0] - 1) / 2
    acc = np.zeros((h * ss, w * ss), np.float32)
    for u, v in uv:
        tx = (u - x0) * ss - 0.5; ty = (v - y0) * ss - 0.5
        M = np.array([[c, -s_, tx - (c * ctr - s_ * ctr)], [s_, c, ty - (s_ * ctr + c * ctr)]], np.float32)
        acc += cv2.warpAffine(spr, M, (w * ss, h * ss), flags=cv2.INTER_LINEAR)
    acc /= len(uv)
    alpha = cv2.resize(acc, (w, h), interpolation=cv2.INTER_AREA)
    total = float(alpha.sum())
    # clip to the image
    cx0, cy0 = max(0, x0), max(0, y0)
    cx1, cy1 = min(width, x1), min(height, y1)
    alpha = alpha[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
    return cx0, cy0, alpha, total
