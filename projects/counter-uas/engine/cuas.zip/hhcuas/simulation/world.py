"""Scenario simulator: renders sensor frames with exact ground truth and
generates radar / bearing-sensor reports. Everything produced here is SIMULATED
and is labelled as such on every record."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import cv2
import numpy as np

from .. import ORIGIN_SIMULATED
from . import sensors as S
from . import targets as T
from .config import CameraSpec, ScenarioConfig, TargetSpec
from .environments import TARGET_LIGHT, Background, build_background


@dataclass
class Frame:
    idx: int
    t: float                 # true capture time (end of exposure)
    t_stamp: float           # timestamp reported by the sensor (may contain errors)
    cam_id: str
    image: np.ndarray | None  # uint8 BGR (EO) or grey (thermal); None when dropped
    gt: list[dict]
    dropped: bool = False
    exposure_s: float = 0.0
    gain: float = 1.0
    origin: str = ORIGIN_SIMULATED
    meta: dict = field(default_factory=dict)


def _in_dropout(t: float, intervals) -> bool:
    return any(a <= t <= b for a, b in intervals)


class Simulator:
    def __init__(self, cfg: ScenarioConfig):
        self.cfg = cfg
        self.env = cfg.environment
        self.targets: list[TargetSpec] = [t.resolved() for t in cfg.targets] + self._make_clutter()
        self._bg: dict[str, Background] = {}
        self._exp: dict[str, tuple[float, float]] = {}
        self._iris: dict[str, float] = {}
        self._pool = np.random.default_rng([cfg.seed, 99]).standard_normal(1 << 22, dtype=np.float32)
        self._gamma = (np.linspace(0, 1, 4096) ** (1 / 2.2) * 255 + 0.5).astype(np.uint8)

    # ------------------------------------------------------------ clutter
    def _make_clutter(self) -> list[TargetSpec]:
        cfg = self.cfg
        if not cfg.cameras:
            return []
        rng = np.random.default_rng([cfg.seed, 7919])
        cam = cfg.cameras[0]
        half = math.radians(cam.hfov_deg) / 2
        out: list[TargetSpec] = []

        def place(rng_m, az_off, el):
            az = math.radians(cam.az_deg) + az_off
            return np.asarray(cam.pos) + rng_m * S.bearing_unit(az, el)

        vfov = half * cam.height / cam.width
        el0 = math.radians(cam.el_deg)
        for i in range(cfg.clutter.n_birds):
            r = float(rng.uniform(60, 250)); side = 1 if rng.random() < 0.5 else -1
            p = place(r, -side * half * float(rng.uniform(0.3, 1.0)), el0 + vfov * float(rng.uniform(-0.5, 0.8)))
            sp = float(rng.uniform(8, 14))
            az = math.radians(cam.az_deg)
            lat = np.array([math.cos(az), -math.sin(az), 0.0]) * side
            v = lat * sp + np.array([0, 0, float(rng.uniform(-0.8, 0.8))])
            out.append(TargetSpec(id=f"bird-{i + 1}", cls="bird", p0=tuple(p), vel=tuple(v),
                                  weave_amp_m=float(rng.uniform(2, 5)), weave_period_s=float(rng.uniform(2, 4)),
                                  span_m=float(rng.uniform(0.6, 1.3)),
                                  t_start=float(rng.uniform(0, cfg.duration_s * 0.4)), is_clutter=True).resolved())
        for i in range(cfg.clutter.n_insects):
            r = float(rng.uniform(2.0, 6.0))
            p = place(r, half * float(rng.uniform(-0.9, 0.9)), el0 + vfov * float(rng.uniform(-0.8, 0.8)))
            d = rng.normal(size=3); d /= np.linalg.norm(d)
            t0 = float(rng.uniform(0, cfg.duration_s - 1.0))
            out.append(TargetSpec(id=f"insect-{i + 1}", cls="insect", p0=tuple(p), vel=tuple(d * float(rng.uniform(0.8, 2.5))),
                                  weave_amp_m=0.25, weave_period_s=0.6, t_start=t0,
                                  t_end=t0 + float(rng.uniform(0.5, 1.5)), is_clutter=True).resolved())
        for i in range(cfg.clutter.n_aircraft):
            r = float(rng.uniform(4000, 9000)); side = 1 if rng.random() < 0.5 else -1
            p = place(r, -side * half * float(rng.uniform(0.2, 0.9)), el0 + vfov * float(rng.uniform(0.0, 0.8)))
            az = math.radians(cam.az_deg)
            lat = np.array([math.cos(az), -math.sin(az), 0.0]) * side
            out.append(TargetSpec(id=f"aircraft-{i + 1}", cls="aircraft", p0=tuple(p),
                                  vel=tuple(lat * float(rng.uniform(70, 120))), is_clutter=True).resolved())
        return out

    # ------------------------------------------------------------ helpers
    def background(self, cam: CameraSpec) -> Background:
        if cam.id not in self._bg:
            self._bg[cam.id] = build_background(self.env, cam, self.cfg.occluders, self.cfg.seed, self.cfg.duration_s)
        return self._bg[cam.id]

    def exposure(self, cam: CameraSpec) -> tuple[float, float]:
        """Auto-exposure solved once on the static scene: (exposure_s, gain)."""
        if cam.id not in self._exp:
            if cam.kind == "thermal":
                self._exp[cam.id] = (0.008, 1.0)     # microbolometer thermal time constant
            else:
                mean_rad = float(np.clip(self.background(cam).eo(0.0), 0, 1.5).mean())
                k = max(mean_rad * self.env.lux * cam.sens_e_per_lux_s, 1e-12)
                target = 0.22 * cam.full_well_e       # mean signal level the auto-exposure aims for
                t_min = 1 / 8000
                t_exp = cam.fixed_exposure_s or float(np.clip(target / k, t_min, min(cam.max_exposure_s, 1 / cam.fps)))
                iris = min(1.0, target / (k * t_exp))  # iris / ND closes when the shutter limit is reached
                gain = float(np.clip(target / (k * t_exp * iris), 1.0, cam.max_gain))
                self._exp[cam.id] = (t_exp, gain)
                self._iris[cam.id] = iris
        return self._exp[cam.id]

    def n_frames(self, cam_id: str) -> int:
        return int(math.floor(self.cfg.duration_s * self.cfg.camera(cam_id).fps))

    def frames(self, cam_id: str):
        for i in range(self.n_frames(cam_id)):
            yield self.render(cam_id, i)

    # ------------------------------------------------------------ rendering
    def render(self, cam_id: str, idx: int, with_image: bool = True) -> Frame:
        cfg, env = self.cfg, self.env
        cam = cfg.camera(cam_id)
        ci = [c.id for c in cfg.cameras].index(cam_id)
        rng = np.random.default_rng([cfg.seed, 1000 + ci, idx])
        deg = cam.degradation
        t = (idx + 1) / cam.fps
        t_stamp = t + deg.timestamp_bias_s + (deg.timestamp_jitter_s * float(rng.standard_normal()) if deg.timestamp_jitter_s else 0.0)
        t_exp, gain = self.exposure(cam)
        dropped = _in_dropout(t, deg.dropouts) or (deg.frame_drop_prob > 0 and rng.random() < deg.frame_drop_prob)
        bg = self.background(cam)
        thermal = cam.kind == "thermal"
        W, H = cam.width, cam.height
        img = (bg.thermal(t) if thermal else bg.eo(t)) if with_image and not dropped else None
        T_amb = env.ambient_temp_c + 273.15
        gt: list[dict] = []

        for spec in self.targets:
            if not T.active(spec, t, cfg.duration_s):
                continue
            # exposure sub-samples (motion blur)
            p_mid = T.position(spec, t - t_exp / 2)
            u0, v0, z0, r0 = S.project(cam, p_mid)
            if z0[0] <= 0.5:
                continue
            pe = T.position(spec, np.array([t - t_exp, t]))
            ue, ve, ze, _ = S.project(cam, pe)
            if np.any(ze <= 0.5):
                continue
            blur = math.hypot(ue[1] - ue[0], ve[1] - ve[0])
            K = int(np.clip(math.ceil(blur) + 1, 1, 24))
            ts = t - t_exp * (np.arange(K) + 0.5) / K
            uu, vv, _, _ = S.project(cam, T.position(spec, ts))
            size_px = cam.fx * spec.span_m / r0[0]
            ang = math.atan2(ve[1] - ve[0], ue[1] - ue[0]) if spec.cls in ("fixed_wing", "aircraft", "bird") and blur > 1e-6 else 0.0
            if spec.cls in ("fixed_wing", "aircraft", "bird") and blur <= 1e-6:
                ang = 0.0
            ph = int(((t * 4.0 + T._phase(spec, 3) / (2 * math.pi)) % 1.0) * T.N_BIRD_PHASES) % T.N_BIRD_PHASES if spec.cls == "bird" else 0
            res = T.render_alpha(spec.cls, ph, np.stack([uu, vv], 1), size_px, ang, W, H)
            if res is None:
                continue
            x0, y0, alpha, total = res
            h, w = alpha.shape
            if h == 0 or w == 0 or total <= 1e-9:
                continue
            occ = bg.occ_mask[y0:y0 + h, x0:x0 + w]
            a_vis = alpha * (1 - occ)
            vis = float(a_vis.sum() / total)
            amax = float(alpha.max())
            ys, xs = np.nonzero(alpha > max(0.15 * amax, 1e-4))
            if len(xs) == 0:
                continue
            bx1, by1 = x0 + int(xs.min()), y0 + int(ys.min())
            bx2, by2 = x0 + int(xs.max()) + 1, y0 + int(ys.max()) + 1
            if bx2 - bx1 < 2:
                bx2 = bx1 + 2
            if by2 - by1 < 2:
                by2 = by1 + 2
            tau = math.exp(-3.912 * r0[0] / env.visibility_m)
            snr = 0.0
            core = a_vis > 0.3 * amax
            if thermal:
                tau_ir = math.exp(-env.lwir_atten_per_km * r0[0] / 1000.0)
                T_app = T_amb + spec.delta_t_k * tau_ir
                if img is not None:
                    roi = img[y0:y0 + h, x0:x0 + w]
                    if core.any():
                        snr = float(np.abs(a_vis * (T_app - roi))[core].mean()) * deg.thermal_contrast_scale / (cam.netd_k * deg.noise_mult)
                    roi += (T_app - roi) * a_vis
            else:
                c_t = spec.reflectance * TARGET_LIGHT[env.lighting]
                col = c_t * tau + bg.airlight * (1 - tau)
                if img is not None:
                    roi = img[y0:y0 + h, x0:x0 + w]
                    if core.any():
                        d_rad = np.abs(a_vis[..., None] * (col[None, None] - roi)).mean(axis=2)[core].mean()
                        e_bg = float(np.clip(roi, 0, None).mean()) * env.lux * cam.sens_e_per_lux_s * t_exp * self._iris.get(cam.id, 1.0)
                        snr = float(d_rad) * env.lux * cam.sens_e_per_lux_s * t_exp * self._iris.get(cam.id, 1.0) / (math.sqrt(e_bg + cam.read_noise_e ** 2) * deg.noise_mult)
                    roi += (col[None, None] - roi) * a_vis[..., None]
                    if spec.lights and (t % 1.0) < 0.5 and vis > 0.5:
                        px, py = int(u0[0]), int(v0[0])
                        if 0 <= px < W and 0 <= py < H:
                            img[py, px] += 3e4 / (r0[0] ** 2 * max(env.lux, 1e-3))
            gt.append(dict(
                id=spec.id, cls=spec.cls, bbox=[bx1, by1, bx2, by2], cx=float(u0[0]), cy=float(v0[0]),
                size_px=float(size_px), range_m=float(r0[0]), vis=vis,
                snr=snr, blur_px=float(blur), is_clutter=spec.is_clutter,
            ))

        out = None
        if img is not None:
            out = self._thermal_sensor(img, cam, bg, rng) if thermal else self._eo_sensor(img, cam, bg, rng, t, t_exp, gain)
        return Frame(idx=idx, t=t, t_stamp=t_stamp, cam_id=cam_id, image=out, gt=gt, dropped=dropped,
                     exposure_s=t_exp, gain=gain, meta=dict(sensor_kind=cam.kind, lux=env.lux))

    def _eo_sensor(self, rad, cam, bg, rng, t, t_exp, gain):
        env, deg = self.env, cam.degradation
        if env.background == "coastal" and env.lighting in ("sunny", "backlit"):
            hz = int(max(0, min(cam.height - 1, bg.horizon_row)))
            n = 40
            if hz < cam.height - 1:
                ys = rng.integers(hz, cam.height, n); xs = rng.integers(0, cam.width, n)
                rad[ys, xs] += 0.6                       # sun glint on water
        if cam.exposure_wobble_ev:
            gain = gain * 2 ** (cam.exposure_wobble_ev * math.sin(2 * math.pi * t / 3.0))
        e = np.clip(rad, 0, None) * np.float32(env.lux * cam.sens_e_per_lux_s * t_exp * self._iris.get(cam.id, 1.0))
        sigma = np.sqrt(e + np.float32(cam.read_noise_e ** 2))
        e += sigma * (self._noise(rng, e.shape) * np.float32(deg.noise_mult))
        q = np.clip(e * np.float32(gain / cam.full_well_e * 4095.0), 0, 4095).astype(np.uint16)
        return self._gamma[q]

    def _noise(self, rng, shape) -> np.ndarray:
        """Unit Gaussian noise drawn as a random window of a per-run pool (fast, deterministic)."""
        n = int(np.prod(shape))
        if n > len(self._pool) // 2:
            return rng.standard_normal(shape, dtype=np.float32)
        off = int(rng.integers(0, len(self._pool) - n))
        return self._pool[off:off + n].reshape(shape)

    def _thermal_sensor(self, Tm, cam, bg, rng):
        deg = cam.degradation
        if deg.thermal_contrast_scale != 1.0:
            m = float(Tm.mean())
            Tm = m + (Tm - m) * deg.thermal_contrast_scale
        if cam.psf_sigma_px > 0:
            Tm = cv2.GaussianBlur(Tm, (0, 0), cam.psf_sigma_px)
        Tm = Tm + np.float32(cam.netd_k * deg.noise_mult) * self._noise(rng, Tm.shape)
        lo, hi = bg.agc
        return (np.clip((Tm - lo) / (hi - lo), 0, 1) * 255 + 0.5).astype(np.uint8)

    # ------------------------------------------------------------ truth
    def truth(self, t: float, include_clutter: bool = True) -> list[dict]:
        out = []
        for spec in self.targets:
            if spec.cls == "insect" or not T.active(spec, t, self.cfg.duration_s):
                continue
            if spec.is_clutter and not include_clutter:
                continue
            out.append(dict(id=spec.id, cls=spec.cls, pos=T.position(spec, t)[0].tolist(),
                            vel=T.velocity(spec, t).tolist(), is_clutter=spec.is_clutter))
        return out

    # ------------------------------------------------------------ radar
    def radar_scans(self, radar_id: str) -> list[dict]:
        cfg = self.cfg
        ri = [r.id for r in cfg.radars].index(radar_id)
        radar = cfg.radars[ri]
        rng = np.random.default_rng([cfg.seed, 5000 + ri])
        deg = radar.degradation
        pos = np.asarray(radar.pos)
        scans = []
        n = int(cfg.duration_s * radar.scan_hz)
        for k in range(1, n + 1):
            t = k / radar.scan_hz
            if _in_dropout(t, deg.dropouts) or (deg.frame_drop_prob and rng.random() < deg.frame_drop_prob):
                continue
            plots = []
            for spec in self.targets:
                if spec.cls == "insect" or not T.active(spec, t, cfg.duration_s):
                    continue
                p = T.position(spec, t)[0]
                r, az, el = S.enu_to_polar(pos, p)
                if r > radar.range_max_m or el < 0 or el > math.radians(radar.el_max_deg):
                    continue
                if S.line_of_sight_blocked(pos, p, cfg.occluders):
                    continue
                vr = float((p - pos) @ T.velocity(spec, t) / r)
                if rng.random() > S.radar_pd(radar, spec.rcs_m2, r, vr):
                    continue
                m = deg.noise_mult
                plots.append(dict(
                    r=r + radar.sigma_range_m * m * float(rng.standard_normal()),
                    az=az + math.radians(radar.sigma_az_deg) * m * float(rng.standard_normal()),
                    el=el + math.radians(radar.sigma_el_deg) * m * float(rng.standard_normal()),
                    vr=vr + radar.sigma_vr_mps * m * float(rng.standard_normal()), truth_id=spec.id))
            for _ in range(int(rng.poisson(radar.false_alarms_per_scan))):
                plots.append(dict(r=float(rng.uniform(50, radar.range_max_m)), az=float(rng.uniform(-math.pi, math.pi)),
                                  el=float(rng.uniform(0, math.radians(radar.el_max_deg))),
                                  vr=float(rng.normal(0, 5)), truth_id=None))
            stamp = t + deg.timestamp_bias_s + deg.timestamp_jitter_s * float(rng.standard_normal())
            scans.append(dict(t=t, t_stamp=stamp, sensor=radar.id, kind="radar", plots=plots, origin=ORIGIN_SIMULATED))
        return scans

    # ------------------------------------------------------------ bearing reporters
    def bearing_reports(self, sensor_id: str) -> list[dict]:
        cfg = self.cfg
        si = [s.id for s in cfg.bearing_sensors].index(sensor_id)
        sen = cfg.bearing_sensors[si]
        rng = np.random.default_rng([cfg.seed, 6000 + si])
        pos = np.asarray(sen.pos)
        out = []
        for k in range(1, int(cfg.duration_s * sen.rate_hz) + 1):
            t = k / sen.rate_hz
            if _in_dropout(t, sen.degradation.dropouts):
                continue
            reps = []
            for spec in self.targets:
                if not T.active(spec, t, cfg.duration_s):
                    continue
                if sen.kind == "rf" and not spec.rf_emitter:
                    continue
                if sen.kind == "acoustic" and spec.cls not in ("multirotor", "fixed_wing"):
                    continue
                r, az, _ = S.enu_to_polar(pos, T.position(spec, t)[0])
                pd = sen.pd * (0.5 if (sen.kind == "acoustic" and spec.cls == "fixed_wing") else 1.0)
                if r > sen.range_max_m or rng.random() > pd:
                    continue
                reps.append(dict(az=az + math.radians(sen.sigma_az_deg) * sen.degradation.noise_mult * float(rng.standard_normal()),
                                 truth_id=spec.id))
            out.append(dict(t=t, t_stamp=t + sen.degradation.timestamp_bias_s, sensor=sen.id, kind=sen.kind,
                            plots=reps, origin=ORIGIN_SIMULATED))
        return out
