"""Scenario configuration models (pydantic). Everything a run needs is in here,
so a config + seed reproduces an experiment exactly."""
from __future__ import annotations

import hashlib
import json
from typing import Literal, Optional

from pydantic import BaseModel, Field

Vec3 = tuple[float, float, float]

LIGHTING_LUX = {
    "sunny": 80000.0, "overcast": 10000.0, "backlit": 60000.0, "dusk": 40.0,
    "night_urban": 1.0, "night_moon": 0.2, "night_dark": 0.01,
}


class Environment(BaseModel):
    background: Literal["clear_sky", "cloudy", "urban", "coastal", "vegetation", "open_field"] = "clear_sky"
    lighting: Literal["sunny", "overcast", "backlit", "dusk", "night_urban", "night_moon", "night_dark"] = "sunny"
    illuminance_lux: Optional[float] = Field(None, description="Overrides the lighting preset")
    cloud_cover: float = Field(0.3, ge=0, le=1)
    visibility_m: float = Field(20000.0, gt=50, description="Meteorological visibility (haze)")
    ambient_temp_c: float = 18.0
    zenith_sky_temp_c: float = Field(-40.0, description="Effective LWIR clear-sky temperature at zenith")
    cloud_base_delta_k: float = Field(-8.0, description="Cloud apparent temperature minus ambient")
    solar_heating_k: Optional[float] = Field(None, description="Mean heating of ground/buildings above ambient")
    lwir_atten_per_km: float = 0.3
    wind_mps: float = 4.0

    @property
    def lux(self) -> float:
        return self.illuminance_lux if self.illuminance_lux is not None else LIGHTING_LUX[self.lighting]

    @property
    def is_night(self) -> bool:
        return self.lighting.startswith("night") or self.lighting == "dusk"


class Degradation(BaseModel):
    noise_mult: float = 1.0
    frame_drop_prob: float = 0.0
    dropouts: list[tuple[float, float]] = Field(default_factory=list, description="[t0,t1] intervals with no data")
    timestamp_jitter_s: float = 0.0
    timestamp_bias_s: float = 0.0
    latency_s: float = 0.0
    thermal_contrast_scale: float = 1.0


class CameraSpec(BaseModel):
    id: str
    kind: Literal["eo_day", "eo_lowlight", "thermal"] = "eo_day"
    width: int = 640
    height: int = 480
    hfov_deg: float = 30.0
    fps: float = 30.0
    pos: Vec3 = (0.0, 0.0, 2.0)
    az_deg: float = 0.0
    el_deg: float = 8.0
    # EO radiometry (electrons per lux-second at unit relative radiance)
    sens_e_per_lux_s: float = 2000.0
    read_noise_e: float = 6.0
    full_well_e: float = 10000.0
    max_exposure_s: float = 1 / 60
    max_gain: float = 16.0
    fixed_exposure_s: Optional[float] = None
    exposure_wobble_ev: float = 0.0
    # thermal
    netd_k: float = 0.05
    psf_sigma_px: float = 0.7
    # calibration error used by fusion experiments (truth minus assumed boresight)
    calib_bias_deg: tuple[float, float] = (0.0, 0.0)
    degradation: Degradation = Field(default_factory=Degradation)

    @property
    def fx(self) -> float:
        import math
        return (self.width / 2) / math.tan(math.radians(self.hfov_deg) / 2)


def eo_day(id: str = "eo-1", **kw) -> CameraSpec:
    return CameraSpec(id=id, kind="eo_day", **kw)


def eo_lowlight(id: str = "ll-1", **kw) -> CameraSpec:
    base = dict(sens_e_per_lux_s=14000.0, read_noise_e=1.6, max_exposure_s=1 / 30, max_gain=64.0)
    base.update(kw)
    return CameraSpec(id=id, kind="eo_lowlight", **base)


def thermal(id: str = "ir-1", **kw) -> CameraSpec:
    base = dict(width=320, height=256)
    base.update(kw)
    return CameraSpec(id=id, kind="thermal", **base)


class RadarSpec(BaseModel):
    id: str = "radar-1"
    pos: Vec3 = (30.0, -20.0, 3.0)
    range_max_m: float = 1500.0
    el_max_deg: float = 45.0
    scan_hz: float = 2.0
    sigma_range_m: float = 3.0
    sigma_az_deg: float = 1.0
    sigma_el_deg: float = 2.5
    sigma_vr_mps: float = 0.5
    snr0_db: float = 13.0          # single-scan SNR for rcs0 at range0
    rcs0_m2: float = 0.01
    range0_m: float = 1000.0
    pfa: float = 1e-6
    false_alarms_per_scan: float = 0.3
    min_radial_speed_mps: float = 0.5
    degradation: Degradation = Field(default_factory=Degradation)


class BearingSensorSpec(BaseModel):
    """Azimuth-only reporter: acoustic array or authorised RF direction-finding metadata."""
    id: str
    kind: Literal["acoustic", "rf"] = "acoustic"
    pos: Vec3 = (0.0, 0.0, 2.0)
    range_max_m: float = 250.0
    sigma_az_deg: float = 8.0
    pd: float = 0.7
    rate_hz: float = 2.0
    degradation: Degradation = Field(default_factory=Degradation)


CLASS_DEFAULTS = {
    #               span  refl  dT    rcs
    "multirotor": (0.45, 0.18, 6.0, 0.02),
    "fixed_wing": (2.0, 0.30, 2.5, 0.08),
    "bird": (0.9, 0.22, 4.0, 0.008),
    "aircraft": (34.0, 0.55, 15.0, 20.0),
    "insect": (0.025, 0.15, 0.0, 1e-6),
}


class TargetSpec(BaseModel):
    id: str
    cls: Literal["multirotor", "fixed_wing", "bird", "aircraft", "insect"] = "multirotor"
    traj: Literal["linear", "hover", "orbit"] = "linear"
    p0: Vec3 = (0.0, 200.0, 40.0)
    vel: Vec3 = (10.0, 0.0, 0.0)
    weave_amp_m: float = 0.0
    weave_period_s: float = 4.0
    orbit_radius_m: float = 30.0
    orbit_period_s: float = 20.0
    t_start: float = 0.0
    t_end: Optional[float] = None
    span_m: Optional[float] = None
    reflectance: Optional[float] = None
    delta_t_k: Optional[float] = None
    rcs_m2: Optional[float] = None
    lights: bool = False
    rf_emitter: Optional[bool] = None
    is_clutter: bool = False

    def resolved(self) -> "TargetSpec":
        span, refl, dt, rcs = CLASS_DEFAULTS[self.cls]
        return self.model_copy(update=dict(
            span_m=self.span_m if self.span_m is not None else span,
            reflectance=self.reflectance if self.reflectance is not None else refl,
            delta_t_k=self.delta_t_k if self.delta_t_k is not None else dt,
            rcs_m2=self.rcs_m2 if self.rcs_m2 is not None else rcs,
            rf_emitter=self.rf_emitter if self.rf_emitter is not None else self.cls == "multirotor",
        ))


class Occluder(BaseModel):
    """Vertical rectangle (building face / tree) standing on the ground, facing the site origin."""
    az_deg: float = 0.0
    range_m: float = 60.0
    width_m: float = 12.0
    height_m: float = 25.0
    kind: Literal["building", "tree"] = "building"


class ClutterSpec(BaseModel):
    n_birds: int = 0
    n_insects: int = 0
    n_aircraft: int = 0


class ScenarioConfig(BaseModel):
    name: str = "custom"
    scenario: str = "custom"           # library key (A..H) or "custom"
    description: str = ""
    seed: int = 1
    duration_s: float = 8.0
    environment: Environment = Field(default_factory=Environment)
    cameras: list[CameraSpec] = Field(default_factory=lambda: [eo_day()])
    radars: list[RadarSpec] = Field(default_factory=list)
    bearing_sensors: list[BearingSensorSpec] = Field(default_factory=list)
    targets: list[TargetSpec] = Field(default_factory=list)
    clutter: ClutterSpec = Field(default_factory=ClutterSpec)
    occluders: list[Occluder] = Field(default_factory=list)

    def camera(self, cam_id: str) -> CameraSpec:
        for c in self.cameras:
            if c.id == cam_id:
                return c
        raise KeyError(f"no camera {cam_id!r} in scenario")

    def config_hash(self) -> str:
        blob = json.dumps(self.model_dump(mode="json"), sort_keys=True).encode()
        return hashlib.sha256(blob).hexdigest()[:16]
