"""Procedural backgrounds: visible radiance layers and LWIR apparent-temperature fields.

All layers are generated from the scenario seed. Co-located cameras with the same
boresight and field of view share one layout, so EO and thermal views show the same scene.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import cv2
import numpy as np

from .config import CameraSpec, Environment, Occluder
from .sensors import occluder_corners, project

SKY, GROUND, BUILDING, VEGETATION, SEA, OCC_BUILDING, OCC_TREE = range(7)

# RGB albedo-like base colours per label
BASE_RGB = {
    GROUND: (0.30, 0.36, 0.20), BUILDING: (0.50, 0.48, 0.45), VEGETATION: (0.10, 0.22, 0.08),
    SEA: (0.16, 0.30, 0.42), OCC_BUILDING: (0.42, 0.40, 0.40), OCC_TREE: (0.07, 0.16, 0.06),
}
SKY_RGB = {  # (zenith, horizon) relative radiance
    "sunny": ((0.22, 0.42, 0.80), (0.70, 0.82, 0.95)),
    "backlit": ((0.30, 0.48, 0.80), (0.80, 0.86, 0.92)),
    "overcast": ((0.70, 0.71, 0.73), (0.78, 0.79, 0.80)),
    "dusk": ((0.10, 0.14, 0.30), (0.85, 0.50, 0.25)),
    "night_urban": ((0.25, 0.27, 0.35), (0.55, 0.47, 0.38)),
    "night_moon": ((0.34, 0.38, 0.50), (0.40, 0.42, 0.50)),
    "night_dark": ((0.28, 0.29, 0.34), (0.32, 0.32, 0.36)),
}
FG_LIGHT = {"sunny": 1.0, "backlit": 0.35, "overcast": 0.8, "dusk": 0.5,
            "night_urban": 0.5, "night_moon": 0.45, "night_dark": 0.4}
TARGET_LIGHT = {"sunny": 0.6, "backlit": 0.15, "overcast": 0.7, "dusk": 0.5,
                "night_urban": 0.4, "night_moon": 0.4, "night_dark": 0.4}
SOLAR_HEATING = {"sunny": 9.0, "backlit": 7.0, "overcast": 2.0, "dusk": 1.0,
                 "night_urban": -1.0, "night_moon": -1.5, "night_dark": -1.5}


def fractal_noise(rng, h: int, w: int, octaves: int = 5, base: int = 4, persistence: float = 0.55) -> np.ndarray:
    out = np.zeros((h, w), np.float32)
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        n = base * 2 ** o
        g = rng.random((max(2, int(round(n * h / w))) + 1, n + 1), dtype=np.float32)
        out += amp * cv2.resize(g, (w, h), interpolation=cv2.INTER_CUBIC)
        tot += amp
        amp *= persistence
    out /= tot
    lo, hi = float(out.min()), float(out.max())
    return (out - lo) / max(hi - lo, 1e-6)


@dataclass
class Background:
    width: int
    height: int
    horizon_row: float
    sky: np.ndarray            # HxWx3 BGR relative radiance
    cloud_alpha: np.ndarray    # Hx(W+pad)
    cloud_rad: np.ndarray      # Hx(W+pad) grey radiance of cloud
    fg: np.ndarray             # HxWx3 BGR
    fg_alpha: np.ndarray       # HxW 0/1
    label: np.ndarray          # HxW uint8
    occ_mask: np.ndarray       # HxW float (explicit occluders, in front of targets)
    sky_T: np.ndarray          # HxW kelvin
    cloud_T: float
    fg_T: np.ndarray           # HxW kelvin
    drift_px_s: float
    airlight: np.ndarray       # BGR
    agc: tuple[float, float] = (0.0, 1.0)
    _cache: dict | None = None

    def eo(self, t: float) -> np.ndarray:
        """Scene radiance at time t. Cloud drift is rendered as a linear blend of the two
        nearest whole-pixel cloud positions (composites are cached)."""
        if self.cloud_alpha is None or self.drift_px_s == 0:
            return self._composite(0).copy()
        s = self.drift_px_s * t
        k = int(math.floor(s)); f = np.float32(s - k)
        a, b = self._composite(k), self._composite(k + 1)
        return a + (b - a) * f

    def _composite(self, k: int) -> np.ndarray:
        if self._cache is None:
            self._cache = {}
        if k not in self._cache:
            img = self.sky.copy()
            if self.cloud_alpha is not None:
                kk = min(k, self.cloud_alpha.shape[1] - self.width)
                al = self.cloud_alpha[:, kk:kk + self.width, None]
                img += (self.cloud_rad[:, kk:kk + self.width, None] - img) * al
            m = self.fg_alpha[..., None]
            if len(self._cache) > 6:
                self._cache.pop(min(self._cache))
            self._cache[k] = img * (1 - m) + self.fg * m
        return self._cache[k]

    def thermal(self, t: float) -> np.ndarray:
        T = self.sky_T.copy()
        a, _ = self._cloud(t)
        if a is not None:
            T += (self.cloud_T - T) * a
        return np.where(self.fg_alpha > 0, self.fg_T, T)

    def _cloud(self, t: float):
        if self.cloud_alpha is None:
            return None, None
        s = self.drift_px_s * t
        k = int(math.floor(s)); f = s - k
        W = self.width
        k = min(k, self.cloud_alpha.shape[1] - W - 1)
        a = self.cloud_alpha[:, k:k + W] * (1 - f) + self.cloud_alpha[:, k + 1:k + W + 1] * f
        r = self.cloud_rad[:, k:k + W] * (1 - f) + self.cloud_rad[:, k + 1:k + W + 1] * f
        return a, r


def build_background(env: Environment, cam: CameraSpec, occluders: list[Occluder],
                     seed: int, duration_s: float) -> Background:
    # canonical layout resolution: 640 px wide for this FOV, then resized to the sensor
    W0 = 640
    H0 = int(round(W0 * cam.height / cam.width))
    key = [seed, int(round(cam.az_deg * 10)) % 3600, int(round((cam.el_deg + 90) * 10)), int(round(cam.hfov_deg * 10)), H0]
    rng = np.random.default_rng(key)
    fx0 = (W0 / 2) / math.tan(math.radians(cam.hfov_deg) / 2)
    el = math.radians(cam.el_deg + cam.calib_bias_deg[1])
    rows = np.arange(H0, dtype=np.float32) + 0.5
    el_row = el + np.arctan((H0 / 2 - rows) / fx0)
    horizon = H0 / 2 + fx0 * math.tan(el)
    s = np.clip(np.sin(el_row), 0, 1)[:, None]

    # ---------------- sky radiance
    zen, hor = SKY_RGB[env.lighting]
    zen, hor = np.array(zen[::-1], np.float32), np.array(hor[::-1], np.float32)
    sky = hor[None, None] + (zen - hor)[None, None] * (s ** 0.6)[..., None]
    sky = np.repeat(sky, W0, axis=1).astype(np.float32)
    if env.lighting == "backlit":
        yy, xx = np.mgrid[0:H0, 0:W0].astype(np.float32)
        d2 = (xx - 0.68 * W0) ** 2 + (yy - 0.30 * H0) ** 2
        glare = 2.5 * np.exp(-d2 / (2 * (0.10 * W0) ** 2)) + 0.5 * np.exp(-d2 / (2 * (0.38 * W0) ** 2))
        sky += glare[..., None]

    # ---------------- clouds
    cover = 0.0 if env.background == "clear_sky" else env.cloud_cover
    if env.background == "cloudy":
        cover = max(cover, 0.5)
    if env.lighting == "overcast":
        cover = 1.0
    drift = fx0 * env.wind_mps / 3000.0           # cloud layer assumed ~3 km slant range
    cloud_alpha = cloud_rad = None
    if cover > 0:
        pad = int(drift * duration_s) + 4
        n = fractal_noise(rng, H0, W0 + pad, octaves=5, base=3, persistence=0.45)
        thr = 1.0 - cover
        cloud_alpha = np.clip((n - (thr - 0.12)) / 0.24, 0, 1).astype(np.float32)
        cloud_alpha = cloud_alpha * cloud_alpha * (3 - 2 * cloud_alpha)
        shade = 0.72 + 0.28 * fractal_noise(rng, H0, W0 + pad, octaves=5, base=6)
        bright = {"sunny": 0.95, "backlit": 1.1, "overcast": 0.80, "dusk": 0.45,
                  "night_urban": 0.60, "night_moon": 0.55, "night_dark": 0.33}[env.lighting]
        cloud_rad = (bright * shade).astype(np.float32)

    # ---------------- foreground layout
    label = np.zeros((H0, W0), np.uint8)
    shade = np.ones((H0, W0), np.float32)
    heat = np.ones((H0, W0), np.float32)
    hz = int(np.clip(round(horizon), 0, H0))
    if hz < H0:
        label[hz:] = SEA if env.background == "coastal" else GROUND
        if env.background == "coastal":
            g = rng.random((max(2, (H0 - hz) // 2), 6), dtype=np.float32)
            shade[hz:] = 0.8 + 0.4 * cv2.resize(g, (W0, H0 - hz), interpolation=cv2.INTER_LINEAR)
            heat[hz:] = -0.35
        else:
            shade[hz:] = 0.8 + 0.4 * fractal_noise(rng, H0 - hz, W0, octaves=4, base=8)
            heat[hz:] = 0.6 + 0.4 * fractal_noise(rng, H0 - hz, W0, octaves=3, base=4)
    if env.background == "urban" and hz > 0:
        x = -int(rng.integers(0, 30))
        while x < W0:
            bw = int(rng.integers(30, 90)); bh = int(rng.integers(20, int(0.36 * H0)))
            top = max(0, hz - bh); x0, x1 = max(0, x), min(W0, x + bw)
            if x1 > x0:
                label[top:hz, x0:x1] = BUILDING
                bs = float(rng.uniform(0.5, 1.2))
                if env.lighting == "sunny" and rng.random() < 0.4:
                    bs *= 0.45                               # shadowed face
                blk = np.full((hz - top, x1 - x0), bs, np.float32)
                lit = env.lighting.startswith("night")
                for wy in range(4, hz - top - 3, 8):
                    for wx in range(3, x1 - x0 - 3, 7):
                        blk[wy:wy + 4, wx:wx + 3] = bs * (3.5 if lit and rng.random() < 0.15 else 0.6)
                shade[top:hz, x0:x1] = blk
                heat[top:hz, x0:x1] = float(rng.uniform(0.3, 1.6))
            x += bw + int(rng.integers(-5, 25))
    if env.background == "vegetation" and hz > 0:
        prof = fractal_noise(rng, 1, W0, octaves=5, base=6)[0]
        top = np.clip(hz - (0.05 + 0.22 * prof) * H0, 0, hz).astype(int)
        rr = np.arange(H0)[:, None]
        veg = (rr >= top[None]) & (rr < hz)
        label[veg] = VEGETATION
        tex = 0.6 + 0.8 * fractal_noise(rng, H0, W0, octaves=6, base=24, persistence=0.8)
        shade[veg] = tex[veg]
        heat[veg] = 0.3

    # ---------------- explicit occluders (in front of the targets)
    occ = np.zeros((H0, W0), np.float32)
    cam0 = cam.model_copy(update=dict(width=W0, height=H0))
    for o in occluders:
        uu, vv, z, _ = project(cam0, occluder_corners(o))
        if np.any(z <= 0.5):
            continue
        poly = np.stack([uu, vv], 1).astype(np.int32)
        m = np.zeros((H0, W0), np.uint8)
        if o.kind == "tree":
            x0, x1 = poly[:, 0].min(), poly[:, 0].max(); y1, y0 = poly[:, 1].max(), poly[:, 1].min()
            cxp, wpx, hpx = (x0 + x1) // 2, max(2, x1 - x0), max(2, y1 - y0)
            cv2.ellipse(m, (int(cxp), int(y0 + 0.4 * hpx)), (int(wpx / 2), int(0.4 * hpx)), 0, 0, 360, 1, -1)
            cv2.rectangle(m, (int(cxp - wpx * 0.06), int(y0 + 0.7 * hpx)), (int(cxp + wpx * 0.06), int(y1)), 1, -1)
            lab, hv = OCC_TREE, 0.3
        else:
            cv2.fillConvexPoly(m, poly, 1)
            lab, hv = OCC_BUILDING, 1.0
        sel = m > 0
        label[sel] = lab
        shade[sel] = (0.75 + 0.5 * fractal_noise(rng, H0, W0, octaves=5, base=16))[sel] if lab == OCC_TREE else 0.9
        if lab == OCC_BUILDING:
            ys, xs = np.nonzero(sel)
            win = ((ys // 5) % 3 == 1) & ((xs // 4) % 3 == 1)
            shade[ys[win], xs[win]] = 0.55
        heat[sel] = hv
        occ[sel] = 1.0

    light = FG_LIGHT[env.lighting]
    fg = np.zeros((H0, W0, 3), np.float32)
    for lab, rgb in BASE_RGB.items():
        sel = label == lab
        if sel.any():
            fg[sel] = np.array(rgb[::-1], np.float32)[None] * (shade[sel] * light)[:, None]
    airlight = hor.copy()
    # haze on distant foreground (assumed ~600 m), not on near occluders
    tau_fg = math.exp(-3.912 * 600.0 / env.visibility_m)
    far = (label > 0) & (occ == 0)
    fg[far] = fg[far] * tau_fg + airlight[None] * (1 - tau_fg)

    # ---------------- thermal fields (kelvin)
    T_amb = env.ambient_temp_c + 273.15
    T_zen = env.zenith_sky_temp_c + 273.15
    sky_T = (T_zen + (T_amb - 3.0 - T_zen) * (1 - s) ** 3).astype(np.float32)
    sky_T = np.repeat(sky_T, W0, axis=1)
    heat_k = env.solar_heating_k if env.solar_heating_k is not None else SOLAR_HEATING[env.lighting]
    tex = fractal_noise(rng, H0, W0, octaves=5, base=12)
    fg_T = (T_amb + heat_k * heat + 0.8 * (tex - 0.5)).astype(np.float32)

    def rs(a, interp=cv2.INTER_AREA, wide=False):
        if a is None:
            return None
        w = cam.width if not wide else int(round(a.shape[1] * cam.width / W0))
        if (a.shape[1], a.shape[0]) == (w, cam.height):
            return a
        return cv2.resize(a, (w, cam.height), interpolation=interp)

    scale = cam.width / W0
    bg = Background(
        width=cam.width, height=cam.height, horizon_row=horizon * scale,
        sky=rs(sky), cloud_alpha=rs(cloud_alpha, wide=True), cloud_rad=rs(cloud_rad, wide=True),
        fg=rs(fg), fg_alpha=rs((label > 0).astype(np.float32), cv2.INTER_NEAREST),
        label=rs(label, cv2.INTER_NEAREST), occ_mask=rs(occ, cv2.INTER_NEAREST),
        sky_T=rs(sky_T), cloud_T=T_amb + env.cloud_base_delta_k, fg_T=rs(fg_T),
        drift_px_s=drift * scale, airlight=airlight,
    )
    if bg.cloud_alpha is not None and bg.cloud_alpha.shape[1] < cam.width + 2:
        padw = cam.width + 2 - bg.cloud_alpha.shape[1]
        bg.cloud_alpha = np.pad(bg.cloud_alpha, ((0, 0), (0, padw)), mode="edge")
        bg.cloud_rad = np.pad(bg.cloud_rad, ((0, 0), (0, padw)), mode="edge")
    T0 = bg.thermal(0.0)
    lo, hi = np.percentile(T0[::2, ::2], [0.5, 99.5])
    bg.agc = (float(lo) - 1.5, float(hi) + 1.5)
    return bg
