"""Sensor geometry and measurement models (camera projection, radar, bearing reporters).

ENU world frame: x east, y north, z up. Azimuth is measured clockwise from north.
"""
from __future__ import annotations

import math

import numpy as np

from .config import CameraSpec, Occluder, RadarSpec


def basis(az_deg: float, el_deg: float):
    az, el = math.radians(az_deg), math.radians(el_deg)
    f = np.array([math.sin(az) * math.cos(el), math.cos(az) * math.cos(el), math.sin(el)])
    r = np.array([math.cos(az), -math.sin(az), 0.0])
    u = np.cross(r, f)
    return f, r, u


def project(cam: CameraSpec, pts: np.ndarray, true_boresight: bool = True):
    """World points (N,3) -> (u, v, depth, range). Uses the *true* boresight
    (nominal + calibration bias) when rendering; fusion assumes the nominal one."""
    b = cam.calib_bias_deg if true_boresight else (0.0, 0.0)
    f, r, u = basis(cam.az_deg + b[0], cam.el_deg + b[1])
    rel = np.atleast_2d(pts) - np.asarray(cam.pos)
    z = rel @ f
    zs = np.where(np.abs(z) < 1e-6, 1e-6, z)
    fx = cam.fx
    uu = fx * (rel @ r) / zs + cam.width / 2
    vv = -fx * (rel @ u) / zs + cam.height / 2
    return uu, vv, z, np.linalg.norm(rel, axis=1)


def pixel_to_bearing(cam: CameraSpec, u: float, v: float) -> tuple[float, float]:
    """Image point -> world (azimuth, elevation) in radians using the nominal calibration."""
    f, r, up = basis(cam.az_deg, cam.el_deg)
    d = f + r * ((u - cam.width / 2) / cam.fx) + up * (-(v - cam.height / 2) / cam.fx)
    d /= np.linalg.norm(d)
    return math.atan2(d[0], d[1]), math.asin(d[2])


def bearing_unit(az: float, el: float) -> np.ndarray:
    return np.array([math.sin(az) * math.cos(el), math.cos(az) * math.cos(el), math.sin(el)])


def occluder_corners(o: Occluder) -> np.ndarray:
    az = math.radians(o.az_deg)
    c = np.array([o.range_m * math.sin(az), o.range_m * math.cos(az), 0.0])
    lat = np.array([math.cos(az), -math.sin(az), 0.0])
    a, b = c - lat * o.width_m / 2, c + lat * o.width_m / 2
    top = np.array([0, 0, o.height_m])
    return np.array([a, b, b + top, a + top])


def line_of_sight_blocked(p_from: np.ndarray, p_to: np.ndarray, occluders: list[Occluder]) -> bool:
    d = p_to - p_from
    for o in occluders:
        az = math.radians(o.az_deg)
        n = np.array([math.sin(az), math.cos(az), 0.0])
        c = n * o.range_m
        den = d @ n
        if abs(den) < 1e-9:
            continue
        s = ((c - p_from) @ n) / den
        if not 0.0 < s < 1.0:
            continue
        q = p_from + s * d
        lat = np.array([math.cos(az), -math.sin(az), 0.0])
        if abs((q - c) @ lat) <= o.width_m / 2 and 0 <= q[2] <= o.height_m:
            return True
    return False


def radar_pd(radar: RadarSpec, rcs: float, rng_m: float, radial_speed: float) -> float:
    """Swerling-1 single-scan detection probability: Pd = Pfa^(1/(1+SNR))."""
    snr = 10 ** (radar.snr0_db / 10) * (rcs / radar.rcs0_m2) * (radar.range0_m / max(rng_m, 1.0)) ** 4
    if abs(radial_speed) < radar.min_radial_speed_mps:
        snr *= 0.05                      # inside the clutter-rejection notch
    return float(radar.pfa ** (1.0 / (1.0 + snr)))


def polar_to_enu(pos, r: float, az: float, el: float) -> np.ndarray:
    return np.asarray(pos) + r * bearing_unit(az, el)


def enu_to_polar(pos, p: np.ndarray) -> tuple[float, float, float]:
    rel = np.asarray(p) - np.asarray(pos)
    r = float(np.linalg.norm(rel))
    return r, math.atan2(rel[0], rel[1]), math.asin(max(-1.0, min(1.0, rel[2] / max(r, 1e-9))))
