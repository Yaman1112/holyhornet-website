"""Browser edition: the engine without a server.

On holyhornet.com the Python package runs on Pyodide inside a Web Worker. This module
answers the same HTTP-shaped requests as the FastAPI app (`apps/api`) by calling the same
engine functions, so the web application is identical in both editions.

Differences from the server edition (all stated in the UI):
  - one built-in guest user with the researcher role; no accounts, user management or audit log
  - stored campaign results are read-only; experiments run in the tab live in memory and vanish on reload
  - evaluation studies are precomputed (re-running them in a browser would take hours)
  - dataset import / upload / evaluation is not available
  - the classifier runs through the NumPy backend instead of ONNX Runtime; no process metrics

    request(method, path, body_text, progress) -> (status, content_type, body, filename)
    live_open(params_json) -> json | live_step() -> json or None | live_close()
"""
from __future__ import annotations

import base64
import json
import math
import re
import time
import uuid
from collections import OrderedDict
from datetime import datetime, timezone
from urllib.parse import parse_qs, urlsplit

import cv2

from . import __version__, assistant, datasets, interceptor, paths, store
from .detection.enhance import MODES, Enhancer
from .detection.registry import build_detector, default_threshold, list_models
from .evaluation import campaign, reports
from .evaluation.detection_metrics import evaluate_detection
from .evaluation.tracking_metrics import evaluate_tracking
from .pipeline import PipelineSpec, run_camera
from .sensor_fusion.run import run_fusion
from .simulation.config import ScenarioConfig
from .simulation.scenarios import SCENARIOS, build_scenario
from .simulation.sensors import pixel_to_bearing
from .simulation.world import Simulator
from .status import BOUNDARIES, sensor_inventory
from .tracking.tracker import PRESETS, Tracker

ORG = "holyhornet"
USER = dict(id=0, username="guest", org=ORG, role="researcher", active=1, created="")
ROLES = ("viewer", "analyst", "researcher", "admin")
_T0 = time.time()
_sims: "OrderedDict[str, Simulator]" = OrderedDict()
_jobs: "OrderedDict[str, dict]" = OrderedDict()
_seed_ids: set[str] = set()
_live: dict = {}


class HttpError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status, self.detail = status, detail


def boot() -> dict:
    """Index the experiment payloads shipped with the site. The data directory comes from CUAS_DATA_DIR."""
    n = store.reindex(ORG)
    _seed_ids.update(r["id"] for r in store.list_experiments(ORG))
    return dict(version=__version__, experiments=n, models=[m["name"] for m in list_models()], edition="browser")


def _sim(cfg: ScenarioConfig) -> Simulator:
    k = cfg.config_hash()
    if k not in _sims:
        _sims[k] = Simulator(cfg)
        while len(_sims) > 2:
            _sims.popitem(last=False)
    _sims.move_to_end(k)
    return _sims[k]


def _jpeg(img, q: int = 85):
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, q])
    if not ok:
        raise HttpError(500, "image encoding failed")
    return 200, "image/jpeg", buf.tobytes(), None


def _json(obj, status: int = 200):
    return status, "application/json", store.dumps(obj), None


def _build(scenario: str, seed, params: dict) -> ScenarioConfig:
    if scenario not in SCENARIOS:
        raise HttpError(400, f"unknown scenario {scenario!r}")
    if not isinstance(seed, int) or not 1 <= seed <= 9999:
        raise HttpError(422, "seed must be 1–9999 (10000 and above are reserved for training data)")
    allowed = {p["name"] for p in SCENARIOS[scenario]["params"]} | {"duration_s", "sensors"}
    bad = set(params) - allowed
    if bad:
        raise HttpError(400, f"unknown parameters: {sorted(bad)}")
    try:
        cfg = build_scenario(scenario, seed=seed, **params)
    except Exception as e:                                      # noqa: BLE001
        raise HttpError(400, f"invalid scenario parameters: {e}")
    if cfg.duration_s > 30:
        raise HttpError(400, "duration limited to 30 s")
    return cfg


def _specs(pipes: list[dict]) -> list[PipelineSpec]:
    names = {m["name"] for m in list_models()}
    if not 1 <= len(pipes) <= 4:
        raise HttpError(400, "the browser edition runs 1–4 pipelines per experiment")
    out = []
    for p in pipes:
        det, trk, enh = p.get("detector", "cnn-day"), p.get("tracker", "kalman-gated"), p.get("enhance", "none")
        if det not in names or trk not in PRESETS or enh not in MODES:
            raise HttpError(400, "unknown detector, tracker or enhancement")
        out.append(PipelineSpec(det, trk, enh, p.get("threshold")))
    return out


def _job(kind: str, label: str, work, progress) -> dict:
    jid = uuid.uuid4().hex[:12]
    job = dict(id=jid, org=ORG, user="guest", kind=kind, label=label, status="running", progress=0.0, result_ids=[], error=None,
               created=datetime.now(timezone.utc).isoformat(timespec="seconds"), finished=None)
    _jobs[jid] = job
    try:
        job["result_ids"] = work((lambda p: progress(jid, float(p))) if progress else None)
        job["status"], job["progress"] = "done", 1.0
    except HttpError:
        _jobs.pop(jid, None)
        raise
    except Exception as e:                                      # noqa: BLE001
        job["status"], job["error"] = "failed", f"{type(e).__name__}: {e}"
    job["finished"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    while len(_jobs) > 50:
        _jobs.popitem(last=False)
    return job


def _status() -> dict:
    sensors, live, exps = sensor_inventory(ORG)
    origins: dict = {}
    for r in exps:
        origins[r["origin"]] = origins.get(r["origin"], 0) + 1
    return dict(
        version=__version__, uptime_s=round(time.time() - _T0), user=USER, sensors=sensors, live_adapters=live, edition="browser",
        counts=dict(experiments=len(exps), by_origin=origins, datasets=0, models=len(list_models())),
        system=dict(cpu_percent=None, cpu_count=None, memory_percent=None, memory_used_gb=None, memory_total_gb=None,
                    gpu="not used (the engine runs as WebAssembly in this browser tab)"),
        jobs=dict(active=0), boundaries=BOUNDARIES,
        storage=dict(index="SQLite (in memory, this tab)", payloads="shipped campaign results + runs made in this tab",
                     note="Browser edition: nothing is sent to a server and nothing you run is kept after the tab is reloaded."),
        roles=ROLES)


def _export(text: str, fmt: str, name: str):
    if fmt == "html":
        return 200, "text/html", reports.md_to_html(text), f"{name}.html"
    return 200, "text/markdown; charset=utf-8", text, f"{name}.md"


def _load(eid: str) -> dict:
    e = store.load(eid, ORG)
    if not e:
        raise HttpError(404, "experiment not found")
    return e


def request(method: str, path: str, body_text: str | None = None, progress=None):
    """-> (status, content_type, body str|bytes, download filename or None)"""
    try:
        return _route(method.upper(), path, json.loads(body_text) if body_text else {}, progress)
    except HttpError as e:
        return e.status, "application/json", json.dumps(dict(detail=e.detail)), None
    except Exception as e:                                      # noqa: BLE001
        return 500, "application/json", json.dumps(dict(detail=f"{type(e).__name__}: {e}")), None


def _route(method: str, path: str, body: dict, progress):
    u = urlsplit(path)
    p = u.path.rstrip("/")
    q = {k: v[0] for k, v in parse_qs(u.query).items()}
    G, P = method == "GET", method == "POST"

    if G and p == "/api/health":
        return _json(dict(status="ok", version=__version__, edition="browser"))
    if G and p == "/api/auth/me":
        return _json(USER)
    if G and p == "/api/system/status":
        return _json(_status())
    if p in ("/api/users", "/api/audit") or p.startswith("/api/users/") or p.startswith("/api/auth/"):
        raise HttpError(403, "Accounts, user management and the audit log exist in the server edition only.")

    if G and p == "/api/scenarios":
        out = []
        for k, s in SCENARIOS.items():
            cfg = build_scenario(k)
            out.append(dict(key=k, title=s["title"], description=cfg.description, params=s["params"], default_sensor=s["default_sensor"],
                            sensors=[dict(id=c.id, kind=c.kind) for c in cfg.cameras], radars=[r.id for r in cfg.radars],
                            bearing_sensors=[b.id for b in cfg.bearing_sensors], duration_s=cfg.duration_s, origin="simulated"))
        return _json(dict(scenarios=out, trackers=list(PRESETS), enhancements=list(MODES), studies=list(campaign.STUDIES)))
    if P and p == "/api/scenarios/preview":
        cfg = _build(body.get("scenario", "A"), body.get("seed", 1), body.get("params") or {})
        cam = body.get("sensor") if body.get("sensor") in [c.id for c in cfg.cameras] else cfg.cameras[0].id
        sim = _sim(cfg)
        idx = min(sim.n_frames(cam) - 1, int(float(body.get("t", 2.0)) * cfg.camera(cam).fps))
        return _jpeg(sim.render(cam, idx).image)
    if G and p == "/api/models":
        return _json(list_models())

    if P and p == "/api/experiments":
        key = body.get("scenario", "A")
        cfg = _build(key, body.get("seed", 1), body.get("params") or {})
        specs = _specs(body.get("pipelines") or [{}])
        cams = [c.id for c in cfg.cameras]
        d = SCENARIOS[key]["default_sensor"]
        cam = body.get("sensor") if body.get("sensor") in cams else (d if d in cams else cams[0])
        return _json(_job("pipeline", f"{cfg.name} | {cam}", lambda pr: [
            store.save(r, ORG, "guest", ["user"]) for r in run_camera(cfg, cam, specs, pr, sim=_sim(cfg))], progress))
    if P and p == "/api/experiments/fusion":
        cfg = _build(body.get("scenario", "H"), body.get("seed", 1), body.get("params") or {})
        if not cfg.radars and len(cfg.cameras) < 2:
            raise HttpError(400, "scenario has no radar and fewer than two cameras; fusion needs a ranging source")
        ids = [c.id for c in cfg.cameras] + [r.id for r in cfg.radars] + [b.id for b in cfg.bearing_sensors]
        use = body.get("sensors")
        if use and set(use) - set(ids):
            raise HttpError(400, f"unknown sensors; available: {ids}")
        det = dict(eo_day="cnn-day", eo_lowlight="cnn-lowlight", thermal="cnn-thermal")
        return _json(_job("fusion", f"{cfg.name} | fusion", lambda pr: [
            store.save(run_fusion(cfg, use, det, progress=pr), ORG, "guest", ["user"])], progress))
    if P and p == "/api/experiments/study":
        raise HttpError(501, "Studies are precomputed in the browser edition (a full study takes minutes to hours of CPU). "
                             "Single experiments and fusion runs can be run here.")
    if G and p == "/api/jobs":
        return _json(list(reversed(_jobs.values())))
    m = re.fullmatch(r"/api/jobs/([0-9a-f]+)", p)
    if G and m:
        if m.group(1) not in _jobs:
            raise HttpError(404, "job not found")
        return _json(_jobs[m.group(1)])

    if G and p == "/api/experiments":
        return _json(store.list_experiments(ORG, q.get("kind"), q.get("tag")))
    if G and p == "/api/studies":
        out = {}
        for r in store.list_experiments(ORG, kind="sweep"):
            st = r["summary"].get("study")
            if st and st not in out:
                out[st] = store.load(r["id"], ORG)
        return _json(out)
    m = re.fullmatch(r"/api/experiments/([\w.-]+)/frame/(\d+)", p)
    if G and m:
        e = _load(m.group(1))
        if e.get("origin") != "simulated" or not e.get("config"):
            raise HttpError(404, "no imagery for this experiment")
        cfg = ScenarioConfig.model_validate(e["config"])
        cams = [c.id for c in cfg.cameras]
        cam = q.get("sensor") if q.get("sensor") in cams else (e["sensor"] if e["sensor"] in cams else cams[0])
        sim = _sim(cfg)
        idx = int(m.group(2))
        if not 0 <= idx < sim.n_frames(cam):
            raise HttpError(404, "frame out of range")
        fr = sim.render(cam, idx)
        if fr.image is None:
            raise HttpError(404, "frame was dropped by the sensor")
        return _jpeg(fr.image)
    m = re.fullmatch(r"/api/experiments/([\w.-]+)", p)
    if m and G:
        e = _load(m.group(1))
        if q.get("frames", "0") in ("0", "") and "frames" in e:
            e["n_frames"] = len(e["frames"])
            e.pop("frames")
        return _json(e)
    if m and method == "DELETE":
        if m.group(1) in _seed_ids:
            raise HttpError(403, "Stored campaign results are read-only in the browser edition.")
        if not store.delete(m.group(1), ORG):
            raise HttpError(404, "experiment not found")
        return _json(dict(ok=True))

    m = re.fullmatch(r"/api/reports/experiment/([\w.-]+)", p)
    if G and m:
        e = _load(m.group(1))
        if q.get("format") == "json":
            e.pop("frames", None)
            return _json(e)
        return _export(reports.experiment_report_md(e), q.get("format", "md"), f"experiment-{e['id']}")
    if G and p == "/api/reports/compare":
        want = [i for i in q.get("ids", "").split(",") if i][:12]
        rows = [r for r in store.list_experiments(ORG) if r["id"] in want and r["kind"] == "pipeline"]
        rows.sort(key=lambda r: want.index(r["id"]))
        if not rows:
            raise HttpError(404, "no matching pipeline experiments")
        cmp = reports.comparison(rows)
        if q.get("format", "json") == "json":
            return _json(cmp)
        return _export(reports.comparison_md(cmp), q["format"], "comparison-report")
    if G and p == "/api/reports/validation":
        f = paths.REPORTS / "VALIDATION_REPORT.md"
        if not f.exists():
            raise HttpError(404, "validation report not shipped")
        return _export(f.read_text(encoding="utf-8"), q.get("format", "md"), "validation-report")

    if P and p == "/api/assistant/ask":
        qn = str(body.get("question", "")).strip()
        if not 2 <= len(qn) <= 500:
            raise HttpError(422, "question must be 2–500 characters")
        return _json(assistant.ask(ORG, qn))
    if p == "/api/interceptor" and (G or method == "PUT"):
        st = interceptor.save(ORG, body, "guest") if method == "PUT" else interceptor.load(ORG)
        return _json(dict(state=st, scores=interceptor.score(st), cueing=interceptor.measured_cueing(ORG)))

    if G and p == "/api/datasets":
        return _json(dict(datasets=[], import_root="(server edition only)", candidates=datasets.CANDIDATE_DATASETS))
    if p.startswith("/api/datasets"):
        raise HttpError(501, "Dataset import, annotation and evaluation need the server edition; nothing can be uploaded from this page.")
    raise HttpError(404, f"no such endpoint: {method} {p}")


# ---------------------------------------------------------------- live feed (replaces the WebSocket)
def live_open(params_json: str) -> str:
    first = json.loads(params_json)
    live_close()
    try:
        key = first.get("scenario", "A")
        allowed = {p["name"] for p in SCENARIOS.get(key, {"params": []})["params"]} | {"duration_s"}
        cfg = _build(key, int(first.get("seed", 1)), {k: v for k, v in (first.get("params") or {}).items() if k in allowed})
        cams = [c.id for c in cfg.cameras]
        cam_id = first.get("sensor") if first.get("sensor") in cams else cams[0]
        spec = _specs([dict(detector=first.get("detector", "classical-contrast"), tracker=first.get("tracker", "kalman-gated"),
                            enhance=first.get("enhance", "none"))])[0]
    except HttpError as e:
        return json.dumps(dict(type="error", error=e.detail))
    cam = cfg.camera(cam_id)
    sim = _sim(cfg)
    _live.update(cfg=cfg, cam=cam, sim=sim, i=0, n=sim.n_frames(cam_id), det=build_detector(spec.detector), trk=Tracker(spec.tracker),
                 enh=Enhancer(spec.enhance), frames=[], sent=0, t0=time.perf_counter(), thr=default_threshold(spec.detector))
    env = cfg.environment
    return json.dumps(dict(type="start", origin="simulated", scenario=cfg.name, sensor=cam_id, sensor_kind=cam.kind, frames=_live["n"], fps=cam.fps,
                           width=cam.width, height=cam.height, detector=spec.detector, tracker=spec.tracker, hfov_deg=cam.hfov_deg,
                           az_deg=cam.az_deg, el_deg=cam.el_deg, conditions=dict(
                               background=env.background, lighting=env.lighting, illuminance_lux=env.lux, visibility_m=env.visibility_m,
                               ambient_temp_c=env.ambient_temp_c, wind_mps=env.wind_mps)))


def live_step() -> str | None:
    """Next message of the live feed: a frame, then one 'end' summary, then None."""
    L = _live
    if not L:
        return None
    if L["i"] >= L["n"]:
        frames = L["frames"]
        out = None
        if frames:
            d = evaluate_detection(frames, "uav", L["thr"]); t = evaluate_tracking(frames)
            out = store.dumps(dict(type="end", origin="simulated", frames=len(frames), summary=dict(
                precision=d["precision"], recall=d["recall"], f1=d["f1"], fp_per_frame=d["fp_per_frame"], hota=t["hota"], mota=t["clear"]["mota"],
                idf1=t["idf1"], id_switches=t["clear"]["id_switches"], track_init_s=t["track_initiation_s"]["mean_uav"],
                track_continuity=t["continuity"]["mean_uav"])))
        L.clear()
        return out
    cam, trk = L["cam"], L["trk"]
    fr = L["sim"].render(cam.id, L["i"])
    a = time.perf_counter()
    dets = L["det"].detect(L["enh"](fr.image), fr.t_stamp) if not fr.dropped else []
    b = time.perf_counter()
    tracks = trk.step(dets, fr.t_stamp, fr.idx)
    c = time.perf_counter()
    for tr in tracks:
        az, el = pixel_to_bearing(cam, (tr["x1"] + tr["x2"]) / 2, (tr["y1"] + tr["y2"]) / 2)
        tr["az_deg"], tr["el_deg"] = round(math.degrees(az), 2), round(math.degrees(el), 2)
    rec = dict(idx=fr.idx, t=fr.t, t_stamp=fr.t_stamp, dropped=fr.dropped, gt=fr.gt, dets=[d.to_dict() for d in dets], tracks=tracks)
    L["frames"].append(rec)
    L["i"] += 1
    jpg = None
    if fr.image is not None:
        ok, buf = cv2.imencode(".jpg", fr.image, [cv2.IMWRITE_JPEG_QUALITY, 80])
        jpg = base64.b64encode(buf.tobytes()).decode() if ok else None
    msg = store.dumps(dict(type="frame", origin="simulated", idx=rec["idx"], t=round(rec["t"], 3), dropped=rec["dropped"], jpeg=jpg, dets=rec["dets"],
                           tracks=tracks, truth=[dict(id=g["id"], cls=g["cls"], bbox=g["bbox"], vis=g["vis"]) for g in rec["gt"]],
                           detect_ms=round((b - a) * 1e3, 2), track_ms=round((c - b) * 1e3, 3), lag_ms=0.0, bandwidth_kbps=None,
                           new_events=[e for e in trk.events[-6:] if e["frame"] == rec["idx"]]))
    return msg


def live_close():
    _live.clear()
