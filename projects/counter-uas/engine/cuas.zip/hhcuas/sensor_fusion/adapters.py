"""Sensor adapters: every data source is converted to `Measurement` records.

A new sensor is integrated by writing one adapter that yields measurements with
  - a timestamp in the common time base,
  - the sensor position in the site ENU frame,
  - a measurement vector `z` with covariance `R` in one of three forms:
        kind="radar"    z = [range m, azimuth rad, elevation rad]
        kind="bearing"  z = [azimuth rad, elevation rad]        (calibrated camera)
        kind="az"       z = [azimuth rad]                       (acoustic array, RF direction finding)
  - an `origin` label: simulated | imported_dataset | live_sensor.

Adapters only reformat what the sensor reported. They never invent measurements,
and `truth_id` (present on simulated data) is carried for evaluation only — the
fusion engine never reads it.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from typing import Iterable

import numpy as np

from .. import ORIGIN_IMPORTED, ORIGIN_SIMULATED
from ..simulation.config import BearingSensorSpec, CameraSpec, RadarSpec
from ..simulation.sensors import pixel_to_bearing

CAMERA_OUTPUT = ("confirmed", "tracking", "reacquired")


@dataclass(eq=False)          # identity semantics: instances hold arrays and live in lists
class Measurement:
    t: float
    t_arrival: float
    sensor: str
    kind: str
    z: np.ndarray
    R: np.ndarray
    pos: np.ndarray
    track_ref: int | None = None
    score: float = 1.0
    uav_prob: float | None = None
    cls: str = "unknown"
    origin: str = ORIGIN_SIMULATED
    truth_id: str | None = field(default=None, repr=False)


def camera_measurements(cam: CameraSpec, frames: list[dict], every: int = 3, calib_sigma_deg: float = 0.1,
                        time_offset_s: float = 0.0, origin: str = ORIGIN_SIMULATED) -> list[Measurement]:
    """Image tracks -> bearing measurements using the camera's nominal calibration."""
    out = []
    pos = np.asarray(cam.pos, float)
    for fr in frames:
        if fr.get("dropped") or fr["idx"] % every:
            continue
        for tr in fr["tracks"]:
            if tr["status"] not in CAMERA_OUTPUT:
                continue
            u, v = (tr["x1"] + tr["x2"]) / 2, (tr["y1"] + tr["y2"]) / 2
            az, el = pixel_to_bearing(cam, u, v)
            sig_px = max(1.5, 0.3 * max(tr["x2"] - tr["x1"], tr["y2"] - tr["y1"]))
            sig = math.hypot(sig_px / cam.fx, math.radians(calib_sigma_deg))
            out.append(Measurement(t=fr["t_stamp"] - time_offset_s, t_arrival=fr["t"] + cam.degradation.latency_s, sensor=cam.id,
                                   kind="bearing", z=np.array([az, el]), R=np.eye(2) * sig ** 2, pos=pos, track_ref=tr["id"],
                                   score=tr["conf"], uav_prob=tr.get("uav_prob"), cls=tr.get("cls", "unknown"), origin=origin))
    return out


def radar_measurements(radar: RadarSpec, scans: list[dict], time_offset_s: float = 0.0) -> list[Measurement]:
    out = []
    pos = np.asarray(radar.pos, float)
    R = np.diag([radar.sigma_range_m ** 2, math.radians(radar.sigma_az_deg) ** 2, math.radians(radar.sigma_el_deg) ** 2])
    for sc in scans:
        for p in sc["plots"]:
            out.append(Measurement(t=sc["t_stamp"] - time_offset_s, t_arrival=sc["t"] + radar.degradation.latency_s, sensor=radar.id,
                                   kind="radar", z=np.array([p["r"], p["az"], p["el"]]), R=R, pos=pos,
                                   origin=sc.get("origin", ORIGIN_SIMULATED), truth_id=p.get("truth_id")))
    return out


def az_measurements(sen: BearingSensorSpec, reports: list[dict], time_offset_s: float = 0.0) -> list[Measurement]:
    out = []
    pos = np.asarray(sen.pos, float)
    for rp in reports:
        for p in rp["plots"]:
            out.append(Measurement(t=rp["t_stamp"] - time_offset_s, t_arrival=rp["t"] + sen.degradation.latency_s, sensor=sen.id,
                                   kind="az", z=np.array([p["az"]]), R=np.eye(1) * math.radians(sen.sigma_az_deg) ** 2, pos=pos,
                                   score=0.5, uav_prob=0.8 if sen.kind == "rf" else 0.7,
                                   origin=rp.get("origin", ORIGIN_SIMULATED), truth_id=p.get("truth_id")))
    return out


def external_track_feed(lines: Iterable[str], sensor_pos=(0.0, 0.0, 0.0)) -> list[Measurement]:
    """External tracking feed (JSON lines). Each line:
        {"t": 12.5, "sensor": "radar-x", "range_m": 410.0, "az_deg": 31.2, "el_deg": 6.0,
         "sigma_range_m": 5, "sigma_az_deg": 1, "sigma_el_deg": 2}
    Omit range_m for a bearing-only report; omit el_deg as well for azimuth-only."""
    out = []
    pos = np.asarray(sensor_pos, float)
    for ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        d = json.loads(ln)
        saz = math.radians(d.get("sigma_az_deg", 1.0)); sel = math.radians(d.get("sigma_el_deg", 2.0))
        if "range_m" in d:
            kind, z = "radar", np.array([d["range_m"], math.radians(d["az_deg"]), math.radians(d["el_deg"])])
            R = np.diag([d.get("sigma_range_m", 5.0) ** 2, saz ** 2, sel ** 2])
        elif "el_deg" in d:
            kind, z, R = "bearing", np.array([math.radians(d["az_deg"]), math.radians(d["el_deg"])]), np.diag([saz ** 2, sel ** 2])
        else:
            kind, z, R = "az", np.array([math.radians(d["az_deg"])]), np.eye(1) * saz ** 2
        out.append(Measurement(t=d["t"], t_arrival=d.get("t_arrival", d["t"]), sensor=d.get("sensor", "external"), kind=kind,
                               z=z, R=R, pos=pos, origin=ORIGIN_IMPORTED))
    return out
