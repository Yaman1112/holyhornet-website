"""Measurement-level multi-sensor fusion.

Tracks live in the site ENU frame with a constant-velocity Extended Kalman Filter
(state: position + velocity). Association is global nearest neighbour (Hungarian)
on the gated Mahalanobis innovation, per sensor batch.

What supports range:
  - a radar plot (range + two angles), or
  - two bearings from cameras at different positions (triangulation).
A single camera, or co-located cameras, give direction only. Such tracks are kept
as "bearing-only" and are never assigned a 3-D position.

Implemented: EKF, GNN association, out-of-sequence handling by tolerance, per-sensor
time-offset correction, existence confidence, sensor-disagreement events.
Not implemented (roadmap): UKF, JPDA, MHT.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import linear_sum_assignment

from .adapters import Measurement

GATE = {1: 10.8, 2: 13.8, 3: 16.3}       # chi-square 99.9 %


def wrap(a: float) -> float:
    return (a + math.pi) % (2 * math.pi) - math.pi


def h_meas(x: np.ndarray, m: Measurement) -> np.ndarray:
    rel = x[:3] - m.pos
    r = float(np.linalg.norm(rel))
    az = math.atan2(rel[0], rel[1])
    if m.kind == "az":
        return np.array([az])
    el = math.asin(max(-1.0, min(1.0, rel[2] / max(r, 1e-9))))
    return np.array([az, el]) if m.kind == "bearing" else np.array([r, az, el])


def jacobian(x: np.ndarray, m: Measurement) -> np.ndarray:
    n = {"az": 1, "bearing": 2, "radar": 3}[m.kind]
    J = np.zeros((n, 6))
    for k in range(3):
        d = np.zeros(6); d[k] = 0.05
        diff = h_meas(x + d, m) - h_meas(x - d, m)
        ai = 0 if m.kind != "radar" else 1
        diff[ai] = wrap(diff[ai])
        J[:, k] = diff / 0.1
    return J


def innovation(x: np.ndarray, m: Measurement) -> np.ndarray:
    y = m.z - h_meas(x, m)
    ai = 0 if m.kind != "radar" else 1
    y[ai] = wrap(y[ai])
    return y


@dataclass
class FusionConfig:
    accel_sigma: float = 4.0            # m/s^2
    init_vel_sigma: float = 30.0
    coast_s: float = 3.0
    tentative_coast_s: float = 1.5
    max_oosm_s: float = 0.5             # older out-of-sequence measurements are dropped
    min_baseline_m: float = 20.0
    triang_window_s: float = 0.15
    time_offsets: dict = field(default_factory=dict)


@dataclass(eq=False)
class FusedTrack:
    id: int
    x: np.ndarray
    P: np.ndarray
    t: float
    t_first: float
    source: str
    updates: int = 1
    confirmed: bool = False
    logit: float = -1.0
    last_update: float = 0.0
    sensors: dict = field(default_factory=dict)        # sensor -> last update time
    n_by_sensor: dict = field(default_factory=dict)
    refs: dict = field(default_factory=dict)           # (sensor, track_ref) links
    uav: dict = field(default_factory=dict)            # sensor -> (sum, n)
    disagree: int = 0

    @property
    def conf(self) -> float:
        return 1 / (1 + math.exp(-self.logit))

    @property
    def uav_prob(self):
        v = [s / n for s, n in self.uav.values() if n]
        return float(np.mean(v)) if v else None


WEIGHT = {"radar": 0.8, "bearing": 0.6, "az": 0.3}


class FusionEngine:
    def __init__(self, cfg: FusionConfig | None = None):
        self.cfg = cfg or FusionConfig()
        self.tracks: list[FusedTrack] = []
        self.events: list[dict] = []
        self.snapshots: list[dict] = []
        self.bearing_only: dict = {}       # (sensor, ref) -> dict
        self.pending: list[Measurement] = []
        self.stats = dict(measurements=0, late_dropped=0, out_of_sequence=0, associated=0, unassociated=0)
        self._next = 1
        self._t = 0.0
        self._link: dict = {}              # (sensor, ref) -> fused id

    def _event(self, t, tid, kind, reason, **kw):
        self.events.append(dict(t=round(t, 3), track_id=tid, type=kind, reason=reason, **kw))

    def _predict(self, tr: FusedTrack, t: float):
        dt = t - tr.t
        if dt <= 0:
            return
        F = np.eye(6); F[:3, 3:] = np.eye(3) * dt
        q = self.cfg.accel_sigma ** 2
        Q = np.zeros((6, 6))
        Q[:3, :3] = np.eye(3) * q * dt ** 4 / 4
        Q[:3, 3:] = Q[3:, :3] = np.eye(3) * q * dt ** 3 / 2
        Q[3:, 3:] = np.eye(3) * q * dt ** 2
        tr.x = F @ tr.x; tr.P = F @ tr.P @ F.T + Q; tr.t = t
        tr.logit = max(-4.0, tr.logit - 0.6 * dt)

    def _gate(self, tr: FusedTrack, m: Measurement):
        J = jacobian(tr.x, m)
        S = J @ tr.P @ J.T + m.R
        y = innovation(tr.x, m)
        d2 = float(y @ np.linalg.solve(S, y))
        return d2, J, S, y

    def _update(self, tr: FusedTrack, m: Measurement, J, S, y, t):
        K = tr.P @ J.T @ np.linalg.inv(S)
        tr.x = tr.x + K @ y
        tr.P = (np.eye(6) - K @ J) @ tr.P
        tr.P = (tr.P + tr.P.T) / 2
        tr.updates += 1; tr.last_update = t
        if m.sensor not in tr.sensors:
            self._event(t, tr.id, "sensor_added", f"{m.sensor} ({m.kind}) measurement fell inside the gate; now contributing")
        tr.sensors[m.sensor] = t
        tr.n_by_sensor[m.sensor] = tr.n_by_sensor.get(m.sensor, 0) + 1
        tr.logit = min(6.0, tr.logit + WEIGHT[m.kind] * (m.score if m.kind == "bearing" else 1.0))
        if m.uav_prob is not None:
            s, n = tr.uav.get(m.sensor, (0.0, 0))
            tr.uav[m.sensor] = (s + m.uav_prob, n + 1)
        if m.track_ref is not None:
            self._link[(m.sensor, m.track_ref)] = tr.id
        if not tr.confirmed and tr.updates >= 3 and (len(tr.n_by_sensor) >= 2 or tr.updates >= 4):
            tr.confirmed = True
            self._event(t, tr.id, "confirmed", f"{tr.updates} updates from {', '.join(sorted(tr.n_by_sensor))}")

    def _new_track(self, pos, P_pos, t, source, reason):
        P = np.zeros((6, 6)); P[:3, :3] = P_pos; P[3:, 3:] = np.eye(3) * self.cfg.init_vel_sigma ** 2
        tr = FusedTrack(id=self._next, x=np.concatenate([pos, np.zeros(3)]), P=P, t=t, t_first=t, source=source, last_update=t)
        self._next += 1
        self.tracks.append(tr)
        self._event(t, tr.id, "created", reason)
        return tr

    def _from_radar(self, m: Measurement, t: float):
        r, az, el = m.z
        u = np.array([math.sin(az) * math.cos(el), math.cos(az) * math.cos(el), math.sin(el)])
        e_az = np.array([math.cos(az), -math.sin(az), 0.0])
        e_el = np.cross(e_az, u)
        P = (m.R[0, 0] * np.outer(u, u) + (r * math.cos(el)) ** 2 * m.R[1, 1] * np.outer(e_az, e_az)
             + r ** 2 * m.R[2, 2] * np.outer(e_el, e_el))
        tr = self._new_track(m.pos + r * u, P, t, m.sensor, f"{m.sensor} plot at {r:.0f} m matched no fused track")
        tr.sensors[m.sensor] = t; tr.n_by_sensor[m.sensor] = 1
        return tr

    def _triangulate(self, a: Measurement, b: Measurement):
        def ray(m):
            az, el = m.z
            return np.array([math.sin(az) * math.cos(el), math.cos(az) * math.cos(el), math.sin(el)])
        da, db = ray(a), ray(b)
        w = a.pos - b.pos
        A, B, C = da @ da, da @ db, db @ db
        D, E = da @ w, db @ w
        den = A * C - B * B
        if abs(den) < 1e-6:
            return None
        s = (B * E - C * D) / den; u = (A * E - B * D) / den
        if s <= 5 or u <= 5 or s > 4000 or u > 4000:
            return None
        pa, pb = a.pos + s * da, b.pos + u * db
        miss = float(np.linalg.norm(pa - pb))
        tol = 3.0 + 3 * (s * math.sqrt(a.R[0, 0]) + u * math.sqrt(b.R[0, 0]))
        if miss > tol:
            return None
        sig = max(5.0, tol)
        return (pa + pb) / 2, np.eye(3) * sig ** 2, miss

    # ------------------------------------------------------------ main loop
    def process_batch(self, batch: list[Measurement]):
        cfg = self.cfg
        t = batch[0].t
        self.stats["measurements"] += len(batch)
        if t < self._t - cfg.max_oosm_s:
            self.stats["late_dropped"] += len(batch)
            return
        if t < self._t:
            self.stats["out_of_sequence"] += len(batch)   # applied at the current filter time (documented approximation)
            t = self._t
        self._t = t
        for tr in self.tracks:
            self._predict(tr, t)
        kind = batch[0].kind
        nm, nt = len(batch), len(self.tracks)
        BIG = 1e6
        C = np.full((nt, nm), BIG)
        cache = {}
        for i, tr in enumerate(self.tracks):
            for j, m in enumerate(batch):
                d2, J, S, y = self._gate(tr, m)
                linked = m.track_ref is not None and self._link.get((m.sensor, m.track_ref)) == tr.id
                if d2 <= GATE[len(m.z)]:
                    C[i, j] = d2 - (5.0 if linked else 0.0)
                    cache[(i, j)] = (J, S, y)
                elif linked:
                    tr.disagree += 1
                    if tr.disagree in (1, 10, 50):
                        self._event(t, tr.id, "sensor_disagreement",
                                    f"{m.sensor} track {m.track_ref} was linked to this track but its measurement is now outside the gate "
                                    f"(d²={d2:.1f}); check calibration / time synchronisation")
        used = set()
        if nt and nm:
            r, c = linear_sum_assignment(C)
            for i, j in zip(r, c):
                if C[i, j] < BIG:
                    self._update(self.tracks[i], batch[j], *cache[(i, j)], t)
                    used.add(j)
        self.stats["associated"] += len(used)
        self.stats["unassociated"] += nm - len(used)
        for j, m in enumerate(batch):
            if j in used:
                if m.kind == "bearing":
                    self.bearing_only.pop((m.sensor, m.track_ref), None)
                continue
            if kind == "radar":
                self._from_radar(m, t)
            elif kind == "bearing":
                done = False
                for o in self.pending:
                    if o.sensor == m.sensor or abs(o.t - m.t) > cfg.triang_window_s:
                        continue
                    if np.linalg.norm(o.pos - m.pos) < cfg.min_baseline_m:
                        continue
                    tri = self._triangulate(m, o)
                    if tri:
                        pos, P, miss = tri
                        tr = self._new_track(pos, P, t, f"{m.sensor}+{o.sensor}",
                                             f"bearings from {m.sensor} and {o.sensor} intersect within {miss:.1f} m (triangulation)")
                        for q in (m, o):
                            tr.sensors[q.sensor] = t; tr.n_by_sensor[q.sensor] = 1
                            self._link[(q.sensor, q.track_ref)] = tr.id
                            self.bearing_only.pop((q.sensor, q.track_ref), None)
                        self.pending.remove(o)
                        done = True
                        break
                if not done:
                    self.pending.append(m)
                    self.bearing_only[(m.sensor, m.track_ref)] = dict(
                        sensor=m.sensor, ref=m.track_ref, t=t, az=float(m.z[0]), el=float(m.z[1]), pos=m.pos.tolist(),
                        conf=m.score, cls=m.cls, uav_prob=m.uav_prob, origin=m.origin)
        self.pending = [o for o in self.pending if t - o.t <= cfg.triang_window_s]
        self.bearing_only = {k: v for k, v in self.bearing_only.items() if t - v["t"] <= 0.5}
        keep = []
        for tr in self.tracks:
            lim = cfg.coast_s if tr.confirmed else cfg.tentative_coast_s
            if t - tr.last_update > lim:
                self._event(t, tr.id, "terminated", f"no associated measurement for {t - tr.last_update:.1f} s")
            else:
                keep.append(tr)
        self.tracks = keep

    def snapshot(self, t: float):
        tracks = []
        for tr in self.tracks:
            dt = max(0.0, t - tr.t)
            pos = tr.x[:3] + tr.x[3:] * dt
            live = [s for s, ts in tr.sensors.items() if t - ts <= 1.0]
            tracks.append(dict(
                id=tr.id, pos=[round(float(v), 2) for v in pos], vel=[round(float(v), 2) for v in tr.x[3:]],
                sigma_m=round(float(math.sqrt(max(np.trace(tr.P[:3, :3]), 0) / 3)), 2), conf=round(tr.conf, 3),
                status="confirmed" if tr.confirmed else "tentative", coasting=t - tr.last_update > 0.6,
                sensors=sorted(live), all_sensors=sorted(tr.n_by_sensor), uav_prob=tr.uav_prob,
                range_m=round(float(np.linalg.norm(pos)), 1), range_supported=True))
        self.snapshots.append(dict(t=round(t, 3), tracks=tracks, bearing_only=list(self.bearing_only.values())))

    def run(self, measurements: list[Measurement], duration_s: float, snapshot_hz: float = 10.0):
        ms = sorted(measurements, key=lambda m: (m.t_arrival, m.sensor))
        batches: list[list[Measurement]] = []
        for m in ms:
            if batches and batches[-1][0].sensor == m.sensor and abs(batches[-1][0].t - m.t) < 1e-9:
                batches[-1].append(m)
            else:
                batches.append([m])
        k = 0
        n_snap = int(duration_s * snapshot_hz)
        for i in range(1, n_snap + 1):
            ts = i / snapshot_hz
            while k < len(batches) and batches[k][0].t_arrival <= ts:
                self.process_batch(batches[k]); k += 1
            self.snapshot(ts)
        return self
