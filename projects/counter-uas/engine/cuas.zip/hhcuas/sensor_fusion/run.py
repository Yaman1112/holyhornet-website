"""Run a fusion experiment on a scenario and score it against simulation truth."""
from __future__ import annotations

from collections import Counter, defaultdict

import numpy as np
from scipy.optimize import linear_sum_assignment

from .. import ORIGIN_SIMULATED, UAV_CLASSES, __version__
from ..pipeline import PipelineSpec, run_camera
from ..simulation.config import ScenarioConfig
from ..simulation.world import Simulator
from .adapters import az_measurements, camera_measurements, radar_measurements
from .engine import FusionConfig, FusionEngine

DEFAULT_DETECTOR = {"eo_day": "cnn-day", "eo_lowlight": "cnn-lowlight", "thermal": "cnn-thermal"}


def evaluate_fusion(sim: Simulator, snapshots: list[dict]) -> dict:
    last: dict[str, int] = {}
    hit, alive = Counter(), Counter()
    err, verr = defaultdict(list), defaultdict(list)
    first_alive, first_hit = {}, {}
    idsw = 0
    tr_frames, tr_matched = Counter(), Counter()
    cls_of = {}
    for snap in snapshots:
        t = snap["t"]
        truth = sim.truth(t)
        trs = [x for x in snap["tracks"] if x["status"] == "confirmed"]
        for x in trs:
            tr_frames[x["id"]] += 1
        for o in truth:
            alive[o["id"]] += 1; first_alive.setdefault(o["id"], t); cls_of[o["id"]] = o["cls"]
        if not truth or not trs:
            continue
        D = np.array([[np.linalg.norm(np.array(o["pos"]) - np.array(x["pos"])) for x in trs] for o in truth])
        gate = np.array([max(25.0, 0.1 * np.linalg.norm(o["pos"])) for o in truth])
        C = np.where(D <= gate[:, None], D, 1e6)
        r, c = linear_sum_assignment(C)
        for i, j in zip(r, c):
            if C[i, j] >= 1e6:
                continue
            gid, tid = truth[i]["id"], trs[j]["id"]
            if gid in last and last[gid] != tid:
                idsw += 1
            last[gid] = tid
            hit[gid] += 1; first_hit.setdefault(gid, t); tr_matched[tid] += 1
            err[gid].append(D[i, j])
            verr[gid].append(np.linalg.norm(np.array(truth[i]["vel"]) - np.array(trs[j]["vel"])))
    per = {}
    for gid in alive:
        e = np.array(err[gid]) if err[gid] else None
        per[gid] = dict(cls=cls_of[gid], coverage=hit[gid] / alive[gid],
                        position_rmse_m=float(np.sqrt(np.mean(e ** 2))) if e is not None else None,
                        velocity_rmse_mps=float(np.sqrt(np.mean(np.square(verr[gid])))) if verr[gid] else None,
                        initiation_s=(first_hit[gid] - first_alive[gid]) if gid in first_hit else None)
    uav = [v for g, v in per.items() if v["cls"] in UAV_CLASSES]
    rm = [v["position_rmse_m"] for v in uav if v["position_rmse_m"] is not None]
    ini = [v["initiation_s"] for v in uav if v["initiation_s"] is not None]
    false_tracks = [tid for tid, n in tr_frames.items() if tr_matched[tid] < 0.5 * n]
    return dict(
        per_target=per, uav_coverage=float(np.mean([v["coverage"] for v in uav])) if uav else None,
        uav_position_rmse_m=float(np.mean(rm)) if rm else None,
        uav_initiation_s=float(np.mean(ini)) if ini else None, uav_never_tracked=[g for g, v in per.items() if v["cls"] in UAV_CLASSES and v["initiation_s"] is None],
        id_switches=idsw, confirmed_tracks=len(tr_frames), false_tracks=len(false_tracks),
        note="Fused 3-D tracks matched to simulation truth within max(25 m, 10 % of range). Coverage = share of the target's lifetime with a confirmed fused track.")


def run_fusion(cfg: ScenarioConfig, sensors: list[str] | None = None, detectors: dict | None = None,
               tracker: str = "kalman-gated", fusion_cfg: FusionConfig | None = None, progress=None,
               camera_results: dict | None = None) -> dict:
    """sensors: ids to include (default: all in the scenario)."""
    sim = Simulator(cfg)
    all_ids = [c.id for c in cfg.cameras] + [r.id for r in cfg.radars] + [b.id for b in cfg.bearing_sensors]
    use = sensors or all_ids
    fusion_cfg = fusion_cfg or FusionConfig()
    det = dict(DEFAULT_DETECTOR); det.update(detectors or {})
    ms, per_sensor = [], {}
    cams = [c for c in cfg.cameras if c.id in use]
    for k, cam in enumerate(cams):
        if camera_results and cam.id in camera_results:
            res = camera_results[cam.id]
        else:
            res = run_camera(cfg, cam.id, [PipelineSpec(det[cam.kind], tracker)], sim=sim,
                             progress=(lambda p, k=k: progress((k + p) / max(len(cams), 1) * 0.9)) if progress else None)[0]
            if camera_results is not None:
                camera_results[cam.id] = res
        m = camera_measurements(cam, res["frames"], time_offset_s=fusion_cfg.time_offsets.get(cam.id, 0.0))
        ms += m
        d = res["metrics"]["detection"]["uav"]
        per_sensor[cam.id] = dict(kind=cam.kind, detector=res["detector"], measurements=len(m), recall=d["recall"], precision=d["precision"],
                                  f1=d["f1"], fp_per_frame=d["fp_per_frame"], provides="bearing (azimuth, elevation); no range")
    for r in cfg.radars:
        if r.id in use:
            scans = sim.radar_scans(r.id)
            m = radar_measurements(r, scans, fusion_cfg.time_offsets.get(r.id, 0.0))
            ms += m
            uav_ids = {t.id for t in sim.targets if t.cls in UAV_CLASSES}
            opp = sum(1 for s in scans for t in sim.targets if t.cls in UAV_CLASSES and t.t_start <= s["t"] <= (t.t_end or cfg.duration_s))
            got = sum(1 for x in m if x.truth_id in uav_ids)
            per_sensor[r.id] = dict(kind="radar", measurements=len(m), recall=got / opp if opp else None,
                                    false_plots=sum(1 for x in m if x.truth_id is None), scans=len(scans),
                                    provides="range, azimuth, elevation; no classification")
    for b in cfg.bearing_sensors:
        if b.id in use:
            m = az_measurements(b, sim.bearing_reports(b.id), fusion_cfg.time_offsets.get(b.id, 0.0))
            ms += m
            per_sensor[b.id] = dict(kind=b.kind, measurements=len(m), provides="azimuth only; supports confidence, not position")
    eng = FusionEngine(fusion_cfg).run(ms, cfg.duration_s)
    if progress:
        progress(1.0)
    truth_tl = [dict(t=s["t"], objects=sim.truth(s["t"])) for s in eng.snapshots[::2]]
    return dict(
        origin=ORIGIN_SIMULATED, kind="fusion", name=f"{cfg.name} | fusion [{', '.join(use)}]", scenario=cfg.scenario,
        scenario_name=cfg.name, seed=cfg.seed, config=cfg.model_dump(mode="json"), config_hash=cfg.config_hash(),
        sensor="+".join(use), sensor_kind="fusion", sensors=use, detector="/".join(sorted({v.get("detector", "-") for v in per_sensor.values() if "detector" in v})) or "-",
        tracker=tracker, enhance="none", software=dict(hhcuas=__version__),
        conditions=dict(background=cfg.environment.background, lighting=cfg.environment.lighting, illuminance_lux=cfg.environment.lux,
                        visibility_m=cfg.environment.visibility_m, sensor_kind="fusion"),
        metrics=dict(fusion=evaluate_fusion(sim, eng.snapshots), per_sensor=per_sensor, engine=eng.stats),
        snapshots=eng.snapshots, events=eng.events, truth=truth_tl,
        site=dict(cameras=[c.model_dump(mode="json") for c in cfg.cameras], radars=[r.model_dump(mode="json") for r in cfg.radars],
                  bearing_sensors=[b.model_dump(mode="json") for b in cfg.bearing_sensors],
                  occluders=[o.model_dump(mode="json") for o in cfg.occluders]),
    )
