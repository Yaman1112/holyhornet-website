"""Train the patch classifier on SIMULATED data and export it to ONNX.

    python -m hhcuas.detection.train --model cnn-day --modalities eo
    python -m hhcuas.detection.train --all

Training scenes use seeds 10000+, validation scenes 20000+ (see scenarios.py);
the evaluation campaign uses seeds < 1000, so no evaluation frame is ever trained on.
The model card records exactly what was used. No real imagery is involved: the
sim-to-real gap is NOT assessed by anything in this file.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from datetime import datetime, timezone

import numpy as np

from .. import CNN_CLASSES, __version__, paths
from ..evaluation.matching import match_point
from ..simulation.scenarios import random_training_scenario
from ..simulation.world import Simulator
from .base import to_gray
from .classical import ContrastDetector
from .cnn import PROPOSAL_Z, extract_patches

PRESETS = {
    "cnn-day": ["eo"],
    "cnn-lowlight": ["lowlight"],
    "cnn-thermal": ["thermal"],
    "cnn-multi": ["eo", "lowlight", "thermal"],
}
CLS_IDX = {c: i for i, c in enumerate(CNN_CLASSES)}


def build_patches(modalities: list[str], seed0: int, n_scenes: int, frame_step: int = 6, log=print):
    X, y, meta = [], [], dict(frames=0, scenes=0)
    prop = ContrastDetector(z_thr=PROPOSAL_Z)
    rng = np.random.default_rng(seed0)
    for m in modalities:
        for k in range(n_scenes):
            sim = Simulator(random_training_scenario(seed0 + k, m))
            cam = sim.cfg.cameras[0].id
            meta["scenes"] += 1
            for idx in range(2, sim.n_frames(cam), frame_step):
                f = sim.render(cam, idx)
                g = to_gray(f.image)
                meta["frames"] += 1
                boxes, labels, used = [], [], set()
                for d in prop.detect(g):
                    hit = None
                    for j, o in enumerate(f.gt):
                        if o["vis"] >= 0.3 and match_point(d, o):
                            hit = j
                            break
                    if hit is None:
                        boxes.append((d.x1, d.y1, d.x2, d.y2)); labels.append(CLS_IDX["clutter"])
                    else:
                        used.add(hit)
                        c = f.gt[hit]["cls"]
                        boxes.append((d.x1, d.y1, d.x2, d.y2)); labels.append(CLS_IDX.get(c, CLS_IDX["clutter"]))
                # visible objects the proposer missed: add jittered ground-truth patches
                for j, o in enumerate(f.gt):
                    if j in used or o["vis"] < 0.5 or o["snr"] < 3 or o["cls"] == "insect":
                        continue
                    x1, y1, x2, y2 = o["bbox"]
                    jx, jy = rng.uniform(-1.5, 1.5, 2)
                    boxes.append((x1 + jx, y1 + jy, x2 + jx, y2 + jy)); labels.append(CLS_IDX[o["cls"]])
                lab = np.array(labels)
                keep = np.ones(len(lab), bool)
                clut = np.nonzero(lab == CLS_IDX["clutter"])[0]
                cap = max(6, 3 * int((lab != CLS_IDX["clutter"]).sum()))
                if len(clut) > cap:
                    keep[rng.choice(clut, len(clut) - cap, replace=False)] = False
                if keep.any():
                    bb = [b for b, k_ in zip(boxes, keep) if k_]
                    X.append(extract_patches(g, bb)); y.append(lab[keep])
            if (k + 1) % 25 == 0:
                log(f"  [{m}] {k + 1}/{n_scenes} scenes, {sum(len(a) for a in y)} patches")
    return np.concatenate(X), np.concatenate(y), meta


def make_net():
    import torch.nn as nn

    def block(i, o):
        return nn.Sequential(nn.Conv2d(i, o, 3, padding=1), nn.BatchNorm2d(o), nn.ReLU(inplace=True),
                             nn.Conv2d(o, o, 3, padding=1), nn.BatchNorm2d(o), nn.ReLU(inplace=True), nn.MaxPool2d(2))
    return nn.Sequential(block(2, 24), block(24, 48), block(48, 96), nn.AdaptiveAvgPool2d(1), nn.Flatten(),
                         nn.Dropout(0.2), nn.Linear(96, len(CNN_CLASSES)))


def train(model: str, modalities: list[str], n_train: int = 140, n_val: int = 40, epochs: int = 12,
          seed: int = 0, log=print) -> dict:
    import torch
    import torch.nn.functional as F

    t0 = time.time()
    torch.manual_seed(seed)
    log(f"[{model}] building training patches ({modalities})")
    Xt, yt, mt = build_patches(modalities, 10000, n_train, log=log)
    log(f"[{model}] building validation patches")
    Xv, yv, mv = build_patches(modalities, 20000, n_val, log=log)
    counts = np.bincount(yt, minlength=len(CNN_CLASSES))
    w = torch.tensor((counts.sum() / (len(CNN_CLASSES) * np.maximum(counts, 1))) ** 0.5, dtype=torch.float32)
    net = make_net()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-4)
    steps = epochs * (len(Xt) // 256 + 1)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=4e-3, total_steps=steps)
    Xt_t, yt_t = torch.from_numpy(Xt), torch.from_numpy(yt).long()
    Xv_t = torch.from_numpy(Xv)
    g = torch.Generator().manual_seed(seed)
    history = []
    for ep in range(epochs):
        net.train()
        perm = torch.randperm(len(Xt_t), generator=g)
        tot = 0.0
        for i in range(0, len(perm), 256):
            b = perm[i:i + 256]
            xb = Xt_t[b]
            flip = torch.rand(len(b), generator=g) < 0.5
            xb = torch.where(flip[:, None, None, None], xb.flip(3), xb)
            loss = F.cross_entropy(net(xb), yt_t[b], weight=w, label_smoothing=0.05)
            opt.zero_grad(); loss.backward(); opt.step(); sched.step()
            tot += float(loss) * len(b)
        net.eval()
        with torch.no_grad():
            pv = torch.cat([net(Xv_t[i:i + 2048]) for i in range(0, len(Xv_t), 2048)]).argmax(1).numpy()
        acc = float((pv == yv).mean())
        history.append(dict(epoch=ep + 1, train_loss=tot / len(perm), val_acc=acc))
        log(f"[{model}] epoch {ep + 1}/{epochs} loss {tot / len(perm):.4f} val_acc {acc:.4f}")
    conf = np.zeros((len(CNN_CLASSES), len(CNN_CLASSES)), int)
    for a, b in zip(yv, pv):
        conf[a, b] += 1
    out = paths.MODELS / model
    out.mkdir(parents=True, exist_ok=True)
    net.eval()
    torch.onnx.export(net, torch.zeros(1, 2, 32, 32), str(out / "model.onnx"), input_names=["patch"],
                      output_names=["logits"], dynamic_axes={"patch": {0: "n"}, "logits": {0: "n"}},
                      opset_version=17, dynamo=False)
    torch.save(net.state_dict(), out / "model.pt")
    sha = hashlib.sha256((out / "model.onnx").read_bytes()).hexdigest()
    card = dict(
        name=model, version=datetime.now(timezone.utc).strftime("%Y%m%d.%H%M"), architecture="patch-cnn-3block (2x32x32 -> 5 classes)",
        classes=list(CNN_CLASSES), modalities=modalities, data_origin="simulated",
        training=dict(seeds="10000..%d" % (10000 + n_train - 1), scenes=mt["scenes"], frames=mt["frames"], patches=int(len(Xt)),
                      class_counts={c: int(n) for c, n in zip(CNN_CLASSES, counts)}, epochs=epochs, optimizer="AdamW/OneCycle",
                      batch=256, augmentation="horizontal flip", proposal_z=PROPOSAL_Z, torch_seed=seed),
        validation=dict(seeds="20000..%d" % (20000 + n_val - 1), scenes=mv["scenes"], frames=mv["frames"], patches=int(len(Xv)),
                        patch_accuracy=history[-1]["val_acc"], confusion=conf.tolist(),
                        note="Patch-level accuracy on simulated validation scenes; not a detection metric and not a field result."),
        history=history, sha256=sha, software=dict(hhcuas=__version__, torch=torch.__version__),
        created_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"), train_seconds=round(time.time() - t0, 1),
        limitations="Trained only on procedurally simulated imagery. Performance on real sensors is unknown.",
    )
    (out / "card.json").write_text(json.dumps(card, indent=2))
    log(f"[{model}] saved {out} ({card['train_seconds']} s)")
    return card


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="cnn-day")
    ap.add_argument("--modalities", nargs="*")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--scenes", type=int, default=140)
    ap.add_argument("--epochs", type=int, default=12)
    a = ap.parse_args()
    todo = PRESETS if a.all else {a.model: a.modalities or PRESETS[a.model]}
    for name, mods in todo.items():
        n = a.scenes if len(mods) == 1 else max(60, a.scenes * 2 // 3)
        train(name, mods, n_train=n, epochs=a.epochs)


if __name__ == "__main__":
    main()
