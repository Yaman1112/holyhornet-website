"""Pure-NumPy forward pass of the patch classifier.

Used where ONNX Runtime is not available (the browser edition on Pyodide). Weights come
from `model.npz`, written by tools/export_npz.py with batch-norm folded into the convolutions.
Numerically equivalent to the ONNX model (checked in tests) but slower.
"""
from __future__ import annotations

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view


class NumpyNet:
    def __init__(self, path):
        z = np.load(path)
        self.convs = [(z[f"w{i}"], z[f"b{i}"]) for i in range(6)]      # w: (9*C_in, C_out), b: (C_out,)
        self.fc_w, self.fc_b = z["fc_w"], z["fc_b"]                   # (96, n_classes)

    @staticmethod
    def _conv(x: np.ndarray, w: np.ndarray, b: np.ndarray) -> np.ndarray:
        n, h, wd, c = x.shape
        xp = np.pad(x, ((0, 0), (1, 1), (1, 1), (0, 0)))
        win = sliding_window_view(xp, (3, 3), axis=(1, 2))            # (n, h, w, c, 3, 3)
        y = win.reshape(n * h * wd, c * 9) @ w + b
        return np.maximum(y, 0, out=y).reshape(n, h, wd, -1)

    def __call__(self, patches: np.ndarray) -> np.ndarray:
        """patches (N, 2, 32, 32) float32 -> logits (N, n_classes)."""
        out = []
        for k in range(0, len(patches), 16):                          # small batches bound memory
            x = np.ascontiguousarray(patches[k:k + 16].transpose(0, 2, 3, 1), dtype=np.float32)
            for i, (w, b) in enumerate(self.convs):
                x = self._conv(x, w, b)
                if i % 2 == 1:
                    n, h, wd, c = x.shape
                    x = x.reshape(n, h // 2, 2, wd // 2, 2, c).max(axis=(2, 4))
            out.append(x.mean(axis=(1, 2)) @ self.fc_w + self.fc_b)
        return np.concatenate(out) if out else np.zeros((0, len(self.fc_b)), np.float32)
