"""Low-light image enhancement used as optional pre-processing.

none      pass-through
clahe     contrast-limited adaptive histogram equalisation
denoise   temporal recursive filter (static camera) + spatial Gaussian
denoise+clahe
Temporal filtering trades noise for smear on moving targets; the low-light
evaluation measures that trade instead of assuming it helps.
"""
from __future__ import annotations

import cv2
import numpy as np

from .base import to_gray

MODES = ("none", "clahe", "denoise", "denoise+clahe")


class Enhancer:
    def __init__(self, mode: str = "none", temporal_alpha: float = 0.45):
        if mode not in MODES:
            raise ValueError(f"unknown enhancement mode {mode!r}")
        self.mode = mode
        self.alpha = temporal_alpha
        self._acc = None
        self._clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))

    def reset(self):
        self._acc = None

    def __call__(self, image: np.ndarray) -> np.ndarray:
        if self.mode == "none":
            return image
        g = to_gray(image)
        if "denoise" in self.mode:
            if self._acc is None or self._acc.shape != g.shape:
                self._acc = g.copy()
            else:
                self._acc += self.alpha * (g - self._acc)
            g = cv2.GaussianBlur(self._acc, (0, 0), 0.7)
        out = np.clip(g, 0, 255).astype(np.uint8)
        if "clahe" in self.mode:
            out = self._clahe.apply(out)
        return out
