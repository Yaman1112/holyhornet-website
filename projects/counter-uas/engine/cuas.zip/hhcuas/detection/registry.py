"""Detector registry: one place that knows which detection models exist."""
from __future__ import annotations

import json

from .. import paths
from .base import Detector
from .classical import ContrastDetector, MotionDetector

CLASSICAL = {
    "classical-contrast": dict(kind="classical", classifies=False, default_threshold=0.0,
                               description="Single-frame CFAR on a difference-of-Gaussians response. No learning, no classification."),
    "classical-motion": dict(kind="classical", classifies=False, default_threshold=0.0,
                             description="Running-average background subtraction. Static camera only; hovering targets fade out."),
}


def list_models() -> list[dict]:
    out = [dict(name=k, trained=True, **v) for k, v in CLASSICAL.items()]
    for d in sorted(paths.MODELS.glob("*/card.json")):
        card = json.loads(d.read_text())
        out.append(dict(name=card["name"], kind="cnn", classifies=True, default_threshold=0.5, trained=True,
                        description=f"Proposal + patch-CNN classifier trained on simulated {'/'.join(card['modalities'])} imagery.",
                        card=card))
    return out


def default_threshold(name: str) -> float:
    return CLASSICAL[name]["default_threshold"] if name in CLASSICAL else 0.5


def build_detector(name: str, **kw) -> Detector:
    if name == "classical-contrast":
        return ContrastDetector(**kw)
    if name == "classical-motion":
        return MotionDetector(**kw)
    if name.startswith("yolo-onnx:"):
        from .yolo_onnx import YoloOnnxDetector
        return YoloOnnxDetector(name.split(":", 1)[1], **kw)
    from .cnn import PatchCNNDetector
    return PatchCNNDetector(name, **kw)
