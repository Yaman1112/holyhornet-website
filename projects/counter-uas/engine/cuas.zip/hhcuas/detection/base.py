"""Detector interface. Every detector — classical, CNN or an external ONNX model —
implements `detect(image, t)` and returns a list of `Detection`."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

import cv2
import numpy as np


@dataclass
class Detection:
    x1: float
    y1: float
    x2: float
    y2: float
    score: float                 # objectness: "an aerial object is here"
    cls: str = "unknown"         # one of hhcuas.DETECTION_LABELS
    uav_score: float | None = None   # P(object is a UAV); None -> detector cannot classify
    probs: dict | None = None
    peak: float = 0.0            # detector-specific raw response (z-score)

    @property
    def cx(self) -> float:
        return (self.x1 + self.x2) / 2

    @property
    def cy(self) -> float:
        return (self.y1 + self.y2) / 2

    @property
    def w(self) -> float:
        return self.x2 - self.x1

    @property
    def h(self) -> float:
        return self.y2 - self.y1

    @property
    def rank_uav(self) -> float:
        return self.score if self.uav_score is None else self.uav_score

    def to_dict(self) -> dict:
        d = asdict(self)
        for k in ("x1", "y1", "x2", "y2"):
            d[k] = round(d[k], 1)
        d["score"] = round(self.score, 4)
        d["peak"] = round(self.peak, 2)
        if self.uav_score is not None:
            d["uav_score"] = round(self.uav_score, 4)
        if self.probs:
            d["probs"] = {k: round(v, 3) for k, v in self.probs.items()}
        return d


def to_gray(img: np.ndarray) -> np.ndarray:
    if img.ndim == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return img.astype(np.float32)


def size_label(w: float, h: float) -> str:
    return "small_aerial_object" if max(w, h) < 24 else "large_aerial_object"


@dataclass
class Detector:
    name: str = "detector"
    info: dict = field(default_factory=dict)

    def reset(self) -> None:
        pass

    def detect(self, image: np.ndarray, t: float = 0.0) -> list[Detection]:
        raise NotImplementedError


def nms(dets: list[Detection], iou_thr: float = 0.3) -> list[Detection]:
    dets = sorted(dets, key=lambda d: -d.peak)
    keep: list[Detection] = []
    for d in dets:
        ok = True
        for k in keep:
            ix = max(0.0, min(d.x2, k.x2) - max(d.x1, k.x1)); iy = max(0.0, min(d.y2, k.y2) - max(d.y1, k.y1))
            inter = ix * iy
            if inter > 0 and (inter / (d.w * d.h + k.w * k.h - inter) > iou_thr or
                              (k.x1 <= d.cx <= k.x2 and k.y1 <= d.cy <= k.y2)):
                ok = False
                break
        if ok:
            keep.append(d)
    return keep
