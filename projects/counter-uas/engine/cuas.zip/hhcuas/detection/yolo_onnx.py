"""Adapter for externally trained YOLO-family detectors exported to ONNX
(Ultralytics v8/v11 layout: output [1, 4+nc, N], boxes as cx,cy,w,h in input pixels).

No YOLO weights ship with this repository. The decode/NMS path is unit-tested on
synthetic tensors; end-to-end accuracy with a real model has NOT been measured here.
Use:  build_detector("yolo-onnx:/path/to/model.onnx", class_map={0: "multirotor", ...})
"""
from __future__ import annotations

import cv2
import numpy as np

from .. import UAV_CLASSES
from .base import Detection, Detector


def letterbox(img: np.ndarray, size: int):
    h, w = img.shape[:2]
    r = min(size / h, size / w)
    nh, nw = int(round(h * r)), int(round(w * r))
    canvas = np.full((size, size, 3), 114, np.uint8)
    top, left = (size - nh) // 2, (size - nw) // 2
    canvas[top:top + nh, left:left + nw] = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
    return canvas, r, left, top


def decode(out: np.ndarray, r: float, left: int, top: int, class_map: dict[int, str],
           conf_thr: float = 0.1, iou_thr: float = 0.5) -> list[Detection]:
    p = out[0].T if out.ndim == 3 else out.T          # (N, 4+nc)
    scores = p[:, 4:]
    cls = scores.argmax(1)
    conf = scores.max(1)
    keep = conf >= conf_thr
    p, cls, conf, scores = p[keep], cls[keep], conf[keep], scores[keep]
    if not len(p):
        return []
    x1 = (p[:, 0] - p[:, 2] / 2 - left) / r; y1 = (p[:, 1] - p[:, 3] / 2 - top) / r
    w = p[:, 2] / r; h = p[:, 3] / r
    idx = cv2.dnn.NMSBoxes(np.stack([x1, y1, w, h], 1).tolist(), conf.tolist(), conf_thr, iou_thr)
    dets = []
    for i in np.array(idx).reshape(-1):
        name = class_map.get(int(cls[i]), "unknown")
        uav = float(sum(scores[i, k] for k, n in class_map.items() if n in UAV_CLASSES and k < scores.shape[1]))
        dets.append(Detection(x1=float(x1[i]), y1=float(y1[i]), x2=float(x1[i] + w[i]), y2=float(y1[i] + h[i]),
                              score=float(conf[i]), cls=name, uav_score=min(1.0, uav), peak=float(conf[i])))
    return dets


class YoloOnnxDetector(Detector):
    def __init__(self, model_path: str, class_map: dict[int, str] | None = None, size: int = 640, conf_thr: float = 0.1):
        import onnxruntime as ort
        super().__init__(name=f"yolo-onnx:{model_path}")
        self.session = ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
        self.input = self.session.get_inputs()[0].name
        self.class_map = class_map or {0: "multirotor"}
        self.size, self.conf_thr = size, conf_thr

    def detect(self, image: np.ndarray, t: float = 0.0) -> list[Detection]:
        img = image if image.ndim == 3 else cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        lb, r, left, top = letterbox(img, self.size)
        x = lb[:, :, ::-1].transpose(2, 0, 1)[None].astype(np.float32) / 255.0
        return decode(self.session.run(None, {self.input: x})[0], r, left, top, self.class_map, self.conf_thr)
