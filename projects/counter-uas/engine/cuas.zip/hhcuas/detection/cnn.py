"""Two-stage learned detector.

Stage 1  class-agnostic proposals from the CFAR contrast detector at a low threshold.
Stage 2  a small CNN classifies a 32x32 context patch around each proposal as
         multirotor / fixed_wing / bird / aircraft / clutter.

Inference runs in ONNX Runtime; training (PyTorch) lives in `train.py`.
"""
from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

from .. import CNN_CLASSES, paths
from .base import Detection, Detector, size_label, to_gray
from .classical import ContrastDetector

PATCH = 32
PROPOSAL_Z = 4.0


def patch_side(w: float, h: float) -> int:
    return int(np.clip(2.0 * max(w, h) + 6, 16, 128))


def extract_patches(gray: np.ndarray, boxes: list[tuple[float, float, float, float]]) -> np.ndarray:
    """(N,2,32,32): channel 0 = locally standardised patch (shape), channel 1 = fixed-scale contrast."""
    H, W = gray.shape
    out = np.zeros((len(boxes), 2, PATCH, PATCH), np.float32)
    for i, (x1, y1, x2, y2) in enumerate(boxes):
        s = patch_side(x2 - x1, y2 - y1)
        cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
        xa, ya = int(round(cx - s / 2)), int(round(cy - s / 2))
        xs = np.clip(np.arange(xa, xa + s), 0, W - 1)
        ys = np.clip(np.arange(ya, ya + s), 0, H - 1)
        p = gray[np.ix_(ys, xs)]
        if s != PATCH:
            p = cv2.resize(p, (PATCH, PATCH), interpolation=cv2.INTER_AREA if s > PATCH else cv2.INTER_LINEAR)
        p = p - p.mean()
        out[i, 0] = p / (p.std() + 2.0)
        out[i, 1] = np.clip(p / 40.0, -3, 3)
    return out


def softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - x.max(axis=1, keepdims=True))
    return e / e.sum(axis=1, keepdims=True)


class PatchCNNDetector(Detector):
    def __init__(self, model: str, proposal_z: float = PROPOSAL_Z, min_score: float = 0.05, max_dets: int = 60):
        d = Path(model) if Path(model).is_dir() else paths.MODELS / model
        card = json.loads((d / "card.json").read_text()) if (d / "card.json").exists() else {}
        super().__init__(name=d.name, info=card)
        try:
            import onnxruntime as ort
        except ImportError:                      # browser edition (Pyodide): NumPy forward pass of the same weights
            ort = None
        if ort is not None and (d / "model.onnx").exists():
            so = ort.SessionOptions()
            so.intra_op_num_threads = 2
            session = ort.InferenceSession(str(d / "model.onnx"), so, providers=["CPUExecutionProvider"])
            self._infer = lambda x: session.run(None, {"patch": x})[0]
            self.backend = "onnxruntime"
        elif (d / "model.npz").exists():
            from .numpy_net import NumpyNet
            self._infer = NumpyNet(d / "model.npz")
            self.backend = "numpy"
        else:
            raise FileNotFoundError(f"model {model!r} is not trained yet ({d}); run python -m hhcuas.detection.train")
        self.proposer = ContrastDetector(z_thr=proposal_z, max_dets=max_dets)
        self.min_score = min_score

    def detect(self, image: np.ndarray, t: float = 0.0) -> list[Detection]:
        props = self.proposer.detect(image)
        self.shared_ms = self.proposer.shared_ms
        if not props:
            return []
        g = to_gray(image)
        x = extract_patches(g, [(p.x1, p.y1, p.x2, p.y2) for p in props])
        probs = softmax(self._infer(x))
        out = []
        for p, pr in zip(props, probs):
            obj = float(1.0 - pr[-1])
            if obj < self.min_score:
                continue
            k = int(np.argmax(pr[:-1]))
            p.score = obj
            p.uav_score = float(pr[0] + pr[1])
            p.probs = {c: float(v) for c, v in zip(CNN_CLASSES, pr)}
            p.cls = CNN_CLASSES[k] if pr[k] >= 0.4 else size_label(p.w, p.h)
            out.append(p)
        return out
