"""Classical (non-learned) detectors used as baselines and as proposal generators.

ContrastDetector  single-frame CFAR on a difference-of-Gaussians response.
MotionDetector    running-average background subtraction (static camera only).
"""
from __future__ import annotations

import time
import zlib
from dataclasses import dataclass

import cv2
import numpy as np

from .base import Detection, Detector, nms, size_label, to_gray


_MAP_CACHE: dict = {}


def _components(z: np.ndarray, thr: float, scale: float, max_n: int, min_area: int = 1) -> list[Detection]:
    mask = (z >= thr).astype(np.uint8)
    if not mask.any():
        return []
    mask = cv2.dilate(mask, np.ones((3, 3), np.uint8))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    out = []
    if n - 1 > 4 * max_n:           # pathological frame (e.g. pure noise): keep the strongest blobs only
        order = np.argsort(-stats[1:, cv2.CC_STAT_AREA])[:4 * max_n] + 1
    else:
        order = range(1, n)
    for i in order:
        x, y, w, h, area = stats[i]
        if area < min_area:
            continue
        peak = float(z[y:y + h, x:x + w].max())
        out.append(Detection(x1=x * scale, y1=y * scale, x2=(x + w) * scale, y2=(y + h) * scale,
                             score=peak / (peak + 1.5 * thr), peak=peak))
    out.sort(key=lambda d: -d.peak)
    return out[:max_n]


@dataclass
class ContrastDetector(Detector):
    """Cell-averaging CFAR (with guard cells) on a band-pass (DoG) image at two scales."""
    name: str = "classical-contrast"
    z_thr: float = 6.0
    window: int = 41
    guard: int = 9
    noise_floor: float = 0.6
    max_dets: int = 60
    scales: tuple = ((0.8, 4.0, 1), (1.2, 6.0, 3))
    shared_ms: float = 0.0

    def response(self, g: np.ndarray):
        for s1, s2, down in self.scales:
            gg = g if down == 1 else cv2.resize(g, None, fx=1 / down, fy=1 / down, interpolation=cv2.INTER_AREA)
            d = cv2.GaussianBlur(gg, (0, 0), s1) - cv2.GaussianBlur(gg, (0, 0), s2)
            k = self.window if down == 1 else max(15, self.window // down | 1)
            gk = self.guard if down == 1 else max(3, self.guard // down | 1)
            # cell-averaging CFAR with guard cells: statistics from the ring between guard and window
            n = float(k * k - gk * gk)
            s1_ = cv2.boxFilter(d, -1, (k, k), normalize=False) - cv2.boxFilter(d, -1, (gk, gk), normalize=False)
            s2_ = cv2.boxFilter(d * d, -1, (k, k), normalize=False) - cv2.boxFilter(d * d, -1, (gk, gk), normalize=False)
            mu = s1_ / n
            var = s2_ / n - mu * mu
            z = np.abs(d - mu) / (np.sqrt(np.maximum(var, 0)) + self.noise_floor / down)
            yield z, down

    def maps(self, image: np.ndarray):
        """CFAR response maps for a frame, shared between detectors that look at the same image
        object (several pipelines on one frame). Returns (maps, compute_ms, was_cached)."""
        # identity + content checksum (~0.3 ms), so a buffer that is reused or edited in place is not mistaken for a hit
        key = (id(image), image.shape, zlib.adler32(np.ascontiguousarray(image)), self.window, self.guard, self.noise_floor, self.scales)
        hit = _MAP_CACHE.get(key)
        if hit is not None and hit[0] is image:
            return hit[1], hit[2], True
        t0 = time.perf_counter()
        maps = list(self.response(to_gray(image)))
        ms = (time.perf_counter() - t0) * 1e3
        if len(_MAP_CACHE) >= 4:
            _MAP_CACHE.pop(next(iter(_MAP_CACHE)))
        _MAP_CACHE[key] = (image, maps, ms)
        return maps, ms, False

    def detect(self, image: np.ndarray, t: float = 0.0) -> list[Detection]:
        maps, ms, cached = self.maps(image)
        # a cached map still cost `ms` to compute: charge it so per-pipeline timing stays standalone-equivalent
        self.shared_ms = ms if cached else 0.0
        dets: list[Detection] = []
        for z, down in maps:
            dets += _components(z, self.z_thr, float(down), self.max_dets)
        dets = nms(dets)[: self.max_dets]
        for d in dets:
            d.cls = size_label(d.w, d.h)
        return dets


@dataclass
class MotionDetector(Detector):
    """Background subtraction with a running average. Assumes a static camera;
    hovering targets fade into the background model (a documented limitation)."""
    name: str = "classical-motion"
    k_thr: float = 6.0
    alpha: float = 0.08
    warmup: int = 5
    max_dets: int = 60

    def __post_init__(self):
        self.reset()

    def reset(self) -> None:
        self._bg = None
        self._n = 0

    def detect(self, image: np.ndarray, t: float = 0.0) -> list[Detection]:
        g = cv2.GaussianBlur(to_gray(image), (0, 0), 0.8)
        if self._bg is None or self._bg.shape != g.shape:
            self._bg, self._n = g.copy(), 0
            return []
        d = np.abs(g - self._bg)
        self._bg += self.alpha * (g - self._bg)
        self._n += 1
        if self._n < self.warmup:
            return []
        sigma = 1.4826 * float(np.median(d[::4, ::4])) + 0.4
        z = d / sigma
        dets = _components(z, self.k_thr, 1.0, self.max_dets)
        for x in dets:
            x.cls = size_label(x.w, x.h)
        return dets
