"""Interceptor technology evaluation workspace.

A weighted multi-criteria comparison of counter-UAS *response platform categories*.
Scope is high-level and non-destructive only: there are no design, construction,
guidance or engagement details here, and kinetic / destructive effectors are
explicitly outside the evaluated set.

Default ratings are ANALYST PRIORS on a 1–5 ordinal scale (5 = most favourable).
They are qualitative starting points, not measurements and not vendor data; the
workspace marks them unverified until a user replaces them and cites a source.
"""
from __future__ import annotations

import json
from copy import deepcopy
from datetime import datetime, timezone

import numpy as np

from . import paths, store

CRITERIA = [
    dict(id="detection", name="Detection capability", help="How little the response depends on an external detection chain (5 = self-sufficient)."),
    dict(id="tracking", name="Tracking capability", help="Tolerance to coarse or intermittent cueing (5 = works with coarse cueing)."),
    dict(id="integration", name="Integration architecture", help="Ease of integrating with command-and-control and sensor feeds."),
    dict(id="latency", name="Response latency", help="Time from confirmed track to effect (5 = shortest)."),
    dict(id="workload", name="Operator workload", help="5 = lowest workload."),
    dict(id="reliability", name="Reliability", help="Consistency of outcome against the target classes it is meant for."),
    dict(id="constraints", name="Operational constraints", help="5 = fewest constraints (range, line of sight, target type)."),
    dict(id="environment", name="Environmental limitations", help="5 = least affected by wind, rain, light, urban clutter."),
    dict(id="safety", name="Safety", help="5 = lowest risk to people, property and other spectrum/airspace users."),
    dict(id="regulatory", name="Regulatory requirements", help="5 = lightest authorisation burden."),
    dict(id="deployment", name="Deployment complexity", help="5 = simplest to deploy and sustain."),
]

_P = "analyst prior — unverified"

DEFAULT_PLATFORMS = [
    dict(id="detect_alert", name="Detect–track–alert only", category="No effector",
         summary="Sensor network with alerting, evidence capture and procedural response (pause operations, notify authorities, locate the pilot).",
         ratings=dict(detection=5, tracking=5, integration=5, latency=2, workload=4, reliability=4, constraints=5, environment=4, safety=5, regulatory=5, deployment=4),
         notes="Does not stop the aircraft. Baseline against which effectors should be justified."),
    dict(id="rf_takeover", name="RF protocol takeover (cyber)", category="Non-kinetic, RF",
         summary="Takes over a recognised control link to land or redirect the aircraft.",
         ratings=dict(detection=4, tracking=4, integration=3, latency=4, workload=3, reliability=2, constraints=2, environment=4, safety=4, regulatory=1, deployment=3),
         notes="Only works on supported protocols; ineffective against autonomous or unknown links. Transmitting is normally reserved to authorised state bodies."),
    dict(id="rf_jam", name="RF link disruption (jamming)", category="Non-kinetic, RF",
         summary="Disrupts control/video links to trigger the aircraft's lost-link behaviour.",
         ratings=dict(detection=2, tracking=3, integration=3, latency=4, workload=3, reliability=3, constraints=3, environment=4, safety=2, regulatory=1, deployment=3),
         notes="Outcome depends on the target's fail-safe. Affects other spectrum users. Unlawful for most operators in most jurisdictions."),
    dict(id="gnss_disrupt", name="GNSS disruption", category="Non-kinetic, RF",
         summary="Denies or manipulates satellite navigation to prevent autonomous navigation.",
         ratings=dict(detection=2, tracking=3, integration=2, latency=3, workload=3, reliability=2, constraints=2, environment=4, safety=1, regulatory=1, deployment=3),
         notes="Wide collateral effect on aviation and infrastructure; very tightly restricted."),
    dict(id="net_uav", name="Net capture — interceptor UAV", category="Non-destructive capture",
         summary="A capture aircraft carries or deploys a net and recovers the target.",
         ratings=dict(detection=1, tracking=1, integration=2, latency=2, workload=2, reliability=3, constraints=2, environment=2, safety=3, regulatory=2, deployment=2),
         notes="Needs continuous, accurate tracking of the target — the quality measured by this platform's tracking metrics. Fast or agile targets are hard."),
    dict(id="net_ground", name="Net capture — ground launcher", category="Non-destructive capture",
         summary="Hand-held or mounted launcher throws a net at short range.",
         ratings=dict(detection=1, tracking=2, integration=1, latency=3, workload=2, reliability=2, constraints=1, environment=2, safety=3, regulatory=3, deployment=4),
         notes="Very short range; operator must be in the right place. Falling aircraft remains a hazard."),
]

OUT_OF_SCOPE = [
    "Kinetic or collision interceptors", "Projectile and explosive effectors", "Directed-energy weapons",
    "Any autonomous engagement or weapon-guidance function",
]


def _file(org: str):
    d = paths.DATA / "interceptor"
    d.mkdir(exist_ok=True)
    return d / f"{org}.json"


def default_state() -> dict:
    return dict(criteria=CRITERIA, weights={c["id"]: 1.0 for c in CRITERIA},
                platforms=[dict(p, rating_source={c["id"]: _P for c in CRITERIA}, documented_specs=[], verified=False) for p in deepcopy(DEFAULT_PLATFORMS)],
                out_of_scope=OUT_OF_SCOPE, updated=None, updated_by=None)


def load(org: str) -> dict:
    f = _file(org)
    st = json.loads(f.read_text()) if f.exists() else default_state()
    st["criteria"] = CRITERIA
    st["out_of_scope"] = OUT_OF_SCOPE
    return st


def save(org: str, state: dict, user: str) -> dict:
    ids = {c["id"] for c in CRITERIA}
    clean = default_state()
    clean["weights"] = {k: float(np.clip(float(state.get("weights", {}).get(k, 1.0)), 0, 10)) for k in ids}
    plats = []
    for p in state.get("platforms", [])[:40]:
        ratings = {k: int(np.clip(int(p.get("ratings", {}).get(k, 3)), 1, 5)) for k in ids}
        src = {k: str(p.get("rating_source", {}).get(k, _P))[:300] for k in ids}
        specs = [dict(name=str(s.get("name", ""))[:120], value=str(s.get("value", ""))[:200], source=str(s.get("source", ""))[:300])
                 for s in p.get("documented_specs", [])[:30]]
        plats.append(dict(id=str(p.get("id"))[:40], name=str(p.get("name"))[:120], category=str(p.get("category", ""))[:80],
                          summary=str(p.get("summary", ""))[:600], notes=str(p.get("notes", ""))[:800], ratings=ratings, rating_source=src,
                          documented_specs=specs, verified=all(v != _P for v in src.values())))
    clean["platforms"] = plats
    clean["updated"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    clean["updated_by"] = user
    _file(org).write_text(json.dumps(clean, indent=1))
    return clean


def score(state: dict) -> dict:
    w = state["weights"]
    tot = sum(w.values()) or 1.0
    rows = []
    for p in state["platforms"]:
        s = sum(w[k] * p["ratings"][k] for k in w) / tot
        unverified = sum(1 for v in p["rating_source"].values() if v == _P)
        rows.append(dict(id=p["id"], name=p["name"], category=p["category"], score=round(s, 3), normalised=round((s - 1) / 4, 3),
                         unverified_ratings=unverified, verified=p["verified"]))
    rows.sort(key=lambda r: -r["score"])
    # sensitivity: how often each platform ranks first when weights are perturbed
    rng = np.random.default_rng(0)
    keys = list(w)
    R = np.array([[p["ratings"][k] for k in keys] for p in state["platforms"]], float)
    base = np.array([w[k] for k in keys])
    wins = np.zeros(len(R))
    if len(R) and base.sum() > 0:
        for _ in range(2000):
            ww = base * rng.uniform(0.5, 1.5, len(keys))
            wins[np.argmax(R @ ww)] += 1
    sens = {p["id"]: round(float(wins[i] / 2000), 3) for i, p in enumerate(state["platforms"])}
    for r in rows:
        r["rank1_share_under_weight_perturbation"] = sens.get(r["id"])
    return dict(ranking=rows, note="Scores are weighted means of 1–5 ordinal ratings. They rank categories against the stated weights; "
                                   "they are not performance measurements. 'rank-1 share' = fraction of 2000 random ±50 % weight perturbations in which the platform ranks first.")


def measured_cueing(org: str) -> dict:
    """What the platform's own experiments say about the cue quality available to any response system."""
    rows = [r["summary"] for r in store.list_experiments(org, kind="pipeline") if r["summary"].get("track_init_s") is not None]
    if not rows:
        return dict(available=False, note="No tracking experiments stored yet.")
    f = lambda k: [r[k] for r in rows if r.get(k) is not None]
    return dict(available=True, experiments=len(rows), origin="simulated",
                track_initiation_s=dict(mean=float(np.mean(f("track_init_s"))), max=float(np.max(f("track_init_s")))),
                track_continuity=dict(mean=float(np.mean(f("track_continuity"))), min=float(np.min(f("track_continuity")))),
                detection_latency_s=dict(mean=float(np.mean(f("detection_latency_s")))) if f("detection_latency_s") else None,
                processing_ms=dict(mean=float(np.mean(f("e2e_ms")))) if f("e2e_ms") else None,
                note="Measured on stored (simulated) experiments. A response platform's own latency adds to detection latency + track initiation.")
