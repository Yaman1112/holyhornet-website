"""Sensor inventory and operating boundaries shown by the Command Center and Settings."""
from __future__ import annotations

from . import store
from .simulation.scenarios import build_scenario

BOUNDARIES = [
    "Research, detection, identification, tracking and technology evaluation only.",
    "No weapon guidance, firing interfaces, autonomous pursuit, collision/ramming or target-neutralisation functions exist in this software.",
    "No construction or engagement instructions for interceptors or payloads.",
    "The research assistant cannot authorise or initiate any defensive response.",
    "Any real-world response capability is a separately authorised, human-supervised integration with its own legal and safety review.",
    "Not a certified counter-UAS defence system. Results are laboratory results on simulated data unless labelled otherwise.",
]

CAMERA_TYPE = {"eo_day": "Daylight camera", "eo_lowlight": "Low-light camera", "thermal": "Thermal camera (LWIR)"}


def sensor_inventory(org: str) -> tuple[list[dict], list[dict], list[dict]]:
    """-> (sensors, live_adapters, experiment index rows)."""
    site = build_scenario("H")
    exps = store.list_experiments(org)
    last = {}
    for r in reversed(exps):
        if r["kind"] == "pipeline":
            last[r["sensor_kind"]] = r
    sensors = []
    for c in site.cameras + [build_scenario("B").camera("ll-1")]:
        lr = last.get(c.kind)
        sensors.append(dict(id=c.id, type=CAMERA_TYPE[c.kind], kind=c.kind, source="simulated", status="available",
                            detail=f"{c.width}x{c.height} @ {c.fps:g} fps, HFOV {c.hfov_deg:g}°", pos=c.pos, az_deg=c.az_deg, el_deg=c.el_deg,
                            hfov_deg=c.hfov_deg, last_experiment=lr["id"] if lr else None, last_recall=lr["summary"].get("recall") if lr else None))
    for r in site.radars:
        sensors.append(dict(id=r.id, type="Radar data source", kind="radar", source="simulated", status="available",
                            detail=f"{r.scan_hz:g} Hz scan, {r.range_max_m:g} m", pos=r.pos, range_max_m=r.range_max_m))
    for b in site.bearing_sensors:
        sensors.append(dict(id=b.id, type="Acoustic array" if b.kind == "acoustic" else "RF direction metadata", kind=b.kind, source="simulated",
                            status="available", detail=f"azimuth only, σ {b.sigma_az_deg:g}°, {b.range_max_m:g} m", pos=b.pos, range_max_m=b.range_max_m))
    live = [dict(id="camera adapter", type="Live camera / RTSP (OpenCV)", source="live_sensor", status="not connected",
                 detail="adapter present, no device configured; untested on hardware"),
            dict(id="external feed adapter", type="External track / radar feed (JSON lines)", source="live_sensor", status="not connected",
                 detail="adapter present, no feed configured")]
    return sensors, live, exps
