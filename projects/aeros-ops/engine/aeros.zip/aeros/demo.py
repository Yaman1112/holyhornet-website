"""Demonstration dataset.

Loaded only on an administrator's request. Every record is fictional and labelled: codes start with DEMO-, names end
with (demo), and the application shows a banner while the dataset is present. It contains NO flight data, approvals
or test results — those are produced by actually working through the platform (simulation, checklists, approvals).
"""
from datetime import timedelta

from . import fleet, models as m
from .core import hash_password, today
from .db import utcnow

SITE = (52.1680, 4.4250)  # open former airfield near Valkenburg (NL), used here only as a plausible map location


def load(db, admin, password: str | None) -> dict:
    td = today()
    cust = m.Customer(code="DEMO-CUS-01", name="Northfield Survey BV (demo)", country="Netherlands", contact_name="A. Example", notes="Fictional customer")
    db.add(cust)
    db.flush()
    prj = m.Project(code="DEMO-PRJ-01", name="Corridor mapping platform (demo)", customer_id=cust.id, status="active", manager_id=admin.id,
                    description="Fictional project used by the demonstration dataset.", start_date=td - timedelta(days=30), end_date=td + timedelta(days=120))
    db.add(prj)
    people = {}
    for uname, name, role, disc in (("demo.fltops", "Dana Okafor (demo)", "flight_ops", "Flight operations"), ("demo.fte", "Ravi Menon (demo)", "flight_test", "Test"),
                                    ("demo.uaveng", "Lena Vos (demo)", "uav_eng", "Hardware"), ("demo.maint", "Tomas Brandt (demo)", "maintenance", "Hardware"),
                                    ("demo.pilot", "Sofia Marin (demo)", "operator", "Flight operations"), ("demo.instr", "Hugo Lindqvist (demo)", "instructor", "Systems")):
        u = m.User(username=uname, full_name=name, role=role, discipline=disc, organisation="Demonstration", can_login=bool(password), active=True,
                   password_hash=hash_password(password) if password else None, notes="Demonstration dataset account")
        db.add(u)
        people[role] = u
    db.flush()
    for role, title, kind, issuer in (("operator", "Remote pilot certificate — fictional example", "regulatory_licence", "Example aviation authority (demo)"),
                                      ("flight_test", "Remote pilot certificate — fictional example", "regulatory_licence", "Example aviation authority (demo)"),
                                      ("flight_ops", "Flight operations manager appointment — fictional example", "other", "Demonstration")):
        db.add(m.Qualification(user_id=people[role].id, kind=kind, title=title, issuer=issuer, reference="DEMO-0000", issued_date=td - timedelta(days=200),
                               expiry_date=td + timedelta(days=400), notes="Fictional record in the demonstration dataset"))

    def aircraft(code, name, typ, frame, mtom, empty, payload, fw):
        ac = m.Aircraft(code=code, name=name, manufacturer="Demo Dynamics", model=name.split(" (")[0], serial_number=code.replace("AC", "SN"), aircraft_type=typ,
                        airframe_config=frame, mtom_kg=mtom, empty_mass_kg=empty, payload_mass_kg=payload, payload_config="Mapping camera on a fixed mount",
                        flight_controller="DD-FC6", autopilot="PX4", autopilot_firmware=fw, propulsion="Brushless outrunner, direct drive", esc_config="Individual ESCs, DShot600",
                        battery_config="Single pack", nav_sensors="GNSS L1/L5, IMU, barometer, magnetometer", comm_equipment="433 MHz telemetry, 2.4 GHz RC",
                        companion_computer="None", software_version="DD-Stack 2.3.0", project_id=prj.id, received_date=td - timedelta(days=10), flight_hours=0.0,
                        flight_cycles=0, notes="Fictional aircraft in the demonstration dataset")
        db.add(ac)
        db.flush()
        return ac

    n = [0]

    def comp(ac, cat, model, specs, pos=None, ver=None):
        n[0] += 1
        c = m.Component(code=f"DEMO-CMP-{n[0]:03d}", category=cat, manufacturer="Demo Dynamics", model=model, serial_number=f"DD{n[0]:05d}", specs=specs,
                        aircraft_id=ac.id, position=pos, installed_date=td - timedelta(days=8), config_version=ver, status="installed", hours=0.0, cycles=0)
        db.add(c)
        db.flush()
        db.add(m.ComponentEvent(component_id=c.id, aircraft_id=ac.id, event_type="installed", description=f"Installed on {ac.code}" + (f" at {pos}" if pos else ""),
                                user_id=admin.id, hours_at_event=0.0))

    a1 = aircraft("DEMO-AC-01", "Kestrel Q4 (demo)", "Multicopter (quad)", "X4", 2.4, 1.75, 0.35, "PX4 v1.15.2")
    for i, pos in enumerate(("M1 front-right", "M2 rear-left", "M3 front-left", "M4 rear-right")):
        comp(a1, "Motor", "DD-2814 920KV", {"kv": 920, "max_current_a": 22, "max_thrust_g": 1350, "cells_min": 3, "cells_max": 4, "prop_in_min": 9, "prop_in_max": 11, "mass_g": 62}, pos)
        comp(a1, "ESC", "DD-ESC30", {"continuous_current_a": 30, "cells_min": 2, "cells_max": 6, "channels": 1, "protocol": "DShot600", "mass_g": 9}, pos, "BLHeli_32 32.9")
        comp(a1, "Propeller", "DD-1045", {"diameter_in": 10, "pitch_in": 4.5, "mass_g": 11}, pos)
    comp(a1, "Battery", "DD-4S5200", {"cells": 4, "capacity_mah": 5200, "c_rating": 35, "chemistry": "LiPo", "mass_g": 480, "cycle_limit": 300})
    comp(a1, "Flight controller", "DD-FC6", {"supported_firmware": "PX4, ArduPilot", "voltage_min": 4.5, "voltage_max": 5.5, "mass_g": 38}, ver="PX4 v1.15.2")
    comp(a1, "GPS module", "DD-GNSS-M9", {"constellations": "GPS, Galileo, BeiDou", "rtk": "no", "mass_g": 25})
    comp(a1, "Telemetry module", "DD-TEL433", {"frequency_mhz": 433, "power_mw": 100, "mass_g": 18}, ver="1.9")
    comp(a1, "Radio receiver", "DD-RX24", {"frequency_mhz": 2400, "protocol": "CRSF", "mass_g": 6})

    a2 = aircraft("DEMO-AC-02", "Heron H6 (demo)", "Hexacopter", "Flat hex", 6.5, 4.6, 1.2, "PX4 v1.15.2")
    for i in range(6):
        comp(a2, "Motor", "DD-4114 400KV", {"kv": 400, "max_current_a": 35, "max_thrust_g": 2200, "cells_min": 4, "cells_max": 6, "prop_in_min": 13, "prop_in_max": 16, "mass_g": 148}, f"M{i + 1}")
        comp(a2, "ESC", "DD-ESC30", {"continuous_current_a": 30, "cells_min": 2, "cells_max": 6, "channels": 1, "protocol": "DShot600", "mass_g": 9}, f"M{i + 1}", "BLHeli_32 32.9")
        comp(a2, "Propeller", "DD-1555", {"diameter_in": 15, "pitch_in": 5.5, "mass_g": 28}, f"M{i + 1}")
    comp(a2, "Battery", "DD-6S10000", {"cells": 6, "capacity_mah": 10000, "c_rating": 25, "chemistry": "LiPo", "mass_g": 1280, "cycle_limit": 250})
    comp(a2, "Flight controller", "DD-FC6", {"supported_firmware": "PX4, ArduPilot", "mass_g": 38}, ver="PX4 v1.15.2")
    comp(a2, "GPS module", "DD-GNSS-M9", {"constellations": "GPS, Galileo, BeiDou", "mass_g": 25})
    comp(a2, "Telemetry module", "DD-TEL433", {"frequency_mhz": 433, "power_mw": 100, "mass_g": 18})

    for title, cat, h, cyc, days in (("Motor bearing and mount inspection", "Motor inspection", 25, None, None), ("Propeller inspection", "Propeller inspection", None, 10, None),
                                     ("Airframe structural inspection", "Structural condition", None, None, 90)):
        db.add(m.MaintenanceTask(aircraft_id=a1.id, title=title, task_type="scheduled", category=cat, interval_hours=h, interval_cycles=cyc, interval_days=days,
                                 last_done_date=td - timedelta(days=8), last_done_hours=0.0, last_done_cycles=0, active=True))

    eqs = []
    for code, cat, name, host, port in (("DEMO-C2-01", "Ground control station", "Field GCS laptop (demo)", "127.0.0.1", None),
                                        ("DEMO-C2-02", "Telemetry device", "433 MHz ground radio (demo)", None, None),
                                        ("DEMO-C2-03", "Antenna", "433 MHz 5 dBi omni on mast (demo)", None, None),
                                        ("DEMO-C2-04", "Network equipment", "Field router (demo)", None, None)):
        e = m.C2Equipment(code=code, category=cat, name=name, manufacturer="Demo Dynamics", model=name.split(" (")[0], serial_number=code.replace("C2", "S"),
                          software_version="QGroundControl 4.4" if cat == "Ground control station" else None, host=host, port=port, status="serviceable",
                          location="Stores", last_maintenance=td - timedelta(days=40), next_maintenance=td + timedelta(days=140),
                          configuration="Fictional equipment in the demonstration dataset")
        db.add(e)
        eqs.append(e)
    db.flush()
    db.add(m.TelemetryLink(name="SITL on UDP 14550 (demo)", transport="udp", address="0.0.0.0", port=14550, source_class="sitl", transmit=False, aircraft_id=a1.id,
                           equipment_id=eqs[0].id, notes="Receive-only. Start PX4 or ArduPilot SITL on this workstation, then connect."))

    lat, lon = SITE
    dn, de = 1 / 111_320.0, 1 / (111_320.0 * 0.6134)
    P = lambda north, east: [round(lat + north * dn, 7), round(lon + east * de, 7)]  # noqa: E731
    wp = lambda north, east, alt, hold=0: {"lat": P(north, east)[0], "lon": P(north, east)[1], "alt": alt, "hold_s": hold}  # noqa: E731
    camp = m.Campaign(code="DEMO-TC-01", name="Kestrel Q4 initial flight validation (demo)", customer_id=cust.id, project_id=prj.id, aircraft_id=a1.id,
                      location="Test field, Valkenburg (demo)", lat=lat, lon=lon, responsible_engineer_id=people["flight_test"].id,
                      personnel=[people["flight_test"].id, people["operator"].id], start_date=td + timedelta(days=7), end_date=td + timedelta(days=9),
                      objectives="Validate hover stability, vibration levels, battery performance and waypoint tracking of the Kestrel Q4 at its first released configuration.",
                      weather="To be recorded on the test day. Limits: wind below 8 m/s, no precipitation.", environment="Open grass field, sea level, 5–25 °C.",
                      procedures="Per test cards. One battery per card; inspect between flights.",
                      success_criteria="All required acceptance criteria met on every executed card; no open critical or major issue.",
                      firmware_version=a1.autopilot_firmware, software_release=a1.software_version, stage=0, status="active",
                      stage_log=[{"stage": 0, "at": utcnow().isoformat(), "by": admin.id}])
    db.add(camp)
    db.flush()
    cards = [
        ("Hover stability", "Flight stability", "Hold a 60 s position-mode hover at 10 m in wind below 5 m/s.",
         [("Hover attitude standard deviation", "hover_att_std_deg", "<=", 2.0, "deg"), ("Hover altitude standard deviation", "hover_alt_std_m", "<=", 0.5, "m")]),
        ("Vibration survey", "Hardware reliability", "Hover 60 s then fly a 100 m out-and-back at 8 m/s.",
         [("Vibration (accelerometer RMS, worst axis)", "vib_rms_ms2", "<=", 3.0, "m/s²"), ("Accelerometer clipping events", "clip_count", "<=", 0, "")]),
        ("Battery performance", "Battery performance", "Fly the standard circuit until 30% remaining.",
         [("Minimum battery voltage", "v_min", ">=", 14.0, "V"), ("Maximum battery temperature", "batt_temp_max_c", "<=", 55, "°C")]),
        ("Waypoint tracking", "Autonomous mission execution", "Fly mission DEMO-MSN-01 in mission mode.",
         [("Cross-track error (maximum)", "xtrack_max_m", "<=", 5.0, "m"), ("Minimum satellites", "sats_min", ">=", 10, "")]),
    ]
    for i, (title, cat, proc, crit) in enumerate(cards):
        db.add(m.TestCard(code=f"DEMO-TP-{i + 1:02d}", campaign_id=camp.id, title=title, category=cat, objective=f"Demonstrate acceptable {title.lower()}.",
                          aircraft_config="Released configuration, mapping payload fitted, full battery.", preconditions="Aircraft inspected; wind within limits; geofence active.",
                          procedure=proc, expected_results="All acceptance criteria met.", requires_evidence=True, status="planned", measurements={},
                          criteria=[{"id": f"c{j + 1}", "parameter": p, "metric": k, "op": op, "value": v, "unit": un, "required": True} for j, (p, k, op, v, un) in enumerate(crit)]))
    for hz, cause, cons, l_, s_, mit in (("Loss of control link", "Range, antenna masking or interference", "Aircraft continues without operator control", 3, 4,
                                          "Link-loss failsafe set to return-to-launch and verified on the ground; flight inside geofence; observer maintains visual contact."),
                                         ("Fly-away beyond the test area", "Navigation or control failure", "Aircraft leaves the authorized area", 2, 5,
                                          "Geofence with flight termination; test area sterile; maximum distance 400 m.")):
        db.add(m.RiskItem(campaign_id=camp.id, hazard=hz, cause=cause, consequence=cons, likelihood=l_, severity=s_, mitigation=mit, residual_likelihood=1,
                          residual_severity=s_, owner_id=people["flight_test"].id))
    ms = m.Mission(code="DEMO-MSN-01", name="Standard validation circuit (demo)", aircraft_id=a1.id, campaign_id=camp.id,
                   description="Rectangular circuit inside the test field boundary.", home={"lat": lat, "lon": lon, "alt": 2.0},
                   waypoints=[wp(60, 0, 30), wp(60, 150, 30, 5), wp(-60, 150, 40), wp(-60, -80, 40), wp(20, -80, 25)],
                   geofence={"polygon": [P(130, -160), P(130, 230), P(-130, 230), P(-130, -160)], "alt_min": 0, "alt_max": 60, "max_distance": 400},
                   emergency_sites=[{"name": "East grass strip", "lat": P(0, 190)[0], "lon": P(0, 190)[1]}], cruise_speed=8.0,
                   environment={"wind_speed": 4, "wind_dir": 250, "temperature": 15}, revision=1, status="draft")
    db.add(ms)
    db.flush()
    db.add(m.MissionRevision(mission_id=ms.id, number=1, snapshot={f: getattr(ms, f) for f in ("home", "waypoints", "geofence", "emergency_sites", "environment", "cruise_speed")},
                             note="Created by the demonstration dataset", created_by=admin.id))
    dep = m.Deployment(code="DEMO-DEP-01", name="Corridor survey pilot, Portugal (demo)", customer_id=cust.id, country="Portugal", location="Alentejo test corridor (demo)",
                       objectives="Two-week pilot survey with one aircraft.", start_date=td + timedelta(days=45), end_date=td + timedelta(days=59),
                       aircraft_ids=[a1.id], equipment_ids=[e.id for e in eqs[:3]], personnel_ids=[people["flight_ops"].id, people["operator"].id, people["maintenance"].id],
                       spares="", tools="Field toolkit, battery chargers ×2, LiPo transport cases", travel="", site_requirements="Vehicle access, 230 V supply or generator",
                       status="planning")
    db.add(dep)
    db.flush()
    db.add(m.Permit(code="DEMO-PMT-01", deployment_id=dep.id, permit_type="Operational permission", authority="Example national aviation authority (demo)",
                    reference="pending", location=dep.location, status="applied", notes="Fictional application in the demonstration dataset"))
    db.add(m.Demonstration(code="DEMO-DEMO-01", name="Autonomous corridor survey demonstration (demo)", customer_id=cust.id, audience="Operations director and two survey engineers",
                           objectives="Show an autonomous survey circuit with live telemetry and a post-flight data review.",
                           scenario="Brief → pre-flight → autonomous circuit → landing → telemetry replay and report.", aircraft_id=a1.id, mission_id=ms.id,
                           equipment_ids=[eqs[0].id], personnel_ids=[people["flight_ops"].id, people["operator"].id], scheduled_at=utcnow() + timedelta(days=21),
                           location="Test field, Valkenburg (demo)", safety_briefing="Spectators remain behind the marked line; follow instructions from the safety observer.",
                           acceptance_criteria=[{"text": "Mission completes autonomously without operator intervention", "met": None, "note": ""},
                                                {"text": "Live telemetry visible to the customer throughout the flight", "met": None, "note": ""},
                                                {"text": "Post-flight report delivered within 30 minutes", "met": None, "note": ""}], status="planned"))
    db.flush()
    errs = [c for c in fleet.compatibility(fleet.snapshot(db, a2)) if c["level"] == "error"]
    return {"aircraft": 2, "components": n[0], "people": len(people), "campaign": camp.code, "mission": ms.code, "deployment": dep.code,
            "note": f"{a2.code} deliberately carries {len(errs)} hardware compatibility error(s) to show the validation.", "accounts_can_sign_in": bool(password)}
