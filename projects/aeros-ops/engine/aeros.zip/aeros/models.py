"""Database schema for AEROS OPS PRO.

Column ``info`` carries UI metadata (label, choices, widget, ref) so the generic
record API and the schema-driven forms share one definition.
"""
from sqlalchemy import JSON, Boolean, Column, Date, DateTime, Float, ForeignKey, Integer, String, Text

from .db import Base, utcnow

ROLES = {
    "admin": "Administrator",
    "flight_ops": "Flight Operations Engineer",
    "flight_test": "Flight Test Engineer",
    "uav_eng": "UAV Engineer",
    "instructor": "Instructor",
    "operator": "Operator",
    "maintenance": "Maintenance Engineer",
    "customer": "Customer Viewer",
}
AIRCRAFT_TYPES = ["FPV quadcopter", "Multicopter (quad)", "Hexacopter", "Octocopter", "Fixed-wing", "VTOL", "Autonomous robotic platform"]
COMPONENT_CATEGORIES = [
    "Motor", "ESC", "Propeller", "Battery", "Flight controller", "GPS module", "IMU", "Barometer", "Magnetometer",
    "Camera", "LiDAR", "Optical flow", "Telemetry module", "Radio receiver", "Companion computer", "Airframe", "Other",
]
VALIDATION_CATEGORIES = [
    "Flight stability", "Flight-controller performance", "Navigation accuracy", "Sensor reliability",
    "Autonomous mission execution", "Communications reliability", "Battery performance", "Environmental tolerance",
    "Software reliability", "Hardware reliability", "Payload integration", "System recovery behaviour",
]
CAMPAIGN_STAGES = [
    "Campaign proposal", "Engineering review", "Test planning", "Risk assessment", "Aircraft inspection",
    "Ground validation", "Simulation validation", "Flight-test authorization", "Test execution", "Data collection",
    "Post-test analysis", "Engineering review (results)", "Campaign acceptance", "Final report",
]
C2_CATEGORIES = [
    "Ground control station", "Operator workstation", "Ground communication equipment", "Telemetry device",
    "Network equipment", "Antenna", "Data link", "Power supply", "Communication interface",
]
TRAINING_CATEGORIES = [
    "UAV fundamentals", "Flight theory", "Aircraft systems", "Avionics", "Flight-controller architecture",
    "Autonomous mission planning", "Ground control station operation", "Sensor systems", "Battery management",
    "Pre-flight inspections", "Emergency procedures", "Maintenance and troubleshooting", "Flight-test documentation",
    "Operational safety",
]
MAINT_CATEGORIES = ["Motor inspection", "Propeller inspection", "ESC condition", "Structural condition", "Sensor condition",
                    "Firmware update", "Battery", "General"]
DISCIPLINES = ["Hardware", "Software", "Flight operations", "Systems", "Test", "Project management"]
SOURCE_CLASSES = ["physical", "sitl", "simulation"]


def C(type_, label=None, *args, **kw):
    info = {}
    for k in ("choices", "widget", "ref", "ro", "help", "unit", "hidden"):
        if k in kw:
            info[k] = kw.pop(k)
    if label:
        info["label"] = label
    return Column(type_, *args, info=info, **kw)


def FK(target, label=None, **kw):
    table = target.split(".")[0]
    kw.setdefault("ref", table)
    kw.setdefault("nullable", True)
    kw.setdefault("index", True)
    return C(Integer, label, ForeignKey(target), **kw)


class Rec:
    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime, default=utcnow, info={"ro": True, "label": "Created"})
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow, info={"ro": True, "label": "Updated"})


# ───────────────────────── core ─────────────────────────
class User(Rec, Base):
    __tablename__ = "users"
    username = C(String(60), "Username", unique=True, nullable=False)
    full_name = C(String(120), "Full name", nullable=False)
    email = C(String(160), "Email")
    role = C(String(20), "Role", choices=list(ROLES), nullable=False, default="operator")
    discipline = C(String(40), "Discipline", choices=DISCIPLINES)
    organisation = C(String(120), "Organisation")
    customer_id = FK("customers.id", "Customer (viewer scope)")
    can_login = C(Boolean, "Can sign in", default=True)
    active = C(Boolean, "Active", default=True)
    password_hash = C(String(300), hidden=True)
    notes = C(Text, "Notes")


class Session(Base):
    __tablename__ = "sessions"
    id = Column(Integer, primary_key=True)
    token_hash = Column(String(64), unique=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)
    expires_at = Column(DateTime)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True)
    ts = Column(DateTime, default=utcnow, index=True)
    user_id = Column(Integer)
    username = Column(String(60))
    action = Column(String(40), index=True)
    entity = Column(String(60), index=True)
    entity_id = Column(String(40))
    summary = Column(Text)
    detail = Column(JSON)
    prev_hash = Column(String(64))
    hash = Column(String(64))


class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(80), primary_key=True)
    value = Column(JSON)
    secret = Column(Boolean, default=False)


class Customer(Rec, Base):
    __tablename__ = "customers"
    code = C(String(30), "Customer ID", unique=True)
    name = C(String(160), "Name", nullable=False)
    country = C(String(80), "Country")
    contact_name = C(String(120), "Contact")
    contact_email = C(String(160), "Contact email")
    notes = C(Text, "Notes")


class Project(Rec, Base):
    __tablename__ = "projects"
    code = C(String(30), "Project ID", unique=True)
    name = C(String(160), "Name", nullable=False)
    customer_id = FK("customers.id", "Customer")
    status = C(String(20), "Status", choices=["planned", "active", "on_hold", "complete"], default="active")
    manager_id = FK("users.id", "Project manager")
    description = C(Text, "Description")
    start_date = C(Date, "Start")
    end_date = C(Date, "End")


class Attachment(Base):
    __tablename__ = "attachments"
    id = Column(Integer, primary_key=True)
    subject_type = Column(String(40), index=True)
    subject_id = Column(Integer, index=True)
    filename = Column(String(255))
    stored_name = Column(String(80))
    size = Column(Integer)
    sha256 = Column(String(64))
    content_type = Column(String(120))
    description = Column(Text)
    uploaded_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)


class Comment(Base):
    __tablename__ = "comments"
    id = Column(Integer, primary_key=True)
    subject_type = Column(String(40), index=True)
    subject_id = Column(Integer, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    body = Column(Text)
    created_at = Column(DateTime, default=utcnow)


class Approval(Base):
    __tablename__ = "approvals"
    id = Column(Integer, primary_key=True)
    kind = Column(String(40), index=True)
    subject_type = Column(String(40), index=True)
    subject_id = Column(Integer, index=True)
    tag = Column(String(40))
    config_revision_id = Column(Integer, ForeignKey("config_revisions.id"))
    status = Column(String(20), default="requested", index=True)  # requested/approved/rejected/withdrawn
    requested_by = Column(Integer, ForeignKey("users.id"))
    requested_at = Column(DateTime, default=utcnow)
    request_note = Column(Text)
    evidence = Column(JSON)
    decided_by = Column(Integer, ForeignKey("users.id"))
    decided_at = Column(DateTime)
    decision_note = Column(Text)
    expires_at = Column(DateTime)


class Checklist(Base):
    __tablename__ = "checklists"
    id = Column(Integer, primary_key=True)
    kind = Column(String(40), index=True)
    title = Column(String(200))
    subject_type = Column(String(40), index=True)
    subject_id = Column(Integer, index=True)
    config_revision_id = Column(Integer, ForeignKey("config_revisions.id"))
    status = Column(String(20), default="open")
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)
    completed_at = Column(DateTime)


class ChecklistItem(Base):
    __tablename__ = "checklist_items"
    id = Column(Integer, primary_key=True)
    checklist_id = Column(Integer, ForeignKey("checklists.id", ondelete="CASCADE"), index=True)
    seq = Column(Integer)
    category = Column(String(80))
    label = Column(Text)
    auto_key = Column(String(60))
    status = Column(String(10), default="pending")  # pending/ok/fail/na
    note = Column(Text)
    signed_by = Column(Integer, ForeignKey("users.id"))
    signed_at = Column(DateTime)


# ───────────────────────── fleet ─────────────────────────
class Aircraft(Rec, Base):
    __tablename__ = "aircraft"
    code = C(String(30), "Aircraft ID", unique=True)
    name = C(String(120), "Name", nullable=False)
    manufacturer = C(String(120), "Manufacturer")
    model = C(String(120), "Model")
    serial_number = C(String(80), "Serial number")
    aircraft_type = C(String(40), "Aircraft type", choices=AIRCRAFT_TYPES, nullable=False)
    airframe_config = C(String(120), "Airframe configuration", help="e.g. X4, H-frame, coaxial X8, tail-sitter")
    mtom_kg = C(Float, "Maximum take-off mass", unit="kg")
    empty_mass_kg = C(Float, "Empty mass", unit="kg")
    payload_config = C(Text, "Payload configuration")
    payload_mass_kg = C(Float, "Payload mass", unit="kg")
    flight_controller = C(String(120), "Flight controller")
    autopilot = C(String(20), "Autopilot stack", choices=["PX4", "ArduPilot", "Betaflight", "INAV", "Other"])
    autopilot_firmware = C(String(60), "Autopilot firmware")
    propulsion = C(String(160), "Propulsion system")
    esc_config = C(String(160), "ESC configuration")
    battery_config = C(String(160), "Battery configuration")
    nav_sensors = C(String(200), "Navigation sensors")
    comm_equipment = C(String(200), "Communication equipment")
    companion_computer = C(String(120), "Companion computer")
    software_version = C(String(60), "Software version")
    hardware_revision = C(String(40), "Hardware revision")
    project_id = FK("projects.id", "Project")
    received_date = C(Date, "Received from R&D")
    current_revision_id = C(Integer, "Released configuration", ro=True)
    flight_hours = C(Float, "Flight hours", default=0.0, ro=True, unit="h")
    flight_cycles = C(Integer, "Flight cycles", default=0, ro=True)
    notes = C(Text, "Notes")


class Component(Rec, Base):
    __tablename__ = "components"
    code = C(String(30), "Component ID", unique=True)
    category = C(String(40), "Category", choices=COMPONENT_CATEGORIES, nullable=False)
    manufacturer = C(String(120), "Manufacturer")
    model = C(String(120), "Model", nullable=False)
    serial_number = C(String(80), "Serial number")
    specs = C(JSON, "Specifications", widget="specs", default=dict)
    aircraft_id = FK("aircraft.id", "Installed on", ro=True)
    position = C(String(60), "Position", help="e.g. M1 front-right", ro=True)
    installed_date = C(Date, "Installation date", ro=True)
    config_version = C(String(60), "Configuration / firmware version")
    status = C(String(20), "Status", choices=["in_stock", "installed", "removed", "quarantined", "scrapped"], default="in_stock", ro=True)
    hours = C(Float, "Operating hours", default=0.0, ro=True, unit="h")
    cycles = C(Integer, "Cycles", default=0, ro=True)
    notes = C(Text, "Notes")


class ComponentEvent(Base):
    __tablename__ = "component_events"
    id = Column(Integer, primary_key=True)
    component_id = Column(Integer, ForeignKey("components.id", ondelete="CASCADE"), index=True)
    aircraft_id = Column(Integer, ForeignKey("aircraft.id"))
    ts = Column(DateTime, default=utcnow)
    event_type = Column(String(30))
    description = Column(Text)
    user_id = Column(Integer, ForeignKey("users.id"))
    hours_at_event = Column(Float)


class ConfigRevision(Base):
    __tablename__ = "config_revisions"
    id = Column(Integer, primary_key=True)
    aircraft_id = Column(Integer, ForeignKey("aircraft.id", ondelete="CASCADE"), index=True)
    number = Column(Integer)
    label = Column(String(60))
    status = Column(String(20), default="draft")  # draft/released/superseded
    snapshot = Column(JSON)
    checks = Column(JSON)
    digest = Column(String(64))
    notes = Column(Text)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)
    released_at = Column(DateTime)


class Grounding(Base):
    __tablename__ = "groundings"
    id = Column(Integer, primary_key=True)
    aircraft_id = Column(Integer, ForeignKey("aircraft.id", ondelete="CASCADE"), index=True)
    reason = Column(Text)
    grounded_by = Column(Integer, ForeignKey("users.id"))
    grounded_at = Column(DateTime, default=utcnow)
    active = Column(Boolean, default=True)
    lifted_by = Column(Integer, ForeignKey("users.id"))
    lifted_at = Column(DateTime)
    lift_note = Column(Text)


# ───────────────────────── test campaigns ─────────────────────────
class Campaign(Rec, Base):
    __tablename__ = "campaigns"
    code = C(String(30), "Campaign ID", unique=True)
    name = C(String(160), "Campaign name", nullable=False)
    customer_id = FK("customers.id", "Customer")
    project_id = FK("projects.id", "Project")
    aircraft_id = FK("aircraft.id", "Aircraft", nullable=False)
    location = C(String(160), "Test location")
    lat = C(Float, "Site latitude")
    lon = C(Float, "Site longitude")
    responsible_engineer_id = FK("users.id", "Responsible engineer")
    personnel = C(JSON, "Flight-test personnel", widget="refs", ref="users", default=list)
    objectives = C(Text, "Campaign objectives")
    start_date = C(Date, "Start date")
    end_date = C(Date, "End date")
    weather = C(Text, "Weather conditions")
    environment = C(Text, "Environmental conditions")
    config_revision_id = C(Integer, "Hardware revision under test", ro=True)
    firmware_version = C(String(60), "Firmware version")
    software_release = C(String(60), "Software release")
    procedures = C(Text, "Test procedures")
    success_criteria = C(Text, "Success criteria")
    stage = C(Integer, "Lifecycle stage", default=0, ro=True)
    status = C(String(20), "Status", choices=["active", "complete", "cancelled"], default="active", ro=True)
    stage_log = C(JSON, "Stage history", default=list, hidden=True)


class RiskItem(Rec, Base):
    __tablename__ = "risk_items"
    campaign_id = FK("campaigns.id", "Campaign", nullable=False)
    hazard = C(String(200), "Hazard", nullable=False)
    cause = C(Text, "Cause")
    consequence = C(Text, "Consequence")
    likelihood = C(Integer, "Likelihood (1-5)", default=3)
    severity = C(Integer, "Severity (1-5)", default=3)
    mitigation = C(Text, "Mitigation")
    residual_likelihood = C(Integer, "Residual likelihood (1-5)")
    residual_severity = C(Integer, "Residual severity (1-5)")
    owner_id = FK("users.id", "Owner")


class TestCard(Rec, Base):
    __tablename__ = "test_cards"
    code = C(String(30), "Test ID", unique=True)
    campaign_id = FK("campaigns.id", "Campaign", nullable=False)
    title = C(String(200), "Title", nullable=False)
    category = C(String(60), "Validation area", choices=VALIDATION_CATEGORIES, nullable=False)
    objective = C(Text, "Test objective")
    aircraft_config = C(Text, "Aircraft configuration")
    preconditions = C(Text, "Preconditions")
    procedure = C(Text, "Test procedure")
    expected_results = C(Text, "Expected results")
    criteria = C(JSON, "Acceptance criteria", widget="criteria", default=list)
    measurements = C(JSON, "Measured parameters", default=dict, hidden=True)
    actual_results = C(Text, "Actual results")
    observations = C(Text, "Observations")
    deviations = C(Text, "Deviations")
    requires_evidence = C(Boolean, "Evidence attachment or flight log required", default=True)
    flight_log_id = C(Integer, "Linked flight log", ro=True)
    status = C(String(20), "Status", default="planned", ro=True)  # planned/executed/pass/fail/incomplete/deferred
    evaluation = C(JSON, "Evaluation", hidden=True)
    signed_by = C(Integer, "Signed by", ro=True, ref="users")
    signed_at = C(DateTime, "Signed at", ro=True)
    signature = C(String(64), "Signature digest", ro=True)
    retest_of_id = C(Integer, "Retest of", ro=True, ref="test_cards")


class Flight(Rec, Base):
    __tablename__ = "flights"
    code = C(String(30), "Flight ID", unique=True)
    aircraft_id = FK("aircraft.id", "Aircraft", nullable=False)
    source_class = C(String(12), "Flight class", choices=SOURCE_CLASSES, nullable=False, default="physical")
    date = C(DateTime, "Date / time (UTC)", nullable=False)
    duration_s = C(Float, "Duration", unit="s", default=0)
    pilot_id = FK("users.id", "Pilot / operator")
    campaign_id = FK("campaigns.id", "Campaign")
    test_card_id = FK("test_cards.id", "Test card")
    mission_id = FK("missions.id", "Mission")
    deployment_id = FK("deployments.id", "Deployment")
    demonstration_id = FK("demonstrations.id", "Demonstration")
    location = C(String(160), "Location")
    gate_status = C(String(20), "Safety gates", ro=True)
    gate_detail = C(JSON, "Gate detail", hidden=True)
    notes = C(Text, "Notes")


class Incident(Rec, Base):
    __tablename__ = "incidents"
    code = C(String(30), "Incident ID", unique=True)
    date = C(DateTime, "Date / time (UTC)", nullable=False)
    aircraft_id = FK("aircraft.id", "Aircraft")
    flight_id = FK("flights.id", "Flight")
    incident_type = C(String(40), "Type", choices=["Safety-gate violation", "Loss of link", "Loss of control", "Hard landing", "Fly-away",
                                                   "Battery event", "Airspace / boundary", "Ground handling", "Other"])
    severity = C(String(12), "Severity", choices=["critical", "major", "minor"], default="minor")
    description = C(Text, "Description", nullable=False)
    immediate_action = C(Text, "Immediate action")
    status = C(String(16), "Status", choices=["open", "investigating", "closed"], default="open")
    reported_by = FK("users.id", "Reported by", ro=True)


# ───────────────────────── missions ─────────────────────────
class Mission(Rec, Base):
    __tablename__ = "missions"
    code = C(String(30), "Mission ID", unique=True)
    name = C(String(160), "Name", nullable=False)
    aircraft_id = FK("aircraft.id", "Aircraft")
    campaign_id = FK("campaigns.id", "Campaign")
    description = C(Text, "Mission definition")
    home = C(JSON, "Home", default=dict, hidden=True)
    waypoints = C(JSON, "Waypoints", default=list, hidden=True)
    geofence = C(JSON, "Geofence", default=dict, hidden=True)
    emergency_sites = C(JSON, "Emergency landing sites", default=list, hidden=True)
    cruise_speed = C(Float, "Cruise speed", unit="m/s", default=8.0)
    environment = C(JSON, "Environment", default=dict, hidden=True)
    revision = C(Integer, "Revision", default=1, ro=True)
    status = C(String(20), "Status", default="draft", ro=True)  # draft/validated/sim_passed
    validation = C(JSON, "Validation", hidden=True)


class MissionRevision(Base):
    __tablename__ = "mission_revisions"
    id = Column(Integer, primary_key=True)
    mission_id = Column(Integer, ForeignKey("missions.id", ondelete="CASCADE"), index=True)
    number = Column(Integer)
    snapshot = Column(JSON)
    note = Column(Text)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)


class SimRun(Base):
    __tablename__ = "sim_runs"
    id = Column(Integer, primary_key=True)
    mission_id = Column(Integer, ForeignKey("missions.id", ondelete="CASCADE"), index=True)
    mission_revision = Column(Integer)
    aircraft_id = Column(Integer, ForeignKey("aircraft.id"), index=True)
    config_revision_id = Column(Integer)
    engine = Column(String(30))  # internal_kinematic / sitl
    result = Column(String(10))
    summary = Column(JSON)
    flight_log_id = Column(Integer)
    run_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)


# ───────────────────────── C2 infrastructure ─────────────────────────
class C2Equipment(Rec, Base):
    __tablename__ = "c2_equipment"
    code = C(String(30), "Equipment ID", unique=True)
    category = C(String(40), "Category", choices=C2_CATEGORIES, nullable=False)
    name = C(String(160), "Name", nullable=False)
    manufacturer = C(String(120), "Manufacturer")
    model = C(String(120), "Model")
    serial_number = C(String(80), "Serial number")
    software_version = C(String(60), "Software version")
    configuration = C(Text, "Configuration record")
    host = C(String(120), "Network address", help="Hostname or IP used for diagnostics")
    port = C(Integer, "TCP port", help="Optional service port for reachability test")
    status = C(String(20), "Status", choices=["serviceable", "unserviceable", "in_maintenance", "deployed"], default="serviceable")
    location = C(String(120), "Location")
    last_maintenance = C(Date, "Last maintenance")
    next_maintenance = C(Date, "Next maintenance due")
    notes = C(Text, "Deployment documentation / notes")


class LinkDiag(Base):
    __tablename__ = "link_diags"
    id = Column(Integer, primary_key=True)
    equipment_id = Column(Integer, ForeignKey("c2_equipment.id", ondelete="CASCADE"), index=True)
    ts = Column(DateTime, default=utcnow)
    result = Column(JSON)
    run_by = Column(Integer, ForeignKey("users.id"))


class TelemetryLink(Rec, Base):
    __tablename__ = "telemetry_links"
    name = C(String(120), "Name", nullable=False)
    transport = C(String(10), "Transport", choices=["udp", "tcp", "serial"], nullable=False, default="udp")
    address = C(String(120), "Address / COM port", help="udp: listen address (0.0.0.0) · tcp: remote host · serial: COM port")
    port = C(Integer, "Port", default=14550)
    baud = C(Integer, "Baud rate", default=57600)
    source_class = C(String(12), "Declared source", choices=["physical", "sitl"], nullable=False, default="sitl",
                     help="Declare whether the far end is a physical aircraft or a software-in-the-loop simulator")
    transmit = C(Boolean, "Transmit GCS heartbeat", default=False,
                 help="Off = receive-only monitor. On = this station sends heartbeats / timesync and may upload released missions. "
                      "An autopilot with GCS failsafe enabled may react when a transmitting station disconnects.")
    aircraft_id = FK("aircraft.id", "Aircraft")
    equipment_id = FK("c2_equipment.id", "C2 equipment")
    notes = C(Text, "Notes")


# ───────────────────────── deployments / demos ─────────────────────────
class Deployment(Rec, Base):
    __tablename__ = "deployments"
    code = C(String(30), "Deployment ID", unique=True)
    name = C(String(160), "Name", nullable=False)
    customer_id = FK("customers.id", "Customer")
    country = C(String(80), "Country")
    location = C(String(160), "Location")
    objectives = C(Text, "Deployment objectives")
    start_date = C(Date, "Start date")
    end_date = C(Date, "End date")
    aircraft_ids = C(JSON, "Aircraft inventory", widget="refs", ref="aircraft", default=list)
    equipment_ids = C(JSON, "Ground station inventory", widget="refs", ref="c2_equipment", default=list)
    personnel_ids = C(JSON, "Personnel", widget="refs", ref="users", default=list)
    spares = C(Text, "Spare components")
    tools = C(Text, "Tools and equipment")
    travel = C(Text, "Travel arrangements")
    site_requirements = C(Text, "Site requirements")
    emergency_procedures = C(Text, "Emergency procedures")
    weather_assessment = C(Text, "Weather assessment")
    status = C(String(20), "Status", choices=["planning", "ready", "deployed", "complete", "cancelled"], default="planning", ro=True)


class Permit(Rec, Base):
    __tablename__ = "permits"
    code = C(String(30), "Permit ID", unique=True)
    deployment_id = FK("deployments.id", "Deployment")
    campaign_id = FK("campaigns.id", "Campaign")
    permit_type = C(String(40), "Type", nullable=False, choices=["Regulatory approval", "Operational permission", "Site authorization",
                                                                "Frequency licence", "Insurance", "Customs / export"])
    authority = C(String(160), "Issuing authority / owner")
    reference = C(String(120), "Reference")
    location = C(String(160), "Location")
    valid_from = C(Date, "Valid from")
    valid_to = C(Date, "Valid to")
    status = C(String(12), "Status", choices=["applied", "granted", "denied"], default="applied")
    notes = C(Text, "Conditions / notes")


class Demonstration(Rec, Base):
    __tablename__ = "demonstrations"
    code = C(String(30), "Demonstration ID", unique=True)
    name = C(String(160), "Name", nullable=False)
    customer_id = FK("customers.id", "Customer", nullable=False)
    audience = C(Text, "Customer profile / audience")
    objectives = C(Text, "Demonstration objectives")
    scenario = C(Text, "Demonstration scenario")
    aircraft_id = FK("aircraft.id", "Aircraft")
    mission_id = FK("missions.id", "Mission")
    equipment_ids = C(JSON, "Equipment requirements", widget="refs", ref="c2_equipment", default=list)
    personnel_ids = C(JSON, "Personnel assignments", widget="refs", ref="users", default=list)
    scheduled_at = C(DateTime, "Scheduled (UTC)")
    location = C(String(160), "Location")
    safety_briefing = C(Text, "Safety briefing")
    presentation_notes = C(Text, "Technical presentation")
    acceptance_criteria = C(JSON, "Acceptance criteria", widget="acceptance", default=list)
    feedback = C(Text, "Customer feedback")
    feedback_score = C(Integer, "Feedback score (1-5)")
    results = C(Text, "Demonstration results")
    status = C(String(16), "Status", choices=["planned", "prepared", "completed", "cancelled"], default="planned")


# ───────────────────────── training ─────────────────────────
class Course(Rec, Base):
    __tablename__ = "courses"
    code = C(String(30), "Course ID", unique=True)
    title = C(String(200), "Title", nullable=False)
    category = C(String(60), "Category", choices=TRAINING_CATEGORIES, nullable=False)
    description = C(Text, "Description")
    validity_months = C(Integer, "Record validity (months)", default=24)
    pass_mark = C(Integer, "Pass mark (%)", default=80)
    active = C(Boolean, "Active", default=True)


class CourseModule(Rec, Base):
    __tablename__ = "course_modules"
    course_id = FK("courses.id", "Course", nullable=False)
    seq = C(Integer, "Order", default=1)
    title = C(String(200), "Title", nullable=False)
    kind = C(String(12), "Type", choices=["theory", "practical", "scenario"], default="theory")
    content = C(Text, "Content")
    diagram = C(String(40), "Technical diagram", choices=["", "multicopter_forces", "control_loop", "power_train", "c2_link", "preflight_flow"])


class QuizQuestion(Rec, Base):
    __tablename__ = "quiz_questions"
    course_id = FK("courses.id", "Course", nullable=False)
    seq = C(Integer, "Order", default=1)
    kind = C(String(12), "Type", choices=["theory", "scenario"], default="theory")
    text = C(Text, "Question", nullable=False)
    options = C(JSON, "Options", widget="tags", default=list)
    answer = C(Integer, "Correct option (0-based)", default=0)
    explanation = C(Text, "Explanation")


class Enrollment(Rec, Base):
    __tablename__ = "enrollments"
    course_id = FK("courses.id", "Course", nullable=False)
    student_id = FK("users.id", "Student", nullable=False)
    instructor_id = FK("users.id", "Instructor")
    status = C(String(14), "Status", default="enrolled", ro=True)  # enrolled/in_progress/completed/failed/withdrawn
    progress = C(JSON, "Modules completed", default=list, hidden=True)
    completed_at = C(DateTime, "Completed", ro=True)
    instructor_feedback = C(Text, "Instructor feedback")


class QuizAttempt(Base):
    __tablename__ = "quiz_attempts"
    id = Column(Integer, primary_key=True)
    enrollment_id = Column(Integer, ForeignKey("enrollments.id", ondelete="CASCADE"), index=True)
    answers = Column(JSON)
    score = Column(Float)
    passed = Column(Boolean)
    taken_at = Column(DateTime, default=utcnow)


class Attendance(Rec, Base):
    __tablename__ = "attendance"
    enrollment_id = FK("enrollments.id", "Enrollment", nullable=False)
    date = C(Date, "Date", nullable=False)
    session = C(String(120), "Session")
    present = C(Boolean, "Present", default=True)


class Qualification(Rec, Base):
    __tablename__ = "qualifications"
    user_id = FK("users.id", "Person", nullable=False)
    kind = C(String(30), "Record type", nullable=False, default="regulatory_licence",
             choices=["internal_training_record", "regulatory_licence", "medical", "other"],
             help="Internal training records are company records and are not aviation licences")
    title = C(String(200), "Title", nullable=False)
    issuer = C(String(160), "Issuing body")
    reference = C(String(120), "Reference / licence number")
    course_id = FK("courses.id", "Course", ro=True)
    issued_date = C(Date, "Issued")
    expiry_date = C(Date, "Expires")
    notes = C(Text, "Notes")


# ───────────────────────── maintenance ─────────────────────────
class MaintenanceTask(Rec, Base):
    __tablename__ = "maintenance_tasks"
    aircraft_id = FK("aircraft.id", "Aircraft", nullable=False)
    component_id = FK("components.id", "Component")
    title = C(String(200), "Task", nullable=False)
    task_type = C(String(12), "Type", choices=["scheduled", "condition"], default="scheduled")
    category = C(String(40), "Category", choices=MAINT_CATEGORIES, default="General")
    interval_hours = C(Float, "Interval (flight hours)")
    interval_cycles = C(Integer, "Interval (cycles)")
    interval_days = C(Integer, "Interval (days)")
    last_done_date = C(Date, "Last done", ro=True)
    last_done_hours = C(Float, "Hours at last accomplishment", ro=True)
    last_done_cycles = C(Integer, "Cycles at last accomplishment", ro=True)
    trigger_note = C(Text, "Condition trigger")
    active = C(Boolean, "Active", default=True)


class MaintenanceAction(Rec, Base):
    __tablename__ = "maintenance_actions"
    code = C(String(30), "Action ID", unique=True)
    aircraft_id = FK("aircraft.id", "Aircraft")
    component_id = FK("components.id", "Component")
    equipment_id = FK("c2_equipment.id", "C2 equipment")
    task_id = FK("maintenance_tasks.id", "Closes task")
    date = C(Date, "Date", nullable=False)
    action_type = C(String(20), "Action", nullable=False, default="inspection",
                    choices=["inspection", "repair", "replacement", "firmware_update", "calibration", "cleaning"])
    category = C(String(40), "Category", choices=MAINT_CATEGORIES, default="General")
    description = C(Text, "Work performed", nullable=False)
    findings = C(Text, "Findings")
    condition = C(String(16), "Condition found", choices=["serviceable", "monitor", "unserviceable"], default="serviceable")
    failure = C(Boolean, "Component failure", default=False, help="Counts towards reliability statistics")
    performed_by = FK("users.id", "Performed by", ro=True)
    hours_at_action = C(Float, "Aircraft hours", ro=True)
    cycles_at_action = C(Integer, "Aircraft cycles", ro=True)


# ───────────────────────── analysis / issues / reports ─────────────────────────
class FlightLog(Base):
    __tablename__ = "flight_logs"
    id = Column(Integer, primary_key=True)
    code = Column(String(30), unique=True)
    name = Column(String(200))
    aircraft_id = Column(Integer, ForeignKey("aircraft.id"), index=True)
    flight_id = Column(Integer, ForeignKey("flights.id"))
    mission_id = Column(Integer, ForeignKey("missions.id"))
    config_revision_id = Column(Integer)
    fmt = Column(String(20))
    source_class = Column(String(12))
    original_name = Column(String(255))
    stored_name = Column(String(80))
    data_file = Column(String(80))
    sha256 = Column(String(64))
    duration_s = Column(Float)
    metrics = Column(JSON)
    observations = Column(JSON)
    events = Column(JSON)
    imported_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=utcnow)


class Issue(Rec, Base):
    __tablename__ = "issues"
    code = C(String(30), "Issue ID", unique=True)
    title = C(String(200), "Title", nullable=False)
    aircraft_id = FK("aircraft.id", "Aircraft")
    hardware_revision = C(String(60), "Hardware revision")
    software_version = C(String(60), "Software version")
    campaign_id = FK("campaigns.id", "Test campaign")
    test_card_id = FK("test_cards.id", "Originating test card")
    flight_log_id = C(Integer, "Supporting telemetry (flight log)", ref="flight_logs")
    severity = C(String(12), "Severity", choices=["critical", "major", "minor", "observation"], nullable=False, default="minor")
    discipline = C(String(40), "Owning discipline", choices=DISCIPLINES)
    description = C(Text, "Description", nullable=False)
    assigned_to = FK("users.id", "Assigned engineer")
    reported_by = FK("users.id", "Reported by", ro=True)
    status = C(String(20), "Status", default="open", ro=True)  # open/analysis/corrective_action/verification/closed
    root_cause = C(Text, "Root-cause analysis")
    corrective_action = C(Text, "Corrective action")
    verification_test_card_id = FK("test_cards.id", "Verification test")
    closed_at = C(DateTime, "Closed", ro=True)


class Report(Base):
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True)
    code = Column(String(40), unique=True)
    report_type = Column(String(40), index=True)
    title = Column(String(240))
    subject_type = Column(String(40))
    subject_id = Column(Integer)
    revision = Column(Integer)
    author_id = Column(Integer, ForeignKey("users.id"))
    aircraft_code = Column(String(60))
    config_version = Column(String(60))
    approvals = Column(JSON)
    files = Column(JSON)
    created_at = Column(DateTime, default=utcnow)


class AssistantMessage(Base):
    __tablename__ = "assistant_messages"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    role = Column(String(12))
    content = Column(JSON)
    created_at = Column(DateTime, default=utcnow)
