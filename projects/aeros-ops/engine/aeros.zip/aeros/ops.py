"""Operations: command dashboard, C2 infrastructure diagnostics, field deployments and customer demonstrations."""
import re
import socket
import subprocess
import sys
import time
from datetime import timedelta

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session as Db

from . import approvals as ap, fleet, maint, models as m, testing
from .core import audit, current_user, internal_user, require, to_dict, today, user_names
from .db import get_db, utcnow
from .resources import REG, get_obj, hook

router = APIRouter(prefix="/api")


# ───────────── C2 infrastructure ─────────────
def run_diagnostics(host: str, port: int | None) -> dict:
    """Reachability diagnostics against a recorded network address: ICMP echo and optional TCP connect timing."""
    if not re.fullmatch(r"[A-Za-z0-9.\-:]{1,120}", host or ""):
        raise HTTPException(422, "The equipment has no valid network address recorded.")
    out = {"host": host, "port": port}
    try:
        out["resolved"] = socket.gethostbyname(host)
    except OSError as e:
        out.update(resolved=None, error=f"Name resolution failed: {e}")
        return out
    cmd = ["ping", "-n", "4", "-w", "1000", host] if sys.platform == "win32" else ["ping", "-c", "4", "-W", "1", host]
    try:
        kw = {"creationflags": 0x08000000} if sys.platform == "win32" else {}
        txt = subprocess.run(cmd, capture_output=True, text=True, timeout=15, **kw).stdout
        loss = re.search(r"(\d+)% (?:packet )?loss", txt)
        avg = re.search(r"Average = (\d+)ms", txt) or re.search(r"= [\d.]+/([\d.]+)/", txt)
        out["icmp"] = {"packet_loss_pct": int(loss.group(1)) if loss else None, "avg_ms": float(avg.group(1)) if avg else None}
    except (subprocess.SubprocessError, OSError) as e:
        out["icmp"] = {"error": str(e)}
    if port:
        times, errs = [], 0
        for _ in range(3):
            t0 = time.perf_counter()
            try:
                with socket.create_connection((host, int(port)), timeout=2):
                    times.append((time.perf_counter() - t0) * 1000)
            except OSError:
                errs += 1
        out["tcp"] = {"port": port, "connect_ms": round(sum(times) / len(times), 1) if times else None, "failures": errs, "attempts": 3}
    icmp_ok = out.get("icmp", {}).get("packet_loss_pct") == 0
    tcp_ok = out.get("tcp", {}).get("failures") == 0 if port else None
    out["verdict"] = "reachable" if (tcp_ok or (tcp_ok is None and icmp_ok)) else "degraded" if (icmp_ok or (out.get("tcp", {}).get("connect_ms"))) else "unreachable"
    return out


@router.post("/c2/{eid}/diagnose")
def diagnose(eid: int, u: m.User = Depends(require("flight_ops", "uav_eng", "operator", "flight_test")), db: Db = Depends(get_db)):
    eq = db.get(m.C2Equipment, eid)
    if not eq:
        raise HTTPException(404, "Equipment not found")
    res = run_diagnostics(eq.host, eq.port)
    d = m.LinkDiag(equipment_id=eid, result=res, run_by=u.id)
    db.add(d)
    audit(db, u, "c2_diagnose", "c2_equipment", eid, f"Network diagnostics on {eq.code}: {res.get('verdict', res.get('error'))}")
    db.commit()
    return to_dict(d)


@router.get("/c2/overview")
def c2_overview(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    from .telemetry import hub

    live = {r.link_id: r.snapshot() for r in hub.runners.values() if r.link_id}
    links = list(db.scalars(select(m.TelemetryLink)))
    rows = []
    for eq in db.scalars(select(m.C2Equipment).order_by(m.C2Equipment.code)):
        last = db.scalar(select(m.LinkDiag).where(m.LinkDiag.equipment_id == eq.id).order_by(m.LinkDiag.id.desc()))
        cl = db.scalar(select(m.Checklist).where(m.Checklist.kind == "c2_infrastructure", m.Checklist.subject_id == eq.id).order_by(m.Checklist.id.desc()))
        snaps = []
        for ln in links:
            if ln.equipment_id == eq.id and ln.id in live:
                s = live[ln.id]
                snaps.append({k: s[k] for k in ("key", "name", "source_class", "status", "age_s", "msg_rate", "packet_loss_pct", "rtt_ms", "interruptions", "bytes", "error")}
                             | {"rssi": s["state"].get("rssi"), "radio_noise": s["state"].get("radio_noise"), "rxerrors": s["state"].get("rxerrors")})
        days = (eq.next_maintenance - today()).days if eq.next_maintenance else None
        rows.append(dict(to_dict(eq), last_diag=to_dict(last) if last else None, live_links=snaps, maintenance_due_days=days,
                         checklist={"id": cl.id, "status": cl.status, "completed_at": cl.completed_at.isoformat() if cl.completed_at else None} if cl else None))
    return rows


@router.get("/c2/{eid}/history")
def c2_history(eid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    names = user_names(db)
    return {"diagnostics": [dict(to_dict(d), run_by_name=names.get(d.run_by)) for d in
                            db.scalars(select(m.LinkDiag).where(m.LinkDiag.equipment_id == eid).order_by(m.LinkDiag.id.desc()).limit(30))],
            "maintenance": [dict(to_dict(a), performed_by_name=names.get(a.performed_by)) for a in
                            db.scalars(select(m.MaintenanceAction).where(m.MaintenanceAction.equipment_id == eid).order_by(m.MaintenanceAction.date.desc()))]}


def _equipment_ok(db, cl):
    eq = db.get(m.C2Equipment, cl.subject_id)
    if eq.status not in ("serviceable", "deployed"):
        return "fail", f"Recorded status: {eq.status}"
    if eq.next_maintenance and eq.next_maintenance < today():
        return "fail", f"Maintenance overdue since {eq.next_maintenance}"
    return "ok", "Serviceable; maintenance not overdue"


ap.AUTO["equipment_serviceable"] = _equipment_ok


# ───────────── deployments ─────────────
def _dep_aircraft(db, dep):
    return [fleet.readiness(db, ac) for ac in db.scalars(select(m.Aircraft).where(m.Aircraft.id.in_(dep.aircraft_ids or [0])))]


def _auto_dep(fn):
    def wrapped(db, cl):
        dep = db.get(m.Deployment, cl.subject_id)
        bad = fn(db, dep)
        return ("fail", bad) if bad else ("ok", "Verified from platform records")

    return wrapped


def _d_aircraft(db, dep):
    rds = _dep_aircraft(db, dep)
    if not rds:
        return "No aircraft assigned to the deployment"
    bad = [f"{r['code']} ({'blocked: ' + r['blockers'][0]['text'] if r['blockers'] else 'no operational release'})" for r in rds
           if r["blockers"] or not r["operational_release"]]
    return "; ".join(bad)


def _d_gate(key):
    def fn(db, dep):
        rds = _dep_aircraft(db, dep)
        if not rds:
            return "No aircraft assigned to the deployment"
        return "; ".join(f"{r['code']}: gate not met" for r in rds if not next(g for g in r["gates"] if g["key"] == key)["ok"])

    return fn


def _d_gcs(db, dep):
    eqs = list(db.scalars(select(m.C2Equipment).where(m.C2Equipment.id.in_(dep.equipment_ids or [0]))))
    if not any(e.category == "Ground control station" for e in eqs):
        return "No ground control station assigned"
    return "; ".join(f"{e.code} is {e.status}" for e in eqs if e.status not in ("serviceable", "deployed"))


def _d_personnel(db, dep):
    if not dep.personnel_ids:
        return "No personnel assigned"
    names = user_names(db)
    return "; ".join(f"{names.get(p, '?')} has no current qualification record" for p in dep.personnel_ids if not testing.has_current_qualification(db, p))


def _d_permits(db, dep):
    permits = list(db.scalars(select(m.Permit).where(m.Permit.deployment_id == dep.id, m.Permit.status == "granted")))
    end = dep.end_date or today()
    cur = [p for p in permits if not p.valid_to or p.valid_to >= end]
    miss = []
    if not any(p.permit_type == "Site authorization" for p in cur):
        miss.append("no granted site authorization valid to the end of the deployment")
    if not any(p.permit_type in ("Regulatory approval", "Operational permission") for p in cur):
        miss.append("no granted regulatory approval / operational permission valid to the end of the deployment")
    return "; ".join(miss)


ap.AUTO.update(
    dep_aircraft=_auto_dep(_d_aircraft), dep_inspection=_auto_dep(_d_gate("inspection")), dep_firmware=_auto_dep(_d_gate("ground")),
    dep_spares=_auto_dep(lambda db, d: "" if (d.spares or "").strip() else "Spare component list is empty"), dep_gcs=_auto_dep(_d_gcs),
    dep_personnel=_auto_dep(_d_personnel), dep_permits=_auto_dep(_d_permits),
    dep_weather=_auto_dep(lambda db, d: "" if (d.weather_assessment or "").strip() else "No weather assessment recorded"),
    dep_emergency=_auto_dep(lambda db, d: "" if (d.emergency_procedures or "").strip() else "No emergency procedures recorded"))
ap.PRECOND["deployment_release"] = lambda db, dep, tag: (
    [] if ap.checklist_complete(db, "deployment_readiness", "deployment", dep.id) else ["The deployment readiness checklist is not complete."])


def _on_dep_release(db, a, dep, user):
    dep.status = "ready"


ap.ON_APPROVE["deployment_release"] = _on_dep_release


def deployment_detail_data(db: Db, dep: m.Deployment) -> dict:
    names = user_names(db)
    d = to_dict(dep)
    d["customer"] = getattr(db.get(m.Customer, dep.customer_id or 0), "name", None)
    d["aircraft"] = [{"id": r["aircraft_id"], "code": r["code"], "name": r["name"], "state": r["state"], "released": bool(r["operational_release"]),
                      "blockers": [b["text"] for b in r["blockers"]]} for r in _dep_aircraft(db, dep)]
    d["equipment"] = [to_dict(e) for e in db.scalars(select(m.C2Equipment).where(m.C2Equipment.id.in_(dep.equipment_ids or [0])))]
    d["personnel"] = [{"id": p, "name": names.get(p, "?"), "qualified": testing.has_current_qualification(db, p)} for p in dep.personnel_ids or []]
    d["permits"] = [dict(to_dict(p), expired=bool(p.valid_to and p.valid_to < today())) for p in db.scalars(select(m.Permit).where(m.Permit.deployment_id == dep.id))]
    cl = db.scalar(select(m.Checklist).where(m.Checklist.kind == "deployment_readiness", m.Checklist.subject_id == dep.id).order_by(m.Checklist.id.desc()))
    d["checklist"] = ap.checklist_out(db, cl) if cl else None
    d["approvals"] = [ap.approval_out(db, a, names) for a in db.scalars(
        select(m.Approval).where(m.Approval.subject_type == "deployment", m.Approval.subject_id == dep.id).order_by(m.Approval.id.desc()))]
    missing = [lbl for f, lbl in (("objectives", "Deployment objectives"), ("spares", "Spare components list"), ("tools", "Tools and equipment list"),
                                  ("travel", "Travel arrangements"), ("site_requirements", "Site requirements"), ("emergency_procedures", "Emergency procedures"),
                                  ("weather_assessment", "Weather assessment"), ("start_date", "Start date"), ("end_date", "End date")) if not getattr(dep, f)]
    perm = _d_permits(db, dep)
    if perm:
        missing.append("Permits: " + perm)
    d["missing_documentation"] = missing
    db.rollback()
    return d


@router.get("/deployments/{did}")
def deployment_detail(did: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    dep = db.get(m.Deployment, did)
    if not dep:
        raise HTTPException(404, "Deployment not found")
    return deployment_detail_data(db, dep)


@router.post("/deployments/{did}/status")
def deployment_status(did: int, data: dict = Body(...), u: m.User = Depends(require("flight_ops")), db: Db = Depends(get_db)):
    dep = db.get(m.Deployment, did)
    to = data.get("status")
    if not dep or to not in ("deployed", "complete", "cancelled", "planning"):
        raise HTTPException(422, "Invalid deployment or status")
    if to == "deployed" and not ap.valid_approval(db, "deployment_release", "deployment", did):
        raise HTTPException(409, "A deployment can only be marked deployed after an approved deployment release.")
    if to == "complete" and dep.status != "deployed":
        raise HTTPException(409, "Only a deployed deployment can be completed.")
    dep.status = to
    audit(db, u, "deployment_status", "deployment", did, f"Deployment {dep.code} → {to}")
    db.commit()
    return to_dict(dep)


# ───────────── demonstrations ─────────────
def _demo_aircraft(db, cl):
    demo = db.get(m.Demonstration, cl.subject_id)
    ac = db.get(m.Aircraft, demo.aircraft_id or 0)
    if not ac:
        return "fail", "No aircraft assigned"
    r = fleet.readiness(db, ac)
    if r["blockers"]:
        return "fail", r["blockers"][0]["text"]
    return ("ok", r["operational_release"]["text"]) if r["operational_release"] else ("fail", f"{ac.code} holds no operational release (state: {r['state']})")


ap.AUTO["demo_aircraft"] = _demo_aircraft


@hook("demonstrations", "before_save")
def _demo_before(db, user, obj, data, is_new, changes):
    crit = []
    for c in obj.acceptance_criteria or []:
        if isinstance(c, str):
            c = {"text": c, "met": None, "note": ""}
        if (c.get("text") or "").strip():
            crit.append({"text": c["text"].strip(), "met": c.get("met"), "note": c.get("note") or ""})
    obj.acceptance_criteria = crit
    if "status" in changes or is_new:
        if obj.status == "prepared" and (is_new or not ap.checklist_complete(db, "demo_preparation", "demonstration", obj.id)):
            raise HTTPException(409, "A demonstration is 'prepared' only when its preparation checklist is complete.")
        if obj.status == "completed":
            if not (obj.results or "").strip():
                raise HTTPException(409, "Record the demonstration results before completing it.")
            if any(c["met"] is None for c in crit) or not crit:
                raise HTTPException(409, "Every acceptance criterion must be assessed as met or not met before completion.")


@router.get("/demonstrations/{did}")
def demo_detail(did: int, u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    res = REG["demonstrations"]
    if u.role == "customer":
        demo = get_obj(db, res, did, u)
    else:
        demo = get_obj(db, res, did)
    names = user_names(db)
    ac = db.get(m.Aircraft, demo.aircraft_id or 0)
    ms = db.get(m.Mission, demo.mission_id or 0)
    d = to_dict(demo)
    d.update(customer=getattr(db.get(m.Customer, demo.customer_id), "name", None),
             aircraft={"id": ac.id, "code": ac.code, "name": ac.name, "aircraft_type": ac.aircraft_type, "model": ac.model, "manufacturer": ac.manufacturer,
                       "mtom_kg": ac.mtom_kg} if ac else None,
             mission={"id": ms.id, "code": ms.code, "name": ms.name, "home": ms.home, "waypoints": ms.waypoints, "geofence": ms.geofence} if ms else None,
             personnel=[names.get(p, "?") for p in demo.personnel_ids or []],
             equipment=[f"{e.code} · {e.name}" for e in db.scalars(select(m.C2Equipment).where(m.C2Equipment.id.in_(demo.equipment_ids or [0])))])
    if u.role != "customer":
        cl = db.scalar(select(m.Checklist).where(m.Checklist.kind == "demo_preparation", m.Checklist.subject_id == did).order_by(m.Checklist.id.desc()))
        d["checklist"] = ap.checklist_out(db, cl) if cl else None
        db.rollback()
    else:
        for k in ("presentation_notes",):
            d.pop(k, None)
    return d


# ───────────── operations command dashboard ─────────────
@router.get("/dashboard")
def dashboard(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    names = user_names(db)
    td = today()
    rd = [fleet.readiness(db, ac, names) for ac in db.scalars(select(m.Aircraft).order_by(m.Aircraft.code))]
    for r in rd:
        r["evidence"] = [e["text"] for g in r["gates"] for e in g["evidence"] if g["ok"]][-2:]
        r["next"] = next((g["evidence"][0]["text"] for g in r["gates"] if not g["ok"]), None)
    camps = list(db.scalars(select(m.Campaign).order_by(m.Campaign.id.desc())))
    acode = {r["aircraft_id"]: r["code"] for r in rd}

    def camp(c):
        return {"id": c.id, "code": c.code, "name": c.name, "aircraft": acode.get(c.aircraft_id), "location": c.location, "stage": c.stage,
                "stage_name": m.CAMPAIGN_STAGES[c.stage], "start_date": c.start_date.isoformat() if c.start_date else None,
                "end_date": c.end_date.isoformat() if c.end_date else None, "engineer": names.get(c.responsible_engineer_id)}

    active = [c for c in camps if c.status == "active"]
    alerts = []
    for ac in db.scalars(select(m.Aircraft)):
        alerts += maint.alerts(db, ac)
    issues = list(db.scalars(select(m.Issue).where(m.Issue.status != "closed")))
    quals = [q for q in db.scalars(select(m.Qualification).where(m.Qualification.expiry_date.is_not(None)))
             if q.expiry_date <= td + timedelta(days=60)]
    enr = list(db.scalars(select(m.Enrollment).where(m.Enrollment.status.in_(["enrolled", "in_progress"]))))
    courses = {c.id: c.title for c in db.scalars(select(m.Course))}
    deps = list(db.scalars(select(m.Deployment).where(m.Deployment.status.in_(["planning", "ready", "deployed"]))))
    demos = list(db.scalars(select(m.Demonstration).where(m.Demonstration.status.in_(["planned", "prepared"]))))
    assign: dict = {}
    for c in active:
        for p in set((c.personnel or []) + ([c.responsible_engineer_id] if c.responsible_engineer_id else [])):
            assign.setdefault(p, []).append({"type": "campaign", "id": c.id, "label": f"{c.code} · {c.name}"})
    for d in deps:
        for p in d.personnel_ids or []:
            assign.setdefault(p, []).append({"type": "deployment", "id": d.id, "label": f"{d.code} · {d.name}"})
    for d in demos:
        for p in d.personnel_ids or []:
            assign.setdefault(p, []).append({"type": "demonstration", "id": d.id, "label": f"{d.code} · {d.name}"})
    eq = dict(db.execute(select(m.C2Equipment.status, func.count()).group_by(m.C2Equipment.status)).all())
    comp = dict(db.execute(select(m.Component.status, func.count()).group_by(m.Component.status)).all())
    fw: dict = {}
    for ac in db.scalars(select(m.Aircraft)):
        fw.setdefault((ac.autopilot or "—", ac.autopilot_firmware or "not recorded", ac.software_version or "—"), []).append(ac.code)
    pending = [a for a in db.scalars(select(m.Approval).where(m.Approval.status == "requested").order_by(m.Approval.id))]
    states = {s: sum(1 for r in rd if r["state"] == s) for s in fleet.STATES}
    return {
        "readiness": [{k: r[k] for k in ("aircraft_id", "code", "name", "aircraft_type", "state", "evidence", "next", "revision", "drift", "flight_hours",
                                         "designated_campaign", "operational_release")} | {"blockers": [b["text"] for b in r["blockers"]],
                                                                                           "gates": [{"label": g["label"], "ok": g["ok"]} for g in r["gates"]]} for r in rd],
        "states": states, "active_aircraft": sum(1 for r in rd if r["state"] not in ("Grounded", "Maintenance required")), "aircraft_total": len(rd),
        "campaigns": {"upcoming": [camp(c) for c in active if c.stage < 8], "ongoing": [camp(c) for c in active if 8 <= c.stage <= 9],
                      "analysis": [camp(c) for c in active if c.stage >= 10], "completed": [camp(c) for c in camps if c.status == "complete"][:8]},
        "maintenance": sorted(alerts, key=lambda a: a["level"] != "overdue")[:20],
        "integration": [{"aircraft_id": r["aircraft_id"], "code": r["code"], "status": "No released configuration" if not r["revision"] else
                         "Configuration changed since release" if r["drift"] else f"Released rev {r['revision']['number']} ({r['revision']['label']})",
                         "ok": bool(r["revision"]) and not r["drift"]} for r in rd],
        "software": [{"autopilot": k[0], "firmware": k[1], "software": k[2], "aircraft": v} for k, v in sorted(fw.items())],
        "training": {"active_enrollments": [{"id": e.id, "student": names.get(e.student_id), "course": courses.get(e.course_id), "status": e.status} for e in enr][:12],
                     "expiring": [{"id": q.id, "person": names.get(q.user_id), "title": q.title, "kind": q.kind, "expiry_date": q.expiry_date.isoformat(),
                                   "expired": q.expiry_date < td} for q in sorted(quals, key=lambda q: q.expiry_date)][:12]},
        "deployments": [{"id": d.id, "code": d.code, "name": d.name, "country": d.country, "status": d.status,
                         "start_date": d.start_date.isoformat() if d.start_date else None} for d in deps],
        "demonstrations": [{"id": d.id, "code": d.code, "name": d.name, "status": d.status,
                            "scheduled_at": d.scheduled_at.isoformat() if d.scheduled_at else None} for d in demos],
        "issues": {"by_severity": {s: sum(1 for i in issues if i.severity == s) for s in ("critical", "major", "minor", "observation")},
                   "open": [{"id": i.id, "code": i.code, "title": i.title, "severity": i.severity, "status": i.status, "aircraft": acode.get(i.aircraft_id),
                             "assigned": names.get(i.assigned_to)} for i in sorted(issues, key=lambda i: ["critical", "major", "minor", "observation"].index(i.severity))][:12]},
        "incidents": [{"id": i.id, "code": i.code, "incident_type": i.incident_type, "severity": i.severity, "status": i.status, "date": i.date.isoformat(),
                       "aircraft": acode.get(i.aircraft_id)} for i in db.scalars(select(m.Incident).where(m.Incident.status != "closed").order_by(m.Incident.id.desc()).limit(10))],
        "equipment": {"c2": eq, "components": comp},
        "personnel": [{"id": p, "name": names.get(p, "?"), "assignments": a} for p, a in sorted(assign.items(), key=lambda kv: names.get(kv[0], ""))],
        "pending_approvals": [dict(ap.approval_out(db, a, names), can_decide=ap.can_decide(u, a) is None) for a in pending][:15],
        "activity": [{"ts": e.ts.isoformat(), "user": e.username, "summary": e.summary} for e in db.scalars(select(m.AuditLog).order_by(m.AuditLog.id.desc()).limit(12))],
        "generated_at": utcnow().isoformat(),
    }
