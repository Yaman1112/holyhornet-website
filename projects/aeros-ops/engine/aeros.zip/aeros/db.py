"""Database engine and session handling (SQLite standalone, PostgreSQL via AEROS_DB_URL)."""
from datetime import datetime, timezone

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from . import config


class Base(DeclarativeBase):
    pass


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None, microsecond=0)


_engine = None
SessionLocal = sessionmaker(autoflush=False, expire_on_commit=False)


def init_engine(url: str | None = None):
    global _engine
    config.ensure_dirs()
    url = url or config.DB_URL
    kw = {}
    if url.startswith("sqlite"):
        kw["connect_args"] = {"check_same_thread": False, "timeout": 30}
    _engine = create_engine(url, **kw)
    if url.startswith("sqlite"):

        @event.listens_for(_engine, "connect")
        def _pragma(dbapi, _rec):
            cur = dbapi.cursor()
            if not config.BROWSER:  # the in-memory file system of the browser edition has no shared-memory WAL
                cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.close()

    SessionLocal.configure(bind=_engine)
    from . import models  # noqa: F401  (register tables)

    Base.metadata.create_all(_engine)
    return _engine


def engine():
    return _engine


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
