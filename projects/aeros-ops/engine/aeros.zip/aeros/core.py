"""Authentication, role-based access control, audit trail, secrets and shared helpers."""
import ctypes
import hashlib
import hmac
import json
import secrets
import sys
from datetime import date, datetime, timedelta

from fastapi import Depends, Header, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session as Db

from . import config, models as m
from .db import get_db, utcnow

INTERNAL = ["admin", "flight_ops", "flight_test", "uav_eng", "instructor", "operator", "maintenance"]
SESSION_HOURS = 12


# ───────────── passwords & sessions ─────────────
def hash_password(pw: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, config.PBKDF2_ITER)
    return f"pbkdf2_sha256${config.PBKDF2_ITER}${salt.hex()}${dk.hex()}"


def verify_password(pw: str, stored: str | None) -> bool:
    try:
        _, iters, salt, dk = (stored or "").split("$")
        calc = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), int(iters))
        return hmac.compare_digest(calc.hex(), dk)
    except Exception:
        return False


def password_problem(pw: str) -> str | None:
    if len(pw or "") < 10:
        return "Password must be at least 10 characters."
    if pw.lower() == pw or not any(c.isdigit() for c in pw):
        return "Password must contain an upper-case letter and a digit."
    return None


def _th(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_session(db: Db, user: m.User) -> str:
    token = secrets.token_urlsafe(32)
    db.add(m.Session(token_hash=_th(token), user_id=user.id, expires_at=utcnow() + timedelta(hours=SESSION_HOURS)))
    return token


def user_from_token(db: Db, token: str | None) -> m.User | None:
    if not token:
        return None
    s = db.scalar(select(m.Session).where(m.Session.token_hash == _th(token)))
    if not s or s.expires_at < utcnow():
        return None
    u = db.get(m.User, s.user_id)
    return u if u and u.active and u.can_login else None


def current_user(authorization: str | None = Header(None), db: Db = Depends(get_db)) -> m.User:
    token = authorization[7:] if authorization and authorization.lower().startswith("bearer ") else None
    u = user_from_token(db, token)
    if not u:
        raise HTTPException(401, "Sign-in required")
    return u


def require(*roles: str):
    """Dependency: user must hold one of the roles (administrators always pass)."""

    def dep(u: m.User = Depends(current_user)) -> m.User:
        if u.role != "admin" and u.role not in roles:
            raise HTTPException(403, f"Your role ({m.ROLES.get(u.role, u.role)}) is not permitted to do this.")
        return u

    return dep


internal_user = require(*INTERNAL)


# ───────────── audit trail (hash chained) ─────────────
def audit(db: Db, user: m.User | None, action: str, entity: str, entity_id=None, summary: str = "", detail=None) -> None:
    prev = db.scalar(select(m.AuditLog.hash).order_by(m.AuditLog.id.desc()).limit(1)) or ""
    ts = utcnow()
    detail = json.loads(json.dumps(detail, default=str)) if detail is not None else None
    entity_id = str(entity_id) if entity_id is not None else None
    body = json.dumps([ts.isoformat(), user.id if user else None, action, entity, str(entity_id), summary, detail], sort_keys=True, default=str)
    h = hashlib.sha256((prev + body).encode()).hexdigest()
    db.add(m.AuditLog(ts=ts, user_id=user.id if user else None, username=user.username if user else "system", action=action,
                      entity=entity, entity_id=entity_id, summary=summary, detail=detail, prev_hash=prev, hash=h))
    db.flush()


def verify_audit_chain(db: Db) -> dict:
    prev, n = "", 0
    for r in db.scalars(select(m.AuditLog).order_by(m.AuditLog.id)):
        body = json.dumps([r.ts.isoformat(), r.user_id, r.action, r.entity, str(r.entity_id), r.summary, r.detail], sort_keys=True, default=str)
        if r.prev_hash != prev or hashlib.sha256((prev + body).encode()).hexdigest() != r.hash:
            return {"ok": False, "entries": n, "broken_at": r.id}
        prev, n = r.hash, n + 1
    return {"ok": True, "entries": n}


# ───────────── secrets (Windows DPAPI) ─────────────
class _Blob(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _dpapi(data: bytes, protect: bool) -> bytes:
    if sys.platform != "win32":
        raise RuntimeError("Encrypted credential storage requires Windows DPAPI")
    buf = ctypes.create_string_buffer(data, len(data))
    inp, out = _Blob(len(data), buf), _Blob()
    fn = ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out)):
        raise RuntimeError("DPAPI call failed")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


def set_setting(db: Db, key: str, value, secret: bool = False) -> None:
    row = db.get(m.Setting, key) or m.Setting(key=key)
    row.secret = secret
    row.value = _dpapi(str(value).encode(), True).hex() if secret and value else value
    db.add(row)


def get_setting(db: Db, key: str, default=None):
    row = db.get(m.Setting, key)
    if not row or row.value in (None, ""):
        return default
    if row.secret:
        try:
            return _dpapi(bytes.fromhex(row.value), False).decode()
        except Exception:
            return default
    return row.value


# ───────────── misc helpers ─────────────
def next_code(db: Db, model, prefix: str) -> str:
    n = (db.scalar(select(func.max(model.id))) or 0) + 1
    while True:
        code = f"{prefix}-{n:04d}"
        if not db.scalar(select(model.id).where(model.code == code)):
            return code
        n += 1


def jsonable(v):
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return v


def to_dict(obj, exclude=("password_hash",)) -> dict:
    return {c.name: jsonable(getattr(obj, c.name)) for c in obj.__table__.columns if c.name not in exclude}


def user_names(db: Db) -> dict:
    return {u.id: u.full_name for u in db.scalars(select(m.User))}


def today() -> date:
    return utcnow().date()
