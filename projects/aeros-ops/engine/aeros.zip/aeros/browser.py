"""Browser edition: the same FastAPI application inside Pyodide (CPython on WebAssembly) in a Web Worker.

The worker (frontend/public/engine/worker.js) unpacks the prepared demonstration data directory, calls ``boot()``
once, then ``request(method, path, headers_json, body)`` for every API call.

Differences from the desktop edition, all deliberate and stated in the interface:
* no threads and no sockets: MAVLink links (UDP / TCP / serial) are unavailable; the internal simulator runs
  in-process and is advanced by the telemetry status poll (see BrowserSim);
* no Windows DPAPI, so no API key can be stored: the assistant uses the deterministic records query;
* no Plotly bundle: flight-data reports come without the interactive HTML file;
* everything lives in the visitor's tab and is discarded on reload; nothing is sent anywhere.
"""
import json
import math
import os
import sqlite3
import time
from datetime import date, datetime

from . import config

_app = None
ANCHOR = "demo_anchor_date"


def _no_threads() -> None:
    import anyio.to_thread

    async def run_sync(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):  # noqa: ARG001
        return func(*args)

    anyio.to_thread.run_sync = run_sync


def shift_to_today(db_path: str) -> int:
    """Move every date / datetime column by whole days so the day the demonstration data was built becomes today."""
    from sqlalchemy import Date, DateTime

    from . import models  # noqa: F401
    from .db import Base

    con = sqlite3.connect(db_path)
    row = con.execute("select value from settings where key = ?", (ANCHOR,)).fetchone()
    if not row:
        con.close()
        return 0
    days = (datetime.utcnow().date() - date.fromisoformat(json.loads(row[0]))).days
    if days:
        mod = f"{days:+d} days"
        for table in Base.metadata.sorted_tables:
            sets = []
            for c in table.columns:
                if isinstance(c.type, DateTime):
                    sets.append(f"{c.name} = case when {c.name} is null then null else strftime('%Y-%m-%d %H:%M:%S', substr({c.name}, 1, 19), '{mod}') || substr({c.name}, 20) end")
                elif isinstance(c.type, Date):
                    sets.append(f"{c.name} = case when {c.name} is null then null else date({c.name}, '{mod}') end")
            if sets:
                con.execute(f"update {table.name} set {', '.join(sets)}")
        con.execute("update settings set value = ? where key = ?", (json.dumps(datetime.utcnow().date().isoformat()), ANCHOR))
        con.commit()
    con.close()
    return days


def _reseal_audit(days: int) -> None:
    """Shifting the demonstration dates changes every audit timestamp, which (correctly) breaks the hash chain.
    The browser edition recomputes the chain over the shifted entries and records that it did so."""
    import hashlib

    from sqlalchemy import select

    from . import models as m
    from .core import audit
    from .db import SessionLocal

    with SessionLocal() as db:
        prev = ""
        for r in db.scalars(select(m.AuditLog).order_by(m.AuditLog.id)):
            body = json.dumps([r.ts.isoformat(), r.user_id, r.action, r.entity, str(r.entity_id), r.summary, r.detail], sort_keys=True, default=str)
            r.prev_hash, r.hash = prev, hashlib.sha256((prev + body).encode()).hexdigest()
            prev = r.hash
        db.flush()
        audit(db, None, "demo_shift", "system", None, f"Browser edition: demonstration dataset dates moved {days:+d} day(s) to the visitor's date; audit chain re-sealed")
        db.commit()


def boot(data_dir: str) -> dict:
    global _app
    t = time.time()
    if not config.BROWSER or config.DATA_DIR.as_posix() != data_dir:
        raise RuntimeError("set AEROS_BROWSER=1 and AEROS_DATA_DIR before importing aeros")
    _no_threads()
    shifted = shift_to_today(os.path.join(data_dir, "aeros.db"))
    from .main import create_app

    _app = create_app()
    if shifted:
        _reseal_audit(shifted)
    return {"ok": True, "boot_s": round(time.time() - t, 2), "shifted_days": shifted}


async def request(method: str, path: str, headers_json: str = "{}", body=None) -> dict:
    if _app is None:
        raise RuntimeError("call boot() first")
    headers = json.loads(headers_json or "{}")
    p, _, qs = path.partition("?")
    raw = bytes(body) if body is not None and type(body).__name__ != "JsNull" else b""
    hdrs = [(k.lower().encode(), str(v).encode()) for k, v in headers.items()] + [(b"host", b"aeros.local")]
    if raw:
        hdrs.append((b"content-length", str(len(raw)).encode()))
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(), "scheme": "http", "path": p,
             "raw_path": p.encode(), "query_string": qs.encode(), "root_path": "", "headers": hdrs, "client": ("browser", 0), "server": ("aeros.local", 80)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": raw, "more_body": False}
        return {"type": "http.disconnect"}

    out = {"status": 500, "headers": [], "body": b""}
    chunks = []

    async def send(msg):
        if msg["type"] == "http.response.start":
            out["status"] = msg["status"]
            out["headers"] = [[k.decode(), v.decode()] for k, v in msg.get("headers", [])]
        elif msg["type"] == "http.response.body":
            chunks.append(msg.get("body", b""))

    await _app(scope, receive, send)
    out["body"] = b"".join(chunks)
    return out


def make_browser_sim(LinkRunner):
    """In-process stand-in for the MAVLink simulator link, sharing LinkRunner's warning rules, events and snapshot."""
    from . import flightdata as fd, simulator

    class BrowserSim(LinkRunner):
        def __init__(self, name, plan, params, faults, aircraft_id=None, autostart=True):
            super().__init__("sim", name, "in-process simulator (browser edition: no MAVLink transport)", "simulation", aircraft_id, transmit=True)
            self.sim = simulator.Sim(plan, params, faults, autostart=autostart)
            self.vehicle, self.uploaded = self, 0
            self.alive, self.wall = True, time.time()
            self.rec, self.k = None, 0
            self.last_mode = None

        # thread interface, without a thread
        def start(self):
            pass

        def is_alive(self):
            return self.alive

        def join(self, timeout=None):
            pass

        def stop(self):
            self.alive = False

        def start_recording(self, name):
            if self.rec is not None:
                raise ValueError("Already recording")
            self.rec, self.rec_start, self.rec_name, self.rec_file = fd.Recorder(), time.time(), name, True
            self.rec.info["autopilot"] = 0
            self.rec_t0 = self.sim.t

        def stop_recording(self):
            rec, self.rec, self.rec_file = self.rec, None, None
            return rec, self.rec_start, self.rec_name

        def advance(self):
            now = time.time()
            steps = int(min(now - self.wall, 1.0) / 0.02)
            self.wall = now
            sim, d = self.sim, math.degrees
            silent = False
            for _ in range(steps):
                sim.step(0.02)
                self.k += 1
                silent = sim.fault("link_loss")
                if self.rec is not None and not silent:
                    t = sim.t - self.rec_t0
                    self.rec.acc.append((t, *sim.acc))
                    if self.k % 5 == 0:
                        fix, sats, hdop = sim.gps()
                        for nm, v in (("lat", sim.lat), ("lon", sim.lon), ("alt", sim.alt0 + sim.h), ("rel_alt", sim.h), ("gs", math.hypot(sim.vn, sim.ve)),
                                      ("climb", -sim.vd), ("roll", d(sim.roll)), ("pitch", d(sim.pitch)), ("yaw", d(sim.yaw) % 360), ("voltage", sim.volt),
                                      ("current", sim.cur), ("remaining", sim.soc * 100), ("mah", sim.mah), ("batt_temp", sim.batt_temp), ("gps_fix", fix),
                                      ("sats", sats), ("hdop", hdop), ("xtrack", sim.xtrack)):
                            self.rec.add(nm, t, v)
                        for j, pwm in enumerate(sim.motors()):
                            self.rec.add(f"m{j + 1}", t, pwm)
                        self.rec.arrivals.append(t)
                for sev, text in sim.messages:
                    if not silent:
                        self.event("critical" if sev <= 2 else "warning" if sev <= 4 else "info", f"Autopilot: {text}")
                        if self.rec is not None:
                            self.rec.text(sim.t - self.rec_t0, text, sev)
                sim.messages.clear()
            if steps and not silent:
                fix, sats, hdop = sim.gps()
                mode = "STANDBY" if sim.phase == "DONE" else sim.phase
                if mode != self.last_mode:
                    if self.last_mode:
                        self.event("info", f"Flight mode {self.last_mode} → {mode}")
                    if self.rec is not None:
                        self.rec.mode(sim.t - self.rec_t0, mode)
                    self.last_mode = mode
                if self.last_rx and now - self.last_rx > 3.0:
                    self.interruptions += 1
                self.last_rx = self.last_hb = now
                self.count += steps
                self.rate = 50.0
                self.loss_pct, self.rtt_ms = 0.0, 0.0
                self.s.update(sysid=1, compid=1, autopilot="Generic (internal simulator)", autopilot_id=0,
                              vehicle_type="Fixed-wing" if sim.p.kind == "fixedwing" else "Quadrotor", armed=sim.phase not in ("STANDBY", "DONE"), mode=mode,
                              roll=round(d(sim.roll), 2), pitch=round(d(sim.pitch), 2), yaw=round(d(sim.yaw) % 360, 1), lat=sim.lat, lon=sim.lon,
                              alt=round(sim.alt0 + sim.h, 1), rel_alt=round(sim.h, 2), gs=round(math.hypot(sim.vn, sim.ve), 2), climb=round(-sim.vd, 2),
                              voltage=round(sim.volt, 2), current=round(sim.cur, 1), remaining=int(sim.soc * 100), batt_temp=round(sim.batt_temp, 1),
                              gps_fix=fix, sats=sats, hdop=hdop, sensors_present=["Gyro", "Accelerometer", "Magnetometer", "Barometer", "GPS"],
                              sensors_unhealthy=[] if fix >= 3 else ["GPS"])
            self._rules(now)

        def snapshot(self):
            snap = super().snapshot()
            snap["sim"] = {"phase": self.sim.phase, "uploaded": self.uploaded, "waypoint": self.sim.i, "waypoints": len(self.sim.wps)}
            snap["recording"]["active"] = self.rec is not None
            return snap

    return BrowserSim

