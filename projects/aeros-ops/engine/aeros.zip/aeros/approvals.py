"""Approvals, checklists, evidence attachments and comments — the evidence backbone of the platform."""
import hashlib
import secrets
from datetime import timedelta

from fastapi import APIRouter, Body, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import config, models as m, reference
from .core import audit, current_user, internal_user, to_dict, user_names
from .db import get_db, utcnow

router = APIRouter(prefix="/api")

SUBJECTS = {
    "aircraft": m.Aircraft, "campaign": m.Campaign, "config_revision": m.ConfigRevision, "issue": m.Issue, "mission": m.Mission,
    "deployment": m.Deployment, "assistant_message": m.AssistantMessage, "test_card": m.TestCard, "demonstration": m.Demonstration,
    "enrollment": m.Enrollment, "c2_equipment": m.C2Equipment, "flight": m.Flight, "component": m.Component, "flight_log": m.FlightLog,
    "incident": m.Incident, "permit": m.Permit, "maintenance_action": m.MaintenanceAction, "telemetry_link": m.TelemetryLink,
}

ENGS = ["flight_ops", "flight_test", "uav_eng"]
# kind -> (label, subject type, deciding roles, independent reviewer required)
KINDS = {
    "config_release": ("Configuration release", "config_revision", ["uav_eng", "flight_ops"], False),
    "inspection": ("Aircraft inspection sign-off", "aircraft", ["maintenance", "uav_eng", "flight_ops"], False),
    "ground_validation": ("Ground validation sign-off", "aircraft", ENGS, False),
    "simulation_validation": ("Simulation validation sign-off", "aircraft", ENGS, False),
    "engineering_review": ("Engineering review", "campaign", ENGS, False),
    "risk_assessment": ("Risk assessment acceptance", "campaign", ["flight_ops"], True),
    "flight_authorization": ("Flight-test authorization", "campaign", ["flight_ops"], True),
    "campaign_acceptance": ("Campaign acceptance", "campaign", ["flight_ops"], True),
    "release_decision": ("Operational release decision", "aircraft", ["flight_ops"], True),
    "issue_closure": ("Issue closure", "issue", ENGS, True),
    "physical_mission_release": ("Physical mission release", "mission", ["flight_ops"], True),
    "independent_safety_check": ("Independent safety check", "mission", ["flight_test", "flight_ops", "operator", "maintenance"], True),
    "deployment_release": ("Deployment release", "deployment", ["flight_ops"], True),
    "ai_recommendation_review": ("AI recommendation review", "assistant_message", ENGS + ["maintenance"], False),
}
PRECOND = {}  # kind -> fn(db, subject, tag) -> list[str] of unmet preconditions
ON_APPROVE = {}  # kind -> fn(db, approval, subject, user)
DECIDE_CHECK = {}  # kind -> fn(approval, user) -> reason the user may not decide, or None
AUTO = {}  # checklist auto_key -> fn(db, checklist) -> (status, note)


def subject(db: Db, stype: str, sid: int):
    model = SUBJECTS.get(stype)
    obj = db.get(model, sid) if model else None
    if not obj:
        raise HTTPException(404, f"{stype} {sid} not found")
    return obj


def subject_label(db: Db, stype: str, sid: int) -> str:
    model = SUBJECTS.get(stype)
    obj = db.get(model, sid) if model else None
    if not obj:
        return f"{stype} #{sid}"
    if stype == "config_revision":
        ac = db.get(m.Aircraft, obj.aircraft_id)
        return f"{ac.code if ac else '?'} rev {obj.number} ({obj.label or '-'})"
    code = getattr(obj, "code", None)
    name = getattr(obj, "name", None) or getattr(obj, "title", None)
    return " · ".join(str(x) for x in (code, name) if x) or f"{stype} #{sid}"


def approval_out(db: Db, a: m.Approval, names=None) -> dict:
    names = names or user_names(db)
    d = to_dict(a)
    d.update(kind_label=KINDS.get(a.kind, (a.kind,))[0], subject_label=subject_label(db, a.subject_type, a.subject_id),
             requested_by_name=names.get(a.requested_by), decided_by_name=names.get(a.decided_by),
             expired=bool(a.expires_at and a.expires_at < utcnow()))
    return d


def valid_approval(db: Db, kind: str, stype: str, sid: int, tag: str | None = None, revision_id: int | None = None) -> m.Approval | None:
    """Latest approved, unexpired approval of this kind (optionally bound to a configuration revision)."""
    st = select(m.Approval).where(m.Approval.kind == kind, m.Approval.subject_type == stype, m.Approval.subject_id == sid,
                                  m.Approval.status == "approved")
    if tag is not None:
        st = st.where(m.Approval.tag == tag)
    if revision_id is not None:
        st = st.where(m.Approval.config_revision_id == revision_id)
    for a in db.scalars(st.order_by(m.Approval.id.desc())):
        if not a.expires_at or a.expires_at >= utcnow():
            return a
    return None


def can_decide(u: m.User, a: m.Approval) -> str | None:
    label, _, roles, independent = KINDS[a.kind]
    if u.role != "admin" and u.role not in roles:
        return f"{label} must be decided by: {', '.join(m.ROLES[r] for r in roles)}."
    if independent and a.requested_by == u.id:
        return f"{label} requires an independent reviewer — it cannot be decided by the person who requested it."
    if a.kind in DECIDE_CHECK:
        return DECIDE_CHECK[a.kind](a, u)
    return None


@router.get("/approvals")
def list_approvals(subject_type: str | None = None, subject_id: int | None = None, status: str | None = None, kind: str | None = None,
                   mine: bool = False, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    st = select(m.Approval)
    if subject_type:
        st = st.where(m.Approval.subject_type == subject_type)
    if subject_id is not None:
        st = st.where(m.Approval.subject_id == subject_id)
    if status:
        st = st.where(m.Approval.status == status)
    if kind:
        st = st.where(m.Approval.kind == kind)
    names = user_names(db)
    rows = []
    for a in db.scalars(st.order_by(m.Approval.id.desc()).limit(500)):
        d = approval_out(db, a, names)
        d["can_decide"] = a.status == "requested" and can_decide(u, a) is None
        if mine and not d["can_decide"]:
            continue
        rows.append(d)
    return rows


@router.get("/approval-kinds")
def kinds(u: m.User = Depends(internal_user)):
    return {k: {"label": v[0], "subject": v[1], "roles": [m.ROLES[r] for r in v[2]], "independent": v[3]} for k, v in KINDS.items()}


@router.post("/approvals")
def request_approval(data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    kind, sid, tag = data.get("kind"), data.get("subject_id"), data.get("tag")
    if kind not in KINDS:
        raise HTTPException(422, "Unknown approval kind")
    stype = KINDS[kind][1]
    subj = subject(db, stype, sid)
    dup = db.scalar(select(m.Approval).where(m.Approval.kind == kind, m.Approval.subject_type == stype, m.Approval.subject_id == sid,
                                             m.Approval.status == "requested", m.Approval.tag == tag))
    if dup:
        raise HTTPException(409, "An approval request of this kind is already pending.")
    unmet = PRECOND[kind](db, subj, tag) if kind in PRECOND else []
    if unmet:
        raise HTTPException(409, {"message": f"{KINDS[kind][0]} cannot be requested yet — required evidence is missing.", "unmet": unmet})
    rev = None
    if stype == "aircraft":
        rev = subj.current_revision_id
    elif stype == "campaign":
        rev = subj.config_revision_id
    elif stype == "config_revision":
        rev = subj.id
    a = m.Approval(kind=kind, subject_type=stype, subject_id=sid, tag=tag, config_revision_id=rev, requested_by=u.id,
                   request_note=data.get("note"), evidence=data.get("evidence"))
    if data.get("valid_days"):
        a.expires_at = utcnow() + timedelta(days=int(data["valid_days"]))
    db.add(a)
    db.flush()
    audit(db, u, "approval_request", stype, sid, f"Requested {KINDS[kind][0].lower()} for {subject_label(db, stype, sid)}", {"approval": a.id})
    db.commit()
    return approval_out(db, a)


@router.post("/approvals/{aid}/decide")
def decide(aid: int, data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    a = db.get(m.Approval, aid)
    if not a or a.status != "requested":
        raise HTTPException(404, "No pending approval request")
    decision = data.get("decision")
    if decision not in ("approved", "rejected"):
        raise HTTPException(422, "decision must be approved or rejected")
    why = can_decide(u, a)
    if why:
        raise HTTPException(403, why)
    if decision == "rejected" and not (data.get("note") or "").strip():
        raise HTTPException(422, "A rejection must state a reason.")
    subj = subject(db, a.subject_type, a.subject_id)
    if decision == "approved" and a.kind in PRECOND:
        unmet = PRECOND[a.kind](db, subj, a.tag)
        if unmet:
            raise HTTPException(409, {"message": "The evidence this request relied on is no longer complete.", "unmet": unmet})
    a.status, a.decided_by, a.decided_at, a.decision_note = decision, u.id, utcnow(), data.get("note")
    if decision == "approved" and a.kind in ON_APPROVE:
        ON_APPROVE[a.kind](db, a, subj, u)
    audit(db, u, f"approval_{decision}", a.subject_type, a.subject_id,
          f"{KINDS[a.kind][0]} {decision} for {subject_label(db, a.subject_type, a.subject_id)}", {"approval": a.id, "note": a.decision_note})
    db.commit()
    return approval_out(db, a)


@router.post("/approvals/{aid}/withdraw")
def withdraw(aid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    a = db.get(m.Approval, aid)
    if not a or a.status != "requested":
        raise HTTPException(404, "No pending approval request")
    if a.requested_by != u.id and u.role != "admin":
        raise HTTPException(403, "Only the requester can withdraw a request.")
    a.status = "withdrawn"
    audit(db, u, "approval_withdraw", a.subject_type, a.subject_id, f"Withdrew {KINDS[a.kind][0].lower()} request", {"approval": a.id})
    db.commit()
    return {"ok": True}


# ───────────── checklists ─────────────
def refresh_auto(db: Db, cl: m.Checklist, items: list) -> None:
    for it in items:
        if it.auto_key and it.auto_key in AUTO and cl.status != "complete":
            it.status, it.note = AUTO[it.auto_key](db, cl)


def checklist_out(db: Db, cl: m.Checklist) -> dict:
    items = list(db.scalars(select(m.ChecklistItem).where(m.ChecklistItem.checklist_id == cl.id).order_by(m.ChecklistItem.seq)))
    refresh_auto(db, cl, items)
    names = user_names(db)
    d = to_dict(cl)
    d["subject_label"] = subject_label(db, cl.subject_type, cl.subject_id)
    d["items"] = [dict(to_dict(i), signed_by_name=names.get(i.signed_by)) for i in items]
    d["done"] = sum(1 for i in items if i.status in ("ok", "na"))
    d["failed"] = sum(1 for i in items if i.status == "fail")
    d["total"] = len(items)
    return d


def checklist_complete(db: Db, kind: str, stype: str, sid: int, revision_id: int | None = None) -> m.Checklist | None:
    """Latest completed checklist of this kind for the subject with every item OK / N/A."""
    st = select(m.Checklist).where(m.Checklist.kind == kind, m.Checklist.subject_type == stype, m.Checklist.subject_id == sid,
                                   m.Checklist.status == "complete")
    if revision_id is not None:
        st = st.where(m.Checklist.config_revision_id == revision_id)
    return db.scalar(st.order_by(m.Checklist.id.desc()))


@router.get("/checklist-templates")
def templates(u: m.User = Depends(internal_user)):
    return {k: {"title": v["title"], "subject": v["subject"], "count": len(v["items"])} for k, v in reference.CHECKLISTS.items()}


@router.post("/checklists")
def create_checklist(data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    kind, sid = data.get("kind"), data.get("subject_id")
    tpl = reference.CHECKLISTS.get(kind)
    if not tpl:
        raise HTTPException(422, "Unknown checklist")
    stype = tpl["subject"]
    subj = subject(db, stype, sid)
    rev = subj.current_revision_id if stype == "aircraft" else None
    open_ = db.scalar(select(m.Checklist).where(m.Checklist.kind == kind, m.Checklist.subject_type == stype, m.Checklist.subject_id == sid,
                                                m.Checklist.status == "open"))
    if open_:
        return checklist_out(db, open_)
    cl = m.Checklist(kind=kind, title=tpl["title"], subject_type=stype, subject_id=sid, config_revision_id=rev, created_by=u.id)
    db.add(cl)
    db.flush()
    for i, it in enumerate(tpl["items"]):
        cat, label, auto = (it + (None,))[:3]
        db.add(m.ChecklistItem(checklist_id=cl.id, seq=i + 1, category=cat, label=label, auto_key=auto))
    audit(db, u, "checklist_open", stype, sid, f"Opened checklist: {tpl['title']}", {"checklist": cl.id})
    db.commit()
    return checklist_out(db, cl)


@router.get("/checklists")
def list_checklists(subject_type: str, subject_id: int, kind: str | None = None, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    st = select(m.Checklist).where(m.Checklist.subject_type == subject_type, m.Checklist.subject_id == subject_id)
    if kind:
        st = st.where(m.Checklist.kind == kind)
    res = [checklist_out(db, c) for c in db.scalars(st.order_by(m.Checklist.id.desc()))]
    db.rollback()  # auto-evaluated values are display only until an item is signed
    return res


@router.post("/checklist-items/{iid}")
def sign_item(iid: int, data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    it = db.get(m.ChecklistItem, iid)
    cl = db.get(m.Checklist, it.checklist_id) if it else None
    if not it or not cl:
        raise HTTPException(404, "Checklist item not found")
    if cl.status == "complete":
        raise HTTPException(409, "This checklist is complete and locked. Open a new one to re-inspect.")
    status = data.get("status")
    if status not in ("ok", "fail", "na", "pending"):
        raise HTTPException(422, "status must be ok, fail, na or pending")
    if it.auto_key:
        raise HTTPException(409, "This item is evaluated automatically from platform records and cannot be signed by hand.")
    if status in ("fail", "na") and not (data.get("note") or "").strip():
        raise HTTPException(422, "A note is required when an item is failed or marked not applicable.")
    it.status, it.note = status, data.get("note")
    it.signed_by, it.signed_at = (u.id, utcnow()) if status != "pending" else (None, None)
    db.flush()
    items = list(db.scalars(select(m.ChecklistItem).where(m.ChecklistItem.checklist_id == cl.id)))
    refresh_auto(db, cl, items)
    if all(i.status in ("ok", "na") for i in items):
        cl.status, cl.completed_at = "complete", utcnow()
    audit(db, u, "checklist_sign", cl.subject_type, cl.subject_id, f"{cl.title}: item {it.seq} → {status}", {"checklist": cl.id, "item": it.id})
    db.commit()
    return checklist_out(db, cl)


# ───────────── attachments & comments ─────────────
@router.post("/attachments")
async def upload(subject_type: str = Form(...), subject_id: int = Form(...), description: str = Form(""), file: UploadFile = File(...),
                 u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    subject(db, subject_type, subject_id)
    data = await file.read()
    if not data:
        raise HTTPException(422, "The file is empty.")
    stored = secrets.token_hex(16)
    (config.sub("attachments") / stored).write_bytes(data)
    a = m.Attachment(subject_type=subject_type, subject_id=subject_id, filename=file.filename, stored_name=stored, size=len(data),
                     sha256=hashlib.sha256(data).hexdigest(), content_type=file.content_type, description=description, uploaded_by=u.id)
    db.add(a)
    db.flush()
    audit(db, u, "attach", subject_type, subject_id, f"Attached evidence file {file.filename}", {"attachment": a.id, "sha256": a.sha256})
    db.commit()
    return to_dict(a)


def attachments_of(db: Db, stype: str, sid: int) -> list:
    return list(db.scalars(select(m.Attachment).where(m.Attachment.subject_type == stype, m.Attachment.subject_id == sid).order_by(m.Attachment.id)))


@router.get("/attachments")
def list_attachments(subject_type: str, subject_id: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    names = user_names(db)
    return [dict(to_dict(a), uploaded_by_name=names.get(a.uploaded_by)) for a in attachments_of(db, subject_type, subject_id)]


@router.get("/attachments/{aid}/download")
def download(aid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    a = db.get(m.Attachment, aid)
    p = config.sub("attachments") / a.stored_name if a else None
    if not a or not p.exists():
        raise HTTPException(404, "Attachment not found")
    return FileResponse(p, filename=a.filename, media_type=a.content_type or "application/octet-stream")


@router.delete("/attachments/{aid}")
def delete_attachment(aid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    a = db.get(m.Attachment, aid)
    if not a:
        raise HTTPException(404, "Attachment not found")
    if a.uploaded_by != u.id and u.role != "admin":
        raise HTTPException(403, "Only the uploader or an administrator can remove evidence.")
    if a.subject_type == "test_card" and db.get(m.TestCard, a.subject_id).signed_at:
        raise HTTPException(409, "Evidence on a signed test card cannot be removed.")
    (config.sub("attachments") / a.stored_name).unlink(missing_ok=True)
    audit(db, u, "detach", a.subject_type, a.subject_id, f"Removed evidence file {a.filename}", {"sha256": a.sha256})
    db.delete(a)
    db.commit()
    return {"ok": True}


@router.get("/comments")
def comments(subject_type: str, subject_id: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    names = user_names(db)
    roles = {x.id: x for x in db.scalars(select(m.User))}
    rows = db.scalars(select(m.Comment).where(m.Comment.subject_type == subject_type, m.Comment.subject_id == subject_id).order_by(m.Comment.id))
    return [dict(to_dict(c), user_name=names.get(c.user_id), discipline=getattr(roles.get(c.user_id), "discipline", None),
                 role=m.ROLES.get(getattr(roles.get(c.user_id), "role", ""), "")) for c in rows]


@router.post("/comments")
def add_comment(data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    subject(db, data.get("subject_type"), data.get("subject_id"))
    if not (data.get("body") or "").strip():
        raise HTTPException(422, "Comment is empty")
    c = m.Comment(subject_type=data["subject_type"], subject_id=data["subject_id"], user_id=u.id, body=data["body"].strip())
    db.add(c)
    db.commit()
    return to_dict(c)
