"""AEROS OPS PRO application: API, WebSocket telemetry and the bundled web interface."""
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse

from . import config, db


def create_app() -> FastAPI:
    config.ensure_dirs()
    from . import admin

    restored = admin.apply_pending_restore() if config.DB_URL.startswith("sqlite") else None
    db.init_engine()
    from . import analysis, approvals, assistant, fleet, maint, missions, ops, reports, resources, telemetry, testing, training

    analysis.cleanup_temp()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        yield
        telemetry.hub.shutdown()

    app = FastAPI(title=config.APP_NAME, version=config.VERSION, docs_url="/api/docs", openapi_url="/api/openapi.json", redoc_url=None, lifespan=lifespan)
    app.state.restored_from = restored
    for mod in (admin, resources, approvals, fleet, maint, testing, missions, analysis, telemetry, ops, training, reports, assistant):
        app.include_router(mod.router)

    @app.exception_handler(HTTPException)
    async def http_err(request: Request, exc: HTTPException):
        d = exc.detail
        body = {"message": d["message"], "unmet": d.get("unmet", [])} if isinstance(d, dict) else {"message": str(d)}
        return JSONResponse(body, status_code=exc.status_code)

    static = config.STATIC_DIR

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path.startswith(("api/", "ws/")):
            raise HTTPException(404, "Not found")
        f = (static / path).resolve()
        if path and static.resolve() in f.parents and f.is_file():
            return FileResponse(f)
        index = static / "index.html"
        if index.exists():
            return FileResponse(index, headers={"Cache-Control": "no-store"})
        return JSONResponse({"message": "The web interface has not been built. Run `npm run build` in aeros_ops/frontend, or use the dev server."}, status_code=503)

    return app


app = None


def get_app() -> FastAPI:
    global app
    if app is None:
        app = create_app()
    return app
