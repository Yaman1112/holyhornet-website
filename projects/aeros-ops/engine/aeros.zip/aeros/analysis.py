"""Post-flight engineering analysis: log import, metrics, observations, series, comparison and export."""
import csv
import hashlib
import io
import secrets
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import config, fleet, flightdata as fd, models as m
from .core import audit, internal_user, next_code, require, to_dict, user_names
from .db import get_db

router = APIRouter(prefix="/api")
ANALYSTS = ("flight_ops", "flight_test", "uav_eng", "operator", "maintenance")


def _discard(p: Path) -> None:
    """Delete a temporary import file; a parser that failed mid-read may still hold it open on Windows."""
    import gc

    for _ in range(2):
        try:
            p.unlink(missing_ok=True)
            return
        except PermissionError:
            gc.collect()
    # still locked: it is removed by cleanup_temp() at the next start


def cleanup_temp() -> None:
    for d in ("flightlogs", "recordings"):
        for f in config.sub(d).glob("_import_*"):
            try:
                f.unlink()
            except OSError:
                pass


def planned_path(ms) -> list:
    """The path the aircraft is expected to fly: home, each waypoint, and back to home (return to launch)."""
    home = ms.home or {}
    h = [{"lat": home["lat"], "lon": home["lon"]}] if home.get("lat") is not None else []
    return h + list(ms.waypoints or []) + h


def _cells(db: Db, aircraft_id) -> int | None:
    if not aircraft_id:
        return None
    for c in fleet.installed(db, aircraft_id):
        if c.category == "Battery":
            try:
                return int(float((c.specs or {}).get("cells")))
            except (TypeError, ValueError):
                return None
    return None


def store_log(db: Db, user, rec: fd.Recorder, fmt: str, source_class: str, name: str, aircraft_id=None, mission_id=None, flight_id=None,
              original: bytes | None = None, original_name: str | None = None, extra_events: list | None = None) -> m.FlightLog:
    norm = rec.finalize()
    ms = db.get(m.Mission, mission_id) if mission_id else None
    metrics = fd.compute_metrics(norm, planned_path(ms) if ms else None)
    events = norm["events"] + (extra_events or [])
    events.sort(key=lambda e: e["t"])
    ac = db.get(m.Aircraft, aircraft_id) if aircraft_id else None
    stored = secrets.token_hex(12)
    fd.save_norm(norm, config.sub("flightlogs") / f"{stored}.npz")
    if original is not None:
        (config.sub("flightlogs") / f"{stored}.orig").write_bytes(original)
    log = m.FlightLog(code=next_code(db, m.FlightLog, "LOG"), name=name, aircraft_id=aircraft_id, flight_id=flight_id, mission_id=mission_id,
                      config_revision_id=ac.current_revision_id if ac else None, fmt=fmt, source_class=source_class, original_name=original_name,
                      stored_name=f"{stored}.orig" if original is not None else None, data_file=f"{stored}.npz",
                      sha256=hashlib.sha256(original).hexdigest() if original is not None else None, duration_s=metrics.get("duration_s"),
                      metrics=metrics, observations=fd.observations(metrics, _cells(db, aircraft_id)), events=events,
                      imported_by=user.id if user else None)
    db.add(log)
    db.flush()
    return log


def log_out(db: Db, log: m.FlightLog, full: bool = False) -> dict:
    d = to_dict(log)
    ac = db.get(m.Aircraft, log.aircraft_id) if log.aircraft_id else None
    rev = db.get(m.ConfigRevision, log.config_revision_id) if log.config_revision_id else None
    d.update(aircraft=ac.code if ac else None, format_label=fd.FORMAT_LABEL.get(log.fmt, log.fmt),
             revision=f"rev {rev.number} ({rev.label})" if rev else None,
             findings={lvl: sum(1 for o in log.observations or [] if o["level"] == lvl) for lvl in ("critical", "warning")})
    if not full:
        for k in ("metrics", "observations", "events"):
            d.pop(k, None)
    else:
        d["metric_table"] = [{"key": k, "label": fd.METRICS[k][0], "unit": fd.METRICS[k][1], "area": fd.METRICS[k][2], "value": v}
                             for k, v in (log.metrics or {}).items() if k in fd.METRICS]
        d["channels"] = (log.metrics or {}).get("_channels", [])
        d["spectrum"] = (log.metrics or {}).get("_vib_spectrum")
        d["missing_areas"] = sorted({a for _, _, a in fd.METRICS.values()} - {x["area"] for x in d["metric_table"]})
    return d


@router.get("/metrics")
def metric_catalogue(u: m.User = Depends(internal_user)):
    return [{"key": k, "label": v[0], "unit": v[1], "area": v[2]} for k, v in fd.METRICS.items()]


@router.post("/logs/import")
async def import_log(file: UploadFile = File(...), name: str = Form(""), source_class: str = Form("physical"), aircraft_id: int | None = Form(None),
                     flight_id: int | None = Form(None), mission_id: int | None = Form(None),
                     u: m.User = Depends(require(*ANALYSTS)), db: Db = Depends(get_db)):
    ext = Path(file.filename or "").suffix.lower()
    fmt = fd.EXT.get(ext)
    if not fmt:
        raise HTTPException(422, f"Unsupported file type “{ext}”. Supported: PX4 ULog (.ulg), ArduPilot (.bin), MAVLink (.tlog), .csv, .json")
    if source_class not in ("physical", "sitl"):
        raise HTTPException(422, "Imported logs must be declared as physical or SITL.")
    data = await file.read()
    tmp = config.sub("flightlogs") / f"_import_{secrets.token_hex(6)}{ext}"
    tmp.write_bytes(data)
    try:
        rec = fd.PARSERS[fmt](tmp)
        log = store_log(db, u, rec, fmt, source_class, name or Path(file.filename).stem, aircraft_id, mission_id, flight_id, data, file.filename)
    except HTTPException:
        raise
    except Exception as e:  # parser errors are reported to the engineer, never swallowed
        db.rollback()
        raise HTTPException(422, f"Could not read {file.filename} as {fd.FORMAT_LABEL[fmt]}: {e}")
    finally:
        _discard(tmp)
    audit(db, u, "log_import", "flight_log", log.id, f"Imported {fd.FORMAT_LABEL[fmt]} log {file.filename} as {log.code}", {"sha256": log.sha256})
    db.commit()
    return log_out(db, log, True)


@router.get("/logs")
def list_logs(aircraft_id: int | None = None, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    st = select(m.FlightLog)
    if aircraft_id:
        st = st.where(m.FlightLog.aircraft_id == aircraft_id)
    names = user_names(db)
    return [dict(log_out(db, x), imported_by_name=names.get(x.imported_by)) for x in db.scalars(st.order_by(m.FlightLog.id.desc()).limit(500))]


def _log(db, lid) -> m.FlightLog:
    log = db.get(m.FlightLog, lid)
    if not log:
        raise HTTPException(404, "Flight log not found")
    return log


@router.get("/logs/compare")
def compare(a: int, b: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    la, lb = _log(db, a), _log(db, b)
    rows = []
    for k, (label, unit, area) in fd.METRICS.items():
        va, vb = (la.metrics or {}).get(k), (lb.metrics or {}).get(k)
        if va is None and vb is None:
            continue
        delta = round(vb - va, 3) if va is not None and vb is not None else None
        rows.append({"key": k, "label": label, "unit": unit, "area": area, "a": va, "b": vb, "delta": delta,
                     "delta_pct": round(100 * delta / abs(va), 1) if delta is not None and va else None})
    cfg = None
    if la.config_revision_id and lb.config_revision_id and la.config_revision_id != lb.config_revision_id:
        ra, rb = db.get(m.ConfigRevision, la.config_revision_id), db.get(m.ConfigRevision, lb.config_revision_id)
        if ra and rb:
            cfg = fleet.diff_snapshots(ra.snapshot, rb.snapshot)
    return {"a": log_out(db, la), "b": log_out(db, lb), "rows": rows, "config_diff": cfg,
            "note": "Differences are measured values. Attributing a difference to a configuration change is a hypothesis unless the flights were otherwise equivalent."}


@router.get("/logs/{lid}")
def get_log(lid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    return log_out(db, _log(db, lid), True)


@router.get("/logs/{lid}/series")
def log_series(lid: int, channels: str = "", max_points: int = 1500, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    log = _log(db, lid)
    p = config.sub("flightlogs") / log.data_file
    if not p.exists():
        raise HTTPException(410, "The data file for this log is missing from the data directory.")
    data = fd.load_norm(p)
    return fd.series(data, [c for c in channels.split(",") if c] or None, min(max(max_points, 100), 6000))


@router.get("/logs/{lid}/export.csv")
def export_csv(lid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    log = _log(db, lid)
    data = fd.load_norm(config.sub("flightlogs") / log.data_file)
    keys = ["t"] + sorted(k for k in data if k not in ("t", "acc_raw"))
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([f"# {log.code} {log.name} | source: {log.source_class.upper()} | format: {fd.FORMAT_LABEL.get(log.fmt, log.fmt)}"])
    w.writerow(keys)
    for i in range(len(data["t"])):
        w.writerow(["" if data[k][i] != data[k][i] else round(float(data[k][i]), 6) for k in keys])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{log.code}.csv"'})


PLOT_GROUPS = [("Height / speed", ["rel_alt", "gs", "climb"]), ("Attitude (deg)", ["roll", "pitch", "roll_sp", "pitch_sp"]),
               ("Battery", ["voltage", "current", "remaining"]), ("Navigation", ["sats", "hdop", "xtrack"]),
               ("Motor outputs", [f"m{i}" for i in range(1, 9)]), ("Vibration", ["vibe_x", "vibe_y", "vibe_z"])]


def plotly_html(log: m.FlightLog) -> str:
    """Self-contained interactive chart document (Plotly, script embedded so it opens offline)."""
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots

    s = fd.series(fd.load_norm(config.sub("flightlogs") / log.data_file), None, 4000)
    groups = [(t, [k for k in keys if k in s]) for t, keys in PLOT_GROUPS]
    groups = [g for g in groups if g[1]]
    fig = make_subplots(rows=max(1, len(groups)), cols=1, shared_xaxes=True, vertical_spacing=0.035, subplot_titles=[g[0] for g in groups])
    for i, (_, keys) in enumerate(groups):
        for k in keys:
            fig.add_trace(go.Scattergl(x=s["t"], y=s[k], name=k, mode="lines", line={"width": 1.2}, legendgroup=str(i)), row=i + 1, col=1)
    for e in log.events or []:
        if e.get("type") == "anomaly" or e.get("severity") == "critical":
            fig.add_vline(x=e["t"], line_width=1, line_dash="dot", line_color="#f0555d")
    src = {"physical": "PHYSICAL AIRCRAFT FLIGHT DATA", "sitl": "SITL SIMULATION — not a physical flight",
           "simulation": "INTERNAL KINEMATIC SIMULATION — NOT AIRCRAFT FLIGHT DATA"}[log.source_class]
    fig.update_layout(template="plotly_dark", height=260 * max(1, len(groups)) + 120, margin={"l": 60, "r": 30, "t": 90, "b": 40}, hovermode="x unified",
                      title={"text": f"{log.code} · {log.name}<br><sup>{src} · {fd.FORMAT_LABEL.get(log.fmt, log.fmt)} · AEROS OPS PRO</sup>"},
                      paper_bgcolor="#0d1014", plot_bgcolor="#151a20")
    fig.update_xaxes(title_text="time (s)", row=max(1, len(groups)), col=1)
    return fig.to_html(include_plotlyjs=True, full_html=True)


@router.get("/logs/{lid}/charts.html")
def charts_html(lid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    log = _log(db, lid)
    if config.BROWSER:
        raise HTTPException(409, "Interactive Plotly charts are part of the desktop edition.")
    return Response(plotly_html(log), media_type="text/html", headers={"Content-Disposition": f'attachment; filename="{log.code}-charts.html"'})


@router.patch("/logs/{lid}")
def update_log(lid: int, data: dict = Body(...), u: m.User = Depends(require(*ANALYSTS)), db: Db = Depends(get_db)):
    log = _log(db, lid)
    for k in ("name", "aircraft_id", "flight_id", "mission_id"):
        if k in data:
            setattr(log, k, data[k] or None)
    if "mission_id" in data or "aircraft_id" in data:  # re-evaluate what depends on the links
        ms = db.get(m.Mission, log.mission_id) if log.mission_id else None
        if ms and (config.sub("flightlogs") / log.data_file).exists():
            d = fd.load_norm(config.sub("flightlogs") / log.data_file)
            if "lat" in d and "rel_alt" in d:
                import numpy as np

                air = np.nan_to_num(d["rel_alt"], nan=0.0) > 1.0
                ok = np.isfinite(d["lat"]) & np.isfinite(d["lon"]) & air
                xt = fd.cross_track(d["lat"][ok], d["lon"][ok], planned_path(ms))
                if xt is not None and len(xt):
                    log.metrics = dict(log.metrics, xtrack_rms_m=round(float(np.sqrt(np.mean(xt * xt))), 2), xtrack_max_m=round(float(xt.max()), 2))
        log.observations = fd.observations(log.metrics, _cells(db, log.aircraft_id))
        ac = db.get(m.Aircraft, log.aircraft_id) if log.aircraft_id else None
        if "aircraft_id" in data:
            log.config_revision_id = ac.current_revision_id if ac else None
    audit(db, u, "log_update", "flight_log", log.id, f"Updated links of {log.code}", data)
    db.commit()
    return log_out(db, log, True)


@router.delete("/logs/{lid}")
def delete_log(lid: int, u: m.User = Depends(require("flight_ops", "flight_test")), db: Db = Depends(get_db)):
    log = _log(db, lid)
    used = db.scalar(select(m.TestCard.code).where(m.TestCard.flight_log_id == lid))
    if used:
        raise HTTPException(409, f"This log is evidence for test card {used} and cannot be deleted.")
    if db.scalar(select(m.SimRun.id).where(m.SimRun.flight_log_id == lid)):
        raise HTTPException(409, "This log is the record of a simulation run and cannot be deleted.")
    for f in (log.data_file, log.stored_name):
        if f:
            (config.sub("flightlogs") / f).unlink(missing_ok=True)
    audit(db, u, "log_delete", "flight_log", lid, f"Deleted flight log {log.code} {log.name}", {"sha256": log.sha256})
    db.delete(log)
    db.commit()
    return {"ok": True}
