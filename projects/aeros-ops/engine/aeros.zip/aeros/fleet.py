"""Aircraft configuration management, hardware compatibility validation, revisions and evidence-based readiness."""
import hashlib
import json

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import approvals as ap, models as m, reference
from .core import audit, internal_user, require, to_dict, today, user_names
from .db import get_db, utcnow
from .resources import coerce, hook

router = APIRouter(prefix="/api")

AC_FIELDS = ["code", "name", "manufacturer", "model", "serial_number", "aircraft_type", "airframe_config", "mtom_kg", "empty_mass_kg",
             "payload_config", "payload_mass_kg", "flight_controller", "autopilot", "autopilot_firmware", "propulsion", "esc_config",
             "battery_config", "nav_sensors", "comm_equipment", "companion_computer", "software_version"]
ROTORS = {"FPV quadcopter": 4, "Multicopter (quad)": 4, "Hexacopter": 6, "Octocopter": 8}


def installed(db: Db, aircraft_id: int) -> list:
    return list(db.scalars(select(m.Component).where(m.Component.aircraft_id == aircraft_id, m.Component.status == "installed").order_by(m.Component.code)))


def snapshot(db: Db, ac: m.Aircraft) -> dict:
    comps = [{"code": c.code, "category": c.category, "manufacturer": c.manufacturer, "model": c.model, "serial_number": c.serial_number,
              "position": c.position, "config_version": c.config_version, "specs": c.specs or {}} for c in installed(db, ac.id)]
    return {"aircraft": {f: getattr(ac, f) for f in AC_FIELDS}, "components": comps}


def digest(snap: dict) -> str:
    return hashlib.sha256(json.dumps(snap, sort_keys=True, default=str).encode()).hexdigest()


def _num(spec: dict, key: str):
    try:
        v = spec.get(key)
        return float(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def compatibility(snap: dict) -> list:
    """Rule-based hardware compatibility validation. A rule that cannot be evaluated because specification data
    is missing is reported as 'unverified' — never as a pass."""
    ac, comps = snap["aircraft"], snap["components"]
    out = []

    def add(rule, level, msg):
        out.append({"rule": rule, "level": level, "message": msg})

    by = {}
    for c in comps:
        by.setdefault(c["category"], []).append(c)
    typ = ac.get("aircraft_type")
    n = ROTORS.get(typ)
    motors, escs, props, batts, fcs = (by.get(k, []) for k in ("Motor", "ESC", "Propeller", "Battery", "Flight controller"))

    # R1 required components
    if n:
        if len(motors) != n:
            add("Required components", "error", f"{typ} requires {n} motors; {len(motors)} installed.")
        if len(props) != n:
            add("Required components", "error", f"{typ} requires {n} propellers; {len(props)} installed.")
        ch = sum(int(_num(e["specs"], "channels") or 1) for e in escs)
        if ch < n:
            add("Required components", "error", f"ESC channels installed ({ch}) do not cover {n} motors.")
    elif typ in ("Fixed-wing", "VTOL"):
        need = 1 if typ == "Fixed-wing" else 5
        if len(motors) < need:
            add("Required components", "error", f"{typ} requires at least {need} motor(s); {len(motors)} installed.")
        if len(props) < len(motors):
            add("Required components", "error", f"{len(motors)} motors but only {len(props)} propellers installed.")
        if not escs:
            add("Required components", "error", "No ESC installed.")
    if typ != "Autonomous robotic platform" or batts or motors:
        if not batts:
            add("Required components", "error", "No battery installed.")
    if not fcs and not by.get("Companion computer"):
        add("Required components", "error", "No flight controller or companion computer installed.")
    if len(fcs) > 1:
        add("Required components", "warning", f"{len(fcs)} flight controllers installed — confirm redundancy is intended.")
    if typ != "FPV quadcopter" and not by.get("GPS module"):
        add("Required components", "warning", "No GPS module installed — autonomous navigation cannot be validated.")
    if not by.get("Radio receiver") and not by.get("Telemetry module"):
        add("Required components", "error", "No radio receiver or telemetry module installed — no command and control link.")
    if not any(o["rule"] == "Required components" for o in out):
        add("Required components", "ok", "Required component categories are present for this airframe type.")

    # R2 cell count vs ESC / motor limits
    cells = {int(v) for v in (_num(b["specs"], "cells") for b in batts) if v}
    if len(cells) > 1:
        add("Battery cell count", "error", f"Installed batteries have different cell counts: {sorted(cells)}S.")
    if batts and not cells:
        add("Battery cell count", "unverified", "Battery cell count is not recorded — voltage compatibility cannot be verified.")
    for cell in cells:
        bad = False
        for c in motors + escs:
            lo, hi = _num(c["specs"], "cells_min"), _num(c["specs"], "cells_max")
            if hi is None:
                add("Voltage compatibility", "unverified", f"{c['code']} {c['model']}: supported cell range not recorded.")
                bad = True
            elif cell > hi or (lo and cell < lo):
                add("Voltage compatibility", "error", f"{c['code']} {c['model']} supports {int(lo or 1)}–{int(hi)}S; battery is {cell}S.")
                bad = True
        if not bad and (motors or escs):
            add("Voltage compatibility", "ok", f"{cell}S battery is within the limits of all motors and ESCs.")

    # R3 ESC current vs motor current
    m_cur = [x for x in (_num(c["specs"], "max_current_a") for c in motors) if x]
    e_cur = [x for x in (_num(c["specs"], "continuous_current_a") for c in escs) if x]
    if motors and escs:
        if len(m_cur) < len(motors) or len(e_cur) < len(escs):
            add("ESC current margin", "unverified", "Motor max current or ESC continuous current is not recorded for every unit.")
        elif min(e_cur) < max(m_cur):
            add("ESC current margin", "error", f"ESC continuous rating {min(e_cur):g} A is below motor max current {max(m_cur):g} A.")
        elif min(e_cur) < 1.2 * max(m_cur):
            add("ESC current margin", "warning", f"ESC margin is under 20% ({min(e_cur):g} A vs motor {max(m_cur):g} A).")
        else:
            add("ESC current margin", "ok", f"ESC rating {min(e_cur):g} A covers motor max current {max(m_cur):g} A with ≥20% margin.")

    # R4 battery discharge capability
    if batts and m_cur and len(m_cur) == len(motors):
        cap = [(_num(b["specs"], "capacity_mah"), _num(b["specs"], "c_rating")) for b in batts]
        if any(a is None or b is None for a, b in cap):
            add("Battery discharge capability", "unverified", "Battery capacity or C rating not recorded.")
        else:
            avail, need = sum(a / 1000 * b for a, b in cap), sum(m_cur)
            lvl = "ok" if avail >= need else "warning" if avail >= 0.6 * need else "error"
            add("Battery discharge capability", lvl, f"Pack can deliver {avail:.0f} A continuous; all motors at maximum draw {need:.0f} A.")

    # R5 propeller size
    if motors and props:
        dia = [x for x in (_num(p["specs"], "diameter_in") for p in props) if x]
        rng = [(_num(c["specs"], "prop_in_min"), _num(c["specs"], "prop_in_max")) for c in motors]
        if len(dia) < len(props) or any(hi is None for _, hi in rng):
            add("Propeller match", "unverified", "Propeller diameter or motor propeller range not recorded.")
        elif any(d > hi or (lo and d < lo) for d in dia for lo, hi in rng):
            add("Propeller match", "error", f"Propeller diameter {sorted(set(dia))} in is outside the motor's recommended range.")
        else:
            add("Propeller match", "ok", "Propeller diameters are within the motors' recommended range.")
        if len(set(dia)) > 1 and n:
            add("Propeller match", "warning", f"Mixed propeller diameters installed: {sorted(set(dia))} in.")

    # R6 thrust-to-weight
    thrust = [x for x in (_num(c["specs"], "max_thrust_g") for c in motors) if x]
    mtom = ac.get("mtom_kg")
    if motors and (n or typ in ("VTOL", "Fixed-wing")):
        if not mtom or len(thrust) < len(motors):
            add("Thrust-to-weight", "unverified", "MTOM or motor maximum thrust not recorded — thrust margin cannot be verified.")
        else:
            lift = thrust if typ != "VTOL" else sorted(thrust, reverse=True)[: max(4, len(thrust) - 1)]
            tw = sum(lift) / (mtom * 1000)
            lo_err, lo_warn = (0.25, 0.4) if typ == "Fixed-wing" else (1.5, 2.0)
            lvl = "error" if tw < lo_err else "warning" if tw < lo_warn else "ok"
            add("Thrust-to-weight", lvl, f"Static thrust-to-weight at MTOM is {tw:.2f} (minimum {lo_err}, recommended ≥ {lo_warn}).")

    # R7 mass budget
    empty, payload = ac.get("empty_mass_kg"), ac.get("payload_mass_kg") or 0
    if not mtom or not empty:
        add("Mass budget", "unverified", "MTOM or empty mass not recorded.")
    elif empty + payload > mtom:
        add("Mass budget", "error", f"Empty mass {empty:g} kg + payload {payload:g} kg exceeds MTOM {mtom:g} kg.")
    else:
        add("Mass budget", "ok", f"Empty mass {empty:g} kg + payload {payload:g} kg is within MTOM {mtom:g} kg ({mtom - empty - payload:.2f} kg margin).")

    # R8 firmware support
    if fcs:
        sup = " ".join(str(f["specs"].get("supported_firmware") or "") for f in fcs).lower()
        ap_ = (ac.get("autopilot") or "").lower()
        if not ap_ or not sup.strip():
            add("Firmware support", "unverified", "Autopilot stack or the flight controller's supported firmware is not recorded.")
        elif ap_ not in sup:
            add("Firmware support", "error", f"Flight controller does not list {ac.get('autopilot')} as supported firmware.")
        else:
            add("Firmware support", "ok", f"Flight controller supports {ac.get('autopilot')}.")
    if not ac.get("autopilot_firmware"):
        add("Firmware record", "error", "Autopilot firmware version is not recorded on the aircraft.")

    # R9 component documentation
    undocumented = [c["code"] for c in comps if not c.get("serial_number") or not c.get("manufacturer")]
    if undocumented:
        add("Component documentation", "warning", f"Serial number or manufacturer missing for: {', '.join(undocumented)}.")
    elif comps:
        add("Component documentation", "ok", "Every installed component has a manufacturer and serial number on record.")

    # R10 positions
    pos = [c["position"] for c in motors if c.get("position")]
    if len(pos) != len(set(pos)):
        add("Motor positions", "error", "Two motors are recorded at the same position.")
    elif motors and len(pos) < len(motors):
        add("Motor positions", "warning", "Not every motor has a recorded position.")

    # R11 RF coexistence (documentation only)
    freqs = [(c["code"], _num(c["specs"], "frequency_mhz")) for c in by.get("Telemetry module", []) + by.get("Radio receiver", [])]
    seen = {}
    for code, f in freqs:
        if f and f in seen:
            add("RF coexistence", "warning", f"{seen[f]} and {code} are both recorded on {f:g} MHz — confirm channel separation.")
        elif f:
            seen[f] = code
    return out


def check_summary(checks: list) -> dict:
    return {lvl: sum(1 for c in checks if c["level"] == lvl) for lvl in ("error", "warning", "unverified", "ok")}


def current_revision(db: Db, ac: m.Aircraft) -> m.ConfigRevision | None:
    return db.get(m.ConfigRevision, ac.current_revision_id) if ac.current_revision_id else None


def rev_out(r: m.ConfigRevision, names=None) -> dict:
    d = to_dict(r)
    d["summary"] = check_summary(r.checks or [])
    d["created_by_name"] = (names or {}).get(r.created_by)
    return d


def _ac(db, aid) -> m.Aircraft:
    ac = db.get(m.Aircraft, aid)
    if not ac:
        raise HTTPException(404, "Aircraft not found")
    return ac


@router.get("/spec-keys")
def spec_keys(u: m.User = Depends(internal_user)):
    return {"keys": reference.SPEC_KEYS, "default": reference.DEFAULT_SPEC}


@router.get("/aircraft/{aid}/config")
def aircraft_config(aid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    ac = _ac(db, aid)
    snap = snapshot(db, ac)
    cur = current_revision(db, ac)
    names = user_names(db)
    revs = list(db.scalars(select(m.ConfigRevision).where(m.ConfigRevision.aircraft_id == aid).order_by(m.ConfigRevision.number.desc())))
    checks = compatibility(snap)
    return {"snapshot": snap, "digest": digest(snap), "checks": checks, "summary": check_summary(checks),
            "components": [to_dict(c) for c in installed(db, aid)],
            "current_revision": rev_out(cur, names) if cur else None, "drift": bool(cur and cur.digest != digest(snap)),
            "drift_detail": diff_snapshots(cur.snapshot, snap) if cur and cur.digest != digest(snap) else None,
            "revisions": [rev_out(r, names) for r in revs]}


@router.post("/aircraft/{aid}/revisions")
def create_revision(aid: int, data: dict = Body({}), u: m.User = Depends(require("flight_ops", "uav_eng")), db: Db = Depends(get_db)):
    ac = _ac(db, aid)
    snap = snapshot(db, ac)
    dg = digest(snap)
    last = db.scalar(select(m.ConfigRevision).where(m.ConfigRevision.aircraft_id == aid).order_by(m.ConfigRevision.number.desc()))
    if last and last.digest == dg and last.status != "superseded":
        raise HTTPException(409, f"Configuration is unchanged since revision {last.number}.")
    for d in db.scalars(select(m.ConfigRevision).where(m.ConfigRevision.aircraft_id == aid, m.ConfigRevision.status == "draft")):
        d.status = "superseded"
    num = (last.number if last else 0) + 1
    r = m.ConfigRevision(aircraft_id=aid, number=num, label=(data.get("label") or f"R{num}"), snapshot=snap, checks=compatibility(snap),
                         digest=dg, notes=data.get("notes"), created_by=u.id)
    db.add(r)
    db.flush()
    audit(db, u, "config_revision", "aircraft", aid, f"Captured configuration revision {num} ({r.label}) for {ac.code}", {"revision": r.id, "digest": dg})
    db.commit()
    return rev_out(r)


def diff_snapshots(a: dict, b: dict) -> dict:
    fields = [{"field": f, "from": a["aircraft"].get(f), "to": b["aircraft"].get(f)} for f in AC_FIELDS
              if a["aircraft"].get(f) != b["aircraft"].get(f)]
    ca, cb = {c["code"]: c for c in a["components"]}, {c["code"]: c for c in b["components"]}
    changed = []
    for code in sorted(set(ca) & set(cb)):
        x, y = ca[code], cb[code]
        ch = [{"field": k, "from": x.get(k), "to": y.get(k)} for k in ("position", "config_version", "serial_number", "model") if x.get(k) != y.get(k)]
        for k in sorted(set(x["specs"]) | set(y["specs"])):
            if x["specs"].get(k) != y["specs"].get(k):
                ch.append({"field": f"spec · {k}", "from": x["specs"].get(k), "to": y["specs"].get(k)})
        if ch:
            changed.append({"code": code, "category": y["category"], "model": y["model"], "changes": ch})
    return {"fields": fields, "added": [cb[c] for c in sorted(set(cb) - set(ca))], "removed": [ca[c] for c in sorted(set(ca) - set(cb))],
            "changed": changed}


@router.get("/revisions/{a}/diff/{b}")
def diff(a: int, b: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    ra, rb = db.get(m.ConfigRevision, a), db.get(m.ConfigRevision, b)
    if not ra or not rb:
        raise HTTPException(404, "Revision not found")
    d = diff_snapshots(ra.snapshot, rb.snapshot)
    d.update(**{"from": rev_out(ra), "to": rev_out(rb)})
    return d


# ───────────── config release approval ─────────────
def _pre_release(db, rev: m.ConfigRevision, tag):
    unmet = []
    if rev.status != "draft":
        unmet.append(f"Revision {rev.number} is {rev.status}; only a draft revision can be released.")
    ac = db.get(m.Aircraft, rev.aircraft_id)
    if digest(snapshot(db, ac)) != rev.digest:
        unmet.append("The aircraft configuration has changed since this revision was captured — capture a new revision.")
    unmet += [f"Compatibility error — {c['rule']}: {c['message']}" for c in rev.checks or [] if c["level"] == "error"]
    return unmet


def _on_release(db, a, rev: m.ConfigRevision, user):
    ac = db.get(m.Aircraft, rev.aircraft_id)
    for r in db.scalars(select(m.ConfigRevision).where(m.ConfigRevision.aircraft_id == ac.id, m.ConfigRevision.status == "released")):
        r.status = "superseded"
    rev.status, rev.released_at = "released", utcnow()
    ac.current_revision_id, ac.hardware_revision = rev.id, rev.label


ap.PRECOND["config_release"] = _pre_release
ap.ON_APPROVE["config_release"] = _on_release


# ───────────── component installation ─────────────
def _event(db, comp, etype, desc, user, aircraft_id=None):
    db.add(m.ComponentEvent(component_id=comp.id, aircraft_id=aircraft_id or comp.aircraft_id, event_type=etype, description=desc,
                            user_id=user.id if user else None, hours_at_event=comp.hours))


@router.post("/components/{cid}/install")
def install(cid: int, data: dict = Body(...), u: m.User = Depends(require("flight_ops", "uav_eng", "maintenance")), db: Db = Depends(get_db)):
    c = db.get(m.Component, cid)
    if not c:
        raise HTTPException(404, "Component not found")
    if c.status == "installed":
        raise HTTPException(409, "Component is already installed — remove it first.")
    if c.status in ("quarantined", "scrapped"):
        raise HTTPException(409, f"Component is {c.status} and cannot be installed.")
    ac = _ac(db, data.get("aircraft_id"))
    c.aircraft_id, c.position, c.status = ac.id, data.get("position"), "installed"
    c.installed_date = coerce(m.Component.__table__.c.installed_date, data.get("installed_date")) or today()
    _event(db, c, "installed", f"Installed on {ac.code}" + (f" at {c.position}" if c.position else ""), u)
    audit(db, u, "install", "component", c.id, f"Installed {c.code} {c.model} on {ac.code}", {"aircraft": ac.id, "position": c.position})
    db.commit()
    return to_dict(c)


@router.post("/components/{cid}/remove")
def remove(cid: int, data: dict = Body({}), u: m.User = Depends(require("flight_ops", "uav_eng", "maintenance")), db: Db = Depends(get_db)):
    c = db.get(m.Component, cid)
    if not c or c.status != "installed":
        raise HTTPException(409, "Component is not installed.")
    ac = db.get(m.Aircraft, c.aircraft_id)
    new = data.get("status") if data.get("status") in ("in_stock", "quarantined", "scrapped") else "in_stock"
    _event(db, c, "removed", f"Removed from {ac.code}: {data.get('reason') or 'no reason recorded'}", u, ac.id)
    c.aircraft_id, c.position, c.status, c.installed_date = None, None, new, None
    audit(db, u, "remove", "component", c.id, f"Removed {c.code} {c.model} from {ac.code}", {"reason": data.get("reason"), "status": new})
    db.commit()
    return to_dict(c)


@router.get("/components/{cid}/history")
def component_history(cid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    names = user_names(db)
    ev = [dict(to_dict(e), user_name=names.get(e.user_id)) for e in
          db.scalars(select(m.ComponentEvent).where(m.ComponentEvent.component_id == cid).order_by(m.ComponentEvent.id.desc()))]
    acts = [dict(to_dict(a), performed_by_name=names.get(a.performed_by)) for a in
            db.scalars(select(m.MaintenanceAction).where(m.MaintenanceAction.component_id == cid).order_by(m.MaintenanceAction.date.desc()))]
    return {"events": ev, "maintenance": acts}


@hook("components", "before_delete")
def _no_delete_installed(db, user, obj):
    if obj.status == "installed":
        raise HTTPException(409, "Remove the component from its aircraft before deleting it.")


# ───────────── groundings ─────────────
@router.post("/aircraft/{aid}/ground")
def ground(aid: int, data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    ac = _ac(db, aid)
    if not (data.get("reason") or "").strip():
        raise HTTPException(422, "A grounding must state a reason.")
    g = m.Grounding(aircraft_id=aid, reason=data["reason"].strip(), grounded_by=u.id)
    db.add(g)
    audit(db, u, "ground", "aircraft", aid, f"Grounded {ac.code}: {g.reason}")
    db.commit()
    return to_dict(g)


@router.post("/groundings/{gid}/lift")
def lift(gid: int, data: dict = Body(...), u: m.User = Depends(require("flight_ops", "maintenance")), db: Db = Depends(get_db)):
    g = db.get(m.Grounding, gid)
    if not g or not g.active:
        raise HTTPException(404, "No active grounding")
    if not (data.get("note") or "").strip():
        raise HTTPException(422, "Lifting a grounding requires a note describing the rectification.")
    g.active, g.lifted_by, g.lifted_at, g.lift_note = False, u.id, utcnow(), data["note"].strip()
    audit(db, u, "unground", "aircraft", g.aircraft_id, f"Lifted grounding: {g.lift_note}")
    db.commit()
    return to_dict(g)


# ───────────── readiness (derived from evidence, never assigned) ─────────────
STATES = ["Under integration", "Ready for inspection", "Awaiting validation", "Ready for simulation", "Awaiting flight authorization",
          "Approved for designated testing", "Maintenance required", "Grounded"]


def readiness(db: Db, ac: m.Aircraft, names=None) -> dict:
    from . import maint  # local import: maint depends on this module

    names = names or user_names(db)
    cur = current_revision(db, ac)
    drift = bool(cur and cur.digest != digest(snapshot(db, ac)))
    gates, blockers = [], []

    def ev(text, type_=None, id_=None):
        return {"text": text, "type": type_, "id": id_}

    def appr_ev(a):
        return ev(f"{ap.KINDS[a.kind][0]} approved by {names.get(a.decided_by, '?')} on {a.decided_at:%Y-%m-%d}"
                  + (f", valid to {a.expires_at:%Y-%m-%d}" if a.expires_at else ""), "approval", a.id)

    # blockers
    for g in db.scalars(select(m.Grounding).where(m.Grounding.aircraft_id == ac.id, m.Grounding.active)):
        blockers.append({"state": "Grounded", **ev(f"Grounded by {names.get(g.grounded_by, '?')} on {g.grounded_at:%Y-%m-%d}: {g.reason}", "grounding", g.id)})
    for i in db.scalars(select(m.Issue).where(m.Issue.aircraft_id == ac.id, m.Issue.severity == "critical", m.Issue.status != "closed")):
        blockers.append({"state": "Grounded", **ev(f"Open critical issue {i.code}: {i.title}", "issue", i.id)})
    for al in maint.alerts(db, ac):
        if al["level"] == "overdue":
            blockers.append({"state": "Maintenance required", **ev(al["message"], "maintenance_task", al.get("task_id"))})

    # G1 integration
    g1 = {"key": "integration", "label": "Configuration released", "ok": False, "evidence": []}
    if not cur:
        g1["evidence"].append(ev("No released configuration revision. Register components, capture a revision and obtain a configuration release."))
    elif drift:
        g1["evidence"].append(ev(f"Configuration has changed since released revision {cur.number} ({cur.label}) — a new revision must be captured and released."))
    else:
        g1["ok"] = True
        rel = ap.valid_approval(db, "config_release", "config_revision", cur.id)
        g1["evidence"].append(ev(f"Revision {cur.number} ({cur.label}) released {cur.released_at:%Y-%m-%d}; digest {cur.digest[:12]}", "config_revision", cur.id))
        if rel:
            g1["evidence"].append(appr_ev(rel))
    gates.append(g1)

    rid = cur.id if cur and not drift else -1
    spec = [("inspection", "Aircraft inspection approved", "inspection", "aircraft_inspection"),
            ("ground", "Ground validation approved", "ground_validation", "ground_validation"),
            ("simulation", "Simulation validation approved", "simulation_validation", None)]
    prev_ok = g1["ok"]
    for key, label, kind, cl_kind in spec:
        g = {"key": key, "label": label, "ok": False, "evidence": []}
        a = ap.valid_approval(db, kind, "aircraft", ac.id, revision_id=rid) if prev_ok else None
        if a:
            g["ok"] = True
            g["evidence"].append(appr_ev(a))
            if cl_kind:
                cl = ap.checklist_complete(db, cl_kind, "aircraft", ac.id, rid)
                if cl:
                    g["evidence"].append(ev(f"{cl.title} checklist completed {cl.completed_at:%Y-%m-%d}", "checklist", cl.id))
            else:
                sr = db.scalar(select(m.SimRun).where(m.SimRun.aircraft_id == ac.id, m.SimRun.config_revision_id == rid, m.SimRun.result == "pass")
                               .order_by(m.SimRun.id.desc()))
                if sr:
                    g["evidence"].append(ev(f"Simulation run #{sr.id} ({sr.engine}) passed {sr.created_at:%Y-%m-%d}", "sim_run", sr.id))
        elif prev_ok:
            g["evidence"].append(ev(f"No approved {ap.KINDS[kind][0].lower()} for the released configuration."))
        else:
            g["evidence"].append(ev("Blocked by the previous gate."))
        gates.append(g)
        prev_ok = g["ok"]

    # G5 flight authorization (campaign scoped)
    g5 = {"key": "authorization", "label": "Flight-test authorization in force", "ok": False, "evidence": []}
    designated = None
    if prev_ok:
        for c in db.scalars(select(m.Campaign).where(m.Campaign.aircraft_id == ac.id, m.Campaign.status == "active")):
            a = ap.valid_approval(db, "flight_authorization", "campaign", c.id, revision_id=rid)
            if a:
                g5["ok"], designated = True, c
                g5["evidence"] += [appr_ev(a), ev(f"Designated campaign {c.code} · {c.name}", "campaign", c.id)]
                break
        if not g5["ok"]:
            g5["evidence"].append(ev("No flight-test authorization in force for an active campaign on the released configuration."))
    else:
        g5["evidence"].append(ev("Blocked by the previous gate."))
    gates.append(g5)

    order = ["Under integration", "Ready for inspection", "Awaiting validation", "Ready for simulation", "Awaiting flight authorization"]
    state = "Approved for designated testing"
    for g, s in zip(gates, order):
        if not g["ok"]:
            state = s
            break
    if any(b["state"] == "Grounded" for b in blockers):
        state = "Grounded"
    elif blockers:
        state = "Maintenance required"

    release = ap.valid_approval(db, "release_decision", "aircraft", ac.id, revision_id=rid) if g1["ok"] else None
    return {"aircraft_id": ac.id, "code": ac.code, "name": ac.name, "aircraft_type": ac.aircraft_type, "state": state, "gates": gates,
            "blockers": blockers, "revision": {"id": cur.id, "number": cur.number, "label": cur.label} if cur else None, "drift": drift,
            "designated_campaign": {"id": designated.id, "code": designated.code, "name": designated.name} if designated else None,
            "operational_release": appr_ev(release) if release else None,
            "flight_hours": round(ac.flight_hours or 0, 2), "flight_cycles": ac.flight_cycles or 0}


@router.get("/readiness")
def all_readiness(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    names = user_names(db)
    return [readiness(db, ac, names) for ac in db.scalars(select(m.Aircraft).order_by(m.Aircraft.code))]


@router.get("/aircraft/{aid}/readiness")
def one_readiness(aid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    ac = _ac(db, aid)
    d = readiness(db, ac)
    d["groundings"] = [to_dict(g) for g in db.scalars(select(m.Grounding).where(m.Grounding.aircraft_id == aid).order_by(m.Grounding.id.desc()))]
    return d


# ───────────── gate approvals: preconditions ─────────────
def _released_clean(db, ac):
    cur = current_revision(db, ac)
    if not cur:
        return None, ["The aircraft has no released configuration revision."]
    if cur.digest != digest(snapshot(db, ac)):
        return None, ["The configuration has changed since the released revision — release a new revision first."]
    return cur, []


def _pre_inspection(db, ac, tag):
    cur, unmet = _released_clean(db, ac)
    if cur and not ap.checklist_complete(db, "aircraft_inspection", "aircraft", ac.id, cur.id):
        unmet.append("A completed aircraft inspection checklist for the released configuration is required.")
    return unmet


def _pre_ground(db, ac, tag):
    cur, unmet = _released_clean(db, ac)
    if cur:
        if not ap.valid_approval(db, "inspection", "aircraft", ac.id, revision_id=cur.id):
            unmet.append("Aircraft inspection has not been approved for the released configuration.")
        if not ap.checklist_complete(db, "ground_validation", "aircraft", ac.id, cur.id):
            unmet.append("A completed ground validation checklist for the released configuration is required.")
    return unmet


def _pre_sim(db, ac, tag):
    cur, unmet = _released_clean(db, ac)
    if cur:
        if not ap.valid_approval(db, "ground_validation", "aircraft", ac.id, revision_id=cur.id):
            unmet.append("Ground validation has not been approved for the released configuration.")
        if not db.scalar(select(m.SimRun.id).where(m.SimRun.aircraft_id == ac.id, m.SimRun.config_revision_id == cur.id, m.SimRun.result == "pass")):
            unmet.append("No passed simulation run exists for this aircraft at the released configuration.")
    return unmet


def _pre_release_decision(db, ac, tag):
    cur, unmet = _released_clean(db, ac)
    if cur:
        accepted = [c for c in db.scalars(select(m.Campaign).where(m.Campaign.aircraft_id == ac.id, m.Campaign.config_revision_id == cur.id))
                    if ap.valid_approval(db, "campaign_acceptance", "campaign", c.id)]
        if not accepted:
            unmet.append("No accepted test campaign exists for the released configuration.")
        open_ = db.scalars(select(m.Issue).where(m.Issue.aircraft_id == ac.id, m.Issue.status != "closed",
                                                  m.Issue.severity.in_(["critical", "major"]))).all()
        if open_:
            unmet.append("Open critical / major issues: " + ", ".join(i.code for i in open_))
    r = readiness(db, ac)
    unmet += [b["text"] for b in r["blockers"]]
    return unmet


ap.PRECOND.update(inspection=_pre_inspection, ground_validation=_pre_ground, simulation_validation=_pre_sim, release_decision=_pre_release_decision)
ap.AUTO["config_clean"] = lambda db, cl: (
    ("ok", "No compatibility errors on the released revision") if (r := db.get(m.ConfigRevision, cl.config_revision_id or 0))
    and not any(c["level"] == "error" for c in r.checks or []) else ("fail", "No released revision, or it has compatibility errors"))
