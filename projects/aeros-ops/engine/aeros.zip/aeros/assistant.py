"""AI flight operations assistant.

Every answer is grounded in tools that query authorized project records and return facts with source references.
Two engines share the same tools:
  * Claude (Anthropic API) when an API key is configured in Administration — it plans tool calls and writes the answer.
  * A deterministic records-query engine otherwise — keyword routing over the same tools, no language model.
Hypotheses are kept apart from facts, and any answer that contains recommendations is queued for review by
qualified personnel before it may be relied on.
"""
import json

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import or_, select
from sqlalchemy.orm import Session as Db

from . import approvals as ap, fleet, maint, models as m, ops, testing, training
from .core import audit, get_setting, internal_user, to_dict, today, user_names
from .db import get_db, utcnow

router = APIRouter(prefix="/api/assistant")
MODEL = "claude-opus-5-5"
REVIEW_NOTE = "AI-generated recommendations must be reviewed and approved by qualified personnel before use."


def src(type_, id_, label):
    return {"type": type_, "id": id_, "label": label}


def fact(text, *sources):
    return {"text": text, "sources": list(sources)}


def _find(db, model, ref, fields=("code", "name")):
    if ref in (None, ""):
        return None
    if isinstance(ref, int) or str(ref).isdigit():
        return db.get(model, int(ref))
    conds = [getattr(model, f).ilike(f"%{ref}%") for f in fields if hasattr(model, f)]
    return db.scalar(select(model).where(or_(*conds)).order_by(model.id.desc()))


# ───────────── tools ─────────────
def t_fleet_readiness(db, u, **_):
    out = {"facts": [], "hypotheses": [], "recommendations": []}
    for r in fleet.all_readiness(u, db):
        ev = "; ".join(e["text"] for g in r["gates"] if g["ok"] for e in g["evidence"][:1]) or r["gates"][0]["evidence"][0]["text"]
        nxt = next((g["label"] for g in r["gates"] if not g["ok"]), None)
        out["facts"].append(fact(f"{r['code']} {r['name']}: {r['state']}." + (f" Next gate: {nxt}." if nxt and not r["blockers"] else "")
                                 + "".join(f" Blocker: {b['text']}." for b in r["blockers"]) + f" Evidence: {ev}", src("aircraft", r["aircraft_id"], r["code"])))
    if not out["facts"]:
        out["facts"].append(fact("No aircraft are registered."))
    return out


def t_incomplete_tests(db, u, campaign=None, **_):
    c = _find(db, m.Campaign, campaign)
    ov = testing.validation_overview(None, c.id if c else None, u, db)
    out = {"facts": [], "hypotheses": [], "recommendations": []}
    t = ov["totals"]
    out["facts"].append(fact(f"{'Campaign ' + c.code if c else 'All campaigns'}: {t['total']} test cards — {t['pass']} pass, {t['fail']} fail, {t['incomplete']} incomplete, "
                             f"{t['executed']} executed but not evaluated, {t['planned']} not executed, {t['deferred']} deferred.",
                             *([src("campaigns", c.id, c.code)] if c else [])))
    for k in ov["incomplete"]:
        out["facts"].append(fact(f"{k['code']} “{k['title']}” ({k['campaign']}) is {k['status']}" + (": " + "; ".join(k["reasons"]) if k["reasons"] else "") + ".",
                                 src("test_cards", k["id"], k["code"])))
    for c_ in ov["coverage"]:
        if c_["total"] == 0:
            out["facts"].append(fact(f"No test card covers the validation area “{c_['category']}”."))
    return out


def t_recurring_findings(db, u, keyword="vibration", **_):
    kw = (keyword or "vibration").lower()
    out = {"facts": [], "hypotheses": [], "recommendations": []}
    acs = {a.id: a for a in db.scalars(select(m.Aircraft))}
    per: dict = {}
    for log in db.scalars(select(m.FlightLog).where(m.FlightLog.aircraft_id.is_not(None), m.FlightLog.source_class != "simulation")):
        for o in log.observations or []:
            if o["level"] in ("warning", "critical") and (kw in o["area"].lower() or kw in o["fact"].lower()):
                per.setdefault(log.aircraft_id, []).append((log, o))
    for i in db.scalars(select(m.Issue).where(m.Issue.aircraft_id.is_not(None))):
        if kw in (i.title + " " + (i.description or "")).lower():
            per.setdefault(i.aircraft_id, []).append((i, None))
    for aid, items in per.items():
        ac = acs.get(aid)
        logs = [(x, o) for x, o in items if o]
        iss = [x for x, o in items if not o]
        tag = "recurring" if len({x.id for x, _ in logs}) + len(iss) >= 2 else "single occurrence"
        out["facts"].append(fact(f"{ac.code}: {len({x.id for x, _ in logs})} flight log(s) and {len(iss)} issue(s) with {kw} findings ({tag}).",
                                 src("aircraft", aid, ac.code), *[src("flight_logs", x.id, x.code) for x, _ in logs[:6]], *[src("issues", x.id, x.code) for x in iss[:6]]))
        for log, o in logs[:4]:
            out["facts"].append(fact(f"{log.code}: {o['fact']}", src("flight_logs", log.id, log.code)))
            if o.get("hypothesis"):
                out["hypotheses"].append(f"{ac.code} / {log.code}: {o['hypothesis']}")
            if o.get("recommendation"):
                out["recommendations"].append(f"{ac.code}: {o['recommendation']}")
    if not per:
        out["facts"].append(fact(f"No flight-log observation or issue mentioning “{kw}” is recorded against any aircraft (simulation logs excluded)."))
    return out


def t_compare_revisions(db, u, aircraft=None, **_):
    out = {"facts": [], "hypotheses": [], "recommendations": []}
    acs = [_find(db, m.Aircraft, aircraft)] if aircraft else list(db.scalars(select(m.Aircraft)))
    for ac in [a for a in acs if a]:
        revs = list(db.scalars(select(m.ConfigRevision).where(m.ConfigRevision.aircraft_id == ac.id).order_by(m.ConfigRevision.number.desc()).limit(2)))
        if len(revs) < 2:
            out["facts"].append(fact(f"{ac.code} has {len(revs)} configuration revision(s); two are needed for a comparison.", src("aircraft", ac.id, ac.code)))
            continue
        b, a = revs
        d = fleet.diff_snapshots(a.snapshot, b.snapshot)
        s = [src("aircraft", ac.id, f"{ac.code} rev {a.number}→{b.number}")]
        out["facts"].append(fact(f"{ac.code}: revision {a.number} ({a.label}, {a.status}) → revision {b.number} ({b.label}, {b.status}): {len(d['fields'])} aircraft field change(s), "
                                 f"{len(d['added'])} component(s) added, {len(d['removed'])} removed, {len(d['changed'])} changed.", *s))
        for x in d["fields"]:
            out["facts"].append(fact(f"{ac.code} {x['field']}: {x['from']} → {x['to']}", *s))
        for c in d["added"]:
            out["facts"].append(fact(f"{ac.code} added {c['code']} ({c['category']} {c['model']})", *s))
        for c in d["removed"]:
            out["facts"].append(fact(f"{ac.code} removed {c['code']} ({c['category']} {c['model']})", *s))
        for c in d["changed"]:
            out["facts"].append(fact(f"{ac.code} {c['code']}: " + "; ".join(f"{x['field']} {x['from']} → {x['to']}" for x in c["changes"]), *s))
        if a.status == "superseded" and b.status == "draft":
            out["recommendations"].append(f"{ac.code}: revision {b.number} is a draft — approvals bound to revision {a.number} do not carry over; re-validation is required after release.")
    if not out["facts"]:
        out["facts"].append(fact("No matching aircraft found."))
    return out


def t_campaign_summary(db, u, campaign=None, **_):
    c = _find(db, m.Campaign, campaign) or db.scalar(select(m.Campaign).order_by(m.Campaign.id.desc()))
    if not c:
        return {"facts": [fact("No test campaigns are recorded.")], "hypotheses": [], "recommendations": []}
    d = testing.campaign_detail(c.id, u, db)
    s = src("campaigns", c.id, c.code)
    tot = {k: sum(1 for x in d["cards"] if x["status"] == k) for k in ("pass", "fail", "incomplete", "executed", "planned", "deferred")}
    out = {"facts": [
        fact(f"{c.code} “{c.name}” on {d['aircraft']['code']} at {c.location or 'unrecorded location'}; stage {c.stage + 1}/14 “{d['stage_name']}”, status {c.status}.", s),
        fact(f"Objectives: {c.objectives or 'not recorded'}", s),
        fact(f"{len(d['cards'])} test cards: {tot['pass']} pass, {tot['fail']} fail, {tot['incomplete']} incomplete, {tot['executed']} awaiting evaluation, "
             f"{tot['planned']} not executed, {tot['deferred']} deferred.", s)], "hypotheses": [], "recommendations": []}
    for k in d["cards"]:
        if k["status"] == "fail":
            bad = [f"{r['parameter']} measured {r['measured']} vs {r['op']} {r['value']}" for r in (k["evaluation"] or {}).get("criteria", []) if r["result"] == "fail"]
            out["facts"].append(fact(f"{k['code']} “{k['title']}” failed: " + "; ".join(bad), src("test_cards", k["id"], k["code"])))
    for i in d["issues"]:
        out["facts"].append(fact(f"Issue {i['code']} ({i['severity']}, {i['status']}): {i['title']}", src("issues", i["id"], i["code"])))
    for cd in d["conditions"]:
        if not cd["ok"]:
            out["facts"].append(fact(f"Outstanding to leave the current stage: {cd['text']}", s))
    return out


def t_failure_rates(db, u, **_):
    r = maint.reliability(db)
    out = {"facts": [], "hypotheses": [], "recommendations": []}
    failing = [c for c in r["components"] if c["failures"]]
    for c in failing[:10]:
        rate = f"{c['failures_per_100h']} failures per 100 h (MTBF {c['mtbf_h']} h)" if c["failures_per_100h"] is not None else "no operating hours recorded, rate undefined"
        out["facts"].append(fact(f"{c['category']} {c['manufacturer'] or ''} {c['model']}: {c['failures']} failure(s) across {c['units']} unit(s), {c['hours']} h — {rate}.", *c["sources"][:6]))
    if not failing:
        out["facts"].append(fact(f"No component failures are recorded across {sum(c['units'] for c in r['components'])} registered components."))
    elif any(c["hours"] < 20 for c in failing):
        out["hypotheses"].append("Failure rates computed from fewer than 20 operating hours are statistically weak and may not reflect the true rate.")
    return out


def t_deployment_gaps(db, u, deployment=None, **_):
    deps = [_find(db, m.Deployment, deployment)] if deployment else list(db.scalars(select(m.Deployment).where(m.Deployment.status.in_(["planning", "ready", "deployed"]))))
    out = {"facts": [], "hypotheses": [], "recommendations": []}
    for dep in [d for d in deps if d]:
        d = ops.deployment_detail_data(db, dep)
        s = src("deployments", dep.id, dep.code)
        if d["missing_documentation"]:
            out["facts"].append(fact(f"{dep.code} “{dep.name}” is missing: " + "; ".join(d["missing_documentation"]) + ".", s))
        else:
            out["facts"].append(fact(f"{dep.code} “{dep.name}”: all deployment documentation fields and permits are on record.", s))
        cl = d["checklist"]
        if cl:
            out["facts"] += [fact(f"{dep.code} readiness item not satisfied — {i['category']}: {i['note'] or i['label']}", s) for i in cl["items"] if i["status"] not in ("ok", "na")]
        else:
            out["facts"].append(fact(f"{dep.code}: the deployment readiness checklist has not been opened.", s))
        out["facts"] += [fact(f"{dep.code}: {p['name']} has no current qualification record.", s) for p in d["personnel"] if not p["qualified"]]
    if not out["facts"]:
        out["facts"].append(fact("No active deployments are recorded."))
    return out


def t_log_findings(db, u, log=None, **_):
    lg = _find(db, m.FlightLog, log) or db.scalar(select(m.FlightLog).order_by(m.FlightLog.id.desc()))
    if not lg:
        return {"facts": [fact("No flight logs have been imported.")], "hypotheses": [], "recommendations": []}
    s = src("flight_logs", lg.id, lg.code)
    out = {"facts": [fact(f"{lg.code} “{lg.name}”: data source {lg.source_class.upper()}, {lg.duration_s} s, channels: {', '.join((lg.metrics or {}).get('_channels', []))}.", s)],
           "hypotheses": [], "recommendations": []}
    for o in lg.observations or []:
        out["facts"].append(fact(f"[{o['level']}] {o['area']}: {o['fact']}", s))
        if o.get("hypothesis"):
            out["hypotheses"].append(f"{lg.code} {o['area']}: {o['hypothesis']}")
        if o.get("recommendation") and o["level"] != "info":
            out["recommendations"].append(f"{lg.code}: {o['recommendation']}")
    for e in [e for e in lg.events or [] if e["severity"] in ("warning", "critical")][:10]:
        out["facts"].append(fact(f"t={e['t']} s {e['type']}: {e['text']}", s))
    return out


def t_maintenance_status(db, u, **_):
    al = maint.all_alerts(u, db)
    out = {"facts": [fact(a["message"] + f" [{a['level']}]", *([src("aircraft", a["aircraft_id"], a.get("aircraft"))] if a.get("aircraft_id") else [])) for a in al],
           "hypotheses": [], "recommendations": []}
    if not al:
        out["facts"].append(fact("No maintenance is due or overdue."))
    return out


def t_open_issues(db, u, **_):
    names = user_names(db)
    acs = {a.id: a.code for a in db.scalars(select(m.Aircraft))}
    rows = list(db.scalars(select(m.Issue).where(m.Issue.status != "closed").order_by(m.Issue.id.desc())))
    out = {"facts": [fact(f"{i.code} [{i.severity}, {i.status}] {acs.get(i.aircraft_id, 'no aircraft')}: {i.title} — assigned to {names.get(i.assigned_to, 'nobody')}.",
                          src("issues", i.id, i.code)) for i in rows[:40]], "hypotheses": [], "recommendations": []}
    if not rows:
        out["facts"].append(fact("No open engineering issues."))
    return out


def t_training_status(db, u, **_):
    names = user_names(db)
    out = {"facts": [], "hypotheses": [], "recommendations": []}
    for q in db.scalars(select(m.Qualification).where(m.Qualification.expiry_date.is_not(None)).order_by(m.Qualification.expiry_date)):
        days = (q.expiry_date - today()).days
        if days <= 60:
            kind = "internal training record" if q.kind == "internal_training_record" else q.kind.replace("_", " ")
            out["facts"].append(fact(f"{names.get(q.user_id)}: {q.title} ({kind}) {'expired' if days < 0 else 'expires'} {q.expiry_date}.", src("qualifications", q.id, q.title)))
    courses = {c.id: c for c in db.scalars(select(m.Course))}
    for e in db.scalars(select(m.Enrollment).where(m.Enrollment.status.in_(["enrolled", "in_progress"]))):
        st = training.enrollment_state(db, e)
        out["facts"].append(fact(f"{names.get(e.student_id)} — {courses[e.course_id].title}: {st['percent']}% ({'; '.join(st['unmet']) or 'ready for instructor sign-off'}).",
                                 src("enrollments", e.id, courses[e.course_id].code)))
    out["facts"].append(fact(f"{len(courses)} courses available across categories: " + ", ".join(sorted({c.category for c in courses.values()})) + "."))
    return out


def t_search_records(db, u, query="", **_):
    q = f"%{query}%"
    out = {"facts": [], "hypotheses": [], "recommendations": []}
    for model, res, fields in ((m.Aircraft, "aircraft", ("code", "name", "model")), (m.Component, "components", ("code", "model", "serial_number")),
                               (m.Campaign, "campaigns", ("code", "name", "objectives")), (m.TestCard, "test_cards", ("code", "title")),
                               (m.Issue, "issues", ("code", "title", "description")), (m.Mission, "missions", ("code", "name")),
                               (m.Deployment, "deployments", ("code", "name", "country")), (m.Demonstration, "demonstrations", ("code", "name"))):
        for o in db.scalars(select(model).where(or_(*[getattr(model, f).ilike(q) for f in fields])).limit(8)):
            d = to_dict(o)
            brief = ", ".join(f"{k}={v}" for k, v in d.items() if v not in (None, "", [], {}) and k not in ("id", "created_at", "updated_at", "stage_log", "snapshot")
                              and not isinstance(v, (list, dict)))[:400]
            out["facts"].append(fact(f"{res}: {brief}", src(res, o.id, getattr(o, "code", None) or str(o.id))))
    if not out["facts"]:
        out["facts"].append(fact(f"No records match “{query}”."))
    return out


TOOLS = {
    "fleet_readiness": (t_fleet_readiness, "Readiness state, gates, blockers and evidence for every aircraft.", {}),
    "incomplete_tests": (t_incomplete_tests, "Test cards that are not executed, not evaluated or incomplete, plus uncovered validation areas.", {"campaign": "Campaign ID or name (optional)"}),
    "recurring_findings": (t_recurring_findings, "Aircraft with repeated flight-log observations or issues matching a keyword such as 'vibration', 'gps', 'battery', 'link'.", {"keyword": "Keyword"}),
    "compare_revisions": (t_compare_revisions, "Differences between the latest two hardware configuration revisions of an aircraft (or all aircraft).", {"aircraft": "Aircraft ID or name (optional)"}),
    "campaign_summary": (t_campaign_summary, "Summary of a test campaign: stage, results, failures, issues, outstanding conditions. Defaults to the latest campaign.", {"campaign": "Campaign ID or name (optional)"}),
    "component_failure_rates": (t_failure_rates, "Component models ranked by recorded failures, with failure rate and MTBF.", {}),
    "deployment_gaps": (t_deployment_gaps, "Missing documentation, permits, qualifications and unmet readiness items for deployments.", {"deployment": "Deployment ID or name (optional)"}),
    "flight_log_findings": (t_log_findings, "Measured observations, anomaly events and hypotheses for a flight log. Defaults to the latest log.", {"log": "Flight log ID or name (optional)"}),
    "maintenance_status": (t_maintenance_status, "Maintenance tasks due or overdue across the fleet and C2 equipment.", {}),
    "open_issues": (t_open_issues, "Open engineering issues with severity, status and assignee.", {}),
    "training_status": (t_training_status, "Active enrolments, expiring qualification records and the course catalogue.", {}),
    "search_records": (t_search_records, "Free-text search across aircraft, components, campaigns, test cards, issues, missions, deployments and demonstrations.", {"query": "Search text"}),
}

ROUTES = [
    (("vibration",), "recurring_findings", {"keyword": "vibration"}), (("gps", "gnss", "satellite"), "recurring_findings", {"keyword": "navigation"}),
    (("compare", "revision", "hardware rev"), "compare_revisions", {}), (("failure rate", "highest failure", "reliab", "mtbf"), "component_failure_rates", {}),
    (("incomplete", "remain", "outstanding test", "not executed", "coverage"), "incomplete_tests", {}),
    (("deployment", "deploy"), "deployment_gaps", {}), (("anomal", "telemetry", "post-flight", "post flight", "flight log", "flight report"), "flight_log_findings", {}),
    (("maintenance", "overdue", "inspection due"), "maintenance_status", {}), (("issue", "ticket", "defect"), "open_issues", {}),
    (("training", "course", "qualif", "certif", "licen"), "training_status", {}),
    (("campaign", "test plan"), "campaign_summary", {}), (("ready", "readiness", "validation", "grounded", "fleet", "aircraft"), "fleet_readiness", {}),
    (("demonstration", "demo "), "fleet_readiness", {}),
]
DRAFTS = {
    "test campaign plan": ("Draft test campaign plan (template — complete and review before use)",
                           ["Objectives: state what the campaign must demonstrate and for which configuration revision.",
                            "Test cards: at least one per validation area that applies — " + ", ".join(m.VALIDATION_CATEGORIES) + ".",
                            "Each card: objective, preconditions, procedure, expected result, and numeric acceptance criteria tied to flight-log metrics where possible.",
                            "Risk assessment: hazards, likelihood, severity, mitigation, residual rating; accepted by an independent Flight Operations Engineer.",
                            "Sequence: inspection → ground validation → simulation → flight-test authorization → execution → analysis → review → acceptance → report.",
                            "Personnel: responsible engineer, pilot, safety observer — each with a current qualification record."]),
    "demonstration checklist": ("Draft customer demonstration checklist (template)",
                                [f"{cat}: {label}" for cat, label, *_ in __import__("aeros.reference", fromlist=["x"]).CHECKLISTS["demo_preparation"]["items"]]
                                + ["Agree acceptance criteria with the customer in writing before the day.", "Record results and customer feedback immediately afterwards."]),
    "training program": ("Draft technical training programme (template)",
                         [f"{i + 1}. {c}" for i, c in enumerate(m.TRAINING_CATEGORIES)] + ["Each course: theory modules, a theoretical assessment (pass mark 80%), and a practical "
                                                                                           "assessment checklist signed by an instructor where the course has practical content.",
                                                                                           "Completion is an internal training record, not an aviation licence."]),
}


def records_answer(db, u, question: str) -> dict:
    ql = question.lower()
    picked = []
    for keys, tool, args in ROUTES:
        if any(k in ql for k in keys) and tool not in [p[0] for p in picked]:
            picked.append((tool, args))
    draft = next((v for k, v in DRAFTS.items() if all(w in ql for w in k.split()[:2]) or k in ql), None)
    if "checklist" in ql and "demo" in ql:
        draft = DRAFTS["demonstration checklist"]
    if "generate" in ql and "campaign" in ql or "campaign plan" in ql:
        draft = DRAFTS["test campaign plan"]
    if ("create" in ql or "generate" in ql) and "training" in ql:
        draft = DRAFTS["training program"]
    if not picked:
        picked = [("search_records", {"query": question.strip(" ?")[:60]})]
    facts, hyps, recs, used = [], [], [], []
    for tool, args in picked[:3]:
        r = TOOLS[tool][0](db, u, **args)
        facts += r["facts"]
        hyps += r["hypotheses"]
        recs += r["recommendations"]
        used.append(tool)
    db.rollback()
    return {"engine": "records", "engine_label": "Deterministic records query (no language model configured)", "tools": used, "facts": facts[:60],
            "hypotheses": list(dict.fromkeys(hyps))[:12], "recommendations": list(dict.fromkeys(recs))[:12],
            "draft": {"title": draft[0], "items": draft[1]} if draft else None, "text": None}


SYSTEM = """You are the engineering assistant inside AEROS OPS PRO, a flight operations engineering platform for UAV development teams.

You answer questions from flight operations, flight-test, UAV and maintenance engineers about their own project records. Their decisions affect the safety of physical flight tests, so the value of your answer lies in its traceability, not its fluency.

Ground every factual statement in tool results. The tools query the platform's records and return facts, each with source references; call the tools you need (several in parallel if useful) before answering. If the records do not contain something, say that plainly rather than filling the gap from general knowledge. General UAV engineering knowledge is welcome for explanation, but label it as general knowledge.

Structure the answer in Markdown with these sections, omitting any that would be empty:
**Facts** — what the records show. Cite the source after each statement in the form [type:id label], copied from the tool result.
**Hypotheses** — possible explanations or interpretations that the records do not prove. State what evidence would confirm or refute each one.
**Recommendations (require qualified review)** — suggested actions. Include this section only when you are recommending something; anything in it is queued for review by qualified personnel and is not an instruction.

Readiness states, approvals and test results are determined by the platform from recorded evidence; you cannot change them and should not suggest bypassing a gate, an approval or an independent check. Data whose source is SIMULATION or SITL is not flight data — say so whenever you use it.

Be concise and specific: engineers read this between tasks."""


def claude_answer(db, u, question: str, history: list, api_key: str) -> dict:
    import anthropic

    client = anthropic.Anthropic(api_key=api_key, timeout=120.0)
    tools = [{"name": name, "description": desc,
              "input_schema": {"type": "object", "properties": {k: {"type": "string", "description": v} for k, v in params.items()}, "additionalProperties": False}}
             for name, (_, desc, params) in TOOLS.items()]
    msgs = [{"role": h["role"], "content": h["text"]} for h in history[-8:] if h.get("text")] + [{"role": "user", "content": question}]
    facts, hyps, recs, used = [], [], [], []
    resp = None
    for _ in range(6):
        resp = client.beta.messages.create(model=MODEL, max_tokens=16000, system=SYSTEM, tools=tools, messages=msgs, thinking={"type": "adaptive"},
                                           betas=["server-side-fallback-2026-07-01"], fallbacks="default")
        if resp.stop_reason != "tool_use":
            break
        msgs.append({"role": "assistant", "content": resp.content})
        results = []
        for block in resp.content:
            if block.type != "tool_use":
                continue
            fn = TOOLS.get(block.name)
            try:
                args = {k: v for k, v in (block.input or {}).items() if isinstance(v, (str, int))}
                r = fn[0](db, u, **args) if fn else {"facts": [fact(f"Unknown tool {block.name}")], "hypotheses": [], "recommendations": []}
                facts += r["facts"]
                hyps += r["hypotheses"]
                recs += r["recommendations"]
                used.append(block.name)
                results.append({"type": "tool_result", "tool_use_id": block.id, "content": json.dumps(r, default=str)[:60000]})
            except Exception as e:
                results.append({"type": "tool_result", "tool_use_id": block.id, "content": f"Tool failed: {e}", "is_error": True})
        msgs.append({"role": "user", "content": results})
    db.rollback()
    if resp.stop_reason == "refusal":
        text = "The language model declined to answer this request. The record facts gathered so far are listed below."
    else:
        text = "\n".join(b.text for b in resp.content if b.type == "text").strip()
        if resp.stop_reason == "max_tokens":
            text += "\n\n*(Answer truncated at the output limit.)*"
    has_recs = "recommendations (require" in text.lower()
    return {"engine": "claude", "engine_label": f"Claude ({resp.model}) over project record tools", "tools": used, "facts": facts[:60], "hypotheses": [], "text": text,
            "recommendations": ["See the Recommendations section of the answer."] if has_recs else [], "draft": None}


def _msg_out(db, a: m.AssistantMessage) -> dict:
    d = {"id": a.id, "role": a.role, "created_at": a.created_at.isoformat(), **(a.content or {})}
    if a.role == "assistant":
        rv = db.scalar(select(m.Approval).where(m.Approval.kind == "ai_recommendation_review", m.Approval.subject_id == a.id).order_by(m.Approval.id.desc()))
        d["review"] = ap.approval_out(db, rv) if rv else None
    return d


@router.get("/status")
def status(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    key = bool(get_setting(db, "anthropic_api_key"))
    return {"engine": "claude" if key else "records", "model": MODEL if key else None, "review_note": REVIEW_NOTE,
            "tools": [{"name": k, "description": v[1]} for k, v in TOOLS.items()],
            "examples": ["Which aircraft are ready for validation?", "What tests remain incomplete?", "Which aircraft have recurring vibration issues?",
                         "Compare the latest two hardware revisions.", "Summarize the last test campaign.", "Which components have the highest failure rates?",
                         "Generate a test campaign plan.", "Prepare a customer demonstration checklist.", "Identify missing deployment documentation.",
                         "Create a technical training program.", "Explain this telemetry anomaly.", "Generate a post-flight engineering report."]}


@router.get("/history")
def history(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    rows = list(db.scalars(select(m.AssistantMessage).where(m.AssistantMessage.user_id == u.id).order_by(m.AssistantMessage.id.desc()).limit(60)))
    return [_msg_out(db, a) for a in reversed(rows)]


@router.delete("/history")
def clear(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    reviewed = {a.subject_id for a in db.scalars(select(m.Approval).where(m.Approval.kind == "ai_recommendation_review"))}
    for a in db.scalars(select(m.AssistantMessage).where(m.AssistantMessage.user_id == u.id)):
        if a.id not in reviewed:  # messages under review are kept as records
            db.delete(a)
    db.commit()
    return {"ok": True}


@router.post("/ask")
def ask(data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    q = (data.get("question") or "").strip()
    if not q:
        raise HTTPException(422, "Ask a question.")
    hist = [{"role": a.role, "text": (a.content or {}).get("text") or (a.content or {}).get("question")} for a in
            db.scalars(select(m.AssistantMessage).where(m.AssistantMessage.user_id == u.id).order_by(m.AssistantMessage.id.desc()).limit(8))][::-1]
    key = get_setting(db, "anthropic_api_key")
    error = None
    if key:
        import anthropic

        try:
            ans = claude_answer(db, u, q, hist, key)
        except anthropic.AuthenticationError:
            error = "The configured Anthropic API key was rejected."
        except anthropic.RateLimitError:
            error = "The Anthropic API rate limit was reached."
        except anthropic.APIStatusError as e:
            error = f"Anthropic API error {e.status_code}: {e.message}"
        except anthropic.APIConnectionError:
            error = "The Anthropic API could not be reached (network)."
        if error:
            db.rollback()
            ans = records_answer(db, u, q)
            ans["notice"] = f"{error} Answered with the deterministic records query instead."
    else:
        ans = records_answer(db, u, q)
    db.add(m.AssistantMessage(user_id=u.id, role="user", content={"question": q}, created_at=utcnow()))
    msg = m.AssistantMessage(user_id=u.id, role="assistant", content=ans, created_at=utcnow())
    db.add(msg)
    db.flush()
    if ans["recommendations"]:
        db.add(m.Approval(kind="ai_recommendation_review", subject_type="assistant_message", subject_id=msg.id, requested_by=u.id,
                          request_note=f"Review AI-generated recommendations for: {q[:200]}"))
    audit(db, u, "assistant", "assistant_message", msg.id, f"Assistant query ({ans['engine']}): {q[:120]}", {"tools": ans["tools"]})
    db.commit()
    return _msg_out(db, msg)
