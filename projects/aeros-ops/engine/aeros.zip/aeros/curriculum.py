"""Starter training curriculum installed on first run (one course per training category). Instructors can edit,
extend or replace every course. Each entry: (category, title, description, [(module title, kind, diagram, content)],
[(kind, question, options, correct index, explanation)])."""

CURRICULUM = [
    ("UAV fundamentals", "UAV Fundamentals",
     "Categories of unmanned aircraft, their main subsystems and the roles in a flight team.",
     [("Aircraft categories and subsystems", "theory", "",
       "Unmanned aircraft are grouped by how they generate lift. **Multicopters** (quad, hexa, octo) lift with fixed-pitch rotors and control "
       "attitude by varying rotor speed; they hover and take off vertically but are energy-hungry. **Fixed-wing** aircraft lift with a wing and "
       "need airspeed, giving long endurance but no hover. **VTOL** hybrids combine both.\n\nEvery platform has the same building blocks: airframe, "
       "propulsion (motor, ESC, propeller), energy storage, flight controller with its sensors, a command-and-control link, and usually a payload."),
      ("The flight team", "theory", "",
       "A test flight is a team activity. The **pilot / operator** controls the aircraft. The **flight-test engineer** owns the test card and decides "
       "whether a test point is complete. The **safety observer** watches the aircraft and airspace and can call an abort. Roles are assigned before "
       "the flight and nobody holds two conflicting roles at once.")],
     [("theory", "Why can a conventional multicopter not glide after a total power loss?",
       ["Its rotors are fixed-pitch and produce lift only when driven", "Its flight controller disables gliding", "It is too light", "Its battery is too large"], 0,
       "Fixed-pitch rotors need motor power; there is no wing to convert height into lift."),
      ("theory", "Which subsystem turns the flight controller's commands into motor speed?", ["GPS module", "ESC", "Barometer", "Telemetry radio"], 1,
       "The electronic speed controller commutates the motor at the commanded speed."),
      ("scenario", "During a test the safety observer calls “abort” but the test point is 5 seconds from complete. What happens?",
       ["Finish the test point first", "The pilot aborts immediately", "The flight-test engineer decides", "Ask the customer"], 1,
       "An abort call is acted on immediately by the pilot; it is discussed afterwards.")]),
    ("Flight theory", "Flight Theory for Multicopters and Fixed-Wing",
     "Forces in flight, thrust margin, and why wind and density matter.",
     [("Forces and thrust margin", "theory", "multicopter_forces",
       "In a steady hover total rotor thrust equals weight. To accelerate forward the aircraft tilts, so part of the thrust acts horizontally and "
       "total thrust must rise to hold altitude. The **thrust-to-weight ratio** at maximum take-off mass therefore sets how much margin remains for "
       "manoeuvre and gust rejection; about 2:1 is a common minimum for multicopters.\n\nAir density falls with altitude and temperature, reducing "
       "thrust and wing lift. A configuration that is comfortable at sea level on a cold day can be marginal on a hot day at altitude."),
      ("Wind", "theory", "",
       "The aircraft flies in the air mass. In a headwind, ground speed drops and energy per metre of ground covered rises. A mission is only "
       "feasible if cruise airspeed comfortably exceeds the wind, and the return leg must be planned for the worst case.")],
     [("theory", "A quadcopter pitches forward to accelerate. To hold altitude, total thrust must:", ["Decrease", "Stay the same", "Increase", "Drop to zero"], 2,
       "Only the vertical component of thrust supports weight, so total thrust must increase when tilted."),
      ("theory", "Hot weather at a high-altitude site mainly reduces:", ["GPS accuracy", "Air density and therefore thrust", "Battery capacity only", "Radio range"], 1,
       "Lower density reduces rotor thrust and wing lift."),
      ("scenario", "Cruise speed is 8 m/s and the forecast wind is 7 m/s along the outbound leg. The correct decision is:",
       ["Fly — 8 is more than 7", "Postpone or re-plan; the margin is inadequate", "Fly faster than cruise the whole way", "Remove the geofence"], 1,
       "With 1 m/s of ground speed on one leg the energy plan and gust margin are not credible.")]),
    ("Aircraft systems", "Aircraft Systems: Propulsion and Power",
     "How motors, ESCs, propellers and batteries are matched.",
     [("The power train", "theory", "power_train",
       "The battery supplies DC to the ESCs, which drive brushless motors turning the propellers. Matching matters: battery **cell count** must lie "
       "within the motor and ESC voltage range; the ESC's **continuous current** rating must exceed the motor's maximum current with margin; and the "
       "propeller diameter and pitch must suit the motor's KV and the supply voltage. The pack must be able to deliver the combined peak current "
       "(capacity in Ah × C rating)."),
      ("Inspecting the power train", "practical", "",
       "With propellers removed: check each motor spins freely without grinding, mounts are tight, ESC solder joints and connectors show no heat "
       "damage, and the battery is not swollen or punctured. Record findings as a maintenance inspection.")],
     [("theory", "A 6S battery is fitted to ESCs rated for 2–4S. This is:", ["Fine if flown gently", "An over-voltage incompatibility", "Only a problem in cold weather", "Recommended for more thrust"], 1,
       "Exceeding the ESC voltage rating can destroy it in flight."),
      ("theory", "A 5000 mAh pack rated 20C can continuously deliver about:", ["20 A", "50 A", "100 A", "250 A"], 2, "5 Ah × 20 = 100 A."),
      ("scenario", "One motor feels gritty when turned by hand during inspection. You should:",
       ["Fly and monitor", "Record it and remove the motor from service for inspection", "Add oil to the bell", "Swap the propeller only"], 1,
       "A bearing defect is a finding: record it and rectify before flight.")]),
    ("Avionics", "Avionics and Wiring",
     "Flight controller peripherals, buses and installation practice.",
     [("Avionics architecture", "theory", "",
       "The flight controller reads inertial sensors, barometer, magnetometer and GNSS, and talks to peripherals over serial (UART), I²C, SPI and "
       "CAN. Power is supplied through a regulated power module that also measures battery voltage and current. Installation practice matters: keep "
       "the magnetometer and GNSS antenna away from high-current wiring, secure every connector, and isolate the flight controller from vibration.")],
     [("theory", "Why is a magnetometer mounted away from battery leads?", ["To keep it cool", "High currents create magnetic fields that disturb heading", "To save weight", "For GPS reception"], 1,
       "Current-induced fields corrupt the heading measurement."),
      ("theory", "The power module provides the flight controller with:", ["Motor commands", "Regulated power plus voltage and current measurement", "GPS corrections", "RC input"], 1,
       "It both powers the controller and senses the battery."),
      ("scenario", "After moving the GNSS mast next to the telemetry radio, satellite count drops in flight. First hypothesis to test:",
       ["Battery ageing", "RF interference from the radio", "Propeller imbalance", "Wrong firmware"], 1,
       "Co-located transmitters are a common cause; verify by test before concluding.")]),
    ("Flight-controller architecture", "Flight-Controller Architecture",
     "Estimation, control loops and failsafes in PX4 and ArduPilot class autopilots.",
     [("Estimator and control loops", "theory", "control_loop",
       "An autopilot is a cascade. A state **estimator** (EKF) fuses IMU, GNSS, barometer and magnetometer into attitude, velocity and position. The "
       "**position** controller turns a position error into a velocity and attitude setpoint; the **attitude** controller turns that into body-rate "
       "setpoints; the **rate** controller drives the mixer and motors. Inner loops run fastest. Poor tracking is diagnosed from the inside out: rate, "
       "then attitude, then position."),
      ("Failsafes", "theory", "",
       "Failsafes are configured responses to lost capability: control-link loss, low battery, geofence breach and estimator failure. Each must be "
       "configured deliberately and verified on the ground before flight testing.")],
     [("theory", "Which loop runs fastest in the control cascade?", ["Position", "Velocity", "Attitude", "Rate"], 3, "The body-rate loop is innermost and fastest."),
      ("theory", "The estimator's job is to:", ["Command the motors", "Fuse sensor data into a state estimate", "Log data", "Charge the battery"], 1,
       "Controllers act on the estimated state."),
      ("scenario", "Logs show good rate tracking but poor attitude tracking. Where do you look first?",
       ["Rate controller gains", "Attitude controller gains", "GNSS antenna", "Telemetry radio"], 1, "The innermost loop that is misbehaving is the attitude loop.")]),
    ("Autonomous mission planning", "Autonomous Mission Planning",
     "Building, bounding and validating a waypoint mission.",
     [("Planning inside a boundary", "theory", "",
       "A mission is planned inside an **operational boundary**: a geofence polygon, a maximum height and a maximum distance from home. Every "
       "waypoint and every leg, including the return to launch, must stay inside it. Add emergency landing locations, check the energy budget with "
       "at least 20% reserve, and set speed for the expected wind."),
      ("Simulate before you fly", "scenario", "",
       "Validate the mission, then run it in simulation. Simulation and physical operations are separate workflows: sending a mission to a physical "
       "aircraft needs a release from a Flight Operations Engineer and an independent safety check by another person.")],
     [("theory", "A mission's return-to-launch leg crosses outside the geofence. The mission is:", ["Valid, RTL is exempt", "Invalid until re-planned", "Valid if flown fast", "Valid in simulation only"], 1,
       "Every leg including RTL must be inside the boundary."),
      ("theory", "The minimum planned battery reserve at landing on this platform is:", ["5%", "10%", "20%", "50%"], 2, "Missions are planned to land with at least 20%."),
      ("scenario", "You approved the physical mission release. Who may perform the independent safety check?",
       ["You, since you know the mission", "A different qualified person", "Nobody; it is optional", "The customer"], 1,
       "Independence means a different person from the one who approved the release.")]),
    ("Ground control station operation", "Ground Control Station Operation",
     "Setting up the station, the link and telemetry monitoring.",
     [("Station set-up and link", "theory", "c2_link",
       "The ground control station is a computer, a radio and antennas. Verify power and backup, software version, antenna orientation and the "
       "licensed frequency before connecting. Once linked, watch signal quality, packet loss and latency; a link that is marginal on the ground will "
       "not improve with range."),
      ("Station set-up exercise", "practical", "",
       "Set up the station, open the telemetry link, confirm heartbeat and parameters, start a telemetry recording, and demonstrate the link-loss "
       "indication by powering down the air radio.")],
     [("theory", "Packet loss rises steadily as the aircraft flies away. The most likely cause is:", ["Low battery", "Link margin reducing with range", "GPS drift", "Wrong flight mode"], 1,
       "Received signal falls with distance."),
      ("theory", "Before connecting, the radio frequency and power must:", ["Be as high as possible", "Comply with the local licence or authorization", "Match the GPS band", "Be changed each flight"], 1,
       "Operating outside the authorization is not permitted."),
      ("scenario", "Telemetry stops for 6 seconds in flight then returns. You should:",
       ["Ignore it", "Log it as a communication interruption and review failsafe behaviour", "Increase TX power beyond the licence", "Land in the nearest field immediately"], 1,
       "Record the event; the link-loss failsafe and the cause need review.")]),
    ("Sensor systems", "Sensor Systems",
     "IMU, barometer, magnetometer, GNSS and range sensors: what they measure and how they fail.",
     [("Sensors and their failure modes", "theory", "",
       "The **IMU** measures acceleration and rotation rate; it is sensitive to vibration and temperature. The **barometer** measures pressure "
       "altitude and is disturbed by prop wash and sunlight. The **magnetometer** gives heading and is disturbed by nearby current and steel. "
       "**GNSS** gives position and velocity; quality is judged by satellite count and HDOP. **LiDAR / optical flow** give height and velocity near "
       "the ground. Knowing the failure mode tells you which log channel to check.")],
     [("theory", "HDOP is a measure of:", ["Battery health", "Satellite geometry quality", "Vibration", "Radio strength"], 1, "Lower HDOP means better geometry."),
      ("theory", "Which sensor is most directly degraded by airframe vibration?", ["GNSS", "IMU", "Magnetometer", "Telemetry radio"], 1, "Accelerometers and gyros sense vibration directly."),
      ("scenario", "Altitude hold wanders when the aircraft flies fast forward but is steady in hover. First hypothesis:",
       ["Barometer affected by airflow", "GNSS failure", "Low battery", "Bad propeller"], 0, "Dynamic pressure on the baro port is a classic cause; confirm with logs.")]),
    ("Battery management", "Battery Management",
     "Lithium pack handling, limits and life tracking.",
     [("Limits and care", "theory", "",
       "Lithium-polymer cells operate between about 3.3 V and 4.2 V. Discharging below the lower limit, charging above the upper limit, or exceeding "
       "the current rating damages the cell and can cause fire. Store at roughly 3.8 V per cell, charge in a fire-resistant container, never charge "
       "unattended, and quarantine any pack that is swollen, punctured or was in a crash.\n\nTrack **cycle count** and watch **internal resistance**: "
       "rising resistance shows as deeper voltage sag under load.")],
     [("theory", "A 4S pack reads 12.4 V under load in flight. Per cell that is:", ["4.1 V", "3.6 V", "3.1 V", "2.8 V"], 2, "12.4 / 4 = 3.1 V per cell — below the safe minimum."),
      ("theory", "Rising internal resistance in a pack shows up as:", ["Higher capacity", "Deeper voltage sag under load", "Lower temperature", "Faster charging"], 1,
       "Sag = current × internal resistance."),
      ("scenario", "A pack is slightly swollen after a flight. You should:", ["Charge it slowly", "Quarantine it and record the finding", "Fly one more time", "Puncture it to release gas"], 1,
       "A swollen pack is unserviceable.")]),
    ("Pre-flight inspections", "Pre-Flight Inspections",
     "A repeatable inspection flow and what counts as a finding.",
     [("Inspection flow", "theory", "preflight_flow",
       "Inspect in a fixed order so nothing is skipped: structure, propulsion, electrical, avionics, payload, then configuration against the "
       "released record. A check item is signed only when it has actually been checked. Anything abnormal is a **finding**: record it, and do not "
       "fly until it is rectified or assessed as acceptable by an authorized person."),
      ("Inspection exercise", "practical", "", "Perform the aircraft inspection checklist on a training airframe and record one seeded defect correctly.")],
     [("theory", "An inspection item was not checked because of time pressure. It should be:", ["Signed OK", "Left pending and reported", "Marked N/A", "Signed by a colleague"], 1,
       "Only checked items are signed."),
      ("theory", "Installed serial numbers are compared with:", ["The purchase order", "The released configuration record", "The weather report", "The training record"], 1,
       "The released configuration is the reference."),
      ("scenario", "You find a hairline crack in a propeller. The correct action is:", ["Tape it", "Replace it and record the action", "Fly at low throttle", "Ignore if under 5 mm"], 1,
       "Damaged propellers are replaced, and the action is recorded.")]),
    ("Emergency procedures", "Emergency Procedures",
     "Recognise, announce and act: link loss, fly-away, low battery and loss of control.",
     [("Standard responses", "theory", "",
       "Emergencies are handled with briefed, rehearsed actions. **Link loss:** confirm the failsafe has triggered, keep visual contact, clear the "
       "landing area. **Low battery:** land at the nearest safe site, not necessarily home. **Fly-away / loss of control:** announce it, keep "
       "people clear, use the flight-termination function if the aircraft leaves the boundary. Afterwards secure the aircraft, preserve logs and "
       "report the incident."),
      ("Emergency scenarios", "scenario", "", "Work through the scenario questions in the assessment, then rehearse the link-loss drill in the practical session.")],
     [("theory", "With a critically low battery far from home, the priority is to:", ["Return home at full speed", "Land at the nearest safe site", "Climb for better link", "Continue the mission"], 1,
       "Reaching the ground under control matters more than reaching home."),
      ("theory", "After any incident, flight logs should be:", ["Deleted to save space", "Preserved as evidence", "Edited for clarity", "Shared publicly"], 1, "Logs are evidence for the investigation."),
      ("scenario", "Telemetry and RC are both lost and the aircraft continues its mission. You should first:",
       ["Chase it", "Announce the emergency, keep visual contact and clear the expected landing area", "Switch off the ground station", "Wait silently"], 1,
       "Announce, observe, protect people; the failsafe is expected to act.")]),
    ("Maintenance and troubleshooting", "Maintenance and Troubleshooting",
     "Scheduled and condition-based maintenance, and structured fault-finding.",
     [("Maintenance principles", "theory", "",
       "**Scheduled** maintenance is driven by flight hours, cycles or calendar time. **Condition-based** maintenance is triggered by a finding or a "
       "trend, such as rising vibration. Every action is recorded against the aircraft and component so reliability can be measured.\n\n"
       "Troubleshoot methodically: reproduce the symptom, form one hypothesis, change one thing, test, and record the result."),
      ("Fault-finding exercise", "practical", "", "Diagnose a seeded fault on a training airframe and record the maintenance action with findings.")],
     [("theory", "Replacing a motor because vibration has trended upward is:", ["Scheduled maintenance", "Condition-based maintenance", "A modification", "Unnecessary"], 1,
       "It is triggered by measured condition."),
      ("theory", "Good troubleshooting changes:", ["Everything at once", "One thing at a time", "Nothing", "Only software"], 1, "Otherwise the cause cannot be identified."),
      ("scenario", "After a firmware update the aircraft's configuration record no longer matches. Before the next test flight you must:",
       ["Nothing", "Capture and release a new configuration revision and repeat the affected validation", "Revert the log files", "Change the serial number"], 1,
       "A configuration change invalidates approvals bound to the old revision.")]),
    ("Flight-test documentation", "Flight-Test Documentation",
     "Test cards, evidence and traceability.",
     [("Test cards and evidence", "theory", "",
       "A **test card** states the objective, preconditions, procedure, expected result and **acceptance criteria** before the flight. After the "
       "flight it records actual results, measured parameters, observations and deviations. A test passes only when every required measurement "
       "exists, meets its criterion, and is supported by evidence such as the flight log. A missing measurement is *incomplete*, never a pass. "
       "Signed cards are locked; new results go on a retest card.")],
     [("theory", "A required measurement was not recorded. The test result is:", ["Pass", "Fail", "Incomplete", "Deferred"], 2, "Without the evidence the test cannot be judged."),
      ("theory", "Acceptance criteria are written:", ["After seeing the data", "Before the test", "By the customer only", "Only for failed tests"], 1, "Criteria fixed in advance prevent bias."),
      ("scenario", "A signed card contains a typo in a measured value. You should:", ["Edit the signed card", "Create a retest / corrected card with the reason recorded", "Delete the card", "Ignore it"], 1,
       "Signed records are not altered; corrections are traceable.")]),
    ("Operational safety", "Operational Safety",
     "Authorization, risk assessment and the separation of duties.",
     [("Authorization and risk", "theory", "",
       "No physical flight takes place without authorization. A **risk assessment** identifies hazards, their likelihood and severity, and the "
       "mitigations that reduce them. The person who prepares a request does not approve it: **independent review** is a safety control, not "
       "bureaucracy. Site permission, airspace status, weather limits and crew qualification are all checked before every operation."),
      ("Human factors", "theory", "",
       "Most incidents involve time pressure, assumption or distraction. Use checklists, speak up, and treat “we always do it this way” as a "
       "prompt to check.")],
     [("theory", "Who may approve a flight-test authorization request?", ["The requester", "An independent authorized Flight Operations Engineer", "Any operator", "The customer"], 1,
       "Independent approval is required."),
      ("theory", "A risk's rating combines:", ["Cost and schedule", "Likelihood and severity", "Altitude and speed", "Mass and power"], 1, "Risk = likelihood × severity."),
      ("scenario", "The site owner's permission expired yesterday; the team is on site and ready. You should:",
       ["Fly, it was valid yesterday", "Not fly until a current authorization is obtained", "Fly at low altitude", "Fly from the car park"], 1,
       "Operations need a current site authorization.")]),
]


def install(db) -> int:
    from . import models as m

    if db.query(m.Course).count():
        return 0
    for i, (cat, title, desc, modules, questions) in enumerate(CURRICULUM):
        c = m.Course(code=f"CRS-{i + 1:04d}", title=title, category=cat, description=desc, validity_months=24, pass_mark=80, active=True)
        db.add(c)
        db.flush()
        for j, (mt, kind, diagram, content) in enumerate(modules):
            db.add(m.CourseModule(course_id=c.id, seq=j + 1, title=mt, kind=kind, diagram=diagram, content=content))
        for j, (kind, text, options, answer, expl) in enumerate(questions):
            db.add(m.QuizQuestion(course_id=c.id, seq=j + 1, kind=kind, text=text, options=options, answer=answer, explanation=expl))
    return len(CURRICULUM)
