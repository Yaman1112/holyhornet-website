"""Autonomous mission management: planning, boundary validation, simulation, revision history, import / export,
and the release controls that separate simulation from physical aircraft operations."""
import json
import math

from fastapi import APIRouter, Body, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import analysis, approvals as ap, fleet, models as m, simulator
from .core import audit, internal_user, next_code, require, to_dict, user_names
from .db import get_db
from .flightdata import haversine
from .resources import hook

router = APIRouter(prefix="/api")
PLANNERS = ("flight_ops", "flight_test", "uav_eng", "operator")
PLAN_FIELDS = ("home", "waypoints", "geofence", "emergency_sites", "environment", "cruise_speed")
INTEGRATIONS = [
    {"name": "MAVLink", "status": "implemented", "detail": "Mission upload (MISSION_COUNT / MISSION_ITEM_INT), telemetry over UDP, TCP and serial via pymavlink."},
    {"name": "PX4", "status": "implemented", "detail": "QGroundControl .plan export / import with firmwareType 12; ULog import; MAVLink telemetry, mission upload and SITL over UDP 14550 (verified against PX4 SITL)."},
    {"name": "ArduPilot", "status": "implemented", "detail": "QGC WPL 110 .waypoints export / import; DataFlash BIN and tlog import; MAVLink telemetry and SITL."},
    {"name": "QGroundControl", "status": "implemented", "detail": "Plan files (mission items, inclusion geofence polygon, rally points) open directly in QGroundControl."},
    {"name": "Mission Planner", "status": "implemented", "detail": "QGC WPL 110 waypoint files load in Mission Planner's Plan view."},
    {"name": "ROS 2", "status": "implemented", "detail": "Read-only rclpy bridge (tools/ros2_bridge): live telemetry as NavSatFix, PoseStamped and BatteryState, mission path as nav_msgs/Path; GeoJSON mission export."},
]


def inside(poly: list, lat: float, lon: float) -> bool:
    n, c = len(poly), False
    for i in range(n):
        y1, x1 = poly[i]
        y2, x2 = poly[(i + 1) % n]
        if (y1 > lat) != (y2 > lat) and lon < (x2 - x1) * (lat - y1) / (y2 - y1) + x1:
            c = not c
    return c


def path_points(ms_or_dict) -> list:
    g = ms_or_dict.get if isinstance(ms_or_dict, dict) else lambda k: getattr(ms_or_dict, k)
    home, wps = g("home") or {}, g("waypoints") or []
    pts = [(home["lat"], home["lon"])] if home.get("lat") is not None else []
    pts += [(w["lat"], w["lon"]) for w in wps]
    if pts and home.get("lat") is not None:
        pts.append((home["lat"], home["lon"]))
    return pts


def validate(plan: dict, snap: dict | None) -> dict:
    """Geofence, boundary, altitude, speed and energy validation of a mission plan."""
    out = []

    def add(level, rule, msg):
        out.append({"level": level, "rule": rule, "message": msg})

    home, wps = plan.get("home") or {}, plan.get("waypoints") or []
    fence, sites, env = plan.get("geofence") or {}, plan.get("emergency_sites") or [], plan.get("environment") or {}
    cruise = float(plan.get("cruise_speed") or 0)
    if home.get("lat") is None or home.get("lon") is None:
        add("error", "Home position", "Home / launch position is not set.")
    if not wps:
        add("error", "Waypoints", "The mission has no waypoints.")
    if out:
        return {"ok": False, "checks": out, "stats": {}}
    pts = path_points(plan)
    legs = [float(haversine(a[0], a[1], b[0], b[1])) for a, b in zip(pts[:-1], pts[1:])]
    total = sum(legs)
    poly = fence.get("polygon") or []
    if len(poly) < 3:
        add("error", "Geofence", "No geofence polygon is defined. A mission cannot be validated without an operational boundary.")
    else:
        outside = [i for i, w in enumerate(wps) if not inside(poly, w["lat"], w["lon"])]
        if not inside(poly, home["lat"], home["lon"]):
            add("error", "Geofence", "Home position is outside the geofence.")
        if outside:
            add("error", "Geofence", "Waypoints outside the geofence: " + ", ".join(str(i + 1) for i in outside))
        crossing = []
        for i, (a, b) in enumerate(zip(pts[:-1], pts[1:])):
            n = max(2, int(legs[i] / 5))
            if any(not inside(poly, a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n) for k in range(1, n)):
                crossing.append(i + 1)
        if crossing and not outside:
            add("error", "Geofence", "Flight path leaves the geofence on leg(s): " + ", ".join(map(str, crossing)) + " (including the return leg).")
        if not outside and not crossing and inside(poly, home["lat"], home["lon"]):
            add("ok", "Geofence", "Home, all waypoints and every leg (including the return to launch) are inside the geofence.")
    lo, hi = fence.get("alt_min"), fence.get("alt_max")
    if hi in (None, ""):
        add("error", "Altitude limits", "No maximum altitude is defined for the operational boundary.")
    else:
        bad = [i + 1 for i, w in enumerate(wps) if float(w.get("alt") or 0) > float(hi) or float(w.get("alt") or 0) < float(lo or 0)]
        add("error" if bad else "ok", "Altitude limits",
            f"Waypoints outside {float(lo or 0):g}–{float(hi):g} m above home: {', '.join(map(str, bad))}" if bad
            else f"All waypoint altitudes are within {float(lo or 0):g}–{float(hi):g} m above home.")
    low = [i + 1 for i, w in enumerate(wps) if float(w.get("alt") or 0) < 2]
    if low:
        add("error", "Altitude limits", f"Waypoints below 2 m above home: {', '.join(map(str, low))}")
    far = max(float(haversine(home["lat"], home["lon"], w["lat"], w["lon"])) for w in wps)
    md = fence.get("max_distance")
    if md not in (None, ""):
        add("error" if far > float(md) else "ok", "Mission boundary", f"Furthest waypoint is {far:.0f} m from home; limit {float(md):g} m.")
    speeds = [float(w.get("speed") or cruise) for w in wps]
    if cruise <= 0:
        add("error", "Speed constraints", "Cruise speed is not set.")
    elif any(s < 0.5 or s > 40 for s in speeds):
        add("error", "Speed constraints", "Waypoint speeds must be between 0.5 and 40 m/s.")
    else:
        add("ok", "Speed constraints", f"Speeds between {min(speeds):g} and {max(speeds):g} m/s.")
    short = [i + 1 for i, l_ in enumerate(legs[:-1]) if l_ < 2 and i > 0]
    if short:
        add("warning", "Waypoints", f"Legs shorter than 2 m (possible duplicates): {', '.join(map(str, short))}")
    if not sites:
        add("warning", "Emergency landing", "No emergency landing location is defined.")
    else:
        worst = max(min(float(haversine(w["lat"], w["lon"], s["lat"], s["lon"])) for s in sites + [home]) for w in wps)
        add("ok", "Emergency landing", f"{len(sites)} emergency landing location(s); the furthest waypoint is {worst:.0f} m from the nearest site or home.")
    wind = float(env.get("wind_speed") or 0)
    if cruise > 0 and wind >= cruise:
        add("error", "Environment", f"Planned wind {wind:g} m/s is at or above the cruise speed {cruise:g} m/s.")
    elif cruise > 0 and wind > 0.6 * cruise:
        add("warning", "Environment", f"Planned wind {wind:g} m/s exceeds 60% of the cruise speed.")
    # energy estimate from the kinematic model
    p = simulator.params_from_snapshot(snap, cruise or None)
    climb = sum(abs(float(b.get("alt") or 0) - float(a.get("alt") or 0)) for a, b in zip([{"alt": 0}] + wps, wps + [{"alt": 0}]))
    t_est = total / max(cruise, 0.5) + climb / 2.0 + sum(float(w.get("hold_s") or 0) for w in wps)
    mah = p.hover_power() * 1.15 / (p.cells * 3.7) * t_est / 3.6
    frac = mah / p.capacity_mah
    lvl = "error" if frac > 0.8 else "warning" if frac > 0.6 else "ok"
    add(lvl, "Energy", f"Estimated {mah:.0f} mAh ({100 * frac:.0f}% of {p.capacity_mah:.0f} mAh) for {t_est / 60:.1f} min; planning limit 80%.")
    for a in p.assumptions:
        add("unverified", "Energy", a)
    return {"ok": not any(c["level"] == "error" for c in out), "checks": out,
            "stats": {"distance_m": round(total), "est_time_s": round(t_est), "est_mah": round(mah), "max_distance_home_m": round(far), "waypoints": len(wps)}}


def _mission(db, mid) -> m.Mission:
    ms = db.get(m.Mission, mid)
    if not ms:
        raise HTTPException(404, "Mission not found")
    return ms


def _snap(db, ms):
    ac = db.get(m.Aircraft, ms.aircraft_id) if ms.aircraft_id else None
    return fleet.snapshot(db, ac) if ac else None


def plan_of(ms: m.Mission) -> dict:
    return {f: getattr(ms, f) for f in PLAN_FIELDS}


@hook("missions", "after_create")
def _mission_created(db, user, obj, data):
    db.add(m.MissionRevision(mission_id=obj.id, number=1, snapshot=plan_of(obj), note="Created", created_by=user.id))


@router.get("/integrations")
def integrations(u: m.User = Depends(internal_user)):
    return INTEGRATIONS


@router.get("/missions/{mid}")
def mission_detail(mid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    ms = _mission(db, mid)
    names = user_names(db)
    d = to_dict(ms)
    d["revisions"] = [dict(to_dict(r), created_by_name=names.get(r.created_by), waypoints=len((r.snapshot or {}).get("waypoints") or []))
                      for r in db.scalars(select(m.MissionRevision).where(m.MissionRevision.mission_id == mid).order_by(m.MissionRevision.number.desc()))]
    for r in d["revisions"]:
        r.pop("snapshot")
    d["sim_runs"] = [dict(to_dict(s), run_by_name=names.get(s.run_by)) for s in
                     db.scalars(select(m.SimRun).where(m.SimRun.mission_id == mid).order_by(m.SimRun.id.desc()).limit(20))]
    for s in d["sim_runs"]:
        (s.get("summary") or {}).pop("track", None)
    d["approvals"] = [ap.approval_out(db, a, names) for a in db.scalars(
        select(m.Approval).where(m.Approval.subject_type == "mission", m.Approval.subject_id == mid).order_by(m.Approval.id.desc()))]
    d["physical_release"] = physical_release_status(db, ms)
    return d


@router.put("/missions/{mid}/plan")
def save_plan(mid: int, data: dict = Body(...), u: m.User = Depends(require(*PLANNERS)), db: Db = Depends(get_db)):
    ms = _mission(db, mid)
    before = json.dumps(plan_of(ms), sort_keys=True)
    for f in PLAN_FIELDS:
        if f in data:
            setattr(ms, f, data[f])
    for i, w in enumerate(ms.waypoints or []):
        try:
            w["lat"], w["lon"], w["alt"] = float(w["lat"]), float(w["lon"]), float(w.get("alt") or 0)
        except (KeyError, TypeError, ValueError):
            raise HTTPException(422, f"Waypoint {i + 1} needs numeric latitude, longitude and altitude.")
        if not (-90 <= w["lat"] <= 90 and -180 <= w["lon"] <= 180):
            raise HTTPException(422, f"Waypoint {i + 1} has coordinates out of range.")
    if json.dumps(plan_of(ms), sort_keys=True) == before:
        return mission_detail(mid, u, db)
    ms.revision = (ms.revision or 1) + 1
    ms.status, ms.validation = "draft", None
    db.add(m.MissionRevision(mission_id=mid, number=ms.revision, snapshot=plan_of(ms), note=data.get("note") or "Plan edited", created_by=u.id))
    audit(db, u, "mission_plan", "mission", mid, f"Mission {ms.code} plan saved as revision {ms.revision}; validation and releases reset")
    db.commit()
    return mission_detail(mid, u, db)


@router.post("/missions/{mid}/restore/{number}")
def restore(mid: int, number: int, u: m.User = Depends(require(*PLANNERS)), db: Db = Depends(get_db)):
    r = db.scalar(select(m.MissionRevision).where(m.MissionRevision.mission_id == mid, m.MissionRevision.number == number))
    if not r:
        raise HTTPException(404, "Revision not found")
    return save_plan(mid, dict(r.snapshot, note=f"Restored from revision {number}"), u, db)


@router.post("/missions/{mid}/validate")
def validate_ep(mid: int, u: m.User = Depends(require(*PLANNERS)), db: Db = Depends(get_db)):
    ms = _mission(db, mid)
    res = validate(plan_of(ms), _snap(db, ms))
    ms.validation = dict(res, revision=ms.revision)
    ms.status = "validated" if res["ok"] else "draft"
    audit(db, u, "mission_validate", "mission", mid, f"Mission {ms.code} rev {ms.revision} validation: {'PASS' if res['ok'] else 'FAIL'}")
    db.commit()
    return mission_detail(mid, u, db)


@router.post("/missions/{mid}/simulate")
def simulate(mid: int, data: dict = Body({}), u: m.User = Depends(require(*PLANNERS)), db: Db = Depends(get_db)):
    """Run the mission in the internal kinematic simulator (faster than real time) and record the result."""
    ms = _mission(db, mid)
    if ms.status not in ("validated", "sim_passed") or (ms.validation or {}).get("revision") != ms.revision:
        raise HTTPException(409, "Validate the current mission revision before simulating it.")
    ac = db.get(m.Aircraft, ms.aircraft_id) if ms.aircraft_id else None
    params = simulator.params_from_snapshot(_snap(db, ms), ms.cruise_speed)
    faults = data.get("faults") or []
    rec, summary = simulator.run_offline(plan_of(ms), params, faults)
    poly, fence = (ms.geofence or {}).get("polygon") or [], ms.geofence or {}
    track = summary.pop("track")
    breaches = sum(1 for la, lo, h in track if (len(poly) >= 3 and not inside(poly, la, lo)) or (fence.get("alt_max") and h > float(fence["alt_max"]) + 2))
    summary["geofence_breaches"] = breaches
    reasons = []
    if not summary["completed"]:
        reasons.append("Mission did not complete and land normally" + (" (low-battery failsafe)" if summary["failsafe"] else " (time limit)" if summary["timed_out"] else ""))
    if breaches:
        reasons.append(f"Simulated track left the operational boundary at {breaches} sample(s)")
    if summary["min_remaining_pct"] < 20:
        reasons.append(f"Battery reserve at landing {summary['min_remaining_pct']}% is below the 20% minimum")
    if faults:
        reasons.append("Fault injection was active — a faulted run is a rehearsal and cannot count as a validation pass")
    summary["reasons"], summary["faults"] = reasons, faults
    result = "fail" if reasons else "pass"
    log = analysis.store_log(db, u, rec, "simulation", "simulation", f"SIM {ms.code} rev {ms.revision}", ms.aircraft_id, ms.id)
    run = m.SimRun(mission_id=mid, mission_revision=ms.revision, aircraft_id=ms.aircraft_id, config_revision_id=ac.current_revision_id if ac else None,
                   engine="internal_kinematic", result=result, summary=summary, flight_log_id=log.id, run_by=u.id)
    db.add(run)
    ms.status = "sim_passed" if result == "pass" else "validated"
    audit(db, u, "mission_simulate", "mission", mid, f"Mission {ms.code} rev {ms.revision} internal simulation: {result.upper()}", {"reasons": reasons})
    db.commit()
    return {"result": result, "summary": summary, "flight_log_id": log.id, "mission": mission_detail(mid, u, db)}


# ───────────── import / export ─────────────
def to_qgc_plan(ms: m.Mission, firmware: int) -> dict:
    home, wps = ms.home or {}, ms.waypoints or []
    items, n = [], 1

    def item(cmd, lat, lon, alt, p1=0.0):
        nonlocal n
        items.append({"AMSLAltAboveTerrain": None, "Altitude": alt, "AltitudeMode": 1, "autoContinue": True, "command": cmd, "doJumpId": n,
                      "frame": 3, "params": [p1, 0, 0, None, lat, lon, alt], "type": "SimpleItem"})
        n += 1

    if wps:
        item(22, wps[0]["lat"], wps[0]["lon"], wps[0]["alt"])
    for w in wps:
        item(16, w["lat"], w["lon"], w["alt"], float(w.get("hold_s") or 0))
    items.append({"autoContinue": True, "command": 20, "doJumpId": n, "frame": 2, "params": [0, 0, 0, 0, 0, 0, 0], "type": "SimpleItem"})
    poly = (ms.geofence or {}).get("polygon") or []
    return {"fileType": "Plan", "version": 1, "groundStation": "AEROS OPS PRO",
            "geoFence": {"circles": [], "polygons": [{"inclusion": True, "polygon": poly, "version": 1}] if len(poly) >= 3 else [], "version": 2},
            "rallyPoints": {"points": [[s["lat"], s["lon"], float(s.get("alt") or 0)] for s in ms.emergency_sites or []], "version": 2},
            "mission": {"cruiseSpeed": ms.cruise_speed or 8, "hoverSpeed": ms.cruise_speed or 5, "firmwareType": firmware, "vehicleType": 2, "version": 2,
                        "globalPlanAltitudeMode": 1, "plannedHomePosition": [home.get("lat"), home.get("lon"), home.get("alt") or 0], "items": items}}


def to_wpl(ms: m.Mission) -> str:
    home, wps = ms.home or {}, ms.waypoints or []
    rows = [f"0\t1\t0\t16\t0\t0\t0\t0\t{home.get('lat', 0):.7f}\t{home.get('lon', 0):.7f}\t{float(home.get('alt') or 0):.2f}\t1"]
    if wps:
        rows.append(f"1\t0\t3\t22\t0\t0\t0\t0\t0\t0\t{wps[0]['alt']:.2f}\t1")
    for w in wps:
        rows.append(f"{len(rows)}\t0\t3\t16\t{float(w.get('hold_s') or 0):g}\t0\t0\t0\t{w['lat']:.7f}\t{w['lon']:.7f}\t{w['alt']:.2f}\t1")
    rows.append(f"{len(rows)}\t0\t3\t20\t0\t0\t0\t0\t0\t0\t0\t1")
    return "QGC WPL 110\n" + "\n".join(rows) + "\n"


def to_geojson(ms: m.Mission) -> dict:
    wps, home, poly = ms.waypoints or [], ms.home or {}, (ms.geofence or {}).get("polygon") or []
    feats = [{"type": "Feature", "properties": {"role": "home"}, "geometry": {"type": "Point", "coordinates": [home.get("lon"), home.get("lat"), home.get("alt") or 0]}}]
    feats += [{"type": "Feature", "properties": {"role": "waypoint", "seq": i + 1, "alt_rel_m": w["alt"], "speed": w.get("speed"), "hold_s": w.get("hold_s")},
               "geometry": {"type": "Point", "coordinates": [w["lon"], w["lat"], w["alt"]]}} for i, w in enumerate(wps)]
    feats.append({"type": "Feature", "properties": {"role": "path"}, "geometry": {"type": "LineString", "coordinates": [[w["lon"], w["lat"], w["alt"]] for w in wps]}})
    if len(poly) >= 3:
        ring = [[p[1], p[0]] for p in poly] + [[poly[0][1], poly[0][0]]]
        feats.append({"type": "Feature", "properties": {"role": "geofence", **{k: (ms.geofence or {}).get(k) for k in ("alt_min", "alt_max", "max_distance")}},
                      "geometry": {"type": "Polygon", "coordinates": [ring]}})
    feats += [{"type": "Feature", "properties": {"role": "emergency_landing", "name": s.get("name")},
               "geometry": {"type": "Point", "coordinates": [s["lon"], s["lat"]]}} for s in ms.emergency_sites or []]
    return {"type": "FeatureCollection", "name": f"{ms.code} {ms.name} rev {ms.revision}", "features": feats}


@router.get("/missions/{mid}/export")
def export(mid: int, fmt: str = "plan", u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    ms = _mission(db, mid)
    ac = db.get(m.Aircraft, ms.aircraft_id) if ms.aircraft_id else None
    if fmt == "plan":
        body, name, mt = json.dumps(to_qgc_plan(ms, 3 if ac and ac.autopilot == "ArduPilot" else 12), indent=2), f"{ms.code}.plan", "application/json"
    elif fmt == "waypoints":
        body, name, mt = to_wpl(ms), f"{ms.code}.waypoints", "text/plain"
    elif fmt == "geojson":
        body, name, mt = json.dumps(to_geojson(ms), indent=2), f"{ms.code}.geojson", "application/geo+json"
    else:
        raise HTTPException(422, "fmt must be plan, waypoints or geojson")
    audit(db, u, "mission_export", "mission", mid, f"Exported mission {ms.code} rev {ms.revision} as {fmt}")
    db.commit()
    return Response(body, media_type=mt, headers={"Content-Disposition": f'attachment; filename="{name}"'})


def parse_mission_file(name: str, text: str) -> dict:
    low = name.lower()
    if text.lstrip().startswith("QGC WPL"):
        home, wps = {}, []
        for line in text.strip().splitlines()[1:]:
            f = line.split()
            if len(f) < 11:
                continue
            seq, cmd, p1, lat, lon, alt = int(f[0]), int(f[3]), float(f[4]), float(f[8]), float(f[9]), float(f[10])
            if seq == 0:
                home = {"lat": lat, "lon": lon, "alt": alt}
            elif cmd == 16 and (lat or lon):
                wps.append({"lat": lat, "lon": lon, "alt": alt, "hold_s": p1})
        if not wps:
            raise ValueError("No NAV_WAYPOINT items found in the waypoint file.")
        return {"home": home, "waypoints": wps}
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        raise ValueError("File is neither a QGC WPL 110 waypoint file nor JSON (.plan / GeoJSON).")
    if obj.get("fileType") == "Plan":
        mi = obj.get("mission", {})
        hp = mi.get("plannedHomePosition") or [None, None, 0]
        wps = []
        for it in mi.get("items", []):
            p = it.get("params") or []
            if it.get("command") == 16 and len(p) >= 7 and p[4] is not None:
                wps.append({"lat": p[4], "lon": p[5], "alt": p[6], "hold_s": p[0] or 0})
        out = {"home": {"lat": hp[0], "lon": hp[1], "alt": hp[2] if len(hp) > 2 else 0}, "waypoints": wps}
        polys = [p for p in obj.get("geoFence", {}).get("polygons", []) if p.get("inclusion", True)]
        if polys:
            out["geofence"] = {"polygon": polys[0]["polygon"]}
        rp = obj.get("rallyPoints", {}).get("points") or []
        if rp:
            out["emergency_sites"] = [{"name": f"Rally {i + 1}", "lat": p[0], "lon": p[1]} for i, p in enumerate(rp)]
        if mi.get("cruiseSpeed"):
            out["cruise_speed"] = mi["cruiseSpeed"]
        if not wps:
            raise ValueError("The plan contains no NAV_WAYPOINT items.")
        return out
    if obj.get("type") == "FeatureCollection":
        out = {"waypoints": [], "emergency_sites": []}
        for ft in obj.get("features", []):
            role, geo = (ft.get("properties") or {}).get("role"), ft.get("geometry") or {}
            c = geo.get("coordinates")
            if geo.get("type") == "Point" and role == "home":
                out["home"] = {"lat": c[1], "lon": c[0], "alt": c[2] if len(c) > 2 else 0}
            elif geo.get("type") == "Point" and role == "emergency_landing":
                out["emergency_sites"].append({"name": ft["properties"].get("name") or "Site", "lat": c[1], "lon": c[0]})
            elif geo.get("type") == "Point":
                pr = ft.get("properties") or {}
                out["waypoints"].append({"lat": c[1], "lon": c[0], "alt": pr.get("alt_rel_m") or (c[2] if len(c) > 2 else 20), "hold_s": pr.get("hold_s") or 0})
            elif geo.get("type") == "Polygon":
                pr = ft.get("properties") or {}
                out["geofence"] = {"polygon": [[p[1], p[0]] for p in c[0][:-1]], **{k: pr[k] for k in ("alt_min", "alt_max", "max_distance") if pr.get(k) is not None}}
        if not out["waypoints"]:
            raise ValueError("The GeoJSON contains no waypoint points.")
        return out
    raise ValueError(f"Unrecognised mission file: {low}")


@router.post("/missions/import")
async def import_mission(file: UploadFile = File(...), mission_id: int | None = Form(None), name: str = Form(""),
                         u: m.User = Depends(require(*PLANNERS)), db: Db = Depends(get_db)):
    try:
        plan = parse_mission_file(file.filename or "", (await file.read()).decode("utf-8-sig"))
    except (ValueError, UnicodeDecodeError) as e:
        raise HTTPException(422, f"Could not import {file.filename}: {e}")
    if mission_id:
        ms = _mission(db, mission_id)
        merged = {**plan_of(ms), **plan}
        if "geofence" in plan:
            merged["geofence"] = {**(ms.geofence or {}), **plan["geofence"]}
        return save_plan(mission_id, dict(merged, note=f"Imported from {file.filename}"), u, db)
    ms = m.Mission(code=next_code(db, m.Mission, "MSN"), name=name or (file.filename or "Imported mission").rsplit(".", 1)[0], home=plan.get("home") or {},
                   waypoints=plan["waypoints"], geofence=plan.get("geofence") or {}, emergency_sites=plan.get("emergency_sites") or [],
                   environment={}, cruise_speed=plan.get("cruise_speed") or 8.0, revision=1, status="draft")
    db.add(ms)
    db.flush()
    db.add(m.MissionRevision(mission_id=ms.id, number=1, snapshot=plan_of(ms), note=f"Imported from {file.filename}", created_by=u.id))
    audit(db, u, "mission_import", "mission", ms.id, f"Imported mission {ms.code} from {file.filename}")
    db.commit()
    return mission_detail(ms.id, u, db)


# ───────────── release controls for physical operations ─────────────
def _tag(ms) -> str:
    return f"rev{ms.revision}"


def aircraft_authorized(db: Db, ms: m.Mission) -> tuple[bool, str]:
    ac = db.get(m.Aircraft, ms.aircraft_id) if ms.aircraft_id else None
    if not ac:
        return False, "No aircraft is assigned to the mission"
    rd = fleet.readiness(db, ac)
    if rd["blockers"]:
        return False, rd["blockers"][0]["text"]
    if rd["state"] == "Approved for designated testing" or rd["operational_release"]:
        return True, f"{ac.code}: {rd['state']}" + (" · operational release on record" if rd["operational_release"] else "")
    return False, f"{ac.code} is “{rd['state']}” and holds no operational release"


def physical_release_status(db: Db, ms: m.Mission) -> dict:
    rel = ap.valid_approval(db, "physical_mission_release", "mission", ms.id, tag=_tag(ms))
    chk = ap.valid_approval(db, "independent_safety_check", "mission", ms.id, tag=_tag(ms))
    cl = ap.checklist_complete(db, "preflight_safety_gates", "mission", ms.id)
    ok_ac, why = aircraft_authorized(db, ms)
    names = user_names(db)
    gates = [
        {"label": "Mission validated and passed simulation at this revision", "ok": ms.status == "sim_passed"},
        {"label": "Aircraft authorized", "ok": ok_ac, "detail": why},
        {"label": "Pre-flight safety gate checklist complete", "ok": bool(cl)},
        {"label": "Physical mission release approved (Flight Operations Engineer)", "ok": bool(rel), "detail": names.get(rel.decided_by) if rel else None},
        {"label": "Independent safety check approved by a different person", "ok": bool(chk), "detail": names.get(chk.decided_by) if chk else None},
    ]
    return {"released": all(g["ok"] for g in gates), "gates": gates, "tag": _tag(ms)}


def _pre_phys(db, ms, tag):
    unmet = []
    if tag != _tag(ms):
        unmet.append(f"The release must reference the current mission revision ({_tag(ms)}).")
    if ms.status != "sim_passed":
        unmet.append("The current mission revision must be validated and pass simulation.")
    ok, why = aircraft_authorized(db, ms)
    if not ok:
        unmet.append(why)
    return unmet


def _pre_safety(db, ms, tag):
    unmet = _pre_phys(db, ms, tag)
    if not ap.checklist_complete(db, "preflight_safety_gates", "mission", ms.id):
        unmet.append("The pre-flight safety gate checklist is not complete.")
    if not ap.valid_approval(db, "physical_mission_release", "mission", ms.id, tag=_tag(ms)):
        unmet.append("The physical mission release has not been approved.")
    return unmet


def _safety_decider(a, u):
    from .db import SessionLocal

    with SessionLocal() as s:
        rel = ap.valid_approval(s, "physical_mission_release", "mission", a.subject_id, tag=a.tag)
        if rel and rel.decided_by == u.id:
            return "The independent safety check must be performed by someone other than the person who approved the mission release."
    return None


ap.PRECOND.update(physical_mission_release=_pre_phys, independent_safety_check=_pre_safety)
ap.DECIDE_CHECK["independent_safety_check"] = _safety_decider
ap.AUTO["mission_validated"] = lambda db, cl: (
    ("ok", "Validated") if (ms := db.get(m.Mission, cl.subject_id)) and ms.status in ("validated", "sim_passed") else ("fail", "Mission is not validated at its current revision"))
ap.AUTO["mission_simulated"] = lambda db, cl: (
    ("ok", "Simulation passed") if (ms := db.get(m.Mission, cl.subject_id)) and ms.status == "sim_passed" else ("fail", "No passed simulation at the current revision"))
ap.AUTO["aircraft_authorized"] = lambda db, cl: (lambda r: ("ok" if r[0] else "fail", r[1]))(aircraft_authorized(db, db.get(m.Mission, cl.subject_id)))


def upload_check(db: Db, ms: m.Mission, source_class: str) -> list:
    """Reasons a mission may NOT be sent to the far end of a telemetry link. Empty list = permitted."""
    if source_class in ("simulation", "sitl"):
        return [] if ms.status in ("validated", "sim_passed") else ["Validate the mission before sending it to a simulator."]
    st = physical_release_status(db, ms)
    return [g["label"] + (f" — {g['detail']}" if g.get("detail") and not g["ok"] else "") for g in st["gates"] if not g["ok"]]


def mav_items(ms: m.Mission, ardupilot: bool) -> list:
    """(command, frame, param1, lat, lon, alt) tuples for MISSION_ITEM_INT upload."""
    wps, home = ms.waypoints or [], ms.home or {}
    items = []
    if ardupilot:
        items.append((16, 0, 0.0, home.get("lat", 0), home.get("lon", 0), float(home.get("alt") or 0)))
    if wps:
        items.append((22, 3, 0.0, wps[0]["lat"], wps[0]["lon"], wps[0]["alt"]))
    items += [(16, 3, float(w.get("hold_s") or 0), w["lat"], w["lon"], w["alt"]) for w in wps]
    items.append((20, 2, 0.0, 0, 0, 0))  # RTL carries no position: MAV_FRAME_MISSION (PX4 rejects a global frame here)
    return items


def bearing(a, b) -> float:
    return math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) % 360
