"""Reference data: checklist templates and component specification keys.

Checklist items are (category, text) or (category, text, auto_key). Items with an auto_key are
evaluated from platform records and cannot be signed by hand.
"""

CHECKLISTS = {
    "aircraft_inspection": {
        "title": "Aircraft inspection", "subject": "aircraft",
        "items": [
            ("Structure", "Airframe, arms and landing gear free of cracks, delamination and loose fasteners"),
            ("Structure", "Centre of gravity within limits for the recorded payload configuration"),
            ("Propulsion", "Motors rotate freely, no bearing play or grinding; mounts secure"),
            ("Propulsion", "Propellers undamaged, correct type and rotation direction, hubs tight"),
            ("Electrical", "ESC wiring, solder joints and connectors inspected; no chafing or heat damage"),
            ("Electrical", "Battery pack undamaged, not swollen; connectors and retention checked"),
            ("Avionics", "Flight controller, GPS and antenna mounts secure and correctly oriented"),
            ("Avionics", "Sensor windows / lenses clean; pitot / airflow ports clear where fitted"),
            ("Configuration", "Installed serial numbers match the released configuration record"),
            ("Configuration", "Released configuration has no open compatibility errors", "config_clean"),
        ],
    },
    "ground_validation": {
        "title": "Ground validation", "subject": "aircraft",
        "items": [
            ("Firmware", "Autopilot firmware version matches the configuration record"),
            ("Firmware", "Parameter file loaded and archived as evidence"),
            ("Sensors", "Accelerometer, gyro and magnetometer calibration completed"),
            ("Sensors", "GNSS fix obtained; satellite count and HDOP within limits"),
            ("Control", "RC / C2 link bound; control surface or motor direction verified (props removed)"),
            ("Control", "Failsafe actions (link loss, low battery, geofence) configured and bench-tested"),
            ("Power", "Battery voltage and current sensor readings verified against a reference meter"),
            ("Propulsion", "Motor run-up without propellers: order, direction and vibration normal"),
        ],
    },
    "preflight_safety_gates": {
        "title": "Pre-flight safety gates", "subject": "mission",
        "items": [
            ("Authorization", "Mission validated against geofence and operational boundary", "mission_validated"),
            ("Authorization", "Mission passed simulation at the current revision", "mission_simulated"),
            ("Authorization", "Aircraft is approved for designated testing or operationally released", "aircraft_authorized"),
            ("Site", "Take-off area clear; bystanders briefed and behind the safety line"),
            ("Site", "Airspace status checked for the operating window"),
            ("Weather", "Wind, visibility and precipitation within the aircraft limits"),
            ("Aircraft", "Battery charged, secured and within temperature limits"),
            ("Aircraft", "Home position and return altitude confirmed on the ground station"),
            ("Crew", "Emergency procedures and abort criteria briefed; roles assigned"),
            ("C2", "Telemetry and control link confirmed; link-loss behaviour verified"),
        ],
    },
    "c2_infrastructure": {
        "title": "C2 infrastructure pre-operation check", "subject": "c2_equipment",
        "items": [
            ("Power", "Ground station power source and backup verified"),
            ("Software", "Ground control software version matches the configuration record"),
            ("Radio", "Antenna, feed line and connectors inspected; antenna correctly oriented"),
            ("Radio", "Operating frequency and power comply with the local licence / authorization"),
            ("Network", "Network equipment reachable; addresses match the configuration record"),
            ("Link", "Telemetry link established with the aircraft on the ground"),
            ("Link", "Signal quality and packet loss acceptable at the operating position"),
            ("Recording", "Telemetry recording enabled and storage space sufficient"),
            ("Equipment", "Equipment is recorded as serviceable and maintenance is not overdue", "equipment_serviceable"),
        ],
    },
    "deployment_readiness": {
        "title": "Deployment readiness", "subject": "deployment",
        "items": [
            ("Aircraft availability", "All deployment aircraft hold an operational release and are not grounded", "dep_aircraft"),
            ("Hardware inspection", "All deployment aircraft have an approved inspection at their released configuration", "dep_inspection"),
            ("Firmware verification", "Firmware versions verified against configuration records (ground validation approved)", "dep_firmware"),
            ("Software verification", "Ground control and companion software versions verified and recorded"),
            ("Batteries and charging equipment", "Batteries, chargers and transport containers packed; state of charge set for transport"),
            ("Spare parts", "Spare component list recorded for this deployment", "dep_spares"),
            ("Ground control station", "Ground station equipment assigned and serviceable", "dep_gcs"),
            ("Communications infrastructure", "Communications equipment checked; frequencies permitted at the deployment location"),
            ("Documentation", "Aircraft records, manuals, checklists and emergency contacts packed"),
            ("Personnel qualifications", "Every assigned person holds a current qualification record", "dep_personnel"),
            ("Site authorization", "Granted and current site authorization and regulatory approval on record", "dep_permits"),
            ("Weather assessment", "Weather assessment recorded for the deployment window", "dep_weather"),
            ("Emergency procedures", "Emergency procedures recorded for the deployment site", "dep_emergency"),
        ],
    },
    "demo_preparation": {
        "title": "Demonstration preparation", "subject": "demonstration",
        "items": [
            ("Scenario", "Demonstration scenario rehearsed end to end"),
            ("Aircraft", "Demonstration aircraft is operationally released and not grounded", "demo_aircraft"),
            ("Equipment", "Ground station, displays and presentation equipment tested at the venue"),
            ("Safety", "Safety briefing prepared and spectator area defined"),
            ("Presentation", "Technical presentation reviewed; acceptance criteria agreed with the customer"),
            ("Contingency", "Backup aircraft / battery and weather contingency plan in place"),
        ],
    },
    "practical_assessment": {
        "title": "Practical assessment", "subject": "enrollment",
        "items": [
            ("Preparation", "Completes the pre-flight inspection without prompting"),
            ("Preparation", "Sets up the ground control station and verifies the link"),
            ("Operation", "Performs the briefed manoeuvres / mission within tolerances"),
            ("Operation", "Monitors battery, GNSS and link status and calls out deviations"),
            ("Emergency", "Responds correctly to a simulated link loss"),
            ("Emergency", "Responds correctly to a simulated low-battery event"),
            ("Close-out", "Completes post-flight inspection and flight documentation"),
        ],
    },
}

# Specification keys the compatibility checks understand, per component category.
SPEC_KEYS = {
    "Motor": [("kv", "KV rating", "rpm/V"), ("max_current_a", "Max current", "A"), ("max_thrust_g", "Max thrust", "g"),
              ("cells_min", "Min cells", "S"), ("cells_max", "Max cells", "S"), ("prop_in_min", "Min prop", "in"),
              ("prop_in_max", "Max prop", "in"), ("mass_g", "Mass", "g")],
    "ESC": [("continuous_current_a", "Continuous current", "A"), ("cells_min", "Min cells", "S"), ("cells_max", "Max cells", "S"),
            ("channels", "Channels", ""), ("protocol", "Protocol", ""), ("mass_g", "Mass", "g")],
    "Propeller": [("diameter_in", "Diameter", "in"), ("pitch_in", "Pitch", "in"), ("mass_g", "Mass", "g")],
    "Battery": [("cells", "Cells", "S"), ("capacity_mah", "Capacity", "mAh"), ("c_rating", "Discharge rating", "C"),
                ("chemistry", "Chemistry", ""), ("mass_g", "Mass", "g")],
    "Flight controller": [("supported_firmware", "Supported firmware", ""), ("voltage_min", "Min supply", "V"),
                          ("voltage_max", "Max supply", "V"), ("mass_g", "Mass", "g")],
    "GPS module": [("constellations", "Constellations", ""), ("rtk", "RTK", ""), ("mass_g", "Mass", "g")],
    "Telemetry module": [("frequency_mhz", "Frequency", "MHz"), ("power_mw", "TX power", "mW"), ("mass_g", "Mass", "g")],
    "Radio receiver": [("frequency_mhz", "Frequency", "MHz"), ("protocol", "Protocol", ""), ("mass_g", "Mass", "g")],
    "Companion computer": [("interface", "FC interface", ""), ("power_w", "Power draw", "W"), ("mass_g", "Mass", "g")],
}
DEFAULT_SPEC = [("interface", "Interface", ""), ("mass_g", "Mass", "g")]
