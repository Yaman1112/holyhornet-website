"""Operator training and internal certification records.

Completion records issued here are INTERNAL TRAINING RECORDS. They are stored with kind 'internal_training_record'
and are never presented as aviation licences; regulatory licences are recorded separately with their issuing authority.
"""
from datetime import timedelta

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import approvals as ap, models as m
from .core import audit, get_setting, internal_user, require, to_dict, today, user_names
from .db import get_db, utcnow

router = APIRouter(prefix="/api/training")
DISCLAIMER = ("Internal training completion record. This is a company record of training completed on this platform. "
              "It is not an aviation licence, certificate of competency or regulatory authorization.")


def _modules(db, cid):
    return list(db.scalars(select(m.CourseModule).where(m.CourseModule.course_id == cid).order_by(m.CourseModule.seq, m.CourseModule.id)))


def _questions(db, cid):
    return list(db.scalars(select(m.QuizQuestion).where(m.QuizQuestion.course_id == cid).order_by(m.QuizQuestion.seq, m.QuizQuestion.id)))


def enrollment_state(db: Db, e: m.Enrollment) -> dict:
    mods, qs = _modules(db, e.course_id), _questions(db, e.course_id)
    done = [x for x in (e.progress or []) if x in {md.id for md in mods}]
    attempts = list(db.scalars(select(m.QuizAttempt).where(m.QuizAttempt.enrollment_id == e.id).order_by(m.QuizAttempt.id.desc())))
    needs_practical = any(md.kind == "practical" for md in mods)
    cl = db.scalar(select(m.Checklist).where(m.Checklist.kind == "practical_assessment", m.Checklist.subject_id == e.id).order_by(m.Checklist.id.desc()))
    unmet = []
    if len(done) < len(mods):
        unmet.append(f"{len(mods) - len(done)} learning module(s) not completed")
    if qs and not any(a.passed for a in attempts):
        unmet.append("Theoretical assessment not passed")
    if needs_practical and not (cl and cl.status == "complete"):
        unmet.append("Practical assessment checklist not completed by an instructor")
    return {"modules_total": len(mods), "modules_done": len(done), "quiz_required": bool(qs), "quiz_passed": any(a.passed for a in attempts),
            "best_score": max((a.score for a in attempts), default=None), "attempts": len(attempts), "practical_required": needs_practical,
            "practical_done": bool(cl and cl.status == "complete"), "practical_checklist_id": cl.id if cl else None, "unmet": unmet,
            "percent": round(100 * (len(done) + (1 if not qs or any(a.passed for a in attempts) else 0) + (1 if not needs_practical or (cl and cl.status == "complete") else 0))
                             / (len(mods) + 2)) if mods else 0}


@router.get("/courses")
def courses(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    mine = {e.course_id: e for e in db.scalars(select(m.Enrollment).where(m.Enrollment.student_id == u.id, m.Enrollment.status != "withdrawn"))}
    out = []
    for c in db.scalars(select(m.Course).order_by(m.Course.code)):
        e = mine.get(c.id)
        out.append(dict(to_dict(c), modules=len(_modules(db, c.id)), questions=len(_questions(db, c.id)),
                        my_enrollment=dict(id=e.id, status=e.status, **enrollment_state(db, e)) if e else None))
    return out


@router.get("/courses/{cid}")
def course(cid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    c = db.get(m.Course, cid)
    if not c:
        raise HTTPException(404, "Course not found")
    teach = u.role in ("admin", "instructor")
    qs = [dict(to_dict(q)) for q in _questions(db, cid)]
    if not teach:
        for q in qs:
            q.pop("answer")
            q.pop("explanation")
    e = db.scalar(select(m.Enrollment).where(m.Enrollment.course_id == cid, m.Enrollment.student_id == u.id, m.Enrollment.status != "withdrawn"))
    return dict(to_dict(c), modules=[to_dict(x) for x in _modules(db, cid)], questions=qs, can_teach=teach,
                my_enrollment=dict(to_dict(e), **enrollment_state(db, e)) if e else None, disclaimer=DISCLAIMER)


@router.post("/enroll")
def enroll(data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    sid = data.get("student_id") or u.id
    if sid != u.id and u.role not in ("admin", "instructor"):
        raise HTTPException(403, "Only an instructor can enrol another person.")
    c = db.get(m.Course, data.get("course_id") or 0)
    if not c or not c.active:
        raise HTTPException(404, "Course not found or inactive")
    if not db.get(m.User, sid):
        raise HTTPException(404, "Student not found")
    dup = db.scalar(select(m.Enrollment).where(m.Enrollment.course_id == c.id, m.Enrollment.student_id == sid, m.Enrollment.status.in_(["enrolled", "in_progress"])))
    if dup:
        raise HTTPException(409, "Already enrolled in this course.")
    e = m.Enrollment(course_id=c.id, student_id=sid, instructor_id=data.get("instructor_id") or (u.id if u.role == "instructor" else None),
                     status="enrolled", progress=[])
    db.add(e)
    db.flush()
    audit(db, u, "enroll", "enrollment", e.id, f"Enrolled {user_names(db).get(sid)} in {c.code} {c.title}")
    db.commit()
    return to_dict(e)


def _enr(db, eid, u, teach_only=False) -> m.Enrollment:
    e = db.get(m.Enrollment, eid)
    if not e:
        raise HTTPException(404, "Enrollment not found")
    teach = u.role in ("admin", "instructor")
    if teach_only and not teach:
        raise HTTPException(403, "Instructor only.")
    if not teach and e.student_id != u.id:
        raise HTTPException(403, "This is not your enrollment.")
    return e


@router.get("/enrollments")
def enrollments(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    names = user_names(db)
    courses_ = {c.id: c for c in db.scalars(select(m.Course))}
    st = select(m.Enrollment).order_by(m.Enrollment.id.desc())
    if u.role not in ("admin", "instructor"):
        st = st.where(m.Enrollment.student_id == u.id)
    return [dict(to_dict(e), student=names.get(e.student_id), instructor=names.get(e.instructor_id), course=courses_[e.course_id].title,
                 course_code=courses_[e.course_id].code, **enrollment_state(db, e)) for e in db.scalars(st)]


@router.get("/enrollments/{eid}")
def enrollment(eid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    e = _enr(db, eid, u)
    names = user_names(db)
    c = db.get(m.Course, e.course_id)
    cl = db.scalar(select(m.Checklist).where(m.Checklist.kind == "practical_assessment", m.Checklist.subject_id == e.id).order_by(m.Checklist.id.desc()))
    return dict(to_dict(e), student=names.get(e.student_id), instructor=names.get(e.instructor_id), course=to_dict(c), **enrollment_state(db, e),
                quiz_attempts=[{"id": a.id, "score": a.score, "passed": a.passed, "taken_at": a.taken_at.isoformat()} for a in
                               db.scalars(select(m.QuizAttempt).where(m.QuizAttempt.enrollment_id == eid).order_by(m.QuizAttempt.id.desc()))],
                attendance=[to_dict(a) for a in db.scalars(select(m.Attendance).where(m.Attendance.enrollment_id == eid).order_by(m.Attendance.date))],
                practical=ap.checklist_out(db, cl) if cl else None,
                record=[to_dict(q) for q in db.scalars(select(m.Qualification).where(m.Qualification.user_id == e.student_id, m.Qualification.course_id == e.course_id))])


@router.post("/enrollments/{eid}/module")
def complete_module(eid: int, data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    e = _enr(db, eid, u)
    if e.status not in ("enrolled", "in_progress"):
        raise HTTPException(409, "This enrollment is closed.")
    md = db.get(m.CourseModule, data.get("module_id") or 0)
    if not md or md.course_id != e.course_id:
        raise HTTPException(404, "Module not found in this course")
    if md.id not in (e.progress or []):
        e.progress = (e.progress or []) + [md.id]
    e.status = "in_progress"
    db.commit()
    return enrollment_state(db, e)


@router.post("/enrollments/{eid}/quiz")
def take_quiz(eid: int, data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    e = _enr(db, eid, u)
    if e.student_id != u.id:
        raise HTTPException(403, "An assessment must be taken by the enrolled student.")
    if e.status not in ("enrolled", "in_progress"):
        raise HTTPException(409, "This enrollment is closed.")
    qs = _questions(db, e.course_id)
    if not qs:
        raise HTTPException(409, "This course has no theoretical assessment.")
    ans = {int(k): v for k, v in (data.get("answers") or {}).items()}
    if len(ans) < len(qs):
        raise HTTPException(422, f"Answer all {len(qs)} questions before submitting.")
    c = db.get(m.Course, e.course_id)
    detail = [{"id": q.id, "correct": ans.get(q.id) == q.answer, "explanation": q.explanation} for q in qs]
    score = round(100 * sum(d["correct"] for d in detail) / len(qs), 1)
    passed = score >= (c.pass_mark or 80)
    db.add(m.QuizAttempt(enrollment_id=e.id, answers=ans, score=score, passed=passed))
    e.status = "in_progress"
    audit(db, u, "quiz", "enrollment", e.id, f"Theoretical assessment for {c.code}: {score}% ({'pass' if passed else 'fail'})")
    db.commit()
    return {"score": score, "passed": passed, "pass_mark": c.pass_mark, "detail": detail}


@router.post("/enrollments/{eid}/complete")
def complete(eid: int, data: dict = Body({}), u: m.User = Depends(require("instructor")), db: Db = Depends(get_db)):
    e = _enr(db, eid, u, True)
    if e.status == "completed":
        raise HTTPException(409, "Already completed.")
    if e.student_id == u.id and u.role != "admin":
        raise HTTPException(403, "An instructor cannot certify their own training.")
    st = enrollment_state(db, e)
    if st["unmet"]:
        raise HTTPException(409, {"message": "Training cannot be recorded as complete.", "unmet": st["unmet"]})
    c = db.get(m.Course, e.course_id)
    e.status, e.completed_at = "completed", utcnow()
    e.instructor_id = e.instructor_id or u.id
    if data.get("feedback"):
        e.instructor_feedback = data["feedback"]
    q = m.Qualification(user_id=e.student_id, kind="internal_training_record", title=f"{c.title} — internal training record",
                        issuer=get_setting(db, "organisation", "Internal training organisation"), reference=f"{c.code}-{e.id:05d}", course_id=c.id,
                        issued_date=today(), expiry_date=today() + timedelta(days=30 * (c.validity_months or 24)), notes=DISCLAIMER)
    db.add(q)
    audit(db, u, "training_complete", "enrollment", e.id, f"Recorded completion of {c.code} for {user_names(db).get(e.student_id)}")
    db.commit()
    return enrollment(eid, u, db)


@router.post("/enrollments/{eid}/withdraw")
def withdraw(eid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    e = _enr(db, eid, u)
    if e.status == "completed":
        raise HTTPException(409, "A completed enrollment cannot be withdrawn.")
    e.status = "withdrawn"
    db.commit()
    return {"ok": True}


@router.get("/people/{uid}")
def person(uid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    p = db.get(m.User, uid)
    if not p:
        raise HTTPException(404, "Person not found")
    courses_ = {c.id: c for c in db.scalars(select(m.Course))}
    td = today()
    quals = [dict(to_dict(q), expired=bool(q.expiry_date and q.expiry_date < td), is_licence=q.kind == "regulatory_licence")
             for q in db.scalars(select(m.Qualification).where(m.Qualification.user_id == uid).order_by(m.Qualification.expiry_date))]
    return {"person": {k: getattr(p, k) for k in ("id", "full_name", "role", "discipline", "organisation", "email")},
            "role_label": m.ROLES.get(p.role), "qualifications": quals, "disclaimer": DISCLAIMER,
            "enrollments": [dict(to_dict(e), course=courses_[e.course_id].title, **enrollment_state(db, e))
                            for e in db.scalars(select(m.Enrollment).where(m.Enrollment.student_id == uid).order_by(m.Enrollment.id.desc()))]}
