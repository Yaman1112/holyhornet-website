"""Authentication endpoints and administration: settings, audit trail, backup / restore, demonstration dataset."""
import shutil
import sqlite3
import time
import zipfile
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session as Db

from . import config, curriculum, models as m
from .core import (audit, create_session, current_user, get_setting, hash_password, password_problem, require, set_setting, to_dict, verify_audit_chain,
                   verify_password, _th)
from .db import get_db

router = APIRouter(prefix="/api")
admin = require()  # administrators only
_fails: dict = {}


def user_out(u: m.User) -> dict:
    d = to_dict(u)
    d["role_label"] = m.ROLES.get(u.role, u.role)
    return d


@router.get("/health")
def health(db: Db = Depends(get_db)):
    out = {"ok": True, "app": config.APP_NAME, "version": config.VERSION, "setup_required": not db.scalar(select(func.count(m.User.id))),
           "organisation": get_setting(db, "organisation"), "demo_data": bool(get_setting(db, "demo_loaded")), "browser": config.BROWSER}
    if config.BROWSER:  # public demonstration accounts: the whole system runs in the visitor's tab and protects nothing
        out["demo_accounts"] = {"password": get_setting(db, "demo_password"),
                                "users": [{"username": u.username, "full_name": u.full_name, "role": m.ROLES.get(u.role)} for u in
                                          db.scalars(select(m.User).where(m.User.can_login, m.User.active).order_by(m.User.id))]}
    return out


@router.post("/setup")
def setup(data: dict = Body(...), db: Db = Depends(get_db)):
    """First-run: create the administrator account. Disabled as soon as any user exists."""
    if db.scalar(select(func.count(m.User.id))):
        raise HTTPException(409, "Setup has already been completed.")
    for f in ("username", "full_name", "password"):
        if not (data.get(f) or "").strip():
            raise HTTPException(422, f"{f.replace('_', ' ').capitalize()} is required.")
    prob = password_problem(data["password"])
    if prob:
        raise HTTPException(422, prob)
    u = m.User(username=data["username"].strip(), full_name=data["full_name"].strip(), email=data.get("email"), role="admin",
               organisation=data.get("organisation"), can_login=True, active=True, password_hash=hash_password(data["password"]))
    db.add(u)
    db.flush()
    set_setting(db, "organisation", (data.get("organisation") or "").strip() or None)
    n = curriculum.install(db)
    audit(db, u, "setup", "system", None, f"Platform initialised; administrator {u.username} created; {n} starter courses installed")
    token = create_session(db, u)
    db.commit()
    return {"token": token, "user": user_out(u)}


@router.post("/login")
def login(data: dict = Body(...), db: Db = Depends(get_db)):
    name = (data.get("username") or "").strip()
    cnt, until = _fails.get(name.lower(), (0, 0))
    if until > time.time():
        raise HTTPException(429, f"Too many failed attempts. Try again in {int(until - time.time())} s.")
    u = db.scalar(select(m.User).where(func.lower(m.User.username) == name.lower()))
    if not u or not u.active or not u.can_login or not verify_password(data.get("password") or "", u.password_hash):
        cnt += 1
        _fails[name.lower()] = (cnt, time.time() + 60 if cnt >= 5 else 0)
        audit(db, u, "login_failed", "user", u.id if u else None, f"Failed sign-in for “{name}”")
        db.commit()
        raise HTTPException(401, "Incorrect username or password.")
    _fails.pop(name.lower(), None)
    token = create_session(db, u)
    audit(db, u, "login", "user", u.id, f"{u.username} signed in")
    db.commit()
    return {"token": token, "user": user_out(u)}


@router.post("/logout")
def logout(authorization: str | None = Header(None), u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    db.query(m.Session).filter(m.Session.token_hash == _th(authorization[7:])).delete()
    audit(db, u, "logout", "user", u.id, f"{u.username} signed out")
    db.commit()
    return {"ok": True}


@router.get("/me")
def me(u: m.User = Depends(current_user)):
    return user_out(u)


@router.post("/me/password")
def change_password(data: dict = Body(...), u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    if not verify_password(data.get("current") or "", u.password_hash):
        raise HTTPException(403, "Current password is incorrect.")
    prob = password_problem(data.get("new") or "")
    if prob:
        raise HTTPException(422, prob)
    u.password_hash = hash_password(data["new"])
    audit(db, u, "password_change", "user", u.id, f"{u.username} changed their password")
    db.commit()
    return {"ok": True}


# ───────────── administration ─────────────
@router.get("/admin/audit")
def audit_log(q: str = "", entity: str = "", limit: int = 300, u: m.User = Depends(admin), db: Db = Depends(get_db)):
    st = select(m.AuditLog)
    if q:
        st = st.where(or_(m.AuditLog.summary.ilike(f"%{q}%"), m.AuditLog.username.ilike(f"%{q}%"), m.AuditLog.action.ilike(f"%{q}%")))
    if entity:
        st = st.where(m.AuditLog.entity == entity)
    return [to_dict(r) for r in db.scalars(st.order_by(m.AuditLog.id.desc()).limit(min(limit, 2000)))]


@router.get("/admin/audit/verify")
def audit_verify(u: m.User = Depends(admin), db: Db = Depends(get_db)):
    return verify_audit_chain(db)


@router.get("/admin/settings")
def get_settings(u: m.User = Depends(admin), db: Db = Depends(get_db)):
    return {"organisation": get_setting(db, "organisation"), "has_anthropic_key": bool(get_setting(db, "anthropic_api_key")),
            "demo_loaded": bool(get_setting(db, "demo_loaded")), "data_dir": str(config.DATA_DIR), "database": config.DB_URL.split("///")[-1],
            "version": config.VERSION, "credential_storage": "Windows DPAPI (current user)"}


@router.put("/admin/settings")
def put_settings(data: dict = Body(...), u: m.User = Depends(admin), db: Db = Depends(get_db)):
    if "organisation" in data:
        set_setting(db, "organisation", (data["organisation"] or "").strip() or None)
    if "anthropic_api_key" in data:
        try:
            set_setting(db, "anthropic_api_key", (data["anthropic_api_key"] or "").strip() or None, secret=True)
        except RuntimeError as e:
            raise HTTPException(500, str(e))
    audit(db, u, "settings", "system", None, "Updated settings: " + ", ".join(k for k in data if k in ("organisation", "anthropic_api_key")))
    db.commit()
    return get_settings(u, db)


def make_backup(label: str = "manual") -> Path:
    """Consistent backup: SQLite online backup plus the evidence / log / report files, in one zip."""
    if not config.DB_URL.startswith("sqlite"):
        raise HTTPException(409, "Built-in backup covers the standalone SQLite database. Use your PostgreSQL backup tooling for a server database.")
    dst = config.sub("backups") / f"aeros-backup-{datetime.now():%Y%m%d-%H%M%S}-{label}.zip"
    tmp = config.sub("backups") / "_snapshot.db"
    src = sqlite3.connect(config.DB_URL.split("///")[-1])
    out = sqlite3.connect(tmp)
    with out:
        src.backup(out)
    out.close()
    src.close()
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(tmp, "aeros.db")
        for sub in ("attachments", "flightlogs", "reports"):
            for f in config.sub(sub).iterdir():
                if f.is_file() and not f.name.startswith("_"):
                    z.write(f, f"{sub}/{f.name}")
    tmp.unlink(missing_ok=True)
    return dst


@router.get("/admin/backups")
def backups(u: m.User = Depends(admin)):
    files = sorted((f for f in config.sub("backups").glob("aeros-backup-*.zip")), reverse=True)
    return {"backups": [{"name": f.name, "size": f.stat().st_size, "created": datetime.fromtimestamp(f.stat().st_mtime).isoformat(timespec="seconds")} for f in files],
            "restore_pending": (config.DATA_DIR / "restore_pending.zip").exists()}


@router.post("/admin/backups")
def create_backup(u: m.User = Depends(admin), db: Db = Depends(get_db)):
    p = make_backup()
    audit(db, u, "backup", "system", None, f"Created backup {p.name}")
    db.commit()
    return {"name": p.name, "size": p.stat().st_size}


def _backup_path(name: str) -> Path:
    p = config.sub("backups") / Path(name).name
    if not p.exists() or not p.name.startswith("aeros-backup-"):
        raise HTTPException(404, "Backup not found")
    return p


@router.get("/admin/backups/{name}")
def download_backup(name: str, u: m.User = Depends(admin)):
    return FileResponse(_backup_path(name), filename=name, media_type="application/zip")


def _stage_restore(src: Path):
    with zipfile.ZipFile(src) as z:
        if "aeros.db" not in z.namelist():
            raise HTTPException(422, "This archive is not an AEROS OPS PRO backup (aeros.db missing).")
    shutil.copyfile(src, config.DATA_DIR / "restore_pending.zip")


@router.post("/admin/backups/{name}/restore")
def restore_backup(name: str, u: m.User = Depends(admin), db: Db = Depends(get_db)):
    """Stage a restore. It is applied on the next application start, after an automatic safety backup of the current data."""
    _stage_restore(_backup_path(name))
    audit(db, u, "restore_staged", "system", None, f"Staged restore of {name}; applies at next start")
    db.commit()
    return {"ok": True, "message": "Restore staged. Close and restart AEROS OPS PRO to apply it."}


@router.post("/admin/restore-upload")
async def restore_upload(file: UploadFile = File(...), u: m.User = Depends(admin), db: Db = Depends(get_db)):
    p = config.sub("backups") / f"aeros-backup-uploaded-{int(time.time())}.zip"
    p.write_bytes(await file.read())
    try:
        _stage_restore(p)
    except (zipfile.BadZipFile, HTTPException):
        p.unlink(missing_ok=True)
        raise HTTPException(422, "The uploaded file is not a valid AEROS OPS PRO backup.")
    audit(db, u, "restore_staged", "system", None, f"Staged restore of uploaded backup {file.filename}")
    db.commit()
    return {"ok": True, "message": "Restore staged. Close and restart AEROS OPS PRO to apply it."}


@router.delete("/admin/restore-pending")
def cancel_restore(u: m.User = Depends(admin)):
    (config.DATA_DIR / "restore_pending.zip").unlink(missing_ok=True)
    return {"ok": True}


def apply_pending_restore() -> str | None:
    """Called before the database is opened."""
    pend = config.DATA_DIR / "restore_pending.zip"
    if not pend.exists():
        return None
    dbp = Path(config.DB_URL.split("///")[-1])
    safety = config.sub("backups") / f"aeros-backup-{datetime.now():%Y%m%d-%H%M%S}-pre-restore.zip"
    with zipfile.ZipFile(safety, "w", zipfile.ZIP_DEFLATED) as z:
        if dbp.exists():
            z.write(dbp, "aeros.db")
        for sub in ("attachments", "flightlogs", "reports"):
            for f in config.sub(sub).iterdir():
                if f.is_file():
                    z.write(f, f"{sub}/{f.name}")
    for ext in ("", "-wal", "-shm"):
        Path(str(dbp) + ext).unlink(missing_ok=True)
    for sub in ("attachments", "flightlogs", "reports"):
        for f in config.sub(sub).iterdir():
            if f.is_file():
                f.unlink()
    with zipfile.ZipFile(pend) as z:
        for n in z.namelist():
            target = (config.DATA_DIR / n).resolve()
            if config.DATA_DIR in target.parents and (n == "aeros.db" or n.split("/")[0] in ("attachments", "flightlogs", "reports")):
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(n))
    pend.unlink()
    return safety.name


@router.post("/admin/demo-data")
def load_demo(data: dict = Body({}), u: m.User = Depends(admin), db: Db = Depends(get_db)):
    from . import demo

    if get_setting(db, "demo_loaded"):
        raise HTTPException(409, "The demonstration dataset is already loaded.")
    pw = data.get("password")
    if pw:
        prob = password_problem(pw)
        if prob:
            raise HTTPException(422, prob)
    backup = make_backup("pre-demo").name if config.DB_URL.startswith("sqlite") else None
    summary = demo.load(db, u, pw)
    set_setting(db, "demo_loaded", True)
    audit(db, u, "demo_data", "system", None, "Loaded the demonstration dataset (records are prefixed DEMO-)", summary)
    db.commit()
    return {"ok": True, "summary": summary, "backup": backup}
