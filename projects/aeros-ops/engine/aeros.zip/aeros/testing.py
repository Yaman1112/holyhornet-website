"""Test campaign lifecycle, test cards, the validation engine, flight records with safety gates, and issue workflow."""
import hashlib
import json

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import approvals as ap, fleet, maint, models as m
from .core import audit, internal_user, next_code, require, to_dict, today, user_names
from .db import get_db, utcnow
from .resources import hook

router = APIRouter(prefix="/api")
STAGES = m.CAMPAIGN_STAGES
OPS = {"<=": lambda v, a, b: v <= a, ">=": lambda v, a, b: v >= a, "<": lambda v, a, b: v < a, ">": lambda v, a, b: v > a,
       "==": lambda v, a, b: abs(v - a) <= 1e-9, "between": lambda v, a, b: a <= v <= b}


def has_current_qualification(db: Db, user_id: int) -> bool:
    for q in db.scalars(select(m.Qualification).where(m.Qualification.user_id == user_id)):
        if not q.expiry_date or q.expiry_date >= today():
            return True
    return False


# ───────────── campaigns ─────────────
@hook("campaigns", "before_save")
def _camp_before(db, user, obj, data, is_new, changes):
    ac = db.get(m.Aircraft, obj.aircraft_id)
    if not ac:
        raise HTTPException(422, "Campaign aircraft not found.")
    if is_new:
        obj.config_revision_id = ac.current_revision_id
        obj.firmware_version = obj.firmware_version or ac.autopilot_firmware
        obj.software_release = obj.software_release or ac.software_version
        obj.stage, obj.status = 0, "active"
        obj.stage_log = [{"stage": 0, "at": utcnow().isoformat(), "by": user.id}]
    elif "aircraft_id" in changes and obj.stage > 3:
        raise HTTPException(409, "The campaign aircraft cannot be changed after the risk assessment stage.")


def cards_of(db: Db, cid: int) -> list:
    return list(db.scalars(select(m.TestCard).where(m.TestCard.campaign_id == cid).order_by(m.TestCard.id)))


def stage_conditions(db: Db, c: m.Campaign) -> list:
    """Conditions for leaving the current stage. Each is (text, ok)."""
    ac = db.get(m.Aircraft, c.aircraft_id)
    cards = cards_of(db, c.id)
    live = [k for k in cards if k.status != "deferred"]
    s = c.stage
    rd = fleet.readiness(db, ac) if 4 <= s <= 7 else None
    gate = {g["key"]: g["ok"] for g in rd["gates"]} if rd else {}
    same_rev = c.config_revision_id is not None and c.config_revision_id == ac.current_revision_id
    rev_cond = ("Campaign is bound to the aircraft's released configuration revision", same_rev)
    if s == 0:
        return [("Campaign objectives recorded", bool(c.objectives)), ("Test location recorded", bool(c.location)),
                ("Responsible engineer assigned", bool(c.responsible_engineer_id)), ("Test dates recorded", bool(c.start_date and c.end_date))]
    if s == 1:
        return [("Engineering review of the proposal approved", bool(ap.valid_approval(db, "engineering_review", "campaign", c.id, tag="plan")))]
    if s == 2:
        return [("At least one test card defined", bool(cards)),
                ("Every test card has a procedure and at least one acceptance criterion", bool(cards) and all(k.procedure and k.criteria for k in cards)),
                ("Campaign success criteria recorded", bool(c.success_criteria)), ("Flight-test personnel assigned", bool(c.personnel))]
    if s == 3:
        risks = list(db.scalars(select(m.RiskItem).where(m.RiskItem.campaign_id == c.id)))
        return [("At least one hazard assessed", bool(risks)),
                ("Every hazard has a mitigation and residual rating", bool(risks) and all(r.mitigation and r.residual_likelihood and r.residual_severity for r in risks)),
                ("Risk assessment accepted by an independent Flight Operations Engineer", bool(ap.valid_approval(db, "risk_assessment", "campaign", c.id)))]
    if s == 4:
        return [rev_cond, ("Aircraft inspection approved for the released configuration", gate.get("inspection", False))]
    if s == 5:
        return [rev_cond, ("Ground validation approved for the released configuration", gate.get("ground", False))]
    if s == 6:
        return [rev_cond, ("Simulation validation approved for the released configuration", gate.get("simulation", False))]
    if s == 7:
        return [rev_cond, ("Flight-test authorization approved and in force",
                           bool(ap.valid_approval(db, "flight_authorization", "campaign", c.id, revision_id=ac.current_revision_id))),
                ("Aircraft has no grounding or overdue maintenance", not rd["blockers"])]
    if s == 8:
        return [("Every test card has been executed or deferred with a recorded deviation", bool(cards) and all(k.status != "planned" for k in cards))]
    if s == 9:
        return [("Every executed test card has complete measurements and evidence (none incomplete)",
                 all(k.status in ("pass", "fail") for k in live) and bool(live))]
    if s == 10:
        return [("Every evaluated test card is signed by an engineer", all(k.signed_at for k in live) and bool(live))]
    if s == 11:
        failed = [k for k in live if k.status == "fail"]
        linked = {i.test_card_id for i in db.scalars(select(m.Issue).where(m.Issue.campaign_id == c.id))}
        return [("Every failed test card has an engineering issue raised", all(k.id in linked for k in failed)),
                ("Engineering review of the results approved", bool(ap.valid_approval(db, "engineering_review", "campaign", c.id, tag="results")))]
    if s == 12:
        return [("Campaign acceptance approved by an independent Flight Operations Engineer", bool(ap.valid_approval(db, "campaign_acceptance", "campaign", c.id)))]
    if s == 13:
        rep = db.scalar(select(m.Report.id).where(m.Report.report_type == "campaign", m.Report.subject_id == c.id))
        return [("Flight-Test Campaign Report generated", bool(rep))]
    return []


def card_out(db: Db, k: m.TestCard, names=None) -> dict:
    d = to_dict(k)
    d["signed_by_name"] = (names or user_names(db)).get(k.signed_by)
    d["attachments"] = len(ap.attachments_of(db, "test_card", k.id))
    return d


def coverage(cards: list) -> list:
    out = []
    for cat in m.VALIDATION_CATEGORIES:
        cs = [k for k in cards if k.category == cat]
        out.append({"category": cat, "total": len(cs), **{s: sum(1 for k in cs if k.status == s) for s in ("pass", "fail", "incomplete", "executed", "planned", "deferred")}})
    return out


@router.get("/campaigns/{cid}")
def campaign_detail(cid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    c = db.get(m.Campaign, cid)
    if not c:
        raise HTTPException(404, "Campaign not found")
    names = user_names(db)
    ac = db.get(m.Aircraft, c.aircraft_id)
    rev = db.get(m.ConfigRevision, c.config_revision_id) if c.config_revision_id else None
    cards = cards_of(db, cid)
    conds = stage_conditions(db, c) if c.status == "active" else []
    d = to_dict(c)
    d.update(aircraft={"id": ac.id, "code": ac.code, "name": ac.name, "current_revision_id": ac.current_revision_id},
             revision={"id": rev.id, "number": rev.number, "label": rev.label} if rev else None,
             responsible_engineer=names.get(c.responsible_engineer_id), personnel_names=[names.get(p, "?") for p in c.personnel or []],
             personnel_unqualified=[names.get(p, "?") for p in c.personnel or [] if not has_current_qualification(db, p)],
             stage_name=STAGES[c.stage], stages=STAGES, conditions=[{"text": t, "ok": ok} for t, ok in conds],
             can_advance=c.status == "active" and all(ok for _, ok in conds),
             cards=[card_out(db, k, names) for k in cards], coverage=coverage(cards),
             risks=[to_dict(r) for r in db.scalars(select(m.RiskItem).where(m.RiskItem.campaign_id == cid).order_by(m.RiskItem.id))],
             approvals=[ap.approval_out(db, a, names) for a in db.scalars(select(m.Approval).where(m.Approval.subject_type == "campaign", m.Approval.subject_id == cid).order_by(m.Approval.id.desc()))],
             issues=[to_dict(i) for i in db.scalars(select(m.Issue).where(m.Issue.campaign_id == cid))],
             flights=[to_dict(f) for f in db.scalars(select(m.Flight).where(m.Flight.campaign_id == cid).order_by(m.Flight.date))],
             stage_history=[dict(e, by_name=names.get(e.get("by")), stage_name=STAGES[e["stage"]]) for e in c.stage_log or []])
    return d


@router.post("/campaigns/{cid}/advance")
def advance(cid: int, u: m.User = Depends(require("flight_ops", "flight_test")), db: Db = Depends(get_db)):
    c = db.get(m.Campaign, cid)
    if not c or c.status != "active":
        raise HTTPException(409, "Campaign is not active.")
    unmet = [t for t, ok in stage_conditions(db, c) if not ok]
    if unmet:
        raise HTTPException(409, {"message": f"Cannot leave stage “{STAGES[c.stage]}” — conditions not met.", "unmet": unmet})
    if c.stage == len(STAGES) - 1:
        c.status = "complete"
        c.stage_log = (c.stage_log or []) + [{"stage": c.stage, "at": utcnow().isoformat(), "by": u.id, "complete": True}]
        audit(db, u, "campaign_complete", "campaign", c.id, f"Campaign {c.code} completed")
    else:
        c.stage += 1
        c.stage_log = (c.stage_log or []) + [{"stage": c.stage, "at": utcnow().isoformat(), "by": u.id}]
        audit(db, u, "campaign_stage", "campaign", c.id, f"Campaign {c.code} advanced to stage {c.stage + 1}: {STAGES[c.stage]}")
    db.commit()
    return campaign_detail(cid, u, db)


@router.post("/campaigns/{cid}/rebase")
def rebase(cid: int, data: dict = Body({}), u: m.User = Depends(require("flight_ops", "flight_test")), db: Db = Depends(get_db)):
    """Bind the campaign to the aircraft's newly released configuration (retest after a corrective action)."""
    c = db.get(m.Campaign, cid)
    ac = db.get(m.Aircraft, c.aircraft_id) if c else None
    if not c or c.status != "active":
        raise HTTPException(409, "Campaign is not active.")
    if c.config_revision_id == ac.current_revision_id:
        raise HTTPException(409, "Campaign is already bound to the released configuration.")
    old = c.config_revision_id
    c.config_revision_id = ac.current_revision_id
    back = min(c.stage, 4)
    if c.stage > 4:
        c.stage = back
    c.stage_log = (c.stage_log or []) + [{"stage": c.stage, "at": utcnow().isoformat(), "by": u.id, "note": f"Rebased from revision id {old} to {c.config_revision_id}"}]
    audit(db, u, "campaign_rebase", "campaign", c.id,
          f"Campaign {c.code} rebased to configuration revision {c.config_revision_id}; returned to stage “{STAGES[c.stage]}” for re-inspection and re-authorization")
    db.commit()
    return campaign_detail(cid, u, db)


@router.post("/campaigns/{cid}/cancel")
def cancel(cid: int, data: dict = Body(...), u: m.User = Depends(require("flight_ops")), db: Db = Depends(get_db)):
    c = db.get(m.Campaign, cid)
    if not c or c.status != "active":
        raise HTTPException(409, "Campaign is not active.")
    if not (data.get("reason") or "").strip():
        raise HTTPException(422, "A reason is required.")
    c.status = "cancelled"
    audit(db, u, "campaign_cancel", "campaign", c.id, f"Campaign {c.code} cancelled: {data['reason']}")
    db.commit()
    return {"ok": True}


def _pre_eng_review(db, c, tag):
    if tag not in ("plan", "results"):
        return ["Engineering review must be tagged 'plan' or 'results'."]
    if tag == "plan" and c.stage != 1:
        return ["The proposal review is requested during the Engineering review stage."]
    if tag == "results":
        if c.stage != 11:
            return ["The results review is requested during the Engineering review (results) stage."]
        return [t for t, ok in stage_conditions(db, c)[:1] if not ok]
    return []


def _pre_risk(db, c, tag):
    return [t for t, ok in stage_conditions(db, c)[:2] if not ok] if c.stage == 3 else ["Risk assessment is accepted during the Risk assessment stage."]


def _pre_flight_auth(db, c, tag):
    if c.stage != 7:
        return ["Flight-test authorization is requested during the Flight-test authorization stage."]
    ac = db.get(m.Aircraft, c.aircraft_id)
    rd = fleet.readiness(db, ac)
    unmet = [f"Aircraft gate not met: {g['label']}" for g in rd["gates"][:4] if not g["ok"]]
    unmet += [b["text"] for b in rd["blockers"]]
    if c.config_revision_id != ac.current_revision_id:
        unmet.append("Campaign is not bound to the aircraft's released configuration revision.")
    if not ap.valid_approval(db, "risk_assessment", "campaign", c.id):
        unmet.append("Risk assessment has not been accepted.")
    names = user_names(db)
    unmet += [f"{names.get(p, '?')} has no current qualification record." for p in c.personnel or [] if not has_current_qualification(db, p)]
    if not c.personnel:
        unmet.append("No flight-test personnel assigned.")
    return unmet


def _on_flight_auth(db, a, c, user):
    from datetime import timedelta
    if not a.expires_at:
        a.expires_at = utcnow() + timedelta(days=30)
    ac = db.get(m.Aircraft, c.aircraft_id)
    a.config_revision_id = ac.current_revision_id


def _pre_acceptance(db, c, tag):
    if c.stage != 12:
        return ["Campaign acceptance is requested during the Campaign acceptance stage."]
    live = [k for k in cards_of(db, c.id) if k.status != "deferred"]
    return [f"Test card {k.code} is not evaluated and signed." for k in live if not k.signed_at]


ap.PRECOND.update(engineering_review=_pre_eng_review, risk_assessment=_pre_risk, flight_authorization=_pre_flight_auth, campaign_acceptance=_pre_acceptance)
ap.ON_APPROVE["flight_authorization"] = _on_flight_auth


# ───────────── test cards & validation engine ─────────────
def _card(db, kid) -> m.TestCard:
    k = db.get(m.TestCard, kid)
    if not k:
        raise HTTPException(404, "Test card not found")
    return k


def _unlocked(k: m.TestCard):
    if k.signed_at:
        raise HTTPException(409, f"Test card {k.code} is signed and locked. Create a retest card to record new results.")


@hook("test_cards", "before_change")
def _card_lock(db, user, obj, data):
    _unlocked(obj)


@hook("test_cards", "before_save")
def _card_before(db, user, obj, data, is_new, changes):
    c = db.get(m.Campaign, obj.campaign_id)
    if not c or c.status != "active":
        raise HTTPException(409, "Test cards can only be edited in an active campaign.")
    crit = obj.criteria or []
    for i, cr in enumerate(crit):
        if not cr.get("parameter") or cr.get("op") not in OPS or cr.get("value") in (None, ""):
            raise HTTPException(422, f"Acceptance criterion {i + 1} needs a parameter, a comparison and a threshold value.")
        if cr["op"] == "between" and cr.get("value2") in (None, ""):
            raise HTTPException(422, f"Acceptance criterion {i + 1}: 'between' needs an upper limit.")
        cr.setdefault("id", f"c{i + 1}")
        cr.setdefault("required", True)
    ids = [cr["id"] for cr in crit]
    if len(ids) != len(set(ids)):
        for i, cr in enumerate(crit):
            cr["id"] = f"c{i + 1}"
    obj.criteria = [dict(cr) for cr in crit]
    if not is_new and "criteria" in changes and obj.status in ("pass", "fail", "incomplete"):
        obj.status, obj.evaluation = "executed", None
    if not is_new and obj.status == "planned" and any(changes.get(f) for f in ("actual_results", "observations")):
        if c.stage < 8:
            raise HTTPException(409, "Results can only be recorded once the campaign has reached Test execution.")
        obj.status = "executed"


def _need_execution(db, k):
    c = db.get(m.Campaign, k.campaign_id)
    if c.stage < 8 or c.status != "active":
        raise HTTPException(409, "Results can only be recorded once the campaign has reached Test execution (flight-test authorization in force).")
    return c


@router.put("/test-cards/{kid}/measurements")
def set_measurements(kid: int, data: dict = Body(...), u: m.User = Depends(require("flight_ops", "flight_test", "uav_eng")), db: Db = Depends(get_db)):
    k = _card(db, kid)
    _unlocked(k)
    _need_execution(db, k)
    meas = dict(k.measurements or {})
    ids = {c["id"] for c in k.criteria or []}
    for cid_, v in data.items():
        if cid_ not in ids:
            continue
        if v in (None, ""):
            meas.pop(cid_, None)
            continue
        try:
            meas[cid_] = {"value": float(v), "source": "manual", "by": u.id, "at": utcnow().isoformat()}
        except (TypeError, ValueError):
            raise HTTPException(422, f"Measured value for {cid_} must be a number.")
    k.measurements = meas
    if k.status in ("planned", "pass", "fail", "incomplete"):
        k.status, k.evaluation = "executed", None
    audit(db, u, "measure", "test_card", k.id, f"Recorded measurements on {k.code}", {"measurements": data})
    db.commit()
    return card_out(db, k)


@router.post("/test-cards/{kid}/link-log")
def link_log(kid: int, data: dict = Body(...), u: m.User = Depends(require("flight_ops", "flight_test", "uav_eng")), db: Db = Depends(get_db)):
    """Attach a flight log as evidence and pull the measurements it can supply (criteria that name a log metric)."""
    k = _card(db, kid)
    _unlocked(k)
    c = _need_execution(db, k)
    log = db.get(m.FlightLog, data.get("flight_log_id"))
    if not log:
        raise HTTPException(404, "Flight log not found")
    if log.aircraft_id and log.aircraft_id != c.aircraft_id:
        raise HTTPException(409, "This flight log belongs to a different aircraft.")
    if log.source_class == "simulation" and k.category != "Autonomous mission execution":
        raise HTTPException(409, "A log from the internal simulator cannot be used as flight-test evidence.")
    k.flight_log_id = log.id
    meas, pulled, missing = dict(k.measurements or {}), [], []
    for cr in k.criteria or []:
        key = cr.get("metric")
        if not key:
            continue
        v = (log.metrics or {}).get(key)
        if isinstance(v, (int, float)):
            meas[cr["id"]] = {"value": float(v), "source": f"flight_log:{log.id}", "by": u.id, "at": utcnow().isoformat()}
            pulled.append(cr["parameter"])
        else:
            missing.append(cr["parameter"])
    k.measurements = meas
    if k.status in ("planned", "pass", "fail", "incomplete"):
        k.status, k.evaluation = "executed", None
    audit(db, u, "link_log", "test_card", k.id, f"Linked flight log {log.code} to {k.code}", {"pulled": pulled, "missing": missing})
    db.commit()
    return {"card": card_out(db, k), "pulled": pulled, "not_in_log": missing}


def evaluate_card(db: Db, k: m.TestCard) -> dict:
    """Compare measurements with acceptance criteria. Missing required measurements or evidence can never yield a pass."""
    results, missing, failed = [], [], []
    meas = k.measurements or {}
    for cr in k.criteria or []:
        mm = meas.get(cr["id"])
        a = float(cr["value"])
        b = float(cr["value2"]) if cr.get("value2") not in (None, "") else None
        r = {"id": cr["id"], "parameter": cr["parameter"], "op": cr["op"], "value": a, "value2": b, "unit": cr.get("unit"),
             "required": cr.get("required", True), "measured": mm["value"] if mm else None, "source": mm["source"] if mm else None}
        if not mm:
            r["result"] = "missing"
            if r["required"]:
                missing.append(cr["parameter"])
        else:
            ok = OPS[cr["op"]](mm["value"], a, b)
            r["result"] = "pass" if ok else "fail"
            if not ok:
                limit = a if cr["op"] != "between" else (a if mm["value"] < a else b)
                r["deviation"] = round(mm["value"] - limit, 6)
                r["deviation_pct"] = round(100 * (mm["value"] - limit) / abs(limit), 1) if limit else None
                if r["required"]:
                    failed.append(cr["parameter"])
        results.append(r)
    n_att = len(ap.attachments_of(db, "test_card", k.id))
    evidence_ok = (not k.requires_evidence) or n_att > 0 or bool(k.flight_log_id)
    reasons = []
    if not k.criteria:
        reasons.append("No acceptance criteria defined.")
    if missing:
        reasons.append("Required measurements missing: " + ", ".join(missing))
    if not evidence_ok:
        reasons.append("Required evidence missing: attach a document / image or link a flight log.")
    if not (k.actual_results or "").strip():
        reasons.append("Actual results have not been recorded.")
    status = "incomplete" if reasons else "fail" if failed else "pass"
    return {"status": status, "criteria": results, "missing": missing, "failed": failed, "evidence_ok": evidence_ok, "attachments": n_att,
            "flight_log_id": k.flight_log_id, "reasons": reasons, "evaluated_at": utcnow().isoformat()}


@router.post("/test-cards/{kid}/evaluate")
def evaluate(kid: int, u: m.User = Depends(require("flight_ops", "flight_test", "uav_eng")), db: Db = Depends(get_db)):
    k = _card(db, kid)
    _unlocked(k)
    _need_execution(db, k)
    ev = evaluate_card(db, k)
    ev["evaluated_by"] = u.id
    k.evaluation, k.status = ev, ev["status"]
    audit(db, u, "evaluate", "test_card", k.id, f"Evaluated {k.code}: {ev['status'].upper()}", {"failed": ev["failed"], "missing": ev["missing"], "reasons": ev["reasons"]})
    db.commit()
    return card_out(db, k)


@router.post("/test-cards/{kid}/sign")
def sign(kid: int, u: m.User = Depends(require("flight_ops", "flight_test", "uav_eng")), db: Db = Depends(get_db)):
    k = _card(db, kid)
    _unlocked(k)
    if k.status not in ("pass", "fail"):
        raise HTTPException(409, "Only an evaluated test card (pass or fail) can be signed. Incomplete cards need their missing evidence first.")
    fresh = evaluate_card(db, k)
    if fresh["status"] != k.status:
        raise HTTPException(409, "The card changed since it was evaluated — evaluate it again before signing.")
    k.signed_by, k.signed_at = u.id, utcnow()
    body = json.dumps({f: getattr(k, f) for f in ("code", "title", "criteria", "measurements", "actual_results", "observations", "deviations", "status")}
                      | {"signed_by": u.id, "signed_at": k.signed_at.isoformat()}, sort_keys=True, default=str)
    k.signature = hashlib.sha256(body.encode()).hexdigest()
    audit(db, u, "sign", "test_card", k.id, f"Signed test card {k.code} ({k.status.upper()})", {"signature": k.signature})
    db.commit()
    return card_out(db, k)


@router.post("/test-cards/{kid}/defer")
def defer(kid: int, data: dict = Body(...), u: m.User = Depends(require("flight_ops", "flight_test")), db: Db = Depends(get_db)):
    k = _card(db, kid)
    _unlocked(k)
    if not (data.get("reason") or "").strip():
        raise HTTPException(422, "Deferring a test requires a recorded deviation / reason.")
    k.status = "deferred"
    k.deviations = ((k.deviations + "\n") if k.deviations else "") + f"Deferred {today()}: {data['reason'].strip()}"
    audit(db, u, "defer", "test_card", k.id, f"Deferred test card {k.code}: {data['reason']}")
    db.commit()
    return card_out(db, k)


@router.post("/test-cards/{kid}/retest")
def retest(kid: int, data: dict = Body({}), u: m.User = Depends(require("flight_ops", "flight_test", "uav_eng")), db: Db = Depends(get_db)):
    src = _card(db, kid)
    cid = data.get("campaign_id") or src.campaign_id
    c = db.get(m.Campaign, cid)
    if not c or c.status != "active":
        raise HTTPException(409, "Retest cards must be created in an active campaign.")
    k = m.TestCard(code=next_code(db, m.TestCard, "TP"), campaign_id=cid, title=f"Retest — {src.title}"[:200], category=src.category,
                   objective=src.objective, aircraft_config=src.aircraft_config, preconditions=src.preconditions, procedure=src.procedure,
                   expected_results=src.expected_results, criteria=[dict(x) for x in src.criteria or []], measurements={},
                   requires_evidence=src.requires_evidence, status="planned", retest_of_id=src.id)
    db.add(k)
    db.flush()
    audit(db, u, "retest", "test_card", k.id, f"Created retest card {k.code} from {src.code}")
    db.commit()
    return card_out(db, k)


@router.get("/validation/overview")
def validation_overview(aircraft_id: int | None = None, campaign_id: int | None = None, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    st = select(m.TestCard, m.Campaign).join(m.Campaign, m.Campaign.id == m.TestCard.campaign_id)
    if aircraft_id:
        st = st.where(m.Campaign.aircraft_id == aircraft_id)
    if campaign_id:
        st = st.where(m.Campaign.id == campaign_id)
    pairs = db.execute(st).all()
    cards = [k for k, _ in pairs]
    camp = {c.id: c for _, c in pairs}
    acs = {a.id: a.code for a in db.scalars(select(m.Aircraft))}
    deviations, anomalies, seen_logs = [], [], set()
    for k in cards:
        for r in (k.evaluation or {}).get("criteria", []):
            if r["result"] == "fail":
                deviations.append({"card_id": k.id, "card": k.code, "title": k.title, "category": k.category, "aircraft": acs.get(camp[k.campaign_id].aircraft_id),
                                   "parameter": r["parameter"], "measured": r["measured"], "op": r["op"], "limit": r["value"], "limit2": r["value2"],
                                   "unit": r["unit"], "deviation": r.get("deviation"), "deviation_pct": r.get("deviation_pct"), "source": r["source"]})
        if k.flight_log_id and k.flight_log_id not in seen_logs:
            seen_logs.add(k.flight_log_id)
            log = db.get(m.FlightLog, k.flight_log_id)
            for o in (log.observations or []) if log else []:
                if o["level"] in ("warning", "critical"):
                    anomalies.append({"log_id": log.id, "log": log.code, "card": k.code, **o})
    done = [k for k in cards if k.status in ("pass", "fail")]
    first = {}
    for k in sorted(cards, key=lambda x: x.id):
        root = k.retest_of_id or k.id
        first.setdefault(root, []).append(k)
    issues = db.scalars(select(m.Issue).where(m.Issue.status != "closed")).all()
    if aircraft_id:
        issues = [i for i in issues if i.aircraft_id == aircraft_id]
    if campaign_id:
        issues = [i for i in issues if i.campaign_id == campaign_id]
    return {
        "coverage": coverage(cards),
        "totals": {s: sum(1 for k in cards if k.status == s) for s in ("pass", "fail", "incomplete", "executed", "planned", "deferred")} | {"total": len(cards)},
        "reliability": {"evaluated": len(done), "pass_rate": round(100 * sum(1 for k in done if k.status == "pass") / len(done), 1) if done else None,
                        "retests": sum(1 for k in cards if k.retest_of_id), "retest_pass": sum(1 for k in cards if k.retest_of_id and k.status == "pass"),
                        "signed": sum(1 for k in cards if k.signed_at),
                        "categories_covered": sum(1 for c in coverage(cards) if c["pass"] + c["fail"] > 0), "categories_total": len(m.VALIDATION_CATEGORIES)},
        "deviations": deviations, "anomalies": anomalies,
        "outstanding_issues": [{"id": i.id, "code": i.code, "title": i.title, "severity": i.severity, "status": i.status, "aircraft": acs.get(i.aircraft_id)} for i in issues],
        "incomplete": [{"id": k.id, "code": k.code, "title": k.title, "status": k.status, "campaign": camp[k.campaign_id].code,
                        "reasons": (k.evaluation or {}).get("reasons", [])} for k in cards if k.status in ("incomplete", "executed", "planned")],
    }


# ───────────── flights & safety gates ─────────────
def flight_gates(db: Db, aircraft_id: int, campaign_id=None, pilot_id=None, mission_id=None) -> dict:
    ac = db.get(m.Aircraft, aircraft_id)
    rd = fleet.readiness(db, ac)
    gates = []

    def g(label, ok, detail=""):
        gates.append({"label": label, "ok": bool(ok), "detail": detail})

    g("Aircraft not grounded and maintenance not overdue", not rd["blockers"], "; ".join(b["text"] for b in rd["blockers"]))
    if campaign_id:
        ok = rd["state"] == "Approved for designated testing" and rd["designated_campaign"] and rd["designated_campaign"]["id"] == campaign_id
        c = db.get(m.Campaign, campaign_id)
        g("Flight-test authorization in force for this campaign", ok, f"Aircraft state: {rd['state']}")
        g("Campaign is in the Test execution stage", bool(c and c.stage == 8 and c.status == "active"), f"Stage: {STAGES[c.stage] if c else '-'}")
    else:
        g("Aircraft holds an operational release (no campaign designated)", bool(rd["operational_release"]),
          rd["operational_release"]["text"] if rd["operational_release"] else f"Aircraft state: {rd['state']}")
    g("Pilot / operator assigned", bool(pilot_id))
    if pilot_id:
        g("Pilot / operator holds a current qualification record", has_current_qualification(db, pilot_id))
    if mission_id:
        ms = db.get(m.Mission, mission_id)
        g("Mission validated against geofence and boundaries", bool(ms and ms.status in ("validated", "sim_passed")), f"Mission status: {ms.status if ms else '-'}")
        cl = ap.checklist_complete(db, "preflight_safety_gates", "mission", mission_id)
        g("Pre-flight safety gate checklist completed", bool(cl))
    return {"pass": all(x["ok"] for x in gates), "gates": gates, "aircraft_state": rd["state"]}


@router.post("/flights/preflight")
def preflight(data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    if not db.get(m.Aircraft, data.get("aircraft_id") or 0):
        raise HTTPException(404, "Aircraft not found")
    return flight_gates(db, data["aircraft_id"], data.get("campaign_id"), data.get("pilot_id"), data.get("mission_id"))


@hook("flights", "before_change")
def _flight_fixed(db, user, obj, data):
    for f in ("aircraft_id", "source_class"):
        if f in data and str(data[f]) != str(getattr(obj, f)):
            raise HTTPException(409, "Aircraft and flight class cannot be changed after a flight is recorded — delete and re-enter it.")


@hook("flights", "before_save")
def _flight_before(db, user, obj, data, is_new, changes):
    if (obj.duration_s or 0) < 0:
        raise HTTPException(422, "Duration cannot be negative.")
    if not is_new and "duration_s" in changes and obj.source_class == "physical":
        old, new = changes["duration_s"]
        maint.accumulate(db, obj.aircraft_id, (new or 0) - (old or 0), 0)


@hook("flights", "after_create")
def _flight_after(db, user, obj, data):
    if obj.source_class != "physical":
        obj.gate_status = "n/a"
        return
    res = flight_gates(db, obj.aircraft_id, obj.campaign_id, obj.pilot_id, obj.mission_id)
    obj.gate_detail = res
    obj.gate_status = "pass" if res["pass"] else "violation"
    maint.accumulate(db, obj.aircraft_id, obj.duration_s or 0, 1)
    if not res["pass"]:
        failed = [x["label"] for x in res["gates"] if not x["ok"]]
        inc = m.Incident(code=next_code(db, m.Incident, "INC"), date=obj.date, aircraft_id=obj.aircraft_id, flight_id=obj.id,
                         incident_type="Safety-gate violation", severity="major", reported_by=user.id,
                         description=f"Physical flight {obj.code} was recorded without all safety gates satisfied: " + "; ".join(failed))
        db.add(inc)
        audit(db, user, "gate_violation", "flight", obj.id, f"Flight {obj.code} recorded with safety-gate violations", {"failed": failed})


@hook("flights", "before_delete")
def _flight_delete(db, user, obj):
    if obj.source_class == "physical":
        maint.accumulate(db, obj.aircraft_id, -(obj.duration_s or 0), -1)
    for i in db.scalars(select(m.Incident).where(m.Incident.flight_id == obj.id)):
        i.flight_id = None


# ───────────── issues ─────────────
FLOW = ["open", "analysis", "corrective_action", "verification", "closed"]


@hook("issues", "before_save")
def _issue_before(db, user, obj, data, is_new, changes):
    if is_new:
        obj.reported_by, obj.status = user.id, "open"
        if obj.test_card_id and not obj.campaign_id:
            obj.campaign_id = db.get(m.TestCard, obj.test_card_id).campaign_id
        if obj.campaign_id and not obj.aircraft_id:
            obj.aircraft_id = db.get(m.Campaign, obj.campaign_id).aircraft_id
        ac = db.get(m.Aircraft, obj.aircraft_id) if obj.aircraft_id else None
        if ac:
            obj.hardware_revision = obj.hardware_revision or ac.hardware_revision
            obj.software_version = obj.software_version or ac.software_version or ac.autopilot_firmware
    elif obj.status == "closed" and changes:
        raise HTTPException(409, "A closed issue cannot be edited. Reopen it first.")


@router.post("/issues/{iid}/transition")
def transition(iid: int, data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    i = db.get(m.Issue, iid)
    if not i:
        raise HTTPException(404, "Issue not found")
    to = data.get("to")
    if to == "reopen":
        if i.status == "open":
            raise HTTPException(409, "Issue is already open.")
        if not (data.get("note") or "").strip():
            raise HTTPException(422, "Reopening requires a note.")
        i.status, i.closed_at = "analysis", None
        db.add(m.Comment(subject_type="issue", subject_id=i.id, user_id=u.id, body=f"Reopened: {data['note'].strip()}"))
    else:
        if to not in FLOW[1:4] or FLOW.index(to) != FLOW.index(i.status) + 1:
            raise HTTPException(409, f"Issue is in “{i.status}”; the next step is “{FLOW[min(FLOW.index(i.status) + 1, 4)]}”. Closure requires an approval.")
        need = {"analysis": [("assigned_to", "An engineer must be assigned")],
                "corrective_action": [("root_cause", "Root-cause analysis must be recorded")],
                "verification": [("corrective_action", "Corrective action must be recorded"), ("verification_test_card_id", "A verification test card must be linked")]}[to]
        unmet = [msg for f, msg in need if not getattr(i, f)]
        if unmet:
            raise HTTPException(409, {"message": "Cannot advance the issue.", "unmet": unmet})
        i.status = to
    audit(db, u, "issue_status", "issue", i.id, f"Issue {i.code} → {i.status}")
    db.commit()
    return to_dict(i)


def _pre_closure(db, i, tag):
    unmet = []
    if i.status != "verification":
        unmet.append("The issue must be in the verification step.")
    k = db.get(m.TestCard, i.verification_test_card_id) if i.verification_test_card_id else None
    if not k:
        unmet.append("No verification test card is linked.")
    elif k.status != "pass" or not k.signed_at:
        unmet.append(f"Verification test {k.code} has not passed and been signed (status: {k.status}).")
    if not i.root_cause or not i.corrective_action:
        unmet.append("Root cause and corrective action must be recorded.")
    return unmet


def _on_closure(db, a, i, user):
    i.status, i.closed_at = "closed", utcnow()


ap.PRECOND["issue_closure"] = _pre_closure
ap.ON_APPROVE["issue_closure"] = _on_closure


@router.get("/issues/{iid}/trace")
def trace(iid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    i = db.get(m.Issue, iid)
    if not i:
        raise HTTPException(404, "Issue not found")
    names = user_names(db)

    def card(kid):
        k = db.get(m.TestCard, kid) if kid else None
        return {"id": k.id, "code": k.code, "title": k.title, "status": k.status, "signed": bool(k.signed_at)} if k else None

    camp = db.get(m.Campaign, i.campaign_id) if i.campaign_id else None
    log = db.get(m.FlightLog, i.flight_log_id) if i.flight_log_id else None
    ac = db.get(m.Aircraft, i.aircraft_id) if i.aircraft_id else None
    closure = [ap.approval_out(db, a, names) for a in db.scalars(select(m.Approval).where(m.Approval.kind == "issue_closure", m.Approval.subject_id == iid).order_by(m.Approval.id.desc()))]
    timeline = [{"ts": e.ts.isoformat(), "user": e.username, "summary": e.summary} for e in
                db.scalars(select(m.AuditLog).where(m.AuditLog.entity.in_(["issue", "issues"]), m.AuditLog.entity_id == str(iid)).order_by(m.AuditLog.id))]
    return {"issue": dict(to_dict(i), assigned_to_name=names.get(i.assigned_to), reported_by_name=names.get(i.reported_by)),
            "aircraft": {"id": ac.id, "code": ac.code, "name": ac.name} if ac else None,
            "campaign": {"id": camp.id, "code": camp.code, "name": camp.name} if camp else None,
            "origin_card": card(i.test_card_id), "flight_log": {"id": log.id, "code": log.code, "name": log.name} if log else None,
            "verification_card": card(i.verification_test_card_id), "closure": closure, "timeline": timeline, "flow": FLOW}
