"""Maintenance programme, alerts, usage accumulation and reliability metrics."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import models as m
from .core import internal_user, to_dict, today, user_names
from .db import get_db
from .resources import hook

router = APIRouter(prefix="/api")


def alerts(db: Db, ac: m.Aircraft) -> list:
    out = []
    hrs, cyc = ac.flight_hours or 0, ac.flight_cycles or 0
    for t in db.scalars(select(m.MaintenanceTask).where(m.MaintenanceTask.aircraft_id == ac.id, m.MaintenanceTask.active)):
        base = {"task_id": t.id, "aircraft_id": ac.id, "aircraft": ac.code, "category": t.category, "title": t.title}
        if t.task_type == "condition":
            out.append({**base, "level": "overdue", "message": f"{ac.code}: condition-based task open — {t.title}" + (f" ({t.trigger_note})" if t.trigger_note else "")})
            continue
        ratios = []
        if t.interval_hours:
            used = hrs - (t.last_done_hours or 0)
            ratios.append((used / t.interval_hours, f"{used:.1f} of {t.interval_hours:g} flight hours"))
        if t.interval_cycles:
            used = cyc - (t.last_done_cycles or 0)
            ratios.append((used / t.interval_cycles, f"{used} of {t.interval_cycles} cycles"))
        if t.interval_days:
            used = (today() - (t.last_done_date or t.created_at.date())).days
            ratios.append((used / t.interval_days, f"{used} of {t.interval_days} days"))
        if not ratios:
            continue
        r, text = max(ratios)
        if r >= 1:
            out.append({**base, "level": "overdue", "message": f"{ac.code}: {t.title} overdue ({text})"})
        elif r >= 0.9:
            out.append({**base, "level": "due_soon", "message": f"{ac.code}: {t.title} due soon ({text})"})
    for c in db.scalars(select(m.Component).where(m.Component.aircraft_id == ac.id, m.Component.status == "installed")):
        lim = (c.specs or {}).get("cycle_limit")
        try:
            lim = float(lim) if lim not in (None, "") else None
        except (TypeError, ValueError):
            lim = None
        if lim and (c.cycles or 0) >= 0.9 * lim:
            over = (c.cycles or 0) >= lim
            out.append({"task_id": None, "aircraft_id": ac.id, "aircraft": ac.code, "category": c.category, "title": f"{c.code} cycle limit",
                        "level": "overdue" if over else "due_soon",
                        "message": f"{ac.code}: {c.category.lower()} {c.code} at {c.cycles} of {lim:g} cycle limit"})
    return out


def accumulate(db: Db, aircraft_id: int, d_seconds: float, d_cycles: int) -> None:
    """Add (or remove) flight time and cycles on the aircraft and every installed component. Physical flights only."""
    ac = db.get(m.Aircraft, aircraft_id)
    if not ac:
        return
    ac.flight_hours = max(0.0, (ac.flight_hours or 0) + d_seconds / 3600)
    ac.flight_cycles = max(0, (ac.flight_cycles or 0) + d_cycles)
    for c in db.scalars(select(m.Component).where(m.Component.aircraft_id == aircraft_id, m.Component.status == "installed")):
        c.hours = max(0.0, (c.hours or 0) + d_seconds / 3600)
        c.cycles = max(0, (c.cycles or 0) + d_cycles)


@hook("maintenance_actions", "before_save")
def _ma_before(db, user, obj, data, is_new, changes):
    if obj.component_id and not obj.aircraft_id:
        comp = db.get(m.Component, obj.component_id)
        obj.aircraft_id = comp.aircraft_id if comp else None
    if not (obj.aircraft_id or obj.component_id or obj.equipment_id):
        raise HTTPException(422, "A maintenance action must reference an aircraft, a component or C2 equipment.")
    if obj.failure and not obj.component_id:
        raise HTTPException(422, "A component failure must reference the failed component.")
    if is_new:
        obj.performed_by = user.id
        ac = db.get(m.Aircraft, obj.aircraft_id) if obj.aircraft_id else None
        if ac:
            obj.hours_at_action, obj.cycles_at_action = ac.flight_hours, ac.flight_cycles


@hook("maintenance_actions", "after_create")
def _ma_after(db, user, obj, data):
    if obj.task_id:
        t = db.get(m.MaintenanceTask, obj.task_id)
        if t:
            t.last_done_date, t.last_done_hours, t.last_done_cycles = obj.date, obj.hours_at_action, obj.cycles_at_action
            if t.task_type == "condition":
                t.active = False
    if obj.component_id:
        comp = db.get(m.Component, obj.component_id)
        db.add(m.ComponentEvent(component_id=comp.id, aircraft_id=obj.aircraft_id, event_type="failed" if obj.failure else obj.action_type,
                                description=f"{obj.code}: {obj.description}" + (f" — findings: {obj.findings}" if obj.findings else ""),
                                user_id=user.id, hours_at_event=comp.hours))
    if obj.equipment_id:
        eq = db.get(m.C2Equipment, obj.equipment_id)
        if eq:
            eq.last_maintenance = obj.date
            if obj.condition == "unserviceable":
                eq.status = "unserviceable"
    if obj.condition == "unserviceable" and obj.aircraft_id and obj.action_type not in ("repair", "replacement"):
        db.add(m.MaintenanceTask(aircraft_id=obj.aircraft_id, component_id=obj.component_id, task_type="condition", category=obj.category,
                                 title=f"Rectify unserviceable finding from {obj.code}", trigger_note=(obj.findings or obj.description)[:300]))


@router.get("/maintenance/alerts")
def all_alerts(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    out = []
    for ac in db.scalars(select(m.Aircraft)):
        out += alerts(db, ac)
    for eq in db.scalars(select(m.C2Equipment).where(m.C2Equipment.next_maintenance.is_not(None))):
        days = (eq.next_maintenance - today()).days
        if days <= 14:
            out.append({"task_id": None, "equipment_id": eq.id, "category": "C2 equipment", "title": eq.name,
                        "level": "overdue" if days < 0 else "due_soon",
                        "message": f"{eq.code} {eq.name}: maintenance {'overdue by ' + str(-days) if days < 0 else 'due in ' + str(days)} days"})
    return sorted(out, key=lambda a: a["level"] != "overdue")


@router.get("/aircraft/{aid}/maintenance")
def aircraft_maintenance(aid: int, u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    ac = db.get(m.Aircraft, aid)
    if not ac:
        raise HTTPException(404, "Aircraft not found")
    names = user_names(db)
    comps = {c.id: f"{c.code} · {c.model}" for c in db.scalars(select(m.Component))}
    acts = [dict(to_dict(a), performed_by_name=names.get(a.performed_by), component=comps.get(a.component_id)) for a in
            db.scalars(select(m.MaintenanceAction).where(m.MaintenanceAction.aircraft_id == aid).order_by(m.MaintenanceAction.date.desc(), m.MaintenanceAction.id.desc()))]
    tasks = [to_dict(t) for t in db.scalars(select(m.MaintenanceTask).where(m.MaintenanceTask.aircraft_id == aid).order_by(m.MaintenanceTask.id))]
    batteries = [to_dict(c) for c in db.scalars(select(m.Component).where(m.Component.aircraft_id == aid, m.Component.category == "Battery"))]
    return {"aircraft": to_dict(ac), "alerts": alerts(db, ac), "tasks": tasks, "actions": acts, "batteries": batteries}


def reliability(db: Db) -> dict:
    comps = list(db.scalars(select(m.Component)))
    fails = {}
    for a in db.scalars(select(m.MaintenanceAction).where(m.MaintenanceAction.failure)):
        fails.setdefault(a.component_id, []).append(a)
    groups = {}
    for c in comps:
        g = groups.setdefault((c.category, c.manufacturer or "", c.model), {"category": c.category, "manufacturer": c.manufacturer, "model": c.model,
                                                                            "units": 0, "hours": 0.0, "cycles": 0, "failures": 0, "sources": []})
        g["units"] += 1
        g["hours"] += c.hours or 0
        g["cycles"] += c.cycles or 0
        g["failures"] += len(fails.get(c.id, []))
        g["sources"] += [{"type": "maintenance_action", "id": a.id, "label": a.code} for a in fails.get(c.id, [])]
    rows = []
    for g in groups.values():
        g["hours"] = round(g["hours"], 2)
        g["mtbf_h"] = round(g["hours"] / g["failures"], 1) if g["failures"] and g["hours"] else None
        g["failures_per_100h"] = round(100 * g["failures"] / g["hours"], 2) if g["hours"] else None
        rows.append(g)
    rows.sort(key=lambda g: (-g["failures"], -(g["failures_per_100h"] or 0), g["category"]))
    fleet = []
    for ac in db.scalars(select(m.Aircraft).order_by(m.Aircraft.code)):
        f = db.scalars(select(m.MaintenanceAction).where(m.MaintenanceAction.aircraft_id == ac.id, m.MaintenanceAction.failure)).all()
        iss = db.scalars(select(m.Issue).where(m.Issue.aircraft_id == ac.id)).all()
        inc = db.scalars(select(m.Incident).where(m.Incident.aircraft_id == ac.id)).all()
        h = ac.flight_hours or 0
        fleet.append({"aircraft_id": ac.id, "code": ac.code, "name": ac.name, "hardware_revision": ac.hardware_revision, "flight_hours": round(h, 2),
                      "flight_cycles": ac.flight_cycles or 0, "failures": len(f), "issues": len(iss),
                      "open_issues": sum(1 for i in iss if i.status != "closed"), "incidents": len(inc),
                      "mtbf_h": round(h / len(f), 1) if f and h else None})
    return {"components": rows, "aircraft": fleet,
            "note": "MTBF is flight hours divided by recorded failures; it is undefined (not infinite) where no failure or no hours are recorded."}


@router.get("/maintenance/reliability")
def reliability_ep(u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    return reliability(db)
