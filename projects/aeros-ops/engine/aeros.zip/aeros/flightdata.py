"""Flight-data normalisation and engineering analysis.

Every supported source (PX4 ULog, ArduPilot BIN, MAVLink tlog, CSV, JSON, internal simulator) is reduced to one
channel set on a uniform time grid, so metrics, charts, comparison and test-card evaluation share a single code path.
"""
import json
import math
from pathlib import Path

import numpy as np

G = 9.80665
STEP_CH = {"gps_fix", "sats", "mode_idx"}
SIM_MODES = {0: "STANDBY", 1: "TAKEOFF", 2: "MISSION", 3: "RTL", 4: "LAND", 5: "HOLD"}
PX4_NAV = {0: "MANUAL", 1: "ALTCTL", 2: "POSCTL", 3: "AUTO_MISSION", 4: "AUTO_LOITER", 5: "AUTO_RTL", 10: "ACRO", 12: "DESCEND",
           14: "OFFBOARD", 15: "STAB", 17: "AUTO_TAKEOFF", 18: "AUTO_LAND", 20: "AUTO_PRECLAND", 22: "AUTO_VTOL_TAKEOFF"}

# key -> (label, unit, analysis area)
METRICS = {
    "duration_s": ("Log duration", "s", "General"), "flight_time_s": ("Airborne time", "s", "General"),
    "max_rel_alt_m": ("Maximum height above home", "m", "General"), "max_gs_ms": ("Maximum ground speed", "m/s", "General"),
    "max_climb_ms": ("Maximum climb rate", "m/s", "General"), "max_descent_ms": ("Maximum descent rate", "m/s", "General"),
    "distance_m": ("Distance flown", "m", "General"),
    "roll_max_deg": ("Maximum roll angle", "deg", "Flight stability"), "pitch_max_deg": ("Maximum pitch angle", "deg", "Flight stability"),
    "att_osc_rms_deg": ("Attitude oscillation (RMS, >1 Hz)", "deg", "Flight stability"),
    "hover_att_std_deg": ("Hover attitude standard deviation", "deg", "Flight stability"),
    "hover_alt_std_m": ("Hover altitude standard deviation", "m", "Flight stability"),
    "hover_pos_std_m": ("Hover horizontal position standard deviation", "m", "Flight stability"),
    "roll_track_rms_deg": ("Roll tracking error (RMS)", "deg", "Flight-controller performance"),
    "pitch_track_rms_deg": ("Pitch tracking error (RMS)", "deg", "Flight-controller performance"),
    "rate_max_dps": ("Maximum angular rate", "deg/s", "Flight-controller performance"),
    "load_max_pct": ("Maximum autopilot CPU load", "%", "Flight-controller performance"),
    "motor_imbalance_pct": ("Motor output imbalance", "%", "Flight-controller performance"),
    "motor_saturation_pct": ("Time with a motor output saturated", "%", "Flight-controller performance"),
    "vib_rms_ms2": ("Vibration (accelerometer RMS, worst axis)", "m/s²", "Vibration"),
    "vib_peak_hz": ("Dominant vibration frequency", "Hz", "Vibration"),
    "vibe_max_ms2": ("Autopilot vibration level (maximum)", "m/s²", "Vibration"), "clip_count": ("Accelerometer clipping events", "", "Vibration"),
    "sats_min": ("Minimum satellites", "", "Navigation accuracy"), "sats_mean": ("Mean satellites", "", "Navigation accuracy"),
    "hdop_max": ("Maximum HDOP", "", "Navigation accuracy"), "hdop_mean": ("Mean HDOP", "", "Navigation accuracy"),
    "gps_fix_loss_count": ("GNSS 3D-fix losses in flight", "", "Navigation accuracy"),
    "pos_jump_count": ("Position jumps", "", "Navigation accuracy"),
    "xtrack_rms_m": ("Cross-track error (RMS)", "m", "Mission execution"), "xtrack_max_m": ("Cross-track error (maximum)", "m", "Mission execution"),
    "v_min": ("Minimum battery voltage", "V", "Power"), "v_mean": ("Mean battery voltage", "V", "Power"), "v_sag_v": ("Voltage sag from start", "V", "Power"),
    "i_max": ("Maximum current", "A", "Power"), "i_mean": ("Mean current in flight", "A", "Power"), "mah_used": ("Charge consumed", "mAh", "Power"),
    "energy_wh": ("Energy consumed", "Wh", "Power"), "power_mean_w": ("Mean power in flight", "W", "Power"), "power_max_w": ("Maximum power", "W", "Power"),
    "r_internal_mohm": ("Estimated pack internal resistance", "mΩ", "Battery"), "batt_temp_max_c": ("Maximum battery temperature", "°C", "Battery"),
    "remaining_min_pct": ("Minimum battery remaining", "%", "Battery"),
    "link_gap_count": ("Telemetry interruptions (>2 s)", "", "Communications"), "link_gap_max_s": ("Longest telemetry interruption", "s", "Communications"),
    "rssi_min": ("Minimum RSSI", "", "Communications"),
    "mode_changes": ("Flight-mode changes", "", "Software"), "failsafe_events": ("Failsafe messages", "", "Software"),
    "error_events": ("Error-severity messages", "", "Software"),
}


class Recorder:
    """Collects raw samples per channel while a source is parsed."""

    def __init__(self):
        self.ch: dict[str, tuple[list, list]] = {}
        self.acc: list = []  # (t, ax, ay, az) at native rate, m/s²
        self.events: list = []
        self.arrivals: list = []
        self.modes: list = []  # (t, name)
        self.info: dict = {}

    def add(self, name, t, v):
        if v is None or (isinstance(v, float) and math.isnan(v)):
            return
        c = self.ch.get(name)
        if c is None:
            c = self.ch[name] = ([], [])
        c[0].append(t)
        c[1].append(float(v))

    def add_array(self, name, t, v):
        t, v = np.asarray(t, float), np.asarray(v, float)
        ok = np.isfinite(t) & np.isfinite(v)
        if ok.any():
            c = self.ch.setdefault(name, ([], []))
            c[0].extend(t[ok].tolist())
            c[1].extend(v[ok].tolist())

    def mode(self, t, name):
        if name and (not self.modes or self.modes[-1][1] != name):
            self.modes.append((t, name))
            self.events.append({"t": t, "type": "mode", "text": f"Mode → {name}", "severity": "info"})

    def text(self, t, text, severity=6):
        sev = "critical" if severity <= 2 else "warning" if severity <= 4 else "info"
        self.events.append({"t": t, "type": "text", "text": str(text).strip("\x00 ").strip(), "severity": sev, "mav_severity": int(severity)})

    def finalize(self) -> dict:
        times = [x for c in self.ch.values() for x in (c[0][0], c[0][-1])] if self.ch else []
        if not times or max(times) - min(times) < 1.0:
            raise ValueError("The file contains no usable time-series data (less than one second of recognised telemetry).")
        t0, t1 = min(times), max(times)
        rate = 10.0
        while (t1 - t0) * rate > 150_000:
            rate /= 2
        grid = np.arange(0, (t1 - t0) + 1e-9, 1 / rate)
        data = {"t": grid}
        for name, (ts, vs) in self.ch.items():
            ts, vs = np.asarray(ts) - t0, np.asarray(vs)
            order = np.argsort(ts, kind="stable")
            ts, vs = ts[order], vs[order]
            if name in STEP_CH:
                idx = np.clip(np.searchsorted(ts, grid, side="right") - 1, 0, len(ts) - 1)
                y = vs[idx].astype(float)
            else:
                y = np.interp(grid, ts, vs)
            y[(grid < ts[0] - 1.0) | (grid > ts[-1] + 1.0)] = np.nan
            data[name] = y
        if self.acc:
            a = np.asarray(self.acc, float)
            a = a[np.argsort(a[:, 0], kind="stable")]
            a[:, 0] -= t0
            data["acc_raw"] = a
        arr = np.sort(np.asarray(self.arrivals, float)) - t0 if self.arrivals else None
        events = sorted(({**e, "t": round(e["t"] - t0, 2)} for e in self.events), key=lambda e: e["t"])
        return {"data": data, "events": events[:2000], "arrivals": arr, "info": self.info, "rate": rate}


def quat_to_euler(w, x, y, z):
    roll = np.arctan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    pitch = np.arcsin(np.clip(2 * (w * y - z * x), -1, 1))
    yaw = np.arctan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    return np.degrees(roll), np.degrees(pitch), np.degrees(yaw)


# ───────────── MAVLink (tlog and live recordings) ─────────────
def feed_mav(rec: Recorder, msg, t: float) -> None:
    typ = msg.get_type()
    if typ == "BAD_DATA":
        return
    rec.arrivals.append(t)
    d = math.degrees
    if typ == "ATTITUDE":
        rec.add("roll", t, d(msg.roll)); rec.add("pitch", t, d(msg.pitch)); rec.add("yaw", t, d(msg.yaw) % 360)
        rec.add("rollspeed", t, d(msg.rollspeed)); rec.add("pitchspeed", t, d(msg.pitchspeed)); rec.add("yawspeed", t, d(msg.yawspeed))
    elif typ == "GLOBAL_POSITION_INT":
        if msg.lat or msg.lon:
            rec.add("lat", t, msg.lat / 1e7); rec.add("lon", t, msg.lon / 1e7)
        rec.add("alt", t, msg.alt / 1000); rec.add("rel_alt", t, msg.relative_alt / 1000)
        rec.add("gs", t, math.hypot(msg.vx, msg.vy) / 100); rec.add("climb", t, -msg.vz / 100)
    elif typ == "GPS_RAW_INT":
        rec.add("gps_fix", t, msg.fix_type); rec.add("sats", t, msg.satellites_visible if msg.satellites_visible != 255 else None)
        rec.add("hdop", t, msg.eph / 100 if msg.eph != 65535 else None)
    elif typ == "SYS_STATUS":
        rec.add("voltage", t, msg.voltage_battery / 1000 if msg.voltage_battery not in (0, 65535) else None)
        rec.add("current", t, msg.current_battery / 100 if msg.current_battery >= 0 else None)
        rec.add("remaining", t, msg.battery_remaining if msg.battery_remaining >= 0 else None)
        rec.add("load", t, msg.load / 10)
    elif typ == "BATTERY_STATUS":
        rec.add("batt_temp", t, msg.temperature / 100 if msg.temperature != 32767 else None)
        rec.add("mah", t, msg.current_consumed if msg.current_consumed >= 0 else None)
    elif typ == "SERVO_OUTPUT_RAW":
        for i in range(1, 9):
            v = getattr(msg, f"servo{i}_raw", 0)
            if v:
                rec.add(f"m{i}", t, v)
    elif typ in ("SCALED_IMU", "RAW_IMU", "HIGHRES_IMU"):
        if rec.info.setdefault("imu_src", typ) == typ:  # one IMU stream only, the first seen
            k = 1.0 if typ == "HIGHRES_IMU" else G / 1000
            rec.acc.append((t, msg.xacc * k, msg.yacc * k, msg.zacc * k))
    elif typ == "VIBRATION":
        rec.add("vibe_x", t, msg.vibration_x); rec.add("vibe_y", t, msg.vibration_y); rec.add("vibe_z", t, msg.vibration_z)
        rec.add("clip", t, msg.clipping_0 + msg.clipping_1 + msg.clipping_2)
    elif typ == "RADIO_STATUS":
        rec.add("rssi", t, msg.rssi)
    elif typ == "RC_CHANNELS":
        rec.add("rssi", t, msg.rssi if msg.rssi != 255 else None)
    elif typ == "NAV_CONTROLLER_OUTPUT":
        rec.add("roll_sp", t, msg.nav_roll); rec.add("pitch_sp", t, msg.nav_pitch); rec.add("xtrack", t, msg.xtrack_error)
    elif typ == "ATTITUDE_TARGET":
        r, p, _ = quat_to_euler(*msg.q)
        rec.add("roll_sp", t, float(r)); rec.add("pitch_sp", t, float(p))
    elif typ == "STATUSTEXT":
        rec.text(t, msg.text, msg.severity)
    elif typ == "HEARTBEAT" and msg.type not in (6, 18, 26, 27):  # ignore GCS / companion heartbeats
        rec.info.setdefault("autopilot", int(msg.autopilot))
        rec.info.setdefault("vehicle_type", int(msg.type))
        if msg.autopilot == 0:
            name = SIM_MODES.get(msg.custom_mode, f"MODE {msg.custom_mode}")
        else:
            from pymavlink import mavutil
            name = mavutil.mode_string_v10(msg)
        rec.mode(t, name)


def parse_tlog(path: Path) -> Recorder:
    from pymavlink import mavutil

    rec = Recorder()
    mlog = mavutil.mavlink_connection(str(path), dialect="ardupilotmega")
    while True:
        try:
            msg = mlog.recv_match()
        except Exception:
            continue
        if msg is None:
            break
        feed_mav(rec, msg, float(getattr(msg, "_timestamp", 0.0)))
    _close(mlog)
    return rec


def _close(mlog) -> None:
    """Release the file handle / memory map pymavlink holds, so the source file can be moved or deleted on Windows."""
    for attr in ("data_map", "filehandle", "f"):
        h = getattr(mlog, attr, None)
        try:
            if h is not None:
                h.close()
        except Exception:
            pass


def parse_bin(path: Path) -> Recorder:
    from pymavlink import mavutil

    rec = Recorder()
    mlog = mavutil.mavlink_connection(str(path))
    want = ["ATT", "GPS", "POS", "BAT", "IMU", "VIBE", "RCOU", "MODE", "MSG", "CTUN", "RATE"]
    g = lambda m_, k: getattr(m_, k, None)  # noqa: E731
    while True:
        msg = mlog.recv_match(type=want)
        if msg is None:
            break
        typ, t = msg.get_type(), float(msg._timestamp)
        rec.arrivals.append(t)
        if g(msg, "I") not in (None, 0) and typ in ("GPS", "IMU", "BAT", "VIBE"):
            continue
        if typ == "ATT":
            rec.add("roll", t, g(msg, "Roll")); rec.add("pitch", t, g(msg, "Pitch")); rec.add("yaw", t, g(msg, "Yaw"))
            rec.add("roll_sp", t, g(msg, "DesRoll")); rec.add("pitch_sp", t, g(msg, "DesPitch"))
        elif typ == "RATE":
            for src, dst in (("R", "rollspeed"), ("P", "pitchspeed"), ("Y", "yawspeed")):
                rec.add(dst, t, g(msg, src))
        elif typ == "GPS":
            rec.add("gps_fix", t, g(msg, "Status")); rec.add("sats", t, g(msg, "NSats")); rec.add("hdop", t, g(msg, "HDop"))
            rec.add("gs", t, g(msg, "Spd"))
            if g(msg, "Lat") and "POS" not in rec.info:
                rec.add("lat", t, msg.Lat); rec.add("lon", t, msg.Lng); rec.add("alt", t, g(msg, "Alt"))
        elif typ == "POS":
            rec.info["POS"] = True
            rec.add("lat", t, g(msg, "Lat")); rec.add("lon", t, g(msg, "Lng")); rec.add("alt", t, g(msg, "Alt"))
            rec.add("rel_alt", t, g(msg, "RelHomeAlt"))
        elif typ == "CTUN":
            if g(msg, "CRt") is not None:
                rec.add("climb", t, msg.CRt / 100)
            if "POS" not in rec.info and g(msg, "Alt") is not None:
                rec.add("rel_alt", t, msg.Alt)
        elif typ == "BAT":
            rec.add("voltage", t, g(msg, "Volt")); rec.add("current", t, g(msg, "Curr")); rec.add("mah", t, g(msg, "CurrTot"))
            if g(msg, "Temp"):
                rec.add("batt_temp", t, msg.Temp)
        elif typ == "IMU":
            if g(msg, "AccX") is not None:
                rec.acc.append((t, msg.AccX, msg.AccY, msg.AccZ))
        elif typ == "VIBE":
            rec.add("vibe_x", t, g(msg, "VibeX")); rec.add("vibe_y", t, g(msg, "VibeY")); rec.add("vibe_z", t, g(msg, "VibeZ"))
            rec.add("clip", t, g(msg, "Clip") if g(msg, "Clip") is not None else (g(msg, "Clip0") or 0) + (g(msg, "Clip1") or 0) + (g(msg, "Clip2") or 0))
        elif typ == "RCOU":
            for i in range(1, 9):
                v = g(msg, f"C{i}")
                if v:
                    rec.add(f"m{i}", t, v)
        elif typ == "MODE":
            rec.mode(t, str(getattr(mlog, "flightmode", None) or g(msg, "Mode")))
        elif typ == "MSG":
            txt = str(g(msg, "Message") or "")
            low = txt.lower()
            rec.text(t, txt, 3 if any(k in low for k in ("failsafe", "error", "crash", "ekf", "fail")) else 6)
    _close(mlog)
    rec.info["autopilot"] = 3
    return rec


def parse_ulog(path: Path) -> Recorder:
    from pyulog import ULog

    rec = Recorder()
    ulog = ULog(str(path))
    sets = {}
    for d in ulog.data_list:
        if d.multi_id == 0 or d.name not in sets:
            sets.setdefault(d.name, d.data)
    ts = lambda d: d["timestamp"] / 1e6  # noqa: E731

    def col(d, *names):
        for nm in names:
            if nm in d:
                return d[nm]
        return None

    if (d := sets.get("vehicle_attitude")) is not None:
        r, p, y = quat_to_euler(d["q[0]"], d["q[1]"], d["q[2]"], d["q[3]"])
        t = ts(d)
        rec.add_array("roll", t, r); rec.add_array("pitch", t, p); rec.add_array("yaw", t, y % 360)
        rec.arrivals.extend(t[:: max(1, len(t) // 20000)].tolist())
    if (d := sets.get("vehicle_attitude_setpoint")) is not None:
        if "q_d[0]" in d:
            r, p, _ = quat_to_euler(d["q_d[0]"], d["q_d[1]"], d["q_d[2]"], d["q_d[3]"])
        else:
            r, p = np.degrees(d["roll_body"]), np.degrees(d["pitch_body"])
        rec.add_array("roll_sp", ts(d), r); rec.add_array("pitch_sp", ts(d), p)
    if (d := sets.get("vehicle_angular_velocity")) is not None:
        for i, nm in enumerate(("rollspeed", "pitchspeed", "yawspeed")):
            rec.add_array(nm, ts(d), np.degrees(d[f"xyz[{i}]"]))
    if (d := sets.get("vehicle_global_position")) is not None:
        rec.add_array("lat", ts(d), d["lat"]); rec.add_array("lon", ts(d), d["lon"]); rec.add_array("alt", ts(d), d["alt"])
    if (d := sets.get("vehicle_local_position")) is not None:
        rec.add_array("gs", ts(d), np.hypot(d["vx"], d["vy"])); rec.add_array("climb", ts(d), -d["vz"]); rec.add_array("rel_alt", ts(d), -d["z"])
    if (d := sets.get("battery_status")) is not None:
        v = col(d, "voltage_v", "voltage_filtered_v")
        i = col(d, "current_a", "current_filtered_a")
        if v is not None:
            rec.add_array("voltage", ts(d), v)
        if i is not None:
            rec.add_array("current", ts(d), np.where(i < 0, np.nan, i))
        if "remaining" in d:
            rec.add_array("remaining", ts(d), d["remaining"] * 100)
        if "discharged_mah" in d:
            rec.add_array("mah", ts(d), d["discharged_mah"])
        if "temperature" in d:
            rec.add_array("batt_temp", ts(d), np.where(d["temperature"] == 0, np.nan, d["temperature"]))
    if (d := sets.get("sensor_combined")) is not None:
        t = ts(d)
        a = np.column_stack([t, d["accelerometer_m_s2[0]"], d["accelerometer_m_s2[1]"], d["accelerometer_m_s2[2]"]])
        rec.acc = a[np.isfinite(a).all(axis=1)].tolist()
    d = sets.get("vehicle_gps_position")
    if d is None:
        d = sets.get("sensor_gps")
    if d is not None:
        rec.add_array("gps_fix", ts(d), d["fix_type"]); rec.add_array("sats", ts(d), d["satellites_used"])
        if "hdop" in d:
            rec.add_array("hdop", ts(d), d["hdop"])
    if (d := sets.get("actuator_outputs")) is not None:
        for i in range(8):
            if f"output[{i}]" in d and np.nanmax(d[f"output[{i}]"]) > 0:
                rec.add_array(f"m{i + 1}", ts(d), d[f"output[{i}]"])
    if (d := sets.get("input_rc")) is not None and "rssi" in d:
        rec.add_array("rssi", ts(d), d["rssi"])
    if (d := sets.get("cpuload")) is not None:
        rec.add_array("load", ts(d), d["load"] * 100)
    if (d := sets.get("vehicle_status")) is not None and "nav_state" in d:
        for t, ns in zip(ts(d), d["nav_state"]):
            rec.mode(float(t), PX4_NAV.get(int(ns), f"NAV_STATE {int(ns)}"))
    for lm in ulog.logged_messages:
        lvl = lm.log_level
        sev = int(lvl) - 48 if isinstance(lvl, int) and lvl >= 48 else int(lvl) if isinstance(lvl, int) else 6
        rec.text(lm.timestamp / 1e6, lm.message, sev)
    rec.info["autopilot"] = 12
    return rec


ALIASES = {
    "lat": ["lat", "latitude"], "lon": ["lon", "lng", "long", "longitude"], "alt": ["alt", "altitude", "alt_amsl", "altitude_amsl"],
    "rel_alt": ["rel_alt", "relative_alt", "height", "alt_rel", "agl"], "gs": ["gs", "groundspeed", "ground_speed", "speed"],
    "climb": ["climb", "vertical_speed", "vspeed", "climb_rate", "vs"], "roll": ["roll"], "pitch": ["pitch"], "yaw": ["yaw", "heading"],
    "rollspeed": ["rollspeed", "roll_rate", "gyro_x", "p"], "pitchspeed": ["pitchspeed", "pitch_rate", "gyro_y", "q"],
    "yawspeed": ["yawspeed", "yaw_rate", "gyro_z", "r"], "roll_sp": ["roll_sp", "roll_setpoint", "des_roll", "desroll"],
    "pitch_sp": ["pitch_sp", "pitch_setpoint", "des_pitch", "despitch"], "ax": ["ax", "acc_x", "accx", "accel_x"],
    "ay": ["ay", "acc_y", "accy", "accel_y"], "az": ["az", "acc_z", "accz", "accel_z"],
    "voltage": ["voltage", "volt", "battery_voltage", "vbat", "v"], "current": ["current", "curr", "battery_current", "amps", "i"],
    "batt_temp": ["batt_temp", "battery_temp", "battery_temperature"], "remaining": ["remaining", "battery_remaining", "soc"],
    "mah": ["mah", "consumed_mah", "currtot"], "gps_fix": ["gps_fix", "fix_type", "fix"], "sats": ["sats", "satellites", "nsats", "num_sats"],
    "hdop": ["hdop"], "rssi": ["rssi"], "xtrack": ["xtrack", "cross_track_error", "xtrack_error"], "load": ["load", "cpu_load"],
    **{f"m{i}": [f"m{i}", f"motor{i}", f"motor_{i}", f"pwm{i}", f"c{i}"] for i in range(1, 9)},
}
TIME_COLS = ["t", "time", "time_s", "timestamp", "time_us", "timeus", "time_ms", "timestamp_us", "timestamp_ms", "seconds"]


def parse_table(df) -> Recorder:
    cols = {str(c).strip().lower(): c for c in df.columns}
    tcol = next((cols[c] for c in TIME_COLS if c in cols), None)
    if tcol is None:
        raise ValueError("No time column found. Expected one of: " + ", ".join(TIME_COLS))
    import pandas as pd

    t = pd.to_numeric(df[tcol], errors="coerce").to_numpy(float)
    name = str(tcol).lower()
    dt = np.nanmedian(np.diff(t)) if len(t) > 2 else 1.0
    if "us" in name or dt >= 1000:
        t = t / 1e6
    elif "ms" in name or (dt >= 5 and np.nanmax(t) - np.nanmin(t) > 5000):
        t = t / 1e3
    rec = Recorder()
    found = []
    for ch, names in ALIASES.items():
        src = next((cols[n] for n in names if n in cols), None)
        if src is None:
            src = next((cols[f"{n}_{sfx}"] for n in names for sfx in ("deg", "rad", "m", "v", "a") if f"{n}_{sfx}" in cols), None)
        if src is None:
            continue
        v = pd.to_numeric(df[src], errors="coerce").to_numpy(float)
        if str(src).strip().lower().endswith("_rad"):  # angles are degrees unless the column says otherwise; never guessed from magnitude
            v = np.degrees(v)
        if ch in ("ax", "ay", "az"):
            continue
        rec.add_array(ch, t, v)
        found.append(ch)
    if all(n in cols or any(a in cols for a in ALIASES[n]) for n in ("ax", "ay", "az")):
        a = [pd.to_numeric(df[next(cols[x] for x in ALIASES[n] if x in cols)], errors="coerce").to_numpy(float) for n in ("ax", "ay", "az")]
        arr = np.column_stack([t, *a])
        rec.acc = arr[np.isfinite(arr).all(axis=1)].tolist()
    mode_col = next((cols[c] for c in ("mode", "flight_mode", "flightmode") if c in cols), None)
    if mode_col is not None:
        for ti, mv in zip(t, df[mode_col].astype(str)):
            if np.isfinite(ti) and mv and mv != "nan":
                rec.mode(float(ti), mv)
    if not found:
        raise ValueError("No recognised telemetry columns. Recognised names include: lat, lon, rel_alt, roll, pitch, yaw, voltage, current, gs, sats, hdop.")
    rec.arrivals = t[np.isfinite(t)].tolist()
    return rec


def parse_csv(path: Path) -> Recorder:
    import pandas as pd

    return parse_table(pd.read_csv(path, sep=None, engine="python", comment="#"))


def parse_json(path: Path) -> Recorder:
    import pandas as pd

    obj = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if isinstance(obj, dict) and isinstance(obj.get("channels"), dict):
        obj = obj["channels"]
    if isinstance(obj, dict) and isinstance(obj.get("samples"), list):
        obj = obj["samples"]
    try:
        df = pd.DataFrame(obj)
    except ValueError as e:
        raise ValueError(f"JSON must be a list of sample objects or an object of equal-length channel arrays ({e}).")
    return parse_table(df)


PARSERS = {"ulog": parse_ulog, "bin": parse_bin, "tlog": parse_tlog, "csv": parse_csv, "json": parse_json}
EXT = {".ulg": "ulog", ".ulog": "ulog", ".bin": "bin", ".tlog": "tlog", ".mavlink": "tlog", ".rlog": "tlog", ".csv": "csv", ".json": "json"}
FORMAT_LABEL = {"ulog": "PX4 ULog", "bin": "ArduPilot BIN", "tlog": "MAVLink telemetry log", "csv": "CSV", "json": "JSON",
                "simulation": "Internal kinematic simulation"}


# ───────────── analysis ─────────────
def haversine(lat1, lon1, lat2, lon2):
    r = 6371000.0
    p1, p2 = np.radians(lat1), np.radians(lat2)
    a = np.sin((p2 - p1) / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(np.radians(lon2 - lon1) / 2) ** 2
    return 2 * r * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def to_local(lat, lon, lat0, lon0):
    """Equirectangular projection to metres north / east of a reference point."""
    n = (np.asarray(lat) - lat0) * 111_320.0
    e = (np.asarray(lon) - lon0) * 111_320.0 * math.cos(math.radians(lat0))
    return n, e


def cross_track(lat, lon, wps: list) -> np.ndarray | None:
    """Distance from each position to the nearest leg of the planned path (metres)."""
    if len(wps) < 2:
        return None
    lat0, lon0 = wps[0]["lat"], wps[0]["lon"]
    pn, pe = to_local(lat, lon, lat0, lon0)
    wn, we = to_local([w["lat"] for w in wps], [w["lon"] for w in wps], lat0, lon0)
    best = np.full(len(pn), np.inf)
    for i in range(len(wps) - 1):
        an, ae, bn, be = wn[i], we[i], wn[i + 1], we[i + 1]
        dn, de = bn - an, be - ae
        l2 = dn * dn + de * de
        if l2 < 1e-6:
            continue
        u = np.clip(((pn - an) * dn + (pe - ae) * de) / l2, 0, 1)
        best = np.minimum(best, np.hypot(pn - (an + u * dn), pe - (ae + u * de)))
    return best


def _rms(x):
    x = x[np.isfinite(x)]
    return float(np.sqrt(np.mean(x * x))) if len(x) else None


def _hp(x, n):
    """High-pass by subtracting a centred moving average of n samples."""
    if len(x) < n * 2:
        return x - np.nanmean(x)
    k = np.ones(n) / n
    filled = np.where(np.isfinite(x), x, np.nanmean(x))
    return filled - np.convolve(filled, k, mode="same")


def compute_metrics(norm: dict, mission_wps: list | None = None) -> dict:
    d = norm["data"]
    t = d["t"]
    dt = float(t[1] - t[0]) if len(t) > 1 else 0.1
    has = lambda k: k in d and np.isfinite(d[k]).any()  # noqa: E731
    mt: dict = {"duration_s": round(float(t[-1]), 1)}

    def put(key, val, nd=2):
        if val is not None and np.isfinite(val):
            mt[key] = round(float(val), nd)

    if has("rel_alt"):
        air = np.nan_to_num(d["rel_alt"], nan=0.0) > 1.0
    elif has("gs"):
        air = np.nan_to_num(d["gs"], nan=0.0) > 1.0
    else:
        air = np.ones(len(t), bool)
    if not air.any():
        air = np.ones(len(t), bool)
        mt["_no_flight_detected"] = True
    put("flight_time_s", air.sum() * dt, 1)
    if has("rel_alt"):
        put("max_rel_alt_m", np.nanmax(d["rel_alt"]))
    if has("gs"):
        put("max_gs_ms", np.nanmax(d["gs"]))
    if has("climb"):
        put("max_climb_ms", np.nanmax(d["climb"])); put("max_descent_ms", -np.nanmin(d["climb"]))
    if has("lat") and has("lon"):
        la, lo = d["lat"], d["lon"]
        ok = np.isfinite(la) & np.isfinite(lo)
        seg = haversine(la[:-1], lo[:-1], la[1:], lo[1:])
        seg = np.where(ok[:-1] & ok[1:] & air[:-1], seg, 0.0)
        put("distance_m", seg.sum(), 0)
        speed = seg / dt
        ref = np.nan_to_num(d["gs"][:-1], nan=0.0) if has("gs") else np.zeros(len(seg))
        mt["pos_jump_count"] = int(np.sum(speed > np.maximum(3 * ref + 10, 30)))
        if mission_wps:
            xt = cross_track(la[ok & air], lo[ok & air], mission_wps)
            if xt is not None and len(xt):
                put("xtrack_rms_m", _rms(xt)); put("xtrack_max_m", np.max(xt))
    if "xtrack_rms_m" not in mt and has("xtrack"):
        put("xtrack_rms_m", _rms(d["xtrack"][air])); put("xtrack_max_m", np.nanmax(np.abs(d["xtrack"][air])))

    # attitude
    if has("roll") and has("pitch"):
        r, p = d["roll"], d["pitch"]
        put("roll_max_deg", np.nanmax(np.abs(r[air]))); put("pitch_max_deg", np.nanmax(np.abs(p[air])))
        n = max(3, int(round(1.0 / dt)))
        osc = np.hypot(_hp(r, n), _hp(p, n))[air]
        put("att_osc_rms_deg", _rms(osc), 3)
        slow = air & (np.nan_to_num(d["gs"], nan=99.0) < 1.0) if has("gs") else np.zeros(len(t), bool)
        if has("climb"):
            slow &= np.abs(np.nan_to_num(d["climb"], nan=99.0)) < 0.5
        if slow.sum() * dt >= 5:
            put("hover_att_std_deg", math.hypot(np.nanstd(r[slow]), np.nanstd(p[slow])), 3)
            if has("rel_alt"):
                put("hover_alt_std_m", np.nanstd(d["rel_alt"][slow]), 3)
            if has("lat"):
                pn, pe = to_local(d["lat"][slow], d["lon"][slow], np.nanmean(d["lat"][slow]), np.nanmean(d["lon"][slow]))
                put("hover_pos_std_m", math.hypot(np.nanstd(pn), np.nanstd(pe)), 3)
        if has("roll_sp"):
            put("roll_track_rms_deg", _rms((r - d["roll_sp"])[air]), 3)
        if has("pitch_sp"):
            put("pitch_track_rms_deg", _rms((p - d["pitch_sp"])[air]), 3)
    rates = [np.abs(d[k][air]) for k in ("rollspeed", "pitchspeed", "yawspeed") if has(k)]
    if rates:
        put("rate_max_dps", max(np.nanmax(x) for x in rates), 1)
    if has("load"):
        put("load_max_pct", np.nanmax(d["load"]), 1)

    # motors
    mk = [k for k in (f"m{i}" for i in range(1, 9)) if has(k)]
    if len(mk) >= 3:
        mm = np.array([np.nanmean(d[k][air]) for k in mk])
        span = np.nanmax([np.nanmax(d[k]) for k in mk])
        lo_, hi_ = (1000.0, 2000.0) if span > 100 else (0.0, 1.0)
        norm_m = (mm - lo_) / (hi_ - lo_)
        if np.nanmean(norm_m) > 0.02:
            put("motor_imbalance_pct", 100 * np.nanmax(np.abs(norm_m - np.nanmean(norm_m))) / np.nanmean(norm_m), 1)
        sat = np.zeros(len(t), bool)
        for k in mk:
            sat |= np.nan_to_num(d[k], nan=0.0) >= lo_ + 0.97 * (hi_ - lo_)
        put("motor_saturation_pct", 100 * (sat & air).sum() / max(1, air.sum()), 2)

    # vibration from native-rate accelerometer data
    if "acc_raw" in d and len(d["acc_raw"]) > 200:
        a = d["acc_raw"]
        at = a[:, 0]
        keep = np.interp(at, t, air.astype(float)) > 0.5
        a, at = a[keep], at[keep]
        if len(a) > 200:
            fs = 1.0 / np.median(np.diff(at)) if np.median(np.diff(at)) > 0 else 0
            mt["_acc_rate_hz"] = round(fs, 1)
            if fs >= 20:
                n = max(3, int(fs * 0.5))
                hp = np.column_stack([_hp(a[:, i], n) for i in (1, 2, 3)])
                rms = np.sqrt(np.mean(hp * hp, axis=0))
                put("vib_rms_ms2", rms.max(), 3)
                mt["_vib_axes"] = [round(float(x), 3) for x in rms]
                try:
                    from scipy.signal import welch

                    f, pxx = welch(hp[:, int(np.argmax(rms))], fs=fs, nperseg=min(1024, len(hp)))
                    band = f >= 5
                    if band.any():
                        put("vib_peak_hz", f[band][np.argmax(pxx[band])], 1)
                        mt["_vib_spectrum"] = {"f": [round(float(x), 1) for x in f[band][:200]], "p": [float(x) for x in pxx[band][:200]]}
                except Exception:
                    pass
    vk = [k for k in ("vibe_x", "vibe_y", "vibe_z") if has(k)]
    if vk:
        put("vibe_max_ms2", max(np.nanmax(d[k]) for k in vk))
    if has("clip"):
        c = d["clip"][np.isfinite(d["clip"])]
        mt["clip_count"] = int(c[-1] - c[0]) if len(c) else 0

    # navigation
    if has("sats"):
        put("sats_min", np.nanmin(d["sats"][air]), 0); put("sats_mean", np.nanmean(d["sats"][air]), 1)
    if has("hdop"):
        put("hdop_max", np.nanmax(d["hdop"][air])); put("hdop_mean", np.nanmean(d["hdop"][air]))
    if has("gps_fix"):
        fix = np.nan_to_num(d["gps_fix"], nan=3) >= 3
        mt["gps_fix_loss_count"] = int(np.sum(fix[:-1] & ~fix[1:] & air[1:]))

    # power
    if has("voltage"):
        v = d["voltage"]
        put("v_min", np.nanmin(v[air])); put("v_mean", np.nanmean(v[air]))
        v0 = v[np.isfinite(v)][: max(1, int(5 / dt))]
        put("v_sag_v", float(np.nanmean(v0)) - float(np.nanmin(v[air])))
    if has("current"):
        i = d["current"]
        put("i_max", np.nanmax(i)); put("i_mean", np.nanmean(i[air]))
        if has("mah"):
            mh = d["mah"][np.isfinite(d["mah"])]
            put("mah_used", mh[-1] - mh[0], 0)
        else:
            put("mah_used", np.nansum(i) * dt / 3.6, 0)
        if has("voltage"):
            pw = d["voltage"] * i
            put("energy_wh", np.nansum(pw) * dt / 3600); put("power_mean_w", np.nanmean(pw[air]), 1); put("power_max_w", np.nanmax(pw), 1)
            ok = np.isfinite(v) & np.isfinite(i) & air
            if ok.sum() > 50 and np.nanpercentile(i[ok], 95) - np.nanpercentile(i[ok], 5) > 3:
                tt = t[ok]
                # remove slow discharge trend so the fit sees load-induced sag only
                vv = v[ok] - np.polyval(np.polyfit(tt, v[ok], 1), tt)
                ii = i[ok] - np.polyval(np.polyfit(tt, i[ok], 1), tt)
                slope = float(np.sum(vv * ii) / np.sum(ii * ii)) if np.sum(ii * ii) > 0 else 0
                if slope < 0:
                    put("r_internal_mohm", -slope * 1000, 1)
    if has("batt_temp"):
        put("batt_temp_max_c", np.nanmax(d["batt_temp"]), 1)
    if has("remaining"):
        put("remaining_min_pct", np.nanmin(d["remaining"]), 0)

    # communications
    arr = norm.get("arrivals")
    if arr is not None and len(arr) > 10:
        gaps = np.diff(arr)
        big = gaps[gaps > 2.0]
        mt["link_gap_count"] = int(len(big))
        put("link_gap_max_s", float(gaps.max()), 1)
        mt["_gaps"] = [{"t": round(float(arr[i]), 1), "s": round(float(gaps[i]), 1)} for i in np.where(gaps > 2.0)[0][:50]]
    if has("rssi"):
        put("rssi_min", np.nanmin(d["rssi"]), 0)

    # software / flight controller events
    ev = norm.get("events", [])
    mt["mode_changes"] = max(0, sum(1 for e in ev if e["type"] == "mode") - 1)
    texts = [e for e in ev if e["type"] == "text"]
    mt["failsafe_events"] = sum(1 for e in texts if "failsafe" in e["text"].lower())
    mt["error_events"] = sum(1 for e in texts if e["severity"] in ("critical", "warning"))
    mt["_channels"] = sorted(k for k in d if k not in ("t", "acc_raw") and np.isfinite(d[k]).any())
    return mt


def observations(mt: dict, cells: int | None = None) -> list:
    """Rule-based engineering observations. Facts are measured values; causes are stated as hypotheses to verify."""
    out = []

    def add(level, area, fact, hypothesis=None, rec=None, metric=None):
        out.append({"level": level, "area": area, "fact": fact, "hypothesis": hypothesis, "recommendation": rec, "metric": metric,
                    "value": mt.get(metric) if metric else None})

    g = mt.get
    if g("_no_flight_detected"):
        add("warning", "General", "No airborne segment was detected in this log (height above home never exceeded 1 m).",
            None, "Confirm this is the intended log before using it as flight-test evidence.")
    if (v := g("vib_rms_ms2")) is not None:
        if v > 6:
            add("critical", "Vibration", f"Accelerometer vibration is {v} m/s² RMS on the worst axis (dominant {g('vib_peak_hz', '?')} Hz).",
                "Possible causes: propeller imbalance or damage, loose motor mount, hard-mounted flight controller.",
                "Inspect propellers and motor mounts; check flight-controller isolation; repeat the hover test.", "vib_rms_ms2")
        elif v > 3:
            add("warning", "Vibration", f"Accelerometer vibration is elevated: {v} m/s² RMS (dominant {g('vib_peak_hz', '?')} Hz).",
                "May indicate early propeller or bearing wear.", "Balance propellers and trend this value over the next flights.", "vib_rms_ms2")
    if (v := g("vibe_max_ms2")) is not None and v > 30:
        add("critical" if v > 60 else "warning", "Vibration", f"Autopilot-reported vibration peaked at {v} m/s².",
            "Vibration at this level can degrade the state estimator.", "Investigate before further flight testing.", "vibe_max_ms2")
    if g("clip_count"):
        add("warning", "Vibration", f"{g('clip_count')} accelerometer clipping events were logged.", "Clipping indicates shocks beyond the IMU range.",
            "Check for hard landings, loose components or propeller strikes.", "clip_count")
    for axis in ("roll", "pitch"):
        if (v := g(f"{axis}_track_rms_deg")) is not None and v > 3:
            add("critical" if v > 6 else "warning", "Flight-controller performance", f"{axis.capitalize()} tracking error is {v}° RMS.",
                "Possible causes: attitude controller tuning, actuator saturation, or a centre-of-gravity shift.",
                "Review rate / attitude controller gains against the current mass and inertia.", f"{axis}_track_rms_deg")
    if (v := g("att_osc_rms_deg")) is not None and v > 2:
        add("warning", "Flight stability", f"Attitude oscillation above 1 Hz is {v}° RMS.", "May indicate over-tuned gains or structural resonance.",
            "Compare with vibration spectrum; review controller gains.", "att_osc_rms_deg")
    if (v := g("motor_saturation_pct")) is not None and v > 2:
        add("critical" if v > 10 else "warning", "Flight-controller performance", f"A motor output was saturated for {v}% of the airborne time.",
            "Thrust margin may be insufficient at this take-off mass, or one motor / propeller is under-performing.",
            "Check thrust-to-weight for the recorded configuration; inspect the highest-output motor.", "motor_saturation_pct")
    if (v := g("motor_imbalance_pct")) is not None and v > 15:
        add("warning", "Flight-controller performance", f"Mean motor outputs differ by up to {v}% from the average.",
            "Possible causes: centre-of-gravity offset, a weak motor / ESC, or a damaged propeller.",
            "Check the centre of gravity and compare individual motor outputs in hover.", "motor_imbalance_pct")
    if (v := g("sats_min")) is not None and v < 8:
        add("critical" if v < 6 else "warning", "Navigation accuracy", f"Satellite count dropped to {int(v)} in flight.",
            "Possible causes: sky obstruction, antenna placement, or RF interference from onboard electronics.",
            "Review GNSS antenna placement and repeat with onboard transmitters disabled one at a time.", "sats_min")
    if (v := g("hdop_max")) is not None and v > 2:
        add("warning", "Navigation accuracy", f"HDOP reached {v} in flight.", None, "Treat position-hold and mission-accuracy results from this flight with caution.", "hdop_max")
    if g("gps_fix_loss_count"):
        add("critical", "Navigation accuracy", f"3D GNSS fix was lost {g('gps_fix_loss_count')} time(s) while airborne.", None,
            "Do not use this flight as navigation-accuracy evidence; investigate the GNSS installation.", "gps_fix_loss_count")
    if g("pos_jump_count"):
        add("warning", "Navigation accuracy", f"{g('pos_jump_count')} position jump(s) inconsistent with the reported ground speed.",
            "May be GNSS glitches or estimator resets.", "Inspect the position trace around the jumps.", "pos_jump_count")
    if (v := g("xtrack_max_m")) is not None and v > 5:
        add("warning", "Mission execution", f"Maximum cross-track error was {v} m (RMS {g('xtrack_rms_m', '?')} m).",
            "Possible causes: wind beyond the tuned envelope, acceptance radius, or navigation controller gains.",
            "Compare against the wind recorded for the test and the mission acceptance radius.", "xtrack_max_m")
    if (v := g("v_min")) is not None and cells:
        pc = v / cells
        if pc < 3.5:
            add("critical" if pc < 3.3 else "warning", "Battery", f"Minimum voltage was {v} V ({pc:.2f} V per cell on a {cells}S pack).",
                "Pack may be undersized for the load, aged, or the flight exceeded the planned endurance.",
                "Check pack internal resistance and cycle count; review the low-battery failsafe threshold.", "v_min")
    if (v := g("remaining_min_pct")) is not None and v < 20:
        add("critical" if v < 10 else "warning", "Battery", f"Battery remaining fell to {int(v)}%.", None,
            "Planned missions should land with at least 20% reserve.", "remaining_min_pct")
    if (v := g("batt_temp_max_c")) is not None and v > 55:
        add("critical" if v > 65 else "warning", "Battery", f"Battery temperature reached {v} °C.", None, "Inspect the pack before reuse; review discharge current against the pack rating.", "batt_temp_max_c")
    if g("link_gap_count"):
        add("critical" if (g("link_gap_max_s") or 0) > 10 else "warning", "Communications",
            f"{g('link_gap_count')} telemetry interruption(s) longer than 2 s; the longest lasted {g('link_gap_max_s')} s.",
            "Possible causes: range, antenna masking by the airframe, or interference.",
            "Correlate the gaps with aircraft position and attitude; verify link-loss failsafe behaviour.", "link_gap_count")
    if g("failsafe_events"):
        add("critical", "Software", f"{g('failsafe_events')} failsafe message(s) were logged.", None, "Review the event timeline and the failsafe configuration.", "failsafe_events")
    elif (g("error_events") or 0) > 0:
        add("warning", "Software", f"{g('error_events')} warning / error message(s) were logged by the autopilot.", None, "Review the event timeline.", "error_events")
    if (v := g("load_max_pct")) is not None and v > 80:
        add("warning", "Software", f"Autopilot CPU load peaked at {v}%.", None, "Check logging rates and companion-computer traffic.", "load_max_pct")
    if not out:
        add("info", "General", "No rule-based anomalies were detected in the channels available in this log.", None,
            "Absence of findings is limited to the channels present; see the channel list.")
    return out


def save_norm(norm: dict, path: Path) -> None:
    np.savez_compressed(path, **{k: np.asarray(v) for k, v in norm["data"].items()})


def load_norm(path: Path) -> dict:
    with np.load(path) as z:
        return {k: z[k] for k in z.files}


def series(data: dict, channels: list | None = None, max_points: int = 1500) -> dict:
    t = data["t"]
    step = max(1, int(math.ceil(len(t) / max_points)))
    keys = [k for k in data if k not in ("t", "acc_raw") and (not channels or k in channels)]
    out = {"t": [round(float(x), 2) for x in t[::step]]}
    for k in keys:
        y = data[k][::step]
        if np.isfinite(y).any():
            out[k] = [None if not np.isfinite(x) else round(float(x), 6 if k in ("lat", "lon") else 3) for x in y]
    return out
