"""Runtime configuration. Everything is local to the workstation."""
import os
import sys
from pathlib import Path

APP_NAME = "AEROS OPS PRO"
VERSION = "1.0.0"

_HERE = Path(__file__).resolve().parent
_ROOT = _HERE.parent.parent  # aeros_ops/


def _frozen_base() -> Path:
    return Path(getattr(sys, "_MEIPASS", _HERE))


DATA_DIR = Path(os.environ.get("AEROS_DATA_DIR") or (_ROOT / "data")).resolve()
STATIC_DIR = Path(
    os.environ.get("AEROS_STATIC_DIR")
    or ((_frozen_base() / "web") if getattr(sys, "frozen", False) else (_ROOT / "frontend" / "dist"))
)
DB_URL = os.environ.get("AEROS_DB_URL") or f"sqlite:///{(DATA_DIR / 'aeros.db').as_posix()}"

BROWSER = os.environ.get("AEROS_BROWSER") == "1"  # Pyodide edition: no threads, sockets or OS services
PBKDF2_ITER = int(os.environ.get("AEROS_PBKDF2_ITER", "310000"))

SUBDIRS = ["attachments", "flightlogs", "recordings", "reports", "backups"]


def ensure_dirs() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for s in SUBDIRS:
        (DATA_DIR / s).mkdir(exist_ok=True)


def sub(name: str) -> Path:
    p = DATA_DIR / name
    p.mkdir(parents=True, exist_ok=True)
    return p
