"""Professional reporting: thirteen engineering documents rendered to PDF, Excel and CSV from one document model.

Every report carries document number, revision, creation date, author, aircraft ID, configuration version and the
applicable approvals. Reports are built only from recorded data; empty sections say so explicitly.
"""
import csv
import io
from pathlib import Path

from fastapi import APIRouter, Body, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import analysis, approvals as ap, config, fleet, maint, models as m, ops, testing, training
from .core import audit, current_user, get_setting, internal_user, to_dict, user_names
from .db import get_db, utcnow

router = APIRouter(prefix="/api")

TYPES = {
    "aircraft_config": ("Aircraft Configuration Report", "aircraft"),
    "hardware_integration": ("Hardware Integration Report", "aircraft"),
    "campaign": ("Flight-Test Campaign Report", "campaigns"),
    "test_card": ("Test Card Report", "test_cards"),
    "flight_performance": ("Flight Performance Report", "flight_logs"),
    "telemetry_analysis": ("Telemetry Analysis Report", "flight_logs"),
    "maintenance": ("Maintenance Report", "aircraft"),
    "reliability": ("Reliability Report", None),
    "deployment": ("Field Deployment Report", "deployments"),
    "demonstration": ("Customer Demonstration Report", "demonstrations"),
    "training": ("Training Completion Report", "users"),
    "readiness": ("Operational Readiness Report", None),
    "issue": ("Engineering Issue Report", "issues"),
}
YN = {True: "Yes", False: "No", None: "—"}


def _s(v) -> str:
    if v is None or v == "":
        return "—"
    if isinstance(v, bool):
        return YN[v]
    if isinstance(v, float):
        return f"{v:g}"
    return str(v)


def table(title, columns, rows):
    return {"title": title, "columns": columns, "rows": [[_s(c) for c in r] for r in rows]}


def kv(title, pairs):
    return table(title, ["Item", "Value"], pairs)


def section(heading, paragraphs=None, tables=None):
    return {"heading": heading, "paragraphs": [p for p in (paragraphs or []) if p], "tables": tables or []}


def _approvals(db, pairs) -> list:
    """pairs: [(subject_type, subject_id)] -> human-readable approved approvals."""
    names = user_names(db)
    out = []
    for st, sid in pairs:
        for a in db.scalars(select(m.Approval).where(m.Approval.subject_type == st, m.Approval.subject_id == sid, m.Approval.status == "approved").order_by(m.Approval.id)):
            out.append(f"{ap.KINDS[a.kind][0]}" + (f" [{a.tag}]" if a.tag else "") + f" — {names.get(a.decided_by, '?')}, {a.decided_at:%Y-%m-%d}"
                       + (f", valid to {a.expires_at:%Y-%m-%d}" if a.expires_at else ""))
    return out


def _ac_meta(db, ac):
    rev = fleet.current_revision(db, ac) if ac else None
    return (ac.code if ac else "—", f"Rev {rev.number} ({rev.label})" if rev else "No released configuration",
            ([("config_revision", rev.id)] if rev else []) + ([("aircraft", ac.id)] if ac else []))


def _need(db, model, sid, what):
    obj = db.get(model, sid or 0)
    if not obj:
        raise HTTPException(404, f"{what} not found")
    return obj


def _checks_table(checks):
    return table("Compatibility validation", ["Rule", "Result", "Detail"], [[c["rule"], c["level"].upper(), c["message"]] for c in checks])


# ───────────── builders ─────────────
def b_aircraft_config(db, u, sid):
    ac = _need(db, m.Aircraft, sid, "Aircraft")
    cfg = fleet.aircraft_config(ac.id, u, db)
    code, ver, appr = _ac_meta(db, ac)
    fields = {f["name"]: f["label"] for f in __import__("aeros.resources", fromlist=["x"]).fields_of(m.Aircraft)}
    secs = [section("Aircraft technical record", tables=[kv("Identification and configuration", [[fields.get(f, f), getattr(ac, f)] for f in fleet.AC_FIELDS]
                                                            + [["Flight hours", round(ac.flight_hours or 0, 2)], ["Flight cycles", ac.flight_cycles]])]),
            section("Installed components", ["No components are installed."] if not cfg["components"] else [], [
                table("Component list", ["ID", "Category", "Manufacturer", "Model", "Serial number", "Position", "Installed", "Config / FW", "Hours", "Cycles"],
                      [[c["code"], c["category"], c["manufacturer"], c["model"], c["serial_number"], c["position"], c["installed_date"], c["config_version"],
                        round(c["hours"] or 0, 2), c["cycles"]] for c in cfg["components"]])]),
            section("Configuration status", ["The live configuration differs from the released revision." if cfg["drift"] else
                                             "The live configuration matches the released revision." if cfg["current_revision"] else "No configuration revision has been released."],
                    [_checks_table(cfg["checks"])])]
    return ac.code, f"{ac.code} {ac.name}", code, ver, appr, secs


def b_hardware_integration(db, u, sid):
    ac = _need(db, m.Aircraft, sid, "Aircraft")
    cfg = fleet.aircraft_config(ac.id, u, db)
    code, ver, appr = _ac_meta(db, ac)
    revs = sorted(cfg["revisions"], key=lambda r: r["number"])
    secs = [section("Integration status", [f"Readiness state: {fleet.readiness(db, ac)['state']}."], [
        table("Configuration revisions", ["Rev", "Label", "Status", "Created", "By", "Released", "Errors", "Warnings", "Unverified", "Digest"],
              [[r["number"], r["label"], r["status"], r["created_at"][:10], r["created_by_name"], (r["released_at"] or "")[:10], r["summary"]["error"],
                r["summary"]["warning"], r["summary"]["unverified"], r["digest"][:12]] for r in revs])]),
            section("Hardware compatibility validation (live configuration)", tables=[_checks_table(cfg["checks"])])]
    if len(revs) >= 2:
        a, b = revs[-2], revs[-1]
        d = fleet.diff_snapshots(a["snapshot"], b["snapshot"])
        rows = [["Aircraft", x["field"], x["from"], x["to"]] for x in d["fields"]]
        rows += [[c["code"], "added", "", f"{c['category']} {c['model']}"] for c in d["added"]]
        rows += [[c["code"], "removed", f"{c['category']} {c['model']}", ""] for c in d["removed"]]
        rows += [[c["code"], x["field"], x["from"], x["to"]] for c in d["changed"] for x in c["changes"]]
        secs.append(section(f"Changes between revision {a['number']} and revision {b['number']}", [] if rows else ["No differences."],
                            [table("Revision differences", ["Item", "Field", "From", "To"], rows)] if rows else []))
    hist = []
    for c in cfg["components"]:
        for e in fleet.component_history(c["id"], u, db)["events"]:
            hist.append([e["ts"][:10], c["code"], e["event_type"], e["description"], e["user_name"]])
    secs.append(section("Integration and maintenance history of installed components", [] if hist else ["No component events recorded."],
                        [table("Component events", ["Date", "Component", "Event", "Description", "By"], sorted(hist, reverse=True))] if hist else []))
    return ac.code, f"{ac.code} {ac.name}", code, ver, appr, secs


def _card_tables(k):
    ev = k.get("evaluation") or {}
    crit = ev.get("criteria")
    if crit:
        rows = [[c["parameter"], f"{c['op']} {c['value']:g}" + (f" … {c['value2']:g}" if c.get("value2") is not None else ""), c["unit"], c["measured"],
                 (c["source"] or "").replace("flight_log:", "flight log #"), c["result"].upper(), c.get("deviation")] for c in crit]
    else:
        meas = k.get("measurements") or {}
        rows = [[c["parameter"], f"{c['op']} {c['value']}", c.get("unit"), (meas.get(c["id"]) or {}).get("value"), (meas.get(c["id"]) or {}).get("source"), "NOT EVALUATED", None]
                for c in k.get("criteria") or []]
    return table("Acceptance criteria and measured parameters", ["Parameter", "Criterion", "Unit", "Measured", "Source", "Result", "Deviation"], rows)


def b_campaign(db, u, sid):
    c = _need(db, m.Campaign, sid, "Campaign")
    d = testing.campaign_detail(c.id, u, db)
    ac = db.get(m.Aircraft, c.aircraft_id)
    code, ver, appr = _ac_meta(db, ac)
    cust = db.get(m.Customer, c.customer_id or 0)
    prj = db.get(m.Project, c.project_id or 0)
    tot = {s: sum(1 for k in d["cards"] if k["status"] == s) for s in ("pass", "fail", "incomplete", "executed", "planned", "deferred")}
    secs = [
        section("Campaign definition", tables=[kv("Campaign", [
            ["Campaign ID", c.code], ["Name", c.name], ["Customer", cust.name if cust else None], ["Project", prj.name if prj else None],
            ["Aircraft", f"{ac.code} {ac.name}"], ["Hardware revision under test", f"Rev {d['revision']['number']} ({d['revision']['label']})" if d["revision"] else None],
            ["Firmware version", c.firmware_version], ["Software release", c.software_release], ["Test location", c.location],
            ["Responsible engineer", d["responsible_engineer"]], ["Flight-test personnel", ", ".join(d["personnel_names"])],
            ["Test dates", f"{_s(c.start_date)} to {_s(c.end_date)}"], ["Weather conditions", c.weather], ["Environmental conditions", c.environment],
            ["Lifecycle stage", f"{c.stage + 1}/14 {d['stage_name']} ({c.status})"]])]),
        section("Objectives, procedures and success criteria", [f"Objectives: {_s(c.objectives)}", f"Procedures: {_s(c.procedures)}", f"Success criteria: {_s(c.success_criteria)}"]),
        section("Risk assessment", [] if d["risks"] else ["No hazards recorded."], [
            table("Hazard log", ["Hazard", "Cause", "Consequence", "L", "S", "Mitigation", "Residual L", "Residual S"],
                  [[r["hazard"], r["cause"], r["consequence"], r["likelihood"], r["severity"], r["mitigation"], r["residual_likelihood"], r["residual_severity"]] for r in d["risks"]])] if d["risks"] else []),
        section("Test results summary", [f"{len(d['cards'])} test cards: {tot['pass']} pass, {tot['fail']} fail, {tot['incomplete']} incomplete (evidence missing), "
                                         f"{tot['executed']} executed but not evaluated, {tot['planned']} not executed, {tot['deferred']} deferred."], [
            table("Test cards", ["Test ID", "Title", "Validation area", "Status", "Signed by", "Signed at", "Evidence files", "Flight log"],
                  [[k["code"], k["title"], k["category"], k["status"].upper(), k["signed_by_name"], (k["signed_at"] or "")[:16], k["attachments"],
                    f"#{k['flight_log_id']}" if k["flight_log_id"] else None] for k in d["cards"]]),
            table("Coverage by validation area", ["Validation area", "Cards", "Pass", "Fail", "Incomplete", "Not executed"],
                  [[x["category"], x["total"], x["pass"], x["fail"], x["incomplete"], x["planned"] + x["executed"]] for x in d["coverage"]])]),
    ]
    for k in d["cards"]:
        secs.append(section(f"{k['code']} — {k['title']} [{k['status'].upper()}]",
                            [f"Objective: {_s(k['objective'])}", f"Actual results: {_s(k['actual_results'])}", f"Observations: {_s(k['observations'])}",
                             f"Deviations: {_s(k['deviations'])}"] + [f"Not complete: {r}" for r in (k.get("evaluation") or {}).get("reasons", [])], [_card_tables(k)]))
    secs.append(section("Engineering issues raised", [] if d["issues"] else ["No issues were raised in this campaign."], [
        table("Issues", ["Issue ID", "Title", "Severity", "Status"], [[i["code"], i["title"], i["severity"], i["status"]] for i in d["issues"]])] if d["issues"] else []))
    secs.append(section("Flights", [] if d["flights"] else ["No flights are recorded against this campaign."], [
        table("Flight records", ["Flight ID", "Date", "Class", "Duration (s)", "Safety gates"],
              [[f["code"], f["date"][:16], f["source_class"], f["duration_s"], f["gate_status"]] for f in d["flights"]])] if d["flights"] else []))
    secs.append(section("Lifecycle history", tables=[table("Stage history", ["Stage", "Entered", "By", "Note"],
                                                           [[h["stage_name"], h["at"][:16], h["by_name"], h.get("note") or ("Completed" if h.get("complete") else "")] for h in d["stage_history"]])]))
    return c.code, f"{c.code} {c.name}", code, ver, appr + [("campaign", c.id)], secs


def b_test_card(db, u, sid):
    k = _need(db, m.TestCard, sid, "Test card")
    c = db.get(m.Campaign, k.campaign_id)
    ac = db.get(m.Aircraft, c.aircraft_id)
    code, ver, appr = _ac_meta(db, ac)
    d = testing.card_out(db, k)
    att = ap.attachments_of(db, "test_card", k.id)
    log = db.get(m.FlightLog, k.flight_log_id or 0)
    secs = [section("Test identification", tables=[kv("Test card", [["Test ID", k.code], ["Title", k.title], ["Campaign", f"{c.code} {c.name}"], ["Validation area", k.category],
                                                                     ["Status", k.status.upper()], ["Retest of", getattr(db.get(m.TestCard, k.retest_of_id or 0), "code", None)]])]),
            section("Definition", [f"Objective: {_s(k.objective)}", f"Aircraft configuration: {_s(k.aircraft_config)}", f"Preconditions: {_s(k.preconditions)}",
                                   f"Procedure: {_s(k.procedure)}", f"Expected results: {_s(k.expected_results)}"]),
            section("Results", [f"Actual results: {_s(k.actual_results)}", f"Observations: {_s(k.observations)}", f"Deviations: {_s(k.deviations)}"]
                    + [f"Not complete: {r}" for r in (k.evaluation or {}).get("reasons", [])], [_card_tables(d)]),
            section("Evidence", ([f"Linked flight log: {log.code} {log.name} ({log.source_class}, sha256 {_s(log.sha256)[:16]})"] if log else [])
                    + ([] if att or log else ["No evidence is attached."]),
                    [table("Evidence attachments", ["File", "Size (bytes)", "SHA-256", "Uploaded"], [[a.filename, a.size, a.sha256, f"{a.created_at:%Y-%m-%d %H:%M}"] for a in att])] if att else []),
            section("Engineer signature", [f"Signed by {d['signed_by_name']} on {k.signed_at:%Y-%m-%d %H:%M} UTC. Signature digest: {k.signature}" if k.signed_at
                                           else "This test card has not been signed."])]
    return k.code, f"{k.code} {k.title}", code, ver, appr, secs


def _log_sections(db, log, areas=None):
    d = analysis.log_out(db, log, True)
    mt = [x for x in d["metric_table"] if not areas or x["area"] in areas]
    obs = [o for o in d["observations"] if not areas or o["area"] in areas or o["area"] == "General"]
    secs = [section("Flight log", tables=[kv("Source", [["Log ID", log.code], ["Name", log.name], ["Data source", log.source_class.upper()], ["Format", d["format_label"]],
                                                         ["Original file", log.original_name], ["SHA-256", log.sha256], ["Duration (s)", log.duration_s],
                                                         ["Configuration at import", d["revision"]], ["Channels available", ", ".join(d["channels"])]])],
                    paragraphs=["THIS DATA IS FROM THE INTERNAL KINEMATIC SIMULATOR — IT IS NOT AIRCRAFT FLIGHT DATA." if log.source_class == "simulation" else
                                "This data is from a software-in-the-loop simulation, not a physical flight." if log.source_class == "sitl" else ""])]
    for area in sorted({x["area"] for x in mt}):
        secs.append(section(area, tables=[table(f"{area} metrics", ["Metric", "Value", "Unit"], [[x["label"], x["value"], x["unit"]] for x in mt if x["area"] == area])]))
    if d["missing_areas"] and not areas:
        secs.append(section("Not assessed", ["No data was available in this log to assess: " + ", ".join(d["missing_areas"]) + "."]))
    secs.append(section("Engineering observations", ["Facts are measured values from the log. Hypotheses are possible explanations that require verification."], [
        table("Observations", ["Level", "Area", "Fact (measured)", "Hypothesis (to verify)", "Recommendation"],
              [[o["level"].upper(), o["area"], o["fact"], o["hypothesis"], o["recommendation"]] for o in obs])]))
    return d, secs


def b_flight_performance(db, u, sid):
    log = _need(db, m.FlightLog, sid, "Flight log")
    ac = db.get(m.Aircraft, log.aircraft_id or 0)
    code, ver, appr = _ac_meta(db, ac)
    _, secs = _log_sections(db, log, {"General", "Flight stability", "Flight-controller performance", "Mission execution", "Power", "Battery"})
    return log.code, f"{log.code} {log.name}", code, ver, appr, secs


def b_telemetry_analysis(db, u, sid):
    log = _need(db, m.FlightLog, sid, "Flight log")
    ac = db.get(m.Aircraft, log.aircraft_id or 0)
    code, ver, appr = _ac_meta(db, ac)
    d, secs = _log_sections(db, log)
    ev = d["events"] or []
    secs.append(section("Event timeline", [] if ev else ["No events in the log."], [
        table("Events", ["t (s)", "Type", "Severity", "Text"], [[e["t"], e["type"], e["severity"], e["text"]] for e in ev[:300]])] if ev else []))
    return log.code, f"{log.code} {log.name}", code, ver, appr, secs


def b_maintenance(db, u, sid):
    ac = _need(db, m.Aircraft, sid, "Aircraft")
    d = maint.aircraft_maintenance(ac.id, u, db)
    code, ver, appr = _ac_meta(db, ac)
    secs = [section("Usage", tables=[kv("Aircraft usage", [["Flight hours", round(ac.flight_hours or 0, 2)], ["Flight cycles", ac.flight_cycles]]),
                                     table("Battery cycles", ["Battery", "Model", "Cycles", "Hours"], [[b["code"], b["model"], b["cycles"], round(b["hours"] or 0, 2)] for b in d["batteries"]])]),
            section("Maintenance alerts", ["No maintenance is due."] if not d["alerts"] else [],
                    [table("Alerts", ["Level", "Category", "Detail"], [[a["level"].upper(), a["category"], a["message"]] for a in d["alerts"]])] if d["alerts"] else []),
            section("Maintenance programme", [] if d["tasks"] else ["No maintenance tasks are defined."], [
                table("Tasks", ["Task", "Type", "Category", "Interval h", "Interval cycles", "Interval days", "Last done", "Active"],
                      [[t["title"], t["task_type"], t["category"], t["interval_hours"], t["interval_cycles"], t["interval_days"], t["last_done_date"], t["active"]] for t in d["tasks"]])] if d["tasks"] else []),
            section("Maintenance history", [] if d["actions"] else ["No maintenance actions are recorded."], [
                table("Actions", ["ID", "Date", "Action", "Category", "Component", "Work performed", "Findings", "Condition", "Failure", "By", "Hours"],
                      [[a["code"], a["date"], a["action_type"], a["category"], a["component"], a["description"], a["findings"], a["condition"], a["failure"],
                        a["performed_by_name"], a["hours_at_action"]] for a in d["actions"]])] if d["actions"] else [])]
    return ac.code, f"{ac.code} {ac.name}", code, ver, appr, secs


def b_reliability(db, u, sid):
    r = maint.reliability(db)
    secs = [section("Method", [r["note"]]),
            section("Component reliability by model", [] if r["components"] else ["No components registered."], [
                table("Components", ["Category", "Manufacturer", "Model", "Units", "Hours", "Cycles", "Failures", "MTBF (h)", "Failures / 100 h"],
                      [[c["category"], c["manufacturer"], c["model"], c["units"], c["hours"], c["cycles"], c["failures"], c["mtbf_h"], c["failures_per_100h"]] for c in r["components"]])]),
            section("Aircraft configurations", tables=[
                table("Aircraft", ["Aircraft", "Hardware rev", "Hours", "Cycles", "Component failures", "Issues", "Open issues", "Incidents", "MTBF (h)"],
                      [[a["code"], a["hardware_revision"], a["flight_hours"], a["flight_cycles"], a["failures"], a["issues"], a["open_issues"], a["incidents"], a["mtbf_h"]] for a in r["aircraft"]])])]
    return "FLEET", "Fleet", "Fleet", "—", [], secs


def b_deployment(db, u, sid):
    dep = _need(db, m.Deployment, sid, "Deployment")
    d = ops.deployment_detail_data(db, dep)
    cl = d["checklist"]
    secs = [section("Deployment", tables=[kv("Deployment", [["Deployment ID", dep.code], ["Name", dep.name], ["Customer", d["customer"]], ["Country", dep.country],
                                                             ["Location", dep.location], ["Dates", f"{_s(dep.start_date)} to {_s(dep.end_date)}"], ["Status", dep.status]])],
                    paragraphs=[f"Objectives: {_s(dep.objectives)}"]),
            section("Aircraft inventory", [] if d["aircraft"] else ["No aircraft assigned."], [
                table("Aircraft", ["Aircraft", "Readiness state", "Operational release", "Blockers"], [[a["code"] + " " + a["name"], a["state"], a["released"], "; ".join(a["blockers"])] for a in d["aircraft"]])]),
            section("Ground station inventory", [] if d["equipment"] else ["No ground equipment assigned."], [
                table("Equipment", ["ID", "Category", "Name", "Serial", "Software", "Status"], [[e["code"], e["category"], e["name"], e["serial_number"], e["software_version"], e["status"]] for e in d["equipment"]])]),
            section("Personnel", [] if d["personnel"] else ["No personnel assigned."], [table("Personnel", ["Name", "Current qualification on record"], [[p["name"], p["qualified"]] for p in d["personnel"]])]),
            section("Logistics", [f"Spare components: {_s(dep.spares)}", f"Tools and equipment: {_s(dep.tools)}", f"Travel arrangements: {_s(dep.travel)}",
                                  f"Site requirements: {_s(dep.site_requirements)}", f"Weather assessment: {_s(dep.weather_assessment)}",
                                  f"Emergency procedures: {_s(dep.emergency_procedures)}"]),
            section("Regulatory approvals and operational permissions", [] if d["permits"] else ["No permits are recorded."], [
                table("Permits", ["ID", "Type", "Authority", "Reference", "Valid from", "Valid to", "Status"],
                      [[p["code"], p["permit_type"], p["authority"], p["reference"], p["valid_from"], p["valid_to"], p["status"] + (" (EXPIRED)" if p["expired"] else "")] for p in d["permits"]])] if d["permits"] else []),
            section("Deployment readiness", [f"Checklist: {cl['done']}/{cl['total']} items satisfied, {cl['failed']} failed — {cl['status'].upper()}." if cl else "The readiness checklist has not been opened."]
                    + ([f"Missing documentation: {x}" for x in d["missing_documentation"]]),
                    [table("Readiness checklist", ["#", "Area", "Item", "Status", "Note", "Signed by"],
                           [[i["seq"], i["category"], i["label"], i["status"].upper() + (" (auto)" if i["auto_key"] else ""), i["note"], i["signed_by_name"]] for i in cl["items"]])] if cl else [])]
    return dep.code, f"{dep.code} {dep.name}", ", ".join(a["code"] for a in d["aircraft"]) or "—", "See aircraft records", [("deployment", dep.id)], secs


def b_demonstration(db, u, sid):
    demo = _need(db, m.Demonstration, sid, "Demonstration")
    d = ops.demo_detail(demo.id, u, db)
    ac = db.get(m.Aircraft, demo.aircraft_id or 0)
    code, ver, _ = _ac_meta(db, ac)
    crit = d["acceptance_criteria"] or []
    met = sum(1 for c in crit if c["met"])
    secs = [section("Demonstration", tables=[kv("Overview", [["Demonstration", demo.name], ["Customer", d["customer"]], ["Date", _s(demo.scheduled_at)[:16]], ["Location", demo.location],
                                                              ["Aircraft", f"{ac.name} ({ac.aircraft_type}, {_s(ac.manufacturer)} {_s(ac.model)})" if ac else None],
                                                              ["Team", ", ".join(d["personnel"])], ["Status", demo.status]])]),
            section("Objectives and scenario", [f"Objectives: {_s(demo.objectives)}", f"Scenario: {_s(demo.scenario)}", f"Safety briefing: {_s(demo.safety_briefing)}"]),
            section("Acceptance criteria", [f"{met} of {len(crit)} criteria met." if demo.status == "completed" else "The demonstration has not been completed; criteria are not yet assessed."],
                    [table("Criteria", ["Criterion", "Result", "Note"], [[c["text"], "MET" if c["met"] else "NOT MET" if c["met"] is False else "Not assessed", c["note"]] for c in crit])] if crit else []),
            section("Results and feedback", [f"Results: {_s(demo.results)}", f"Customer feedback: {_s(demo.feedback)}", f"Feedback score: {_s(demo.feedback_score)} / 5"])]
    return demo.code, f"{demo.code} {demo.name}", code, ver, [], secs


def b_training(db, u, sid):
    p = training.person(sid, u, db)
    lic = [q for q in p["qualifications"] if q["kind"] != "internal_training_record"]
    intr = [q for q in p["qualifications"] if q["kind"] == "internal_training_record"]
    cols = ["Title", "Issuer", "Reference", "Issued", "Expires", "Expired"]
    row = lambda q: [q["title"], q["issuer"], q["reference"], q["issued_date"], q["expiry_date"], q["expired"]]  # noqa: E731
    secs = [section("Person", tables=[kv("Profile", [["Name", p["person"]["full_name"]], ["Role", p["role_label"]], ["Discipline", p["person"]["discipline"]], ["Organisation", p["person"]["organisation"]]])]),
            section("Internal training records", [training.DISCLAIMER] + ([] if intr else ["No internal training completed."]), [table("Internal training records", cols, [row(q) for q in intr])] if intr else []),
            section("Externally issued licences and certificates", ["Recorded as supplied by the holder; issued by the named authority, not by this platform."] + ([] if lic else ["None recorded."]),
                    [table("Licences / certificates (external)", ["Type"] + cols, [[q["kind"]] + row(q) for q in lic])] if lic else []),
            section("Course enrolments", [] if p["enrollments"] else ["No enrolments."], [
                table("Enrolments", ["Course", "Status", "Modules", "Best assessment score", "Practical assessment", "Completed"],
                      [[e["course"], e["status"], f"{e['modules_done']}/{e['modules_total']}", e["best_score"], "done" if e["practical_done"] else "required" if e["practical_required"] else "n/a",
                        (e["completed_at"] or "")[:10]] for e in p["enrollments"]])] if p["enrollments"] else [])]
    return p["person"]["full_name"], p["person"]["full_name"], "—", "—", [], secs


def b_readiness(db, u, sid):
    rds = fleet.all_readiness(u, db)
    secs = [section("Fleet readiness", ["Readiness states are derived from recorded evidence and approvals; they cannot be assigned manually."], [
        table("Aircraft readiness", ["Aircraft", "Type", "State", "Released configuration", "Operational release", "Designated campaign", "Hours"],
              [[f"{r['code']} {r['name']}", r["aircraft_type"], r["state"], f"Rev {r['revision']['number']} ({r['revision']['label']})" if r["revision"] else None,
                r["operational_release"]["text"] if r["operational_release"] else None, r["designated_campaign"]["code"] if r["designated_campaign"] else None, r["flight_hours"]] for r in rds])])]
    for r in rds:
        rows = [[g["label"], "MET" if g["ok"] else "NOT MET", " | ".join(e["text"] for e in g["evidence"])] for g in r["gates"]]
        rows += [["Blocker", b["state"].upper(), b["text"]] for b in r["blockers"]]
        secs.append(section(f"{r['code']} {r['name']} — {r['state']}", tables=[table("Gates and evidence", ["Gate", "Status", "Evidence"], rows)]))
    al = maint.all_alerts(u, db)
    secs.append(section("Maintenance alerts", [] if al else ["None."], [table("Alerts", ["Level", "Detail"], [[a["level"].upper(), a["message"]] for a in al])] if al else []))
    return "FLEET", "Fleet", ", ".join(r["code"] for r in rds) or "—", "See per-aircraft sections", [], secs


def b_issue(db, u, sid):
    i = _need(db, m.Issue, sid, "Issue")
    t = testing.trace(i.id, u, db)
    ac = db.get(m.Aircraft, i.aircraft_id or 0)
    code, ver, appr = _ac_meta(db, ac)
    cm = ap.comments("issue", i.id, u, db)
    att = ap.attachments_of(db, "issue", i.id)
    secs = [section("Issue", tables=[kv("Issue", [["Issue ID", i.code], ["Title", i.title], ["Severity", i.severity], ["Status", i.status], ["Aircraft", ac.code if ac else None],
                                                   ["Hardware revision", i.hardware_revision], ["Software version", i.software_version],
                                                   ["Test campaign", t["campaign"]["code"] if t["campaign"] else None], ["Owning discipline", i.discipline],
                                                   ["Assigned engineer", t["issue"]["assigned_to_name"]], ["Reported by", t["issue"]["reported_by_name"]], ["Closed", i.closed_at]])],
                    paragraphs=[f"Description: {_s(i.description)}"]),
            section("Traceability", tables=[kv("Field observation to resolution", [
                ["Originating test card", f"{t['origin_card']['code']} {t['origin_card']['title']} ({t['origin_card']['status']})" if t["origin_card"] else None],
                ["Supporting telemetry", f"{t['flight_log']['code']} {t['flight_log']['name']}" if t["flight_log"] else None],
                ["Root cause", i.root_cause], ["Corrective action", i.corrective_action],
                ["Verification test", f"{t['verification_card']['code']} {t['verification_card']['title']} ({t['verification_card']['status']}, {'signed' if t['verification_card']['signed'] else 'unsigned'})" if t["verification_card"] else None],
                ["Closure approval", "; ".join(f"{a['status']} by {a['decided_by_name']}" for a in t["closure"] if a["decided_by"])]])]),
            section("Supporting documents", [] if att else ["None attached."], [table("Attachments", ["File", "SHA-256"], [[a.filename, a.sha256] for a in att])] if att else []),
            section("Collaboration", [] if cm else ["No comments."], [table("Comments", ["Date", "Author", "Discipline", "Comment"], [[c["created_at"][:16], c["user_name"], c["discipline"] or c["role"], c["body"]] for c in cm])] if cm else []),
            section("History", tables=[table("Timeline", ["Time (UTC)", "User", "Event"], [[e["ts"][:16], e["user"], e["summary"]] for e in t["timeline"]])])]
    return i.code, f"{i.code} {i.title}", code, ver, appr + [("issue", i.id)], secs


BUILDERS = {"aircraft_config": b_aircraft_config, "hardware_integration": b_hardware_integration, "campaign": b_campaign, "test_card": b_test_card,
            "flight_performance": b_flight_performance, "telemetry_analysis": b_telemetry_analysis, "maintenance": b_maintenance, "reliability": b_reliability,
            "deployment": b_deployment, "demonstration": b_demonstration, "training": b_training, "readiness": b_readiness, "issue": b_issue}


# ───────────── renderers ─────────────
def _fonts(pdf) -> str:
    win = Path("C:/Windows/Fonts")
    for reg, bold in (("segoeui.ttf", "segoeuib.ttf"), ("arial.ttf", "arialbd.ttf")):
        if (win / reg).exists() and (win / bold).exists():
            pdf.add_font("ui", "", str(win / reg))
            pdf.add_font("ui", "B", str(win / bold))
            return "ui"
    return "helvetica"


def render_pdf(doc: dict, path: Path) -> None:
    from fpdf import FPDF
    from fpdf.enums import XPos, YPos

    class PDF(FPDF):
        def footer(self):
            self.set_y(-11)
            self.set_font(font, "", 7)
            self.set_text_color(110)
            self.cell(0, 5, clean(f"{doc['code']}  ·  Rev {doc['revision']}  ·  {doc['title']}  ·  {doc['organisation']}"), align="L")
            self.cell(0, 5, f"Page {self.page_no()}/{{nb}}", align="R")

    pdf = PDF(orientation="L", format="A4")
    font = _fonts(pdf)
    clean = (lambda s: s) if font == "ui" else (lambda s: s.replace("—", "-").replace("·", "|").replace("→", "->").replace("≥", ">=").replace("…", "...")
                                               .replace("“", '"').replace("”", '"').replace("’", "'").encode("latin-1", "replace").decode("latin-1"))
    pdf.set_auto_page_break(True, margin=14)
    pdf.set_margins(12, 12, 12)
    pdf.add_page()
    pdf.set_fill_color(24, 28, 34)
    pdf.rect(0, 0, 297, 26, "F")
    pdf.set_text_color(255)
    pdf.set_font(font, "B", 15)
    pdf.set_xy(12, 6)
    pdf.cell(0, 7, clean(doc["title"]), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_font(font, "", 9)
    pdf.cell(0, 6, clean(f"{doc['subject']}  ·  AEROS OPS PRO  ·  {doc['organisation']}"), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
    pdf.set_text_color(20)
    pdf.set_y(31)

    def tbl(columns, rows, widths=None, size=7.5):
        pdf.set_font(font, "", size)
        with pdf.table(col_widths=widths, line_height=4.2, text_align="LEFT", headings_style=__import__("fpdf").fonts.FontFace(emphasis="BOLD", fill_color=(226, 230, 236)),
                       borders_layout="HORIZONTAL_LINES", padding=0.8) as t:
            r = t.row()
            for c in columns:
                r.cell(clean(str(c)))
            for row in rows:
                r = t.row()
                for c in row:
                    r.cell(clean(str(c)))
        pdf.ln(2.5)

    meta = [["Document number", doc["code"]], ["Document revision", doc["revision"]], ["Created (UTC)", doc["created"]], ["Author", doc["author"]],
            ["Aircraft ID", doc["aircraft_code"]], ["Configuration version", doc["config_version"]],
            ["Applicable approvals", "\n".join(doc["approvals"]) or "None recorded"]]
    tbl(["Document control", ""], meta, (55, 218), 8)
    for s in doc["sections"]:
        if pdf.get_y() > 175:
            pdf.add_page()
        pdf.set_font(font, "B", 11)
        pdf.set_text_color(18, 74, 110)
        pdf.multi_cell(0, 6, clean(s["heading"]), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_text_color(20)
        for p in s["paragraphs"]:
            pdf.set_font(font, "", 8.5)
            pdf.multi_cell(0, 4.4, clean(p), new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.ln(0.8)
        for t in s["tables"]:
            if not t["rows"]:
                continue
            n = len(t["columns"])
            lens = [max([len(str(t["columns"][i]))] + [min(len(str(r[i])), 60) for r in t["rows"]]) + 2 for i in range(n)]
            widths = tuple(max(9.0, 273 * x / sum(lens)) for x in lens)
            tbl(t["columns"], t["rows"], tuple(w * 273 / sum(widths) for w in widths))
        pdf.ln(1)
    pdf.output(str(path))


def render_xlsx(doc: dict, path: Path) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    wb = Workbook()
    ws = wb.active
    ws.title = "Document"
    ws.append([doc["title"]])
    ws["A1"].font = Font(bold=True, size=14)
    for k, v in (("Subject", doc["subject"]), ("Document number", doc["code"]), ("Document revision", doc["revision"]), ("Created (UTC)", doc["created"]),
                 ("Author", doc["author"]), ("Aircraft ID", doc["aircraft_code"]), ("Configuration version", doc["config_version"]),
                 ("Applicable approvals", "; ".join(doc["approvals"]) or "None recorded"), ("Organisation", doc["organisation"])):
        ws.append([k, v])
    ws.append([])
    used = {"Document"}
    for s in doc["sections"]:
        ws.append([s["heading"]])
        ws.cell(ws.max_row, 1).font = Font(bold=True)
        for p in s["paragraphs"]:
            ws.append(["", p])
        for t in s["tables"]:
            if not t["rows"]:
                continue
            name = base = "".join(ch for ch in t["title"] if ch not in '[]:*?/\\')[:28]
            k = 2
            while name in used:
                name, k = f"{base}_{k}", k + 1
            used.add(name)
            sh = wb.create_sheet(name)
            sh.append([s["heading"]])
            sh.append(t["columns"])
            for c in sh[2]:
                c.font, c.fill = Font(bold=True), PatternFill("solid", fgColor="DDE3EA")
            for r in t["rows"]:
                sh.append(r)
            for i, col in enumerate(t["columns"]):
                w = max([len(str(col))] + [len(str(r[i])) for r in t["rows"]])
                sh.column_dimensions[sh.cell(2, i + 1).column_letter].width = min(max(10, w + 2), 70)
            sh.freeze_panes = "A3"
            ws.append(["", f"Table: see sheet “{name}”"])
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 120
    for row in ws.iter_rows():
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(path)


def render_csv(doc: dict, path: Path) -> None:
    buf = io.StringIO()
    w = csv.writer(buf)
    for k in ("title", "subject", "code", "revision", "created", "author", "aircraft_code", "config_version", "organisation"):
        w.writerow([k, doc[k]])
    w.writerow(["approvals", "; ".join(doc["approvals"]) or "None recorded"])
    for s in doc["sections"]:
        w.writerow([])
        w.writerow([f"## {s['heading']}"])
        for p in s["paragraphs"]:
            w.writerow([p])
        for t in s["tables"]:
            w.writerow([f"# {t['title']}"])
            w.writerow(t["columns"])
            w.writerows(t["rows"])
    path.write_text(buf.getvalue(), encoding="utf-8-sig", newline="")


def generate(db: Db, u: m.User, rtype: str, subject_id: int | None) -> m.Report:
    if rtype not in TYPES:
        raise HTTPException(422, "Unknown report type")
    title, subj_res = TYPES[rtype]
    if subj_res and not subject_id:
        raise HTTPException(422, f"{title} needs a subject record.")
    key, subject, ac_code, cfg_ver, appr_pairs, secs = BUILDERS[rtype](db, u, subject_id)
    db.rollback()  # builders only read; discard any auto-evaluated checklist display state
    rev = (db.scalar(select(m.Report.revision).where(m.Report.report_type == rtype, m.Report.subject_id == (subject_id or 0)).order_by(m.Report.revision.desc())) or 0) + 1
    rep = m.Report(report_type=rtype, title=title, subject_type=subj_res, subject_id=subject_id or 0, revision=rev, author_id=u.id, aircraft_code=ac_code,
                   config_version=cfg_ver, approvals=_approvals(db, appr_pairs), created_at=utcnow())
    db.add(rep)
    db.flush()
    rep.code = f"AOP-{rtype.upper().replace('_', '-')}-{rep.id:05d}"
    doc = {"title": title, "subject": subject, "code": rep.code, "revision": rev, "created": f"{rep.created_at:%Y-%m-%d %H:%M}", "author": u.full_name,
           "aircraft_code": ac_code, "config_version": cfg_ver, "approvals": rep.approvals, "sections": secs,
           "organisation": get_setting(db, "organisation", "Organisation not set")}
    out = config.sub("reports")
    files = {}
    for fmt, fn in (("pdf", render_pdf), ("xlsx", render_xlsx), ("csv", render_csv)):
        fn(doc, out / f"{rep.code}.{fmt}")
        files[fmt] = f"{rep.code}.{fmt}"
    if rtype in ("flight_performance", "telemetry_analysis"):  # interactive charts accompany the flight-data reports
        try:
            (out / f"{rep.code}.html").write_text(analysis.plotly_html(db.get(m.FlightLog, subject_id)), encoding="utf-8")
            files["html"] = f"{rep.code}.html"
        except ImportError:  # the browser edition ships without the Plotly bundle
            pass
    rep.files = files
    audit(db, u, "report", rtype, subject_id, f"Generated {title} {rep.code} rev {rev} for {subject}")
    db.commit()
    return rep


def _rep_out(r, names):
    return dict(to_dict(r), author=names.get(r.author_id))


@router.get("/report-types")
def report_types(u: m.User = Depends(internal_user)):
    return [{"key": k, "title": v[0], "subject": v[1]} for k, v in TYPES.items()]


@router.post("/reports")
def create_report(data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    rep = generate(db, u, data.get("report_type"), data.get("subject_id"))
    return _rep_out(rep, user_names(db))


def _customer_can(db, u, r) -> bool:
    if r.report_type != "demonstration":
        return False
    demo = db.get(m.Demonstration, r.subject_id)
    return bool(demo and demo.customer_id == u.customer_id)


@router.get("/reports")
def list_reports(report_type: str | None = None, subject_id: int | None = None, u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    st = select(m.Report)
    if report_type:
        st = st.where(m.Report.report_type == report_type)
    if subject_id is not None:
        st = st.where(m.Report.subject_id == subject_id)
    names = user_names(db)
    rows = [r for r in db.scalars(st.order_by(m.Report.id.desc()).limit(300)) if u.role != "customer" or _customer_can(db, u, r)]
    return [_rep_out(r, names) for r in rows]


@router.get("/reports/{rid}/file/{fmt}")
def report_file(rid: int, fmt: str, u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    r = db.get(m.Report, rid)
    if not r or fmt not in (r.files or {}) or (u.role == "customer" and not _customer_can(db, u, r)):
        raise HTTPException(404, "Report file not found")
    p = config.sub("reports") / r.files[fmt]
    if not p.exists():
        raise HTTPException(410, "The report file is missing from the data directory.")
    mt = {"pdf": "application/pdf", "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "csv": "text/csv", "html": "text/html"}[fmt]
    return FileResponse(p, filename=r.files[fmt], media_type=mt)
