"""Schema-driven record API: one registry describes every record type, its permissions and UI metadata."""
from dataclasses import dataclass, field
from datetime import date, datetime

from fastapi import APIRouter, Body, Depends, HTTPException, Request
from sqlalchemy import JSON, Boolean, Date, DateTime, Float, Integer, String, Text, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session as Db

from . import models as m
from .core import INTERNAL, audit, current_user, hash_password, next_code, password_problem, to_dict
from .db import get_db

router = APIRouter(prefix="/api")


@dataclass
class Resource:
    model: type
    title: str
    singular: str
    read: list
    write: list
    prefix: str | None = None
    label: str = "name"
    list_fields: list = field(default_factory=list)
    customer_scope: object = None  # callable(stmt, user) -> stmt, or None (no customer access)
    hooks: dict = field(default_factory=dict)

    @property
    def name(self):
        return self.model.__tablename__


REG: dict[str, Resource] = {}


def register(model, title, singular, write, read=None, **kw):
    r = Resource(model=model, title=title, singular=singular, read=read or INTERNAL, write=write, **kw)
    REG[r.name] = r
    return r


def hook(resource: str, event: str):
    def deco(fn):
        REG[resource].hooks.setdefault(event, []).append(fn)
        return fn

    return deco


def _fire(res: Resource, event: str, **kw):
    for fn in res.hooks.get(event, []):
        fn(**kw)


ENG = ["flight_ops", "uav_eng"]
TEST = ["flight_ops", "flight_test"]

register(m.Customer, "Customers", "Customer", ["flight_ops"], prefix="CUS", list_fields=["code", "name", "country", "contact_name"])
register(m.Project, "Projects", "Project", ["flight_ops", "uav_eng", "flight_test"], prefix="PRJ",
         list_fields=["code", "name", "customer_id", "status", "manager_id", "start_date", "end_date"])
register(m.User, "Users & personnel", "User", [], label="full_name",
         list_fields=["username", "full_name", "role", "discipline", "organisation", "can_login", "active"])
register(m.Aircraft, "Aircraft", "Aircraft", ENG, prefix="AC",
         list_fields=["code", "name", "aircraft_type", "model", "autopilot", "autopilot_firmware", "hardware_revision", "flight_hours"])
register(m.Component, "Components", "Component", ENG + ["maintenance"], prefix="CMP", label="model",
         list_fields=["code", "category", "manufacturer", "model", "serial_number", "status", "aircraft_id", "position", "hours", "cycles"])
register(m.Campaign, "Test campaigns", "Campaign", TEST, prefix="TC",
         list_fields=["code", "name", "aircraft_id", "location", "responsible_engineer_id", "start_date", "stage", "status"])
register(m.RiskItem, "Risk assessment", "Risk item", TEST, label="hazard",
         list_fields=["hazard", "likelihood", "severity", "mitigation", "residual_likelihood", "residual_severity", "owner_id"])
register(m.TestCard, "Test cards", "Test card", TEST + ["uav_eng"], prefix="TP", label="title",
         list_fields=["code", "title", "category", "campaign_id", "status", "signed_by"])
register(m.Flight, "Flights", "Flight", TEST + ["operator", "uav_eng"], prefix="FLT", label="code",
         list_fields=["code", "aircraft_id", "source_class", "date", "duration_s", "pilot_id", "campaign_id", "gate_status"])
register(m.Incident, "Operational incidents", "Incident", INTERNAL, prefix="INC", label="code",
         list_fields=["code", "date", "aircraft_id", "incident_type", "severity", "status"])
register(m.Mission, "Missions", "Mission", TEST + ["uav_eng", "operator"], prefix="MSN",
         list_fields=["code", "name", "aircraft_id", "campaign_id", "revision", "status"])
register(m.C2Equipment, "C2 equipment", "Equipment", ENG + ["operator"], prefix="C2",
         list_fields=["code", "category", "name", "model", "serial_number", "software_version", "status", "location", "next_maintenance"])
register(m.TelemetryLink, "Telemetry links", "Telemetry link", ENG + ["flight_test", "operator"],
         list_fields=["name", "transport", "address", "port", "source_class", "aircraft_id"])
register(m.Deployment, "Deployments", "Deployment", ["flight_ops"], prefix="DEP",
         list_fields=["code", "name", "customer_id", "country", "location", "start_date", "end_date", "status"])
register(m.Permit, "Permits & authorizations", "Permit", ["flight_ops"], prefix="PMT", label="reference",
         list_fields=["code", "permit_type", "authority", "reference", "deployment_id", "campaign_id", "valid_from", "valid_to", "status"])
register(m.Demonstration, "Demonstrations", "Demonstration", ["flight_ops", "flight_test"], prefix="DEMO", read=INTERNAL + ["customer"],
         customer_scope=lambda st, u: st.where(m.Demonstration.customer_id == (u.customer_id or -1)),
         list_fields=["code", "name", "customer_id", "aircraft_id", "scheduled_at", "location", "status"])
register(m.Course, "Courses", "Course", ["instructor"], prefix="CRS", label="title",
         list_fields=["code", "title", "category", "validity_months", "pass_mark", "active"])
register(m.CourseModule, "Learning modules", "Module", ["instructor"], label="title", list_fields=["seq", "title", "kind", "diagram"])
register(m.QuizQuestion, "Assessment questions", "Question", ["instructor"], read=["instructor"], label="text",
         list_fields=["seq", "kind", "text", "answer"])
register(m.Enrollment, "Enrollments", "Enrollment", ["instructor"], label="id",
         list_fields=["course_id", "student_id", "instructor_id", "status", "completed_at"])
register(m.Attendance, "Attendance", "Attendance record", ["instructor"], label="session",
         list_fields=["enrollment_id", "date", "session", "present"])
register(m.Qualification, "Qualifications & licences", "Qualification", ["instructor", "flight_ops"], label="title",
         list_fields=["user_id", "kind", "title", "issuer", "reference", "issued_date", "expiry_date"])
register(m.MaintenanceTask, "Maintenance programme", "Maintenance task", ["maintenance", "flight_ops", "uav_eng"], label="title",
         list_fields=["aircraft_id", "title", "task_type", "category", "interval_hours", "interval_cycles", "interval_days", "last_done_date", "active"])
register(m.MaintenanceAction, "Maintenance actions", "Maintenance action", ["maintenance", "flight_ops", "uav_eng"], prefix="MA", label="code",
         list_fields=["code", "date", "aircraft_id", "component_id", "action_type", "category", "condition", "failure", "performed_by"])
register(m.Issue, "Engineering issues", "Issue", INTERNAL, prefix="ISS", label="title",
         list_fields=["code", "title", "aircraft_id", "severity", "discipline", "status", "assigned_to", "campaign_id"])


# ───────────── metadata ─────────────
def _ftype(col) -> str:
    t = col.type
    if isinstance(t, Boolean):
        return "bool"
    if isinstance(t, DateTime):
        return "datetime"
    if isinstance(t, Date):
        return "date"
    if isinstance(t, Integer):
        return "int"
    if isinstance(t, Float):
        return "float"
    if isinstance(t, JSON):
        return "json"
    if isinstance(t, Text):
        return "textarea"
    return "text"


def fields_of(model) -> list:
    out = []
    for col in model.__table__.columns:
        info = col.info or {}
        if col.name == "id" or info.get("hidden"):
            continue
        f = {"name": col.name, "type": _ftype(col), "label": info.get("label") or col.name.replace("_", " ").capitalize(),
             "required": (not col.nullable) and col.default is None and not col.primary_key, "ro": bool(info.get("ro"))}
        for k in ("choices", "widget", "ref", "help", "unit"):
            if k in info:
                f[k] = info[k]
        if isinstance(col.type, String) and getattr(col.type, "length", None):
            f["max"] = col.type.length
        out.append(f)
    return out


def can(user: m.User, res: Resource, write: bool) -> bool:
    if user.role == "admin":
        return True
    if user.role == "customer" and (write or res.customer_scope is None):
        return False
    return user.role in (res.write if write else res.read)


@router.get("/meta")
def meta(u: m.User = Depends(current_user)):
    res = {}
    for name, r in REG.items():
        if can(u, r, False):
            res[name] = {"title": r.title, "singular": r.singular, "label": r.label, "list": r.list_fields, "auto_code": bool(r.prefix),
                         "can_write": can(u, r, True), "fields": fields_of(r.model), "write_roles": [m.ROLES[x] for x in r.write if x != "admin"]}
    return {"resources": res, "roles": m.ROLES, "stages": m.CAMPAIGN_STAGES, "validation_categories": m.VALIDATION_CATEGORIES,
            "component_categories": m.COMPONENT_CATEGORIES, "aircraft_types": m.AIRCRAFT_TYPES}


# ───────────── CRUD ─────────────
def _res(name: str, u: m.User, write: bool) -> Resource:
    r = REG.get(name)
    if not r:
        raise HTTPException(404, "Unknown record type")
    if not can(u, r, write):
        raise HTTPException(403, f"Your role is not permitted to {'modify' if write else 'view'} {r.title.lower()}.")
    return r


def coerce(col, v):
    if v == "" or v is None:
        return None
    t = col.type
    try:
        if isinstance(t, Boolean):
            return v if isinstance(v, bool) else str(v).lower() in ("1", "true", "yes", "on")
        if isinstance(t, DateTime):
            return v if isinstance(v, datetime) else datetime.fromisoformat(str(v).replace("Z", "")).replace(tzinfo=None)
        if isinstance(t, Date):
            return v if isinstance(v, date) else date.fromisoformat(str(v)[:10])
        if isinstance(t, Integer):
            return int(v)
        if isinstance(t, Float):
            return float(v)
        if isinstance(t, JSON):
            return v
        return str(v)
    except (ValueError, TypeError):
        raise HTTPException(422, f"Invalid value for {col.info.get('label', col.name)}: {v!r}")


def apply(res: Resource, obj, data: dict, is_new: bool) -> dict:
    """Copy client data onto the record; returns the dict of changed fields."""
    changes = {}
    for col in res.model.__table__.columns:
        info = col.info or {}
        if col.name not in data or col.name in ("id", "created_at", "updated_at") or info.get("ro") or col.name == "password_hash":
            continue
        if col.name == "code" and not is_new:
            continue
        v = coerce(col, data[col.name])
        if info.get("choices") and v not in (None, "") and v not in info["choices"]:
            raise HTTPException(422, f"{info.get('label', col.name)} must be one of: {', '.join(info['choices'])}")
        old = getattr(obj, col.name)
        if old != v:
            changes[col.name] = [old, v]
            setattr(obj, col.name, v)
    for col in res.model.__table__.columns:
        if not col.nullable and col.default is None and not col.primary_key and getattr(obj, col.name) in (None, ""):
            raise HTTPException(422, f"{(col.info or {}).get('label', col.name)} is required.")
    return changes


def label_of(res: Resource, obj) -> str:
    v = getattr(obj, res.label, None)
    code = getattr(obj, "code", None)
    if code and res.label != "code":
        return f"{code} · {v}"
    return str(v if v is not None else obj.id)


def out(res: Resource, obj) -> dict:
    d = to_dict(obj)
    d["_label"] = label_of(res, obj)
    return d


@router.get("/r/{name}")
def list_records(name: str, request: Request, u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    res = _res(name, u, False)
    st = select(res.model)
    if u.role == "customer":
        st = res.customer_scope(st, u)
    cols = res.model.__table__.columns
    for k, v in request.query_params.items():
        if k == "q" and v:
            like = [c.ilike(f"%{v}%") for c in cols if isinstance(c.type, (String, Text)) and c.name != "password_hash"]
            st = st.where(or_(*like))
        elif k in cols and v != "":
            st = st.where(cols[k] == coerce(cols[k], v))
    st = st.order_by(res.model.id.desc()).limit(int(request.query_params.get("limit", 1000)))
    return [out(res, o) for o in db.scalars(st)]


@router.get("/options/{name}")
def options(name: str, u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    if name == "flight_logs":
        return [{"id": o.id, "label": f"{o.code} · {o.name}"} for o in db.scalars(select(m.FlightLog).order_by(m.FlightLog.id.desc()))]
    res = REG.get(name)
    if not res:
        raise HTTPException(404, "Unknown record type")
    st = select(res.model)
    if u.role == "customer":
        if res.customer_scope is None and name not in ("customers", "aircraft", "users", "missions", "c2_equipment"):
            raise HTTPException(403, "Not permitted")
        if res.customer_scope is not None:
            st = res.customer_scope(st, u)
    return [{"id": o.id, "label": label_of(res, o)} for o in db.scalars(st.order_by(res.model.id))]


def get_obj(db: Db, res: Resource, id_: int, u: m.User | None = None):
    obj = db.get(res.model, id_)
    if obj and u is not None and u.role == "customer":
        if not db.scalar(res.customer_scope(select(res.model.id), u).where(res.model.id == id_)):
            obj = None
    if not obj:
        raise HTTPException(404, f"{res.singular} not found")
    return obj


@router.get("/r/{name}/{id_}")
def get_record(name: str, id_: int, u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    res = _res(name, u, False)
    return out(res, get_obj(db, res, id_, u))


def _user_extra(db, obj, data, is_new):
    pw = data.get("password")
    if pw:
        prob = password_problem(pw)
        if prob:
            raise HTTPException(422, prob)
        obj.password_hash = hash_password(pw)
        db.query(m.Session).filter(m.Session.user_id == obj.id).delete() if not is_new else None
    if obj.role not in m.ROLES:
        raise HTTPException(422, "Unknown role")


@router.post("/r/{name}")
def create_record(name: str, data: dict = Body(...), u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    res = _res(name, u, True)
    obj = res.model()
    for col in res.model.__table__.columns:  # apply python-side defaults early so hooks can rely on them
        if col.default is not None and col.default.is_scalar:
            setattr(obj, col.name, col.default.arg)
        elif col.default is not None and col.default.is_callable and col.name not in ("created_at", "updated_at"):
            setattr(obj, col.name, col.default.arg(None))
    apply(res, obj, data, True)
    if res.prefix and not getattr(obj, "code", None):
        obj.code = next_code(db, res.model, res.prefix)
    if name == "users":
        _user_extra(db, obj, data, True)
    _fire(res, "before_save", db=db, user=u, obj=obj, data=data, is_new=True, changes={})
    db.add(obj)
    try:
        db.flush()
    except IntegrityError as e:
        db.rollback()
        raise HTTPException(409, f"Could not save: duplicate or invalid reference ({str(e.orig)[:120]})")
    _fire(res, "after_create", db=db, user=u, obj=obj, data=data)
    audit(db, u, "create", name, obj.id, f"Created {res.singular.lower()} {label_of(res, obj)}")
    db.commit()
    return out(res, obj)


@router.patch("/r/{name}/{id_}")
def update_record(name: str, id_: int, data: dict = Body(...), u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    res = _res(name, u, True)
    obj = get_obj(db, res, id_)
    _fire(res, "before_change", db=db, user=u, obj=obj, data=data)
    changes = apply(res, obj, data, False)
    if name == "users":
        _user_extra(db, obj, data, False)
        if data.get("password"):
            changes["password"] = ["***", "***"]
    _fire(res, "before_save", db=db, user=u, obj=obj, data=data, is_new=False, changes=changes)
    try:
        db.flush()
    except IntegrityError as e:
        db.rollback()
        raise HTTPException(409, f"Could not save: duplicate or invalid reference ({str(e.orig)[:120]})")
    _fire(res, "after_update", db=db, user=u, obj=obj, data=data, changes=changes)
    if changes:
        audit(db, u, "update", name, obj.id, f"Updated {res.singular.lower()} {label_of(res, obj)}: {', '.join(changes)}", changes)
    db.commit()
    return out(res, obj)


@router.delete("/r/{name}/{id_}")
def delete_record(name: str, id_: int, u: m.User = Depends(current_user), db: Db = Depends(get_db)):
    res = _res(name, u, True)
    obj = get_obj(db, res, id_)
    if name == "users" and obj.id == u.id:
        raise HTTPException(409, "You cannot delete your own account.")
    _fire(res, "before_delete", db=db, user=u, obj=obj)
    lab = label_of(res, obj)
    snapshot = to_dict(obj)
    try:
        db.delete(obj)
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, f"{res.singular} {lab} is referenced by other records and cannot be deleted.")
    audit(db, u, "delete", name, id_, f"Deleted {res.singular.lower()} {lab}", snapshot)
    db.commit()
    return {"ok": True}
