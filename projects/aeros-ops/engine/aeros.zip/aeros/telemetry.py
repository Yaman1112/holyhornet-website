"""Live telemetry hub: MAVLink links (UDP / TCP / serial), monitoring, anomaly markers, recording and mission upload.

Data provenance is carried end to end: every link is 'physical', 'sitl' (declared by the engineer) or 'simulation'
(the internal simulator). Simulated data is never presented or stored as live aircraft data.
"""
import asyncio
import math
import os
import socket
import struct
import threading
import time
from datetime import datetime, timezone

from fastapi import APIRouter, Body, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy import select
from sqlalchemy.orm import Session as Db

from . import analysis, config, flightdata as fd, fleet, missions, models as m, simulator
from .core import audit, internal_user, require, user_from_token
from .db import SessionLocal, get_db

os.environ.setdefault("MAVLINK20", "1")  # speak MAVLink 2 (pymavlink reads this when it is first imported)
router = APIRouter()
CONNECTORS = ("flight_ops", "flight_test", "uav_eng", "operator")
SENSOR_BITS = {0: "Gyro", 1: "Accelerometer", 2: "Magnetometer", 3: "Barometer", 4: "Airspeed", 5: "GPS", 6: "Optical flow", 8: "Laser position",
               15: "Motor outputs", 16: "RC receiver", 21: "AHRS", 22: "Terrain", 25: "Battery", 26: "Proximity"}
AUTOPILOTS = {0: "Generic (internal simulator)", 3: "ArduPilot", 12: "PX4", 8: "Invalid / GCS"}
VEHICLES = {1: "Fixed-wing", 2: "Quadrotor", 13: "Hexarotor", 14: "Octorotor", 10: "Ground rover", 19: "VTOL", 20: "VTOL", 21: "VTOL", 22: "VTOL"}


class LinkRunner(threading.Thread):
    def __init__(self, key, name, conn_str, source_class, aircraft_id=None, baud=None, transmit=False, link_id=None, vehicle=None):
        super().__init__(daemon=True, name=f"link-{key}")
        self.key, self.link_name, self.conn_str, self.source_class = key, name, conn_str, source_class
        self.aircraft_id, self.baud, self.transmit, self.link_id, self.vehicle = aircraft_id, baud, transmit, link_id, vehicle
        self.stop_evt = threading.Event()
        self.error = None
        self.s: dict = {}
        self.events: list = []
        self.active: set = set()
        self.started = time.time()
        self.last_rx = 0.0
        self.last_hb = 0.0
        self.count = self.bytes = 0
        self.loss_pct = None
        self.rate = 0.0
        self.rtt_ms = None
        self.interruptions = 0
        self.rec_file = None
        self.rec_path = None
        self.rec_start = None
        self.rec_name = None
        self.upload = None
        self.lock = threading.Lock()
        self.conn = None

    # ── recording ──
    def start_recording(self, name: str):
        with self.lock:
            if self.rec_file:
                raise ValueError("Already recording")
            self.rec_path = config.sub("recordings") / f"{self.key}_{int(time.time())}.tlog"
            self.rec_file, self.rec_start, self.rec_name = open(self.rec_path, "wb"), time.time(), name

    def stop_recording(self):
        with self.lock:
            f, self.rec_file = self.rec_file, None
        if f:
            f.close()
        return self.rec_path, self.rec_start, self.rec_name

    def event(self, level, text):
        now = time.time()
        self.events.append({"ts": datetime.now(timezone.utc).strftime("%H:%M:%S"), "wall": now, "level": level, "text": text,
                            "rec_t": round(now - self.rec_start, 1) if self.rec_file else None})
        del self.events[:-300]

    def flag(self, key, on, level, text):
        if on and key not in self.active:
            self.active.add(key)
            self.event(level, text)
        elif not on and key in self.active:
            self.active.discard(key)
            self.event("info", f"Cleared: {text}")

    # ── thread ──
    def run(self):
        from pymavlink import mavutil

        try:
            kw = {"baud": self.baud} if self.baud else {}
            self.conn = mavutil.mavlink_connection(self.conn_str, source_system=255, source_component=190, dialect="ardupilotmega", **kw)
        except Exception as e:
            self.error = f"Could not open {self.conn_str}: {e}"
            return
        ml = mavutil.mavlink
        tick = last_count = last_loss = last_count_m = 0
        last_stat = time.time()
        while not self.stop_evt.is_set():
            try:
                msg = self.conn.recv_match(blocking=True, timeout=0.25)
            except Exception as e:
                self.error = f"Link error: {e}"
                time.sleep(0.5)
                continue
            now = time.time()
            if msg is not None and msg.get_type() != "BAD_DATA":
                if self.last_rx and now - self.last_rx > 3.0:
                    self.interruptions += 1
                self.last_rx = now
                self.count += 1
                buf = msg.get_msgbuf()
                self.bytes += len(buf)
                with self.lock:
                    if self.rec_file:
                        self.rec_file.write(struct.pack(">Q", int(now * 1e6)) + buf)
                try:
                    self._update(msg, ml, mavutil)
                except Exception:
                    pass
            if now - last_stat >= 1.0:
                tick += 1
                self.rate = (self.count - last_count) / (now - last_stat)
                loss, cnt = getattr(self.conn, "mav_loss", 0), getattr(self.conn, "mav_count", 0)
                dl, dc = loss - last_loss, cnt - (last_count_m if tick > 1 else 0)
                self.loss_pct = round(100 * dl / (dl + dc), 1) if dl + dc > 0 else None
                last_count, last_loss, last_count_m, last_stat = self.count, loss, cnt, now
                self._rules(now)
                if self.transmit:
                    try:
                        self.conn.mav.heartbeat_send(ml.MAV_TYPE_GCS, ml.MAV_AUTOPILOT_INVALID, 0, 0, 0)
                        if tick % 2 == 0:
                            self.conn.mav.timesync_send(0, int(now * 1e9))
                        if self.upload and not self.upload["started"] and self.s.get("sysid"):
                            self.upload["started"] = True
                            self.conn.mav.mission_count_send(self.s["sysid"], self.s.get("compid", 1), len(self.upload["items"]))
                    except Exception as e:
                        self.error = f"Transmit error: {e}"
        try:
            self.conn.close()
        except Exception:
            pass
        self.stop_recording()

    def _update(self, msg, ml, mavutil):
        s, typ = self.s, msg.get_type()
        d = math.degrees
        if typ == "HEARTBEAT":
            if msg.type in (ml.MAV_TYPE_GCS, 18, 26, 27):
                return
            self.last_hb = time.time()
            s.update(sysid=msg.get_srcSystem(), compid=msg.get_srcComponent(), autopilot=AUTOPILOTS.get(msg.autopilot, f"Autopilot {msg.autopilot}"),
                     autopilot_id=int(msg.autopilot), vehicle_type=VEHICLES.get(msg.type, f"Type {msg.type}"),
                     armed=bool(msg.base_mode & ml.MAV_MODE_FLAG_SAFETY_ARMED))
            mode = fd.SIM_MODES.get(msg.custom_mode, f"MODE {msg.custom_mode}") if msg.autopilot == 0 else mavutil.mode_string_v10(msg)
            if mode != s.get("mode"):
                if s.get("mode"):
                    self.event("info", f"Flight mode {s['mode']} → {mode}")
                s["mode"] = mode
        elif typ == "ATTITUDE":
            s.update(roll=round(d(msg.roll), 2), pitch=round(d(msg.pitch), 2), yaw=round(d(msg.yaw) % 360, 1))
        elif typ == "GLOBAL_POSITION_INT":
            s.update(lat=msg.lat / 1e7, lon=msg.lon / 1e7, alt=round(msg.alt / 1000, 1), rel_alt=round(msg.relative_alt / 1000, 2),
                     gs=round(math.hypot(msg.vx, msg.vy) / 100, 2), climb=round(-msg.vz / 100, 2))
        elif typ == "VFR_HUD":
            s.update(throttle=msg.throttle, airspeed=round(msg.airspeed, 1))
            s.setdefault("gs", round(msg.groundspeed, 2))
        elif typ == "GPS_RAW_INT":
            s.update(gps_fix=msg.fix_type, sats=msg.satellites_visible if msg.satellites_visible != 255 else None,
                     hdop=round(msg.eph / 100, 2) if msg.eph != 65535 else None)
        elif typ == "SYS_STATUS":
            s.update(voltage=round(msg.voltage_battery / 1000, 2) if msg.voltage_battery not in (0, 65535) else None,
                     current=round(msg.current_battery / 100, 1) if msg.current_battery >= 0 else None,
                     remaining=msg.battery_remaining if msg.battery_remaining >= 0 else None, load=msg.load / 10)
            bad = msg.onboard_control_sensors_present & msg.onboard_control_sensors_enabled & ~msg.onboard_control_sensors_health
            s["sensors_unhealthy"] = [n for b, n in SENSOR_BITS.items() if bad & (1 << b)]
            s["sensors_present"] = [n for b, n in SENSOR_BITS.items() if msg.onboard_control_sensors_present & (1 << b)]
        elif typ == "BATTERY_STATUS":
            s["batt_temp"] = round(msg.temperature / 100, 1) if msg.temperature != 32767 else None
        elif typ == "RADIO_STATUS":
            s.update(rssi=msg.rssi, remrssi=msg.remrssi, radio_noise=msg.noise, rxerrors=msg.rxerrors)
        elif typ == "RC_CHANNELS" and msg.rssi != 255:
            s["rssi"] = msg.rssi
        elif typ == "STATUSTEXT":
            lvl = "critical" if msg.severity <= 2 else "warning" if msg.severity <= 4 else "info"
            self.event(lvl, f"Autopilot: {msg.text}")
        elif typ == "TIMESYNC" and msg.tc1 != 0 and msg.ts1:
            rtt = (time.time() * 1e9 - msg.ts1) / 1e6
            if 0 <= rtt < 10000:
                self.rtt_ms = round(rtt, 1)
        elif typ in ("MISSION_REQUEST_INT", "MISSION_REQUEST") and self.upload:
            it = self.upload["items"]
            if msg.seq < len(it):
                cmd, frame, p1, lat, lon, alt = it[msg.seq]
                self.conn.mav.mission_item_int_send(self.s.get("sysid", 1), self.s.get("compid", 1), msg.seq, frame, cmd, 0, 1, p1, 0, 0, 0,
                                                    int(lat * 1e7), int(lon * 1e7), alt)
                self.upload["sent"] = max(self.upload["sent"], msg.seq + 1)
        elif typ == "MISSION_ACK" and self.upload:
            self.upload["result"] = "accepted" if msg.type == ml.MAV_MISSION_ACCEPTED else f"rejected (MAV_MISSION_RESULT {msg.type})"

    def _rules(self, now):
        s = self.s
        if self.last_rx:
            silent = now - self.last_rx
            self.flag("link", silent > 3.0, "critical", "Communication loss — no telemetry received for more than 3 s")
        if self.last_hb:
            self.flag("hb", now - self.last_hb > 5.0 and now - self.last_rx <= 3.0, "warning", "Autopilot heartbeat missing for more than 5 s")
        rem = s.get("remaining")
        if rem is not None:
            self.flag("batt_crit", rem < 15, "critical", "Battery below 15%")
            self.flag("batt_low", 15 <= rem < 25, "warning", "Battery below 25%")
        if s.get("gps_fix") is not None:
            self.flag("gps_fix", s["gps_fix"] < 3 and bool(s.get("armed")), "critical", "GNSS 3D fix lost while armed")
        if s.get("sats") is not None:
            self.flag("sats", s["sats"] < 7, "warning", "Fewer than 7 satellites")
        if s.get("roll") is not None:
            self.flag("att", abs(s["roll"]) > 50 or abs(s.get("pitch", 0)) > 50, "warning", "Attitude excursion beyond 50°")
        self.flag("sensors", bool(s.get("sensors_unhealthy")), "warning", "Sensor health: " + ", ".join(s.get("sensors_unhealthy") or ["?"]) + " unhealthy")
        if self.loss_pct is not None:
            self.flag("loss", self.loss_pct > 10, "warning", "Packet loss above 10%")

    def snapshot(self) -> dict:
        now = time.time()
        age = round(now - self.last_rx, 1) if self.last_rx else None
        return {"key": self.key, "name": self.link_name, "source_class": self.source_class, "aircraft_id": self.aircraft_id, "link_id": self.link_id,
                "endpoint": self.conn_str, "transmit": self.transmit, "error": self.error,
                "status": "error" if self.error and not self.last_rx else "waiting" if not self.last_rx else "lost" if age > 3 else "connected",
                "age_s": age, "uptime_s": round(now - self.started), "msg_rate": round(self.rate, 1), "messages": self.count, "bytes": self.bytes,
                "packet_loss_pct": self.loss_pct, "rtt_ms": self.rtt_ms, "interruptions": self.interruptions, "warnings": sorted(self.active),
                "recording": {"active": bool(self.rec_file), "seconds": round(now - self.rec_start) if self.rec_file else 0, "name": self.rec_name},
                "sim": ({"phase": self.vehicle.sim.phase, "uploaded": self.vehicle.uploaded, "waypoint": self.vehicle.sim.i,
                         "waypoints": len(self.vehicle.sim.wps)} if self.vehicle else None),
                "state": dict(self.s), "events": self.events[-60:]}

    def stop(self):
        self.stop_evt.set()
        if self.vehicle:
            self.vehicle.stop()


class Hub:
    def __init__(self):
        self.runners: dict[str, LinkRunner] = {}

    def add(self, r: LinkRunner):
        old = self.runners.get(r.key)
        if old and old.is_alive():
            raise HTTPException(409, "This link is already connected.")
        self.runners[r.key] = r
        r.start()

    def get(self, key) -> LinkRunner:
        r = self.runners.get(key)
        if not r:
            raise HTTPException(404, "Link is not connected")
        return r

    def snapshot(self) -> dict:
        return {"links": [r.snapshot() for r in self.runners.values()], "ts": time.time()}

    def shutdown(self):
        for r in self.runners.values():
            r.stop()


hub = Hub()
BrowserSim = None
if config.BROWSER:
    from .browser import make_browser_sim

    BrowserSim = make_browser_sim(LinkRunner)


def _advance():
    """Browser edition: there is no simulator thread, so the status poll advances the in-process simulator."""
    for r in hub.runners.values():
        if BrowserSim is not None and isinstance(r, BrowserSim) and r.alive:
            r.advance()


def _free_udp_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


@router.get("/api/telemetry/ports")
def ports(u: m.User = Depends(internal_user)):
    try:
        from serial.tools import list_ports

        return [{"device": p.device, "description": p.description, "manufacturer": p.manufacturer} for p in list_ports.comports()]
    except Exception as e:
        return {"error": str(e)}


@router.get("/api/telemetry/status")
def status(u: m.User = Depends(internal_user)):
    _advance()
    return hub.snapshot()


@router.post("/api/telemetry/connect")
def connect(data: dict = Body(...), u: m.User = Depends(require(*CONNECTORS)), db: Db = Depends(get_db)):
    link = db.get(m.TelemetryLink, data.get("link_id") or 0)
    if not link:
        raise HTTPException(404, "Telemetry link not found")
    if config.BROWSER:
        raise HTTPException(409, "MAVLink links (UDP, TCP, serial) need the desktop edition: a browser tab cannot open sockets or serial ports. "
                                 "Use Simulation mode here.")
    if link.transport == "udp":
        cs = f"udpin:{link.address or '0.0.0.0'}:{link.port or 14550}"
    elif link.transport == "tcp":
        if not link.address:
            raise HTTPException(422, "A TCP link needs a remote host address.")
        cs = f"tcp:{link.address}:{link.port or 5760}"
    else:
        if not link.address:
            raise HTTPException(422, "A serial link needs a COM port.")
        cs = link.address
    r = LinkRunner(f"link{link.id}", link.name, cs, link.source_class, link.aircraft_id, link.baud if link.transport == "serial" else None,
                   bool(link.transmit), link.id)
    hub.add(r)
    audit(db, u, "link_connect", "telemetry_link", link.id, f"Opened telemetry link {link.name} ({cs}, declared {link.source_class}, "
          f"{'transmit enabled' if link.transmit else 'receive-only'})")
    db.commit()
    time.sleep(0.4)
    if r.error:
        hub.runners.pop(r.key, None)
        raise HTTPException(502, r.error)
    return r.snapshot()


@router.post("/api/telemetry/simulation/start")
def start_simulation(data: dict = Body({}), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    """Start the internal simulator as a MAVLink vehicle on a loopback port. Clearly labelled SIMULATION everywhere."""
    old = hub.runners.get("sim")
    if old and old.is_alive():
        raise HTTPException(409, "The simulation is already running.")
    ms = db.get(m.Mission, data.get("mission_id") or 0)
    ac = db.get(m.Aircraft, (ms.aircraft_id if ms else None) or data.get("aircraft_id") or 0)
    if ms and ms.home.get("lat") is not None and ms.waypoints:
        plan = missions.plan_of(ms)
    else:
        try:
            lat, lon = float(data["lat"]), float(data["lon"])
        except (KeyError, TypeError, ValueError):
            raise HTTPException(422, "Choose a mission with a home position and waypoints, or give a latitude / longitude for the demonstration circuit.")
        dn, de = 120 / 111_320.0, 160 / (111_320.0 * math.cos(math.radians(lat)))
        plan = {"home": {"lat": lat, "lon": lon, "alt": 0}, "cruise_speed": 8, "environment": {"wind_speed": 3, "wind_dir": 240},
                "waypoints": [{"lat": lat + dn, "lon": lon, "alt": 30}, {"lat": lat + dn, "lon": lon + de, "alt": 40, "hold_s": 5},
                              {"lat": lat - dn / 2, "lon": lon + de, "alt": 40}, {"lat": lat - dn / 2, "lon": lon - de / 2, "alt": 25}]}
    params = simulator.params_from_snapshot(fleet.snapshot(db, ac) if ac else None, plan.get("cruise_speed"))
    if BrowserSim is not None:
        r = BrowserSim("Internal simulator" + (f" · {ms.code}" if ms else " · demonstration circuit"), plan, params, data.get("faults") or [],
                       ac.id if ac else None, autostart=data.get("autostart", True))
        hub.add(r)
        audit(db, u, "sim_start", "telemetry", "sim", "Started internal simulation" + (f" of mission {ms.code}" if ms else ""), {"faults": data.get("faults")})
        db.commit()
        return r.snapshot()
    port = _free_udp_port()
    r = LinkRunner("sim", "Internal simulator" + (f" · {ms.code}" if ms else " · demonstration circuit"), f"udpin:127.0.0.1:{port}", "simulation",
                   ac.id if ac else None, transmit=True)
    hub.add(r)
    time.sleep(0.3)
    veh = simulator.MavVehicle(port, plan, params, data.get("faults") or [], autostart=data.get("autostart", True))
    r.vehicle = veh
    veh.start()
    audit(db, u, "sim_start", "telemetry", "sim", f"Started internal simulation" + (f" of mission {ms.code}" if ms else ""), {"faults": data.get("faults")})
    db.commit()
    return r.snapshot()


@router.post("/api/telemetry/simulation/launch")
def sim_launch(u: m.User = Depends(internal_user)):
    r = hub.get("sim")
    r.vehicle.sim.start()
    return r.snapshot()


@router.post("/api/telemetry/disconnect")
def disconnect(data: dict = Body(...), u: m.User = Depends(internal_user), db: Db = Depends(get_db)):
    r = hub.get(data.get("key"))
    if r.rec_file:
        raise HTTPException(409, "Stop the recording before closing the link.")
    r.stop()
    r.join(timeout=3)
    hub.runners.pop(r.key, None)
    audit(db, u, "link_disconnect", "telemetry_link", r.link_id or r.key, f"Closed telemetry link {r.link_name}")
    db.commit()
    return {"ok": True}


@router.post("/api/telemetry/record/start")
def record_start(data: dict = Body(...), u: m.User = Depends(require(*CONNECTORS)), db: Db = Depends(get_db)):
    r = hub.get(data.get("key"))
    try:
        r.start_recording(data.get("name") or f"{r.link_name} {datetime.now():%Y-%m-%d %H:%M}")
    except ValueError as e:
        raise HTTPException(409, str(e))
    r.event("info", "Recording started")
    audit(db, u, "record_start", "telemetry_link", r.link_id or r.key, f"Started telemetry recording on {r.link_name}")
    db.commit()
    return r.snapshot()


@router.post("/api/telemetry/record/stop")
def record_stop(data: dict = Body(...), u: m.User = Depends(require(*CONNECTORS)), db: Db = Depends(get_db)):
    r = hub.get(data.get("key"))
    if not r.rec_file:
        raise HTTPException(409, "This link is not recording.")
    marks = [{"t": e["rec_t"], "type": "anomaly", "text": e["text"], "severity": e["level"]} for e in r.events
             if e.get("rec_t") is not None and e["level"] in ("warning", "critical")]
    path, start, name = r.stop_recording()
    r.event("info", "Recording stopped")
    if BrowserSim is not None and isinstance(r, BrowserSim):  # here `path` is the in-memory recorder
        try:
            log = analysis.store_log(db, u, path, "simulation", "simulation", name, r.aircraft_id, data.get("mission_id"), extra_events=marks)
        except Exception as e:
            db.rollback()
            raise HTTPException(422, f"The recording could not be stored as a flight log: {e}")
        audit(db, u, "record_stop", "flight_log", log.id, f"Stored simulator recording as {log.code} (SIMULATION)")
        db.commit()
        return {"flight_log_id": log.id, "code": log.code, "source_class": log.source_class}
    try:
        rec = fd.parse_tlog(path)
        log = analysis.store_log(db, u, rec, "tlog", r.source_class, name, r.aircraft_id, data.get("mission_id"), original=path.read_bytes(),
                                 original_name=path.name, extra_events=marks)
    except Exception as e:
        db.rollback()
        raise HTTPException(422, f"The recording could not be stored as a flight log: {e}")
    finally:
        path.unlink(missing_ok=True)
    audit(db, u, "record_stop", "flight_log", log.id, f"Stored telemetry recording as {log.code} ({r.source_class.upper()})", {"sha256": log.sha256})
    db.commit()
    return {"flight_log_id": log.id, "code": log.code, "source_class": log.source_class}


@router.post("/api/telemetry/upload-mission")
def upload_mission(data: dict = Body(...), u: m.User = Depends(require(*CONNECTORS)), db: Db = Depends(get_db)):
    """Send a mission to the far end of a link. The platform never arms, launches or starts a mission on a physical aircraft."""
    r = hub.get(data.get("key"))
    ms = db.get(m.Mission, data.get("mission_id") or 0)
    if not ms:
        raise HTTPException(404, "Mission not found")
    blocked = missions.upload_check(db, ms, r.source_class)
    if blocked:
        audit(db, u, "upload_refused", "mission", ms.id, f"Mission upload of {ms.code} to {r.link_name} ({r.source_class}) refused", {"unmet": blocked})
        db.commit()
        raise HTTPException(409, {"message": f"Mission upload to a {r.source_class} link is not permitted.", "unmet": blocked})
    if BrowserSim is not None and isinstance(r, BrowserSim):
        wps = [{"lat": w["lat"], "lon": w["lon"], "alt": w["alt"], "hold_s": w.get("hold_s") or 0} for w in ms.waypoints or []]
        if r.sim.phase in ("STANDBY", "DONE"):
            r.sim.set_mission(wps)
            r.sim.done, r.sim.phase = False, "STANDBY"
        r.uploaded = len(wps)
        r.event("info", f"Mission {ms.code} rev {ms.revision} loaded into the simulator ({len(wps)} waypoints)")
        audit(db, u, "mission_upload", "mission", ms.id, f"Mission {ms.code} rev {ms.revision} loaded into the in-process simulator (SIMULATION)")
        db.commit()
        return {"ok": True, "items": len(wps), "note": "Mission loaded into the simulator. It flies it when on the ground: use Launch simulated flight."}
    if not r.transmit:
        raise HTTPException(409, "This link is receive-only. Enable “Transmit GCS heartbeat” on the link record to upload missions.")
    if not r.s.get("sysid"):
        raise HTTPException(409, "No autopilot heartbeat has been received on this link yet.")
    if r.source_class == "physical" and ms.aircraft_id != r.aircraft_id:
        raise HTTPException(409, "The mission's aircraft does not match the aircraft assigned to this link.")
    r.upload = {"items": missions.mav_items(ms, r.s.get("autopilot_id") == 3), "started": False, "sent": 0, "result": None}
    t0 = time.time()
    while time.time() - t0 < 12 and r.upload["result"] is None:
        time.sleep(0.1)
    res, sent, n = r.upload["result"], r.upload["sent"], len(r.upload["items"])
    r.upload = None
    audit(db, u, "mission_upload", "mission", ms.id, f"Mission {ms.code} rev {ms.revision} upload to {r.link_name} ({r.source_class.upper()}): {res or 'timed out'}",
          {"items": n, "sent": sent})
    db.commit()
    if res != "accepted":
        raise HTTPException(502, f"Mission upload failed: {res or 'no acknowledgement from the autopilot within 12 s'} ({sent}/{n} items sent).")
    r.event("info", f"Mission {ms.code} rev {ms.revision} uploaded ({n} items)")
    return {"ok": True, "items": n, "note": "Mission transferred. Arming and mission start remain with the operator at the control station."}


@router.websocket("/ws/telemetry")
async def ws_telemetry(ws: WebSocket):
    await ws.accept()
    try:
        first = await asyncio.wait_for(ws.receive_json(), timeout=5)
        with SessionLocal() as db:
            u = user_from_token(db, first.get("token"))
        if not u or u.role == "customer":
            await ws.close(code=4401)
            return
        while True:
            await ws.send_json(hub.snapshot())
            await asyncio.sleep(0.2)
    except (WebSocketDisconnect, asyncio.TimeoutError, RuntimeError):
        return
