"""Internal kinematic flight simulator.

This is a point-mass kinematic and energy model for mission rehearsal, demonstrations and training. It is NOT a
flight-dynamics or SITL simulation and its output is always labelled as simulation. It can run faster than real time
(mission simulation) or in real time as a MAVLink vehicle emulator (telemetry demonstration mode).
"""
import math
import random
import threading
import time
from dataclasses import dataclass, field

from .flightdata import G, Recorder

RHO = 1.225


@dataclass
class VehicleParams:
    kind: str = "multicopter"  # multicopter / fixedwing
    mass_kg: float = 2.0
    cells: int = 4
    capacity_mah: float = 5000.0
    rotors: int = 4
    prop_in: float | None = None
    cruise: float = 8.0
    climb_rate: float = 3.0
    descent_rate: float = 1.5
    accel: float = 3.0
    assumptions: list = field(default_factory=list)

    def hover_power(self) -> float:
        if self.kind == "fixedwing":
            return self.mass_kg * G * self.cruise / 8.0 / 0.6  # L/D 8, propulsive efficiency 0.6
        if self.prop_in:
            area = self.rotors * math.pi * (self.prop_in * 0.0254 / 2) ** 2
            return (self.mass_kg * G) ** 1.5 / math.sqrt(2 * RHO * area) / (0.6 * 0.8)  # figure of merit × drive efficiency
        return 170.0 * self.mass_kg


def params_from_snapshot(snap: dict | None, cruise: float | None = None) -> VehicleParams:
    """Derive simulator parameters from an aircraft configuration snapshot, recording every assumption made."""
    p = VehicleParams()
    if cruise:
        p.cruise = float(cruise)
    if not snap:
        p.assumptions.append("No aircraft configuration: generic 2 kg quadcopter with a 4S 5000 mAh pack assumed.")
        return p
    ac, comps = snap["aircraft"], snap["components"]
    typ = ac.get("aircraft_type") or ""
    p.kind = "fixedwing" if typ == "Fixed-wing" else "multicopter"
    if p.kind == "fixedwing" and not cruise:
        p.cruise = 16.0
    if ac.get("mtom_kg"):
        p.mass_kg = float(ac["mtom_kg"])
    else:
        p.assumptions.append("MTOM not recorded: 2 kg assumed.")

    def num(c, k):
        try:
            return float(c["specs"].get(k))
        except (TypeError, ValueError):
            return None

    batts = [c for c in comps if c["category"] == "Battery"]
    caps = [num(b, "capacity_mah") for b in batts]
    cells = [num(b, "cells") for b in batts]
    if batts and all(caps) and all(cells):
        p.capacity_mah, p.cells = sum(caps), int(cells[0])
    else:
        p.assumptions.append("Battery capacity / cell count not recorded: 4S 5000 mAh assumed.")
    motors = [c for c in comps if c["category"] == "Motor"]
    p.rotors = max(1, len(motors)) if motors else 4
    dia = [num(c, "diameter_in") for c in comps if c["category"] == "Propeller"]
    if dia and all(dia):
        p.prop_in = sum(dia) / len(dia)
    elif p.kind == "multicopter":
        p.assumptions.append("Propeller diameter not recorded: hover power estimated at 170 W/kg.")
    return p


class Sim:
    def __init__(self, mission: dict, params: VehicleParams, faults: list | None = None, seed: int = 1, autostart: bool = True):
        self.p = params
        self.rng = random.Random(seed)
        self.faults = faults or []
        self.home = mission.get("home") or {}
        self.lat0, self.lon0 = float(self.home.get("lat", 0)), float(self.home.get("lon", 0))
        self.alt0 = float(self.home.get("alt", 0) or 0)
        env = mission.get("environment") or {}
        ws, wd = float(env.get("wind_speed") or 0), math.radians(float(env.get("wind_dir") or 0))
        self.wind = (-ws * math.cos(wd), -ws * math.sin(wd))  # wind_dir is where the wind blows FROM
        self.temp_amb = float(env.get("temperature") or 20)
        self.set_mission(mission.get("waypoints") or [], mission.get("cruise_speed"))
        self.t = 0.0
        self.n = self.e = self.h = 0.0
        self.vn = self.ve = self.vd = 0.0
        self.roll = self.pitch = 0.0
        self.yaw = 0.0
        self.p_rate = self.q_rate = self.r_rate = 0.0
        self.soc, self.mah, self.volt, self.cur = 1.0, 0.0, self.p.cells * 4.2, 0.0
        self.batt_temp = self.temp_amb
        self.phase = "TAKEOFF" if autostart and self.wps else "STANDBY"
        self.hold = 0.0
        self.dist = 0.0
        self.max_home = 0.0
        self.messages: list = []  # (severity, text) drained by the caller
        self.done = False
        self.completed = False
        self.failsafe = False
        self.throttle = 0.0
        self.acc = (0.0, 0.0, -G)
        self.xtrack = 0.0
        if self.phase == "TAKEOFF":
            self.say(6, "SIM: take-off")

    # mission geometry in metres north / east of home
    def set_mission(self, wps: list, cruise=None):
        if cruise:
            self.p.cruise = float(cruise)
        self.wps = []
        for w in wps:
            n = (float(w["lat"]) - self.lat0) * 111_320.0
            e = (float(w["lon"]) - self.lon0) * 111_320.0 * math.cos(math.radians(self.lat0))
            self.wps.append({"n": n, "e": e, "alt": float(w.get("alt") or 20), "speed": float(w.get("speed") or 0) or None,
                             "hold": float(w.get("hold_s") or 0)})
        self.i = 0

    def start(self):
        if self.phase == "STANDBY" and self.wps:
            self.phase, self.i, self.done = "TAKEOFF", 0, False
            self.say(6, "SIM: take-off")

    def say(self, sev, text):
        self.messages.append((sev, text))

    def fault(self, kind: str) -> bool:
        return any(f.get("type") == kind and f.get("at_s", 0) <= self.t < f.get("at_s", 0) + f.get("duration_s", 30) for f in self.faults)

    @property
    def lat(self):
        return self.lat0 + self.n / 111_320.0

    @property
    def lon(self):
        return self.lon0 + self.e / (111_320.0 * math.cos(math.radians(self.lat0)))

    @property
    def mode_id(self):
        return {"STANDBY": 0, "TAKEOFF": 1, "MISSION": 2, "RTL": 3, "LAND": 4, "DONE": 0}.get(self.phase, 5)

    def _goto(self, tn, te, talt, speed, dt, radius):
        dn, de = tn - self.n, te - self.e
        dist = math.hypot(dn, de)
        fw = self.p.kind == "fixedwing"
        v_cmd = speed if fw else min(speed, math.sqrt(2 * self.p.accel * max(dist - radius * 0.5, 0)) + 0.3)
        brg = math.atan2(de, dn) if dist > 0.05 else self.yaw
        if fw:
            err = (brg - self.yaw + math.pi) % (2 * math.pi) - math.pi
            bank = max(-0.52, min(0.52, 1.5 * err))
            v = max(math.hypot(self.vn, self.ve), 0.6 * speed)
            v += max(-self.p.accel * dt, min(self.p.accel * dt, speed - v))
            self.r_rate = G * math.tan(bank) / max(v, 5)
            self.yaw = (self.yaw + self.r_rate * dt) % (2 * math.pi)
            cn, ce = v * math.cos(self.yaw), v * math.sin(self.yaw)
            an, ae = (cn - self.vn) / dt, (ce - self.ve) / dt
            self.vn, self.ve = cn, ce
            tgt_roll = bank
        else:
            cn, ce = v_cmd * math.cos(brg), v_cmd * math.sin(brg)
            an, ae = (cn - self.vn) / dt, (ce - self.ve) / dt
            a = math.hypot(an, ae)
            if a > self.p.accel:
                an, ae = an * self.p.accel / a, ae * self.p.accel / a
            self.vn += an * dt
            self.ve += ae * dt
            if math.hypot(self.vn, self.ve) > 1.0:
                want = math.atan2(self.ve, self.vn)
                err = (want - self.yaw + math.pi) % (2 * math.pi) - math.pi
                self.r_rate = max(-1.5, min(1.5, 2 * err))
                self.yaw = (self.yaw + self.r_rate * dt) % (2 * math.pi)
            else:
                self.r_rate = 0.0
            tgt_roll = None
        # vertical
        dh = talt - self.h
        vz = max(-self.p.descent_rate, min(self.p.climb_rate, 1.2 * dh))
        self.vd = -vz
        # wind: a small part of the wind is not rejected by the position controller
        self.n += (self.vn + 0.06 * self.wind[0]) * dt
        self.e += (self.ve + 0.06 * self.wind[1]) * dt
        self.h = max(0.0, self.h + vz * dt)
        # attitude from the commanded acceleration plus drag of the air-relative velocity
        van, vae = self.vn - self.wind[0], self.ve - self.wind[1]
        fn, fe = an + 0.018 * van * abs(van), ae + 0.018 * vae * abs(vae)  # drag-equivalent acceleration, ~12 deg tilt at 11 m/s airspeed
        cy, sy = math.cos(self.yaw), math.sin(self.yaw)
        f_fwd, f_right = fn * cy + fe * sy, -fn * sy + fe * cy
        gust = 0.004 * math.hypot(*self.wind)
        new_pitch = (0.05 if fw else -math.atan2(f_fwd, G)) + self.rng.gauss(0, 0.003 + gust)
        new_roll = (tgt_roll if tgt_roll is not None else math.atan2(f_right, G)) + self.rng.gauss(0, 0.003 + gust)
        self.q_rate, self.p_rate = (new_pitch - self.pitch) / dt * 0.2, (new_roll - self.roll) / dt * 0.2
        self.pitch += (new_pitch - self.pitch) * 0.2
        self.roll += (new_roll - self.roll) * 0.2
        self.acc_h = (f_fwd, f_right)
        return dist, abs(dh)

    def step(self, dt: float):
        if self.done:
            return
        self.t += dt
        p = self.p
        radius = 20.0 if p.kind == "fixedwing" else 2.0
        vz_before = -self.vd
        if self.phase == "STANDBY":
            self.vn = self.ve = self.vd = 0.0
            self.acc_h = (0.0, 0.0)
        elif self.phase == "TAKEOFF":
            alt = self.wps[0]["alt"] if self.wps else 10.0
            if p.kind == "fixedwing":
                _, dh = self._goto(self.n + 200 * math.cos(self.yaw), self.e + 200 * math.sin(self.yaw), alt, p.cruise, dt, radius)
            else:
                _, dh = self._goto(self.n, self.e, alt, 0.0, dt, radius)
            if dh < 1.0:
                self.phase = "MISSION"
                self.say(6, "SIM: mission started")
        elif self.phase == "MISSION":
            w = self.wps[self.i]
            dist, dh = self._goto(w["n"], w["e"], w["alt"], w["speed"] or p.cruise, dt, radius)
            if self.i > 0:
                a = self.wps[self.i - 1]
                ln = math.hypot(w["n"] - a["n"], w["e"] - a["e"])
                self.xtrack = ((self.n - a["n"]) * (w["e"] - a["e"]) - (self.e - a["e"]) * (w["n"] - a["n"])) / ln if ln > 1 else 0.0
            if dist < radius and dh < 1.5:
                self.hold += dt
                if self.hold >= w["hold"]:
                    self.hold = 0.0
                    self.say(6, f"SIM: reached waypoint {self.i + 1}")
                    self.i += 1
                    if self.i >= len(self.wps):
                        self.phase, self.completed = "RTL", True
                        self.say(6, "SIM: mission complete — returning to launch")
        elif self.phase == "RTL":
            dist, _ = self._goto(0.0, 0.0, max(self.h, 15.0 if p.kind == "multicopter" else 30.0), p.cruise, dt, radius)
            if dist < radius * (1 if p.kind == "multicopter" else 2):
                self.phase = "LAND"
                self.say(6, "SIM: landing")
        elif self.phase == "LAND":
            if p.kind == "fixedwing":
                self._goto(self.n + 60 * math.cos(self.yaw + 1.2), self.e + 60 * math.sin(self.yaw + 1.2), 0.0, p.cruise * 0.8, dt, radius)
            else:
                self._goto(0.0, 0.0, 0.0, 0.5, dt, radius)
            if self.h <= 0.05:
                self.phase, self.done = "DONE", True
                self.vn = self.ve = self.vd = 0.0
                self.say(6, "SIM: landed")
        # energy
        flying = self.phase not in ("STANDBY", "DONE")
        v = math.hypot(self.vn, self.ve)
        if flying:
            vz = -self.vd
            if p.kind == "fixedwing":
                power = p.hover_power() * (v / p.cruise) ** 2 * (1 if v > 1 else 0) + max(0.0, p.mass_kg * G * vz / 0.6) + 8
            else:
                power = p.hover_power() * (1 + 0.003 * v * v) + p.mass_kg * G * vz / (0.7 if vz > 0 else 3.0) + 8
            power = max(power, 5.0)
        else:
            power = 6.0
        r_pack = 0.0035 * p.cells * (5000.0 / max(p.capacity_mah, 500)) * (3.0 if self.fault("battery_sag") else 1.0)
        ocv = p.cells * (3.3 + 0.9 * self.soc)
        self.cur = power / max(self.volt, p.cells * 2.5)
        self.volt = ocv - self.cur * r_pack
        self.mah += self.cur * dt / 3.6
        self.soc = max(0.0, 1 - self.mah / p.capacity_mah)
        pack_kg = p.cells * p.capacity_mah / 1000 * 0.022
        self.batt_temp += (self.cur ** 2 * r_pack / (900 * pack_kg) - (self.batt_temp - self.temp_amb) / 600) * dt
        self.power = power
        self.throttle = min(1.0, math.sqrt(power / (p.hover_power() * 2.83))) if flying else 0.0
        vib = 0.35 * (12.0 if self.fault("vibration") else 1.0) if flying else 0.02
        az = -(G + (-self.vd - vz_before) / dt * 0.2) if flying else -G
        ph = 2 * math.pi * 118 * self.t
        self.acc = (self.acc_h[0] * 0.2 + vib * math.sin(ph) + self.rng.gauss(0, vib * 0.5),
                    self.acc_h[1] * 0.2 + vib * math.cos(ph) + self.rng.gauss(0, vib * 0.5),
                    az + 1.4 * vib * math.sin(ph + 0.7) + self.rng.gauss(0, vib * 0.6))
        home_d = math.hypot(self.n, self.e)
        self.max_home = max(self.max_home, home_d)
        self.dist += v * dt
        if flying and self.soc < 0.15 and not self.failsafe and self.phase in ("TAKEOFF", "MISSION"):
            self.failsafe, self.phase = True, "RTL"
            self.say(2, "Failsafe: low battery — returning to launch")
        if flying and self.soc <= 0.01:
            self.done, self.phase = True, "DONE"
            self.say(1, "SIM: battery depleted before landing")

    def gps(self):
        if self.fault("gps_degrade"):
            return 2, 5, 4.8
        return 3, 14, 0.7

    def motors(self):
        out = []
        for k in range(self.p.rotors if self.p.kind == "multicopter" else 1):
            ang = 2 * math.pi * (k + 0.5) / max(self.p.rotors, 1)
            mix = 0.25 * (self.roll * math.sin(ang) + self.pitch * math.cos(ang))
            thr = max(0.0, min(1.0, self.throttle * (1 + 0.012 * ((k % 3) - 1)) + mix))
            out.append(1000 + 1000 * thr if self.phase not in ("STANDBY", "DONE") else 1000)
        return out


def run_offline(mission: dict, params: VehicleParams, faults: list | None = None, max_time: float = 7200.0) -> tuple[Recorder, dict]:
    """Faster-than-real-time mission simulation. Returns the recorded channels and a summary."""
    sim = Sim(mission, params, faults)
    rec = Recorder()
    rec.info["autopilot"] = 0
    dt, k = 0.02, 0
    last_mode = None
    track = []
    while not sim.done and sim.t < max_time:
        sim.step(dt)
        t = sim.t
        rec.acc.append((t, *sim.acc))
        if k % 5 == 0:
            d = math.degrees
            fix, sats, hdop = sim.gps()
            for name, val in (("lat", sim.lat), ("lon", sim.lon), ("alt", sim.alt0 + sim.h), ("rel_alt", sim.h), ("gs", math.hypot(sim.vn, sim.ve)),
                              ("climb", -sim.vd), ("roll", d(sim.roll)), ("pitch", d(sim.pitch)), ("yaw", d(sim.yaw) % 360),
                              ("rollspeed", d(sim.p_rate)), ("pitchspeed", d(sim.q_rate)), ("yawspeed", d(sim.r_rate)),
                              ("voltage", sim.volt), ("current", sim.cur), ("remaining", sim.soc * 100), ("mah", sim.mah),
                              ("batt_temp", sim.batt_temp), ("gps_fix", fix), ("sats", sats), ("hdop", hdop), ("xtrack", sim.xtrack)):
                rec.add(name, t, val)
            for j, pwm in enumerate(sim.motors()):
                rec.add(f"m{j + 1}", t, pwm)
            rec.arrivals.append(t)
            if k % 50 == 0:
                track.append((sim.lat, sim.lon, sim.h))
        if sim.phase != last_mode:
            last_mode = sim.phase
            rec.mode(t, "STANDBY" if sim.phase == "DONE" else sim.phase)
        for sev, text in sim.messages:
            rec.text(t, text, sev)
        sim.messages.clear()
        k += 1
    summary = {"completed": sim.completed and sim.phase == "DONE" and not sim.failsafe, "landed": sim.phase == "DONE" and sim.h <= 0.1,
               "timed_out": not sim.done, "failsafe": sim.failsafe, "flight_time_s": round(sim.t, 1), "distance_m": round(sim.dist),
               "mah_used": round(sim.mah), "min_remaining_pct": round(sim.soc * 100, 1), "max_distance_home_m": round(sim.max_home),
               "min_voltage": round(sim.volt, 2), "hover_power_w": round(params.hover_power(), 1), "assumptions": params.assumptions,
               "track": track}
    return rec, summary


class MavVehicle(threading.Thread):
    """Real-time MAVLink emulator of the internal simulator. It identifies itself as MAV_AUTOPILOT_GENERIC and every
    consumer in the platform labels its data as SIMULATION."""

    def __init__(self, port: int, mission: dict, params: VehicleParams, faults: list | None = None, autostart: bool = True):
        super().__init__(daemon=True, name=f"sim-vehicle-{port}")
        self.port, self.sim = port, Sim(mission, params, faults, autostart=autostart)
        self.stop_evt = threading.Event()
        self.items: dict = {}
        self.expect = 0
        self.uploaded = 0

    def stop(self):
        self.stop_evt.set()

    def run(self):
        import socket

        from pymavlink.dialects.v20 import ardupilotmega as ml

        # Own socket on an ephemeral port (pymavlink's udpout binds the destination port on Windows, which
        # would make the ground station's replies loop back to itself).
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(("127.0.0.1", 0))
        sock.setblocking(False)
        dest = ("127.0.0.1", self.port)

        class _Out:
            @staticmethod
            def write(buf):
                try:
                    sock.sendto(buf, dest)
                except OSError:
                    pass

        m_ = ml.MAVLink(_Out(), srcSystem=1, srcComponent=1)
        sim, k, dt = self.sim, 0, 0.02
        nxt = time.perf_counter()
        while not self.stop_evt.is_set():
            sim.step(dt)
            ms = int(sim.t * 1000) & 0xFFFFFFFF
            silent = sim.fault("link_loss")
            try:
                if not silent:
                    m_.scaled_imu_send(ms, int(sim.acc[0] / G * 1000), int(sim.acc[1] / G * 1000), int(sim.acc[2] / G * 1000),
                                       int(sim.p_rate * 1000), int(sim.q_rate * 1000), int(sim.r_rate * 1000), 0, 0, 0)
                    if k % 5 == 0:
                        m_.attitude_send(ms, sim.roll, sim.pitch, (sim.yaw + math.pi) % (2 * math.pi) - math.pi, sim.p_rate, sim.q_rate, sim.r_rate)
                    if k % 10 == 0:
                        hdg = int(math.degrees(sim.yaw) % 360 * 100)
                        m_.global_position_int_send(ms, int(sim.lat * 1e7), int(sim.lon * 1e7), int((sim.alt0 + sim.h) * 1000), int(sim.h * 1000),
                                                    int(sim.vn * 100), int(sim.ve * 100), int(sim.vd * 100), hdg)
                        m_.vfr_hud_send(math.hypot(sim.vn, sim.ve), math.hypot(sim.vn, sim.ve), int(math.degrees(sim.yaw) % 360),
                                        int(sim.throttle * 100), sim.alt0 + sim.h, -sim.vd)
                        pw = (sim.motors() + [0] * 8)[:8]
                        m_.servo_output_raw_send(ms * 1000 & 0xFFFFFFFF, 0, *[int(x) for x in pw])
                    if k % 25 == 0:
                        fix, sats, hdop = sim.gps()
                        m_.gps_raw_int_send(int(sim.t * 1e6), fix, int(sim.lat * 1e7), int(sim.lon * 1e7), int((sim.alt0 + sim.h) * 1000),
                                            int(hdop * 100), int(hdop * 130), int(math.hypot(sim.vn, sim.ve) * 100), 0, sats)
                        sensors = 0x2F | (0 if fix < 3 else 0x20)
                        health = sensors if fix >= 3 else sensors & ~0x20
                        m_.sys_status_send(sensors | 0x20, sensors | 0x20, health, 320, int(sim.volt * 1000), int(sim.cur * 100), int(sim.soc * 100), 0, 0, 0, 0, 0, 0)
                        m_.nav_controller_output_send(math.degrees(sim.roll), math.degrees(sim.pitch), 0, 0, 0, 0, 0, sim.xtrack)
                    if k % 50 == 0:
                        armed = sim.phase not in ("STANDBY", "DONE")
                        m_.heartbeat_send(ml.MAV_TYPE_FIXED_WING if sim.p.kind == "fixedwing" else ml.MAV_TYPE_QUADROTOR, ml.MAV_AUTOPILOT_GENERIC,
                                          ml.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED | (ml.MAV_MODE_FLAG_SAFETY_ARMED if armed else 0), sim.mode_id,
                                          ml.MAV_STATE_ACTIVE if armed else ml.MAV_STATE_STANDBY)
                        volts = [int(sim.volt / sim.p.cells * 1000)] * min(sim.p.cells, 10) + [65535] * (10 - min(sim.p.cells, 10))
                        m_.battery_status_send(0, 1, 1, int(sim.batt_temp * 100), volts, int(sim.cur * 100), int(sim.mah), -1, int(sim.soc * 100))
                    for sev, text in sim.messages:
                        m_.statustext_send(sev, text.encode()[:50])
                    sim.messages.clear()
                while True:
                    try:
                        data, _addr = sock.recvfrom(4096)
                    except OSError:
                        break
                    for msg in m_.parse_buffer(data) or []:
                        if msg.get_type() != "BAD_DATA" and not silent:  # a lost link is lost in both directions
                            self._handle(m_, ml, msg)
            except (OSError, ml.MAVError):
                pass
            k += 1
            nxt += dt
            delay = nxt - time.perf_counter()
            if delay > 0:
                time.sleep(delay)
            elif delay < -1:
                nxt = time.perf_counter()
        sock.close()

    def _handle(self, m_, ml, msg):
        typ = msg.get_type()
        if typ == "TIMESYNC" and msg.tc1 == 0:
            m_.timesync_send(int(time.time() * 1e9), msg.ts1)
        elif typ == "MISSION_COUNT":
            self.items, self.expect = {}, msg.count
            if msg.count:
                m_.mission_request_int_send(msg.get_srcSystem(), msg.get_srcComponent(), 0)
        elif typ == "MISSION_ITEM_INT" and self.expect:
            self.items[msg.seq] = msg
            if msg.seq + 1 < self.expect:
                m_.mission_request_int_send(msg.get_srcSystem(), msg.get_srcComponent(), msg.seq + 1)
            else:
                m_.mission_ack_send(msg.get_srcSystem(), msg.get_srcComponent(), ml.MAV_MISSION_ACCEPTED)
                wps = [{"lat": it.x / 1e7, "lon": it.y / 1e7, "alt": it.z, "hold_s": it.param1}
                       for _, it in sorted(self.items.items()) if it.command == ml.MAV_CMD_NAV_WAYPOINT]
                self.uploaded, self.expect = len(wps), 0
                if self.sim.phase in ("STANDBY", "DONE"):
                    self.sim.set_mission(wps)
                    self.sim.done, self.sim.phase = False, "STANDBY"
                self.sim.say(6, f"SIM: mission received ({len(wps)} waypoints)")
