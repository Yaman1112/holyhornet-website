"""Livestock Guardian services: registry, tracking, movement + health analysis, water and grazing."""

from __future__ import annotations

from datetime import date, datetime, timedelta

import numpy as np
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..engines import health as health_engine
from ..engines import movement
from ..engines.environment import biomass_estimate, drought_indicator, grazing_recommendations, water_forecast
from ..errors import Invalid
from ..models import (Alert, Animal, Area, CollarTelemetry, Device, Farm, HealthObservation, Herd, MovementEvent,
                      SpeciesProfile, Treatment, Vaccination, VegetationObservation, WaterObservation, WaterPoint)
from ..rbac import HEALTH_REVIEW, LIVESTOCK_READ, LIVESTOCK_WRITE, Principal
from . import alerts, events
from .common import audit, get_scoped, ser


def _farm_filter(q, model, p: Principal):
    fs = p.farm_scope
    if fs is not None:
        q = q.where(model.farm_id.in_(fs))
    return q


# ------------------------------------------------------------------ registry


def list_farms(db: Session, p: Principal):
    p.require(LIVESTOCK_READ)
    q = select(Farm).where(Farm.org_id == p.org_id)
    if p.farm_scope is not None:
        q = q.where(Farm.id.in_(p.farm_scope))
    out = []
    for f in db.scalars(q.order_by(Farm.name)):
        d = ser(f)
        d["animals"] = db.scalar(select(func.count()).select_from(Animal).where(Animal.farm_id == f.id, Animal.status != "sold"))
        d["herds"] = [ser(h) for h in db.scalars(select(Herd).where(Herd.farm_id == f.id))]
        out.append(d)
    return out


def create_farm(db: Session, p: Principal, data: dict):
    p.require(LIVESTOCK_WRITE)
    f = Farm(org_id=p.org_id, **{k: data[k] for k in ("name", "owner_name", "village", "district", "region", "lat", "lon",
                                                       "boundary_area_id") if k in data})
    db.add(f)
    db.flush()
    audit(db, p, "farm.create", "farm", f.id)
    return ser(f)


def create_herd(db: Session, p: Principal, data: dict):
    p.require(LIVESTOCK_WRITE)
    get_scoped(db, Farm, data["farm_id"], p)
    h = Herd(org_id=p.org_id, farm_id=data["farm_id"], name=data["name"], species=data.get("species", "cattle"),
             grazing_area_id=data.get("grazing_area_id"))
    db.add(h)
    db.flush()
    return ser(h)


def species_profiles(db: Session):
    return [ser(s) for s in db.scalars(select(SpeciesProfile).order_by(SpeciesProfile.name))]


def list_animals(db: Session, p: Principal, farm_id=None, herd_id=None, status=None, q_text=None):
    p.require(LIVESTOCK_READ)
    q = _farm_filter(select(Animal).where(Animal.org_id == p.org_id), Animal, p)
    if farm_id:
        q = q.where(Animal.farm_id == farm_id)
    if herd_id:
        q = q.where(Animal.herd_id == herd_id)
    if status:
        q = q.where(Animal.status == status)
    if q_text:
        like = f"%{q_text}%"
        q = q.where((Animal.tag.ilike(like)) | (Animal.name.ilike(like)))
    animals = list(db.scalars(q.order_by(Animal.tag)))
    latest = _latest_health(db, [a.id for a in animals])
    devs = {d.animal_id: d for d in db.scalars(select(Device).where(Device.org_id == p.org_id, Device.animal_id.isnot(None)))}
    out = []
    for a in animals:
        d = ser(a, exclude=("baseline",))
        h = latest.get(a.id)
        d["health_level"] = h.level if h else None
        dev = devs.get(a.id)
        d["collar"] = None if not dev else {"id": dev.id, "battery_pct": dev.battery_pct, "connectivity": dev.connectivity}
        out.append(d)
    return out


def _latest_health(db: Session, ids: list[str]) -> dict:
    if not ids:
        return {}
    sub = (select(HealthObservation.animal_id, func.max(HealthObservation.observed_at).label("m"))
           .where(HealthObservation.animal_id.in_(ids)).group_by(HealthObservation.animal_id).subquery())
    rows = db.scalars(select(HealthObservation).join(sub, (HealthObservation.animal_id == sub.c.animal_id)
                                                     & (HealthObservation.observed_at == sub.c.m)))
    return {h.animal_id: h for h in rows}


def create_animal(db: Session, p: Principal, data: dict):
    p.require(LIVESTOCK_WRITE)
    farm = get_scoped(db, Farm, data["farm_id"], p)
    if p.farm_scope is not None and farm.id not in p.farm_scope:
        raise Invalid("farm outside your scope")
    if not db.get(SpeciesProfile, data.get("species", "")):
        raise Invalid("unknown species profile")
    if db.scalar(select(Animal).where(Animal.org_id == p.org_id, Animal.tag == data["tag"])):
        raise Invalid("tag already used in this organisation")
    bd = data.get("birth_date")
    a = Animal(org_id=p.org_id, farm_id=farm.id, herd_id=data.get("herd_id"), tag=data["tag"], name=data.get("name", ""),
               species=data["species"], breed=data.get("breed", ""), sex=data.get("sex", "unknown"),
               birth_date=date.fromisoformat(bd) if isinstance(bd, str) and bd else None,
               age_estimate_months=data.get("age_estimate_months"), notes=data.get("notes", ""))
    db.add(a)
    db.flush()
    audit(db, p, "animal.create", "animal", a.id, {"tag": a.tag})
    return ser(a)


def update_animal(db: Session, p: Principal, animal_id: str, data: dict):
    p.require(LIVESTOCK_WRITE)
    a = get_scoped(db, Animal, animal_id, p)
    for k in ("name", "breed", "sex", "status", "herd_id", "notes", "age_estimate_months", "photo_url"):
        if k in data:
            setattr(a, k, data[k])
    audit(db, p, "animal.update", "animal", a.id, data)
    return ser(a, exclude=("baseline",))


def animal_profile(db: Session, p: Principal, animal_id: str, now: datetime | None = None):
    p.require(LIVESTOCK_READ)
    a = get_scoped(db, Animal, animal_id, p)
    if p.farm_scope is not None and a.farm_id not in p.farm_scope:
        raise Invalid("animal outside your scope")
    d = ser(a)
    d["farm"] = ser(db.get(Farm, a.farm_id))
    d["herd"] = ser(db.get(Herd, a.herd_id)) if a.herd_id else None
    d["species_profile"] = ser(db.get(SpeciesProfile, a.species))
    d["devices"] = [ser(x) for x in db.scalars(select(Device).where(Device.animal_id == a.id))]
    d["health"] = [ser(h) for h in db.scalars(select(HealthObservation).where(HealthObservation.animal_id == a.id)
                                             .order_by(HealthObservation.observed_at.desc()).limit(40))]
    d["vaccinations"] = [ser(v) for v in db.scalars(select(Vaccination).where(Vaccination.animal_id == a.id).order_by(Vaccination.given_on.desc()))]
    d["treatments"] = [ser(t) for t in db.scalars(select(Treatment).where(Treatment.animal_id == a.id).order_by(Treatment.started_on.desc()))]
    d["events"] = [ser(e) for e in db.scalars(select(MovementEvent).where(MovementEvent.animal_id == a.id)
                                             .order_by(MovementEvent.detected_at.desc()).limit(40))]
    d["alerts"] = [ser(x) for x in db.scalars(select(Alert).where(Alert.subject_id == a.id).order_by(Alert.created_at.desc()).limit(40))]
    return d


def track(db: Session, p: Principal, animal_id: str, start: datetime | None, end: datetime | None, max_points=2000):
    p.require(LIVESTOCK_READ)
    a = get_scoped(db, Animal, animal_id, p)
    q = select(CollarTelemetry).where(CollarTelemetry.animal_id == a.id)
    if start:
        q = q.where(CollarTelemetry.recorded_at >= start)
    if end:
        q = q.where(CollarTelemetry.recorded_at <= end)
    rows = list(db.scalars(q.order_by(CollarTelemetry.recorded_at)))
    step = max(1, len(rows) // max_points)
    return [{"t": r.recorded_at.isoformat(), "lat": r.lat, "lon": r.lon, "activity": r.activity, "temp_c": r.temp_c,
             "rest_fraction": r.rest_fraction, "speed_mps": r.speed_mps, "battery_pct": r.battery_pct,
             "delay_min": round((r.received_at - r.recorded_at).total_seconds() / 60, 1)} for r in rows[::step]]


def add_vaccination(db: Session, p: Principal, animal_id: str, data: dict):
    p.require(LIVESTOCK_WRITE)
    a = get_scoped(db, Animal, animal_id, p)
    v = Vaccination(org_id=p.org_id, animal_id=a.id, vaccine=data["vaccine"], given_on=date.fromisoformat(data["given_on"]),
                    next_due=date.fromisoformat(data["next_due"]) if data.get("next_due") else None,
                    administered_by=data.get("administered_by", p.name), batch=data.get("batch", ""))
    db.add(v)
    audit(db, p, "vaccination.add", "animal", a.id, data)
    db.flush()
    return ser(v)


def add_treatment(db: Session, p: Principal, animal_id: str, data: dict):
    p.require(LIVESTOCK_WRITE, HEALTH_REVIEW)  # treatment records are entered by veterinary professionals
    a = get_scoped(db, Animal, animal_id, p)
    t = Treatment(org_id=p.org_id, animal_id=a.id, started_on=date.fromisoformat(data["started_on"]),
                  condition=data["condition"], treatment=data["treatment"],
                  withdrawal_until=date.fromisoformat(data["withdrawal_until"]) if data.get("withdrawal_until") else None,
                  vet_name=data.get("vet_name", p.name))
    db.add(t)
    audit(db, p, "treatment.add", "animal", a.id, {"condition": data["condition"]})
    db.flush()
    return ser(t)


# ------------------------------------------------------------------ health observations


def list_health(db: Session, p: Principal, level: str | None = None, review_status: str | None = None, limit=200):
    p.require(LIVESTOCK_READ)
    q = (select(HealthObservation, Animal).join(Animal, Animal.id == HealthObservation.animal_id)
         .where(HealthObservation.org_id == p.org_id))
    if p.farm_scope is not None:
        q = q.where(Animal.farm_id.in_(p.farm_scope))
    if level:
        q = q.where(HealthObservation.level.in_(level.split(",")))
    if review_status:
        q = q.where(HealthObservation.review_status == review_status)
    q = q.order_by(HealthObservation.observed_at.desc()).limit(limit)
    return [dict(ser(h), animal_tag=a.tag, animal_name=a.name, species=a.species,
                 disclaimer=health_engine.DISCLAIMER if h.source == "engine" else "") for h, a in db.execute(q)]


def review_health(db: Session, p: Principal, obs_id: str, status: str, note: str):
    p.require(HEALTH_REVIEW)
    h = get_scoped(db, HealthObservation, obs_id, p)
    if status not in ("reviewed", "dismissed"):
        raise Invalid("status must be reviewed or dismissed")
    if not note.strip():
        raise Invalid("a review note is required")
    h.review_status, h.reviewed_by, h.review_note = status, p.user_id, note
    audit(db, p, "health.review", "health_observation", h.id, {"status": status})
    return ser(h)


def add_manual_health(db: Session, p: Principal, animal_id: str, data: dict):
    p.require(LIVESTOCK_WRITE)
    a = get_scoped(db, Animal, animal_id, p)
    lvl = data.get("level", "unusual")
    if lvl not in health_engine.LEVELS:
        raise Invalid("level must be one of " + ", ".join(health_engine.LEVELS))
    src = "veterinarian" if p.role == "veterinarian" else "farmer"
    h = HealthObservation(org_id=p.org_id, animal_id=a.id, observed_at=utcnow(), source=src, level=lvl,
                          summary=data.get("summary", ""), supporting=[{"observation": data.get("summary", "")}],
                          review_status="reviewed" if src == "veterinarian" else "unreviewed")
    db.add(h)
    db.flush()
    return ser(h)


# ------------------------------------------------------------------ analysis


def _tracks(db: Session, org_id: str, since: datetime, animals: list[Animal]) -> dict[str, movement.Track]:
    rows = db.execute(select(CollarTelemetry.animal_id, CollarTelemetry.recorded_at, CollarTelemetry.lat,
                             CollarTelemetry.lon, CollarTelemetry.hdop, CollarTelemetry.activity, CollarTelemetry.speed_mps,
                             CollarTelemetry.rest_fraction, CollarTelemetry.temp_c, CollarTelemetry.ambient_c,
                             CollarTelemetry.water_visit)
                      .where(CollarTelemetry.org_id == org_id, CollarTelemetry.recorded_at >= since,
                             CollarTelemetry.lat.isnot(None))
                      .order_by(CollarTelemetry.recorded_at)).all()
    by: dict[str, list] = {}
    for r in rows:
        by.setdefault(r[0], []).append(r)
    out = {}
    for a in animals:
        rs = by.get(a.id, [])
        arr = lambda i: np.array([np.nan if x[i] is None else float(x[i]) for x in rs], float)  # noqa: E731
        tr = movement.Track(a.id, np.array([x[1].timestamp() for x in rs], float), arr(2), arr(3), arr(4), arr(5),
                            arr(6), herd_id=a.herd_id)
        tr.extra = {"rest": arr(7), "temp": arr(8), "ambient": arr(9),
                    "water": np.array([1.0 if x[10] else 0.0 for x in rs])}
        out[a.id] = tr
    return out


def learn_baselines(db: Session, org_id: str, now: datetime, days: float = 3.0):
    animals = list(db.scalars(select(Animal).where(Animal.org_id == org_id, Animal.status == "active")))
    trs = _tracks(db, org_id, now - timedelta(days=days), animals)
    for a in animals:
        tr = trs[a.id]
        if len(tr) < 96:
            continue
        b = movement.learn_baseline(tr)
        ndays = max((tr.t[-1] - tr.t[0]) / 86400, 1e-3)
        wv_per_6h = []
        for k in range(int(ndays * 4)):
            m = (tr.t >= tr.t[0] + k * 21600) & (tr.t < tr.t[0] + (k + 1) * 21600)
            wv_per_6h.append(int(_visits(tr.extra["water"][m])))
        b.update(health_engine.learn_health_baseline(tr.activity, tr.extra["rest"], tr.extra["temp"], tr.extra["ambient"],
                                                     [int(sum(wv_per_6h[i:i + 4])) for i in range(0, len(wv_per_6h) - 3, 4)] or None,
                                                     hours=movement.hour_of_day(tr.t)))
        b["learned_at"] = now.isoformat()
        b["window_days"] = days
        a.baseline = b


def _visits(w: np.ndarray) -> int:
    """Count separate visits (rising edges) rather than samples spent at water."""
    if len(w) == 0:
        return 0
    w = (w > 0.5).astype(int)
    return int(w[0] + np.sum(np.diff(w) == 1))


KIND_TITLES = {
    "separation": "Animal separated from herd", "boundary_exit": "Animal outside grazing boundary",
    "inactivity": "Unusual inactivity", "unusual_movement": "Unusual movement", "congregation": "Unusual herd bunching",
    "missing_animal": "Possible missing animal", "network_outage": "Collar network outage",
}


def analyze_org(db: Session, org_id: str, now: datetime, run_health: bool = True) -> dict:
    """Run movement (and health) intelligence for one organisation; persist events and raise alerts."""
    animals = list(db.scalars(select(Animal).where(Animal.org_id == org_id, Animal.status.in_(["active", "missing"]))))
    if not animals:
        return {"anomalies": 0, "health": 0}
    trs = _tracks(db, org_id, now - timedelta(hours=48), animals)
    by_farm: dict[str, list[Animal]] = {}
    for a in animals:
        by_farm.setdefault(a.farm_id, []).append(a)
    n_anom = 0
    stats = {"anomalies": 0, "health": 0, "by_kind": {}}
    for farm_id, fa in by_farm.items():
        farm = db.get(Farm, farm_id)
        boundary = db.get(Area, farm.boundary_area_id).geometry if farm.boundary_area_id else None
        # known gathering points (water and the night enclosure): bunching there is normal
        wps = [(w.lat, w.lon) for w in db.scalars(select(WaterPoint).where(WaterPoint.farm_id == farm_id))] + [(farm.lat, farm.lon)]
        params = {}
        for kind in ("separation", "boundary_exit", "inactivity", "unusual_movement"):
            r = alerts.rule_for(db, org_id, kind)
            if r:
                params.update(r.params or {})
        th = movement.MovementThresholds.from_params(params)
        found = movement.analyze([trs[a.id] for a in fa], now.timestamp(), boundary, wps, th,
                                 {a.id: a.baseline or {} for a in fa})
        for an in found:
            kind = an.kind
            if kind == "no_data":
                continue  # handled by device connectivity monitoring
            if kind == "separation" and an.metrics.get("distance_from_herd_m", 0) > 1500:
                kind = "missing_animal"
            n_anom += 1
            stats["by_kind"][kind] = stats["by_kind"].get(kind, 0) + 1
            subject = an.animal_id or an.herd_id or farm_id
            animal = db.get(Animal, an.animal_id) if an.animal_id else None
            label = f"{animal.tag}{' ' + animal.name if animal and animal.name else ''}" if animal else farm.name
            al = alerts.raise_alert(db, org_id, "livestock", kind, f"{KIND_TITLES.get(kind, kind)}: {label}", an.explanation,
                                    subject_type="animal" if an.animal_id else "herd", subject_id=subject or "",
                                    lat=an.lat, lon=an.lon, evidence=an.metrics, confidence=an.confidence,
                                    dedupe_key=f"{kind}:{subject}")
            recent = db.scalar(select(MovementEvent).where(MovementEvent.org_id == org_id, MovementEvent.kind == kind,
                                                           MovementEvent.animal_id == an.animal_id,
                                                           MovementEvent.detected_at >= now - timedelta(hours=3)))
            if recent is None:
                db.add(MovementEvent(org_id=org_id, animal_id=an.animal_id, herd_id=an.herd_id, kind=kind, detected_at=now,
                                     confidence=an.confidence, metrics=an.metrics, explanation=an.explanation,
                                     alert_id=al.id if al else None))
    stats["anomalies"] = n_anom
    if run_health:
        stats["health"] = _health_pass(db, org_id, now, animals, trs)
    events.publish(org_id, "livestock.analysis", stats)
    return stats


def _health_pass(db: Session, org_id: str, now: datetime, animals: list[Animal], trs) -> int:
    rule = alerts.rule_for(db, org_id, "health_concern")
    min_level = (rule.params or {}).get("min_level", "concern") if rule else "concern"
    n = 0
    rng = np.random.default_rng(int(now.timestamp()) % 2**31)
    for a in animals:
        tr = trs[a.id]
        if not a.baseline or len(tr) == 0:
            continue
        w = tr.t >= now.timestamp() - 6 * 3600
        w24 = tr.t >= now.timestamp() - 24 * 3600
        separated = db.scalar(select(Alert.id).where(Alert.org_id == org_id, Alert.subject_id == a.id,
                                                     Alert.kind.in_(["separation", "missing_animal"]),
                                                     Alert.status.in_(["open", "acknowledged"]))) is not None
        inp = health_engine.HealthInputs(tr.activity[w], tr.extra["rest"][w], tr.extra["temp"][w], tr.extra["ambient"][w],
                                         _visits(tr.extra["water"][w24]) if w24.sum() >= 48 else None, 24,
                                         separated, a.baseline, movement.hour_of_day(tr.t[w]))
        res = health_engine.assess(inp, rng, n_boot=40)
        db.add(HealthObservation(org_id=org_id, animal_id=a.id, observed_at=now, source="engine", level=res.level,
                                 score=res.score, confidence=res.confidence, uncertainty=res.uncertainty,
                                 supporting=res.supporting, data_coverage=res.data_coverage, summary=res.summary))
        n += 1
        if health_engine.LEVELS.index(res.level) >= health_engine.LEVELS.index(min_level):
            alerts.raise_alert(db, org_id, "livestock", "health_concern",
                               f"{'Urgent veterinary assessment recommended' if res.level == 'urgent' else 'Potential health concern'}: "
                               f"{a.tag}{' ' + a.name if a.name else ''}",
                               res.summary + " " + health_engine.DISCLAIMER, subject_type="animal", subject_id=a.id,
                               lat=a.last_lat, lon=a.last_lon,
                               evidence={"level": res.level, "score": res.score, "uncertainty": res.uncertainty,
                                         "supporting": res.supporting[:4]}, confidence=res.confidence,
                               dedupe_key=f"health:{a.id}", priority="critical" if res.level == "urgent" else None)
    return n


# ------------------------------------------------------------------ water & grazing


def water_points(db: Session, p: Principal, now: datetime | None = None):
    p.require(LIVESTOCK_READ)
    now = now or utcnow()
    out = []
    for w in db.scalars(select(WaterPoint).where(WaterPoint.org_id == p.org_id)):
        obs = list(db.scalars(select(WaterObservation).where(WaterObservation.water_point_id == w.id,
                                                             WaterObservation.observed_at >= now - timedelta(days=4))
                              .order_by(WaterObservation.observed_at)))
        d = ser(w)
        d["latest"] = ser(obs[-1]) if obs else None
        seg = _since_refill(obs)
        d["forecast"] = water_forecast([o.observed_at.timestamp() for o in seg], [o.level_pct for o in seg])
        d["series"] = [[o.observed_at.isoformat(), round(o.level_pct, 1)] for o in obs[-96:]]
        out.append(d)
    return out


def check_water(db: Session, org_id: str, now: datetime):
    rule = alerts.rule_for(db, org_id, "water_shortage")
    prm = (rule.params or {}) if rule else {}
    p = Principal(org_id=org_id, role="org_admin", kind="system")
    for w in water_points(db, p, now):
        lvl = (w["latest"] or {}).get("level_pct")
        f = w["forecast"]
        dte = f.get("days_to_empty")
        # conservative: alert on the trend only when even the optimistic end of the 90% interval is short
        dte_hi = (f.get("days_to_empty_90") or [None, None])[1]
        if (lvl is not None and lvl < prm.get("level_pct", 25)) or (dte_hi is not None and dte_hi < prm.get("days_to_empty", 3)):
            alerts.raise_alert(db, org_id, "livestock", "water_shortage", f"Water running low: {w['name']}",
                               f"Level {lvl:.0f}%" + (f"; estimated {dte:.1f} days to empty at the current trend ({f['basis']})" if dte else "")
                               + ". Estimate from level sensor readings — verify on site.",
                               subject_type="water_point", subject_id=w["id"], lat=w["lat"], lon=w["lon"],
                               evidence={"level_pct": lvl, "forecast": f}, confidence=0.8, dedupe_key=f"water:{w['id']}")


def grazing(db: Session, p: Principal, now: datetime | None = None):
    p.require(LIVESTOCK_READ)
    now = now or utcnow()
    areas = list(db.scalars(select(Area).where(Area.org_id == p.org_id, Area.kind == "grazing_area")))
    herds = list(db.scalars(select(Herd).where(Herd.org_id == p.org_id)))
    in_use = {h.grazing_area_id for h in herds}
    out, rec_in = [], []
    for ar in areas:
        obs = list(db.scalars(select(VegetationObservation).where(VegetationObservation.area_id == ar.id)
                              .order_by(VegetationObservation.observed_at)))
        series = [o.ndvi_mean for o in obs]
        ref = (ar.properties or {}).get("ndvi_seasonal_ref", [])
        rain = (ar.properties or {}).get("rain_30d_mm")
        rain_ref = (ar.properties or {}).get("rain_30d_ref_mm")
        latest = obs[-1] if obs else None
        bio = biomass_estimate(latest.ndvi_mean) if latest else None
        d = {"area_id": ar.id, "name": ar.name, "in_use": ar.id in in_use, "latest": ser(latest) if latest else None,
             "biomass": bio, "drought": drought_indicator(series, ref, rain, rain_ref),
             "series": [[o.observed_at.isoformat(), round(o.ndvi_mean, 3)] for o in obs],
             "days_since_grazed": (ar.properties or {}).get("days_since_grazed", 0 if ar.id in in_use else 30)}
        out.append(d)
        rec_in.append({"id": ar.id, "name": ar.name, "biomass_kg_ha": bio["biomass_kg_ha"] if bio else None,
                       "days_since_grazed": d["days_since_grazed"], "in_use": d["in_use"]})
    return {"areas": out, "recommendations": grazing_recommendations(rec_in),
            "note": "Vegetation, biomass and drought values are model estimates from NDVI, not field measurements."}


def dashboard(db: Session, p: Principal, now: datetime | None = None):
    p.require(LIVESTOCK_READ)
    now = now or utcnow()
    animals = list_animals(db, p)
    by_status: dict = {}
    by_species: dict = {}
    for a in animals:
        by_status[a["status"]] = by_status.get(a["status"], 0) + 1
        by_species[a["species"]] = by_species.get(a["species"], 0) + 1
    lv = {}
    for a in animals:
        lv[a["health_level"] or "no_data"] = lv.get(a["health_level"] or "no_data", 0) + 1
    collars = [a["collar"] for a in animals if a["collar"]]
    open_alerts = db.scalars(select(Alert).where(Alert.org_id == p.org_id, Alert.domain == "livestock",
                                                 Alert.status.in_(["open", "acknowledged"]))
                             .order_by(Alert.created_at.desc()).limit(10))
    return {
        "animals": len(animals), "by_status": by_status, "by_species": by_species, "health_levels": lv,
        "collars": {"total": len(collars), "online": sum(1 for c in collars if c["connectivity"] == "online"),
                    "low_battery": sum(1 for c in collars if (c["battery_pct"] or 100) < 20),
                    "battery": sorted([round(c["battery_pct"] or 0) for c in collars])},
        "alerts": [ser(a) for a in open_alerts],
        "water": water_points(db, p, now), "farms": list_farms(db, p),
    }


def _since_refill(obs: list) -> list:
    """Readings after the most recent refill (a rise of > 5 points), so the trend reflects current draw-down."""
    k = 0
    for i in range(1, len(obs)):
        if obs[i].level_pct - obs[i - 1].level_pct > 5:
            k = i
    return obs[k:]
