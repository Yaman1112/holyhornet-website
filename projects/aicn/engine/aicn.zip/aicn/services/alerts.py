"""Alert engine: rule lookup, de-duplication, notification fan-out, acknowledgement and resolution.

Channels
  in_app  always delivered (notification row, visible in the web/mobile app)
  email   SMTP when AICN_SMTP_HOST is set, otherwise recorded as `not_configured`
  sms     provider adapter (Africa's Talking interface) when AICN_SMS_PROVIDER is set, otherwise `not_configured`
  push    Web Push requires VAPID keys + subscriptions: recorded as `not_configured` in this release
Nothing is ever reported as sent unless the transport accepted it.
"""

from __future__ import annotations

import json
import smtplib
import urllib.parse
import urllib.request
from email.message import EmailMessage

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..db import utcnow
from ..errors import Invalid
from ..models import Alert, AlertRule, Membership, Notification, User
from ..rbac import ALERT_RULES, ALERTS_MANAGE, ALERTS_READ, Principal
from . import events
from .common import audit, get_scoped, protect, ser

PRIORITIES = ["low", "medium", "high", "critical"]

DEFAULT_RULES = {
    # kind: (priority, channels, roles, params)
    "missing_animal": ("high", ["in_app", "sms", "push"], ["farmer", "org_admin"], {}),
    "separation": ("medium", ["in_app", "push"], ["farmer"], {"separation_m": 600, "separation_min_minutes": 45}),
    "boundary_exit": ("high", ["in_app", "sms", "push"], ["farmer", "org_admin"], {"boundary_margin_m": 15}),
    "inactivity": ("medium", ["in_app"], ["farmer", "veterinarian"], {"inactivity_ratio": 0.45, "inactivity_window_h": 6}),
    "unusual_movement": ("high", ["in_app", "sms"], ["farmer"], {"speed_robust_z": 5.0}),
    "congregation": ("low", ["in_app"], ["farmer"], {}),
    "health_concern": ("high", ["in_app", "email"], ["veterinarian", "farmer"], {"min_level": "concern"}),
    "low_battery": ("low", ["in_app"], ["org_admin", "uav_operator"], {"battery_pct": 20}),
    "device_offline": ("medium", ["in_app"], ["org_admin"], {"silent_hours": 1.5}),
    "network_outage": ("high", ["in_app", "email"], ["org_admin"], {}),
    "water_shortage": ("high", ["in_app", "sms"], ["farmer", "org_admin"], {"level_pct": 25, "days_to_empty": 3}),
    "drought_indicator": ("medium", ["in_app", "email"], ["farmer", "org_admin"], {}),
    "possible_entanglement": ("high", ["in_app", "email"], ["marine_researcher", "conservation_officer"], {}),
    "nest_threat": ("high", ["in_app", "sms"], ["conservation_officer"], {}),
    "marine_detection_review": ("low", ["in_app"], ["marine_researcher"], {}),
    "mission_event": ("medium", ["in_app"], ["uav_operator", "rov_operator"], {}),
    "environment_threshold": ("medium", ["in_app"], ["marine_researcher", "conservation_officer"], {"water_temp_c": 30.5}),
}


def ensure_default_rules(db: Session, org_id: str):
    have = {r.kind for r in db.scalars(select(AlertRule).where(AlertRule.org_id == org_id))}
    for kind, (prio, ch, roles, params) in DEFAULT_RULES.items():
        if kind not in have:
            db.add(AlertRule(org_id=org_id, kind=kind, priority=prio, channels=ch, recipients={"roles": roles, "user_ids": []},
                             params=params))


def rule_for(db: Session, org_id: str, kind: str) -> AlertRule | None:
    return db.scalar(select(AlertRule).where(AlertRule.org_id == org_id, AlertRule.kind == kind))


def raise_alert(db: Session, org_id: str, domain: str, kind: str, title: str, message: str, *, subject_type="",
                subject_id="", lat=None, lon=None, evidence: dict | None = None, confidence: float | None = None,
                requires_review=True, dedupe_key: str = "", sensitive=False, source="engine",
                priority: str | None = None) -> Alert | None:
    rule = rule_for(db, org_id, kind)
    if rule is not None and not rule.enabled:
        return None
    prio = priority or (rule.priority if rule else "medium")
    if dedupe_key:
        existing = db.scalar(select(Alert).where(Alert.org_id == org_id, Alert.dedupe_key == dedupe_key,
                                                 Alert.status.in_(["open", "acknowledged"])))
        if existing:
            existing.evidence = evidence or existing.evidence
            existing.message = message
            existing.confidence = confidence
            if lat is not None:
                existing.lat, existing.lon = lat, lon
            return existing
    a = Alert(org_id=org_id, domain=domain, kind=kind, priority=prio, title=title, message=message,
              subject_type=subject_type, subject_id=subject_id, lat=lat, lon=lon, evidence=evidence or {},
              confidence=confidence, requires_review=requires_review, dedupe_key=dedupe_key, sensitive=sensitive,
              source=source, created_at=utcnow())
    db.add(a)
    db.flush()
    _notify(db, a, rule)
    events.publish(org_id, "alert.created", {"id": a.id, "kind": kind, "priority": prio, "title": title}, sensitive)
    return a


def _recipients(db: Session, a: Alert, rule: AlertRule | None) -> list[User]:
    roles = (rule.recipients or {}).get("roles", []) if rule else ["org_admin"]
    ids = set((rule.recipients or {}).get("user_ids", [])) if rule else set()
    rows = db.execute(select(User, Membership.role).join(Membership, Membership.user_id == User.id)
                      .where(Membership.org_id == a.org_id, User.active.is_(True))).all()
    return [u for u, role in rows if role in roles or u.id in ids or role == "org_admin"]


def _notify(db: Session, a: Alert, rule: AlertRule | None):
    channels = rule.channels if rule else ["in_app"]
    for u in _recipients(db, a, rule):
        for ch in channels:
            status, detail, to = _deliver(ch, u, a)
            db.add(Notification(org_id=a.org_id, alert_id=a.id, user_id=u.id, channel=ch, recipient=to, status=status,
                                detail=detail, created_at=utcnow()))


def _deliver(ch: str, u: User, a: Alert) -> tuple[str, str, str]:
    s = config.settings
    text = f"[AICN {a.priority.upper()}] {a.title}"
    if ch == "in_app":
        return "delivered", "", u.id
    if ch == "email":
        if not u.email:
            return "no_address", "user has no email", ""
        if not s.smtp_host or s.browser_mode:
            return "not_configured", "SMTP not configured (AICN_SMTP_HOST)", u.email
        try:
            msg = EmailMessage()
            msg["Subject"], msg["From"], msg["To"] = text, s.smtp_from, u.email
            msg.set_content(a.message + "\n\nThis is an automated observation and needs human review.")
            with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=10) as sm:
                sm.starttls()
                if s.smtp_user:
                    sm.login(s.smtp_user, s.smtp_password)
                sm.send_message(msg)
            return "sent", "", u.email
        except Exception as e:  # pragma: no cover - network
            return "failed", str(e)[:300], u.email
    if ch == "sms":
        if not u.phone:
            return "no_address", "user has no phone number", ""
        if s.sms_provider != "africastalking" or not s.sms_api_key or s.browser_mode:
            return "not_configured", "SMS provider not configured (AICN_SMS_PROVIDER)", u.phone
        try:  # pragma: no cover - network
            body = urllib.parse.urlencode({"username": s.sms_username, "to": u.phone, "message": text[:160]}).encode()
            req = urllib.request.Request("https://api.africastalking.com/version1/messaging", body,
                                         {"apiKey": s.sms_api_key, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=10) as r:
                return "sent", json.loads(r.read())["SMSMessageData"]["Message"][:200], u.phone
        except Exception as e:  # pragma: no cover
            return "failed", str(e)[:300], u.phone
    if ch == "push":
        return "not_configured", "Web Push needs VAPID keys and device subscriptions", u.id
    return "failed", f"unknown channel {ch}", ""


# ------------------------------------------------------------------ API-facing


def list_alerts(db: Session, p: Principal, status: str | None = None, domain: str | None = None, limit=200):
    p.require(ALERTS_READ)
    q = select(Alert).where(Alert.org_id == p.org_id)
    if status:
        q = q.where(Alert.status.in_(status.split(",")))
    if domain:
        q = q.where(Alert.domain == domain)
    q = q.order_by(Alert.created_at.desc()).limit(limit)
    return [protect(ser(a), p) for a in db.scalars(q)]


def transition(db: Session, p: Principal, alert_id: str, action: str, note: str = ""):
    p.require(ALERTS_MANAGE)
    a = get_scoped(db, Alert, alert_id, p)
    now = utcnow()
    if action == "acknowledge":
        if a.status != "open":
            raise Invalid(f"alert is {a.status}")
        a.status, a.acknowledged_by, a.acknowledged_at = "acknowledged", p.user_id, now
    elif action in ("resolve", "dismiss"):
        if a.status in ("resolved", "dismissed"):
            raise Invalid(f"alert is already {a.status}")
        if a.requires_review and not note.strip():
            raise Invalid("a note is required: this alert needs a recorded human assessment")
        a.status = "resolved" if action == "resolve" else "dismissed"
        a.resolved_by, a.resolved_at, a.resolution_note = p.user_id, now, note
    else:
        raise Invalid("unknown action")
    audit(db, p, f"alert.{action}", "alert", a.id, {"note": note})
    events.publish(p.org_id, "alert.updated", {"id": a.id, "status": a.status})
    return protect(ser(a), p)


def list_rules(db: Session, p: Principal):
    p.require(ALERTS_READ)
    return [ser(r) for r in db.scalars(select(AlertRule).where(AlertRule.org_id == p.org_id).order_by(AlertRule.kind))]


def update_rule(db: Session, p: Principal, rule_id: str, data: dict):
    p.require(ALERT_RULES)
    r = get_scoped(db, AlertRule, rule_id, p)
    if "priority" in data and data["priority"] not in PRIORITIES:
        raise Invalid("priority must be one of " + ", ".join(PRIORITIES))
    if "channels" in data and not set(data["channels"]) <= {"in_app", "email", "sms", "push"}:
        raise Invalid("unknown channel")
    for k in ("enabled", "priority", "params", "recipients", "channels"):
        if k in data:
            setattr(r, k, data[k])
    audit(db, p, "alert_rule.update", "alert_rule", r.id, data)
    return ser(r)


def my_notifications(db: Session, p: Principal, limit=50):
    q = (select(Notification, Alert).join(Alert, Alert.id == Notification.alert_id)
         .where(Notification.org_id == p.org_id, Notification.user_id == p.user_id)
         .order_by(Notification.created_at.desc()).limit(limit))
    return [dict(ser(n), alert_title=a.title, alert_priority=a.priority) for n, a in db.execute(q)]
