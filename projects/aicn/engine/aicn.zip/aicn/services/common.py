"""Helpers shared by all services: serialisation, org-scoped lookups, sensitive-location protection, audit."""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import inspect as sa_inspect
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import NotFound
from ..geo import generalize
from ..models import AuditLog
from ..rbac import SENSITIVE_READ, Principal


def ser(obj, exclude: tuple[str, ...] = ()) -> dict:
    out = {}
    for c in sa_inspect(obj).mapper.column_attrs:
        k = c.key
        if k in exclude or k in ("password_hash", "secret_hash", "key_hash"):
            continue
        v = getattr(obj, k)
        if isinstance(v, (datetime, date)):
            v = v.isoformat()
        out[k] = v
    return out


def protect(d: dict, p: Principal, sensitive: bool | None = None, lat_key="lat", lon_key="lon") -> dict:
    """Generalise coordinates of sensitive records for principals without `sensitive.read`."""
    s = d.get("sensitive") if sensitive is None else sensitive
    if s and not p.can(SENSITIVE_READ) and d.get(lat_key) is not None:
        d[lat_key], d[lon_key] = generalize(d[lat_key], d[lon_key])
        d["location_precision"] = "generalized_~11km"
    else:
        d.setdefault("location_precision", "exact")
    return d


def get_scoped(db: Session, model, obj_id: str, p: Principal):
    obj = db.get(model, obj_id)
    if obj is None or getattr(obj, "org_id", p.org_id) not in (p.org_id, None):
        raise NotFound(f"{model.__name__} {obj_id} not found")
    return obj


def audit(db: Session, p: Principal | None, action: str, resource: str = "", resource_id: str = "", detail: dict | None = None,
          org_id: str | None = None):
    db.add(AuditLog(org_id=org_id or (p.org_id if p else None), user_id=p.user_id if p else None,
                    actor=(p.name or p.kind) if p else "anonymous", action=action, resource=resource,
                    resource_id=str(resource_id), detail=detail or {}, at=utcnow()))


def page(q, limit: int = 100, offset: int = 0):
    return q.limit(min(max(limit, 1), 1000)).offset(max(offset, 0))
