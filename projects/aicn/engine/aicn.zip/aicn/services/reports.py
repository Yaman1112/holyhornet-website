"""Analytics & reporting. Every report states its period, area, data sources, units, confidence,
missing-data indicators and which statements are AI-generated interpretation. Exports: PDF, CSV, XLSX."""

from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np
from sqlalchemy import Integer, func, select
from sqlalchemy.orm import Session

from .. import exports
from ..db import utcnow
from ..errors import Invalid
from ..geo import generalize
from ..models import (AIDetection, Alert, Animal, Area, BehaviourEvent, CollarTelemetry, Device, EnvMeasurement,
                      HabitatObservation, HealthObservation, IngestBatch, MarineObservation, Mission, MovementEvent, Nest,
                      Report, VegetationObservation, WaterObservation, WaterPoint)
from ..rbac import REPORTS, SENSITIVE_READ, Principal
from .common import audit, get_scoped, ser


def _sec(title, columns, rows, note="", source="", units=""):
    return {"title": title, "columns": columns, "rows": rows, "note": note, "source": source, "units": units}


def herd_movement(db, org, s, e, p):
    rows = []
    for a in db.scalars(select(Animal).where(Animal.org_id == org).order_by(Animal.tag)):
        pts = db.execute(select(CollarTelemetry.recorded_at, CollarTelemetry.lat, CollarTelemetry.lon)
                         .where(CollarTelemetry.animal_id == a.id, CollarTelemetry.recorded_at.between(s, e),
                                CollarTelemetry.lat.isnot(None)).order_by(CollarTelemetry.recorded_at)).all()
        if len(pts) < 2:
            rows.append([a.tag, a.species, len(pts), None, None, "insufficient data"])
            continue
        la = np.radians([x[1] for x in pts])
        lo = np.radians([x[2] for x in pts])
        d = 2 * 6371008.8 * np.arcsin(np.sqrt(np.sin(np.diff(la) / 2) ** 2 + np.cos(la[:-1]) * np.cos(la[1:]) * np.sin(np.diff(lo) / 2) ** 2))
        days = max((pts[-1][0] - pts[0][0]).total_seconds() / 86400, 1e-6)
        expected = days * 96
        cov = len(pts) / expected
        rows.append([a.tag, a.species, len(pts), round(float(d.sum()) / 1000 / days, 2), round(cov * 100),
                     "ok" if cov > 0.8 else "gaps"])
    return _sec("Herd movement", ["Animal", "Species", "GPS fixes", "Distance (km/day)", "Coverage (%)", "Data"], rows,
                "Distance is the sum of straight lines between 15-minute fixes (underestimates true path length; GPS noise adds some).",
                "smart-collar GNSS", "km/day")


def animal_activity(db, org, s, e, p):
    rows = db.execute(select(Animal.tag, func.avg(CollarTelemetry.activity), func.avg(CollarTelemetry.rest_fraction),
                             func.avg(CollarTelemetry.temp_c), func.count())
                      .join(Animal, Animal.id == CollarTelemetry.animal_id)
                      .where(CollarTelemetry.org_id == org, CollarTelemetry.recorded_at.between(s, e))
                      .group_by(Animal.tag).order_by(Animal.tag)).all()
    return _sec("Animal activity", ["Animal", "Mean activity (g)", "Resting share", "Mean collar temp (°C)", "Samples"],
                [[t, round(a or 0, 3), round(r or 0, 2), round(c or 0, 1), n] for t, a, r, c, n in rows],
                "Collar temperature is skin/collar temperature, not core body temperature.", "collar accelerometer + thermistor",
                "g, fraction, °C")


def missing_incidents(db, org, s, e, p):
    rows = [[a.created_at.isoformat()[:16], a.title, a.priority, a.status, round(a.confidence or 0, 2), a.resolution_note]
            for a in db.scalars(select(Alert).where(Alert.org_id == org, Alert.kind.in_(["missing_animal", "separation", "boundary_exit"]),
                                                    Alert.created_at.between(s, e)).order_by(Alert.created_at))]
    return _sec("Missing-animal and boundary incidents", ["Raised", "Alert", "Priority", "Status", "Confidence", "Resolution"], rows,
                "AI-generated observations from movement data; outcome recorded by people in the resolution column.", "movement engine")


def health_section(db, org, s, e, p):
    q = (select(HealthObservation, Animal.tag).join(Animal, Animal.id == HealthObservation.animal_id)
         .where(HealthObservation.org_id == org, HealthObservation.observed_at.between(s, e),
                HealthObservation.level != "normal").order_by(HealthObservation.observed_at))
    rows = [[h.observed_at.isoformat()[:16], tag, h.level, h.source, h.score, h.confidence, h.uncertainty, h.review_status, h.summary]
            for h, tag in db.execute(q)]
    tot = db.scalar(select(func.count()).select_from(HealthObservation).where(HealthObservation.org_id == org,
                                                                              HealthObservation.observed_at.between(s, e)))
    return _sec("Health observations (non-normal)", ["Time", "Animal", "Level", "Source", "Score", "Confidence", "± score", "Review", "Summary"],
                rows, f"{tot} assessments in the period. AI-generated observations — not veterinary diagnoses.", "health engine + vets")


def grazing_section(db, org, s, e, p):
    rows = []
    for ar in db.scalars(select(Area).where(Area.org_id == org, Area.kind == "grazing_area")):
        obs = list(db.scalars(select(VegetationObservation).where(VegetationObservation.area_id == ar.id,
                                                                  VegetationObservation.observed_at.between(s - timedelta(days=30), e))
                              .order_by(VegetationObservation.observed_at)))
        if obs:
            rows.append([ar.name, len(obs), round(obs[0].ndvi_mean, 3), round(obs[-1].ndvi_mean, 3), obs[-1].biomass_kg_ha,
                         round(np.mean([o.cloud_fraction for o in obs]), 2)])
        else:
            rows.append([ar.name, 0, None, None, None, None])
    return _sec("Grazing areas", ["Area", "Observations", "NDVI first", "NDVI latest", "Est. biomass (kg DM/ha)", "Mean cloud"], rows,
                "Model estimates from (simulated) satellite NDVI; biomass coefficients are uncalibrated placeholders.",
                "satellite NDVI (estimate)", "NDVI, kg DM/ha")


def water_section(db, org, s, e, p):
    rows = []
    for w in db.scalars(select(WaterPoint).where(WaterPoint.org_id == org)):
        v = db.execute(select(func.min(WaterObservation.level_pct), func.avg(WaterObservation.level_pct),
                              func.max(WaterObservation.level_pct), func.count())
                       .where(WaterObservation.water_point_id == w.id, WaterObservation.observed_at.between(s, e))).one()
        rows.append([w.name, w.kind, *(round(x, 1) if x is not None else None for x in v[:3]), v[3]])
    return _sec("Water availability", ["Water point", "Type", "Min level (%)", "Mean level (%)", "Max level (%)", "Readings"], rows,
                "", "water level sensors", "% of capacity")


def device_section(db, org, s, e, p):
    rows = []
    for d in db.scalars(select(Device).where(Device.org_id == org).order_by(Device.device_type, Device.name)):
        b = db.execute(select(func.count(), func.sum(IngestBatch.n_records), func.sum(IngestBatch.n_gaps),
                              func.max(IngestBatch.max_delay_s))
                       .where(IngestBatch.device_id == d.id, IngestBatch.received_at.between(s, e))).one()
        rows.append([d.name, d.device_type, d.battery_pct, d.connectivity, b[0] or 0, b[1] or 0, b[2] or 0,
                     round((b[3] or 0) / 60, 1)])
    return _sec("Device performance", ["Device", "Type", "Battery (%)", "Link", "Uploads", "Records", "Gaps", "Max delay (min)"], rows,
                "Max delay = time between measurement and arrival (store-and-forward while out of coverage).", "ingest log")


def species_section(db, org, s, e, p):
    rows = db.execute(select(MarineObservation.species_group, MarineObservation.method, MarineObservation.verification,
                             func.count(), func.sum(MarineObservation.count), func.avg(MarineObservation.confidence))
                      .where(MarineObservation.org_id == org, MarineObservation.observed_at.between(s, e))
                      .group_by(MarineObservation.species_group, MarineObservation.method, MarineObservation.verification)).all()
    return _sec("Species observations", ["Species group", "Method", "Verification", "Records", "Individuals", "Mean confidence"],
                [[g, m, v, n, c, round(cf or 0, 2) if cf is not None else None] for g, m, v, n, c, cf in rows],
                "Unverified rows are AI candidates; only verified rows should be used as presence records.", "UAV, ROV, surveys")


def distribution_section(db, org, s, e, p):
    q = select(MarineObservation).where(MarineObservation.org_id == org, MarineObservation.observed_at.between(s, e),
                                        MarineObservation.verification.in_(["verified", "unverified"]))
    cells: dict = {}
    for o in db.scalars(q):
        la, lo = generalize(o.lat, o.lon, 0.05 if p.can(SENSITIVE_READ) else 0.1)
        k = (round(la, 3), round(lo, 3), o.species_group)
        cells[k] = cells.get(k, 0) + o.count
    rows = [[a, b, g, n] for (a, b, g), n in sorted(cells.items())]
    return _sec("Species distribution (grid cells)", ["Cell centre lat", "Cell centre lon", "Species group", "Individuals"], rows,
                f"Aggregated to {'~5.5' if p.can(SENSITIVE_READ) else '~11'} km cells to protect sensitive locations.", "observations")


def marine_movement_section(db, org, s, e, p):
    rows = [[b.at.isoformat()[:16], b.species_group, b.observed.get("heading_deg"), b.observed.get("mean_speed_mps"),
             b.observed.get("straightness"), b.interpretation.get("label"), b.interpretation.get("confidence"), b.review_status]
            for b in db.scalars(select(BehaviourEvent).where(BehaviourEvent.org_id == org, BehaviourEvent.at.between(s, e))
                                .order_by(BehaviourEvent.at))]
    return _sec("Animal movement and behaviour", ["Time", "Group", "Heading (°)", "Speed (m/s)", "Straightness",
                                                 "Interpretation (AI)", "Conf.", "Review"], rows,
                "Observed columns are measurements from tracks; 'Interpretation' is an AI hypothesis.", "UAV tracks", "°, m/s")


def nesting_section(db, org, s, e, p):
    rows = []
    for n in db.scalars(select(Nest).where(Nest.org_id == org).order_by(Nest.laid_on)):
        rows.append([n.code, n.laid_on.isoformat(), n.status, n.clutch_size, n.hatchlings_emerged, n.site_condition, n.protected])
    return _sec("Turtle nesting", ["Nest", "Laid", "Status", "Clutch", "Hatchlings emerged", "Site condition", "Protected"], rows,
                "Nest coordinates are deliberately omitted from reports.", "ranger patrols")


def habitat_section(db, org, s, e, p):
    rows = db.execute(select(HabitatObservation.kind, HabitatObservation.method, func.count(), func.avg(HabitatObservation.value),
                             func.avg(HabitatObservation.uncertainty), HabitatObservation.unit)
                      .where(HabitatObservation.org_id == org, HabitatObservation.observed_at.between(s, e))
                      .group_by(HabitatObservation.kind, HabitatObservation.method, HabitatObservation.unit)).all()
    return _sec("Marine habitat monitoring", ["Indicator", "Method", "Segments", "Mean", "Mean ±", "Unit"],
                [[k, m, n, round(v or 0, 3), round(u or 0, 3) if u is not None else None, un] for k, m, n, v, u, un in rows],
                "Estimates from imagery; coral cover from ROV transects.", "ROV / UAV imagery")


def environment_section(db, org, s, e, p):
    rows = db.execute(select(EnvMeasurement.kind, EnvMeasurement.unit, EnvMeasurement.source, func.count(),
                             func.min(EnvMeasurement.value), func.avg(EnvMeasurement.value), func.max(EnvMeasurement.value),
                             func.sum(func.cast(EnvMeasurement.quality != "good", Integer)))
                      .where(EnvMeasurement.org_id == org, EnvMeasurement.measured_at.between(s, e))
                      .group_by(EnvMeasurement.kind, EnvMeasurement.unit, EnvMeasurement.source)).all()
    return _sec("Environmental measurements", ["Variable", "Unit", "Source", "N", "Min", "Mean", "Max", "QC-flagged"],
                [[k, u, src, n, round(a, 2), round(b, 2), round(c, 2), int(q or 0)] for k, u, src, n, a, b, c, q in rows],
                "QC-flagged values (spikes, suspect readings) are counted but still listed in raw exports.", "buoys, sensors")


def coverage_section(db, org, s, e, p):
    rows = []
    for m in db.scalars(select(Mission).where(Mission.org_id == org, Mission.domain == "marine",
                                              Mission.started_at.between(s, e)).order_by(Mission.started_at)):
        ev = (m.outcome or {}).get("evaluation") or {}
        rows.append([m.name, m.kind, m.status, (m.outcome or {}).get("distance_flown_m"), ev.get("frames"),
                     (m.plan or {}).get("footprint_width_m"), (m.outcome or {}).get("observations_created")])
    return _sec("Survey coverage", ["Mission", "Type", "Status", "Distance (m)", "Frames", "Swath (m)", "Candidates"], rows,
                "", "mission logs")


SECTIONS = {
    "herd_movement": herd_movement, "animal_activity": animal_activity, "missing_incidents": missing_incidents,
    "health": health_section, "grazing": grazing_section, "water": water_section, "devices": device_section,
    "species": species_section, "distribution": distribution_section, "marine_movement": marine_movement_section,
    "nesting": nesting_section, "habitat": habitat_section, "environment": environment_section, "coverage": coverage_section,
}
KINDS = {
    "livestock_overview": ("livestock", ["herd_movement", "animal_activity", "missing_incidents", "health", "grazing", "water", "devices"]),
    "herd_movement": ("livestock", ["herd_movement"]), "animal_activity": ("livestock", ["animal_activity"]),
    "missing_incidents": ("livestock", ["missing_incidents"]), "health_observations": ("livestock", ["health"]),
    "grazing_patterns": ("livestock", ["grazing"]), "water_availability": ("livestock", ["water"]),
    "device_performance": ("shared", ["devices"]),
    "marine_overview": ("marine", ["species", "distribution", "marine_movement", "nesting", "habitat", "environment", "coverage"]),
    "species_observations": ("marine", ["species", "distribution"]), "animal_movement": ("marine", ["marine_movement"]),
    "nesting": ("marine", ["nesting"]), "habitat": ("marine", ["habitat"]), "environmental_change": ("marine", ["environment"]),
    "survey_coverage": ("marine", ["coverage"]),
}


def _summary(kind: str, secs: list[dict]) -> list[str]:
    """Reporting AI (template-based): plain-language overview built only from the computed tables."""
    out = []
    for s in secs:
        n = len(s["rows"])
        if s["title"].startswith("Health"):
            urgent = sum(1 for r in s["rows"] if r[2] == "urgent")
            out.append(f"{n} non-normal health observations ({urgent} recommending urgent veterinary assessment). "
                       "These are automated observations awaiting human review, not diagnoses.")
        elif s["title"].startswith("Missing"):
            open_ = sum(1 for r in s["rows"] if r[3] in ("open", "acknowledged"))
            out.append(f"{n} movement incidents raised; {open_} still open.")
        elif s["title"] == "Species observations":
            ver = sum(r[4] or 0 for r in s["rows"] if r[2] == "verified")
            unv = sum(r[4] or 0 for r in s["rows"] if r[2] in ("unverified", "needs_expert"))
            out.append(f"{ver} individuals in verified records; {unv} more in unverified AI candidates still to be reviewed.")
        elif s["title"] == "Turtle nesting":
            hatched = sum(1 for r in s["rows"] if r[2] == "hatched")
            out.append(f"{n} nests monitored, {hatched} hatched.")
        elif s["title"] == "Device performance":
            gaps = sum(r[6] for r in s["rows"])
            out.append(f"{n} devices reported; {gaps} sequence gaps (lost records) across all uploads.")
    return out


def create(db: Session, p: Principal, data: dict):
    p.require(REPORTS)
    kind = data.get("kind")
    if kind not in KINDS:
        raise Invalid(f"kind must be one of {sorted(KINDS)}")
    domain, sections = KINDS[kind]
    end = datetime.fromisoformat(data["end"]) if data.get("end") else utcnow()
    start = datetime.fromisoformat(data["start"]) if data.get("start") else end - timedelta(days=7)
    if start.tzinfo is None:
        start = start.replace(tzinfo=end.tzinfo)
    if end.tzinfo is None:
        end = end.replace(tzinfo=start.tzinfo)
    area = get_scoped(db, Area, data["area_id"], p) if data.get("area_id") else None
    secs = [SECTIONS[s](db, p.org_id, start, end, p) for s in sections]
    missing = [s["title"] for s in secs if not s["rows"]]
    content = {
        "meta": {"period": [start.isoformat(), end.isoformat()], "area": area.name if area else "whole organisation",
                 "data_sources": sorted({s["source"] for s in secs if s["source"]}),
                 "units": {s["title"]: s["units"] for s in secs if s["units"]},
                 "missing_data": missing,
                 "ai_interpretation_labels": "Rows and sentences marked AI are automated observations or interpretations "
                                             "and need human verification. Simulator-generated data is labelled synthetic.",
                 "confidence": "Confidence columns give the engine's own confidence (0–1); they are not validated probabilities."},
        "summary": _summary(kind, secs),
        "sections": secs,
    }
    title = data.get("title") or f"{kind.replace('_', ' ').capitalize()} — {start.date()} to {end.date()}"
    r = Report(org_id=p.org_id, domain=domain, kind=kind, title=title, period_start=start, period_end=end,
               area_id=area.id if area else None, content=content, created_by=p.user_id, created_at=utcnow())
    db.add(r)
    db.flush()
    audit(db, p, "report.create", "report", r.id, {"kind": kind})
    return ser(r)


def list_reports(db: Session, p: Principal):
    p.require(REPORTS)
    return [ser(r, exclude=("content",)) for r in db.scalars(select(Report).where(Report.org_id == p.org_id)
                                                              .order_by(Report.created_at.desc()).limit(100))]


def get_report(db: Session, p: Principal, rid: str):
    p.require(REPORTS)
    return ser(get_scoped(db, Report, rid, p))


def export(db: Session, p: Principal, rid: str, fmt: str) -> tuple[bytes, str, str]:
    p.require(REPORTS)
    r = get_scoped(db, Report, rid, p)
    c = r.content
    meta = [("Report", r.title), ("Period", f"{r.period_start.isoformat()} to {r.period_end.isoformat()}"),
            ("Area", c["meta"]["area"]), ("Data sources", ", ".join(c["meta"]["data_sources"])),
            ("Missing data", ", ".join(c["meta"]["missing_data"]) or "none"),
            ("AI labels", c["meta"]["ai_interpretation_labels"]), ("Confidence", c["meta"]["confidence"])]
    safe = "".join(ch if ch.isalnum() else "_" for ch in r.kind)
    if fmt == "csv":
        return exports.to_csv([{"title": "About", "columns": ["Field", "Value"], "rows": [list(m) for m in meta]}] + c["sections"]), \
            "text/csv", f"aicn_{safe}.csv"
    if fmt == "xlsx":
        return exports.to_xlsx(c["sections"], meta), \
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", f"aicn_{safe}.xlsx"
    if fmt == "pdf":
        paras = ["AI-generated summary: " + s for s in c["summary"]]
        return exports.to_pdf(r.title, meta, paras, c["sections"]), "application/pdf", f"aicn_{safe}.pdf"
    raise Invalid("format must be csv, xlsx or pdf")
