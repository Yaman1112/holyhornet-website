"""Identity, organisations, memberships, API keys, areas, operating restrictions, audit log."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import Forbidden, Invalid, NotFound, Unauthorized
from ..geo import area_m2, bbox_of
from ..models import ApiKey, Area, AuditLog, Membership, OperatingRestriction, Organization, User
from ..rbac import ORG_ADMIN, PLATFORM_ADMIN, ROLES, AUDIT_READ, Principal, permission_matrix
from ..security import api_key_prefix, create_token, hash_password, new_api_key, sha256, verify_password
from .alerts import ensure_default_rules
from .common import audit, get_scoped, ser

AREA_KINDS = {"farm_boundary", "grazing_area", "water_area", "mission_area", "conservation_area", "marine_protected_area",
              "coastal_boundary", "nesting_beach", "reef_site", "survey_area", "restricted_zone"}


def login(db: Session, email: str, password: str, org_id: str | None = None) -> dict:
    u = db.scalar(select(User).where(User.email == email.lower().strip()))
    if not u or not u.active or not verify_password(password, u.password_hash):
        audit(db, None, "auth.login_failed", "user", "", {"email": email[:80]})
        raise Unauthorized("invalid email or password")
    mems = list(db.scalars(select(Membership).where(Membership.user_id == u.id)))
    if not mems:
        raise Forbidden("user has no organisation membership")
    m = next((x for x in mems if x.org_id == org_id), None) if org_id else mems[0]
    if m is None:
        raise Forbidden("not a member of that organisation")
    role = "platform_admin" if u.is_platform_admin else m.role
    tok = create_token(u.id, m.org_id, {"role": role})
    audit(db, Principal(m.org_id, role, u.id, u.name), "auth.login", "user", u.id)
    return {"access_token": tok, "token_type": "bearer", "org_id": m.org_id, "role": role, "user": me_dict(db, u, m.org_id, role)}


def me_dict(db: Session, u: User, org_id: str, role: str) -> dict:
    orgs = [{"id": o.id, "name": o.name, "role": mm.role} for mm, o in
            db.execute(select(Membership, Organization).join(Organization, Organization.id == Membership.org_id)
                       .where(Membership.user_id == u.id))]
    from ..rbac import PERMISSIONS

    return {"id": u.id, "email": u.email, "name": u.name, "language": u.language, "org_id": org_id, "role": role,
            "role_label": ROLES.get(role, role), "permissions": sorted(PERMISSIONS.get(role, set())), "organizations": orgs}


def principal_from_token(db: Session, payload: dict) -> Principal:
    u = db.get(User, payload["sub"])
    if not u or not u.active:
        raise Unauthorized("user disabled")
    m = db.scalar(select(Membership).where(Membership.user_id == u.id, Membership.org_id == payload["org"]))
    if not m and not u.is_platform_admin:
        raise Unauthorized("membership revoked")
    role = "platform_admin" if u.is_platform_admin else m.role
    return Principal(payload["org"], role, u.id, u.name, "user", (m.scope if m else {}) or {})


def principal_from_api_key(db: Session, key: str) -> Principal:
    pre = api_key_prefix(key)
    k = db.scalar(select(ApiKey).where(ApiKey.prefix == pre, ApiKey.revoked.is_(False)))
    if not k or k.key_hash != sha256(key):
        raise Unauthorized("invalid API key")
    k.last_used_at = utcnow()
    return Principal(k.org_id, k.role, None, f"api-key:{k.name}", "api_key")


def switch_org(db: Session, p: Principal, org_id: str) -> dict:
    u = db.get(User, p.user_id)
    m = db.scalar(select(Membership).where(Membership.user_id == u.id, Membership.org_id == org_id))
    if not m and not u.is_platform_admin:
        raise Forbidden("not a member of that organisation")
    role = "platform_admin" if u.is_platform_admin else m.role
    return {"access_token": create_token(u.id, org_id, {"role": role}), "org_id": org_id, "role": role,
            "user": me_dict(db, u, org_id, role)}


def list_orgs(db: Session, p: Principal):
    if p.can(PLATFORM_ADMIN):
        return [ser(o) for o in db.scalars(select(Organization).order_by(Organization.name))]
    return [ser(db.get(Organization, p.org_id))]


def create_org(db: Session, p: Principal, data: dict):
    p.require(PLATFORM_ADMIN)
    if db.scalar(select(Organization).where(Organization.slug == data["slug"])):
        raise Invalid("slug in use")
    o = Organization(name=data["name"], slug=data["slug"], kind=data.get("kind", "farm_cooperative"),
                     country=data.get("country", "TZ"), region=data.get("region", ""), settings=data.get("settings", {}))
    db.add(o)
    db.flush()
    ensure_default_rules(db, o.id)
    audit(db, p, "org.create", "organization", o.id, org_id=o.id)
    return ser(o)


def update_org(db: Session, p: Principal, data: dict):
    p.require(ORG_ADMIN)
    o = db.get(Organization, p.org_id)
    for k in ("name", "region", "telemetry_retention_days"):
        if k in data:
            setattr(o, k, data[k])
    audit(db, p, "org.update", "organization", o.id, data)
    return ser(o)


def list_users(db: Session, p: Principal):
    p.require(ORG_ADMIN)
    rows = db.execute(select(User, Membership).join(Membership, Membership.user_id == User.id)
                      .where(Membership.org_id == p.org_id).order_by(User.name))
    return [dict(ser(u), role=m.role, role_label=ROLES.get(m.role), membership_id=m.id, scope=m.scope) for u, m in rows]


def invite_user(db: Session, p: Principal, data: dict):
    p.require(ORG_ADMIN)
    role = data.get("role")
    if role not in ROLES or role == "platform_admin":
        raise Invalid("invalid role")
    email = data["email"].lower().strip()
    if "@" not in email:
        raise Invalid("invalid email")
    u = db.scalar(select(User).where(User.email == email))
    temp = None
    if not u:
        pw = data.get("password")
        if not pw or len(pw) < 10:
            raise Invalid("a password of at least 10 characters is required for new users")
        u = User(email=email, name=data.get("name", email), phone=data.get("phone", ""), password_hash=hash_password(pw),
                 language=data.get("language", "en"))
        db.add(u)
        db.flush()
    if db.scalar(select(Membership).where(Membership.user_id == u.id, Membership.org_id == p.org_id)):
        raise Invalid("already a member")
    db.add(Membership(user_id=u.id, org_id=p.org_id, role=role, scope=data.get("scope", {})))
    audit(db, p, "user.invite", "user", u.id, {"role": role})
    return dict(ser(u), role=role, temporary_password=temp)


def set_role(db: Session, p: Principal, membership_id: str, role: str):
    p.require(ORG_ADMIN)
    m = db.get(Membership, membership_id)
    if not m or m.org_id != p.org_id:
        raise NotFound("membership not found")
    if role not in ROLES or role == "platform_admin":
        raise Invalid("invalid role")
    if m.user_id == p.user_id and role != "org_admin":
        raise Invalid("you cannot remove your own admin role")
    m.role = role
    audit(db, p, "user.role", "membership", m.id, {"role": role})
    return ser(m)


def create_api_key(db: Session, p: Principal, name: str, role: str):
    p.require(ORG_ADMIN)
    if role not in ROLES or role in ("platform_admin", "org_admin"):
        raise Invalid("API keys cannot have admin roles")
    key, prefix, h = new_api_key()
    k = ApiKey(org_id=p.org_id, name=name, prefix=prefix, key_hash=h, role=role, created_by=p.user_id)
    db.add(k)
    db.flush()
    audit(db, p, "api_key.create", "api_key", k.id, {"role": role})
    return dict(ser(k), api_key=key, note="Store this key now; it is not shown again.")


def list_api_keys(db: Session, p: Principal):
    p.require(ORG_ADMIN)
    return [ser(k) for k in db.scalars(select(ApiKey).where(ApiKey.org_id == p.org_id))]


def revoke_api_key(db: Session, p: Principal, key_id: str):
    p.require(ORG_ADMIN)
    k = get_scoped(db, ApiKey, key_id, p)
    k.revoked = True
    audit(db, p, "api_key.revoke", "api_key", k.id)
    return ser(k)


def audit_log(db: Session, p: Principal, limit=200):
    p.require(AUDIT_READ)
    return [ser(a) for a in db.scalars(select(AuditLog).where(AuditLog.org_id == p.org_id).order_by(AuditLog.at.desc()).limit(limit))]


# ------------------------------------------------------------------ areas & restrictions


def list_areas(db: Session, p: Principal, domain=None, kind=None):
    from ..rbac import SENSITIVE_READ

    q = select(Area).where(Area.org_id == p.org_id)
    if domain:
        q = q.where(Area.domain.in_(domain.split(",")))
    if kind:
        q = q.where(Area.kind.in_(kind.split(",")))
    out = []
    for a in db.scalars(q.order_by(Area.kind, Area.name)):
        d = ser(a)
        d["area_ha"] = round(area_m2(a.geometry) / 1e4, 1)
        if a.sensitive and not p.can(SENSITIVE_READ):
            d["geometry"] = None  # outline of a sensitive site is itself sensitive
            d["location_precision"] = "withheld"
        out.append(d)
    return out


def create_area(db: Session, p: Principal, data: dict):
    p.require_any(ORG_ADMIN, "missions.plan", "livestock.write", "marine.write")
    if data.get("kind") not in AREA_KINDS:
        raise Invalid(f"kind must be one of {sorted(AREA_KINDS)}")
    g = data["geometry"]
    if g.get("type") not in ("Polygon", "MultiPolygon"):
        raise Invalid("geometry must be a GeoJSON Polygon or MultiPolygon")
    a, b, c, d = bbox_of(g)
    if not (-90 <= a <= c <= 90 and -180 <= b <= d <= 180):
        raise Invalid("coordinates out of range")
    ar = Area(org_id=p.org_id, domain=data.get("domain", "shared"), kind=data["kind"], name=data["name"], geometry=g,
              min_lat=a, min_lon=b, max_lat=c, max_lon=d, sensitive=bool(data.get("sensitive", False)),
              properties=data.get("properties", {}))
    db.add(ar)
    db.flush()
    audit(db, p, "area.create", "area", ar.id, {"kind": ar.kind})
    return ser(ar)


def list_restrictions(db: Session, p: Principal):
    return [dict(ser(r), area_name=(db.get(Area, r.area_id).name if r.area_id else None))
            for r in db.scalars(select(OperatingRestriction).where(OperatingRestriction.org_id == p.org_id))]


def upsert_restriction(db: Session, p: Principal, data: dict, rid: str | None = None):
    p.require(ORG_ADMIN)
    if data.get("kind") not in ("no_fly", "altitude_limit", "wildlife_buffer", "time_window", "permit_required", "weather_limit"):
        raise Invalid("unknown restriction kind")
    r = get_scoped(db, OperatingRestriction, rid, p) if rid else OperatingRestriction(org_id=p.org_id)
    for k in ("kind", "name", "area_id", "params", "authority", "verified", "active"):
        if k in data:
            setattr(r, k, data[k])
    if r.area_id:
        get_scoped(db, Area, r.area_id, p)
    db.add(r)
    db.flush()
    audit(db, p, "restriction.upsert", "restriction", r.id, data)
    return ser(r)


def roles() -> dict:
    return {"roles": ROLES, "permissions": permission_matrix()}
