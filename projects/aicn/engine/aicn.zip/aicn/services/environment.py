"""Environmental measurements (both divisions) and the offline mobile sync endpoint."""

from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import Invalid
from ..models import EnvMeasurement, IdempotencyKey
from ..rbac import ENV_READ, ENV_WRITE, Principal
from .common import audit, ser

UNITS = {"water_temp": "degC", "air_temp": "degC", "turbidity": "NTU", "water_clarity": "m", "depth": "m", "rainfall": "mm",
         "water_level": "%", "ndvi": "1", "wind_speed": "m/s", "salinity": "PSU", "ph": "pH", "dissolved_oxygen": "mg/L"}


def measurements(db: Session, p: Principal, kind: str | None = None, domain: str | None = None, hours: float = 72,
                 end: datetime | None = None, limit: int = 2000):
    p.require(ENV_READ)
    end = end or utcnow()
    q = select(EnvMeasurement).where(EnvMeasurement.org_id == p.org_id, EnvMeasurement.measured_at >= end - timedelta(hours=hours))
    if kind:
        q = q.where(EnvMeasurement.kind.in_(kind.split(",")))
    if domain:
        q = q.where(EnvMeasurement.domain == domain)
    return [ser(m) for m in db.scalars(q.order_by(EnvMeasurement.measured_at).limit(limit))]


def add_measurement(db: Session, p: Principal, data: dict):
    p.require(ENV_WRITE)
    kind = data["kind"]
    unit = data.get("unit") or UNITS.get(kind)
    if not unit:
        raise Invalid("unit is required for this kind")
    m = EnvMeasurement(org_id=p.org_id, domain=data.get("domain", "shared"), kind=kind, value=float(data["value"]), unit=unit,
                       lat=data.get("lat"), lon=data.get("lon"), area_id=data.get("area_id"),
                       measured_at=datetime.fromisoformat(data["measured_at"]) if data.get("measured_at") else utcnow(),
                       source=data.get("source", "manual"), is_estimate=bool(data.get("is_estimate", False)),
                       quality=data.get("quality", "good"), calibration=data.get("calibration", {}),
                       clock_source=data.get("clock_source", "ntp"))
    db.add(m)
    db.flush()
    return ser(m)


def sync_batch(db: Session, p: Principal, items: list[dict]) -> dict:
    """Offline-first mobile upload. Each item: {idempotency_key, type, data}. Re-sent items are acknowledged, not duplicated."""
    from . import livestock, marine

    results = []
    for it in items[:500]:
        key = str(it.get("idempotency_key", ""))[:80]
        if len(key) < 8:
            results.append({"idempotency_key": key, "status": "rejected", "error": "idempotency_key (≥ 8 chars) required"})
            continue
        prev = db.get(IdempotencyKey, key)
        if prev:
            results.append({"idempotency_key": key, "status": "duplicate", "id": prev.resource_id})
            continue
        try:
            t, d = it["type"], it["data"]
            if t == "marine_observation":
                r = marine.create_observation(db, p, d)
            elif t == "health_note":
                r = livestock.add_manual_health(db, p, d["animal_id"], d)
            elif t == "env_measurement":
                r = add_measurement(db, p, d)
            elif t == "nest_event":
                r = marine.add_nest_event(db, p, d["nest_id"], d)
            else:
                raise Invalid(f"unknown type {t}")
            db.add(IdempotencyKey(key=key, org_id=p.org_id, resource=t, resource_id=r["id"]))
            db.flush()
            results.append({"idempotency_key": key, "status": "created", "id": r["id"]})
        except Exception as e:  # report per item, keep going
            results.append({"idempotency_key": key, "status": "rejected", "error": getattr(e, "detail", str(e))[:300]})
    audit(db, p, "sync.batch", "sync", "", {"items": len(items), "created": sum(r["status"] == "created" for r in results)})
    return {"results": results, "server_time": utcnow().isoformat()}
