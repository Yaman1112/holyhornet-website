"""Device registry, authentication and store-and-forward ingest (collars, sensors, UAVs, ROVs)."""

from __future__ import annotations

import base64
import hmac
from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..engines import codec
from ..errors import Invalid, NotFound, Unauthorized
from ..models import (Animal, CollarTelemetry, Device, EnvMeasurement, IngestBatch, MaintenanceRecord, WaterObservation,
                      WaterPoint)
from ..rbac import DEVICES_READ, DEVICES_WRITE, Principal
from ..security import new_device_secret, sha256, sign_device_payload
from . import alerts, events
from .common import audit, get_scoped, ser

DEVICE_TYPES = {"collar", "ear_tag", "env_sensor", "water_sensor", "gateway", "uav", "rov", "auv"}


def to_dict(d: Device) -> dict:
    out = ser(d)
    out["stale_minutes"] = None
    if d.last_seen_at:
        out["stale_minutes"] = round((utcnow() - d.last_seen_at).total_seconds() / 60, 1)
    return out


def list_devices(db: Session, p: Principal, device_type: str | None = None, domain: str | None = None):
    p.require(DEVICES_READ)
    q = select(Device).where(Device.org_id == p.org_id)
    if device_type:
        q = q.where(Device.device_type.in_(device_type.split(",")))
    if domain:
        q = q.where(Device.domain == domain)
    return [to_dict(d) for d in db.scalars(q.order_by(Device.device_type, Device.name))]


def get_device(db: Session, p: Principal, device_id: str):
    p.require(DEVICES_READ)
    d = get_scoped(db, Device, device_id, p)
    out = to_dict(d)
    out["maintenance"] = [ser(m) for m in db.scalars(select(MaintenanceRecord).where(MaintenanceRecord.device_id == d.id)
                                                     .order_by(MaintenanceRecord.performed_at.desc()))]
    out["ingest"] = [ser(b) for b in db.scalars(select(IngestBatch).where(IngestBatch.device_id == d.id)
                                                .order_by(IngestBatch.received_at.desc()).limit(20))]
    from ..models import Mission

    out["missions"] = [{"id": m.id, "name": m.name, "status": m.status, "kind": m.kind}
                       for m in db.scalars(select(Mission).where(Mission.device_id == d.id).order_by(Mission.created_at.desc()).limit(20))]
    return out


def register(db: Session, p: Principal, data: dict) -> dict:
    p.require(DEVICES_WRITE)
    if data.get("device_type") not in DEVICE_TYPES:
        raise Invalid(f"device_type must be one of {sorted(DEVICE_TYPES)}")
    if db.scalar(select(Device).where(Device.serial == data["serial"])):
        raise Invalid("serial already registered")
    secret, h = new_device_secret()
    d = Device(org_id=p.org_id, secret_hash=h, **{k: v for k, v in data.items() if k in {
        "domain", "device_type", "category", "name", "serial", "manufacturer", "model", "firmware", "comms", "specs",
        "animal_id", "simulated", "battery_pct"}})
    if d.animal_id:
        get_scoped(db, Animal, d.animal_id, p)
    db.add(d)
    db.flush()
    audit(db, p, "device.register", "device", d.id, {"serial": d.serial})
    out = to_dict(d)
    out["device_secret"] = secret  # shown once; store it on the device
    return out


def update(db: Session, p: Principal, device_id: str, data: dict):
    p.require(DEVICES_WRITE)
    d = get_scoped(db, Device, device_id, p)
    for k in ("name", "status", "firmware", "animal_id", "specs", "comms", "category"):
        if k in data:
            setattr(d, k, data[k])
    audit(db, p, "device.update", "device", d.id, data)
    return to_dict(d)


def add_maintenance(db: Session, p: Principal, device_id: str, data: dict):
    p.require(DEVICES_WRITE)
    d = get_scoped(db, Device, device_id, p)
    m = MaintenanceRecord(org_id=p.org_id, device_id=d.id, kind=data["kind"], notes=data.get("notes", ""),
                          performed_by=data.get("performed_by") or p.name, performed_at=utcnow())
    db.add(m)
    if data.get("kind") == "battery_replacement":
        d.battery_pct = 100.0
    if data.get("firmware"):
        d.firmware = data["firmware"]
    audit(db, p, "device.maintenance", "device", d.id, data)
    return ser(m)


def authenticate_device(db: Session, device_id: str, key: str | None, signature: str | None, body: bytes) -> Device:
    d = db.get(Device, device_id)
    if d is None or d.status == "retired":
        raise Unauthorized("unknown device")
    if key and hmac.compare_digest(sha256(key), d.secret_hash):
        return d
    raise Unauthorized("device authentication failed")


def verify_signature(secret: str, body: bytes, signature: str) -> bool:
    return hmac.compare_digest(sign_device_payload(secret, body), signature)


# ------------------------------------------------------------------ ingest


def ingest(db: Session, d: Device, payload: dict, now: datetime | None = None) -> dict:
    """payload: {encoding: json|ac1, records: [...] | data: base64, dropped: int}. Idempotent per (device, seq)."""
    now = now or utcnow()
    enc = payload.get("encoding", "json")
    if enc == "ac1":
        blob = base64.b64decode(payload["data"])
        recs = codec.decode_batch(blob)
        nbytes = len(blob)
    elif enc == "json":
        recs = payload.get("records") or []
        nbytes = len(str(recs))
    else:
        raise Invalid("encoding must be json or ac1")
    if not recs:
        return {"ack_seq": d.last_seq, "accepted": 0, "duplicates": 0, "gaps": 0}
    if len(recs) > 2000:
        raise Invalid("batch too large (max 2000 records)")
    if d.device_type in ("collar", "ear_tag"):
        res = _ingest_collar(db, d, recs, now)
    elif d.device_type in ("env_sensor", "water_sensor"):
        res = _ingest_env(db, d, recs, now)
    else:
        raise Invalid(f"ingest not supported for {d.device_type} (UAV/ROV telemetry arrives through missions)")
    seqs = [int(r["seq"]) for r in recs]
    gaps = max(0, min(seqs) - (d.last_seq + 1)) if d.last_seq >= 0 else 0
    delays = [(now - _ts(r["t"])).total_seconds() for r in recs]
    db.add(IngestBatch(org_id=d.org_id, device_id=d.id, received_at=now, seq_first=min(seqs), seq_last=max(seqs),
                       n_records=len(recs), n_duplicates=res["duplicates"], n_gaps=gaps, payload_bytes=nbytes,
                       encoding=enc, max_delay_s=max(delays)))
    d.last_seq = max(d.last_seq, max(seqs))
    d.last_seen_at = now
    d.connectivity = "online"
    last = max(recs, key=lambda r: r["seq"])
    if last.get("battery_pct") is not None:
        d.battery_pct = float(last["battery_pct"])
    if last.get("lat") is not None:
        d.last_lat, d.last_lon = last["lat"], last["lon"]
    d.health = "ok"
    if payload.get("dropped"):
        d.health = "degraded"
    _battery_alert(db, d)
    events.publish(d.org_id, "telemetry.ingested", {"device_id": d.id, "records": len(recs) - res["duplicates"],
                                                    "max_delay_min": round(max(delays) / 60, 1)})
    return {"ack_seq": d.last_seq, "accepted": len(recs) - res["duplicates"], "duplicates": res["duplicates"], "gaps": gaps}


def _ts(t) -> datetime:
    if isinstance(t, datetime):
        return t if t.tzinfo else t.replace(tzinfo=timezone.utc)
    if isinstance(t, str):
        return datetime.fromisoformat(t.replace("Z", "+00:00"))
    return datetime.fromtimestamp(float(t), timezone.utc)


def _ingest_collar(db: Session, d: Device, recs: list[dict], now) -> dict:
    seqs = [int(r["seq"]) for r in recs]
    have = set(db.scalars(select(CollarTelemetry.seq).where(CollarTelemetry.device_id == d.id,
                                                             CollarTelemetry.seq.in_(seqs))))
    dup = 0
    rows = []
    for r in recs:
        if int(r["seq"]) in have:
            dup += 1
            continue
        have.add(int(r["seq"]))
        rows.append(CollarTelemetry(org_id=d.org_id, device_id=d.id, animal_id=d.animal_id, seq=int(r["seq"]),
                                    recorded_at=_ts(r["t"]), received_at=now, lat=r.get("lat"), lon=r.get("lon"),
                                    hdop=r.get("hdop"), speed_mps=r.get("speed_mps"), activity=r.get("activity"),
                                    rest_fraction=r.get("rest_fraction"), temp_c=r.get("temp_c"),
                                    ambient_c=r.get("ambient_c"), battery_pct=r.get("battery_pct"), rssi=r.get("rssi"),
                                    water_visit=r.get("water_visit")))
    db.add_all(rows)
    if d.animal_id and rows:
        a = db.get(Animal, d.animal_id)
        newest = max(rows, key=lambda x: x.recorded_at)
        if a and (a.last_fix_at is None or newest.recorded_at > a.last_fix_at) and newest.lat is not None:
            a.last_lat, a.last_lon, a.last_fix_at = newest.lat, newest.lon, newest.recorded_at
    return {"duplicates": dup}


def _ingest_env(db: Session, d: Device, recs: list[dict], now) -> dict:
    dup = 0
    if d.last_seq >= 0:
        dup = sum(1 for r in recs if int(r["seq"]) <= d.last_seq)
    wp = db.scalar(select(WaterPoint).where(WaterPoint.device_id == d.id)) if d.device_type == "water_sensor" else None
    for r in recs:
        if d.last_seq >= 0 and int(r["seq"]) <= d.last_seq:
            continue
        for kind, val in (r.get("values") or {}).items():
            unit = (r.get("units") or {}).get(kind, "")
            qual = "good"
            if r.get("quality", {}).get(kind):
                qual = r["quality"][kind]
            db.add(EnvMeasurement(org_id=d.org_id, domain=d.domain, kind=kind, value=float(val), unit=unit,
                                  lat=r.get("lat", d.last_lat), lon=r.get("lon", d.last_lon), device_id=d.id,
                                  area_id=(d.specs or {}).get("area_id"), measured_at=_ts(r["t"]), source="sensor",
                                  quality=qual, calibration=(d.specs or {}).get("calibration", {}),
                                  clock_source=r.get("clock", "gnss")))
            if wp is not None and kind == "water_level":
                db.add(WaterObservation(org_id=d.org_id, water_point_id=wp.id, observed_at=_ts(r["t"]),
                                        level_pct=float(val), source="sensor"))
    return {"duplicates": dup}


def _battery_alert(db: Session, d: Device):
    rule = alerts.rule_for(db, d.org_id, "low_battery")
    th = (rule.params or {}).get("battery_pct", 20) if rule else 20
    if d.battery_pct is not None and d.battery_pct < th:
        alerts.raise_alert(db, d.org_id, d.domain, "low_battery", f"Low battery: {d.name}",
                           f"{d.name} reports {d.battery_pct:.0f}% battery (threshold {th}%). Plan a battery change or recharge.",
                           subject_type="device", subject_id=d.id, lat=d.last_lat, lon=d.last_lon,
                           evidence={"battery_pct": d.battery_pct}, confidence=0.99, requires_review=False,
                           dedupe_key=f"low_battery:{d.id}", source="device")


def refresh_connectivity(db: Session, org_id: str, now: datetime):
    """Mark devices buffering/offline from their last contact and raise device_offline alerts."""
    rule = alerts.rule_for(db, org_id, "device_offline")
    th_h = (rule.params or {}).get("silent_hours", 1.5) if rule else 1.5
    for d in db.scalars(select(Device).where(Device.org_id == org_id, Device.device_type.in_(
            ["collar", "ear_tag", "env_sensor", "water_sensor", "gateway"]), Device.status == "active")):
        if d.last_seen_at is None:
            continue
        silent = (now - d.last_seen_at).total_seconds() / 3600
        if silent > 6:
            d.connectivity = "offline"
        elif silent > th_h:
            d.connectivity = "buffering"
        else:
            d.connectivity = "online"
        if silent > max(th_h * 3, 4):
            alerts.raise_alert(db, org_id, d.domain, "device_offline", f"No data from {d.name}",
                               f"{d.name} has not uploaded for {silent:.1f} h. Collars store data while out of range; "
                               "if it stays silent, check the device and the gateway.",
                               subject_type="device", subject_id=d.id, lat=d.last_lat, lon=d.last_lon,
                               evidence={"silent_hours": round(silent, 1)}, confidence=0.9, requires_review=False,
                               dedupe_key=f"device_offline:{d.id}", source="engine")


def fleet_summary(db: Session, p: Principal) -> dict:
    p.require(DEVICES_READ)
    rows = db.execute(select(Device.device_type, Device.connectivity, func.count()).where(Device.org_id == p.org_id)
                      .group_by(Device.device_type, Device.connectivity)).all()
    out: dict = {}
    for t, c, n in rows:
        out.setdefault(t, {})[c] = n
    return out


def ingest_stats(db: Session, p: Principal, hours: float = 24, now: datetime | None = None) -> dict:
    p.require(DEVICES_READ)
    now = now or utcnow()
    since = now - timedelta(hours=hours)
    b = db.execute(select(func.count(), func.sum(IngestBatch.n_records), func.sum(IngestBatch.n_duplicates),
                          func.sum(IngestBatch.n_gaps), func.sum(IngestBatch.payload_bytes), func.max(IngestBatch.max_delay_s))
                   .where(IngestBatch.org_id == p.org_id, IngestBatch.received_at >= since)).one()
    return {"batches": b[0] or 0, "records": b[1] or 0, "duplicates": b[2] or 0, "gaps": b[3] or 0,
            "bytes": b[4] or 0, "max_delay_min": round((b[5] or 0) / 60, 1), "window_h": hours}


def find_device(db: Session, p: Principal, device_id: str) -> Device:
    d = db.get(Device, device_id)
    if d is None or d.org_id != p.org_id:
        raise NotFound("device not found")
    return d
