"""Object storage abstraction for images and video frames.

Backends: local directory (development / single node) or in-memory (browser edition, tests).
Production uses S3-compatible storage (Supabase Storage, Cloudflare R2, AWS S3) behind the same put/get API.
"""

from __future__ import annotations

import os
from collections import OrderedDict

from .. import config


class MediaStore:
    def __init__(self, directory: str | None, max_items: int = 600):
        self.dir = directory
        self.mem: OrderedDict[str, tuple[bytes, str]] = OrderedDict()
        self.max_items = max_items
        if directory:
            os.makedirs(directory, exist_ok=True)

    def put(self, key: str, data: bytes, content_type: str = "image/png") -> str:
        if self.dir:
            with open(os.path.join(self.dir, key), "wb") as f:
                f.write(data)
        else:
            self.mem[key] = (data, content_type)
            while len(self.mem) > self.max_items:
                self.mem.popitem(last=False)
        return f"media://{key}"

    def get(self, key: str) -> tuple[bytes, str] | None:
        if self.dir:
            p = os.path.join(self.dir, os.path.basename(key))
            if os.path.exists(p):
                with open(p, "rb") as f:
                    return f.read(), "image/png"
            return None
        return self.mem.get(key)


_store: MediaStore | None = None


def store() -> MediaStore:
    global _store
    if _store is None:
        s = config.settings
        _store = MediaStore(None if s.browser_mode or s.database_url.startswith("sqlite://") and ":memory:" in s.database_url
                            or s.database_url == "sqlite://" else s.media_dir)
    return _store


def reset(directory: str | None = None):
    global _store
    _store = MediaStore(directory)
