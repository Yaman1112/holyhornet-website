"""In-process event bus for real-time updates (WebSocket push on the server, polling in the browser edition).

Production deployments with several API replicas swap this for Redis pub/sub (same publish/subscribe API).
"""

from __future__ import annotations

import asyncio
import itertools
from collections import deque

from ..db import utcnow

_seq = itertools.count(1)
_buf: deque = deque(maxlen=2000)
_subs: set[asyncio.Queue] = set()


def publish(org_id: str, kind: str, data: dict | None = None, sensitive: bool = False) -> dict:
    ev = {"id": next(_seq), "org_id": org_id, "kind": kind, "at": utcnow().isoformat(), "data": data or {},
          "sensitive": sensitive}
    _buf.append(ev)
    for q in list(_subs):
        try:
            q.put_nowait(ev)
        except Exception:
            pass
    return ev


def since(org_id: str, after_id: int, limit: int = 200) -> list[dict]:
    return [e for e in _buf if e["org_id"] == org_id and e["id"] > after_id][-limit:]


def subscribe() -> asyncio.Queue:
    q: asyncio.Queue = asyncio.Queue(maxsize=500)
    _subs.add(q)
    return q


def unsubscribe(q):
    _subs.discard(q)


def reset():
    _buf.clear()
