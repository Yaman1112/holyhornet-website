"""Business logic. Each function takes (db, principal, ...) and enforces permissions and organisation scope."""
