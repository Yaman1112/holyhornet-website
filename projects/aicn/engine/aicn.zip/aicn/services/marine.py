"""Marine Animal Intelligence services: species, observations + verification, nests, habitat, ROV dives, behaviour."""

from __future__ import annotations

from datetime import date, datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import Forbidden, Invalid
from ..models import (Alert, Area, BehaviourEvent, EnvMeasurement, HabitatObservation, MarineObservation, Mission, Nest,
                      NestEvent, RovDive, Species)
from ..rbac import MARINE_READ, MARINE_VERIFY, MARINE_WRITE, SENSITIVE_READ, Principal
from . import events
from .common import audit, get_scoped, protect, ser

VERIFICATION = {"unverified", "verified", "rejected", "needs_expert"}


def list_species(db: Session, p: Principal):
    p.require(MARINE_READ)
    q = select(Species).where((Species.org_id.is_(None)) | (Species.org_id == p.org_id)).order_by(Species.group, Species.common_name)
    return [ser(s) for s in db.scalars(q)]


def create_species(db: Session, p: Principal, data: dict):
    p.require(MARINE_WRITE)
    if db.get(Species, data["id"]):
        raise Invalid("species id exists")
    s = Species(org_id=p.org_id, **{k: data[k] for k in ("id", "common_name", "common_name_sw", "scientific_name", "group",
                                                         "iucn_status", "sensitive", "profile") if k in data})
    db.add(s)
    db.flush()
    return ser(s)


def _obs_dict(o: MarineObservation, p: Principal, sp: dict) -> dict:
    d = ser(o)
    s = sp.get(o.species_id)
    d["species_name"] = s.common_name if s else None
    d["sensitive"] = bool(o.sensitive or (s and s.sensitive))
    return protect(d, p)


def list_observations(db: Session, p: Principal, start=None, end=None, group=None, verification=None, mission_id=None,
                      bbox=None, limit=500):
    p.require(MARINE_READ)
    q = select(MarineObservation).where(MarineObservation.org_id == p.org_id)
    if start:
        q = q.where(MarineObservation.observed_at >= start)
    if end:
        q = q.where(MarineObservation.observed_at <= end)
    if group:
        q = q.where(MarineObservation.species_group.in_(group.split(",")))
    if verification:
        q = q.where(MarineObservation.verification.in_(verification.split(",")))
    if mission_id:
        q = q.where(MarineObservation.mission_id == mission_id)
    if bbox:
        a, b, c, d = bbox
        q = q.where(MarineObservation.lat.between(a, c), MarineObservation.lon.between(b, d))
    sp = {s.id: s for s in db.scalars(select(Species))}
    return [_obs_dict(o, p, sp) for o in db.scalars(q.order_by(MarineObservation.observed_at.desc()).limit(limit))]


def create_observation(db: Session, p: Principal, data: dict, now: datetime | None = None):
    p.require(MARINE_WRITE)
    sp = db.get(Species, data["species_id"]) if data.get("species_id") else None
    if data.get("species_id") and not sp:
        raise Invalid("unknown species")
    if data.get("individual_id") and not data.get("individual_validation"):
        raise Invalid("individual identification needs a recorded validation (photo-ID match by a researcher)")
    o = MarineObservation(org_id=p.org_id, species_id=sp.id if sp else None,
                          species_group=sp.group if sp else data.get("species_group", "other"),
                          count=int(data.get("count", 1)), lat=float(data["lat"]), lon=float(data["lon"]),
                          observed_at=datetime.fromisoformat(data["observed_at"]) if data.get("observed_at") else (now or utcnow()),
                          method=data.get("method", "boat_survey"), source="human", confidence=data.get("confidence"),
                          verification="unverified", environment=data.get("environment", {}), notes=data.get("notes", ""),
                          sensitive=bool(data.get("sensitive", sp.sensitive if sp else False)),
                          individual_id=data.get("individual_id"))
    db.add(o)
    db.flush()
    audit(db, p, "marine_observation.create", "marine_observation", o.id)
    events.publish(p.org_id, "marine.observation", {"id": o.id, "group": o.species_group}, o.sensitive)
    return _obs_dict(o, p, {sp.id: sp} if sp else {})


def verify_observation(db: Session, p: Principal, obs_id: str, status: str, note: str = "", species_id: str | None = None,
                       count: int | None = None):
    p.require(MARINE_VERIFY)
    if status not in VERIFICATION:
        raise Invalid(f"status must be one of {sorted(VERIFICATION)}")
    o = get_scoped(db, MarineObservation, obs_id, p)
    if species_id:
        sp = db.get(Species, species_id)
        if not sp:
            raise Invalid("unknown species")
        o.species_id, o.species_group = sp.id, sp.group
    if count is not None:
        o.count = int(count)
    o.verification, o.verified_by, o.verification_note = status, p.user_id, note
    # propagate the review to the underlying AI detections (feeds model evaluation)
    from ..models import AIDetection

    for det in db.scalars(select(AIDetection).where(AIDetection.id.in_(o.detection_ids or []))):
        det.review_status = {"verified": "confirmed" if not species_id else "corrected", "rejected": "rejected"}.get(status, det.review_status)
        det.review_label = species_id or det.review_label
        det.reviewed_by = p.user_id
    audit(db, p, "marine_observation.verify", "marine_observation", o.id, {"status": status, "species_id": species_id})
    return _obs_dict(o, p, {s.id: s for s in db.scalars(select(Species))})


# ------------------------------------------------------------------ nests (sensitive)


def _nest_dict(n: Nest, p: Principal) -> dict:
    d = ser(n)
    d["sensitive"] = True
    return protect(d, p, True)


def list_nests(db: Session, p: Principal, beach_area_id=None, status=None):
    p.require(MARINE_READ)
    q = select(Nest).where(Nest.org_id == p.org_id)
    if beach_area_id:
        q = q.where(Nest.beach_area_id == beach_area_id)
    if status:
        q = q.where(Nest.status.in_(status.split(",")))
    out = [_nest_dict(n, p) for n in db.scalars(q.order_by(Nest.laid_on.desc()))]
    if not p.can(SENSITIVE_READ):
        for d in out:  # codes can reveal positions on small beaches; keep only aggregate-safe fields
            d["notes"] = ""
    return out


def create_nest(db: Session, p: Principal, data: dict):
    p.require(MARINE_WRITE, SENSITIVE_READ)
    beach = get_scoped(db, Area, data["beach_area_id"], p)
    if beach.kind != "nesting_beach":
        raise Invalid("area is not a nesting beach")
    laid = date.fromisoformat(data["laid_on"])
    n = Nest(org_id=p.org_id, beach_area_id=beach.id, code=data["code"], species_id=data.get("species_id"),
             lat=float(data["lat"]), lon=float(data["lon"]), laid_on=laid,
             expected_hatch_from=laid + timedelta(days=int(data.get("incubation_days", 50))),
             clutch_size=data.get("clutch_size"), site_condition=data.get("site_condition", ""), notes=data.get("notes", ""),
             protected=bool(data.get("protected", False)))
    db.add(n)
    db.flush()
    db.add(NestEvent(org_id=p.org_id, nest_id=n.id, at=utcnow(), kind="laid", detail=data.get("notes", ""), observer=p.name))
    audit(db, p, "nest.create", "nest", n.id)
    return _nest_dict(n, p)


def nest_detail(db: Session, p: Principal, nest_id: str):
    p.require(MARINE_READ)
    n = get_scoped(db, Nest, nest_id, p)
    d = _nest_dict(n, p)
    d["events"] = [ser(e) for e in db.scalars(select(NestEvent).where(NestEvent.nest_id == n.id).order_by(NestEvent.at.desc()))]
    return d


def add_nest_event(db: Session, p: Principal, nest_id: str, data: dict, now: datetime | None = None):
    p.require(MARINE_WRITE)
    n = get_scoped(db, Nest, nest_id, p)
    kind = data["kind"]
    e = NestEvent(org_id=p.org_id, nest_id=n.id, at=now or utcnow(), kind=kind, detail=data.get("detail", ""),
                  observer=data.get("observer") or p.name)
    db.add(e)
    if kind == "hatching":
        n.status = "hatched"
        if data.get("hatchlings_emerged") is not None:
            n.hatchlings_emerged = int(data["hatchlings_emerged"])
    elif kind in ("predation_sign", "inundation"):
        n.site_condition = kind
        if data.get("failed"):
            n.status = "predated" if kind == "predation_sign" else "washed_out"
    elif kind == "conservation_action":
        n.protected = True
    audit(db, p, "nest.event", "nest", n.id, {"kind": kind})
    db.flush()
    return ser(e)


# ------------------------------------------------------------------ habitat, environment, ROV, behaviour


def habitat(db: Session, p: Principal, kind=None, limit=500):
    p.require(MARINE_READ)
    q = select(HabitatObservation).where(HabitatObservation.org_id == p.org_id)
    if kind:
        q = q.where(HabitatObservation.kind == kind)
    return [ser(h) for h in db.scalars(q.order_by(HabitatObservation.observed_at.desc()).limit(limit))]


def rov_dives(db: Session, p: Principal):
    p.require(MARINE_READ)
    out = []
    for d in db.scalars(select(RovDive).where(RovDive.org_id == p.org_id).order_by(RovDive.started_at.desc())):
        x = ser(d, exclude=("track",))
        x["track_points"] = len(d.track or [])
        out.append(x)
    return out


def rov_dive(db: Session, p: Principal, dive_id: str):
    p.require(MARINE_READ)
    return ser(get_scoped(db, RovDive, dive_id, p))


def behaviour_events(db: Session, p: Principal, mission_id=None, limit=300):
    p.require(MARINE_READ)
    q = select(BehaviourEvent).where(BehaviourEvent.org_id == p.org_id)
    if mission_id:
        q = q.where(BehaviourEvent.mission_id == mission_id)
    return [protect(ser(b), p) for b in db.scalars(q.order_by(BehaviourEvent.at.desc()).limit(limit))]


def review_behaviour(db: Session, p: Principal, ev_id: str, status: str, note: str):
    p.require(MARINE_VERIFY)
    b = get_scoped(db, BehaviourEvent, ev_id, p)
    if status not in ("confirmed", "rejected", "uncertain"):
        raise Invalid("status must be confirmed, rejected or uncertain")
    b.review_status = status
    b.interpretation = dict(b.interpretation or {}, review_note=note, reviewed_by=p.user_id)
    audit(db, p, "behaviour.review", "behaviour_event", b.id, {"status": status})
    return protect(ser(b), p)


def dashboard(db: Session, p: Principal, now: datetime | None = None):
    p.require(MARINE_READ)
    now = now or utcnow()
    since = now - timedelta(days=30)
    rows = db.execute(select(MarineObservation.species_group, MarineObservation.verification, func.sum(MarineObservation.count))
                      .where(MarineObservation.org_id == p.org_id, MarineObservation.observed_at >= since)
                      .group_by(MarineObservation.species_group, MarineObservation.verification)).all()
    by_group: dict = {}
    for g, v, n in rows:
        by_group.setdefault(g, {})[v] = int(n or 0)
    nests = db.execute(select(Nest.status, func.count()).where(Nest.org_id == p.org_id).group_by(Nest.status)).all()
    env = {}
    for kind in ("water_temp", "turbidity", "water_clarity"):
        m = db.scalar(select(EnvMeasurement).where(EnvMeasurement.org_id == p.org_id, EnvMeasurement.kind == kind)
                      .order_by(EnvMeasurement.measured_at.desc()))
        if m:
            env[kind] = {"value": round(m.value, 2), "unit": m.unit, "at": m.measured_at.isoformat(), "quality": m.quality}
    pending = db.scalar(select(func.count()).select_from(MarineObservation).where(
        MarineObservation.org_id == p.org_id, MarineObservation.verification.in_(["unverified", "needs_expert"])))
    hab = {}
    for kind in ("coral_cover", "debris"):
        v = db.scalar(select(func.avg(HabitatObservation.value)).where(HabitatObservation.org_id == p.org_id,
                                                                       HabitatObservation.kind == kind))
        if v is not None:
            hab[kind] = round(float(v), 3)
    missions = db.scalars(select(Mission).where(Mission.org_id == p.org_id, Mission.domain == "marine")
                          .order_by(Mission.created_at.desc()).limit(8))
    al = db.scalars(select(Alert).where(Alert.org_id == p.org_id, Alert.domain == "marine",
                                        Alert.status.in_(["open", "acknowledged"])).order_by(Alert.created_at.desc()).limit(10))
    return {"observations_30d": by_group, "pending_verification": pending, "nests": {s: n for s, n in nests},
            "environment": env, "habitat": hab,
            "missions": [{"id": m.id, "name": m.name, "kind": m.kind, "status": m.status} for m in missions],
            "alerts": [protect(ser(a), p) for a in al], "dives": rov_dives(db, p)[:5]}


def public_summary(db: Session, org_id: str) -> dict:
    """Aggregate-only data safe for public pages: counts per species group and region, no coordinates, no nests."""
    rows = db.execute(select(MarineObservation.species_group, func.sum(MarineObservation.count))
                      .where(MarineObservation.org_id == org_id, MarineObservation.verification == "verified")
                      .group_by(MarineObservation.species_group)).all()
    n_nests = db.scalar(select(func.count()).select_from(Nest).where(Nest.org_id == org_id))
    return {"verified_observations_by_group": {g: int(n or 0) for g, n in rows}, "nests_monitored": n_nests or 0,
            "note": "Aggregated counts only. Locations of sensitive species and nests are never published."}


def ensure_can_see_precise(p: Principal):
    if not p.can(SENSITIVE_READ):
        raise Forbidden("precise sensitive locations need the sensitive.read permission")
