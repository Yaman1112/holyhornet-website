"""GIS layers as GeoJSON FeatureCollections, with bbox / time filters and sensitive-location protection.
Historical playback returns time-stamped positions for a window so the map can replay movement."""

from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import Invalid
from ..geo import generalize
from ..models import (Alert, Animal, Area, CollarTelemetry, Device, EnvMeasurement, HabitatObservation, MarineObservation,
                      Mission, Nest, RovDive, WaterPoint)
from ..rbac import LIVESTOCK_READ, MARINE_READ, SENSITIVE_READ, Principal
from .common import protect, ser

LAYERS = {
    "livestock": ["animals", "herd_areas", "grazing_areas", "water_points", "movement", "uav_missions", "alerts"],
    "marine": ["coastal_boundaries", "protected_areas", "marine_observations", "nesting_areas", "nests", "reef_observations",
               "underwater_routes", "environment", "uav_missions", "alerts"],
    "shared": ["restricted_zones", "devices"],
}


def _fc(features):
    return {"type": "FeatureCollection", "features": features}


def _pt(lat, lon, props):
    return {"type": "Feature", "geometry": {"type": "Point", "coordinates": [lon, lat]}, "properties": props}


def _in_bbox(lat, lon, bbox):
    if not bbox or lat is None:
        return True
    a, b, c, d = bbox
    return a <= lat <= c and b <= lon <= d


def layer(db: Session, p: Principal, name: str, bbox=None, start: datetime | None = None, end: datetime | None = None,
          domain: str | None = None) -> dict:
    end = end or utcnow()
    feats = []
    if name in ("animals", "movement"):
        p.require(LIVESTOCK_READ)
    if name in ("marine_observations", "nests", "reef_observations", "underwater_routes", "nesting_areas"):
        p.require(MARINE_READ)
    if name == "animals":
        q = select(Animal).where(Animal.org_id == p.org_id, Animal.last_lat.isnot(None))
        if p.farm_scope is not None:
            q = q.where(Animal.farm_id.in_(p.farm_scope))
        for a in db.scalars(q):
            if _in_bbox(a.last_lat, a.last_lon, bbox):
                age = (end - a.last_fix_at).total_seconds() / 60 if a.last_fix_at else None
                feats.append(_pt(a.last_lat, a.last_lon, {"id": a.id, "tag": a.tag, "name": a.name, "species": a.species,
                                                          "status": a.status, "herd_id": a.herd_id,
                                                          "fix_age_min": round(age) if age is not None else None}))
    elif name == "movement":
        start = start or end - timedelta(hours=12)
        rows = db.execute(select(CollarTelemetry.animal_id, CollarTelemetry.recorded_at, CollarTelemetry.lat, CollarTelemetry.lon)
                          .where(CollarTelemetry.org_id == p.org_id, CollarTelemetry.recorded_at.between(start, end),
                                 CollarTelemetry.lat.isnot(None)).order_by(CollarTelemetry.recorded_at)).all()
        by: dict = {}
        for aid, t, la, lo in rows:
            by.setdefault(aid, []).append([lo, la])
        tags = {a.id: a.tag for a in db.scalars(select(Animal).where(Animal.org_id == p.org_id))}
        for aid, coords in by.items():
            if len(coords) > 1:
                feats.append({"type": "Feature", "geometry": {"type": "LineString", "coordinates": coords},
                              "properties": {"animal_id": aid, "tag": tags.get(aid, "")}})
    elif name in ("herd_areas", "grazing_areas", "coastal_boundaries", "protected_areas", "nesting_areas", "restricted_zones"):
        kinds = {"herd_areas": ["farm_boundary"], "grazing_areas": ["grazing_area"], "coastal_boundaries": ["coastal_boundary"],
                 "protected_areas": ["marine_protected_area", "conservation_area", "survey_area", "reef_site"],
                 "nesting_areas": ["nesting_beach"], "restricted_zones": ["restricted_zone"]}[name]
        for a in db.scalars(select(Area).where(Area.org_id == p.org_id, Area.kind.in_(kinds))):
            if a.sensitive and not p.can(SENSITIVE_READ):
                la, lo = generalize((a.min_lat + a.max_lat) / 2, (a.min_lon + a.max_lon) / 2)
                feats.append(_pt(la, lo, {"id": a.id, "name": a.name, "kind": a.kind, "location_precision": "generalized_~11km"}))
                continue
            feats.append({"type": "Feature", "geometry": a.geometry,
                          "properties": {"id": a.id, "name": a.name, "kind": a.kind, "synthetic": a.synthetic}})
    elif name == "water_points":
        for w in db.scalars(select(WaterPoint).where(WaterPoint.org_id == p.org_id)):
            feats.append(_pt(w.lat, w.lon, {"id": w.id, "name": w.name, "kind": w.kind}))
    elif name == "marine_observations":
        start = start or end - timedelta(days=14)
        for o in db.scalars(select(MarineObservation).where(MarineObservation.org_id == p.org_id,
                                                            MarineObservation.observed_at.between(start, end),
                                                            MarineObservation.verification != "rejected")):
            d = protect({"lat": o.lat, "lon": o.lon, "sensitive": o.sensitive}, p)
            if _in_bbox(d["lat"], d["lon"], bbox):
                feats.append(_pt(d["lat"], d["lon"], {"id": o.id, "group": o.species_group, "count": o.count,
                                                      "verification": o.verification, "method": o.method,
                                                      "confidence": o.confidence, "at": o.observed_at.isoformat(),
                                                      "location_precision": d["location_precision"]}))
    elif name == "nests":
        if p.can(SENSITIVE_READ):
            for n in db.scalars(select(Nest).where(Nest.org_id == p.org_id)):
                feats.append(_pt(n.lat, n.lon, {"id": n.id, "code": n.code, "status": n.status, "sensitive": True}))
        # without sensitive.read: no nest features at all (not even generalised points)
    elif name == "reef_observations":
        for h in db.scalars(select(HabitatObservation).where(HabitatObservation.org_id == p.org_id, HabitatObservation.lat.isnot(None))):
            feats.append(_pt(h.lat, h.lon, {"id": h.id, "kind": h.kind, "value": h.value, "unit": h.unit,
                                            "uncertainty": h.uncertainty, "method": h.method}))
    elif name == "underwater_routes":
        from ..geo import LocalFrame

        for d in db.scalars(select(RovDive).where(RovDive.org_id == p.org_id)):
            la0, lo0 = (d.localization or {}).get("launch", [None, None])
            if la0 is None:
                continue
            fr = LocalFrame(la0, lo0)
            coords = []
            for t, e, n, *_ in d.track or []:
                la, lo = fr.to_latlon(e, n)
                coords.append([round(float(lo), 7), round(float(la), 7)])
            if len(coords) > 1:
                feats.append({"type": "Feature", "geometry": {"type": "LineString", "coordinates": coords},
                              "properties": {"id": d.id, "site": d.site, "max_depth_m": d.max_depth_m, "estimated": True}})
    elif name == "environment":
        latest: dict = {}
        for m in db.scalars(select(EnvMeasurement).where(EnvMeasurement.org_id == p.org_id, EnvMeasurement.lat.isnot(None))
                            .order_by(EnvMeasurement.measured_at.desc()).limit(300)):
            k = (m.device_id, m.kind)
            if k not in latest:
                latest[k] = m
        for m in latest.values():
            feats.append(_pt(m.lat, m.lon, {"kind": m.kind, "value": round(m.value, 2), "unit": m.unit, "quality": m.quality,
                                            "at": m.measured_at.isoformat(), "is_estimate": m.is_estimate}))
    elif name == "uav_missions":
        q = select(Mission).where(Mission.org_id == p.org_id, Mission.status.in_(["approved", "active", "completed", "validated", "draft"]))
        if domain:
            q = q.where(Mission.domain == domain)
        for m in db.scalars(q.order_by(Mission.created_at.desc()).limit(12)):
            w = (m.plan or {}).get("waypoints", [])
            if len(w) > 1:
                feats.append({"type": "Feature", "geometry": {"type": "LineString", "coordinates": [[x[1], x[0]] for x in w]},
                              "properties": {"id": m.id, "name": m.name, "status": m.status, "kind": m.kind, "domain": m.domain}})
    elif name == "alerts":
        q = select(Alert).where(Alert.org_id == p.org_id, Alert.status.in_(["open", "acknowledged"]), Alert.lat.isnot(None))
        if domain:
            q = q.where(Alert.domain == domain)
        for a in db.scalars(q):
            d = protect(ser(a), p)
            feats.append(_pt(d["lat"], d["lon"], {"id": a.id, "title": a.title, "priority": a.priority, "kind": a.kind,
                                                  "domain": a.domain, "location_precision": d["location_precision"]}))
    elif name == "devices":
        for d in db.scalars(select(Device).where(Device.org_id == p.org_id, Device.last_lat.isnot(None),
                                                 Device.device_type.in_(["uav", "rov", "gateway", "env_sensor", "water_sensor"]))):
            feats.append(_pt(d.last_lat, d.last_lon, {"id": d.id, "name": d.name, "type": d.device_type,
                                                      "battery_pct": d.battery_pct, "connectivity": d.connectivity}))
    else:
        raise Invalid(f"unknown layer {name}")
    return _fc(feats)


def playback(db: Session, p: Principal, start: datetime, end: datetime, step_min: int = 30) -> dict:
    """Positions of every collared animal at regular times in [start, end] (last fix at or before each frame)."""
    p.require(LIVESTOCK_READ)
    if (end - start).total_seconds() > 14 * 86400:
        raise Invalid("playback window limited to 14 days")
    rows = db.execute(select(CollarTelemetry.animal_id, CollarTelemetry.recorded_at, CollarTelemetry.lat, CollarTelemetry.lon)
                      .where(CollarTelemetry.org_id == p.org_id, CollarTelemetry.recorded_at.between(start, end),
                             CollarTelemetry.lat.isnot(None)).order_by(CollarTelemetry.recorded_at)).all()
    frames = []
    t = start
    idx: dict = {}
    by: dict = {}
    for aid, ts, la, lo in rows:
        by.setdefault(aid, []).append((ts, la, lo))
    while t <= end:
        pos = {}
        for aid, lst in by.items():
            i = idx.get(aid, 0)
            while i + 1 < len(lst) and lst[i + 1][0] <= t:
                i += 1
            idx[aid] = i
            if lst[i][0] <= t:
                pos[aid] = [round(lst[i][1], 6), round(lst[i][2], 6)]
        frames.append({"t": t.isoformat(), "positions": pos})
        t += timedelta(minutes=step_min)
    tags = {a.id: a.tag for a in db.scalars(select(Animal).where(Animal.org_id == p.org_id))}
    return {"frames": frames, "tags": tags}
