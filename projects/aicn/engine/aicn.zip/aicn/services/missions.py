"""Mission scheduling: plan → pre-flight / pre-dive checks → operator approval → execution → logs.

State machine
  draft ──validate──▶ validated ──approve──▶ approved ──start──▶ active ──▶ completed
    └──────────────┴────────────cancel──────────┘           └──abort──▶ aborted

Execution modes
  simulation  runs in the digital twin (default and the only mode available without hardware)
  supervised  needs a configured hardware link (MAVLink / ROV topside adapter); refused until one is registered.
Unrestricted autonomy is not offered: every run needs a named approving operator and can be aborted at any time.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..engines import planner
from ..errors import Conflict, Invalid, NotConfigured
from ..geo import centroid, circle_polygon
from ..models import Alert, Animal, Area, Device, Mission, MissionLog, OperatingRestriction, Species, SpeciesProfile, WaterPoint
from ..rbac import MISSIONS_ABORT, MISSIONS_PLAN, MISSIONS_READ, ROV_APPROVE, UAV_APPROVE, Principal
from . import events
from .common import audit, get_scoped, ser

KINDS = {
    # kind: (domain, vehicle, default sensor, default altitude m)
    "livestock_patrol": ("livestock", "uav", "thermal", 70),
    "herd_count": ("livestock", "uav", "thermal", 60),
    "missing_animal_search": ("livestock", "uav", "thermal", 60),
    "water_point_check": ("livestock", "uav", "rgb", 60),
    "coastal_patrol": ("marine", "uav", "rgb", 40),
    "marine_animal_survey": ("marine", "uav", "rgb", 40),
    "nesting_beach_survey": ("marine", "uav", "rgb", 50),
    "habitat_mapping": ("marine", "uav", "rgb", 60),
    "rov_reef_survey": ("marine", "rov", "rgb", 0),
    "rov_animal_observation": ("marine", "rov", "rgb", 0),
}


def _sim():
    from ..sim.world import get_sim

    return get_sim()


def list_missions(db: Session, p: Principal, status=None, domain=None):
    p.require(MISSIONS_READ)
    q = select(Mission).where(Mission.org_id == p.org_id)
    if status:
        q = q.where(Mission.status.in_(status.split(",")))
    if domain:
        q = q.where(Mission.domain == domain)
    out = []
    for m in db.scalars(q.order_by(Mission.created_at.desc()).limit(200)):
        d = ser(m, exclude=("plan",))
        d["waypoints"] = len((m.plan or {}).get("waypoints", []))
        out.append(d)
    return out


def get_mission(db: Session, p: Principal, mission_id: str):
    p.require(MISSIONS_READ)
    m = get_scoped(db, Mission, mission_id, p)
    d = ser(m)
    d["logs"] = [ser(x) for x in db.scalars(select(MissionLog).where(MissionLog.mission_id == m.id).order_by(MissionLog.at))]
    d["device"] = ser(db.get(Device, m.device_id)) if m.device_id else None
    d["area"] = ser(db.get(Area, m.area_id)) if m.area_id else None
    sim = _sim()
    if sim and m.status == "active":
        w = sim.worlds.get(m.org_id)
        run = w.runs.get(m.id) if w else None
        if run:
            la, lo, extra = run.position()
            d["live"] = {"lat": la, "lon": lo, "progress": round(getattr(run, "s", getattr(run, "elapsed", 0)) /
                                                               max(getattr(run, "L", getattr(run, "total", 1)), 1), 3)}
    return d


def _area_for(db: Session, p: Principal, kind: str, data: dict) -> Area:
    if data.get("area_id"):
        return get_scoped(db, Area, data["area_id"], p)
    domain = KINDS[kind][0]
    prm = data.get("params") or {}
    geom = None
    name = data.get("name") or kind
    if kind == "missing_animal_search":
        a = get_scoped(db, Animal, prm.get("target_animal_id", ""), p)
        if a.last_lat is None:
            raise Invalid("animal has no known position to search around")
        geom = circle_polygon(a.last_lat, a.last_lon, float(prm.get("radius_m", 350)), 24)
        name = f"Search area around last fix of {a.tag}"
    elif kind == "water_point_check":
        w = get_scoped(db, WaterPoint, prm.get("water_point_id", ""), p)
        geom = circle_polygon(w.lat, w.lon, float(prm.get("radius_m", 120)), 20)
        name = f"Water point {w.name}"
    elif data.get("geometry"):
        geom = data["geometry"]
    if geom is None:
        raise Invalid("an area_id or geometry is required")
    from ..geo import bbox_of

    a, b, c, d = bbox_of(geom)
    ar = Area(org_id=p.org_id, domain=domain, kind="survey_area" if domain == "marine" else "mission_area", name=name,
              geometry=geom, min_lat=a, min_lon=b, max_lat=c, max_lon=d, properties={"created_for": "mission"})
    db.add(ar)
    db.flush()
    return ar


def create(db: Session, p: Principal, data: dict):
    p.require(MISSIONS_PLAN)
    kind = data.get("kind")
    if kind not in KINDS:
        raise Invalid(f"kind must be one of {sorted(KINDS)}")
    domain, vehicle, sensor, alt = KINDS[kind]
    prm = dict(data.get("params") or {})
    prm.setdefault("sensor", sensor)
    if vehicle == "uav":
        prm.setdefault("altitude_m", alt)
        prm["altitude_m"] = float(prm["altitude_m"])
    dev = get_scoped(db, Device, data["device_id"], p) if data.get("device_id") else None
    if dev and dev.device_type != vehicle:
        raise Invalid(f"{kind} needs a {vehicle}, device is a {dev.device_type}")
    if vehicle == "uav":
        area = _area_for(db, p, kind, data)
        spec = planner.UAVSpec.from_specs(dev.specs if dev else None)
        hfov = spec.thermal_hfov_deg if prm["sensor"] == "thermal" else spec.rgb_hfov_deg
        nofly = [db.get(Area, r.area_id).geometry for r in db.scalars(select(OperatingRestriction).where(
            OperatingRestriction.org_id == p.org_id, OperatingRestriction.kind == "no_fly", OperatingRestriction.active.is_(True)))
                 if r.area_id]
        home = (dev.last_lat, dev.last_lon) if dev and dev.last_lat is not None else None
        plan = planner.coverage_plan(area.geometry, prm["altitude_m"], hfov, spec.image_w, spec.image_h,
                                     float(prm.get("sidelap", 0.3)), nofly, home=home)
    else:
        area = get_scoped(db, Area, data["area_id"], p) if data.get("area_id") else None
        start = prm.get("start") or (list(centroid(area.geometry)) if area else None)
        end = prm.get("end")
        if not start or not end:
            raise Invalid("ROV missions need params.start and params.end [lat, lon] (transect)")
        plan = planner.rov_transect(tuple(start), tuple(end), float(prm.get("depth_m", 8)), int(prm.get("legs", 2)),
                                    float(prm.get("leg_spacing_m", 12)))
        prm.setdefault("launch", start)
    m = Mission(org_id=p.org_id, domain=domain, kind=kind, name=data.get("name") or f"{kind.replace('_', ' ').title()}",
                priority=data.get("priority", "normal"), mode=data.get("mode", "simulation"),
                area_id=area.id if area else None, device_id=dev.id if dev else None, params=prm, plan=plan,
                created_by=p.user_id, created_at=utcnow())
    if m.mode not in ("simulation", "supervised"):
        raise Invalid("mode must be simulation or supervised")
    db.add(m)
    db.flush()
    db.add(MissionLog(mission_id=m.id, at=utcnow(), message=f"Planned by {p.name or p.role}: "
                                                            f"{len(plan.get('waypoints', []))} waypoints, {plan.get('length_m', 0):.0f} m"))
    audit(db, p, "mission.create", "mission", m.id, {"kind": kind})
    return get_mission(db, p, m.id)


def _restrictions(db: Session, org_id: str) -> list[dict]:
    out = []
    for r in db.scalars(select(OperatingRestriction).where(OperatingRestriction.org_id == org_id,
                                                           OperatingRestriction.active.is_(True))):
        geom = db.get(Area, r.area_id).geometry if r.area_id else None
        out.append({"kind": r.kind, "name": r.name, "geometry": geom, "params": r.params or {}, "verified": r.verified})
    return out


def _device_check(db: Session, m: Mission) -> tuple[bool, str, Device | None]:
    if not m.device_id:
        return False, "no vehicle assigned", None
    d = db.get(Device, m.device_id)
    if d.status != "active":
        return False, f"{d.name} status is {d.status}", d
    if d.health == "fault":
        return False, f"{d.name} reports a fault", d
    busy = db.scalar(select(Mission).where(Mission.device_id == d.id, Mission.status == "active", Mission.id != m.id))
    if busy:
        return False, f"{d.name} is flying mission '{busy.name}'", d
    cat = d.category or ""
    if m.domain == "livestock" and cat == "marine_uav" or m.domain == "marine" and cat == "livestock_uav":
        return False, f"{d.name} is a {cat.replace('_', ' ')}", d
    return True, f"{d.name} ({d.model}, firmware {d.firmware}) available, battery {d.battery_pct or 0:.0f}%", d


def preflight(db: Session, m: Mission, now: datetime) -> dict:
    ok, note, dev = _device_check(db, m)
    vehicle = KINDS[m.kind][1]
    sim = _sim()
    weather = None
    if sim and m.mode == "simulation":
        w = sim.worlds.get(m.org_id)
        weather = dict(w.weather) if w else None
    if (m.params or {}).get("weather"):
        weather = m.params["weather"]
    if vehicle == "uav":
        spec = planner.UAVSpec.from_specs(dev.specs if dev else None)
        if m.domain == "livestock":
            mins = [s.uav_min_altitude_m for s in db.scalars(select(SpeciesProfile))]
            min_alt = max(mins) if mins else 60.0
        else:
            mins = [float((s.profile or {}).get("min_uav_alt_m", 30)) for s in db.scalars(select(Species))]
            min_alt = max(mins) if mins else 30.0
        hour = (now.hour + now.minute / 60 + 3) % 24
        checks = planner.uav_preflight(m.plan, spec, dev.battery_pct if dev else None, float(m.params.get("altitude_m", 60)),
                                       weather, _restrictions(db, m.org_id), hour, ok, note, min_alt)
    else:
        spec = planner.ROVSpec.from_specs(dev.specs if dev else None)
        cond = (m.params or {}).get("conditions")
        if cond is None and sim and m.mode == "simulation":
            w = sim.worlds.get(m.org_id)
            if w and w.marine:
                cond = {"current_mps": 0.13, "visibility_m": round(w.marine.water_clarity() * 0.6, 1), "source": "simulated"}
        checks = planner.rov_predive(m.plan, spec, tuple(m.params.get("launch")), cond, ok, note,
                                     dev.battery_pct if dev else None)
    if m.mode == "supervised":
        checks.append(planner.check("hardware_link", "fail",
                                    "no flight-controller / topside link is registered for this vehicle — supervised field "
                                    "operation is not available yet (see docs/HARDWARE_ROADMAP.md)"))
    status = "fail" if any(c["status"] == "fail" for c in checks) else ("warn" if any(c["status"] == "warn" for c in checks) else "pass")
    return {"status": status, "checks": checks, "at": now.isoformat(), "weather": weather}


def validate(db: Session, p: Principal, mission_id: str):
    p.require(MISSIONS_PLAN)
    m = get_scoped(db, Mission, mission_id, p)
    if m.status not in ("draft", "validated"):
        raise Conflict(f"mission is {m.status}")
    now = utcnow()
    pf = preflight(db, m, now)
    m.preflight = pf
    m.status = "validated" if pf["status"] != "fail" else "draft"
    db.add(MissionLog(mission_id=m.id, at=now, level="info" if pf["status"] != "fail" else "warning",
                      message=f"Checks: {pf['status']} — " + "; ".join(f"{c['check']}: {c['status']}" for c in pf["checks"])))
    return get_mission(db, p, m.id)


def approve(db: Session, p: Principal, mission_id: str, note: str = ""):
    m = get_scoped(db, Mission, mission_id, p)
    p.require(ROV_APPROVE if KINDS[m.kind][1] == "rov" else UAV_APPROVE)
    if m.status != "validated":
        raise Conflict("only validated missions can be approved")
    now = utcnow()
    pf = preflight(db, m, now)  # conditions change: re-check at approval time
    m.preflight = pf
    if pf["status"] == "fail":
        m.status = "draft"
        raise Conflict("checks no longer pass: " + "; ".join(c["detail"] for c in pf["checks"] if c["status"] == "fail"))
    m.status, m.approved_by, m.approved_at = "approved", p.user_id, now
    db.add(MissionLog(mission_id=m.id, at=now, message=f"Approved by {p.name or p.role}" + (f": {note}" if note else "")))
    audit(db, p, "mission.approve", "mission", m.id, {"note": note})
    return get_mission(db, p, m.id)


def start(db: Session, p: Principal, mission_id: str):
    m = get_scoped(db, Mission, mission_id, p)
    p.require(ROV_APPROVE if KINDS[m.kind][1] == "rov" else UAV_APPROVE)
    if m.status != "approved":
        raise Conflict("mission must be approved first")
    if m.mode == "supervised":
        raise NotConfigured("supervised field execution needs a registered hardware link; none is configured")
    sim = _sim()
    if sim is None:
        raise NotConfigured("simulation is not running on this server")
    now = utcnow()
    ok, note, _ = _device_check(db, m)
    if not ok:
        raise Conflict(note)
    m.status, m.started_at = "active", now
    w = sim.world(db, m.org_id)
    w.start_run(db, m, now)
    audit(db, p, "mission.start", "mission", m.id)
    events.publish(p.org_id, "mission.started", {"mission_id": m.id})
    return get_mission(db, p, m.id)


def cancel(db: Session, p: Principal, mission_id: str, reason: str = ""):
    p.require(MISSIONS_PLAN)
    m = get_scoped(db, Mission, mission_id, p)
    if m.status not in ("draft", "validated", "approved"):
        raise Conflict(f"cannot cancel a mission that is {m.status} (use abort for active missions)")
    m.status = "cancelled"
    m.ended_at = utcnow()
    db.add(MissionLog(mission_id=m.id, at=utcnow(), level="warning", message=f"Cancelled by {p.name or p.role}: {reason}"))
    audit(db, p, "mission.cancel", "mission", m.id, {"reason": reason})
    return get_mission(db, p, m.id)


def abort(db: Session, p: Principal, mission_id: str, reason: str = "operator emergency abort"):
    p.require(MISSIONS_ABORT)
    m = get_scoped(db, Mission, mission_id, p)
    if m.status != "active":
        raise Conflict("only active missions can be aborted")
    sim = _sim()
    now = utcnow()
    if sim:
        w = sim.world(db, m.org_id)
        w.abort_run(db, m, now, reason)
    if m.status == "active":
        m.status, m.ended_at = "aborted", now
    audit(db, p, "mission.abort", "mission", m.id, {"reason": reason})
    events.publish(p.org_id, "mission.aborted", {"mission_id": m.id})
    return get_mission(db, p, m.id)


def suggestions(db: Session, p: Principal) -> list[dict]:
    """Mission Intelligence: proposes missions from open alerts. Nothing is created until a person submits it."""
    p.require(MISSIONS_READ)
    out = []
    from ..geo import haversine_m

    uavs = list(db.scalars(select(Device).where(Device.org_id == p.org_id, Device.device_type == "uav", Device.status == "active")))

    def nearest(cats, lat, lon):
        c = [d for d in uavs if d.category in cats]
        if lat is None or not c:
            return c[0] if c else None
        return min(c, key=lambda d: float(haversine_m(lat, lon, d.last_lat, d.last_lon)) if d.last_lat is not None else 1e12)

    lv_uav = nearest(("livestock_uav", "survey_uav"), None, None)
    mr_uav = nearest(("marine_uav", "survey_uav"), None, None)
    for a in db.scalars(select(Alert).where(Alert.org_id == p.org_id, Alert.status.in_(["open", "acknowledged"]),
                                            Alert.kind.in_(["missing_animal", "separation"]))):
        if lv_uav and a.subject_type == "animal":
            an = db.get(Animal, a.subject_id)
            lv_uav = nearest(("livestock_uav", "survey_uav"), an.last_lat if an else None, an.last_lon if an else None)
            if an:
                out.append({"kind": "missing_animal_search", "reason": a.title, "alert_id": a.id,
                            "request": {"kind": "missing_animal_search", "device_id": lv_uav.id,
                                        "name": f"Search for {an.tag}", "params": {"target_animal_id": an.id, "radius_m": 350}}})
    for a in db.scalars(select(Alert).where(Alert.org_id == p.org_id, Alert.status == "open", Alert.kind == "water_shortage")):
        if lv_uav:
            out.append({"kind": "water_point_check", "reason": a.title, "alert_id": a.id,
                        "request": {"kind": "water_point_check", "device_id": lv_uav.id, "name": f"Inspect {a.title.split(': ')[-1]}",
                                    "params": {"water_point_id": a.subject_id}}})
    if mr_uav:
        sa = db.scalar(select(Area).where(Area.org_id == p.org_id, Area.kind == "survey_area", Area.domain == "marine"))
        if sa:
            mr_uav = nearest(("marine_uav", "survey_uav"), *centroid(sa.geometry))
            out.append({"kind": "marine_animal_survey", "reason": "Routine survey of the core habitat area",
                        "request": {"kind": "marine_animal_survey", "device_id": mr_uav.id, "area_id": sa.id,
                                    "name": f"Survey {sa.name}"}})
    return out
