"""Shared AI engine services: model registry, on-demand detection, review queue, evaluation summaries."""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import config
from ..db import utcnow
from ..engines import vision
from ..errors import Invalid, NotConfigured
from ..models import AIDetection, AIModel, Media, Mission
from ..rbac import AI_REVIEW, AI_RUN, MARINE_READ, Principal
from . import media
from .common import audit, get_scoped, protect, ser

ENGINE_MODELS = [
    ("movement-anomaly-v1", "Movement anomaly detector", "anomaly", "livestock", "rules",
     "Robust statistics on collar tracks: herd separation, boundary exit, inactivity, unusual speed, congregation."),
    ("health-observation-v1", "Health observation scorer", "health", "livestock", "rules",
     "Indicator deviations from each animal's own baseline, corroboration rule, bootstrap uncertainty. Not a diagnosis."),
    ("mot-kalman-v1", "Multi-object tracker", "tracking", "shared", "numpy",
     "Constant-velocity Kalman filters, chi-square gating, Hungarian assignment; counts confirmed tracks."),
    ("behaviour-v1", "Behaviour descriptor", "behaviour", "marine", "rules",
     "Heading, speed, straightness, surfacing share; interpretations are hypotheses for review."),
    ("vegetation-ndvi-v1", "Vegetation / drought estimator", "vegetation", "livestock", "numpy",
     "NDVI statistics, placeholder biomass regression, drought indicator, water-level forecasting."),
    ("coverage-planner-v1", "Mission planner", "planning", "shared", "numpy",
     "Boustrophedon coverage from camera footprint, no-fly avoidance, energy and regulatory checks."),
    ("report-summary-v1", "Report summariser", "reporting", "shared", "rules",
     "Template-based plain-language summaries from report statistics (no generative model in decisions)."),
]


def sync_registry(db: Session):
    for d in vision.registry(config.settings.onnx_model_dir).values():
        ok, why = d.available()
        m = db.get(AIModel, d.id) or AIModel(id=d.id)
        m.name, m.task, m.domain, m.version, m.backend = d.name, d.task, d.domain, d.version, d.backend
        m.available = ok
        m.description = d.description + ("" if ok else f" — unavailable: {why}")
        db.merge(m)
    for mid, name, task, domain, backend, desc in ENGINE_MODELS:
        m = db.get(AIModel, mid) or AIModel(id=mid)
        m.name, m.task, m.domain, m.version, m.backend, m.available, m.description = name, task, domain, "1.0", backend, True, desc
        db.merge(m)


def list_models(db: Session, p: Principal):
    out = []
    for m in db.scalars(select(AIModel).order_by(AIModel.task)):
        d = ser(m)
        d["evaluation"] = evaluation(db, p, m.id) if m.task == "detection" else None
        out.append(d)
    return out


def evaluation(db: Session, p: Principal, model_id: str) -> dict:
    """Two separate evidence sources, never mixed:
    synthetic — mission outcomes on rendered frames (vs simulator truth);
    human_review — share of reviewed detections that people confirmed."""
    syn = {"missions": 0, "tp": 0, "fp": 0, "fn": 0}
    for m in db.scalars(select(Mission).where(Mission.org_id == p.org_id, Mission.status.in_(["completed", "aborted"]))):
        ev = (m.outcome or {}).get("evaluation")
        if ev and ev.get("detector") == model_id:
            syn["missions"] += 1
            syn["tp"] += ev["true_positives"]
            syn["fp"] += ev["false_positives"]
            syn["fn"] += ev["missed"]
    if syn["missions"]:
        syn["precision"] = round(syn["tp"] / max(syn["tp"] + syn["fp"], 1), 3)
        syn["recall"] = round(syn["tp"] / max(syn["tp"] + syn["fn"], 1), 3)
    rows = dict(db.execute(select(AIDetection.review_status, func.count()).where(
        AIDetection.org_id == p.org_id, AIDetection.model_id == model_id).group_by(AIDetection.review_status)).all())
    reviewed = rows.get("confirmed", 0) + rows.get("corrected", 0) + rows.get("rejected", 0)
    hr = {"reviewed": reviewed, "confirmed": rows.get("confirmed", 0), "corrected": rows.get("corrected", 0),
          "rejected": rows.get("rejected", 0), "unreviewed": rows.get("unreviewed", 0)}
    if reviewed:
        hr["confirmed_share"] = round((rows.get("confirmed", 0) + rows.get("corrected", 0)) / reviewed, 3)
    return {"synthetic": syn, "human_review": hr,
            "field_validation": "none yet — requires labelled imagery from Tanzanian / Zanzibar deployments"}


def detect(db: Session, p: Principal, data: dict):
    """Run a detector on an uploaded image. Stores the image and detections (unreviewed)."""
    p.require(AI_RUN)
    reg = vision.registry(config.settings.onnx_model_dir)
    det = reg.get(data.get("model_id", "sea-anomaly-v1"))
    if det is None:
        raise Invalid("unknown model")
    ok, why = det.available()
    if not ok:
        raise NotConfigured(f"{det.id} unavailable: {why}")
    try:
        img = vision.image_from_payload(data["image"])
    except (KeyError, ValueError) as e:
        raise Invalid(f"bad image: {e}")
    if img.shape[0] * img.shape[1] > 1600 * 1600:
        raise Invalid("image too large; downscale to at most 1600×1600 before upload")
    gsd = data.get("gsd_m")
    if gsd is None and data.get("altitude_m") and data.get("hfov_deg"):
        gsd = vision.Camera(float(data["hfov_deg"]), img.shape[1], img.shape[0]).gsd(float(data["altitude_m"]))
    arr = img.mean(axis=2) if det.id == "thermal-blob-v1" else img
    dets = det.detect(arr, gsd)
    now = utcnow()
    domain = data.get("domain") or (det.domain if det.domain != "shared" else "marine")
    med = Media(org_id=p.org_id, domain=domain, kind="image", width=img.shape[1], height=img.shape[0],
                lat=data.get("lat"), lon=data.get("lon"), captured_at=now,
                meta={"uploaded_by": p.user_id, "gsd_m": gsd, "filename": data.get("filename", "")},
                sensitive=bool(data.get("sensitive", False)))
    db.add(med)
    db.flush()
    med.uri = media.store().put(med.id + ".png", vision.encode_png(img))
    out = []
    for d in dets[:300]:
        if data.get("lat") is not None and gsd and data.get("altitude_m"):
            cam = vision.Camera(float(data.get("hfov_deg", 70)), img.shape[1], img.shape[0])
            d.lat, d.lon = vision.georeference(d, cam, float(data["lat"]), float(data["lon"]), float(data["altitude_m"]),
                                               float(data.get("yaw_deg", 0)))
        row = AIDetection(org_id=p.org_id, domain=domain, model_id=det.id, media_id=med.id, label=d.label,
                          species_group=d.species_group, confidence=d.confidence, bbox=d.bbox, lat=d.lat, lon=d.lon,
                          observed_at=now, sensitive=med.sensitive, extra=dict(d.extra, size_m=d.size_m, uploaded=True))
        db.add(row)
        db.flush()
        out.append(ser(row))
    audit(db, p, "ai.detect", "media", med.id, {"model": det.id, "detections": len(out)})
    return {"media_id": med.id, "model_id": det.id, "gsd_m": gsd, "detections": out,
            "note": "Candidates only. Species groups from the classical detector are size hints; review each one."}


def list_detections(db: Session, p: Principal, review_status=None, mission_id=None, media_id=None, limit=300):
    p.require(MARINE_READ)
    q = select(AIDetection).where(AIDetection.org_id == p.org_id)
    if review_status:
        q = q.where(AIDetection.review_status.in_(review_status.split(",")))
    if mission_id:
        q = q.where(AIDetection.mission_id == mission_id)
    if media_id:
        q = q.where(AIDetection.media_id == media_id)
    return [protect(ser(d), p) for d in db.scalars(q.order_by(AIDetection.observed_at.desc()).limit(limit))]


def review_detection(db: Session, p: Principal, det_id: str, status: str, label: str | None = None):
    p.require(AI_REVIEW)
    if status not in ("confirmed", "corrected", "rejected"):
        raise Invalid("status must be confirmed, corrected or rejected")
    d = get_scoped(db, AIDetection, det_id, p)
    if status == "corrected" and not label:
        raise Invalid("a corrected label is required")
    d.review_status, d.review_label, d.reviewed_by = status, label, p.user_id
    audit(db, p, "ai.review", "detection", d.id, {"status": status, "label": label})
    return ser(d)


def list_media(db: Session, p: Principal, mission_id=None, limit=60):
    p.require(MARINE_READ)
    q = select(Media).where(Media.org_id == p.org_id)
    if mission_id:
        q = q.where(Media.mission_id == mission_id)
    rows = list(db.scalars(q.order_by(Media.captured_at.desc()).limit(limit)))
    return [protect(dict(ser(m), detections=[ser(d) for d in db.scalars(select(AIDetection).where(AIDetection.media_id == m.id))]),
                    p) for m in rows]


def media_bytes(db: Session, p: Principal, media_id: str) -> tuple[bytes, str]:
    p.require(MARINE_READ)
    m = get_scoped(db, Media, media_id, p)
    got = media.store().get(m.id + ".png")
    if not got:
        raise NotConfigured("media object no longer in storage")
    return got
