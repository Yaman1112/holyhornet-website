"""Overview dashboard: one call aggregating both divisions and system health."""

from __future__ import annotations

from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..models import (Alert, Animal, CollarTelemetry, Device, EnvMeasurement, MarineObservation, Mission, Nest)
from ..rbac import Principal
from . import devices
from .common import alert_visible, livestock_scope, protect, ser


def overview(db: Session, p: Principal) -> dict:
    now = utcnow()
    org = p.org_id
    day = now - timedelta(hours=24)
    cnt = lambda q: db.scalar(q) or 0  # noqa: E731
    scope = livestock_scope(db, p)
    an = select(func.count()).select_from(Animal).where(Animal.org_id == org)
    tel = select(func.count()).select_from(CollarTelemetry).where(CollarTelemetry.org_id == org, CollarTelemetry.recorded_at >= day)
    if scope is not None:
        an = an.where(Animal.farm_id.in_(p.farm_scope))
        tel = tel.where(CollarTelemetry.animal_id.in_(scope))
    if not p.can("livestock.read"):
        an = an.where(False)
        tel = tel.where(False)
    active = [a for a in db.scalars(select(Alert).where(Alert.org_id == org, Alert.status.in_(["open", "acknowledged"]))
                                    .order_by(Alert.created_at.desc())) if alert_visible(a, p, scope)]
    out = {
        "now": now.isoformat(),
        "scope": "farms: " + str(len(p.farm_scope)) if scope is not None else "organisation",
        "animals": {"livestock": cnt(an.where(Animal.status != "sold")), "missing": cnt(an.where(Animal.status == "missing"))},
        "livestock_observations_24h": cnt(tel),
        "marine_detections_7d": cnt(select(func.sum(MarineObservation.count)).where(
            MarineObservation.org_id == org, MarineObservation.observed_at >= now - timedelta(days=7),
            MarineObservation.verification != "rejected")),
        "marine_pending_review": cnt(select(func.count()).select_from(MarineObservation).where(
            MarineObservation.org_id == org, MarineObservation.verification.in_(["unverified", "needs_expert"]))),
        "nests": cnt(select(func.count()).select_from(Nest).where(Nest.org_id == org)),
        "devices": devices.fleet_summary(db, p) if p.can("devices.read") else {},
        "uav": {"total": cnt(select(func.count()).select_from(Device).where(Device.org_id == org, Device.device_type == "uav")),
                "active": cnt(select(func.count()).select_from(Mission).join(Device, Device.id == Mission.device_id).where(
                    Mission.org_id == org, Mission.status == "active", Device.device_type == "uav"))},
        "rov": {"total": cnt(select(func.count()).select_from(Device).where(Device.org_id == org, Device.device_type == "rov")),
                "active": cnt(select(func.count()).select_from(Mission).join(Device, Device.id == Mission.device_id).where(
                    Mission.org_id == org, Mission.status == "active", Device.device_type == "rov"))},
        "alerts": {pr: sum(1 for a in active if a.status == "open" and a.priority == pr) for pr in ("critical", "high", "medium", "low")},
        "recent_alerts": [protect(ser(a), p) for a in active[:8]],
        "recent_missions": [{"id": m.id, "name": m.name, "kind": m.kind, "status": m.status, "domain": m.domain}
                            for m in db.scalars(select(Mission).where(Mission.org_id == org).order_by(Mission.created_at.desc()).limit(6))],
        "environment": {},
    }
    for kind in ("water_temp", "turbidity", "water_level", "water_clarity"):
        m = db.scalar(select(EnvMeasurement).where(EnvMeasurement.org_id == org, EnvMeasurement.kind == kind)
                      .order_by(EnvMeasurement.measured_at.desc()))
        if m:
            out["environment"][kind] = {"value": round(m.value, 2), "unit": m.unit, "at": m.measured_at.isoformat()}
    if p.can("devices.read"):
        out["ingest_24h"] = devices.ingest_stats(db, p, 24, now)
    from ..sim.world import get_sim

    sim = get_sim()
    out["system"] = {"database": db.get_bind().dialect.name, "simulation": bool(sim),
                     "clock": "virtual (digital twin)" if sim else "real time"}
    return out
