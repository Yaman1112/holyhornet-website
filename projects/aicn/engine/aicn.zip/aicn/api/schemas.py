"""Request bodies (validated by Pydantic, documented in OpenAPI)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class Login(BaseModel):
    email: str = Field(max_length=200)
    password: str = Field(max_length=200)
    org_id: str | None = None


class SwitchOrg(BaseModel):
    org_id: str


class AnimalCreate(BaseModel):
    farm_id: str
    herd_id: str | None = None
    tag: str = Field(min_length=1, max_length=40)
    name: str = ""
    species: str = "cattle"
    breed: str = ""
    sex: Literal["male", "female", "unknown"] = "unknown"
    birth_date: str | None = None
    age_estimate_months: int | None = Field(default=None, ge=0, le=600)
    notes: str = ""


class Vaccination(BaseModel):
    vaccine: str
    given_on: str
    next_due: str | None = None
    administered_by: str = ""
    batch: str = ""


class TreatmentIn(BaseModel):
    started_on: str
    condition: str
    treatment: str
    withdrawal_until: str | None = None
    vet_name: str = ""


class Review(BaseModel):
    status: str
    note: str = ""
    species_id: str | None = None
    count: int | None = None
    label: str | None = None


class ManualHealth(BaseModel):
    level: Literal["normal", "unusual", "concern", "urgent"] = "unusual"
    summary: str = Field(min_length=3, max_length=2000)


class MarineObservationIn(BaseModel):
    species_id: str | None = None
    species_group: str = "other"
    count: int = Field(default=1, ge=1, le=10000)
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    observed_at: str | None = None
    method: Literal["uav_aerial", "rov", "boat_survey", "shore", "acoustic", "community"] = "boat_survey"
    confidence: float | None = Field(default=None, ge=0, le=1)
    environment: dict = {}
    notes: str = ""
    sensitive: bool | None = None
    individual_id: str | None = None
    individual_validation: str | None = None


class NestIn(BaseModel):
    beach_area_id: str
    code: str
    species_id: str | None = None
    lat: float
    lon: float
    laid_on: str
    incubation_days: int = 50
    clutch_size: int | None = None
    site_condition: str = ""
    protected: bool = False
    notes: str = ""


class NestEventIn(BaseModel):
    kind: Literal["inspected", "inundation", "predation_sign", "hatching", "excavated", "conservation_action"]
    detail: str = ""
    hatchlings_emerged: int | None = None
    failed: bool = False
    observer: str = ""


class DeviceIn(BaseModel):
    domain: Literal["livestock", "marine", "shared"]
    device_type: str
    category: str = ""
    name: str
    serial: str
    manufacturer: str = ""
    model: str = ""
    firmware: str = ""
    comms: list[str] = []
    specs: dict = {}
    animal_id: str | None = None


class Maintenance(BaseModel):
    kind: Literal["inspection", "repair", "battery_replacement", "firmware_update", "calibration"]
    notes: str = ""
    performed_by: str = ""
    firmware: str | None = None


class IngestIn(BaseModel):
    encoding: Literal["json", "ac1"] = "json"
    records: list[dict] | None = None
    data: str | None = None
    dropped: int = 0


class MissionIn(BaseModel):
    kind: str
    name: str | None = None
    device_id: str | None = None
    area_id: str | None = None
    geometry: dict | None = None
    priority: Literal["low", "normal", "high", "urgent"] = "normal"
    mode: Literal["simulation", "supervised"] = "simulation"
    params: dict = {}


class Note(BaseModel):
    note: str = ""


class AlertAction(BaseModel):
    action: Literal["acknowledge", "resolve", "dismiss"]
    note: str = ""


class ReportIn(BaseModel):
    kind: str
    start: str | None = None
    end: str | None = None
    area_id: str | None = None
    title: str | None = None


class ImagePayload(BaseModel):
    format: Literal["png", "rgb8", "rgba8"] = "png"
    width: int | None = None
    height: int | None = None
    data: str


class DetectIn(BaseModel):
    model_id: str = "sea-anomaly-v1"
    image: ImagePayload
    domain: str | None = None
    gsd_m: float | None = None
    altitude_m: float | None = None
    hfov_deg: float | None = None
    lat: float | None = None
    lon: float | None = None
    yaw_deg: float | None = None
    sensitive: bool = False
    filename: str = ""


class SyncIn(BaseModel):
    items: list[dict] = Field(max_length=500)


class ScenarioIn(BaseModel):
    kind: str
    params: dict[str, Any] = {}


class StepIn(BaseModel):
    minutes: float = Field(default=15, gt=0, le=10080)


class AddAnimalsIn(BaseModel):
    herd_id: str
    count: int = Field(default=1, ge=1, le=50)
    species: str | None = None


class AreaIn(BaseModel):
    domain: Literal["livestock", "marine", "shared"] = "shared"
    kind: str
    name: str
    geometry: dict
    sensitive: bool = False
    properties: dict = {}


class RestrictionIn(BaseModel):
    kind: str
    name: str
    area_id: str | None = None
    params: dict = {}
    authority: str = ""
    verified: bool = False
    active: bool = True


class InviteIn(BaseModel):
    email: str
    name: str = ""
    role: str
    password: str | None = None
    phone: str = ""
    scope: dict = {}


class ApiKeyIn(BaseModel):
    name: str
    role: str = "viewer"


class EnvIn(BaseModel):
    kind: str
    value: float
    unit: str | None = None
    domain: str = "shared"
    lat: float | None = None
    lon: float | None = None
    area_id: str | None = None
    measured_at: str | None = None
    source: str = "manual"
    is_estimate: bool = False
    quality: Literal["good", "suspect", "bad"] = "good"
    calibration: dict = {}
