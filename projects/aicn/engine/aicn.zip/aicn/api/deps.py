"""FastAPI dependencies. Everything is `async def` on purpose: the same application also runs inside
Pyodide (browser edition), where thread pools — used by FastAPI for sync dependencies — do not exist."""

from __future__ import annotations

from fastapi import Depends, Header, Request
from sqlalchemy.orm import Session

from ..db import SessionLocal
from ..errors import Unauthorized
from ..rbac import Principal
from ..security import decode_token
from ..services import orgs


async def get_db():
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


async def principal(request: Request, db: Session = Depends(get_db), authorization: str | None = Header(default=None),
                    x_api_key: str | None = Header(default=None)) -> Principal:
    if authorization and authorization.lower().startswith("bearer "):
        p = orgs.principal_from_token(db, decode_token(authorization[7:].strip()))
    elif x_api_key:
        p = orgs.principal_from_api_key(db, x_api_key)
    else:
        raise Unauthorized("authentication required (Bearer token or X-API-Key)")
    request.state.principal = p
    return p
