"""REST API v1. Thin layer: parse → service call (permission + org scope enforced there) → commit → JSON."""

from __future__ import annotations

import asyncio
from datetime import datetime

from fastapi import APIRouter, Depends, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import SessionLocal, utcnow
from ..errors import AICNError, Invalid, NotConfigured, NotFound
from ..models import Organization
from ..rbac import SIM_CONTROL, Principal
from ..security import decode_token
from ..services import (ai, alerts, dashboard, devices, environment, events, gis, livestock, marine, missions, orgs,
                        reports)
from . import schemas as S
from .deps import get_db, principal

api = APIRouter(prefix="/api/v1")
P = Depends(principal)
D = Depends(get_db)


def ok(db: Session, value):
    db.commit()
    return value


def _bbox(bbox: str | None):
    if not bbox:
        return None
    try:
        a = [float(x) for x in bbox.split(",")]
        assert len(a) == 4
        return a
    except Exception:
        raise Invalid("bbox must be min_lat,min_lon,max_lat,max_lon")


# ------------------------------------------------------------------ auth & org


@api.post("/auth/login", tags=["auth"])
async def login(body: S.Login, db: Session = D):
    return ok(db, orgs.login(db, body.email, body.password, body.org_id))


@api.get("/auth/me", tags=["auth"])
async def me(p: Principal = P, db: Session = D):
    from ..models import User

    u = db.get(User, p.user_id) if p.user_id else None
    if not u:
        return {"kind": p.kind, "org_id": p.org_id, "role": p.role, "permissions": sorted(p.perms)}
    return orgs.me_dict(db, u, p.org_id, p.role)


@api.post("/auth/switch-org", tags=["auth"])
async def switch_org(body: S.SwitchOrg, p: Principal = P, db: Session = D):
    return ok(db, orgs.switch_org(db, p, body.org_id))


@api.get("/auth/roles", tags=["auth"])
async def roles():
    return orgs.roles()


@api.get("/orgs", tags=["administration"])
async def list_orgs(p: Principal = P, db: Session = D):
    return orgs.list_orgs(db, p)


@api.post("/orgs", tags=["administration"])
async def create_org(body: dict, p: Principal = P, db: Session = D):
    return ok(db, orgs.create_org(db, p, body))


@api.patch("/orgs/current", tags=["administration"])
async def update_org(body: dict, p: Principal = P, db: Session = D):
    return ok(db, orgs.update_org(db, p, body))


@api.get("/users", tags=["administration"])
async def users(p: Principal = P, db: Session = D):
    return orgs.list_users(db, p)


@api.post("/users", tags=["administration"])
async def invite(body: S.InviteIn, p: Principal = P, db: Session = D):
    return ok(db, orgs.invite_user(db, p, body.model_dump()))


@api.patch("/memberships/{mid}", tags=["administration"])
async def set_role(mid: str, body: dict, p: Principal = P, db: Session = D):
    return ok(db, orgs.set_role(db, p, mid, body.get("role", "")))


@api.get("/api-keys", tags=["administration"])
async def api_keys(p: Principal = P, db: Session = D):
    return orgs.list_api_keys(db, p)


@api.post("/api-keys", tags=["administration"])
async def new_key(body: S.ApiKeyIn, p: Principal = P, db: Session = D):
    return ok(db, orgs.create_api_key(db, p, body.name, body.role))


@api.delete("/api-keys/{kid}", tags=["administration"])
async def revoke_key(kid: str, p: Principal = P, db: Session = D):
    return ok(db, orgs.revoke_api_key(db, p, kid))


@api.get("/audit", tags=["administration"])
async def audit(limit: int = 200, p: Principal = P, db: Session = D):
    return orgs.audit_log(db, p, limit)


@api.get("/areas", tags=["gis"])
async def areas(domain: str | None = None, kind: str | None = None, p: Principal = P, db: Session = D):
    return orgs.list_areas(db, p, domain, kind)


@api.post("/areas", tags=["gis"])
async def create_area(body: S.AreaIn, p: Principal = P, db: Session = D):
    return ok(db, orgs.create_area(db, p, body.model_dump()))


@api.get("/restrictions", tags=["missions"])
async def restrictions(p: Principal = P, db: Session = D):
    return orgs.list_restrictions(db, p)


@api.post("/restrictions", tags=["missions"])
async def add_restriction(body: S.RestrictionIn, p: Principal = P, db: Session = D):
    return ok(db, orgs.upsert_restriction(db, p, body.model_dump()))


@api.patch("/restrictions/{rid}", tags=["missions"])
async def edit_restriction(rid: str, body: dict, p: Principal = P, db: Session = D):
    return ok(db, orgs.upsert_restriction(db, p, body, rid))


@api.get("/dashboard", tags=["dashboard"])
async def overview(p: Principal = P, db: Session = D):
    return dashboard.overview(db, p)


@api.get("/events", tags=["realtime"])
async def poll_events(after: int = 0, p: Principal = P):
    from ..rbac import SENSITIVE_READ

    return [e for e in events.since(p.org_id, after) if not e["sensitive"] or p.can(SENSITIVE_READ)]


@api.get("/notifications", tags=["alerts"])
async def notifications(p: Principal = P, db: Session = D):
    return alerts.my_notifications(db, p)


# ------------------------------------------------------------------ livestock


@api.get("/livestock/dashboard", tags=["livestock"])
async def lv_dash(p: Principal = P, db: Session = D):
    return livestock.dashboard(db, p)


@api.get("/livestock/species", tags=["livestock"])
async def lv_species(db: Session = D, p: Principal = P):
    return livestock.species_profiles(db)


@api.get("/livestock/farms", tags=["livestock"])
async def farms(p: Principal = P, db: Session = D):
    return livestock.list_farms(db, p)


@api.post("/livestock/farms", tags=["livestock"])
async def new_farm(body: dict, p: Principal = P, db: Session = D):
    return ok(db, livestock.create_farm(db, p, body))


@api.post("/livestock/herds", tags=["livestock"])
async def new_herd(body: dict, p: Principal = P, db: Session = D):
    return ok(db, livestock.create_herd(db, p, body))


@api.get("/livestock/animals", tags=["livestock"])
async def animals(farm_id: str | None = None, herd_id: str | None = None, status: str | None = None, q: str | None = None,
                  p: Principal = P, db: Session = D):
    return livestock.list_animals(db, p, farm_id, herd_id, status, q)


@api.post("/livestock/animals", tags=["livestock"])
async def new_animal(body: S.AnimalCreate, p: Principal = P, db: Session = D):
    return ok(db, livestock.create_animal(db, p, body.model_dump()))


@api.get("/livestock/animals/{aid}", tags=["livestock"])
async def animal(aid: str, p: Principal = P, db: Session = D):
    return livestock.animal_profile(db, p, aid)


@api.patch("/livestock/animals/{aid}", tags=["livestock"])
async def edit_animal(aid: str, body: dict, p: Principal = P, db: Session = D):
    return ok(db, livestock.update_animal(db, p, aid, body))


@api.get("/livestock/animals/{aid}/track", tags=["livestock"])
async def animal_track(aid: str, start: datetime | None = None, end: datetime | None = None, p: Principal = P, db: Session = D):
    return livestock.track(db, p, aid, start, end)


@api.post("/livestock/animals/{aid}/vaccinations", tags=["livestock"])
async def vacc(aid: str, body: S.Vaccination, p: Principal = P, db: Session = D):
    return ok(db, livestock.add_vaccination(db, p, aid, body.model_dump()))


@api.post("/livestock/animals/{aid}/treatments", tags=["livestock"])
async def treat(aid: str, body: S.TreatmentIn, p: Principal = P, db: Session = D):
    return ok(db, livestock.add_treatment(db, p, aid, body.model_dump()))


@api.post("/livestock/animals/{aid}/health", tags=["livestock"])
async def manual_health(aid: str, body: S.ManualHealth, p: Principal = P, db: Session = D):
    return ok(db, livestock.add_manual_health(db, p, aid, body.model_dump()))


@api.get("/livestock/health", tags=["livestock"])
async def health(level: str | None = None, review_status: str | None = None, p: Principal = P, db: Session = D):
    return livestock.list_health(db, p, level, review_status)


@api.post("/livestock/health/{hid}/review", tags=["livestock"])
async def review_health(hid: str, body: S.Review, p: Principal = P, db: Session = D):
    return ok(db, livestock.review_health(db, p, hid, body.status, body.note))


@api.get("/livestock/water", tags=["environment"])
async def water(p: Principal = P, db: Session = D):
    return livestock.water_points(db, p)


@api.get("/livestock/grazing", tags=["environment"])
async def grazing(p: Principal = P, db: Session = D):
    return livestock.grazing(db, p)


@api.post("/livestock/analyze", tags=["livestock"])
async def analyze(p: Principal = P, db: Session = D):
    from ..rbac import LIVESTOCK_WRITE

    p.require(LIVESTOCK_WRITE)
    return ok(db, livestock.analyze_org(db, p.org_id, utcnow()))


# ------------------------------------------------------------------ marine


@api.get("/marine/dashboard", tags=["marine"])
async def mr_dash(p: Principal = P, db: Session = D):
    return marine.dashboard(db, p)


@api.get("/marine/species", tags=["marine"])
async def mr_species(p: Principal = P, db: Session = D):
    return marine.list_species(db, p)


@api.post("/marine/species", tags=["marine"])
async def mr_new_species(body: dict, p: Principal = P, db: Session = D):
    return ok(db, marine.create_species(db, p, body))


@api.get("/marine/observations", tags=["marine"])
async def mr_obs(start: datetime | None = None, end: datetime | None = None, group: str | None = None,
                 verification: str | None = None, mission_id: str | None = None, bbox: str | None = None,
                 p: Principal = P, db: Session = D):
    return marine.list_observations(db, p, start, end, group, verification, mission_id, _bbox(bbox))


@api.post("/marine/observations", tags=["marine"])
async def mr_new_obs(body: S.MarineObservationIn, p: Principal = P, db: Session = D):
    return ok(db, marine.create_observation(db, p, body.model_dump()))


@api.post("/marine/observations/{oid}/verify", tags=["marine"])
async def mr_verify(oid: str, body: S.Review, p: Principal = P, db: Session = D):
    return ok(db, marine.verify_observation(db, p, oid, body.status, body.note, body.species_id, body.count))


@api.get("/marine/nests", tags=["marine"])
async def nests(beach_area_id: str | None = None, status: str | None = None, p: Principal = P, db: Session = D):
    return marine.list_nests(db, p, beach_area_id, status)


@api.post("/marine/nests", tags=["marine"])
async def new_nest(body: S.NestIn, p: Principal = P, db: Session = D):
    return ok(db, marine.create_nest(db, p, body.model_dump()))


@api.get("/marine/nests/{nid}", tags=["marine"])
async def nest(nid: str, p: Principal = P, db: Session = D):
    return marine.nest_detail(db, p, nid)


@api.post("/marine/nests/{nid}/events", tags=["marine"])
async def nest_event(nid: str, body: S.NestEventIn, p: Principal = P, db: Session = D):
    return ok(db, marine.add_nest_event(db, p, nid, body.model_dump()))


@api.get("/marine/habitat", tags=["marine"])
async def habitat(kind: str | None = None, p: Principal = P, db: Session = D):
    return marine.habitat(db, p, kind)


@api.get("/marine/dives", tags=["robotics"])
async def dives(p: Principal = P, db: Session = D):
    return marine.rov_dives(db, p)


@api.get("/marine/dives/{did}", tags=["robotics"])
async def dive(did: str, p: Principal = P, db: Session = D):
    return marine.rov_dive(db, p, did)


@api.get("/marine/behaviour", tags=["marine"])
async def behaviour(mission_id: str | None = None, p: Principal = P, db: Session = D):
    return marine.behaviour_events(db, p, mission_id)


@api.post("/marine/behaviour/{bid}/review", tags=["marine"])
async def behaviour_review(bid: str, body: S.Review, p: Principal = P, db: Session = D):
    return ok(db, marine.review_behaviour(db, p, bid, body.status, body.note))


# ------------------------------------------------------------------ devices


@api.get("/devices", tags=["devices"])
async def devs(device_type: str | None = None, domain: str | None = None, p: Principal = P, db: Session = D):
    return devices.list_devices(db, p, device_type, domain)


@api.post("/devices", tags=["devices"])
async def new_dev(body: S.DeviceIn, p: Principal = P, db: Session = D):
    return ok(db, devices.register(db, p, body.model_dump()))


@api.get("/devices/stats", tags=["devices"])
async def dev_stats(hours: float = 24, p: Principal = P, db: Session = D):
    return {"fleet": devices.fleet_summary(db, p), "ingest": devices.ingest_stats(db, p, hours)}


@api.get("/devices/{did}", tags=["devices"])
async def dev(did: str, p: Principal = P, db: Session = D):
    return devices.get_device(db, p, did)


@api.patch("/devices/{did}", tags=["devices"])
async def edit_dev(did: str, body: dict, p: Principal = P, db: Session = D):
    return ok(db, devices.update(db, p, did, body))


@api.post("/devices/{did}/maintenance", tags=["devices"])
async def maint(did: str, body: S.Maintenance, p: Principal = P, db: Session = D):
    return ok(db, devices.add_maintenance(db, p, did, body.model_dump()))


@api.post("/ingest/{did}", tags=["devices"])
async def ingest(did: str, request: Request, body: S.IngestIn, db: Session = D):
    """Device upload (store-and-forward batch). Authenticated with the device secret in `X-Device-Key`."""
    raw = await request.body()
    d = devices.authenticate_device(db, did, request.headers.get("x-device-key"), request.headers.get("x-signature"), raw)
    return ok(db, devices.ingest(db, d, body.model_dump()))


# ------------------------------------------------------------------ missions


@api.get("/missions", tags=["missions"])
async def mission_list(status: str | None = None, domain: str | None = None, p: Principal = P, db: Session = D):
    return missions.list_missions(db, p, status, domain)


@api.get("/missions/kinds", tags=["missions"])
async def mission_kinds():
    return {k: {"domain": v[0], "vehicle": v[1], "sensor": v[2], "default_altitude_m": v[3]} for k, v in missions.KINDS.items()}


@api.get("/missions/suggestions", tags=["missions"])
async def mission_suggest(p: Principal = P, db: Session = D):
    return missions.suggestions(db, p)


@api.post("/missions", tags=["missions"])
async def mission_create(body: S.MissionIn, p: Principal = P, db: Session = D):
    return ok(db, missions.create(db, p, body.model_dump()))


@api.get("/missions/{mid}", tags=["missions"])
async def mission_get(mid: str, p: Principal = P, db: Session = D):
    return missions.get_mission(db, p, mid)


@api.post("/missions/{mid}/validate", tags=["missions"])
async def mission_validate(mid: str, p: Principal = P, db: Session = D):
    return ok(db, missions.validate(db, p, mid))


@api.post("/missions/{mid}/approve", tags=["missions"])
async def mission_approve(mid: str, body: S.Note, p: Principal = P, db: Session = D):
    return ok(db, missions.approve(db, p, mid, body.note))


@api.post("/missions/{mid}/start", tags=["missions"])
async def mission_start(mid: str, p: Principal = P, db: Session = D):
    return ok(db, missions.start(db, p, mid))


@api.post("/missions/{mid}/cancel", tags=["missions"])
async def mission_cancel(mid: str, body: S.Note, p: Principal = P, db: Session = D):
    return ok(db, missions.cancel(db, p, mid, body.note))


@api.post("/missions/{mid}/abort", tags=["missions"])
async def mission_abort(mid: str, body: S.Note, p: Principal = P, db: Session = D):
    return ok(db, missions.abort(db, p, mid, body.note or "operator emergency abort"))


# ------------------------------------------------------------------ AI


@api.get("/ai/models", tags=["ai"])
async def ai_models(p: Principal = P, db: Session = D):
    return ai.list_models(db, p)


@api.post("/ai/detect", tags=["ai"])
async def ai_detect(body: S.DetectIn, p: Principal = P, db: Session = D):
    return ok(db, ai.detect(db, p, body.model_dump()))


@api.get("/ai/detections", tags=["ai"])
async def ai_dets(review_status: str | None = None, mission_id: str | None = None, media_id: str | None = None,
                  p: Principal = P, db: Session = D):
    return ai.list_detections(db, p, review_status, mission_id, media_id)


@api.post("/ai/detections/{did}/review", tags=["ai"])
async def ai_review(did: str, body: S.Review, p: Principal = P, db: Session = D):
    return ok(db, ai.review_detection(db, p, did, body.status, body.label))


@api.get("/media", tags=["ai"])
async def media_list(mission_id: str | None = None, p: Principal = P, db: Session = D):
    return ai.list_media(db, p, mission_id)


@api.get("/media/{mid}", tags=["ai"], response_class=Response)
async def media_get(mid: str, p: Principal = P, db: Session = D):
    data, ctype = ai.media_bytes(db, p, mid)
    return Response(content=data, media_type=ctype, headers={"Cache-Control": "private, max-age=3600"})


# ------------------------------------------------------------------ alerts


@api.get("/alerts", tags=["alerts"])
async def alert_list(status: str | None = None, domain: str | None = None, p: Principal = P, db: Session = D):
    return alerts.list_alerts(db, p, status, domain)


@api.post("/alerts/{aid}/action", tags=["alerts"])
async def alert_action(aid: str, body: S.AlertAction, p: Principal = P, db: Session = D):
    return ok(db, alerts.transition(db, p, aid, body.action, body.note))


@api.get("/alert-rules", tags=["alerts"])
async def rules(p: Principal = P, db: Session = D):
    return alerts.list_rules(db, p)


@api.patch("/alert-rules/{rid}", tags=["alerts"])
async def edit_rule(rid: str, body: dict, p: Principal = P, db: Session = D):
    return ok(db, alerts.update_rule(db, p, rid, body))


# ------------------------------------------------------------------ reports


@api.get("/reports/kinds", tags=["reports"])
async def report_kinds():
    return {k: {"domain": v[0], "sections": v[1]} for k, v in reports.KINDS.items()}


@api.get("/reports", tags=["reports"])
async def report_list(p: Principal = P, db: Session = D):
    return reports.list_reports(db, p)


@api.post("/reports", tags=["reports"])
async def report_create(body: S.ReportIn, p: Principal = P, db: Session = D):
    return ok(db, reports.create(db, p, body.model_dump()))


@api.get("/reports/{rid}", tags=["reports"])
async def report_get(rid: str, p: Principal = P, db: Session = D):
    return reports.get_report(db, p, rid)


@api.get("/reports/{rid}/export", tags=["reports"], response_class=Response)
async def report_export(rid: str, format: str = Query("pdf", pattern="^(pdf|csv|xlsx)$"), p: Principal = P, db: Session = D):
    data, ctype, name = reports.export(db, p, rid, format)
    return Response(content=data, media_type=ctype, headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ------------------------------------------------------------------ environment, GIS, sync


@api.get("/environment/measurements", tags=["environment"])
async def env(kind: str | None = None, domain: str | None = None, hours: float = 72, p: Principal = P, db: Session = D):
    return environment.measurements(db, p, kind, domain, hours)


@api.post("/environment/measurements", tags=["environment"])
async def env_add(body: S.EnvIn, p: Principal = P, db: Session = D):
    return ok(db, environment.add_measurement(db, p, body.model_dump()))


@api.get("/gis/layers", tags=["gis"])
async def gis_layers():
    return gis.LAYERS


@api.get("/gis/layers/{name}", tags=["gis"])
async def gis_layer(name: str, bbox: str | None = None, start: datetime | None = None, end: datetime | None = None,
                    domain: str | None = None, p: Principal = P, db: Session = D):
    return gis.layer(db, p, name, _bbox(bbox), start, end, domain)


@api.get("/gis/playback", tags=["gis"])
async def gis_playback(start: datetime, end: datetime, step_min: int = 30, p: Principal = P, db: Session = D):
    return gis.playback(db, p, start, end, step_min)


@api.post("/sync", tags=["offline"])
async def sync(body: S.SyncIn, p: Principal = P, db: Session = D):
    return ok(db, environment.sync_batch(db, p, body.items))


# ------------------------------------------------------------------ simulation (digital twin)


def _sim():
    from ..sim.world import get_sim

    s = get_sim()
    if s is None:
        raise NotConfigured("the digital twin is not running on this server")
    return s


@api.get("/sim/status", tags=["simulation"])
async def sim_status(p: Principal = P, db: Session = D):
    s = _sim()
    s.world(db, p.org_id)
    return s.status(p.org_id)


@api.post("/sim/step", tags=["simulation"])
async def sim_step(body: S.StepIn, p: Principal = P, db: Session = D):
    p.require(SIM_CONTROL)
    s = _sim()
    s.world(db, p.org_id)
    res = s.step(db, body.minutes)
    return ok(db, res)


@api.post("/sim/scenario", tags=["simulation"])
async def sim_scenario(body: S.ScenarioIn, p: Principal = P, db: Session = D):
    p.require(SIM_CONTROL)
    s = _sim()
    msg = s.world(db, p.org_id).inject(db, body.kind, body.params, s.clock)
    from ..services.common import audit as _audit

    _audit(db, p, "sim.scenario", "simulation", body.kind, body.params)
    events.publish(p.org_id, "sim.scenario", {"kind": body.kind, "message": msg})
    return ok(db, {"kind": body.kind, "message": msg})


@api.post("/sim/animals", tags=["simulation"])
async def sim_add_animals(body: S.AddAnimalsIn, p: Principal = P, db: Session = D):
    p.require(SIM_CONTROL)
    from ..rbac import LIVESTOCK_WRITE

    p.require(LIVESTOCK_WRITE)
    ids = _sim().add_livestock(db, p.org_id, body.herd_id, body.count, body.species)
    return ok(db, {"created": ids})


@api.get("/sim/ground-truth", tags=["simulation"])
async def sim_truth(p: Principal = P, db: Session = D):
    """Simulator ground truth — for evaluation and demonstration only, never mixed with observations."""
    p.require(SIM_CONTROL)
    return _sim().world(db, p.org_id).truth()


# ------------------------------------------------------------------ public (no auth)

public = APIRouter(prefix="/public/v1", tags=["public"])


@public.get("/summary/{org_slug}")
async def public_summary(org_slug: str, db: Session = D):
    o = db.scalar(select(Organization).where(Organization.slug == org_slug))
    if not o:
        raise NotFound("organisation not found")
    return {"organization": o.name, "region": o.region, **marine.public_summary(db, o.id)}


# ------------------------------------------------------------------ websocket

ws_router = APIRouter()


@ws_router.websocket("/ws/events")
async def ws_events(ws: WebSocket, token: str):
    try:
        payload = decode_token(token)
        db = SessionLocal()
        try:
            p = orgs.principal_from_token(db, payload)
        finally:
            db.close()
    except AICNError:
        await ws.close(code=4401)
        return
    await ws.accept()
    q = events.subscribe()
    try:
        while True:
            ev = await q.get()
            if ev["org_id"] != p.org_id or (ev["sensitive"] and not p.can("sensitive.read")):
                continue
            await ws.send_json(ev)
    except (WebSocketDisconnect, asyncio.CancelledError):
        pass
    finally:
        events.unsubscribe(q)
