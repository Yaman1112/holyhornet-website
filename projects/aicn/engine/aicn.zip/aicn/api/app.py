"""ASGI application: security headers, rate limiting, body-size limit, CORS, error mapping, OpenAPI.

Middleware is written as plain ASGI (no BaseHTTPMiddleware / task groups) so it also runs in Pyodide.
"""

from __future__ import annotations

import json
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .. import __version__, config
from ..errors import AICNError
from .routes import api, public, ws_router

DESCRIPTION = """
**AICN — Animal Intelligence & Conservation Network.** One platform, two divisions:
*Livestock Guardian AI* and *Marine Animal Intelligence*, on shared identity, GIS, devices, missions, AI, alerts and reports.

Authentication: `POST /api/v1/auth/login` → `Authorization: Bearer <token>`, or `X-API-Key` for integrations.
Devices upload to `/api/v1/ingest/{device_id}` with `X-Device-Key`. Every request is scoped to one organisation;
sensitive conservation coordinates need the `sensitive.read` permission. AI outputs are observations for human review.
"""


class SecurityMiddleware:
    """Security headers, per-client token-bucket rate limit, 8 MB request-body cap."""

    def __init__(self, app, per_minute: int = 600, max_body: int = 8 * 1024 * 1024):
        self.app = app
        self.rate = per_minute / 60.0
        self.cap = float(per_minute)
        self.max_body = max_body
        self.buckets: dict[str, list[float]] = {}

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = {k.decode().lower(): v.decode() for k, v in scope.get("headers", [])}
        client = headers.get("x-api-key") or headers.get("authorization", "")[-24:] or (scope.get("client") or ["anon"])[0]
        now = time.monotonic()
        tokens, last = self.buckets.get(client, [self.cap, now])
        tokens = min(self.cap, tokens + (now - last) * self.rate)
        if tokens < 1:
            return await self._json(send, 429, {"detail": "rate limit exceeded"}, [(b"retry-after", b"5")])
        self.buckets[client] = [tokens - 1, now]
        if len(self.buckets) > 10000:
            self.buckets.clear()
        cl = headers.get("content-length")
        if cl and cl.isdigit() and int(cl) > self.max_body:
            return await self._json(send, 413, {"detail": "request body too large"})

        async def send_wrapper(msg):
            if msg["type"] == "http.response.start":
                h = list(msg.get("headers", []))
                h += [(b"x-content-type-options", b"nosniff"), (b"x-frame-options", b"DENY"),
                      (b"referrer-policy", b"no-referrer"), (b"x-aicn-version", __version__.encode())]
                if config.settings.env == "production":
                    h.append((b"strict-transport-security", b"max-age=31536000; includeSubDomains"))
                msg["headers"] = h
            await send(msg)

        return await self.app(scope, receive, send_wrapper)

    @staticmethod
    async def _json(send, status, body, extra=None):
        data = json.dumps(body).encode()
        await send({"type": "http.response.start", "status": status,
                    "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(data)).encode())] + (extra or [])})
        await send({"type": "http.response.body", "body": data})


def create_app(init: bool = True) -> FastAPI:
    s = config.settings
    s.validate()

    @asynccontextmanager
    async def lifespan(app):
        if init:
            bootstrap(s)
        yield

    app = FastAPI(title="AICN API", version=__version__, description=DESCRIPTION, lifespan=lifespan,
                  openapi_tags=[{"name": n} for n in ("auth", "dashboard", "livestock", "marine", "environment", "gis", "devices",
                                                      "missions", "robotics", "ai", "alerts", "reports", "offline", "simulation",
                                                      "administration", "realtime", "public")])

    @app.exception_handler(AICNError)
    async def aicn_error(request: Request, exc: AICNError):
        return JSONResponse({"detail": exc.detail}, status_code=exc.status)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        errs = [{"loc": list(e.get("loc", [])), "msg": e.get("msg")} for e in exc.errors()]
        return JSONResponse({"detail": "invalid request", "errors": errs}, status_code=422)

    @app.get("/health", tags=["dashboard"])
    async def health():
        from ..db import get_engine, utcnow

        return {"status": "ok", "version": __version__, "time": utcnow().isoformat(),
                "database": get_engine().dialect.name if get_engine() else None}

    app.include_router(api)
    app.include_router(public)
    app.include_router(ws_router)
    app.add_middleware(CORSMiddleware, allow_origins=s.cors_origins, allow_credentials=False,
                       allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["Authorization", "Content-Type", "X-API-Key"])
    app.add_middleware(SecurityMiddleware, per_minute=s.rate_limit_per_minute)
    return app


def bootstrap(s: config.Settings, simulate: bool | None = None):
    """Create tables, catalogues; in demo mode seed the demonstration deployment and start the twin."""
    from sqlalchemy import func, select

    from .. import seed
    from ..db import SessionLocal, init_engine, set_virtual_now
    from ..models import CollarTelemetry, Organization
    from ..services import ai as ai_svc
    from ..sim.world import Simulation, default_start, get_sim, set_sim

    init_engine(s.database_url)
    db = SessionLocal()
    try:
        seed.catalogue(db)
        db.commit()
        if s.seed_demo if simulate is None else simulate:
            fresh = db.scalar(select(Organization.id).where(Organization.slug == "aicn-pilot")) is None
            seed.demo(db, iterations=s.pbkdf2_iterations if not s.browser_mode else 20_000)
            if get_sim() is None:
                sim = Simulation(default_start())
                set_sim(sim)
                if fresh:
                    seed.warm_up(db, sim, 2.0)
                else:  # resume the twin's clock where the stored data ends
                    last = db.scalar(select(func.max(CollarTelemetry.recorded_at)))
                    if last:
                        sim.clock = last
                        set_virtual_now(last)
                    sim.attach_all(db)
        ai_svc.sync_registry(db)
        db.commit()
    finally:
        db.close()


app = None


def get_app():
    global app
    if app is None:
        app = create_app()
    return app
