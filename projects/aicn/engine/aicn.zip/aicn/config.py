"""Runtime settings, read from environment variables (prefix AICN_)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

DEV_SECRET = "dev-insecure-secret-change-me"
_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DEFAULT_DB = "sqlite:///" + os.path.join(_BACKEND_DIR, "data", "aicn.db").replace("\\", "/")


def _env(name: str, default: str) -> str:
    return os.environ.get("AICN_" + name, default)


@dataclass
class Settings:
    env: str = field(default_factory=lambda: _env("ENV", "development"))
    database_url: str = field(default_factory=lambda: _env("DATABASE_URL", _DEFAULT_DB))
    secret_key: str = field(default_factory=lambda: _env("SECRET_KEY", DEV_SECRET))
    token_ttl_s: int = field(default_factory=lambda: int(_env("TOKEN_TTL_S", "28800")))
    pbkdf2_iterations: int = field(default_factory=lambda: int(_env("PBKDF2_ITERATIONS", "120000")))
    rate_limit_per_minute: int = field(default_factory=lambda: int(_env("RATE_LIMIT_PER_MINUTE", "600")))
    cors_origins: list[str] = field(default_factory=lambda: _env("CORS_ORIGINS", "http://localhost:3500").split(","))
    media_dir: str = field(default_factory=lambda: _env("MEDIA_DIR", os.path.join(_BACKEND_DIR, "data", "media")))
    # notification channels: unset = channel reports "not_configured" (never pretends to send)
    smtp_host: str = field(default_factory=lambda: _env("SMTP_HOST", ""))
    smtp_port: int = field(default_factory=lambda: int(_env("SMTP_PORT", "587")))
    smtp_user: str = field(default_factory=lambda: _env("SMTP_USER", ""))
    smtp_password: str = field(default_factory=lambda: _env("SMTP_PASSWORD", ""))
    smtp_from: str = field(default_factory=lambda: _env("SMTP_FROM", "alerts@aicn.local"))
    sms_provider: str = field(default_factory=lambda: _env("SMS_PROVIDER", ""))  # e.g. africastalking
    sms_api_key: str = field(default_factory=lambda: _env("SMS_API_KEY", ""))
    sms_username: str = field(default_factory=lambda: _env("SMS_USERNAME", ""))
    onnx_model_dir: str = field(default_factory=lambda: _env("ONNX_MODEL_DIR", "./models"))
    browser_mode: bool = field(default_factory=lambda: _env("BROWSER_MODE", "0") == "1")
    seed_demo: bool = field(default_factory=lambda: _env("SEED_DEMO", "1") == "1")

    def validate(self) -> None:
        if self.env == "production":
            if self.secret_key == DEV_SECRET or len(self.secret_key) < 32:
                raise RuntimeError("AICN_SECRET_KEY must be set to a random value of at least 32 characters in production")
            if self.database_url.startswith("sqlite"):
                raise RuntimeError("production requires PostgreSQL (AICN_DATABASE_URL)")


settings = Settings()


def reload_settings(**overrides) -> Settings:
    global settings
    s = Settings()
    for k, v in overrides.items():
        setattr(s, k, v)
    settings = s
    return s
