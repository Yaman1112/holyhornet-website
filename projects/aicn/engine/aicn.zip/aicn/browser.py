"""Browser edition bridge: runs the unmodified FastAPI application inside Pyodide.

The web worker calls `boot()` once, then `request(method, path, headers_json, body_bytes)` for every API call.
Requests travel through the full ASGI stack (middleware, validation, auth, RBAC, services, SQLite) exactly as
on a server; only the transport differs (postMessage instead of TCP).
"""

from __future__ import annotations

import json

_app = None


def boot() -> dict:
    global _app
    import time

    from . import config
    from .api.app import bootstrap, create_app

    t = time.time()
    s = config.reload_settings(database_url="sqlite://", browser_mode=True, seed_demo=True, pbkdf2_iterations=20_000,
                               rate_limit_per_minute=100000, cors_origins=["*"])
    _app = create_app(init=False)
    bootstrap(s)
    return {"ok": True, "boot_s": round(time.time() - t, 2)}


async def request(method: str, path: str, headers_json: str = "{}", body: bytes | None = None) -> dict:
    if _app is None:
        raise RuntimeError("call boot() first")
    headers = json.loads(headers_json or "{}")
    if "?" in path:
        p, qs = path.split("?", 1)
    else:
        p, qs = path, ""
    # JS null arrives as JsNull (not None) in recent Pyodide versions
    raw_body = bytes(body) if body is not None and type(body).__name__ != "JsNull" else b""
    hdrs = [(k.lower().encode(), str(v).encode()) for k, v in headers.items()]
    if raw_body:
        hdrs.append((b"content-length", str(len(raw_body)).encode()))
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(), "scheme": "http",
             "path": p, "raw_path": p.encode(), "query_string": qs.encode(), "root_path": "", "headers": hdrs,
             "client": ("browser", 0), "server": ("aicn.local", 80)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": raw_body, "more_body": False}
        return {"type": "http.disconnect"}

    out = {"status": 500, "headers": {}, "body": b""}
    chunks = []

    async def send(msg):
        if msg["type"] == "http.response.start":
            out["status"] = msg["status"]
            out["headers"] = {k.decode(): v.decode() for k, v in msg.get("headers", [])}
        elif msg["type"] == "http.response.body":
            chunks.append(msg.get("body", b""))

    await _app(scope, receive, send)
    out["body"] = b"".join(chunks)
    return out
