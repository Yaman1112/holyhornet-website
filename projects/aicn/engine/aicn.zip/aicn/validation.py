"""Scenario validation of the livestock intelligence against simulator ground truth.

  python -m aicn.validation [--seeds 3] [--out reports/scenario_validation.json]

For each seed: build a fresh demo deployment, warm up, then
  * calm run   — 24 h without injected events → every alert is a false alarm
  * scenarios  — inject one event, run up to N hours, record whether / when the expected alert kind appears
Results describe the engines on SYNTHETIC data only.
"""

from __future__ import annotations

import argparse
import json
import time
from datetime import timedelta

from sqlalchemy import select

SCENARIOS = [
    # name, params, expected alert kinds (any), hours to wait
    ("stray", {"speed_mps": 0.35, "distance_m": 2200}, {"separation", "missing_animal", "boundary_exit"}, 8),
    ("illness", {"severity": 0.85}, {"health_concern", "inactivity"}, 14),
    ("collar_dropped", {}, {"inactivity", "separation", "health_concern"}, 10),
    ("collar_failure", {}, {"device_offline"}, 8),
    ("gateway_outage", {"hours": 5}, {"device_offline", "network_outage"}, 6),
    ("fence_breach", {}, {"boundary_exit"}, 5),
    ("battery_drain", {"factor": 120}, {"low_battery"}, 10),
    ("pump_failure", {}, {"water_shortage"}, 72),
]


def fresh(seed: int):
    from . import config, seed as seed_mod
    from .db import SessionLocal, init_engine
    from .services import events, media
    from .sim.world import Simulation, default_start, set_sim

    config.reload_settings(database_url="sqlite://", browser_mode=True)
    init_engine("sqlite://")
    events.reset()
    media.reset(None)
    db = SessionLocal()
    seed_mod.demo(db, iterations=1000)
    sim = Simulation(default_start(), seed=seed)
    set_sim(sim)
    seed_mod.warm_up(db, sim, 2.0)
    return db, sim


def _alerts(db, org_id, since):
    from .models import Alert

    return list(db.scalars(select(Alert).where(Alert.org_id == org_id, Alert.created_at >= since)))


def run(seeds: list[int]) -> dict:
    from .models import Organization

    out = {"calm": [], "scenarios": {s[0]: [] for s in SCENARIOS}, "seeds": seeds,
           "note": "Synthetic validation: digital-twin ground truth, not field data."}
    for sd in seeds:
        db, sim = fresh(sd)
        org = db.scalar(select(Organization).where(Organization.slug == "aicn-pilot"))
        t0 = sim.clock
        sim.step(db, 24 * 60)
        calm = [a for a in _alerts(db, org.id, t0) if a.domain == "livestock" and a.kind not in ("low_battery",)]
        out["calm"].append({"seed": sd, "false_alarms": len(calm), "kinds": sorted({a.kind for a in calm}),
                            "animal_hours": len(sim.worlds[org.id].livestock.animals) * 24})
        for name, prm, expected, hours in SCENARIOS:
            db, sim = fresh(sd)
            org = db.scalar(select(Organization).where(Organization.slug == "aicn-pilot"))
            w = sim.worlds[org.id]
            sim.step(db, 60)
            t0 = sim.clock
            msg = w.inject(db, name, dict(prm), sim.clock)
            hit_at = None
            other = set()
            for h in range(hours):
                sim.step(db, 60)
                kinds = {a.kind for a in _alerts(db, org.id, t0)}
                if kinds & expected:
                    hit_at = h + 1
                    other = kinds - expected
                    break
            if hit_at is None:
                other = {a.kind for a in _alerts(db, org.id, t0)}
            out["scenarios"][name].append({"seed": sd, "detected": hit_at is not None, "hours_to_alert": hit_at,
                                           "other_alerts": sorted(other), "event": msg})
    summ = {}
    for name, rows in out["scenarios"].items():
        det = [r for r in rows if r["detected"]]
        summ[name] = {"detected": f"{len(det)}/{len(rows)}",
                      "median_hours": sorted(r["hours_to_alert"] for r in det)[len(det) // 2] if det else None}
    out["summary"] = summ
    out["calm_false_alarms_per_100_animal_days"] = round(
        100 * sum(c["false_alarms"] for c in out["calm"]) / max(sum(c["animal_hours"] for c in out["calm"]) / 24, 1), 2)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--first-seed", type=int, default=7001)
    ap.add_argument("--out", default="")
    a = ap.parse_args()
    t = time.time()
    res = run(list(range(a.first_seed, a.first_seed + a.seeds)))
    res["runtime_s"] = round(time.time() - t, 1)
    js = json.dumps(res, indent=2, default=str)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(js)
    print(json.dumps({"summary": res["summary"], "calm": res["calm"],
                      "false_alarms_per_100_animal_days": res["calm_false_alarms_per_100_animal_days"]}, indent=1))


if __name__ == "__main__":
    main()
