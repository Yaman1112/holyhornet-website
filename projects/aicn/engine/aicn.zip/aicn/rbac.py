"""Role-based access control.

Every request resolves to a Principal: one user acting inside one organisation with one role
(or an API key / device). Services call `principal.require(perm)`; data is always filtered by org_id.
Sensitive conservation coordinates need the extra permission `sensitive.read`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .errors import Forbidden

ROLES = {
    "platform_admin": "Platform Administrator",
    "org_admin": "Organization Administrator",
    "farmer": "Farmer",
    "veterinarian": "Veterinary Professional",
    "wildlife_researcher": "Wildlife Researcher",
    "marine_researcher": "Marine Researcher",
    "conservation_officer": "Conservation Officer",
    "uav_operator": "UAV Operator",
    "rov_operator": "ROV Operator",
    "viewer": "Read-only Viewer",
}

_R = "read"
LIVESTOCK_READ = "livestock.read"
LIVESTOCK_WRITE = "livestock.write"
HEALTH_REVIEW = "health.review"
MARINE_READ = "marine.read"
MARINE_WRITE = "marine.write"
MARINE_VERIFY = "marine.verify"
SENSITIVE_READ = "sensitive.read"
DEVICES_READ = "devices.read"
DEVICES_WRITE = "devices.write"
MISSIONS_READ = "missions.read"
MISSIONS_PLAN = "missions.plan"
UAV_APPROVE = "missions.approve_uav"
ROV_APPROVE = "missions.approve_rov"
MISSIONS_ABORT = "missions.abort"
ALERTS_READ = "alerts.read"
ALERTS_MANAGE = "alerts.manage"
ALERT_RULES = "alerts.rules"
REPORTS = "reports.create"
AI_RUN = "ai.run"
AI_REVIEW = "ai.review"
ENV_READ = "environment.read"
ENV_WRITE = "environment.write"
SIM_CONTROL = "simulation.control"
ORG_ADMIN = "org.admin"
AUDIT_READ = "audit.read"
PLATFORM_ADMIN = "platform.admin"

ALL = {
    LIVESTOCK_READ, LIVESTOCK_WRITE, HEALTH_REVIEW, MARINE_READ, MARINE_WRITE, MARINE_VERIFY, SENSITIVE_READ,
    DEVICES_READ, DEVICES_WRITE, MISSIONS_READ, MISSIONS_PLAN, UAV_APPROVE, ROV_APPROVE, MISSIONS_ABORT,
    ALERTS_READ, ALERTS_MANAGE, ALERT_RULES, REPORTS, AI_RUN, AI_REVIEW, ENV_READ, ENV_WRITE, SIM_CONTROL,
    ORG_ADMIN, AUDIT_READ,
}

_BASE_READ = {LIVESTOCK_READ, MARINE_READ, DEVICES_READ, MISSIONS_READ, ALERTS_READ, ENV_READ}

PERMISSIONS: dict[str, set[str]] = {
    "platform_admin": ALL | {PLATFORM_ADMIN},
    "org_admin": ALL,
    "farmer": {LIVESTOCK_READ, LIVESTOCK_WRITE, DEVICES_READ, MISSIONS_READ, MISSIONS_PLAN, ALERTS_READ,
               ALERTS_MANAGE, REPORTS, ENV_READ, ENV_WRITE},
    "veterinarian": {LIVESTOCK_READ, LIVESTOCK_WRITE, HEALTH_REVIEW, ALERTS_READ, ALERTS_MANAGE, REPORTS,
                     ENV_READ, DEVICES_READ},
    "wildlife_researcher": _BASE_READ | {MARINE_WRITE, MARINE_VERIFY, AI_RUN, AI_REVIEW, REPORTS, ENV_WRITE,
                                         MISSIONS_PLAN, SIM_CONTROL},
    "marine_researcher": _BASE_READ | {MARINE_WRITE, MARINE_VERIFY, SENSITIVE_READ, AI_RUN, AI_REVIEW, REPORTS,
                                       ENV_WRITE, MISSIONS_PLAN, SIM_CONTROL},
    "conservation_officer": _BASE_READ | {MARINE_WRITE, SENSITIVE_READ, ALERTS_MANAGE, REPORTS, ENV_WRITE,
                                          MISSIONS_PLAN, AI_REVIEW},
    "uav_operator": _BASE_READ | {DEVICES_WRITE, MISSIONS_PLAN, UAV_APPROVE, MISSIONS_ABORT, AI_RUN, SIM_CONTROL},
    "rov_operator": _BASE_READ | {DEVICES_WRITE, MISSIONS_PLAN, ROV_APPROVE, MISSIONS_ABORT, AI_RUN, SIM_CONTROL},
    "viewer": set(_BASE_READ),
}


@dataclass
class Principal:
    org_id: str
    role: str
    user_id: str | None = None
    name: str = ""
    kind: str = "user"  # user | api_key | device | system
    scope: dict = field(default_factory=dict)

    @property
    def perms(self) -> set[str]:
        return PERMISSIONS.get(self.role, set())

    def can(self, perm: str) -> bool:
        return perm in self.perms

    def require(self, *perms: str) -> None:
        missing = [p for p in perms if not self.can(p)]
        if missing:
            raise Forbidden(f"role '{self.role}' lacks permission: {', '.join(missing)}")

    def require_any(self, *perms: str) -> None:
        if not any(self.can(p) for p in perms):
            raise Forbidden(f"role '{self.role}' needs one of: {', '.join(perms)}")

    @property
    def farm_scope(self) -> list[str] | None:
        """Farmers can be limited to their own farms; None = whole organisation."""
        farms = self.scope.get("farm_ids") if self.scope else None
        return list(farms) if farms else None


def system_principal(org_id: str) -> Principal:
    return Principal(org_id=org_id, role="org_admin", name="system", kind="system")


def permission_matrix() -> dict:
    return {r: sorted(PERMISSIONS[r]) for r in ROLES}
