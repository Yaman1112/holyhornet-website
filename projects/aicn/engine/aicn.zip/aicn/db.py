"""Database engine, declarative base and shared column types.

SQLite is the development / in-browser database; PostgreSQL + PostGIS is the production target
(see migrations/postgres/001_schema.sql for schemas, PostGIS geometry columns and row-level security).
Geometry is stored portably (lat/lon columns + GeoJSON text) so the same ORM runs on both.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from sqlalchemy.pool import StaticPool
from sqlalchemy.types import DateTime, Text, TypeDecorator


def new_id() -> str:
    return uuid.uuid4().hex


_virtual_now: datetime | None = None


def utcnow() -> datetime:
    """Platform clock. Real UTC in production; the digital twin's virtual clock while a simulation drives the platform."""
    return _virtual_now or datetime.now(timezone.utc)


def set_virtual_now(dt: datetime | None) -> None:
    global _virtual_now
    _virtual_now = dt


class UTCDateTime(TypeDecorator):
    """Stores naive UTC, always returns timezone-aware UTC datetimes."""

    impl = DateTime
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).replace(tzinfo=None)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return value.replace(tzinfo=timezone.utc)


class JSONText(TypeDecorator):
    """JSON stored as text (jsonb in the PostgreSQL migration)."""

    impl = Text
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return None if value is None else json.dumps(value, separators=(",", ":"), default=str)

    def process_result_value(self, value, dialect):
        return None if value is None else json.loads(value)


class Base(DeclarativeBase):
    pass


_engine = None
SessionLocal = sessionmaker(autoflush=False, expire_on_commit=False)


def make_engine(url: str):
    if url.startswith("sqlite"):
        kw = {"connect_args": {"check_same_thread": False}}
        if url in ("sqlite://", "sqlite:///:memory:"):
            kw["poolclass"] = StaticPool
        eng = create_engine(url, **kw)

        @event.listens_for(eng, "connect")
        def _pragma(dbapi_conn, _):
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.close()

        return eng
    return create_engine(url, pool_pre_ping=True, pool_size=10, max_overflow=20)


def init_engine(url: str):
    global _engine
    _engine = make_engine(url)
    SessionLocal.configure(bind=_engine)
    from . import models  # noqa: F401  (register tables)

    Base.metadata.create_all(_engine)
    return _engine


def get_engine():
    return _engine
