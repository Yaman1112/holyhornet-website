"""Animal Detection AI: image decoding, detectors, georeferencing.

Detectors share one interface so models can be replaced independently:

  thermal-blob-v1     classical thermal detector (background subtraction + connected components) — counts
                      warm bodies in nadir thermal frames. Works without training data; does not classify species.
  sea-anomaly-v1      classical sea-surface anomaly detector for RGB aerial frames: robust water colour model,
                      Mahalanobis-style distance, components, size/elongation -> candidate object + coarse size class.
                      Species group from size is a *hint for review*, never a confirmed identification.
  onnx-yolo           wrapper for a YOLO-family ONNX export (Ultralytics v8/11 output layout). Needs onnxruntime and
                      weights in AICN_ONNX_MODEL_DIR; reports itself unavailable otherwise.

Real-world accuracy of any detector must be measured on labelled field imagery from the deployment area;
numbers produced by the simulator measure performance on synthetic frames only.
"""

from __future__ import annotations

import base64
import math
import os
import struct
import zlib
from dataclasses import asdict, dataclass, field

import numpy as np

from ..geo import LocalFrame

# --------------------------------------------------------------------------- images


def decode_png(data: bytes) -> np.ndarray:
    """Minimal PNG decoder: 8-bit greyscale / grey+alpha / RGB / RGBA, non-interlaced."""
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG file")
    pos, idat, w = 8, [], None
    while pos < len(data):
        (ln,) = struct.unpack(">I", data[pos:pos + 4])
        typ = data[pos + 4:pos + 8]
        chunk = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b"IHDR":
            w, h, depth, ctype, _, _, interlace = struct.unpack(">IIBBBBB", chunk)
            if depth != 8 or interlace:
                raise ValueError("only 8-bit non-interlaced PNG is supported; send raw RGB instead")
            ch = {0: 1, 2: 3, 4: 2, 6: 4}.get(ctype)
            if ch is None:
                raise ValueError("palette PNG not supported")
        elif typ == b"IDAT":
            idat.append(chunk)
        elif typ == b"IEND":
            break
    if w is None:
        raise ValueError("PNG without header")
    raw = zlib.decompress(b"".join(idat))
    stride = w * ch
    out = np.zeros((h, stride), np.uint8)
    prev = np.zeros(stride, np.int32)
    p = 0
    for y in range(h):
        ft = raw[p]
        line = np.frombuffer(raw, np.uint8, stride, p + 1).astype(np.int32)
        p += stride + 1
        if ft == 0:
            cur = line
        elif ft == 2:
            cur = (line + prev) & 255
        else:
            cur = np.zeros(stride, np.int32)
            for i in range(stride):
                a = cur[i - ch] if i >= ch else 0
                b = prev[i]
                c = prev[i - ch] if i >= ch else 0
                if ft == 1:
                    cur[i] = (line[i] + a) & 255
                elif ft == 3:
                    cur[i] = (line[i] + ((a + b) >> 1)) & 255
                else:
                    pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                    pr = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
                    cur[i] = (line[i] + pr) & 255
        out[y] = cur
        prev = cur
    img = out.reshape(h, w, ch)
    if ch in (1, 2):
        img = np.repeat(img[:, :, :1], 3, axis=2)
    return img[:, :, :3]


def encode_png(img: np.ndarray) -> bytes:
    """Minimal PNG encoder (RGB or greyscale uint8) — for storing frames and tests."""
    if img.ndim == 2:
        img = np.repeat(img[:, :, None], 3, axis=2)
    h, w, _ = img.shape
    raw = b"".join(b"\x00" + img[y].astype(np.uint8).tobytes() for y in range(h))

    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def image_from_payload(payload: dict) -> np.ndarray:
    """{format: rgb8|png, width, height, data: base64}. Browsers decode JPEG/HEIC with a canvas and send rgb8."""
    data = base64.b64decode(payload["data"])
    fmt = payload.get("format", "png")
    if fmt == "png":
        return decode_png(data)
    if fmt in ("rgb8", "rgba8"):
        ch = 3 if fmt == "rgb8" else 4
        w, h = int(payload["width"]), int(payload["height"])
        if len(data) != w * h * ch:
            raise ValueError(f"expected {w * h * ch} bytes for {w}x{h} {fmt}, got {len(data)}")
        return np.frombuffer(data, np.uint8).reshape(h, w, ch)[:, :, :3].copy()
    raise ValueError(f"unsupported image format {fmt}")


# --------------------------------------------------------------------------- primitives


def box_blur(a: np.ndarray, r: int) -> np.ndarray:
    """Mean filter of radius r using an integral image (edges replicated)."""
    p = np.pad(a.astype(float), r + 1, mode="edge")
    s = p.cumsum(0).cumsum(1)
    k = 2 * r + 1
    h, w = a.shape
    tot = s[k:k + h, k:k + w] - s[0:h, k:k + w] - s[k:k + h, 0:w] + s[0:h, 0:w]
    return tot / (k * k)


def label_components(mask: np.ndarray, max_pixels: int = 60_000) -> list[np.ndarray]:
    """4-connected components; returns a list of (N,2) arrays of (row, col)."""
    ys, xs = np.nonzero(mask)
    if len(ys) > max_pixels:
        raise ValueError("foreground too large for component labelling — threshold too low")
    remaining = set(zip(ys.tolist(), xs.tolist()))
    comps = []
    while remaining:
        seed = remaining.pop()
        stack, comp = [seed], [seed]
        while stack:
            y, x = stack.pop()
            for nb in ((y + 1, x), (y - 1, x), (y, x + 1), (y, x - 1)):
                if nb in remaining:
                    remaining.remove(nb)
                    stack.append(nb)
                    comp.append(nb)
        comps.append(np.array(comp))
    return comps


def dilate(mask: np.ndarray, it: int = 1) -> np.ndarray:
    m = mask.copy()
    for _ in range(it):
        n = m.copy()
        n[1:] |= m[:-1]
        n[:-1] |= m[1:]
        n[:, 1:] |= m[:, :-1]
        n[:, :-1] |= m[:, 1:]
        m = n
    return m


@dataclass
class Detection:
    label: str
    confidence: float
    bbox: list  # x, y, w, h (pixels)
    cx: float
    cy: float
    area_px: int
    species_group: str = ""
    size_m: float | None = None
    extra: dict = field(default_factory=dict)
    lat: float | None = None
    lon: float | None = None

    def to_dict(self):
        return asdict(self)


def _shape(comp: np.ndarray):
    ys, xs = comp[:, 0].astype(float), comp[:, 1].astype(float)
    cy, cx = ys.mean(), xs.mean()
    if len(comp) >= 3:
        cov = np.cov(np.vstack([xs, ys]))
        ev = np.sort(np.linalg.eigvalsh(cov))[::-1]
        length = 4 * math.sqrt(max(ev[0], 1e-6))
        width = 4 * math.sqrt(max(ev[1], 1e-6))
    else:
        length = width = 1.0
    bbox = [int(xs.min()), int(ys.min()), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)]
    return cx, cy, length, width, bbox


# --------------------------------------------------------------------------- detectors


class Detector:
    id = "base"
    name = ""
    task = "detection"
    domain = "shared"
    backend = "numpy"
    version = "1.0"
    description = ""

    def available(self) -> tuple[bool, str]:
        return True, "ok"

    def detect(self, img: np.ndarray, gsd_m: float | None = None) -> list[Detection]:
        raise NotImplementedError


class ThermalBlobDetector(Detector):
    id = "thermal-blob-v1"
    name = "Thermal warm-body detector"
    domain = "livestock"
    description = ("Background-subtracted thermal frame, robust threshold (median + k·MAD), 4-connected components, "
                   "size filter in square metres. Counts warm bodies; does not identify species or individuals.")

    def __init__(self, k: float = 5.0, min_area_m2: float = 0.25, max_area_m2: float = 8.0, bg_radius: int = 12):
        self.k, self.min_a, self.max_a, self.bg_r = k, min_area_m2, max_area_m2, bg_radius

    def detect(self, img, gsd_m=None):
        t = img.astype(float) if img.ndim == 2 else img.astype(float).mean(axis=2)
        # two-pass background: replace strong outliers before smoothing so bodies do not leave a halo
        bg0 = box_blur(t, self.bg_r)
        r0 = t - bg0
        mad0 = float(np.median(np.abs(r0 - np.median(r0)))) * 1.4826 + 1e-6
        clean = np.where(np.abs(r0) > 3 * mad0, bg0, t)
        resid = t - box_blur(clean, self.bg_r)
        med = float(np.median(resid))
        mad = float(np.median(np.abs(resid - med))) * 1.4826 + 1e-6
        # either polarity: animals are warmer than the ground at night / dawn, often cooler than sun-heated ground at noon
        mask = np.abs(resid - med) > self.k * mad
        resid = np.abs(resid - med)
        gsd = gsd_m or 0.3
        out = []
        for comp in label_components(mask):
            a_m2 = len(comp) * gsd * gsd
            if not (self.min_a <= a_m2 <= self.max_a):
                continue
            cx, cy, length, width, bbox = _shape(comp)
            contrast = float(resid[comp[:, 0], comp[:, 1]].mean() / (self.k * mad))
            conf = float(np.clip(0.35 + 0.25 * math.log1p(contrast) + 0.15 * min(a_m2 / 2.0, 1), 0.05, 0.95))
            out.append(Detection("warm_body", round(conf, 3), bbox, cx, cy, len(comp), "livestock",
                                 round(length * gsd, 2), {"area_m2": round(a_m2, 2), "contrast": round(contrast, 2)}))
        return out


# size classes for coarse grouping (length in metres); hints only
SIZE_HINTS = [(0.4, 1.6, "sea_turtle"), (1.6, 3.2, "dolphin_or_dugong"), (3.2, 7.0, "large_animal"), (7.0, 30.0, "whale")]


class SeaSurfaceAnomalyDetector(Detector):
    id = "sea-anomaly-v1"
    name = "Sea-surface anomaly detector"
    domain = "marine"
    description = ("Robust per-image water colour model (median, MAD per channel), normalised colour distance, "
                   "dilation, connected components, size/elongation filter. Produces candidate objects with a coarse "
                   "size class for human review. Trained species classifiers plug in as 'onnx-yolo'.")

    def __init__(self, k: float = 6.0, min_len_m: float = 0.4, max_len_m: float = 30.0):
        self.k, self.min_len, self.max_len = k, min_len_m, max_len_m

    def detect(self, img, gsd_m=None):
        x = img.astype(float)
        med = np.median(x.reshape(-1, 3), axis=0)
        mad = np.median(np.abs(x.reshape(-1, 3) - med), axis=0) * 1.4826 + 1.0
        d = np.sqrt((((x - med) / mad) ** 2).sum(axis=2) / 3)
        # sun glint is bright in every channel; animals are darker / differently coloured than water
        lum = x.mean(axis=2)
        glint = lum > np.percentile(lum, 99.5) + 2 * mad.mean()
        mask = (d > self.k) & ~glint
        mask = dilate(mask, 1)
        gsd = gsd_m or 0.3
        out = []
        for comp in label_components(mask):
            cx, cy, length, width, bbox = _shape(comp)
            Lm = length * gsd
            if not (self.min_len <= Lm <= self.max_len) or len(comp) < 4:
                continue
            strength = float(d[comp[:, 0], comp[:, 1]].mean() / self.k)
            group = next((g for lo, hi, g in SIZE_HINTS if lo <= Lm < hi), "unknown")
            conf = float(np.clip(0.25 + 0.2 * math.log1p(strength) + 0.1 * min(len(comp) / 30, 1), 0.05, 0.85))
            out.append(Detection("marine_object", round(conf, 3), bbox, cx, cy, len(comp), group, round(Lm, 2),
                                 {"elongation": round(length / max(width, 1e-6), 2), "strength": round(strength, 2),
                                  "species_hint_basis": "apparent length only"}))
        return out


def nms(boxes: np.ndarray, scores: np.ndarray, iou_th: float = 0.5) -> list[int]:
    """Greedy non-maximum suppression; boxes as x1,y1,x2,y2."""
    order = np.argsort(-scores)
    keep = []
    while len(order):
        i = order[0]
        keep.append(int(i))
        if len(order) == 1:
            break
        r = order[1:]
        xx1 = np.maximum(boxes[i, 0], boxes[r, 0])
        yy1 = np.maximum(boxes[i, 1], boxes[r, 1])
        xx2 = np.minimum(boxes[i, 2], boxes[r, 2])
        yy2 = np.minimum(boxes[i, 3], boxes[r, 3])
        inter = np.clip(xx2 - xx1, 0, None) * np.clip(yy2 - yy1, 0, None)
        a = (boxes[i, 2] - boxes[i, 0]) * (boxes[i, 3] - boxes[i, 1])
        b = (boxes[r, 2] - boxes[r, 0]) * (boxes[r, 3] - boxes[r, 1])
        order = r[inter / (a + b - inter + 1e-9) <= iou_th]
    return keep


def decode_yolo_output(out: np.ndarray, class_names: list[str], conf_th: float, scale: float, pad: tuple,
                       iou_th: float = 0.5) -> list[Detection]:
    """Ultralytics v8/11 export layout: (1, 4 + n_classes, n_anchors) with cx,cy,w,h in input pixels."""
    p = out[0].T  # (anchors, 4+nc)
    scores = p[:, 4:]
    cls = scores.argmax(1)
    conf = scores.max(1)
    sel = conf >= conf_th
    if not sel.any():
        return []
    p, cls, conf = p[sel], cls[sel], conf[sel]
    cx, cy, w, h = (p[:, 0] - pad[0]) / scale, (p[:, 1] - pad[1]) / scale, p[:, 2] / scale, p[:, 3] / scale
    boxes = np.stack([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], 1)
    res = []
    for c in np.unique(cls):
        idx = np.nonzero(cls == c)[0]
        for k in nms(boxes[idx], conf[idx], iou_th):
            j = idx[k]
            x1, y1, x2, y2 = boxes[j]
            res.append(Detection(class_names[int(c)] if int(c) < len(class_names) else f"class_{int(c)}",
                                 round(float(conf[j]), 3), [int(x1), int(y1), int(x2 - x1), int(y2 - y1)],
                                 float(cx[j]), float(cy[j]), int(w[j] * h[j])))
    return res


class OnnxYoloDetector(Detector):
    id = "onnx-yolo"
    name = "YOLO (ONNX Runtime)"
    backend = "onnxruntime"
    description = ("Runs a YOLO-family detector exported to ONNX (e.g. trained on aerial livestock or marine-megafauna "
                   "imagery). Weights are not bundled: place <model>.onnx and <model>.names in AICN_ONNX_MODEL_DIR.")

    def __init__(self, model_dir: str, model_name: str = "aicn-detector", imgsz: int = 640, conf: float = 0.25):
        self.path = os.path.join(model_dir, model_name + ".onnx")
        self.names_path = os.path.join(model_dir, model_name + ".names")
        self.imgsz, self.conf = imgsz, conf
        self._sess = None

    def available(self):
        try:
            import onnxruntime  # noqa: F401
        except Exception:
            return False, "onnxruntime is not installed"
        if not os.path.exists(self.path):
            return False, f"model weights not found at {self.path}"
        return True, "ok"

    def detect(self, img, gsd_m=None):
        ok, why = self.available()
        if not ok:
            from ..errors import NotConfigured

            raise NotConfigured(f"ONNX detector unavailable: {why}")
        import onnxruntime as ort

        if self._sess is None:
            self._sess = ort.InferenceSession(self.path, providers=["CPUExecutionProvider"])
            self.names = open(self.names_path).read().split("\n") if os.path.exists(self.names_path) else []
        h, w = img.shape[:2]
        s = self.imgsz / max(h, w)
        nh, nw = int(round(h * s)), int(round(w * s))
        ys = (np.arange(nh) / s).astype(int).clip(0, h - 1)
        xs = (np.arange(nw) / s).astype(int).clip(0, w - 1)
        canvas = np.full((self.imgsz, self.imgsz, 3), 114, np.uint8)
        px, py = (self.imgsz - nw) // 2, (self.imgsz - nh) // 2
        canvas[py:py + nh, px:px + nw] = img[ys][:, xs]
        x = canvas.astype(np.float32).transpose(2, 0, 1)[None] / 255.0
        out = self._sess.run(None, {self._sess.get_inputs()[0].name: x})[0]
        return decode_yolo_output(out, self.names, self.conf, s, (px, py))


# --------------------------------------------------------------------------- geometry


@dataclass
class Camera:
    hfov_deg: float
    width_px: int
    height_px: int

    def gsd(self, altitude_m: float) -> float:
        return 2 * altitude_m * math.tan(math.radians(self.hfov_deg) / 2) / self.width_px

    def footprint_m(self, altitude_m: float) -> tuple[float, float]:
        g = self.gsd(altitude_m)
        return g * self.width_px, g * self.height_px


def georeference(det: Detection, cam: Camera, lat: float, lon: float, alt_m: float, yaw_deg: float) -> tuple[float, float]:
    """Nadir camera: pixel offset -> body frame -> ENU (yaw clockwise from north) -> lat/lon."""
    g = cam.gsd(alt_m)
    right = (det.cx - cam.width_px / 2) * g
    fwd = (cam.height_px / 2 - det.cy) * g
    y = math.radians(yaw_deg)
    e = fwd * math.sin(y) + right * math.cos(y)
    n = fwd * math.cos(y) - right * math.sin(y)
    la, lo = LocalFrame(lat, lon).to_latlon(e, n)
    return float(la), float(lo)


def registry(model_dir: str = "./models") -> dict[str, Detector]:
    return {d.id: d for d in (ThermalBlobDetector(), SeaSurfaceAnomalyDetector(), OnnxYoloDetector(model_dir))}
