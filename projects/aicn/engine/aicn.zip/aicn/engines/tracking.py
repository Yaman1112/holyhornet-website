"""Animal Tracking AI: multi-object tracking of georeferenced detections across video frames.

Constant-velocity Kalman filter per track in local metres, chi-square gating, optimal assignment
(Hungarian algorithm), track confirmation after `min_hits` and deletion after `max_misses`.
Counting uses confirmed tracks so an animal seen in many overlapping frames is counted once.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


def hungarian(cost: np.ndarray) -> list[tuple[int, int]]:
    """Minimum-cost assignment for a rectangular matrix (Kuhn–Munkres, O(n^3))."""
    cost = np.asarray(cost, float)
    n_r, n_c = cost.shape
    n = max(n_r, n_c)
    big = (np.nanmax(cost[np.isfinite(cost)]) if np.isfinite(cost).any() else 0) + 1e6
    C = np.full((n, n), big)
    C[:n_r, :n_c] = np.where(np.isfinite(cost), cost, big)
    u = np.zeros(n + 1)
    v = np.zeros(n + 1)
    p = np.zeros(n + 1, int)
    way = np.zeros(n + 1, int)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = np.full(n + 1, np.inf)
        used = np.zeros(n + 1, bool)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta, j1 = np.inf, 0
            for j in range(1, n + 1):
                if not used[j]:
                    cur = C[i0 - 1, j - 1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j] = cur
                        way[j] = j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    res = []
    for j in range(1, n + 1):
        i = p[j] - 1
        if i < n_r and j - 1 < n_c and C[i, j - 1] < big:
            res.append((int(i), int(j - 1)))
    return res


@dataclass
class KTrack:
    id: str
    x: np.ndarray  # e, n, ve, vn
    P: np.ndarray
    label: str
    hits: int = 1
    misses: int = 0
    confirmed: bool = False
    history: list = field(default_factory=list)  # (t, e, n, conf)
    labels: dict = field(default_factory=dict)


class MultiObjectTracker:
    def __init__(self, meas_sigma_m=1.5, accel_sigma=0.6, gate_chi2=9.21, min_hits=2, max_misses=3, prefix="T"):
        self.r, self.q, self.gate = meas_sigma_m, accel_sigma, gate_chi2
        self.min_hits, self.max_misses = min_hits, max_misses
        self.tracks: list[KTrack] = []
        self.finished: list[KTrack] = []
        self._n = 0
        self.prefix = prefix
        self.t = None

    def _predict(self, dt):
        F = np.eye(4)
        F[0, 2] = F[1, 3] = dt
        G = np.array([[dt * dt / 2, 0], [0, dt * dt / 2], [dt, 0], [0, dt]])
        Q = G @ G.T * self.q ** 2
        for tr in self.tracks:
            tr.x = F @ tr.x
            tr.P = F @ tr.P @ F.T + Q

    def update(self, t: float, meas: list[tuple[float, float, str, float]], in_view=None) -> list[tuple[int, str]]:
        """meas: [(east, north, label, confidence)]. in_view(e, n) -> bool limits miss counting to the camera footprint.
        Returns [(measurement_index, track_id)]."""
        dt = 0.0 if self.t is None else max(t - self.t, 1e-3)
        self.t = t
        if dt:
            self._predict(dt)
        H = np.zeros((2, 4))
        H[0, 0] = H[1, 1] = 1
        R = np.eye(2) * self.r ** 2
        Z = np.array([[m[0], m[1]] for m in meas], float).reshape(-1, 2)
        cost = np.full((len(self.tracks), len(meas)), np.inf)
        for i, tr in enumerate(self.tracks):
            S = H @ tr.P @ H.T + R
            Si = np.linalg.inv(S)
            for j in range(len(meas)):
                y = Z[j] - H @ tr.x
                d2 = float(y @ Si @ y)
                if d2 <= self.gate:
                    cost[i, j] = d2 + np.log(np.linalg.det(S))
        pairs = hungarian(cost) if cost.size else []
        assigned_t, assigned_m = set(), set()
        out = []
        for i, j in pairs:
            if not np.isfinite(cost[i, j]):
                continue
            tr = self.tracks[i]
            S = H @ tr.P @ H.T + R
            K = tr.P @ H.T @ np.linalg.inv(S)
            tr.x = tr.x + K @ (Z[j] - H @ tr.x)
            tr.P = (np.eye(4) - K @ H) @ tr.P
            tr.hits += 1
            tr.misses = 0
            tr.confirmed = tr.confirmed or tr.hits >= self.min_hits
            tr.history.append((t, float(tr.x[0]), float(tr.x[1]), meas[j][3]))
            tr.labels[meas[j][2]] = tr.labels.get(meas[j][2], 0) + meas[j][3]
            assigned_t.add(i)
            assigned_m.add(j)
            out.append((j, tr.id))
        keep = []
        for i, tr in enumerate(self.tracks):
            if i not in assigned_t:
                if in_view is None or in_view(tr.x[0], tr.x[1]):
                    tr.misses += 1
            if tr.misses > self.max_misses:
                self.finished.append(tr)
            else:
                keep.append(tr)
        self.tracks = keep
        for j, m in enumerate(meas):
            if j in assigned_m:
                continue
            self._n += 1
            tr = KTrack(f"{self.prefix}{self._n}", np.array([m[0], m[1], 0, 0], float),
                        np.diag([self.r ** 2, self.r ** 2, 4.0, 4.0]), m[2], history=[(t, m[0], m[1], m[3])],
                        labels={m[2]: m[3]})
            tr.confirmed = self.min_hits <= 1
            self.tracks.append(tr)
            out.append((j, tr.id))
        return out

    def all_tracks(self) -> list[KTrack]:
        return self.finished + self.tracks

    def confirmed_tracks(self) -> list[KTrack]:
        return [t for t in self.all_tracks() if t.confirmed]

    @staticmethod
    def majority_label(tr: KTrack) -> str:
        return max(tr.labels.items(), key=lambda kv: kv[1])[0] if tr.labels else tr.label
