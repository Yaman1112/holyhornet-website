"""Pure-numpy intelligence engines. No database or web dependencies: each can be tested and replaced on its own."""
