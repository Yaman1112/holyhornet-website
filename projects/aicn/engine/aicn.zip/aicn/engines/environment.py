"""Environmental Intelligence: vegetation, water and drought estimates.

Everything returned here is an ESTIMATE derived from indirect measurements (satellite / multispectral
NDVI, level sensors, rainfall). Each result carries `is_estimate=True` and the basis of the estimate.
"""

from __future__ import annotations

import numpy as np


def ndvi(red: np.ndarray, nir: np.ndarray) -> np.ndarray:
    red = red.astype(float)
    nir = nir.astype(float)
    den = nir + red
    out = np.where(den > 0, (nir - red) / np.where(den == 0, 1, den), np.nan)
    return np.clip(out, -1, 1)


# Simple linear NDVI→green biomass relation of the kind fitted for East African rangelands.
# Coefficients are placeholders to be calibrated with clipped-plot field samples before use.
BIOMASS_A, BIOMASS_B = 4200.0, -350.0  # kg DM/ha per NDVI unit, intercept


def biomass_estimate(ndvi_mean: float) -> dict:
    est = max(0.0, BIOMASS_A * ndvi_mean + BIOMASS_B)
    return {"biomass_kg_ha": round(est), "uncertainty_kg_ha": round(0.35 * est + 150),
            "is_estimate": True, "basis": "linear NDVI model, uncalibrated placeholder coefficients"}


def drought_indicator(ndvi_series: list[float], seasonal_ref: list[float], rain_mm_30d: float | None,
                      rain_ref_mm_30d: float | None) -> dict:
    """NDVI anomaly vs a seasonal reference combined with a 30-day rainfall deficit."""
    if not ndvi_series:
        return {"level": "unknown", "is_estimate": True, "basis": "no vegetation observations"}
    cur = float(np.mean(ndvi_series[-3:]))
    ref = float(np.mean(seasonal_ref)) if seasonal_ref else cur
    vci = cur / ref if ref > 0 else 1.0  # vegetation condition relative to the reference
    rain_ratio = (rain_mm_30d / rain_ref_mm_30d) if (rain_mm_30d is not None and rain_ref_mm_30d) else None
    score = (1 - vci) * 2 + ((1 - rain_ratio) if rain_ratio is not None else 0)
    level = "none"
    if score > 0.3:
        level = "watch"
    if score > 0.6:
        level = "warning"
    if score > 1.0:
        level = "alert"
    return {"level": level, "vegetation_condition_ratio": round(vci, 2),
            "rainfall_ratio": None if rain_ratio is None else round(rain_ratio, 2),
            "score": round(score, 2), "is_estimate": True,
            "basis": "NDVI vs seasonal reference" + (" and 30-day rainfall vs normal" if rain_ratio is not None else "")}


def water_forecast(times_s: list[float], levels_pct: list[float], empty_pct: float = 10.0, min_span_h: float = 12.0) -> dict:
    """Linear trend on recent level readings -> days until the empty threshold, with a 90% interval."""
    t = np.asarray(times_s, float)
    y = np.asarray(levels_pct, float)
    if len(t) < 4 or np.ptp(t) < min_span_h * 3600:
        return {"trend_pct_per_day": None, "days_to_empty": None, "is_estimate": True, "basis": "too few readings"}
    td = (t - t[0]) / 86400
    A = np.vstack([td, np.ones_like(td)]).T
    coef, res, *_ = np.linalg.lstsq(A, y, rcond=None)
    slope, icpt = float(coef[0]), float(coef[1])
    resid = y - A @ coef
    s = float(np.sqrt(np.sum(resid ** 2) / max(len(y) - 2, 1)))
    se_slope = s / max(float(np.sqrt(np.sum((td - td.mean()) ** 2))), 1e-9)
    cur = float(y[-1])
    out = {"current_pct": round(cur, 1), "trend_pct_per_day": round(slope, 2), "is_estimate": True,
           "basis": f"linear trend over {len(y)} readings ({np.ptp(td):.1f} days)"}
    if slope < -0.05:
        days = (cur - empty_pct) / -slope
        lo_s, hi_s = slope - 1.645 * se_slope, min(slope + 1.645 * se_slope, -1e-3)
        out["days_to_empty"] = round(max(days, 0), 1)
        out["days_to_empty_90"] = [round(max((cur - empty_pct) / -lo_s, 0), 1), round(max((cur - empty_pct) / -hi_s, 0), 1)]
    else:
        out["days_to_empty"] = None
    return out


def grazing_recommendations(areas: list[dict], min_biomass: float = 900.0, rest_days: int = 21) -> list[dict]:
    """areas: [{id, name, biomass_kg_ha, days_since_grazed, in_use}] -> ranked recommendations (estimates)."""
    recs = []
    ranked = sorted(areas, key=lambda a: -(a.get("biomass_kg_ha") or 0))
    best = next((a for a in ranked if not a.get("in_use") and (a.get("biomass_kg_ha") or 0) >= min_biomass
                 and (a.get("days_since_grazed") or 999) >= rest_days), None)
    for a in areas:
        b = a.get("biomass_kg_ha")
        if a.get("in_use") and b is not None and b < min_biomass:
            recs.append({"area_id": a["id"], "action": "move_herd",
                         "text": f"{a['name']}: estimated forage {b:.0f} kg/ha is below {min_biomass:.0f} kg/ha."
                                 + (f" Consider moving to {best['name']} (est. {best['biomass_kg_ha']:.0f} kg/ha, rested "
                                    f"{best.get('days_since_grazed', '?')} days)." if best else " No rested area currently meets the target."),
                         "is_estimate": True})
        elif a.get("in_use") is False and (a.get("days_since_grazed") or 0) < rest_days:
            recs.append({"area_id": a["id"], "action": "rest",
                         "text": f"{a['name']}: rested {a.get('days_since_grazed', 0)} of {rest_days} recommended days.",
                         "is_estimate": True})
        elif b is not None and b < 0.6 * min_biomass:
            recs.append({"area_id": a["id"], "action": "inspect",
                         "text": f"{a['name']}: very low estimated forage ({b:.0f} kg/ha) — inspect for overgrazing or drought.",
                         "is_estimate": True})
    return recs
