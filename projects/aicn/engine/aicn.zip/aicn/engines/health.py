"""Health Observation engine.

Turns collar signals into a *risk observation* on four levels:
  normal  ·  unusual  ·  concern  ·  urgent  (urgent = "veterinary assessment recommended")

Each indicator compares recent data with the animal's own baseline. The result always carries the
supporting observations, a confidence (how sure we are the signal is real) and an uncertainty band
on the score (bootstrap over the recent samples). It is never a diagnosis: collar skin temperature
is not core body temperature, and low activity has many harmless causes.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

import numpy as np

LEVELS = ["normal", "unusual", "concern", "urgent"]
DISCLAIMER = ("Automated observation from collar sensors, not a veterinary diagnosis. "
              "A person should check the animal; a veterinary professional decides on any treatment.")


@dataclass
class Indicator:
    name: str
    value: float
    baseline: float | None
    deviation: float  # standardised, positive = more worrying
    weight: float
    text: str


@dataclass
class HealthAssessment:
    level: str
    score: float  # 0..100
    confidence: float  # 0..1
    uncertainty: float  # +/- score points (90% band half-width)
    data_coverage: float  # share of expected samples present
    supporting: list = field(default_factory=list)
    summary: str = ""
    disclaimer: str = DISCLAIMER

    def to_dict(self):
        return asdict(self)


@dataclass
class HealthInputs:
    activity: np.ndarray  # recent window
    rest_fraction: np.ndarray
    temp_c: np.ndarray
    ambient_c: np.ndarray
    water_visits: int | None
    expected_samples: int
    separated: bool = False
    baseline: dict = field(default_factory=dict)
    hours: np.ndarray | None = None  # local hour of each sample (for time-of-day baselines)


def _z(x, mean, sd, floor):
    return (x - mean) / max(sd or 0.0, floor)


def _indicators(inp: HealthInputs, idx=None) -> list[Indicator]:
    b = inp.baseline
    pick = (lambda a: a[idx]) if idx is not None else (lambda a: a)
    ind: list[Indicator] = []
    hrs = pick(inp.hours) if inp.hours is not None else None

    def expected(key_hour, key_mean, values):
        prof = b.get(key_hour)
        ok = np.isfinite(values)
        if prof and hrs is not None:
            ex = np.array([np.nan if prof[int(h)] is None else prof[int(h)] for h in hrs], float)
            ok2 = ok & np.isfinite(ex)
            if ok2.sum() >= 4:
                return float(np.mean(values[ok2])), float(np.mean(ex[ok2]))
        if ok.sum() >= 4 and b.get(key_mean) is not None:
            return float(np.mean(values[ok])), float(b[key_mean])
        return None, None

    m, ref = expected("activity_by_hour", "activity_mean", pick(inp.activity))
    if m is not None and ref:
        sd = b.get("activity_sd_rel", 0.25) * ref
        z = -_z(m, ref, sd, 0.12 * ref)
        ind.append(Indicator("activity", m, ref, z, 1.0, f"activity {m / ref * 100:.0f}% of usual for these hours"))
    m, ref = expected("rest_by_hour", "rest_mean", pick(inp.rest_fraction))
    if m is not None and ref is not None:
        z = _z(m, ref, b.get("rest_sd_hourly", 0.08), 0.06)
        ind.append(Indicator("resting", m, ref, z, 0.7,
                             f"lying/resting {m * 100:.0f}% of the time (usual {ref * 100:.0f}% at these hours)"))
    tc = pick(inp.temp_c)
    amb = pick(inp.ambient_c)
    ok = np.isfinite(tc) & np.isfinite(amb)
    if ok.sum() >= 4 and b.get("temp_offset_mean") is not None:
        # skin temperature tracks ambient; the animal-specific signal is the offset from ambient
        off = float(np.mean(tc[ok] - b.get("temp_ambient_slope", 0.35) * amb[ok]))
        z = _z(off, b["temp_offset_mean"], b.get("temp_offset_sd"), 0.25)
        ind.append(Indicator("collar_temperature", off, b["temp_offset_mean"], z, 0.8,
                             f"collar temperature {off - b['temp_offset_mean']:+.1f} °C vs usual (ambient-corrected)"))
    if inp.water_visits is not None and b.get("water_visits_per_window"):
        wv = inp.water_visits
        z = -_z(wv, b["water_visits_per_window"], b.get("water_visits_sd"), 1.0)
        ind.append(Indicator("water_visits", wv, b["water_visits_per_window"], z, 0.6,
                             f"{wv} water-point visits (usual {b['water_visits_per_window']:.1f})"))
    if inp.separated:
        ind.append(Indicator("separated_from_herd", 1.0, 0.0, 2.0, 0.5, "separated from the herd"))
    return ind


def _score(ind: list[Indicator]) -> float:
    if not ind:
        return 0.0
    # only deviations in the worrying direction count; beyond 1 sd, saturating
    contrib = sum(i.weight * float(np.clip(i.deviation - 1.0, 0, 4)) for i in ind)
    norm = sum(i.weight for i in ind) * 4
    raw = contrib / norm
    strong = sum(1 for i in ind if i.deviation >= 3)
    # corroboration: several independent strong indicators are far more telling than one
    raw = raw * (0.6 + 0.4 * min(strong, 3) / 3) if strong else raw * 0.6
    return float(np.clip(100 * (1 - np.exp(-3 * raw)), 0, 100))


def assess(inp: HealthInputs, rng: np.random.Generator | None = None, n_boot: int = 60) -> HealthAssessment:
    rng = rng or np.random.default_rng(0)
    n = len(inp.activity)
    coverage = float(min(1.0, n / max(inp.expected_samples, 1)))
    ind = _indicators(inp)
    if not ind or n < 4:
        return HealthAssessment("normal", 0.0, 0.1, 50.0, coverage, [],
                                "Not enough recent sensor data or no learned baseline yet — no assessment possible.")
    score = _score(ind)
    boots = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        boots.append(_score(_indicators(inp, idx)))
    lo, hi = np.percentile(boots, [5, 95])
    uncertainty = float((hi - lo) / 2)
    strong = [i for i in ind if i.deviation >= 3]
    level = "normal"
    if score >= 20:
        level = "unusual"
    if score >= 40 and len(strong) >= 1:
        level = "concern"
    if score >= 60 and len(strong) >= 2:
        level = "urgent"  # needs two independent strong indicators; one sensor alone never escalates to urgent
    confidence = float(np.clip(coverage * (1 - uncertainty / 60) * (0.5 + 0.5 * min(len(ind), 4) / 4), 0.05, 0.95))
    supporting = [{"indicator": i.name, "value": round(i.value, 3), "baseline": None if i.baseline is None else round(i.baseline, 3),
                   "deviation_sd": round(i.deviation, 2), "observation": i.text} for i in sorted(ind, key=lambda i: -i.deviation)]
    worrying = [i.text for i in ind if i.deviation >= 1.5]
    if level == "normal":
        summary = "Sensor readings are within this animal's usual range."
    else:
        head = {"unusual": "Unusual behaviour", "concern": "Potential health concern",
                "urgent": "Urgent veterinary assessment recommended"}[level]
        summary = f"{head}: " + "; ".join(worrying or [ind[0].text]) + "."
    if coverage < 0.6:
        summary += f" Only {coverage * 100:.0f}% of expected readings arrived, so treat this with caution."
    return HealthAssessment(level, round(score, 1), round(confidence, 2), round(uncertainty, 1), round(coverage, 2),
                            supporting, summary)


def learn_health_baseline(activity, rest, temp, ambient, water_visits_per_window: list[int] | None = None,
                          ambient_slope: float = 0.35, hours=None) -> dict:
    act = np.asarray(activity, float)
    rest = np.asarray(rest, float)
    temp = np.asarray(temp, float)
    amb = np.asarray(ambient, float)
    ok = np.isfinite(temp) & np.isfinite(amb)
    off = temp[ok] - ambient_slope * amb[ok]
    b = {
        "activity_mean": float(np.nanmean(act)) if np.isfinite(act).any() else None,
        "activity_sd": float(np.nanstd(act)) if np.isfinite(act).any() else None,
        "rest_mean": float(np.nanmean(rest)) if np.isfinite(rest).any() else None,
        "rest_sd": float(np.nanstd(rest)) if np.isfinite(rest).any() else None,
        "temp_offset_mean": float(np.mean(off)) if len(off) else None,
        "temp_offset_sd": float(np.std(off)) if len(off) else None,
        "temp_ambient_slope": ambient_slope,
    }
    if hours is not None:
        hrs = np.asarray(hours, int)
        rb, rel, rsd = [], [], []
        for h in range(24):
            m = (hrs == h) & np.isfinite(rest)
            rb.append(round(float(np.mean(rest[m])), 3) if m.sum() >= 2 else None)
            if m.sum() >= 2:
                rsd.append(float(np.std(rest[m])))
            ma = (hrs == h) & np.isfinite(act)
            if ma.sum() >= 2 and np.mean(act[ma]) > 0:
                rel.append(float(np.std(act[ma]) / np.mean(act[ma])))
        b["rest_by_hour"] = rb
        # per-sample variability within an hour bin; a 6-h mean of ~24 samples varies about 1/sqrt(24) as much
        b["activity_sd_rel"] = max(float(np.median(rel)) / 4, 0.06) if rel else 0.1
        b["rest_sd_hourly"] = max(float(np.median(rsd)) / 4, 0.03) if rsd else 0.05
    if water_visits_per_window:
        b["water_visits_per_window"] = float(np.mean(water_visits_per_window))
        b["water_visits_sd"] = float(np.std(water_visits_per_window))
    return b
