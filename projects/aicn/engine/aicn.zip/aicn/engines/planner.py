"""Mission Intelligence: coverage planning and pre-flight / pre-dive checks.

Plans are generated only from an approved user request (a mission record); execution additionally
needs operator approval. Checks return pass / warn / fail with an explanation. Any `fail` blocks
approval. Regulatory numbers are configuration (OperatingRestriction rows), never hard-coded truths.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..geo import LocalFrame, polygon_rings
from .vision import Camera


@dataclass
class UAVSpec:
    cruise_speed_mps: float = 12.0
    battery_wh: float = 270.0
    cruise_power_w: float = 380.0
    hover_power_w: float = 420.0
    max_wind_mps: float = 10.0
    max_alt_m: float = 120.0
    rgb_hfov_deg: float = 70.0
    thermal_hfov_deg: float = 45.0
    image_w: int = 256  # processing resolution (frames are downsampled on board before inference)
    image_h: int = 192
    rain_tolerant: bool = False
    endurance_reserve: float = 0.25

    @classmethod
    def from_specs(cls, d: dict | None):
        s = cls()
        for k, v in (d or {}).items():
            if hasattr(s, k):
                setattr(s, k, type(getattr(s, k))(v))
        return s


@dataclass
class ROVSpec:
    depth_rating_m: float = 100.0
    tether_m: float = 150.0
    max_current_mps: float = 0.8
    speed_mps: float = 0.5
    battery_wh: float = 266.0
    power_w: float = 180.0

    @classmethod
    def from_specs(cls, d: dict | None):
        s = cls()
        for k, v in (d or {}).items():
            if hasattr(s, k):
                setattr(s, k, type(getattr(s, k))(v))
        return s


def _ring_en(frame: LocalFrame, ring) -> np.ndarray:
    e, n = frame.to_en(np.array([p[1] for p in ring]), np.array([p[0] for p in ring]))
    return np.stack([e, n], 1)


def _principal_angle(pts: np.ndarray) -> float:
    c = pts - pts.mean(0)
    ev, evec = np.linalg.eigh(np.cov(c.T))
    v = evec[:, int(np.argmax(ev))]
    return math.atan2(v[1], v[0])


def _scan_intervals(poly: np.ndarray, y: float) -> list[tuple[float, float]]:
    xs = []
    for (x1, y1), (x2, y2) in zip(poly[:-1], poly[1:]):
        if (y1 <= y < y2) or (y2 <= y < y1):
            xs.append(x1 + (y - y1) * (x2 - x1) / (y2 - y1))
    xs.sort()
    return [(xs[i], xs[i + 1]) for i in range(0, len(xs) - 1, 2)]


def _subtract(iv: list[tuple[float, float]], cut: list[tuple[float, float]]) -> list[tuple[float, float]]:
    out = iv
    for c0, c1 in cut:
        nxt = []
        for a, b in out:
            if c1 <= a or c0 >= b:
                nxt.append((a, b))
                continue
            if c0 > a:
                nxt.append((a, c0))
            if c1 < b:
                nxt.append((c1, b))
        out = nxt
    return [(a, b) for a, b in out if b - a > 1.0]


def _buffer_convex(pts: np.ndarray, d: float) -> np.ndarray:
    c = pts[:-1].mean(0)
    v = pts - c
    r = np.hypot(v[:, 0], v[:, 1])[:, None]
    return c + v * (r + d) / np.maximum(r, 1e-6)


def coverage_plan(area_geom: dict, altitude_m: float, hfov_deg: float, image_w: int, image_h: int,
                  sidelap: float = 0.3, no_fly: list[dict] | None = None, buffer_m: float = 30.0,
                  home: tuple[float, float] | None = None) -> dict:
    """Boustrophedon lanes along the area's long axis, spacing from the camera footprint,
    with no-fly zones (buffered) removed from lanes and detours around them on transits."""
    ring = polygon_rings(area_geom)[0]
    lat0 = float(np.mean([p[1] for p in ring]))
    lon0 = float(np.mean([p[0] for p in ring]))
    frame = LocalFrame(lat0, lon0)
    poly = _ring_en(frame, ring)
    ang = _principal_angle(poly[:-1])
    c, s = math.cos(-ang), math.sin(-ang)
    rot = lambda P: np.stack([P[:, 0] * c - P[:, 1] * s, P[:, 0] * s + P[:, 1] * c], 1)  # noqa: E731
    unrot = lambda P: np.stack([P[:, 0] * c + P[:, 1] * s, -P[:, 0] * s + P[:, 1] * c], 1)  # noqa: E731
    rp = rot(poly)
    cam = Camera(hfov_deg, image_w, image_h)
    fw, _ = cam.footprint_m(altitude_m)
    spacing = max(fw * (1 - sidelap), 5.0)
    zones = []
    for z in no_fly or []:
        for zr in polygon_rings(z):
            zones.append(rot(_buffer_convex(_ring_en(frame, zr), buffer_m)))
    ys = np.arange(rp[:, 1].min() + spacing / 2, rp[:, 1].max(), spacing)
    lanes = []
    for k, y in enumerate(ys):
        ivs = _scan_intervals(rp, y)
        cuts = [iv for zp in zones for iv in _scan_intervals(zp, y)]
        ivs = _subtract(ivs, cuts)
        if k % 2:
            ivs = [(b, a) for a, b in reversed(ivs)]
        for a, b in ivs:
            lanes.append(np.array([[a, y], [b, y]]))
    if not lanes:
        return {"waypoints": [], "lanes": 0, "length_m": 0.0, "spacing_m": spacing, "detours": 0}
    path = [lanes[0][0], lanes[0][1]]
    detours = 0
    for ln in lanes[1:]:
        for zp in zones:
            if _segment_hits(path[-1], ln[0], zp):
                det = _detour(path[-1], ln[0], zp)
                path.extend(det)
                detours += 1
        path.extend([ln[0], ln[1]])
    P = unrot(np.array(path))
    la, lo = frame.to_latlon(P[:, 0], P[:, 1])
    wps = [[round(float(a), 7), round(float(b), 7)] for a, b in zip(la, lo)]
    length = float(np.sum(np.hypot(*np.diff(P, axis=0).T)))
    if home:
        he, hn = frame.to_en(home[0], home[1])
        length += float(np.hypot(P[0, 0] - he, P[0, 1] - hn) + np.hypot(P[-1, 0] - he, P[-1, 1] - hn))
    return {"waypoints": wps, "lanes": len(lanes), "length_m": round(length, 1), "spacing_m": round(spacing, 1),
            "footprint_width_m": round(fw, 1), "gsd_m": round(cam.gsd(altitude_m), 3), "detours": detours,
            "heading_deg": round((90 - math.degrees(ang)) % 180, 1)}


def _segment_hits(p, q, zp: np.ndarray, step=5.0) -> bool:
    d = float(np.hypot(*(q - p)))
    n = max(int(d / step), 2)
    for t in np.linspace(0, 1, n):
        x = p + t * (q - p)
        if _pip(x, zp):
            return True
    return False


def _pip(x, poly) -> bool:
    inside = False
    for (x1, y1), (x2, y2) in zip(poly[:-1], poly[1:]):
        if (y1 > x[1]) != (y2 > x[1]) and x[0] < (x2 - x1) * (x[1] - y1) / ((y2 - y1) or 1e-12) + x1:
            inside = not inside
    return inside


def _detour(p, q, zp: np.ndarray) -> list[np.ndarray]:
    hull = _buffer_convex(zp, 8.0)[:-1]
    i = int(np.argmin(np.hypot(*(hull - p).T)))
    j = int(np.argmin(np.hypot(*(hull - q).T)))
    n = len(hull)
    fwd = [hull[(i + k) % n] for k in range((j - i) % n + 1)]
    bwd = [hull[(i - k) % n] for k in range((i - j) % n + 1)]
    L = lambda pts: sum(np.hypot(*(b - a)) for a, b in zip([p] + pts, pts + [q]))  # noqa: E731
    return list(fwd if L(fwd) <= L(bwd) else bwd)


def path_hits_zone(waypoints: list[list[float]], zone_geom: dict) -> bool:
    if not waypoints:
        return False
    frame = LocalFrame(waypoints[0][0], waypoints[0][1])
    pts = np.array([frame.to_en(a, b) for a, b in waypoints], float)
    for zr in polygon_rings(zone_geom):
        zp = _ring_en(frame, zr)
        for a, b in zip(pts[:-1], pts[1:]):
            if _segment_hits(a, b, zp, step=3.0):
                return True
        if len(pts) == 1 and _pip(pts[0], zp):
            return True
    return False


def uav_energy(length_m: float, spec: UAVSpec, hover_s: float = 0.0) -> dict:
    t = length_m / spec.cruise_speed_mps + hover_s + 60  # +60 s climb/descent
    wh = (spec.cruise_power_w * (length_m / spec.cruise_speed_mps) + spec.hover_power_w * (hover_s + 60)) / 3600
    return {"duration_s": round(t), "energy_wh": round(wh, 1)}


def check(name: str, status: str, detail: str) -> dict:
    return {"check": name, "status": status, "detail": detail}


def uav_preflight(plan: dict, spec: UAVSpec, battery_pct: float | None, altitude_m: float, weather: dict | None,
                  restrictions: list[dict], local_hour: float, device_ok: bool, device_note: str,
                  species_min_alt_m: float | None) -> list[dict]:
    """restrictions: [{kind, name, geometry|None, params, verified}] already filtered to the org."""
    out = [check("device", "pass" if device_ok else "fail", device_note)]
    wps = plan.get("waypoints", [])
    out.append(check("plan", "pass" if wps else "fail",
                     f"{len(wps)} waypoints, {plan.get('length_m', 0):.0f} m" if wps else "no flyable path inside the area"))
    # energy
    e = uav_energy(plan.get("length_m", 0), spec)
    usable = spec.battery_wh * (battery_pct or 0) / 100 * (1 - spec.endurance_reserve)
    if battery_pct is None:
        out.append(check("battery", "fail", "battery state unknown"))
    elif e["energy_wh"] > usable:
        out.append(check("battery", "fail", f"needs ~{e['energy_wh']:.0f} Wh, only {usable:.0f} Wh usable after "
                                             f"{spec.endurance_reserve * 100:.0f}% reserve — split the mission"))
    else:
        out.append(check("battery", "pass", f"needs ~{e['energy_wh']:.0f} Wh of {usable:.0f} Wh usable "
                                             f"({e['duration_s'] / 60:.0f} min)"))
    # weather
    if not weather:
        out.append(check("weather", "fail", "no weather observation available — operator must enter conditions"))
    else:
        w, g = weather.get("wind_mps", 0), weather.get("gust_mps", weather.get("wind_mps", 0))
        rain = weather.get("rain_mm_h", 0)
        vis = weather.get("visibility_km", 10)
        st, notes = "pass", []
        if g > spec.max_wind_mps:
            st = "fail"
            notes.append(f"gusts {g:.0f} m/s exceed {spec.max_wind_mps:.0f} m/s limit")
        elif w > 0.7 * spec.max_wind_mps:
            st = "warn"
            notes.append(f"wind {w:.0f} m/s close to limit")
        if rain > 0.5 and not spec.rain_tolerant:
            st = "fail"
            notes.append(f"rain {rain:.1f} mm/h")
        if vis < 3:
            st = "fail"
            notes.append(f"visibility {vis:.1f} km (VLOS)")
        out.append(check("weather", st, "; ".join(notes) or f"wind {w:.0f} m/s, gust {g:.0f} m/s, no rain"))
    # altitude & welfare
    max_alt = spec.max_alt_m
    for r in restrictions:
        if r["kind"] == "altitude_limit":
            lim = float(r["params"].get("max_alt_m", max_alt))
            max_alt = min(max_alt, lim)
            if not r.get("verified"):
                out.append(check("regulation", "warn", f"'{r['name']}': {lim:.0f} m limit is a placeholder — "
                                                       "confirm with the aviation authority before field use"))
    out.append(check("altitude", "pass" if altitude_m <= max_alt else "fail",
                     f"{altitude_m:.0f} m AGL (limit {max_alt:.0f} m)"))
    if species_min_alt_m is not None:
        out.append(check("animal_welfare", "pass" if altitude_m >= species_min_alt_m else "fail",
                         f"{altitude_m:.0f} m AGL; minimum {species_min_alt_m:.0f} m over animals to avoid disturbance"))
    for r in restrictions:
        geom = r.get("geometry")
        if r["kind"] == "no_fly" and geom:
            hit = path_hits_zone(wps, geom)
            out.append(check("no_fly:" + r["name"], "fail" if hit else "pass",
                             "route enters the no-fly zone" if hit else "route stays clear (with buffer)"))
        elif r["kind"] == "wildlife_buffer" and geom and path_hits_zone(wps, geom):
            p = r["params"]
            st, notes = "pass", []
            if altitude_m < p.get("min_alt_m", 0):
                st = "fail"
                notes.append(f"altitude below {p['min_alt_m']} m required over this site")
            nb = p.get("no_flight_hours")
            if nb and (local_hour >= nb[0] or local_hour < nb[1]):
                st = "fail"
                notes.append(f"no flights {nb[0]:02d}:00–{nb[1]:02d}:00 (nesting / hatchling activity)")
            out.append(check("wildlife:" + r["name"], st, "; ".join(notes) or "crosses wildlife area within its rules"))
        elif r["kind"] == "permit_required" and geom and path_hits_zone(wps, geom):
            ok = bool(r["params"].get("permit_ref"))
            out.append(check("permit:" + r["name"], "pass" if ok else "fail",
                             f"permit {r['params'].get('permit_ref')}" if ok else "route enters an area that needs a permit; none recorded"))
    return out


def rov_transect(start: tuple[float, float], end: tuple[float, float], depth_m: float, legs: int = 1, spacing_m: float = 10.0) -> dict:
    frame = LocalFrame(*start)
    e, n = frame.to_en(end[0], end[1])
    L = float(math.hypot(e, n))
    ux, uy = e / L, n / L
    px, py = -uy, ux
    pts = []
    for k in range(legs):
        off = (k - (legs - 1) / 2) * spacing_m
        a = (off * px, off * py)
        b = (e + off * px, n + off * py)
        pts += [a, b] if k % 2 == 0 else [b, a]
    la, lo = frame.to_latlon(np.array([p[0] for p in pts]), np.array([p[1] for p in pts]))
    return {"waypoints": [[round(float(x), 7), round(float(y), 7), depth_m] for x, y in zip(la, lo)],
            "length_m": round(L * legs + spacing_m * (legs - 1), 1), "depth_m": depth_m}


def rov_predive(plan: dict, spec: ROVSpec, launch: tuple[float, float], conditions: dict | None, device_ok: bool,
                device_note: str, battery_pct: float | None) -> list[dict]:
    out = [check("device", "pass" if device_ok else "fail", device_note)]
    wps = plan.get("waypoints", [])
    frame = LocalFrame(*launch)
    far = max((math.hypot(*frame.to_en(w[0], w[1])) for w in wps), default=0)
    max_depth = max((w[2] for w in wps), default=0)
    slant = math.hypot(far, max_depth)
    out.append(check("tether", "pass" if slant <= 0.85 * spec.tether_m else "fail",
                     f"furthest point {slant:.0f} m slant range; tether {spec.tether_m:.0f} m (85% usable)"))
    out.append(check("depth", "pass" if max_depth <= spec.depth_rating_m else "fail",
                     f"{max_depth:.0f} m planned; rated {spec.depth_rating_m:.0f} m"))
    t = plan.get("length_m", 0) / spec.speed_mps + 300
    wh = spec.power_w * t / 3600
    usable = spec.battery_wh * (battery_pct or 0) / 100 * 0.75
    out.append(check("battery", "pass" if battery_pct and wh <= usable else "fail",
                     f"needs ~{wh:.0f} Wh of {usable:.0f} Wh usable ({t / 60:.0f} min)"))
    if not conditions:
        out.append(check("sea_state", "fail", "no sea-state / current observation — operator must enter conditions"))
    else:
        cur = conditions.get("current_mps", 0)
        out.append(check("current", "pass" if cur <= spec.max_current_mps else "fail",
                         f"current {cur:.2f} m/s (limit {spec.max_current_mps:.2f})"))
        vis = conditions.get("visibility_m")
        if vis is not None:
            out.append(check("visibility", "pass" if vis >= 2 else "warn", f"underwater visibility {vis:.1f} m"))
    out.append(check("supervision", "pass", "tethered ROV: operator in direct control, abort returns to manual"))
    return out
