"""Store-and-forward telemetry for intermittently connected devices (collars, buoys, edge gateways).

  CollarBuffer   on-device ring buffer: keeps observations while offline, uploads in batches, frees on ACK.
                 When full it drops the *oldest* records and counts the loss (reported with the next upload).
  encode_batch   compact binary batch: column-wise fixed-point integers, delta + zigzag varint, zlib.
                 A typical 15-minute collar record shrinks from ~230 B of JSON to ~12–20 B, which matters on LoRaWAN.
  decode_batch   inverse; the server accepts either this format or plain JSON.

Every record carries a monotonically increasing sequence number so the server can deduplicate retries
and detect gaps (lost records) — uploads are idempotent.
"""

from __future__ import annotations

import base64
import struct
import zlib
from collections import deque

FIELDS = [  # name, scale (stored as round(value * scale))
    ("seq", 1), ("t", 1), ("lat", 1e6), ("lon", 1e6), ("hdop", 10), ("speed_mps", 100), ("activity", 1000),
    ("rest_fraction", 100), ("temp_c", 10), ("ambient_c", 10), ("battery_pct", 10), ("rssi", 1), ("water_visit", 1),
]
NULL = -(2 ** 40)
MAGIC = b"AC1"


def _zz(n: int) -> int:
    return (n << 1) ^ (n >> 63)


def _unzz(n: int) -> int:
    return (n >> 1) ^ -(n & 1)


def _varint(n: int, out: bytearray):
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return


def _read_varint(buf: bytes, i: int):
    shift = n = 0
    while True:
        b = buf[i]
        i += 1
        n |= (b & 0x7F) << shift
        shift += 7
        if not b & 0x80:
            return n, i


def encode_batch(records: list[dict]) -> bytes:
    out = bytearray(MAGIC)
    out += struct.pack(">H", len(records))
    for name, scale in FIELDS:
        prev = 0
        for r in records:
            v = r.get(name)
            if isinstance(v, bool):
                v = int(v)
            iv = NULL if v is None else int(round(v * scale))
            _varint(_zz(iv - prev), out)
            prev = iv
    return zlib.compress(bytes(out), 9)


def decode_batch(blob: bytes) -> list[dict]:
    raw = zlib.decompress(blob)
    if raw[:3] != MAGIC:
        raise ValueError("not an AICN telemetry batch")
    (n,) = struct.unpack(">H", raw[3:5])
    i = 5
    cols = {}
    for name, scale in FIELDS:
        prev = 0
        vals = []
        for _ in range(n):
            d, i = _read_varint(raw, i)
            prev = prev + _unzz(d)
            vals.append(None if prev == NULL else (prev if scale == 1 else prev / scale))
        cols[name] = vals
    recs = []
    for k in range(n):
        r = {name: cols[name][k] for name, _ in FIELDS}
        if r["water_visit"] is not None:
            r["water_visit"] = bool(r["water_visit"])
        r["seq"] = int(r["seq"])
        recs.append(r)
    return recs


def b64(blob: bytes) -> str:
    return base64.b64encode(blob).decode()


class CollarBuffer:
    def __init__(self, capacity: int = 2000):
        self.capacity = capacity
        self.q: deque[dict] = deque()
        self.next_seq = 0
        self.dropped = 0

    def push(self, rec: dict) -> dict:
        rec = dict(rec, seq=self.next_seq)
        self.next_seq += 1
        if len(self.q) >= self.capacity:
            self.q.popleft()
            self.dropped += 1
        self.q.append(rec)
        return rec

    def pending(self, max_records: int = 96) -> list[dict]:
        return list(self.q)[:max_records]

    def ack(self, upto_seq: int) -> int:
        n = 0
        while self.q and self.q[0]["seq"] <= upto_seq:
            self.q.popleft()
            n += 1
        return n

    def __len__(self):
        return len(self.q)
