"""Underwater robotics: tethered ROV dynamics and GNSS-free localisation.

No GNSS underwater. The navigation filter fuses
  * pressure depth sensor (direct, accurate)
  * compass / IMU heading with slowly drifting bias
  * visual odometry: ground-relative velocity from the down camera, only when the seabed is within
    visible range (turbidity dependent)
  * USBL acoustic position fixes from the surface vessel (noise grows with slant range, dropouts)
in a Kalman filter whose state also estimates the water current, so dead-reckoning between fixes
stays usable when visual odometry drops out. A dead-reckoning-only estimate is kept for comparison.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np


@dataclass
class DiveConditions:
    current_e: float = 0.15
    current_n: float = -0.05
    visibility_m: float = 8.0
    seabed_depth_m: float = 14.0
    usbl_period_s: float = 8.0
    usbl_dropout: float = 0.15


@dataclass
class DiveResult:
    truth: list = field(default_factory=list)  # [t, e, n, depth, yaw]   (simulator ground truth — not a measurement)
    estimate: list = field(default_factory=list)  # [t, e, n, depth, yaw]
    dead_reckoning: list = field(default_factory=list)
    localization: dict = field(default_factory=dict)
    seabed_samples: list = field(default_factory=list)  # [t, e, n, coral_cover_estimate, coral_cover_truth]
    sightings: list = field(default_factory=list)
    aborted: bool = False
    log: list = field(default_factory=list)


def reef_cover(e: float, n: float, seed: int = 7) -> float:
    """Synthetic coral-cover field (0..1): smooth patches, deterministic per seed."""
    r = np.random.default_rng(seed)
    cs = r.uniform(-150, 150, (8, 2))
    amp = r.uniform(0.2, 0.6, 8)
    sc = r.uniform(25, 60, 8)
    v = 0.08 + np.sum(amp * np.exp(-((e - cs[:, 0]) ** 2 + (n - cs[:, 1]) ** 2) / (2 * sc ** 2)))
    return float(np.clip(v, 0, 0.85))


def simulate_dive(waypoints_en: list[tuple[float, float, float]], cond: DiveConditions, seed: int = 0,
                  speed: float = 0.5, dt: float = 0.5, max_time_s: float = 3600, tether_m: float = 150.0,
                  animals: list[dict] | None = None, abort_at_s: float | None = None) -> DiveResult:
    rng = np.random.default_rng(seed)
    res = DiveResult()
    x = np.array([0.0, 0.0])
    z = 0.0
    yaw = 0.0
    bias = rng.normal(0, math.radians(2))
    # KF state [e, n, ce, cn]
    xh = np.array([0.0, 0.0, 0.0, 0.0])
    P = np.diag([1.0, 1.0, 0.3 ** 2, 0.3 ** 2])
    dr = np.array([0.0, 0.0])
    wi = 0
    t = 0.0
    last_fix = -1e9
    vo_used = fixes = 0
    animals = animals or []
    seen = set()
    while wi < len(waypoints_en) and t < max_time_s:
        if abort_at_s is not None and t >= abort_at_s:
            res.aborted = True
            res.log.append((t, "operator abort: thrusters to manual, ascending"))
            break
        tgt = np.array(waypoints_en[wi][:2])
        tz = waypoints_en[wi][2]
        # guidance uses the *estimate* (the vehicle does not know truth)
        d = tgt - xh[:2]
        if np.hypot(*d) < 2.0 and abs(z - tz) < 1.0:
            wi += 1
            continue
        yaw_cmd = math.atan2(d[0], d[1])
        yaw += float(np.clip(np.angle(np.exp(1j * (yaw_cmd - yaw))), -0.2, 0.2))
        v_water = speed * np.array([math.sin(yaw), math.cos(yaw)]) * min(1.0, np.hypot(*d) / 3)
        cur = np.array([cond.current_e, cond.current_n]) * (1 + 0.2 * math.sin(t / 300))
        x = x + (v_water + cur) * dt
        z += float(np.clip(tz - z, -0.3 * dt, 0.3 * dt))
        # tether: cannot exceed length (slant)
        slant = math.hypot(math.hypot(*x), z)
        if slant > tether_m:
            x = x * (math.sqrt(max(tether_m ** 2 - z ** 2, 0)) / max(math.hypot(*x), 1e-6))
            res.log.append((t, "tether limit reached"))
        t += dt
        # --- sensors
        depth_meas = z + rng.normal(0, 0.05)
        bias += rng.normal(0, math.radians(0.02))
        yaw_meas = yaw + bias + rng.normal(0, math.radians(1))
        altitude = cond.seabed_depth_m - z
        vo_ok = altitude < 0.8 * cond.visibility_m and rng.random() > 0.05
        # --- KF predict
        F = np.eye(4)
        Q = np.diag([0.01, 0.01, 1e-5, 1e-5]) * dt
        if vo_ok:
            v_ground = (v_water + cur) * (1 + rng.normal(0, 0.05)) + rng.normal(0, 0.02, 2)
            # rotate through heading error (the VO measures in body frame; heading from compass)
            err = yaw_meas - yaw
            R2 = np.array([[math.cos(err), math.sin(err)], [-math.sin(err), math.cos(err)]])
            u = R2 @ v_ground
            xh[:2] = xh[:2] + u * dt
            Q[0, 0] = Q[1, 1] = (0.03 * dt) ** 2 + 1e-4
            vo_used += 1
        else:
            v_cmd = speed * np.array([math.sin(yaw_meas), math.cos(yaw_meas)]) * min(1.0, np.hypot(*d) / 3)
            F[0, 2] = F[1, 3] = dt
            xh[:2] = xh[:2] + (v_cmd + xh[2:]) * dt
            Q[0, 0] = Q[1, 1] = (0.05 * dt) ** 2 + 1e-3
        P = F @ P @ F.T + Q
        dr = dr + speed * np.array([math.sin(yaw_meas), math.cos(yaw_meas)]) * min(1.0, np.hypot(*d) / 3) * dt
        # --- USBL update
        if t - last_fix >= cond.usbl_period_s:
            last_fix = t
            if rng.random() > cond.usbl_dropout:
                sr = math.hypot(math.hypot(*x), z)
                sig = 0.5 + 0.01 * sr
                zf = x + rng.normal(0, sig, 2)
                H = np.zeros((2, 4))
                H[0, 0] = H[1, 1] = 1
                S = H @ P @ H.T + np.eye(2) * sig ** 2
                y = zf - H @ xh
                if float(y @ np.linalg.inv(S) @ y) < 13.8:  # outlier gate
                    K = P @ H.T @ np.linalg.inv(S)
                    xh = xh + K @ y
                    P = (np.eye(4) - K @ H) @ P
                    fixes += 1
        res.truth.append([round(t, 1), round(float(x[0]), 2), round(float(x[1]), 2), round(z, 2), round(math.degrees(yaw) % 360, 1)])
        res.estimate.append([round(t, 1), round(float(xh[0]), 2), round(float(xh[1]), 2), round(depth_meas, 2), round(math.degrees(yaw_meas) % 360, 1)])
        res.dead_reckoning.append([round(t, 1), round(float(dr[0]), 2), round(float(dr[1]), 2)])
        # --- camera: seabed survey every 5 s when the bottom is visible
        if vo_ok and int(t / dt) % int(5 / dt) == 0:
            truth_cover = reef_cover(float(x[0]), float(x[1]))
            q = max(0.2, 1 - altitude / cond.visibility_m)
            est = float(np.clip(truth_cover + rng.normal(0, 0.06 / q), 0, 1))
            res.seabed_samples.append([round(t, 1), round(float(xh[0]), 2), round(float(xh[1]), 2), round(est, 3), round(truth_cover, 3)])
        for a in animals:
            if a["id"] in seen:
                continue
            dist = math.dist((a["e"], a["n"], a.get("depth", 5)), (x[0], x[1], z))
            if dist < cond.visibility_m * 0.9 and rng.random() < 0.3:
                seen.add(a["id"])
                res.sightings.append({"t": round(t, 1), "species_group": a["group"], "range_m": round(dist, 1),
                                      "e": round(float(xh[0]), 1), "n": round(float(xh[1]), 1), "depth": round(z, 1),
                                      "confidence": round(float(np.clip(1 - dist / cond.visibility_m, 0.2, 0.9)), 2)})
    T = np.array(res.truth)
    E = np.array(res.estimate)
    D = np.array(res.dead_reckoning)
    if len(T):
        err = np.hypot(T[:, 1] - E[:, 1], T[:, 2] - E[:, 2])
        derr = np.hypot(T[:, 1] - D[:, 1], T[:, 2] - D[:, 2])
        res.localization = {
            "method": "KF: depth + compass + visual odometry + USBL (current estimated)",
            "rmse_m": round(float(np.sqrt(np.mean(err ** 2))), 2), "max_error_m": round(float(err.max()), 2),
            "final_error_m": round(float(err[-1]), 2),
            "dead_reckoning_rmse_m": round(float(np.sqrt(np.mean(derr ** 2))), 2),
            "visual_odometry_share": round(vo_used / len(T), 2), "usbl_fixes": fixes,
            "estimated_current_mps": [round(float(xh[2]), 2), round(float(xh[3]), 2)],
            "true_current_mps": [cond.current_e, cond.current_n],
            "note": "errors are measured against simulator ground truth",
        }
    return res
