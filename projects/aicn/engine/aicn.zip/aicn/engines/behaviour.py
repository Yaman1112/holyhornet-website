"""Behaviour Intelligence: observable behaviour from tracks, kept separate from interpretation.

`observed` holds measurements (heading, speed, turning, group spread, visibility at the surface).
`interpretation` is a hypothesis with a confidence and its basis, marked for review. Possible
entanglement or distress is only ever raised as "possible — needs expert review".
"""

from __future__ import annotations

import math

import numpy as np


def circ_mean_deg(angles_rad: np.ndarray) -> float:
    return float((math.degrees(math.atan2(np.mean(np.sin(angles_rad)), np.mean(np.cos(angles_rad)))) + 360) % 360)


def track_behaviour(history: list[tuple[float, float, float, float]], species_group: str, frames_in_view: int | None = None) -> dict:
    """history: [(t, east, north, conf)] -> {observed, interpretation}"""
    h = np.array(history, float)
    if len(h) < 3:
        return {"observed": {"samples": len(h)}, "interpretation": {"label": "insufficient_data", "confidence": 0.0,
                                                                   "basis": "fewer than 3 positions"}}
    t, e, n = h[:, 0], h[:, 1], h[:, 2]
    de, dn, dt = np.diff(e), np.diff(n), np.maximum(np.diff(t), 1e-3)
    sp = np.hypot(de, dn) / dt
    hd = np.arctan2(de, dn)
    turn = np.abs(np.angle(np.exp(1j * np.diff(hd)))) if len(hd) > 1 else np.array([0.0])
    straightness = float(np.hypot(e[-1] - e[0], n[-1] - n[0]) / max(np.sum(np.hypot(de, dn)), 1e-6))
    observed = {
        "samples": int(len(h)),
        "duration_s": round(float(t[-1] - t[0]), 1),
        "heading_deg": round(circ_mean_deg(hd), 0),
        "mean_speed_mps": round(float(np.mean(sp)), 2),
        "max_speed_mps": round(float(np.max(sp)), 2),
        "mean_turn_deg": round(math.degrees(float(np.mean(turn))), 1),
        "straightness": round(straightness, 2),
    }
    if frames_in_view:
        observed["surface_visibility"] = round(len(h) / frames_in_view, 2)
    label, conf, basis = "travelling", 0.5, "steady heading and speed"
    if observed["mean_speed_mps"] < 0.15:
        label, conf, basis = "stationary_or_resting", 0.5, "speed below 0.15 m/s"
    elif straightness < 0.4 and observed["mean_turn_deg"] > 50:
        label, conf, basis = "milling_or_foraging", 0.4, "low straightness with frequent turns"
    expected_vis = {"sea_turtle": 0.15, "dugong": 0.2, "dolphin_or_dugong": 0.3, "dolphin": 0.3}.get(species_group)
    if (expected_vis and frames_in_view and observed.get("surface_visibility", 0) > 0.9 and frames_in_view >= 8
            and observed["mean_speed_mps"] < 0.2):
        label, conf = "possible_entanglement_or_distress", 0.25
        basis = (f"visible at the surface in {observed['surface_visibility'] * 100:.0f}% of frames (typical ~{expected_vis * 100:.0f}%) "
                 "while nearly stationary. Many benign explanations exist (basking, resting); expert review required.")
    return {"observed": observed, "interpretation": {"label": label, "confidence": conf, "basis": basis,
                                                    "status": "hypothesis — unreviewed"}}


def group_behaviour(positions_en: np.ndarray, velocities_en: np.ndarray | None = None) -> dict:
    """Group spread and polarisation (alignment of headings: 1 = all same direction)."""
    p = np.asarray(positions_en, float)
    if len(p) < 2:
        return {"group_size": int(len(p))}
    c = p.mean(axis=0)
    out = {"group_size": int(len(p)), "spread_m": round(float(np.mean(np.hypot(*(p - c).T))), 1)}
    if velocities_en is not None and len(velocities_en) == len(p):
        v = np.asarray(velocities_en, float)
        sp = np.hypot(v[:, 0], v[:, 1])
        u = v[sp > 0.1] / sp[sp > 0.1, None]
        if len(u) >= 2:
            out["polarisation"] = round(float(np.hypot(*u.mean(axis=0))), 2)
            out["group_heading_deg"] = round(circ_mean_deg(np.arctan2(u[:, 0], u[:, 1])), 0)
    return out
