"""Animal Movement Intelligence.

Finds movement anomalies in collar tracks. Every result is an *observation for a person to assess*,
with the measurements that triggered it, a confidence and a plain-language explanation.
Nothing here diagnoses an animal.

Detectors
  separation        animal far from the robust centre of the rest of its herd for a sustained period
  boundary_exit     consecutive fixes outside the grazing boundary by more than the GPS error
  inactivity        recent accelerometer activity far below the animal's own baseline
  unusual_movement  recent speeds far outside the animal's own distribution (robust z-score), incl. night travel
  congregation      most of the herd packed tightly for a long time away from any water point
  no_data           collar silent past the expected reporting interval (distinguishes network outages)
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

import numpy as np

from ..geo import LocalFrame, distance_to_ring_m, point_in_geometry, polygon_rings


@dataclass
class MovementThresholds:
    separation_m: float = 600.0
    separation_min_minutes: float = 45.0
    boundary_margin_m: float = 15.0  # beyond GPS error
    boundary_min_fixes: int = 2
    inactivity_ratio: float = 0.45  # recent activity / baseline activity
    inactivity_window_h: float = 6.0
    speed_robust_z: float = 5.0
    congregation_radius_m: float = 40.0
    congregation_fraction: float = 0.8
    congregation_min_minutes: float = 120.0
    water_radius_m: float = 150.0
    expected_interval_min: float = 15.0
    no_data_factor: float = 6.0  # silent for > factor * interval
    network_outage_fraction: float = 0.5  # if more than this share of collars is silent: report an outage instead

    @classmethod
    def from_params(cls, params: dict | None) -> "MovementThresholds":
        t = cls()
        for k, v in (params or {}).items():
            if hasattr(t, k):
                setattr(t, k, type(getattr(t, k))(v))
        return t


@dataclass
class Track:
    animal_id: str
    t: np.ndarray  # epoch seconds, ascending
    lat: np.ndarray
    lon: np.ndarray
    hdop: np.ndarray
    activity: np.ndarray
    speed: np.ndarray | None = None
    herd_id: str | None = None

    def __len__(self):
        return len(self.t)


@dataclass
class Anomaly:
    kind: str
    animal_id: str | None
    herd_id: str | None
    confidence: float
    started_at: float
    metrics: dict = field(default_factory=dict)
    explanation: str = ""
    lat: float | None = None
    lon: float | None = None

    def to_dict(self):
        return asdict(self)


def _gps_error_m(hdop) -> np.ndarray:
    # consumer GNSS: roughly 2.5 m * HDOP (1-sigma); conservative 2-sigma
    return 2 * 2.5 * np.nan_to_num(np.asarray(hdop, float), nan=3.0)


def _speeds(tr: Track, frame: LocalFrame) -> np.ndarray:
    if tr.speed is not None and len(tr.speed) == len(tr.t) and np.isfinite(tr.speed).any():
        return np.nan_to_num(tr.speed, nan=0.0)
    e, n = frame.to_en(tr.lat, tr.lon)
    d = np.hypot(np.diff(e), np.diff(n))
    dt = np.maximum(np.diff(tr.t), 1.0)
    return np.concatenate([[0.0], d / dt])


def _conf(margin_ratio: float, n_support: int, base: float = 0.5) -> float:
    """Confidence grows with how far past the threshold the evidence is and how many samples support it."""
    m = 1 - np.exp(-max(margin_ratio, 0) * 1.5)
    s = 1 - np.exp(-n_support / 4)
    return float(np.clip(base * 0.4 + 0.6 * m * s, 0.05, 0.97))


def analyze(
    tracks: list[Track],
    now: float,
    boundary: dict | None = None,
    water_points: list[tuple[float, float]] | None = None,
    th: MovementThresholds | None = None,
    baselines: dict[str, dict] | None = None,
    night_hours: tuple[int, int] = (20, 5),
    utc_offset_h: float = 3.0,  # East Africa Time
) -> list[Anomaly]:
    th = th or MovementThresholds()
    baselines = baselines or {}
    out: list[Anomaly] = []
    live = [tr for tr in tracks if len(tr) > 0]
    if not live:
        return out
    lat0 = float(np.nanmedian(np.concatenate([tr.lat for tr in live])))
    lon0 = float(np.nanmedian(np.concatenate([tr.lon for tr in live])))
    frame = LocalFrame(lat0, lon0)

    out += _no_data(tracks, now, th)
    by_herd: dict[str | None, list[Track]] = {}
    for tr in live:
        by_herd.setdefault(tr.herd_id, []).append(tr)
    for herd_id, herd in by_herd.items():
        out += _separation(herd, frame, th)
        out += _congregation(herd, frame, th, water_points or [], herd_id)
    for tr in live:
        if boundary:
            a = _boundary(tr, boundary, th)
            if a:
                out.append(a)
        a = _inactivity(tr, th, baselines.get(tr.animal_id, {}), now)
        if a:
            out.append(a)
        a = _unusual_movement(tr, frame, th, baselines.get(tr.animal_id, {}), night_hours, utc_offset_h)
        if a:
            out.append(a)
    return out


def _no_data(tracks: list[Track], now: float, th: MovementThresholds) -> list[Anomaly]:
    limit = th.no_data_factor * th.expected_interval_min * 60
    silent = [tr for tr in tracks if len(tr) == 0 or now - tr.t[-1] > limit]
    if not silent:
        return []
    if len(tracks) >= 3 and len(silent) / len(tracks) > th.network_outage_fraction:
        return [Anomaly("network_outage", None, None, 0.8, now, {"silent_collars": len(silent), "total": len(tracks)},
                        f"{len(silent)} of {len(tracks)} collars stopped reporting at the same time. This usually means "
                        "a gateway or network outage rather than missing animals; collars keep storing data and will "
                        "upload when the link returns.")]
    res = []
    for tr in silent:
        last = float(tr.t[-1]) if len(tr) else None
        silent_h = (now - last) / 3600 if last else None
        res.append(Anomaly("no_data", tr.animal_id, tr.herd_id, 0.7, last or now,
                           {"silent_hours": round(silent_h, 2) if silent_h else None},
                           f"No collar data for {silent_h:.1f} h. The collar may be out of radio range, damaged or "
                           "the animal may have moved away; last known position shown." if silent_h else
                           "Collar has never reported.",
                           float(tr.lat[-1]) if len(tr) else None, float(tr.lon[-1]) if len(tr) else None))
    return res


def _separation(herd: list[Track], frame: LocalFrame, th: MovementThresholds) -> list[Anomaly]:
    if len(herd) < 3:
        return []
    # resample on a common time grid (last 6 h) using each animal's latest fix at or before the grid time
    t_end = max(float(tr.t[-1]) for tr in herd)
    grid = np.arange(t_end - 6 * 3600, t_end + 1, th.expected_interval_min * 60)
    pos = np.full((len(herd), len(grid), 2), np.nan)
    for i, tr in enumerate(herd):
        e, n = frame.to_en(tr.lat, tr.lon)
        idx = np.searchsorted(tr.t, grid, side="right") - 1
        ok = (idx >= 0) & (grid - tr.t[np.clip(idx, 0, None)] < 2 * th.expected_interval_min * 60)
        pos[i, ok, 0] = e[idx[ok]]
        pos[i, ok, 1] = n[idx[ok]]
    res = []
    for i, tr in enumerate(herd):
        others = np.delete(pos, i, axis=0)
        centre = np.nanmedian(others, axis=0)  # robust: one stray does not drag the centre
        d = np.hypot(pos[i, :, 0] - centre[:, 0], pos[i, :, 1] - centre[:, 1])
        far = np.nan_to_num(d, nan=0.0) > th.separation_m
        # longest run of consecutive far samples ending at the latest sample
        run = 0
        for f in far[::-1]:
            if not f:
                break
            run += 1
        minutes = run * th.expected_interval_min
        if minutes >= th.separation_min_minutes:
            dist = float(d[-1]) if np.isfinite(d[-1]) else float(np.nanmax(d))
            conf = _conf(dist / th.separation_m - 1, run)
            res.append(Anomaly("separation", tr.animal_id, tr.herd_id, conf, float(grid[-run]),
                               {"distance_from_herd_m": round(dist), "duration_min": minutes,
                                "threshold_m": th.separation_m},
                               f"About {dist:.0f} m from the rest of the herd for at least {minutes:.0f} min "
                               f"(threshold {th.separation_m:.0f} m). Possible straying, theft or an animal unable to keep up.",
                               float(tr.lat[-1]), float(tr.lon[-1])))
    return res


def _boundary(tr: Track, boundary: dict, th: MovementThresholds) -> Anomaly | None:
    rings = polygon_rings(boundary)
    if not rings:
        return None
    n_out = 0
    max_d = 0.0
    err = _gps_error_m(tr.hdop)
    for k in range(len(tr) - 1, max(-1, len(tr) - 8), -1):
        la, lo = float(tr.lat[k]), float(tr.lon[k])
        if point_in_geometry(la, lo, boundary):
            break
        d = min(distance_to_ring_m(la, lo, r) for r in rings)
        if d <= err[k] + th.boundary_margin_m:
            break  # could be GPS error
        n_out += 1
        max_d = max(max_d, d)
    if n_out >= th.boundary_min_fixes:
        return Anomaly("boundary_exit", tr.animal_id, tr.herd_id, _conf(max_d / 100, n_out), float(tr.t[-n_out]),
                       {"outside_fixes": n_out, "max_distance_outside_m": round(max_d)},
                       f"{n_out} consecutive positions outside the grazing boundary, up to {max_d:.0f} m beyond it "
                       "(more than the GPS error). Possible escape or a broken fence.",
                       float(tr.lat[-1]), float(tr.lon[-1]))
    return None


def hour_of_day(t, utc_off: float = 3.0) -> np.ndarray:
    return ((np.asarray(t, float) / 3600 + utc_off) % 24).astype(int)


def _inactivity(tr: Track, th: MovementThresholds, base: dict, now: float) -> Anomaly | None:
    """Compares recent activity with what this animal normally does at the same hours of the day."""
    act = np.asarray(tr.activity, float)
    win = tr.t >= now - th.inactivity_window_h * 3600
    ok = win & np.isfinite(act)
    recent = act[ok]
    if len(recent) < 6:
        return None
    prof = base.get("activity_by_hour")
    hrs = hour_of_day(tr.t[ok])
    if prof:
        expected = np.array([prof[h] if prof[h] is not None else np.nan for h in hrs], float)
    else:
        hist = (~win) & np.isfinite(act)
        if hist.sum() < 48:
            return None
        hh = hour_of_day(tr.t[hist])
        means = {h: float(np.mean(act[hist][hh == h])) for h in np.unique(hh)}
        expected = np.array([means.get(h, np.nan) for h in hrs], float)
    if not np.isfinite(expected).any():
        return None
    ref = float(np.nanmean(expected))
    if ref <= 0:
        return None
    ratio = float(np.mean(recent[np.isfinite(expected)])) / ref
    if ratio < th.inactivity_ratio:
        return Anomaly("inactivity", tr.animal_id, tr.herd_id, _conf((th.inactivity_ratio - ratio) / th.inactivity_ratio * 3, len(recent)),
                       float(tr.t[win][0]),
                       {"activity_ratio": round(ratio, 2), "window_h": th.inactivity_window_h,
                        "recent_mean_g": round(float(np.mean(recent)), 4), "expected_mean_g": round(ref, 4),
                        "baseline": "same hours of day"},
                       f"Activity over the last {th.inactivity_window_h:.0f} h is {ratio * 100:.0f}% of what this animal "
                       "usually does at these hours. Needs a look: could be heat, lameness or illness — or a loose / fallen collar.",
                       float(tr.lat[-1]), float(tr.lon[-1]))
    return None


def _unusual_movement(tr: Track, frame: LocalFrame, th: MovementThresholds, base: dict, night, utc_off) -> Anomaly | None:
    """Sustained speeds well above the animal's own fast walking (p99), or travel at night when it normally rests."""
    sp = _speeds(tr, frame)
    if len(sp) < 30:
        return None
    hist_sp, hist_t = sp[:-8], tr.t[:-8]
    recent, rt = sp[-8:], tr.t[-8:]
    hh = hour_of_day(hist_t, utc_off)
    is_night_h = (hh >= night[0]) | (hh < night[1])
    p99 = base.get("speed_p99", float(np.percentile(hist_sp, 99)))
    p95n = base.get("speed_p95_night", float(np.percentile(hist_sp[is_night_h], 95)) if is_night_h.sum() >= 10 else 0.2)
    fast_th = max(1.5 * p99, 0.9)
    night_th = max(3 * p95n, 0.4)
    rh = hour_of_day(rt, utc_off)
    rn = (rh >= night[0]) | (rh < night[1])
    n_fast = int(np.sum(recent > fast_th))
    n_night = int(np.sum((recent > night_th) & rn))
    if n_fast >= 2 or n_night >= 2:
        kind_txt = "at night, when the herd normally rests" if n_night >= 2 else "much faster than its usual walking"
        ref = night_th if n_night >= 2 else fast_th
        return Anomaly("unusual_movement", tr.animal_id, tr.herd_id, _conf(float(np.max(recent)) / ref - 1 + 0.4, max(n_fast, n_night)),
                       float(tr.t[-8]),
                       {"recent_max_speed_mps": round(float(np.max(recent)), 2), "fast_samples": n_fast, "night_samples": n_night,
                        "threshold_mps": round(ref, 2)},
                       f"Sustained movement {kind_txt}. Possible disturbance (predator, theft, dogs) — check the herd.",
                       float(tr.lat[-1]), float(tr.lon[-1]))
    return None


def _congregation(herd, frame, th, water_points, herd_id) -> list[Anomaly]:
    if len(herd) < 5:
        return []
    t_end = max(float(tr.t[-1]) for tr in herd)
    steps = int(th.congregation_min_minutes / th.expected_interval_min)
    grid = t_end - np.arange(steps) * th.expected_interval_min * 60
    tight = 0
    last_c = None
    for g in grid:
        pts = []
        for tr in herd:
            k = np.searchsorted(tr.t, g, side="right") - 1
            if k >= 0 and g - tr.t[k] < 2 * th.expected_interval_min * 60:
                pts.append(frame.to_en(tr.lat[k], tr.lon[k]))
        if len(pts) < 5:
            break
        p = np.array(pts, float)
        c = np.median(p, axis=0)
        frac = float(np.mean(np.hypot(*(p - c).T) < th.congregation_radius_m))
        if frac < th.congregation_fraction:
            break
        tight += 1
        last_c = c if last_c is None else last_c
    if tight < steps or last_c is None:
        return []
    clat, clon = frame.to_latlon(*last_c)
    for wlat, wlon in water_points:
        we, wn = frame.to_en(wlat, wlon)
        if np.hypot(last_c[0] - we, last_c[1] - wn) < th.water_radius_m:
            return []  # gathering at water is normal
    hours = ((t_end / 3600 + 3) % 24)
    if hours >= 19 or hours < 6:
        return []  # night enclosure (boma) is normal
    return [Anomaly("congregation", None, herd_id, 0.5, float(grid[-1]),
                    {"radius_m": th.congregation_radius_m, "minutes": th.congregation_min_minutes},
                    f"Most of the herd has stayed tightly bunched for {th.congregation_min_minutes:.0f} min during the day, "
                    "away from water. Possible heat stress, a threat nearby, or a blocked route.",
                    float(clat), float(clon))]


def learn_baseline(tr: Track, utc_off: float = 3.0) -> dict:
    """Individual reference values from a calm history window (robust, time-of-day aware)."""
    frame = LocalFrame(float(np.nanmedian(tr.lat)), float(np.nanmedian(tr.lon)))
    sp = _speeds(tr, frame)
    act = np.asarray(tr.activity, float)
    hh = hour_of_day(tr.t, utc_off)
    by_hour = []
    for h in range(24):
        m = (hh == h) & np.isfinite(act)
        by_hour.append(round(float(np.mean(act[m])), 4) if m.sum() >= 2 else None)
    night = (hh >= 20) | (hh < 5)
    fin = act[np.isfinite(act)]
    return {
        "activity_mean": float(np.mean(fin)) if len(fin) else None,
        "activity_sd": float(np.std(fin)) if len(fin) else None,
        "activity_by_hour": by_hour,
        "speed_median": float(np.median(sp)),
        "speed_p99": float(np.percentile(sp, 99)),
        "speed_p95_night": float(np.percentile(sp[night], 95)) if night.sum() >= 10 else 0.2,
        "samples": int(len(tr)),
    }
