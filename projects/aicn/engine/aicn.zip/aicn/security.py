"""Password hashing (PBKDF2-SHA256), signed access tokens (HS256 JWT), API keys and device secrets.

Standard library only so the identical code runs on the server and in the browser edition.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time

from .config import settings
from .errors import Unauthorized


def _pbkdf2_sha256(password: bytes, salt: bytes, iterations: int) -> bytes:
    """PBKDF2-HMAC-SHA256 (RFC 8018), one 32-byte block. Uses OpenSSL when present; pure Python otherwise
    (Pyodide builds hashlib without OpenSSL)."""
    if hasattr(hashlib, "pbkdf2_hmac"):
        return hashlib.pbkdf2_hmac("sha256", password, salt, iterations)
    inner = hmac.new(password, digestmod=hashlib.sha256)
    u = inner.copy()
    u.update(salt + b"\x00\x00\x00\x01")
    u = u.digest()
    acc = int.from_bytes(u, "big")
    for _ in range(iterations - 1):
        h = inner.copy()
        h.update(u)
        u = h.digest()
        acc ^= int.from_bytes(u, "big")
    return acc.to_bytes(32, "big")


def hash_password(password: str, iterations: int | None = None) -> str:
    it = iterations or settings.pbkdf2_iterations
    salt = secrets.token_bytes(16)
    dk = _pbkdf2_sha256(password.encode(), salt, it)
    return f"pbkdf2_sha256${it}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, it, salt_b64, dk_b64 = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = _pbkdf2_sha256(password.encode(), base64.b64decode(salt_b64), int(it))
        return hmac.compare_digest(dk, base64.b64decode(dk_b64))
    except Exception:
        return False


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def create_token(sub: str, org_id: str, extra: dict | None = None, ttl_s: int | None = None) -> str:
    now = int(time.time())
    payload = {"sub": sub, "org": org_id, "iat": now, "exp": now + (ttl_s or settings.token_ttl_s)}
    payload.update(extra or {})
    head = _b64u(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    body = _b64u(json.dumps(payload, separators=(",", ":")).encode())
    sig = hmac.new(settings.secret_key.encode(), f"{head}.{body}".encode(), hashlib.sha256).digest()
    return f"{head}.{body}.{_b64u(sig)}"


def decode_token(token: str) -> dict:
    try:
        head, body, sig = token.split(".")
    except ValueError:
        raise Unauthorized("malformed token")
    expected = hmac.new(settings.secret_key.encode(), f"{head}.{body}".encode(), hashlib.sha256).digest()
    if not hmac.compare_digest(expected, _b64u_dec(sig)):
        raise Unauthorized("invalid token signature")
    if json.loads(_b64u_dec(head)).get("alg") != "HS256":
        raise Unauthorized("unsupported token algorithm")
    payload = json.loads(_b64u_dec(body))
    if payload.get("exp", 0) < time.time():
        raise Unauthorized("token expired")
    return payload


def new_api_key() -> tuple[str, str, str]:
    """Returns (full_key, prefix, sha256 hash). Only the hash is stored."""
    raw = secrets.token_urlsafe(32)
    prefix = raw[:8]
    key = f"aicn_{prefix}_{raw[8:]}"
    return key, prefix, sha256(key)


def sha256(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def api_key_prefix(key: str) -> str:
    parts = key.split("_")
    if len(parts) < 3 or parts[0] != "aicn":
        raise Unauthorized("malformed API key")
    return parts[1]


def new_device_secret() -> tuple[str, str]:
    s = secrets.token_urlsafe(24)
    return s, sha256(s)


def sign_device_payload(secret: str, body: bytes) -> str:
    """Devices sign each upload (HMAC-SHA256) so a captured payload cannot be altered in transit."""
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
