"""Server entry point:  uvicorn aicn.main:app --port 8500"""

from .api.app import create_app

app = create_app()
