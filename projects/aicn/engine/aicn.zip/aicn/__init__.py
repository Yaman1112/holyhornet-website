"""AICN — Animal Intelligence & Conservation Network.

Package layout (domain separation is enforced by module and table prefix):

  aicn.models.shared     core_*  tables: organisations, users, devices, missions, alerts, AI, audit
  aicn.models.livestock  lv_*    tables: farms, herds, animals, collar telemetry, health, water, grazing
  aicn.models.marine     mr_*    tables: species, observations, nests, habitat, ROV dives, behaviour

  aicn.engines           pure-numpy intelligence (movement, health, vision, tracking, planning, ROV, ...)
  aicn.services          business logic; every function takes a DB session and a Principal
  aicn.api               FastAPI application (also runs in the browser through aicn.browser)
  aicn.sim               digital twin that feeds the backend through the same ingest services
"""

__version__ = "0.1.0"
