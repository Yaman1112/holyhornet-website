"""Catalogues and the demonstration deployment.

Everything created here is clearly marked as demonstration / synthetic: farm boundaries, paddocks, beaches and
survey areas are drawn for the simulator near real place names in Zanzibar, Pemba and Dodoma region, but they
are NOT surveyed boundaries. Regulatory limits are placeholders flagged `verified=False`.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

import numpy as np
from sqlalchemy import select
from sqlalchemy.orm import Session

from .db import set_virtual_now
from .geo import bbox_of, circle_polygon, rect_polygon
from .models import (Animal, Area, Device, Farm, Herd, Membership, Nest, NestEvent, OperatingRestriction, Organization,
                     Species, SpeciesProfile, Treatment, User, Vaccination, VegetationObservation, WaterPoint)
from .security import hash_password, new_device_secret
from .services import ai as ai_svc
from .services.alerts import ensure_default_rules

DEMO_PASSWORD = "aicn-demo-2026"

LIVESTOCK_SPECIES = [
    ("cattle", "Cattle", "Ng'ombe", [38.0, 39.3], [3, 10]),
    ("goat", "Goat", "Mbuzi", [38.5, 40.0], [2, 8]),
    ("sheep", "Sheep", "Kondoo", [38.3, 39.9], [2, 8]),
    ("donkey", "Donkey", "Punda", [36.5, 38.0], [5, 20]),
    ("camel", "Camel", "Ngamia", [36.0, 38.6], [10, 30]),
]

MARINE_SPECIES = [
    # id, common, swahili, scientific, group, IUCN (global), sensitive, length m
    ("chelonia_mydas", "Green turtle", "Kasa", "Chelonia mydas", "sea_turtle", "EN", True, 1.0),
    ("eretmochelys_imbricata", "Hawksbill turtle", "Ng'amba", "Eretmochelys imbricata", "sea_turtle", "CR", True, 0.8),
    ("tursiops_aduncus", "Indo-Pacific bottlenose dolphin", "Pomboo", "Tursiops aduncus", "dolphin", "NT", False, 2.4),
    ("stenella_longirostris", "Spinner dolphin", "Pomboo", "Stenella longirostris", "dolphin", "LC", False, 1.9),
    ("sousa_plumbea", "Indian Ocean humpback dolphin", "Pomboo", "Sousa plumbea", "dolphin", "EN", True, 2.5),
    ("dugong_dugon", "Dugong", "Nguva", "Dugong dugon", "dugong", "VU", True, 2.8),
    ("megaptera_novaeangliae", "Humpback whale", "Nyangumi", "Megaptera novaeangliae", "whale", "LC", False, 14.0),
    ("rhincodon_typus", "Whale shark", "Papa potwe", "Rhincodon typus", "shark", "EN", False, 8.0),
    ("mobula_alfredi", "Reef manta ray", "Taa", "Mobula alfredi", "ray", "VU", False, 3.5),
    ("sea_turtle", "Sea turtle (unidentified)", "Kasa", "Cheloniidae", "sea_turtle", "", True, 1.0),
    ("dolphin_or_dugong", "Dolphin or dugong (unidentified)", "", "Cetacea / Sirenia", "dolphin_or_dugong", "", True, 2.5),
    ("other", "Other marine animal", "", "—", "other", "", False, 1.0),
]


def _area(db, org, domain, kind, name, geom, sensitive=False, props=None):
    a, b, c, d = bbox_of(geom)
    ar = Area(org_id=org.id, domain=domain, kind=kind, name=name, geometry=geom, min_lat=a, min_lon=b, max_lat=c, max_lon=d,
              sensitive=sensitive, synthetic=True, properties=props or {})
    db.add(ar)
    db.flush()
    return ar


def _device(db, org, **kw):
    _, h = new_device_secret()
    d = Device(org_id=org.id, secret_hash=h, simulated=True, **kw)
    db.add(d)
    db.flush()
    return d


UAV_SPECS = {"cruise_speed_mps": 10.0, "battery_wh": 270.0, "cruise_power_w": 360.0, "hover_power_w": 420.0,
             "max_wind_mps": 10.0, "max_alt_m": 120.0, "rgb_hfov_deg": 70.0, "thermal_hfov_deg": 45.0}


def catalogue(db: Session):
    for sid, name, sw, temp, km in LIVESTOCK_SPECIES:
        if not db.get(SpeciesProfile, sid):
            db.add(SpeciesProfile(id=sid, name=name, name_sw=sw, body_temp_c=temp, typical_daily_km=km, uav_min_altitude_m=60.0,
                                  notes="Reference ranges for orientation only; 60 m minimum UAV altitude is a "
                                        "conservative placeholder pending local animal-welfare guidance."))
    for sid, cn, sw, sci, grp, iucn, sens, L in MARINE_SPECIES:
        if not db.get(Species, sid):
            db.add(Species(id=sid, common_name=cn, common_name_sw=sw, scientific_name=sci, group=grp, iucn_status=iucn,
                           sensitive=sens, profile={"length_m": L, "min_uav_alt_m": 30, "approach_m": 50,
                                                    "note": "UAV distances are placeholders; follow the permit conditions"}))
    db.flush()
    ai_svc.sync_registry(db)


def _user(db, email, name, phone="", admin=False):
    u = db.scalar(select(User).where(User.email == email))
    if u:
        return u
    u = User(email=email, name=name, phone=phone, password_hash=hash_password(DEMO_PASSWORD, _ITER), is_platform_admin=admin)
    db.add(u)
    db.flush()
    return u


_ITER = 60_000


def demo(db: Session, iterations: int = 60_000):
    global _ITER
    _ITER = iterations
    if db.scalar(select(Organization).where(Organization.slug == "aicn-pilot")):
        return
    catalogue(db)
    rng = np.random.default_rng(11)

    # ---------------------------------------------------------------- pilot organisation (both divisions)
    org = Organization(name="AICN Pilot — Zanzibar & Pemba (demo)", slug="aicn-pilot", kind="research", country="TZ",
                       region="Zanzibar", settings={"sim": {"livestock": True, "marine": True}})
    db.add(org)
    db.flush()
    ensure_default_rules(db, org.id)

    farm_specs = [
        # name, village/district/region, lat, lon, boundary w,h, paddocks [(name, dx, dy, w, h, in_use_by)], herds
        ("Kizimbani Demonstration Farm (synthetic)", "Kizimbani", "Magharibi A", "Mjini Magharibi", -6.1050, 39.2580, 1800, 1300,
         [("North paddock", 0, 380, 1300, 420), ("East paddock", 560, -180, 520, 560), ("South paddock (rested)", -300, -420, 900, 360)],
         [("Herd A — Zebu", "cattle", 14, 0), ("Goats", "goat", 10, 1)], "borehole",
         {"mean_c": 27.0, "amp_c": 3.5}),
        ("Chake Chake Smallholders (synthetic)", "Wawi", "Chake Chake", "Kusini Pemba", -5.2440, 39.7810, 1400, 1100,
         [("Valley grazing", 0, 250, 1000, 420), ("Hill grazing (rested)", 0, -300, 900, 380)],
         [("Herd P — Zebu", "cattle", 8, 0)], "charco", {"mean_c": 27.0, "amp_c": 3.5}),
    ]
    farm_ids = []
    for (fname, village, district, region, lat, lon, bw, bh, paddocks, herds, wkind, climate) in farm_specs:
        b = _area(db, org, "livestock", "farm_boundary", fname, rect_polygon(lat, lon, bw, bh),
                  props={"climate": climate, "note": "synthetic boundary for the simulator"})
        f = Farm(org_id=org.id, name=fname, owner_name="Demo cooperative", village=village, district=district, region=region,
                 lat=lat, lon=lon, boundary_area_id=b.id)
        db.add(f)
        db.flush()
        farm_ids.append(f.id)
        from .geo import LocalFrame

        fr = LocalFrame(lat, lon)
        pads = []
        for i, (pn, dx, dy, w, h) in enumerate(paddocks):
            pl, plo = fr.to_latlon(dx, dy)
            ndvi = float(rng.uniform(0.42, 0.58))
            ref = [round(ndvi + 0.04 * np.sin(k / 3), 3) for k in range(12)]
            pads.append(_area(db, org, "livestock", "grazing_area", f"{pn} — {village}", rect_polygon(float(pl), float(plo), w, h),
                              props={"ndvi_now": ndvi, "ndvi_seasonal_ref": ref, "rain_30d_mm": 85, "rain_30d_ref_mm": 95,
                                     "days_since_grazed": 0 if "rested" not in pn else 26}))
        gw = _device(db, org, domain="livestock", device_type="gateway", category="lorawan_gateway", name=f"Gateway {village}",
                     serial=f"SIM-GW-{village.upper()}", manufacturer="Reference design", model="LoRaWAN 8-channel (simulated)",
                     firmware="2.1.0-sim", comms=["lorawan", "cellular"], last_lat=lat, last_lon=lon, battery_pct=100.0,
                     connectivity="online", health="ok", specs={"range_m": 6000, "backhaul": "cellular 3G/4G with store-and-forward"})
        wl, wlo = fr.to_latlon(-60, 120 if wkind == "borehole" else 180)
        ws = _device(db, org, domain="livestock", device_type="water_sensor", category="water_level", name=f"Water level {village}",
                     serial=f"SIM-WL-{village.upper()}", manufacturer="Reference design", model="Ultrasonic level (simulated)",
                     firmware="1.3.0-sim", comms=["lorawan"], last_lat=float(wl), last_lon=float(wlo), battery_pct=96.0,
                     specs={"calibration": {"id": "CAL-WL-001", "calibrated_at": "2026-10-01", "offset_cm": 0.0}})
        db.add(WaterPoint(org_id=org.id, farm_id=f.id, name=f"{'Borehole' if wkind == 'borehole' else 'Charco dam'} {village}",
                          kind=wkind, lat=float(wl), lon=float(wlo), capacity_l=20000 if wkind == "borehole" else 60000, device_id=ws.id))
        for hi, (hn, sp, n, pad_i) in enumerate(herds):
            h = Herd(org_id=org.id, farm_id=f.id, name=hn, species=sp, grazing_area_id=pads[pad_i].id)
            db.add(h)
            db.flush()
            for k in range(n):
                tag = f"{'ZN' if village == 'Kizimbani' else 'PB'}-{sp[:1].upper()}{k + 1:03d}"
                a = Animal(org_id=org.id, farm_id=f.id, herd_id=h.id, tag=tag,
                           name=["Bahati", "Neema", "Zawadi", "Tumaini", "Furaha", "Imani", "Rehema", "Amani", "Upendo",
                                 "Baraka", "Subira", "Mwanaidi", "Kheri", "Salama"][k % 14] if sp == "cattle" else "",
                           species=sp, breed="Zanzibar Zebu" if sp == "cattle" else "Small East African goat",
                           sex="female" if k % 5 else "male", age_estimate_months=int(rng.integers(18, 96)))
                db.add(a)
                db.flush()
                _device(db, org, domain="livestock", device_type="collar", category="smart_collar", name=f"Collar {tag}",
                        serial=f"SIM-COL-{a.id[:10]}", manufacturer="AICN reference design", model="AC-1 (simulated)",
                        firmware="0.9.0-sim", comms=["lorawan", "ble"], battery_pct=float(rng.uniform(55, 99)), animal_id=a.id,
                        specs={"sensors": ["gnss", "accelerometer", "gyroscope", "temperature", "battery"],
                               "sample_interval_s": 900, "uplink_interval_s": 3600, "buffer_records": 2000})
                if k % 3 == 0:
                    db.add(Vaccination(org_id=org.id, animal_id=a.id, vaccine="Lumpy skin disease (LSD)",
                                       given_on=date(2026, 6, 10), next_due=date(2027, 6, 10), administered_by="District vet (demo)"))
                if sp == "cattle" and k % 2 == 0:
                    db.add(Vaccination(org_id=org.id, animal_id=a.id, vaccine="Foot-and-mouth disease (FMD)",
                                       given_on=date(2026, 3, 2), next_due=date(2026, 9, 2), administered_by="District vet (demo)"))
            if hi == 0:
                first = db.scalar(select(Animal).where(Animal.herd_id == h.id))
                db.add(Treatment(org_id=org.id, animal_id=first.id, started_on=date(2026, 10, 12), condition="Tick infestation (demo record)",
                                 treatment="Acaricide spray, repeat in 14 days", vet_name="Dr. Demo Vet"))
        # vegetation history (simulated satellite, every 5 days for 60 days)
        start = datetime(2026, 11, 2, 7, 30, tzinfo=timezone.utc) - timedelta(days=62)
        for pad in pads:
            v0 = pad.properties["ndvi_now"] - 0.06
            for k in range(12):
                v = float(np.clip(v0 + k * 0.005 + rng.normal(0, 0.015), 0, 1))
                db.add(VegetationObservation(org_id=org.id, area_id=pad.id, observed_at=start + timedelta(days=5 * k),
                                             ndvi_mean=round(v, 3), ndvi_p10=round(v - 0.08, 3), cloud_fraction=round(float(rng.uniform(0, 0.5)), 2),
                                             biomass_kg_ha=round(4200 * v - 350), source="satellite_sim", is_estimate=True))
    # village buffer (no-fly) touching the north paddock of farm 1
    from .geo import LocalFrame

    fr = LocalFrame(-6.1050, 39.2580)
    vl, vlo = fr.to_latlon(420, 470)
    village = _area(db, org, "shared", "restricted_zone", "Homestead cluster buffer (example)", circle_polygon(float(vl), float(vlo), 110))
    db.add(OperatingRestriction(org_id=org.id, kind="no_fly", name="Homestead cluster — no overflight", area_id=village.id,
                                params={"buffer_m": 30}, authority="Village agreement (example)", verified=False))
    db.add(OperatingRestriction(org_id=org.id, kind="altitude_limit", name="Maximum altitude above ground (placeholder)",
                                params={"max_alt_m": 120}, authority="Tanzania Civil Aviation Authority — confirm current rules",
                                verified=False))

    # UAV / ROV fleet
    _device(db, org, domain="livestock", device_type="uav", category="livestock_uav", name="Guardian-1",
            serial="SIM-UAV-G1", manufacturer="Reference airframe", model="Quad 2 kg, RGB + radiometric thermal (simulated)",
            firmware="PX4 1.15 (sim)", comms=["telemetry_radio", "cellular"], battery_pct=100.0, last_lat=-6.1050, last_lon=39.2580,
            specs=dict(UAV_SPECS), health="ok", connectivity="online")
    _device(db, org, domain="shared", device_type="uav", category="survey_uav", name="Survey-2",
            serial="SIM-UAV-S2", manufacturer="Reference airframe", model="Fixed-wing VTOL, multispectral (simulated)",
            firmware="ArduPilot 4.5 (sim)", comms=["telemetry_radio"], battery_pct=82.0, last_lat=-5.2440, last_lon=39.7810,
            specs=dict(UAV_SPECS, cruise_speed_mps=16.0, battery_wh=500.0, cruise_power_w=300.0), health="ok", connectivity="online")

    # ---------------------------------------------------------------- marine
    core_lat, core_lon = -5.8330, 39.3720
    mpa = _area(db, org, "marine", "marine_protected_area", "Mnemba–Chwaka conservation area (approximate, synthetic outline)",
                rect_polygon(-5.835, 39.375, 6000, 5000, 10), props={"note": "approximate outline for simulation only"})
    db.add(OperatingRestriction(org_id=org.id, kind="permit_required", name="Research permit for the conservation area",
                                area_id=mpa.id, params={"permit_ref": "DEMO-PERMIT-001 (placeholder)"},
                                authority="Marine conservation authority — permit conditions apply", verified=False))
    core = _area(db, org, "marine", "survey_area", "Turtle foraging core area", rect_polygon(core_lat, core_lon, 700, 450, 20),
                 props={"habitat": "seagrass and patch reef"})
    reef = _area(db, org, "marine", "reef_site", "Patch reef transect site", rect_polygon(-5.8290, 39.3790, 260, 200))
    _area(db, org, "marine", "coastal_boundary", "Matemwe shoreline (approximate)",
          rect_polygon(-5.8660, 39.3540, 2600, 60, 70))
    beach = _area(db, org, "marine", "nesting_beach", "Nesting beach N1", rect_polygon(-5.8600, 39.3575, 520, 45, 70),
                  sensitive=True, props={"note": "sensitive — precise outline visible to authorised roles only"})
    db.add(OperatingRestriction(org_id=org.id, kind="wildlife_buffer", name="Nesting beach — no night flights, min 50 m",
                                area_id=beach.id, params={"min_alt_m": 50, "no_flight_hours": [18, 7]},
                                authority="Beach monitoring protocol (example)", verified=False))
    _device(db, org, domain="marine", device_type="uav", category="marine_uav", name="Pwani-1", serial="SIM-UAV-P1",
            manufacturer="Reference airframe", model="Quad, marine-rated, RGB zoom (simulated)", firmware="PX4 1.15 (sim)",
            comms=["telemetry_radio"], battery_pct=100.0, last_lat=-5.8420, last_lon=39.3660,
            specs=dict(UAV_SPECS, max_wind_mps=11.0), health="ok", connectivity="online")
    _device(db, org, domain="marine", device_type="rov", category="rov", name="Mwamba ROV-1", serial="SIM-ROV-1",
            manufacturer="Reference design", model="Tethered observation-class ROV, 100 m (simulated)", firmware="2.0.0-sim",
            comms=["tether"], battery_pct=100.0, last_lat=-5.8290, last_lon=39.3790,
            specs={"depth_rating_m": 100, "tether_m": 150, "max_current_mps": 0.8, "speed_mps": 0.5, "battery_wh": 266, "power_w": 180,
                   "sensors": ["hd_camera", "low_light_camera", "led_lights", "depth", "imu", "pressure", "temperature"],
                   "options": ["usbl", "imaging_sonar", "hydrophone"]}, health="ok", connectivity="online")
    _device(db, org, domain="marine", device_type="auv", category="future_auv", name="AUV (phase-2 concept)", serial="PLAN-AUV-1",
            manufacturer="—", model="Not built — see hardware roadmap", firmware="—", comms=["acoustic_modem"], status="planned")
    _device(db, org, domain="marine", device_type="env_sensor", category="buoy", name="Buoy MN-1", serial="SIM-BUOY-1",
            manufacturer="Reference design", model="Temperature / turbidity buoy (simulated)", firmware="1.1.0-sim",
            comms=["cellular", "lorawan"], battery_pct=91.0, last_lat=core_lat, last_lon=core_lon,
            specs={"area_id": core.id, "calibration": {"id": "CAL-BUOY-2026-10", "calibrated_at": "2026-10-15",
                                                       "reference": "two-point lab calibration"}})
    # historic nests (some due to hatch during the simulation)
    from .geo import LocalFrame as LF

    bf = LF(-5.8600, 39.3575)
    for k, age in enumerate([58, 55, 50, 46, 41, 62, 70]):
        e, n = rng.uniform(-200, 200), rng.uniform(-10, 10)
        la, lo = bf.to_latlon(e, n)
        laid = date(2026, 11, 2) - timedelta(days=age)
        st = "hatched" if age >= 62 else "incubating"
        nest = Nest(org_id=org.id, beach_area_id=beach.id, code=f"N-{k + 1:03d}", species_id="chelonia_mydas",
                    lat=float(la), lon=float(lo), laid_on=laid, expected_hatch_from=laid + timedelta(days=50), status=st,
                    clutch_size=int(rng.integers(90, 130)), hatchlings_emerged=int(rng.integers(60, 100)) if st == "hatched" else None,
                    protected=k % 2 == 0)
        db.add(nest)
        db.flush()
        db.add(NestEvent(org_id=org.id, nest_id=nest.id, at=datetime.combine(laid, datetime.min.time()).replace(
            tzinfo=timezone.utc), kind="laid", observer="Ranger (demo)"))

    # people (all demo accounts share DEMO_PASSWORD)
    people = [("admin@aicn.demo", "Asha Org-Admin", "org_admin"), ("farmer@aicn.demo", "Juma Farmer", "farmer"),
              ("vet@aicn.demo", "Dr. Mwanaisha Vet", "veterinarian"), ("wildlife@aicn.demo", "Neema Wildlife-Researcher", "wildlife_researcher"),
              ("marine@aicn.demo", "Dr. Salim Marine-Researcher", "marine_researcher"),
              ("officer@aicn.demo", "Fatma Conservation-Officer", "conservation_officer"),
              ("uav@aicn.demo", "Omar UAV-Operator", "uav_operator"), ("rov@aicn.demo", "Halima ROV-Operator", "rov_operator"),
              ("viewer@aicn.demo", "Guest Viewer", "viewer")]
    for email, name, role in people:
        u = _user(db, email, name, "+255700000000" if role in ("farmer", "conservation_officer") else "")
        db.add(Membership(user_id=u.id, org_id=org.id, role=role,
                          scope={"farm_ids": [farm_ids[0]]} if role == "farmer" else {}))
    pa = _user(db, "platform@aicn.demo", "Platform Administrator", admin=True)
    db.add(Membership(user_id=pa.id, org_id=org.id, role="org_admin"))

    # ---------------------------------------------------------------- second organisation (isolation demo)
    org2 = Organization(name="Mvumi Herders Group (demo)", slug="mvumi-herders", kind="farm_cooperative", country="TZ",
                        region="Dodoma", settings={"sim": {"livestock": True, "marine": False}})
    db.add(org2)
    db.flush()
    ensure_default_rules(db, org2.id)
    lat, lon = -6.3500, 35.8600
    b = _area(db, org2, "livestock", "farm_boundary", "Mvumi communal grazing (synthetic)", rect_polygon(lat, lon, 2600, 2000),
              props={"climate": {"mean_c": 24.0, "amp_c": 6.5}})
    f = Farm(org_id=org2.id, name="Mvumi communal grazing (synthetic)", village="Mvumi", district="Chamwino", region="Dodoma",
             lat=lat, lon=lon, boundary_area_id=b.id)
    db.add(f)
    db.flush()
    fr2 = LocalFrame(lat, lon)
    gl, glo = fr2.to_latlon(0, 450)
    g = _area(db, org2, "livestock", "grazing_area", "Northern rangeland", rect_polygon(float(gl), float(glo), 1800, 700),
              props={"ndvi_now": 0.36, "ndvi_seasonal_ref": [0.4] * 12, "rain_30d_mm": 20, "rain_30d_ref_mm": 45})
    _device(db, org2, domain="livestock", device_type="gateway", category="lorawan_gateway", name="Gateway Mvumi",
            serial="SIM-GW-MVUMI", model="LoRaWAN (simulated)", firmware="2.1.0-sim", last_lat=lat, last_lon=lon, battery_pct=100.0)
    ws = _device(db, org2, domain="livestock", device_type="water_sensor", category="water_level", name="Charco level Mvumi",
                 serial="SIM-WL-MVUMI", model="Ultrasonic level (simulated)", firmware="1.3.0-sim", battery_pct=88.0,
                 last_lat=lat - 0.002, last_lon=lon + 0.001)
    db.add(WaterPoint(org_id=org2.id, farm_id=f.id, name="Mvumi charco", kind="charco", lat=lat - 0.002, lon=lon + 0.001,
                      capacity_l=80000, device_id=ws.id))
    h = Herd(org_id=org2.id, farm_id=f.id, name="Communal herd", species="cattle", grazing_area_id=g.id)
    db.add(h)
    db.flush()
    for k in range(12):
        a = Animal(org_id=org2.id, farm_id=f.id, herd_id=h.id, tag=f"MV-C{k + 1:03d}", species="cattle", breed="Tanzania Shorthorn Zebu",
                   sex="female")
        db.add(a)
        db.flush()
        _device(db, org2, domain="livestock", device_type="collar", category="smart_collar", name=f"Collar MV-C{k + 1:03d}",
                serial=f"SIM-COL-{a.id[:10]}", model="AC-1 (simulated)", firmware="0.9.0-sim", comms=["lorawan"],
                battery_pct=float(rng.uniform(60, 99)), animal_id=a.id)
    _device(db, org2, domain="livestock", device_type="uav", category="livestock_uav", name="Mvumi-UAV", serial="SIM-UAV-MV",
            model="Quad, thermal (simulated)", firmware="PX4 1.15 (sim)", battery_pct=100.0, last_lat=lat, last_lon=lon,
            specs=dict(UAV_SPECS))
    for email, name, role in [("farmer@mvumi.demo", "Paulo Farmer (Mvumi)", "farmer"), ("admin@mvumi.demo", "Rehema Admin (Mvumi)", "org_admin")]:
        u = _user(db, email, name)
        db.add(Membership(user_id=u.id, org_id=org2.id, role=role))
    db.add(Membership(user_id=pa.id, org_id=org2.id, role="org_admin"))
    db.commit()


def warm_up(db: Session, sim, days: float = 2.0):
    """Run the twin from (start - days) without analytics so every animal has a baseline, then enable analytics."""
    from .services import livestock as lv_svc

    start = sim.clock
    sim.clock = start - timedelta(days=days)
    set_virtual_now(sim.clock)
    sim.attach_all(db)
    for w in sim.worlds.values():
        w.analysis = False
        if w.livestock:  # place animals around their boma at dawn
            for a in w.livestock.animals.values():
                h = w.livestock.herds[a.herd_id]
                a.e, a.n = h.boma[0] + w.rng.normal(0, 8), h.boma[1] + w.rng.normal(0, 8)
    sim.step(db, days * 24 * 60)
    for org_id, w in sim.worlds.items():
        if w.livestock:
            lv_svc.learn_baselines(db, org_id, sim.clock, days=days)
            lv_svc.analyze_org(db, org_id, sim.clock, run_health=True)  # first assessment so dashboards are populated
        w.analysis = True
    db.commit()
