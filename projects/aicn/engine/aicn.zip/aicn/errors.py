class AICNError(Exception):
    status = 400

    def __init__(self, detail: str):
        super().__init__(detail)
        self.detail = detail


class NotFound(AICNError):
    status = 404


class Forbidden(AICNError):
    status = 403


class Unauthorized(AICNError):
    status = 401


class Conflict(AICNError):
    status = 409


class Invalid(AICNError):
    status = 422


class NotConfigured(AICNError):
    """An integration (hardware, credentials, model weights) is not available."""

    status = 503
