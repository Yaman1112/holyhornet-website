"""Marine Animal Intelligence tables (mr_*)."""

from __future__ import annotations

from datetime import date, datetime
from typing import Optional

from sqlalchemy import Boolean, Date, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, JSONText, UTCDateTime
from .shared import created, org_fk, pk


class Species(Base):
    """Configurable marine species profile. org_id NULL = platform catalogue entry."""

    __tablename__ = "mr_species"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    org_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    common_name: Mapped[str] = mapped_column(String(120))
    common_name_sw: Mapped[str] = mapped_column(String(120), default="")
    scientific_name: Mapped[str] = mapped_column(String(160))
    group: Mapped[str] = mapped_column(String(32))  # sea_turtle | dolphin | whale | dugong | shark | ray | other
    iucn_status: Mapped[str] = mapped_column(String(8), default="")
    sensitive: Mapped[bool] = mapped_column(Boolean, default=False)  # locations generalised for unauthorised users
    profile: Mapped[dict] = mapped_column(JSONText, default=dict)  # length_m, surface_fraction, min_uav_alt_m, approach_m


class MarineObservation(Base):
    __tablename__ = "mr_observations"
    __table_args__ = (Index("ix_mobs_org_time", "org_id", "observed_at"),)
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    species_id: Mapped[Optional[str]] = mapped_column(String(40), ForeignKey("mr_species.id"), nullable=True)
    species_group: Mapped[str] = mapped_column(String(32))
    count: Mapped[int] = mapped_column(Integer, default=1)
    count_uncertainty: Mapped[int] = mapped_column(Integer, default=0)
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    observed_at: Mapped[datetime] = created()
    method: Mapped[str] = mapped_column(String(24))  # uav_aerial | rov | boat_survey | shore | acoustic | community
    source: Mapped[str] = mapped_column(String(16), default="ai")  # ai | human
    confidence: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    verification: Mapped[str] = mapped_column(String(16), default="unverified")  # unverified | verified | rejected | needs_expert
    verified_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    verification_note: Mapped[str] = mapped_column(Text, default="")
    mission_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    media_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    detection_ids: Mapped[list] = mapped_column(JSONText, default=list)
    environment: Mapped[dict] = mapped_column(JSONText, default=dict)
    individual_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)  # only set from validated photo-ID
    area_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    sensitive: Mapped[bool] = mapped_column(Boolean, default=False)
    notes: Mapped[str] = mapped_column(Text, default="")


class Individual(Base):
    """A known individual (photo-ID catalogue). Only created from validated identification."""

    __tablename__ = "mr_individuals"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    species_id: Mapped[str] = mapped_column(String(40), ForeignKey("mr_species.id"))
    catalogue_code: Mapped[str] = mapped_column(String(60))
    validation: Mapped[str] = mapped_column(Text)  # how the identification was validated
    notes: Mapped[str] = mapped_column(Text, default="")


class Nest(Base):
    """Sea-turtle nest. Precise coordinates are sensitive: only users with sensitive.read see them."""

    __tablename__ = "mr_nests"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    beach_area_id: Mapped[str] = mapped_column(String(32), ForeignKey("core_areas.id", ondelete="CASCADE"), index=True)
    code: Mapped[str] = mapped_column(String(40))
    species_id: Mapped[Optional[str]] = mapped_column(String(40), ForeignKey("mr_species.id"), nullable=True)
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    laid_on: Mapped[date] = mapped_column(Date)
    expected_hatch_from: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="incubating")  # incubating | hatched | failed | predated | washed_out | relocated
    clutch_size: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    hatchlings_emerged: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    site_condition: Mapped[str] = mapped_column(String(40), default="")
    protected: Mapped[bool] = mapped_column(Boolean, default=False)  # fenced / marked by rangers
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = created()


class NestEvent(Base):
    __tablename__ = "mr_nest_events"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    nest_id: Mapped[str] = mapped_column(String(32), ForeignKey("mr_nests.id", ondelete="CASCADE"), index=True)
    at: Mapped[datetime] = created()
    kind: Mapped[str] = mapped_column(String(32))  # laid | inspected | inundation | predation_sign | hatching | excavated | conservation_action
    detail: Mapped[str] = mapped_column(Text, default="")
    observer: Mapped[str] = mapped_column(String(120), default="")
    source: Mapped[str] = mapped_column(String(16), default="human")


class HabitatObservation(Base):
    __tablename__ = "mr_habitat_observations"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    area_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    kind: Mapped[str] = mapped_column(String(32))  # coral_cover | seagrass_cover | debris | erosion | bleaching
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(16))
    uncertainty: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    method: Mapped[str] = mapped_column(String(24))  # rov_transect | uav_mapping | diver | satellite
    observed_at: Mapped[datetime] = created()
    is_estimate: Mapped[bool] = mapped_column(Boolean, default=True)
    mission_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)


class RovDive(Base):
    __tablename__ = "mr_rov_dives"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    mission_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    device_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    site: Mapped[str] = mapped_column(String(160))
    started_at: Mapped[datetime] = created()
    ended_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    max_depth_m: Mapped[float] = mapped_column(Float, default=0.0)
    duration_s: Mapped[float] = mapped_column(Float, default=0.0)
    track: Mapped[list] = mapped_column(JSONText, default=list)  # estimated track [t, east, north, depth, yaw]
    localization: Mapped[dict] = mapped_column(JSONText, default=dict)  # method + error statistics (vs simulator truth when simulated)
    summary: Mapped[dict] = mapped_column(JSONText, default=dict)
    simulated: Mapped[bool] = mapped_column(Boolean, default=True)


class BehaviourEvent(Base):
    """Observed behaviour, kept apart from any interpretation of it."""

    __tablename__ = "mr_behaviour_events"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    observation_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    mission_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    track_id: Mapped[str] = mapped_column(String(40), default="")
    species_group: Mapped[str] = mapped_column(String(32), default="")
    at: Mapped[datetime] = created()
    observed: Mapped[dict] = mapped_column(JSONText, default=dict)  # measured facts: heading, speed, group spread, surfacing
    interpretation: Mapped[dict] = mapped_column(JSONText, default=dict)  # {label, confidence, basis} — a hypothesis
    review_status: Mapped[str] = mapped_column(String(16), default="unreviewed")
    lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    sensitive: Mapped[bool] = mapped_column(Boolean, default=False)
