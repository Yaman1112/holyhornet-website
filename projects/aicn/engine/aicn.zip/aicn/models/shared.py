"""Shared-platform tables (core_*): tenancy, identity, GIS areas, devices, missions, AI, alerts, audit."""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, JSONText, UTCDateTime, new_id, utcnow


def pk():
    return mapped_column(String(32), primary_key=True, default=new_id)


def org_fk(nullable=False):
    return mapped_column(String(32), ForeignKey("core_organizations.id", ondelete="CASCADE"), index=True, nullable=nullable)


def created():
    return mapped_column(UTCDateTime, default=utcnow, nullable=False)


class Organization(Base):
    __tablename__ = "core_organizations"
    id: Mapped[str] = pk()
    name: Mapped[str] = mapped_column(String(200))
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    kind: Mapped[str] = mapped_column(String(40))  # farm_cooperative | conservation | research | veterinary | government
    country: Mapped[str] = mapped_column(String(2), default="TZ")
    region: Mapped[str] = mapped_column(String(80), default="")
    telemetry_retention_days: Mapped[int] = mapped_column(Integer, default=730)
    settings: Mapped[dict] = mapped_column(JSONText, default=dict)
    created_at: Mapped[datetime] = created()


class User(Base):
    __tablename__ = "core_users"
    id: Mapped[str] = pk()
    email: Mapped[str] = mapped_column(String(200), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    phone: Mapped[str] = mapped_column(String(40), default="")
    password_hash: Mapped[str] = mapped_column(String(300))
    is_platform_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    language: Mapped[str] = mapped_column(String(8), default="en")  # en | sw
    created_at: Mapped[datetime] = created()


class Membership(Base):
    __tablename__ = "core_memberships"
    __table_args__ = (UniqueConstraint("user_id", "org_id"),)
    id: Mapped[str] = pk()
    user_id: Mapped[str] = mapped_column(String(32), ForeignKey("core_users.id", ondelete="CASCADE"), index=True)
    org_id: Mapped[str] = org_fk()
    role: Mapped[str] = mapped_column(String(40))
    # optional narrowing: farm ids a farmer may see (empty = all in org)
    scope: Mapped[dict] = mapped_column(JSONText, default=dict)


class ApiKey(Base):
    __tablename__ = "core_api_keys"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    name: Mapped[str] = mapped_column(String(120))
    prefix: Mapped[str] = mapped_column(String(16), index=True)
    key_hash: Mapped[str] = mapped_column(String(128))
    role: Mapped[str] = mapped_column(String(40), default="viewer")
    created_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)
    last_used_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[datetime] = created()


class Area(Base):
    """Any named geometry: farm boundary, grazing area, MPA, nesting beach, restricted zone, survey area."""

    __tablename__ = "core_areas"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    domain: Mapped[str] = mapped_column(String(16))  # livestock | marine | shared
    kind: Mapped[str] = mapped_column(String(40), index=True)
    name: Mapped[str] = mapped_column(String(200))
    geometry: Mapped[dict] = mapped_column(JSONText)  # GeoJSON geometry (EPSG:4326)
    min_lat: Mapped[float] = mapped_column(Float)
    min_lon: Mapped[float] = mapped_column(Float)
    max_lat: Mapped[float] = mapped_column(Float)
    max_lon: Mapped[float] = mapped_column(Float)
    sensitive: Mapped[bool] = mapped_column(Boolean, default=False)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)  # simulator-generated, not a surveyed boundary
    properties: Mapped[dict] = mapped_column(JSONText, default=dict)
    created_at: Mapped[datetime] = created()


class OperatingRestriction(Base):
    """Configurable rules the mission planner must respect (no-fly, wildlife buffers, altitude, permits)."""

    __tablename__ = "core_operating_restrictions"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    kind: Mapped[str] = mapped_column(String(40))  # no_fly | altitude_limit | wildlife_buffer | time_window | permit_required | weather_limit
    name: Mapped[str] = mapped_column(String(200))
    area_id: Mapped[Optional[str]] = mapped_column(String(32), ForeignKey("core_areas.id", ondelete="CASCADE"), nullable=True)
    params: Mapped[dict] = mapped_column(JSONText, default=dict)
    authority: Mapped[str] = mapped_column(String(200), default="")  # e.g. TCAA, ZAA, MPA authority — source of the rule
    verified: Mapped[bool] = mapped_column(Boolean, default=False)  # False = placeholder value that must be confirmed
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = created()


class Device(Base):
    __tablename__ = "core_devices"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    domain: Mapped[str] = mapped_column(String(16))
    device_type: Mapped[str] = mapped_column(String(32), index=True)  # collar | ear_tag | env_sensor | water_sensor | gateway | uav | rov | auv
    category: Mapped[str] = mapped_column(String(40), default="")  # livestock_uav | marine_uav | survey_uav | rov ...
    name: Mapped[str] = mapped_column(String(120))
    serial: Mapped[str] = mapped_column(String(80), unique=True)
    manufacturer: Mapped[str] = mapped_column(String(120), default="")
    model: Mapped[str] = mapped_column(String(120), default="")
    firmware: Mapped[str] = mapped_column(String(40), default="")
    comms: Mapped[list] = mapped_column(JSONText, default=list)  # ["lorawan","ble"]
    secret_hash: Mapped[str] = mapped_column(String(128), default="")
    status: Mapped[str] = mapped_column(String(24), default="active")  # active | maintenance | retired | lost
    health: Mapped[str] = mapped_column(String(24), default="unknown")  # ok | degraded | fault | unknown
    connectivity: Mapped[str] = mapped_column(String(24), default="unknown")  # online | buffering | offline | unknown
    battery_pct: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    last_seen_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    last_lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    last_lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    last_seq: Mapped[int] = mapped_column(Integer, default=-1)
    animal_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    specs: Mapped[dict] = mapped_column(JSONText, default=dict)
    simulated: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = created()


class MaintenanceRecord(Base):
    __tablename__ = "core_maintenance_records"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    device_id: Mapped[str] = mapped_column(String(32), ForeignKey("core_devices.id", ondelete="CASCADE"), index=True)
    performed_at: Mapped[datetime] = created()
    kind: Mapped[str] = mapped_column(String(40))  # inspection | repair | battery_replacement | firmware_update | calibration
    notes: Mapped[str] = mapped_column(Text, default="")
    performed_by: Mapped[str] = mapped_column(String(120), default="")


class IngestBatch(Base):
    """One store-and-forward upload from a device (idempotency and link-quality statistics)."""

    __tablename__ = "core_ingest_batches"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    device_id: Mapped[str] = mapped_column(String(32), ForeignKey("core_devices.id", ondelete="CASCADE"), index=True)
    received_at: Mapped[datetime] = created()
    seq_first: Mapped[int] = mapped_column(Integer)
    seq_last: Mapped[int] = mapped_column(Integer)
    n_records: Mapped[int] = mapped_column(Integer)
    n_duplicates: Mapped[int] = mapped_column(Integer, default=0)
    n_gaps: Mapped[int] = mapped_column(Integer, default=0)
    payload_bytes: Mapped[int] = mapped_column(Integer, default=0)
    encoding: Mapped[str] = mapped_column(String(24), default="json")
    max_delay_s: Mapped[float] = mapped_column(Float, default=0.0)


class Mission(Base):
    __tablename__ = "core_missions"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    domain: Mapped[str] = mapped_column(String(16))
    kind: Mapped[str] = mapped_column(String(40))
    name: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(24), default="draft", index=True)
    # draft -> validated -> approved -> active -> completed | aborted ; draft/validated/approved -> cancelled
    priority: Mapped[str] = mapped_column(String(12), default="normal")
    mode: Mapped[str] = mapped_column(String(16), default="simulation")  # simulation | supervised
    area_id: Mapped[Optional[str]] = mapped_column(String(32), ForeignKey("core_areas.id", ondelete="SET NULL"), nullable=True)
    device_id: Mapped[Optional[str]] = mapped_column(String(32), ForeignKey("core_devices.id", ondelete="SET NULL"), nullable=True)
    params: Mapped[dict] = mapped_column(JSONText, default=dict)
    plan: Mapped[dict] = mapped_column(JSONText, default=dict)
    preflight: Mapped[dict] = mapped_column(JSONText, default=dict)
    outcome: Mapped[dict] = mapped_column(JSONText, default=dict)
    scheduled_for: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    created_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    approved_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    started_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    ended_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[datetime] = created()


class MissionLog(Base):
    __tablename__ = "core_mission_logs"
    id: Mapped[str] = pk()
    mission_id: Mapped[str] = mapped_column(String(32), ForeignKey("core_missions.id", ondelete="CASCADE"), index=True)
    at: Mapped[datetime] = created()
    level: Mapped[str] = mapped_column(String(12), default="info")
    message: Mapped[str] = mapped_column(Text)
    data: Mapped[dict] = mapped_column(JSONText, default=dict)


class Media(Base):
    __tablename__ = "core_media"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    domain: Mapped[str] = mapped_column(String(16))
    kind: Mapped[str] = mapped_column(String(16))  # image | thermal | video_frame
    mission_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    uri: Mapped[str] = mapped_column(String(400), default="")
    width: Mapped[int] = mapped_column(Integer, default=0)
    height: Mapped[int] = mapped_column(Integer, default=0)
    lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    captured_at: Mapped[datetime] = created()
    meta: Mapped[dict] = mapped_column(JSONText, default=dict)
    sensitive: Mapped[bool] = mapped_column(Boolean, default=False)


class AIModel(Base):
    __tablename__ = "core_ai_models"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    task: Mapped[str] = mapped_column(String(40))  # detection | tracking | anomaly | health | vegetation | behaviour | planning | reporting
    domain: Mapped[str] = mapped_column(String(16))
    version: Mapped[str] = mapped_column(String(24))
    backend: Mapped[str] = mapped_column(String(40))  # numpy | onnxruntime | rules
    available: Mapped[bool] = mapped_column(Boolean, default=True)
    description: Mapped[str] = mapped_column(Text, default="")
    metrics: Mapped[dict] = mapped_column(JSONText, default=dict)  # each metric names its evaluation data (synthetic / benchmark / field)


class AIDetection(Base):
    __tablename__ = "core_ai_detections"
    __table_args__ = (Index("ix_det_org_time", "org_id", "observed_at"),)
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    domain: Mapped[str] = mapped_column(String(16))
    model_id: Mapped[str] = mapped_column(String(64))
    media_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    mission_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    label: Mapped[str] = mapped_column(String(80))
    species_group: Mapped[str] = mapped_column(String(40), default="")
    confidence: Mapped[float] = mapped_column(Float)
    bbox: Mapped[list] = mapped_column(JSONText, default=list)  # [x, y, w, h] pixels
    lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    track_id: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    observed_at: Mapped[datetime] = created()
    review_status: Mapped[str] = mapped_column(String(16), default="unreviewed")  # unreviewed | confirmed | corrected | rejected
    review_label: Mapped[Optional[str]] = mapped_column(String(80), nullable=True)
    reviewed_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    sensitive: Mapped[bool] = mapped_column(Boolean, default=False)
    extra: Mapped[dict] = mapped_column(JSONText, default=dict)


class Alert(Base):
    __tablename__ = "core_alerts"
    __table_args__ = (Index("ix_alert_org_status", "org_id", "status"),)
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    domain: Mapped[str] = mapped_column(String(16))
    kind: Mapped[str] = mapped_column(String(40))
    priority: Mapped[str] = mapped_column(String(12))  # low | medium | high | critical
    status: Mapped[str] = mapped_column(String(16), default="open")  # open | acknowledged | resolved | dismissed
    title: Mapped[str] = mapped_column(String(300))
    message: Mapped[str] = mapped_column(Text)
    subject_type: Mapped[str] = mapped_column(String(32), default="")
    subject_id: Mapped[str] = mapped_column(String(32), default="")
    lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    sensitive: Mapped[bool] = mapped_column(Boolean, default=False)
    confidence: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    evidence: Mapped[dict] = mapped_column(JSONText, default=dict)
    requires_review: Mapped[bool] = mapped_column(Boolean, default=True)
    source: Mapped[str] = mapped_column(String(24), default="engine")  # engine | device | edge | user
    dedupe_key: Mapped[str] = mapped_column(String(160), default="", index=True)
    created_at: Mapped[datetime] = created()
    acknowledged_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    acknowledged_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    resolved_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    resolution_note: Mapped[str] = mapped_column(Text, default="")


class AlertRule(Base):
    __tablename__ = "core_alert_rules"
    __table_args__ = (UniqueConstraint("org_id", "kind"),)
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    kind: Mapped[str] = mapped_column(String(40))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    priority: Mapped[str] = mapped_column(String(12), default="medium")
    params: Mapped[dict] = mapped_column(JSONText, default=dict)
    recipients: Mapped[dict] = mapped_column(JSONText, default=dict)  # {"roles": [...], "user_ids": [...]}
    channels: Mapped[list] = mapped_column(JSONText, default=list)  # in_app | email | sms | push


class Notification(Base):
    __tablename__ = "core_notifications"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    alert_id: Mapped[str] = mapped_column(String(32), ForeignKey("core_alerts.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    channel: Mapped[str] = mapped_column(String(16))
    recipient: Mapped[str] = mapped_column(String(200), default="")
    status: Mapped[str] = mapped_column(String(20))  # delivered | sent | not_configured | failed | no_address
    detail: Mapped[str] = mapped_column(Text, default="")
    read: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = created()


class EnvMeasurement(Base):
    __tablename__ = "core_env_measurements"
    __table_args__ = (Index("ix_env_org_kind_time", "org_id", "kind", "measured_at"),)
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    domain: Mapped[str] = mapped_column(String(16))
    kind: Mapped[str] = mapped_column(String(32))  # water_temp | turbidity | water_clarity | depth | air_temp | rainfall | ndvi | water_level | wind_speed ...
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(16))
    lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    area_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    device_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    measured_at: Mapped[datetime] = created()
    source: Mapped[str] = mapped_column(String(24))  # sensor | satellite | uav | rov | manual | model
    is_estimate: Mapped[bool] = mapped_column(Boolean, default=False)
    quality: Mapped[str] = mapped_column(String(12), default="good")  # good | suspect | bad
    calibration: Mapped[dict] = mapped_column(JSONText, default=dict)  # {"id":..., "calibrated_at":..., "offset":...}
    clock_source: Mapped[str] = mapped_column(String(16), default="gnss")  # gnss | ntp | rtc_unsynced


class Report(Base):
    __tablename__ = "core_reports"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    domain: Mapped[str] = mapped_column(String(16))
    kind: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(300))
    period_start: Mapped[datetime] = mapped_column(UTCDateTime)
    period_end: Mapped[datetime] = mapped_column(UTCDateTime)
    area_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    content: Mapped[dict] = mapped_column(JSONText, default=dict)
    created_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    created_at: Mapped[datetime] = created()


class AuditLog(Base):
    __tablename__ = "core_audit_log"
    id: Mapped[str] = pk()
    org_id: Mapped[Optional[str]] = mapped_column(String(32), index=True, nullable=True)
    user_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    actor: Mapped[str] = mapped_column(String(200), default="")
    action: Mapped[str] = mapped_column(String(80))
    resource: Mapped[str] = mapped_column(String(80), default="")
    resource_id: Mapped[str] = mapped_column(String(64), default="")
    detail: Mapped[dict] = mapped_column(JSONText, default=dict)
    at: Mapped[datetime] = created()


class IdempotencyKey(Base):
    """Offline clients (mobile, edge) retry uploads; the key makes each record land exactly once."""

    __tablename__ = "core_idempotency_keys"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    org_id: Mapped[str] = org_fk()
    resource: Mapped[str] = mapped_column(String(40))
    resource_id: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = created()
