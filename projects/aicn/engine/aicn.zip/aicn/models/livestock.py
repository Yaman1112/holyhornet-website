"""Livestock Guardian tables (lv_*)."""

from __future__ import annotations

from datetime import date, datetime
from typing import Optional

from sqlalchemy import Boolean, Date, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ..db import JSONText, UTCDateTime
from ..db import Base
from .shared import created, org_fk, pk


class Farm(Base):
    __tablename__ = "lv_farms"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    name: Mapped[str] = mapped_column(String(200))
    owner_name: Mapped[str] = mapped_column(String(200), default="")
    village: Mapped[str] = mapped_column(String(120), default="")
    district: Mapped[str] = mapped_column(String(120), default="")
    region: Mapped[str] = mapped_column(String(120), default="")
    boundary_area_id: Mapped[Optional[str]] = mapped_column(String(32), ForeignKey("core_areas.id", ondelete="SET NULL"), nullable=True)
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    created_at: Mapped[datetime] = created()


class Herd(Base):
    __tablename__ = "lv_herds"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    farm_id: Mapped[str] = mapped_column(String(32), ForeignKey("lv_farms.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    species: Mapped[str] = mapped_column(String(24))
    grazing_area_id: Mapped[Optional[str]] = mapped_column(String(32), ForeignKey("core_areas.id", ondelete="SET NULL"), nullable=True)


class SpeciesProfile(Base):
    """Configurable livestock species: movement and health baselines used by the engines."""

    __tablename__ = "lv_species_profiles"
    id: Mapped[str] = mapped_column(String(24), primary_key=True)  # cattle | goat | sheep | camel | donkey ...
    name: Mapped[str] = mapped_column(String(80))
    name_sw: Mapped[str] = mapped_column(String(80), default="")
    body_temp_c: Mapped[list] = mapped_column(JSONText)  # [low, high] normal rectal range (reference)
    typical_daily_km: Mapped[list] = mapped_column(JSONText)
    uav_min_altitude_m: Mapped[float] = mapped_column(Float, default=60.0)  # welfare: never fly lower over animals
    notes: Mapped[str] = mapped_column(Text, default="")


class Animal(Base):
    __tablename__ = "lv_animals"
    __table_args__ = (UniqueConstraint("org_id", "tag"),)
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    farm_id: Mapped[str] = mapped_column(String(32), ForeignKey("lv_farms.id", ondelete="CASCADE"), index=True)
    herd_id: Mapped[Optional[str]] = mapped_column(String(32), ForeignKey("lv_herds.id", ondelete="SET NULL"), nullable=True, index=True)
    tag: Mapped[str] = mapped_column(String(40))
    name: Mapped[str] = mapped_column(String(120), default="")
    species: Mapped[str] = mapped_column(String(24), ForeignKey("lv_species_profiles.id"))
    breed: Mapped[str] = mapped_column(String(80), default="")
    sex: Mapped[str] = mapped_column(String(8), default="unknown")
    birth_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    age_estimate_months: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="active")  # active | missing | sold | deceased
    photo_url: Mapped[str] = mapped_column(String(400), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    baseline: Mapped[dict] = mapped_column(JSONText, default=dict)  # learned individual baselines (activity, temp, speed)
    last_lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    last_lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    last_fix_at: Mapped[Optional[datetime]] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[datetime] = created()


class CollarTelemetry(Base):
    __tablename__ = "lv_collar_telemetry"
    __table_args__ = (
        UniqueConstraint("device_id", "seq"),
        Index("ix_tel_animal_time", "animal_id", "recorded_at"),
        Index("ix_tel_org_time", "org_id", "recorded_at"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    org_id: Mapped[str] = org_fk()
    device_id: Mapped[str] = mapped_column(String(32), ForeignKey("core_devices.id", ondelete="CASCADE"))
    animal_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    seq: Mapped[int] = mapped_column(Integer)
    recorded_at: Mapped[datetime] = mapped_column(UTCDateTime)
    received_at: Mapped[datetime] = created()
    lat: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    lon: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    hdop: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    speed_mps: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    activity: Mapped[Optional[float]] = mapped_column(Float, nullable=True)  # ODBA-style index from accelerometer, g
    rest_fraction: Mapped[Optional[float]] = mapped_column(Float, nullable=True)  # share of the interval classified as lying/resting
    temp_c: Mapped[Optional[float]] = mapped_column(Float, nullable=True)  # collar skin temperature (not core body temperature)
    ambient_c: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    battery_pct: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    rssi: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    water_visit: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)  # inside a water-point beacon zone


class HealthObservation(Base):
    __tablename__ = "lv_health_observations"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    animal_id: Mapped[str] = mapped_column(String(32), ForeignKey("lv_animals.id", ondelete="CASCADE"), index=True)
    observed_at: Mapped[datetime] = created()
    source: Mapped[str] = mapped_column(String(16))  # engine | veterinarian | farmer
    level: Mapped[str] = mapped_column(String(16))  # normal | unusual | concern | urgent
    score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    confidence: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    uncertainty: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    supporting: Mapped[list] = mapped_column(JSONText, default=list)
    data_coverage: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    summary: Mapped[str] = mapped_column(Text, default="")
    review_status: Mapped[str] = mapped_column(String(16), default="unreviewed")  # unreviewed | reviewed | dismissed
    reviewed_by: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    review_note: Mapped[str] = mapped_column(Text, default="")


class Vaccination(Base):
    __tablename__ = "lv_vaccinations"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    animal_id: Mapped[str] = mapped_column(String(32), ForeignKey("lv_animals.id", ondelete="CASCADE"), index=True)
    vaccine: Mapped[str] = mapped_column(String(120))
    given_on: Mapped[date] = mapped_column(Date)
    next_due: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    administered_by: Mapped[str] = mapped_column(String(120), default="")
    batch: Mapped[str] = mapped_column(String(80), default="")


class Treatment(Base):
    __tablename__ = "lv_treatments"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    animal_id: Mapped[str] = mapped_column(String(32), ForeignKey("lv_animals.id", ondelete="CASCADE"), index=True)
    started_on: Mapped[date] = mapped_column(Date)
    condition: Mapped[str] = mapped_column(String(200))  # entered by a veterinary professional
    treatment: Mapped[str] = mapped_column(Text)
    withdrawal_until: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    vet_name: Mapped[str] = mapped_column(String(120), default="")


class WaterPoint(Base):
    __tablename__ = "lv_water_points"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    farm_id: Mapped[Optional[str]] = mapped_column(String(32), ForeignKey("lv_farms.id", ondelete="SET NULL"), nullable=True)
    name: Mapped[str] = mapped_column(String(120))
    kind: Mapped[str] = mapped_column(String(24))  # borehole | dam | trough | river | charco
    lat: Mapped[float] = mapped_column(Float)
    lon: Mapped[float] = mapped_column(Float)
    capacity_l: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    device_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)


class WaterObservation(Base):
    __tablename__ = "lv_water_observations"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    water_point_id: Mapped[str] = mapped_column(String(32), ForeignKey("lv_water_points.id", ondelete="CASCADE"), index=True)
    observed_at: Mapped[datetime] = created()
    level_pct: Mapped[float] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(16))  # sensor | uav | manual | model
    is_estimate: Mapped[bool] = mapped_column(Boolean, default=False)


class VegetationObservation(Base):
    __tablename__ = "lv_vegetation_observations"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    area_id: Mapped[str] = mapped_column(String(32), ForeignKey("core_areas.id", ondelete="CASCADE"), index=True)
    observed_at: Mapped[datetime] = created()
    ndvi_mean: Mapped[float] = mapped_column(Float)
    ndvi_p10: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    biomass_kg_ha: Mapped[Optional[float]] = mapped_column(Float, nullable=True)  # model estimate from NDVI
    cloud_fraction: Mapped[float] = mapped_column(Float, default=0.0)
    source: Mapped[str] = mapped_column(String(24))  # satellite_sim | uav_multispectral | satellite
    is_estimate: Mapped[bool] = mapped_column(Boolean, default=True)


class MovementEvent(Base):
    """An anomaly found by the movement engine (an observation for a human, not a conclusion)."""

    __tablename__ = "lv_movement_events"
    id: Mapped[str] = pk()
    org_id: Mapped[str] = org_fk()
    animal_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True, index=True)
    herd_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    kind: Mapped[str] = mapped_column(String(32))
    detected_at: Mapped[datetime] = created()
    confidence: Mapped[float] = mapped_column(Float)
    metrics: Mapped[dict] = mapped_column(JSONText, default=dict)
    explanation: Mapped[str] = mapped_column(Text, default="")
    alert_id: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
