"""Small geodesy toolkit: local ENU projection, distances, polygons, coordinate generalisation.

All geometry is EPSG:4326 GeoJSON at rest; algorithms work in a local tangent plane (metres),
which is accurate to well under 1 m over the 50 km extents used by farms and survey areas.
"""

from __future__ import annotations

import math
from typing import Iterable, Sequence

import numpy as np

R_EARTH = 6_371_008.8


def haversine_m(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dphi = p2 - p1
    dl = np.radians(np.asarray(lon2) - np.asarray(lon1))
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2 * R_EARTH * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


class LocalFrame:
    """Equirectangular tangent-plane projection around an origin (east, north in metres)."""

    def __init__(self, lat0: float, lon0: float):
        self.lat0, self.lon0 = float(lat0), float(lon0)
        self.kx = math.cos(math.radians(lat0)) * math.pi / 180 * R_EARTH
        self.ky = math.pi / 180 * R_EARTH

    def to_en(self, lat, lon):
        return (np.asarray(lon) - self.lon0) * self.kx, (np.asarray(lat) - self.lat0) * self.ky

    def to_latlon(self, e, n):
        return self.lat0 + np.asarray(n) / self.ky, self.lon0 + np.asarray(e) / self.kx


def polygon_rings(geometry: dict) -> list[list[list[float]]]:
    """Outer rings of a Polygon / MultiPolygon as [[lon, lat], ...]."""
    t = geometry.get("type")
    if t == "Polygon":
        return [geometry["coordinates"][0]]
    if t == "MultiPolygon":
        return [p[0] for p in geometry["coordinates"]]
    return []


def point_in_ring(lon: float, lat: float, ring: Sequence[Sequence[float]]) -> bool:
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-15) + xi:
            inside = not inside
        j = i
    return inside


def point_in_geometry(lat: float, lon: float, geometry: dict) -> bool:
    t = geometry.get("type")
    if t == "Polygon":
        rings = geometry["coordinates"]
        return point_in_ring(lon, lat, rings[0]) and not any(point_in_ring(lon, lat, h) for h in rings[1:])
    if t == "MultiPolygon":
        return any(point_in_geometry(lat, lon, {"type": "Polygon", "coordinates": p}) for p in geometry["coordinates"])
    return False


def distance_to_ring_m(lat: float, lon: float, ring) -> float:
    """Distance (m) from a point to the boundary of a ring."""
    f = LocalFrame(lat, lon)
    pts = np.array([f.to_en(p[1], p[0]) for p in ring], dtype=float)
    best = math.inf
    for a, b in zip(pts[:-1], pts[1:]):
        ab = b - a
        t = 0.0 if not ab.any() else float(np.clip(-a.dot(ab) / ab.dot(ab), 0, 1))
        best = min(best, float(np.hypot(*(a + t * ab))))
    return best


def bbox_of(geometry: dict) -> tuple[float, float, float, float]:
    """(min_lat, min_lon, max_lat, max_lon)."""
    pts = list(_coords(geometry))
    lats = [p[1] for p in pts]
    lons = [p[0] for p in pts]
    return min(lats), min(lons), max(lats), max(lons)


def _coords(g) -> Iterable[Sequence[float]]:
    c = g["coordinates"] if isinstance(g, dict) else g
    if isinstance(c, (list, tuple)) and c and isinstance(c[0], (int, float)):
        yield c
    else:
        for x in c:
            yield from _coords(x)


def centroid(geometry: dict) -> tuple[float, float]:
    pts = list(_coords(geometry))
    return float(np.mean([p[1] for p in pts])), float(np.mean([p[0] for p in pts]))


def circle_polygon(lat: float, lon: float, radius_m: float, n: int = 32) -> dict:
    f = LocalFrame(lat, lon)
    a = np.linspace(0, 2 * np.pi, n, endpoint=False)
    la, lo = f.to_latlon(radius_m * np.cos(a), radius_m * np.sin(a))
    ring = [[round(float(x), 7), round(float(y), 7)] for x, y in zip(lo, la)]
    return {"type": "Polygon", "coordinates": [ring + [ring[0]]]}


def rect_polygon(lat: float, lon: float, w_m: float, h_m: float, rot_deg: float = 0.0) -> dict:
    f = LocalFrame(lat, lon)
    c, s = math.cos(math.radians(rot_deg)), math.sin(math.radians(rot_deg))
    corners = [(-w_m / 2, -h_m / 2), (w_m / 2, -h_m / 2), (w_m / 2, h_m / 2), (-w_m / 2, h_m / 2)]
    ring = []
    for x, y in corners:
        la, lo = f.to_latlon(x * c - y * s, x * s + y * c)
        ring.append([round(float(lo), 7), round(float(la), 7)])
    return {"type": "Polygon", "coordinates": [ring + [ring[0]]]}


def area_m2(geometry: dict) -> float:
    total = 0.0
    for ring in polygon_rings(geometry):
        la0, lo0 = ring[0][1], ring[0][0]
        f = LocalFrame(la0, lo0)
        e, n = f.to_en(np.array([p[1] for p in ring]), np.array([p[0] for p in ring]))
        total += 0.5 * abs(float(np.dot(e, np.roll(n, -1)) - np.dot(n, np.roll(e, -1))))
    return total


GENERALIZE_DEG = 0.1  # ~11 km grid


def generalize(lat: float | None, lon: float | None, step: float = GENERALIZE_DEG):
    """Snap a coordinate to the centre of a coarse grid cell (used to protect sensitive sites)."""
    if lat is None or lon is None:
        return lat, lon
    return (math.floor(lat / step) + 0.5) * step, (math.floor(lon / step) + 0.5) * step
