"""Report export to CSV, Excel (.xlsx) and PDF — standard library only (runs in the browser edition too).

The .xlsx writer produces a minimal valid Office Open XML workbook (one sheet per table, inline strings).
The PDF writer produces PDF 1.4 with the built-in Helvetica font, wrapped text and simple tables.
"""

from __future__ import annotations

import csv
import io
import zipfile
from datetime import datetime, timezone
from xml.sax.saxutils import escape


def to_csv(sections: list[dict]) -> bytes:
    """sections: [{title, columns, rows}] -> CSV with a blank line between sections."""
    buf = io.StringIO()
    w = csv.writer(buf)
    for i, s in enumerate(sections):
        if i:
            w.writerow([])
        w.writerow([f"# {s['title']}"])
        w.writerow(s["columns"])
        for r in s["rows"]:
            w.writerow(["" if v is None else v for v in r])
    return buf.getvalue().encode("utf-8-sig")


def _col(n: int) -> str:
    s = ""
    n += 1
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _cell(ref: str, v) -> str:
    if v is None:
        return f'<c r="{ref}"/>'
    if isinstance(v, bool):
        return f'<c r="{ref}" t="b"><v>{int(v)}</v></c>'
    if isinstance(v, (int, float)):
        return f'<c r="{ref}"><v>{v}</v></c>'
    return f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{escape(str(v))}</t></is></c>'


def to_xlsx(sections: list[dict], meta: list[tuple[str, str]] | None = None) -> bytes:
    sheets = []
    if meta:
        sheets.append(("About", {"columns": ["Field", "Value"], "rows": [list(m) for m in meta]}))
    for s in sections:
        name = "".join(ch for ch in s["title"] if ch not in "[]:*?/\\")[:31] or "Sheet"
        base, k = name, 2
        while any(n == name for n, _ in sheets):
            name = f"{base[:28]} {k}"
            k += 1
        sheets.append((name, s))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                             for i in range(len(sheets)))
                   + "</Types>")
        z.writestr("_rels/.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                   "</Relationships>")
        z.writestr("xl/workbook.xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                   'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                   + "".join(f'<sheet name="{escape(n)}" sheetId="{i + 1}" r:id="rId{i + 1}"/>' for i, (n, _) in enumerate(sheets))
                   + "</sheets></workbook>")
        z.writestr("xl/_rels/workbook.xml.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>'
                             for i in range(len(sheets)))
                   + "</Relationships>")
        for i, (_, s) in enumerate(sheets):
            rows = [s["columns"]] + list(s["rows"])
            xml = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
            for r, row in enumerate(rows):
                xml.append(f'<row r="{r + 1}">' + "".join(_cell(f"{_col(c)}{r + 1}", v) for c, v in enumerate(row)) + "</row>")
            xml.append("</sheetData></worksheet>")
            z.writestr(f"xl/worksheets/sheet{i + 1}.xml", "".join(xml))
    return buf.getvalue()


# ----------------------------------------------------------------------------- PDF

_W = {c: 0.556 for c in "abcdeghnopqu0123456789"}
_W.update({c: 0.5 for c in "ksvxyz"}); _W.update({c: 0.278 for c in "fijlt.,;:!'| "}); _W.update({"r": 0.333, "m": 0.833, "w": 0.722})


def _text_w(s: str, size: float) -> float:
    return sum(_W.get(ch, 0.667 if ch.isupper() else 0.556) for ch in s) * size


def _pdf_str(s: str) -> str:
    s = s.encode("latin-1", "replace").decode("latin-1")
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _wrap(s: str, size: float, width: float) -> list[str]:
    out, line = [], ""
    for word in str(s).split():
        cand = (line + " " + word).strip()
        if _text_w(cand, size) <= width or not line:
            line = cand
        else:
            out.append(line)
            line = word
    out.append(line)
    return out


class _PDF:
    W, H, M = 595.0, 842.0, 50.0

    def __init__(self):
        self.pages: list[list[str]] = []
        self.new_page()

    def new_page(self):
        self.ops: list[str] = []
        self.pages.append(self.ops)
        self.y = self.H - self.M

    def text(self, s, size=10, bold=False, x=None, color=(0, 0, 0)):
        if self.y < self.M + size:
            self.new_page()
        f = "F2" if bold else "F1"
        self.ops.append(f"{color[0]} {color[1]} {color[2]} rg BT /{f} {size} Tf {x or self.M} {self.y:.1f} Td ({_pdf_str(s)}) Tj ET")

    def para(self, s, size=10, bold=False, gap=3, color=(0, 0, 0)):
        for ln in _wrap(s, size, self.W - 2 * self.M):
            self.text(ln, size, bold, color=color)
            self.y -= size + gap
        self.y -= gap

    def table(self, columns, rows, size=8):
        n = len(columns)
        cw = (self.W - 2 * self.M) / max(n, 1)

        def clip(v):
            s = "" if v is None else str(v)
            while s and _text_w(s, size) > cw - 4:
                s = s[:-2] + "…" if len(s) > 2 else ""
            return s

        def row(vals, bold=False):
            if self.y < self.M + 20:
                self.new_page()
            for i, v in enumerate(vals):
                self.text(clip(v), size, bold, x=self.M + i * cw)
            self.y -= size + 4

        row(columns, True)
        self.ops.append(f"0.6 0.6 0.6 RG {self.M} {self.y + size:.1f} m {self.W - self.M} {self.y + size:.1f} l S")
        for r in rows:
            row(r)
        self.y -= 6

    def render(self) -> bytes:
        objs = []
        objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
        kids = " ".join(f"{5 + 2 * i} 0 R" for i in range(len(self.pages)))
        objs.append(f"<< /Type /Pages /Kids [{kids}] /Count {len(self.pages)} >>".encode())
        objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        for i, ops in enumerate(self.pages):
            footer = f"0.4 0.4 0.4 rg BT /F1 8 Tf {self.M} 25 Td (AICN report - page {i + 1} of {len(self.pages)}) Tj ET"
            stream = "\n".join(ops + [footer]).encode("latin-1", "replace")
            objs.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {self.W:.0f} {self.H:.0f}] "
                        f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {6 + 2 * i} 0 R >>".encode())
            objs.append(b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream")
        out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offsets = []
        for k, o in enumerate(objs):
            offsets.append(len(out))
            out += f"{k + 1} 0 obj\n".encode() + o + b"\nendobj\n"
        xref = len(out)
        out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
        for off in offsets:
            out += f"{off:010d} 00000 n \n".encode()
        out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
        return bytes(out)


def to_pdf(title: str, meta: list[tuple[str, str]], paragraphs: list[str], sections: list[dict]) -> bytes:
    p = _PDF()
    p.para(title, 16, True, gap=6)
    p.para("Generated " + datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), 8, color=(0.4, 0.4, 0.4))
    for k, v in meta:
        p.para(f"{k}: {v}", 9)
    for para in paragraphs:
        p.para(para, 10)
    for s in sections:
        p.para(s["title"], 11, True, gap=4)
        if s.get("note"):
            p.para(s["note"], 8, color=(0.35, 0.35, 0.35))
        p.table(s["columns"], s["rows"][:400])
    return p.render()
