"""Livestock digital twin: herds, individual animals, smart collars, LoRaWAN gateway, water points, pasture.

Ground truth (true positions, true illness, true collar state) lives only in this module.
What reaches the platform is what a real deployment would see: collar records that pass through
the store-and-forward buffer, the radio link and the ingest service, with noise, gaps and delays.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta

import numpy as np
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..engines.codec import CollarBuffer, b64, encode_batch
from ..geo import LocalFrame, polygon_rings
from ..models import Animal, Area, Device, Farm, Herd, VegetationObservation, WaterPoint
from ..services import devices as device_svc

EAT = 3.0
MODE_SPEED = {"rest": 0.0, "graze": 0.08, "walk": 0.7, "drink": 0.02, "flee": 1.4}
MODE_SPREAD = {"rest": 8.0, "graze": 40.0, "walk": 15.0, "drink": 18.0, "flee": 25.0}
MODE_ACT = {"rest": 0.03, "graze": 0.12, "walk": 0.24, "drink": 0.08, "flee": 0.42}
MODE_REST = {"rest": 0.78, "graze": 0.12, "walk": 0.02, "drink": 0.2, "flee": 0.0}
SIZE = {"cattle": (2.2, 0.8), "goat": (1.1, 0.45), "sheep": (1.2, 0.5)}


def local_hour(t: datetime) -> float:
    return (t.hour + t.minute / 60 + EAT) % 24


@dataclass
class SimAnimal:
    id: str
    tag: str
    herd_id: str
    species: str
    device_id: str | None
    e: float = 0.0
    n: float = 0.0
    oe: float = 0.0
    on: float = 0.0
    act_mult: float = 1.0
    temp_off: float = 0.0
    illness: float = 0.0  # 0..1 severity (truth)
    stray: tuple | None = None  # (dir_e, dir_n, speed, until_dist)
    alive: bool = True


@dataclass
class SimCollar:
    device_id: str
    animal_id: str | None
    buf: CollarBuffer
    battery: float = 100.0
    drain_mult: float = 1.0
    failed: bool = False
    dropped_at: tuple | None = None  # collar fell off: stays at (e, n)
    temp_bias: float = 0.0
    next_uplink: float = 0.0


@dataclass
class SimHerd:
    id: str
    farm_id: str
    species: str
    grazing: np.ndarray  # polygon EN
    boma: tuple
    water: tuple | None
    ce: float = 0.0
    cn: float = 0.0
    target: tuple = (0.0, 0.0)
    mode: str = "rest"
    retarget_at: float = 0.0
    breach_until: float = 0.0
    breach_target: tuple | None = None
    flee_until: float = 0.0
    flee_dir: tuple = (1.0, 0.0)


@dataclass
class SimFarm:
    id: str
    frame: LocalFrame
    boundary: np.ndarray | None
    climate: dict
    herds: list = field(default_factory=list)
    gateway_range_m: float = 6000.0


def _poly_en(frame: LocalFrame, geom: dict) -> np.ndarray:
    ring = polygon_rings(geom)[0]
    e, n = frame.to_en(np.array([p[1] for p in ring]), np.array([p[0] for p in ring]))
    return np.stack([e, n], 1)


def _pip(x, y, poly) -> bool:
    inside = False
    for (x1, y1), (x2, y2) in zip(poly[:-1], poly[1:]):
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / ((y2 - y1) or 1e-12) + x1:
            inside = not inside
    return inside


def _rand_in(poly: np.ndarray, rng, margin=0.15) -> tuple:
    lo, hi = poly.min(0), poly.max(0)
    span = hi - lo
    for _ in range(200):
        x, y = lo + span * (margin + (1 - 2 * margin) * rng.random(2))
        if _pip(x, y, poly):
            return float(x), float(y)
    c = poly[:-1].mean(0)
    return float(c[0]), float(c[1])


class LivestockSim:
    def __init__(self, db: Session, org_id: str, rng: np.random.Generator):
        self.org_id = org_id
        self.rng = rng
        self.farms: dict[str, SimFarm] = {}
        self.herds: dict[str, SimHerd] = {}
        self.animals: dict[str, SimAnimal] = {}
        self.collars: dict[str, SimCollar] = {}
        self.water: dict[str, dict] = {}
        self.ndvi: dict[str, float] = {}
        self.gateway_down_until: float = 0.0
        self.drought = False
        self.pump_failure: set[str] = set()
        self.load(db)

    # ---------------------------------------------------------------- load from DB
    def load(self, db: Session):
        rng = self.rng
        for f in db.scalars(select(Farm).where(Farm.org_id == self.org_id)):
            fr = LocalFrame(f.lat, f.lon)
            b = db.get(Area, f.boundary_area_id) if f.boundary_area_id else None
            climate = (b.properties or {}).get("climate", {"mean_c": 26.0, "amp_c": 4.0}) if b else {"mean_c": 26.0, "amp_c": 4.0}
            sf = SimFarm(f.id, fr, _poly_en(fr, b.geometry) if b else None, climate)
            self.farms[f.id] = sf
            wps = list(db.scalars(select(WaterPoint).where(WaterPoint.farm_id == f.id)))
            for w in wps:
                we, wn = fr.to_en(w.lat, w.lon)
                self.water[w.id] = {"id": w.id, "farm": f.id, "e": float(we), "n": float(wn), "level": 75.0,
                                    "capacity": w.capacity_l or 20000.0, "kind": w.kind, "device_id": w.device_id,
                                    "seq": 0, "lat": w.lat, "lon": w.lon}
            for h in db.scalars(select(Herd).where(Herd.farm_id == f.id)):
                ga = db.get(Area, h.grazing_area_id) if h.grazing_area_id else b
                water = None
                if wps:
                    water = (self.water[wps[0].id]["e"], self.water[wps[0].id]["n"])
                sh = SimHerd(h.id, f.id, h.species, _poly_en(fr, ga.geometry), (0.0, 0.0), water)
                sh.ce, sh.cn = 0.0, 0.0
                self.herds[h.id] = sh
                sf.herds.append(h.id)
                if ga is not None:
                    self.ndvi.setdefault(ga.id, (ga.properties or {}).get("ndvi_now", 0.5))
        devs = {d.animal_id: d for d in db.scalars(select(Device).where(Device.org_id == self.org_id, Device.animal_id.isnot(None)))}
        for a in db.scalars(select(Animal).where(Animal.org_id == self.org_id, Animal.status.in_(["active", "missing"]))):
            self.add_animal(a, devs.get(a.id))

    def add_animal(self, a: Animal, dev: Device | None):
        rng = self.rng
        h = self.herds.get(a.herd_id)
        if h is None:
            return
        fr = self.farms[h.farm_id].frame
        if a.last_lat is not None:
            e, n = fr.to_en(a.last_lat, a.last_lon)
        else:
            e, n = h.ce + rng.normal(0, 8), h.cn + rng.normal(0, 8)
        sa = SimAnimal(a.id, a.tag, h.id, a.species, dev.id if dev else None, float(e), float(n),
                       float(e) - h.ce, float(n) - h.cn, float(rng.normal(1, 0.1)), float(rng.normal(0, 0.3)))
        self.animals[a.id] = sa
        if dev:
            buf = CollarBuffer(2000)
            buf.next_seq = dev.last_seq + 1
            self.collars[dev.id] = SimCollar(dev.id, a.id, buf, dev.battery_pct if dev.battery_pct is not None else 100.0,
                                             next_uplink=0.0)

    # ---------------------------------------------------------------- dynamics
    def ambient(self, farm: SimFarm, t: datetime) -> float:
        h = local_hour(t)
        return farm.climate["mean_c"] + farm.climate["amp_c"] * math.sin(2 * math.pi * (h - 9) / 24)

    def _herd_mode(self, h: SimHerd, t: datetime, ts: float):
        hr = local_hour(t)
        if ts < h.flee_until:
            return "flee", None
        if ts < h.breach_until and h.breach_target:
            return "walk", h.breach_target
        if hr >= 19 or hr < 6.5:
            return ("rest" if math.hypot(h.ce - h.boma[0], h.cn - h.boma[1]) < 30 else "walk"), h.boma
        if 17.5 <= hr < 19:
            return "walk", h.boma
        if 11 <= hr < 12.2 and h.water:
            near = math.hypot(h.ce - h.water[0], h.cn - h.water[1]) < 35
            return ("drink" if near else "walk"), h.water
        if ts >= h.retarget_at or not _pip(h.target[0], h.target[1], h.grazing):
            h.target = _rand_in(h.grazing, self.rng)
            h.retarget_at = ts + self.rng.uniform(3600, 7200)
        near = math.hypot(h.ce - h.target[0], h.cn - h.target[1]) < 60
        return ("graze" if near else "walk"), h.target

    def step(self, t: datetime, dt: float, weather: dict) -> None:
        ts = t.timestamp()
        rng = self.rng
        for h in self.herds.values():
            mode, tgt = self._herd_mode(h, t, ts)
            h.mode = mode
            if mode == "flee":
                h.ce += h.flee_dir[0] * MODE_SPEED["flee"] * dt * 0.5
                h.cn += h.flee_dir[1] * MODE_SPEED["flee"] * dt * 0.5
            elif tgt is not None:
                dx, dy = tgt[0] - h.ce, tgt[1] - h.cn
                d = math.hypot(dx, dy)
                v = MODE_SPEED["walk"] if mode == "walk" else MODE_SPEED[mode]
                stepd = min(d, v * dt)
                if d > 1e-6:
                    h.ce += dx / d * stepd
                    h.cn += dy / d * stepd
                if mode == "graze":
                    h.ce += rng.normal(0, 6)
                    h.cn += rng.normal(0, 6)
        tau = 1800.0
        a_ = math.exp(-dt / tau)
        for a in self.animals.values():
            if not a.alive:
                continue
            h = self.herds[a.herd_id]
            spread = MODE_SPREAD[h.mode] * (1.5 if a.species == "goat" else 1.0)
            if a.stray:
                de, dn, sp, until = a.stray
                if math.hypot(a.oe, a.on) < until:
                    a.oe += de * sp * dt
                    a.on += dn * sp * dt
            else:
                a.oe = a.oe * a_ + spread * math.sqrt(1 - a_ * a_) * rng.normal()
                a.on = a.on * a_ + spread * math.sqrt(1 - a_ * a_) * rng.normal()
            te, tn = h.ce + a.oe, h.cn + a.on
            if a.illness > 0.3:  # lags behind the herd
                te = a.e + (te - a.e) * (1 - 0.7 * a.illness)
                tn = a.n + (tn - a.n) * (1 - 0.7 * a.illness)
                a.oe, a.on = te - h.ce, tn - h.cn
            a.e, a.n = te, tn

    def collar_records(self, t: datetime, weather: dict) -> None:
        """Every 15 min each working collar samples its sensors into its on-board buffer."""
        rng = self.rng
        for c in self.collars.values():
            if c.failed or c.battery <= 0:
                continue
            a = self.animals.get(c.animal_id)
            if a is None:
                continue
            h = self.herds[a.herd_id]
            farm = self.farms[h.farm_id]
            amb = self.ambient(farm, t) + rng.normal(0, 0.3)
            if c.dropped_at:
                e, n = c.dropped_at
                mode = "rest"
                act = 0.004 + abs(rng.normal(0, 0.002))
                rest = 1.0
                temp = amb + rng.normal(0, 0.4)  # lying on the ground: ambient temperature
                spd = 0.0
            else:
                e, n = a.e, a.n
                mode = h.mode if not a.stray else "walk"
                ill = a.illness
                act = max(0.005, MODE_ACT[mode] * a.act_mult * (1 - 0.6 * ill) + rng.normal(0, 0.015))
                rest = float(np.clip(MODE_REST[mode] + 0.4 * ill + rng.normal(0, 0.06), 0, 1))
                temp = 0.35 * amb + 22.5 + a.temp_off + 1.6 * ill + rng.normal(0, 0.25)
                spd = max(0.0, MODE_SPEED["walk" if mode == "walk" else mode] * (1 - 0.5 * ill) + rng.normal(0, 0.05))
            temp += c.temp_bias
            hdop = float(np.clip(rng.gamma(4, 0.3), 0.7, 6))
            fix = rng.random() > 0.03
            la, lo = farm.frame.to_latlon(e + rng.normal(0, 2.5 * hdop), n + rng.normal(0, 2.5 * hdop))
            water = False
            for w in self.water.values():
                if w["farm"] == h.farm_id and math.hypot(e - w["e"], n - w["n"]) < 40:
                    water = True
            c.battery = max(0.0, c.battery - 0.03 * c.drain_mult)
            c.buf.push({"t": int(t.timestamp()), "lat": round(float(la), 6) if fix else None,
                        "lon": round(float(lo), 6) if fix else None, "hdop": round(hdop, 1) if fix else None,
                        "speed_mps": round(spd, 2), "activity": round(act, 3), "rest_fraction": round(rest, 2),
                        "temp_c": round(temp, 1), "ambient_c": round(amb, 1), "battery_pct": round(c.battery, 1),
                        "rssi": None, "water_visit": water})

    def uplink(self, db: Session, t: datetime) -> dict:
        """Hourly LoRaWAN uplink attempt per collar; on ACK the buffer is freed. Returns link statistics."""
        stats = {"attempts": 0, "delivered": 0, "buffered": 0, "records": 0}
        ts = t.timestamp()
        gw_up = ts >= self.gateway_down_until
        for c in self.collars.values():
            if c.failed or c.battery <= 0 or ts < c.next_uplink or not len(c.buf):
                stats["buffered"] += len(c.buf)
                continue
            c.next_uplink = ts + 3600
            a = self.animals.get(c.animal_id)
            h = self.herds[a.herd_id] if a else None
            pos = c.dropped_at or ((a.e, a.n) if a else (0, 0))
            dist = math.hypot(pos[0], pos[1])
            rng_m = self.farms[h.farm_id].gateway_range_m if h else 0
            stats["attempts"] += 1
            if not gw_up or dist > rng_m or self.rng.random() < 0.05 + 0.25 * (dist / max(rng_m, 1)) ** 4:
                stats["buffered"] += len(c.buf)
                continue
            batch = c.buf.pending(96)
            for r in batch:
                r["rssi"] = round(-80 - 30 * dist / rng_m + self.rng.normal(0, 3))
            dev = db.get(Device, c.device_id)
            res = device_svc.ingest(db, dev, {"encoding": "ac1", "data": b64(encode_batch(batch)), "dropped": c.buf.dropped}, now=t)
            c.buf.ack(res["ack_seq"])
            c.battery = max(0.0, c.battery - 0.08 * c.drain_mult)
            stats["delivered"] += 1
            stats["records"] += res["accepted"]
            stats["buffered"] += len(c.buf)
        return stats

    def water_step(self, db: Session, t: datetime, dt: float, hourly: bool):
        rng = self.rng
        hr = local_hour(t)
        for w in self.water.values():
            drinkers = 0
            for a in self.animals.values():
                h = self.herds[a.herd_id]
                if h.farm_id == w["farm"] and math.hypot(a.e - w["e"], a.n - w["n"]) < 40:
                    drinkers += 1
            use_l = drinkers * (35 if True else 0) * dt / 900 * 0.5
            evap = (0.006 if self.drought else 0.003) * dt / 3600
            w["level"] = max(0.0, w["level"] - 100 * use_l / w["capacity"] - evap)
            if w["kind"] == "borehole" and abs(hr - 7.0) < dt / 7200 and w["id"] not in self.pump_failure and not self.drought:
                w["level"] = max(w["level"], 88.0)
            if w["kind"] in ("dam", "charco") and not self.drought and rng.random() < 0.002 * dt / 900:
                w["level"] = min(100.0, w["level"] + rng.uniform(5, 15))
            if hourly and w["device_id"]:
                dev = db.get(Device, w["device_id"])
                if dev:
                    rec = {"seq": dev.last_seq + 1, "t": int(t.timestamp()),
                           "values": {"water_level": round(w["level"] + rng.normal(0, 0.8), 1)},
                           "units": {"water_level": "%"}}
                    if self.gateway_down_until <= t.timestamp():
                        device_svc.ingest(db, dev, {"encoding": "json", "records": [rec]}, now=t)

    def vegetation_step(self, db: Session, t: datetime, dt: float):
        days = dt / 86400
        in_use = {}
        for h in self.herds.values():
            in_use[h.id] = h
        for area_id in list(self.ndvi):
            v = self.ndvi[area_id]
            trend = -0.006 if self.drought else 0.0015  # Nov: short rains ("vuli") greening
            grazed = any(True for h in self.herds.values())  # pressure is applied below per grazing area
            self.ndvi[area_id] = float(np.clip(v + trend * days - (0.0015 * days if grazed else 0), 0.08, 0.85))

    def satellite_pass(self, db: Session, t: datetime):
        """Simulated optical satellite pass: one NDVI estimate per grazing area unless clouds hide it."""
        cloud = float(np.clip(self.rng.beta(2, 3), 0, 1))
        for area_id, v in self.ndvi.items():
            if cloud > 0.7:
                continue
            obs = float(np.clip(v + self.rng.normal(0, 0.02) - 0.1 * cloud * self.rng.random(), 0, 1))
            from ..engines.environment import biomass_estimate

            db.add(VegetationObservation(org_id=self.org_id, area_id=area_id, observed_at=t, ndvi_mean=round(obs, 3),
                                         ndvi_p10=round(obs - 0.08, 3), cloud_fraction=round(cloud, 2),
                                         biomass_kg_ha=biomass_estimate(obs)["biomass_kg_ha"], source="satellite_sim",
                                         is_estimate=True))

    # ---------------------------------------------------------------- truth access
    def truth(self) -> list[dict]:
        out = []
        for a in self.animals.values():
            h = self.herds[a.herd_id]
            fr = self.farms[h.farm_id].frame
            la, lo = fr.to_latlon(a.e, a.n)
            c = self.collars.get(a.device_id) if a.device_id else None
            out.append({"id": a.id, "tag": a.tag, "species": a.species, "lat": float(la), "lon": float(lo),
                        "herd_mode": h.mode, "illness": round(a.illness, 2), "straying": bool(a.stray),
                        "collar": None if not c else {"failed": c.failed, "dropped": bool(c.dropped_at),
                                                      "battery": round(c.battery, 1), "buffered": len(c.buf),
                                                      "temp_bias": c.temp_bias}})
        return out

    def objects(self) -> list[dict]:
        """Physical bodies for the synthetic camera (thermal)."""
        out = []
        for a in self.animals.values():
            h = self.herds[a.herd_id]
            fr = self.farms[h.farm_id].frame
            la, lo = fr.to_latlon(a.e, a.n)
            L, W = SIZE.get(a.species, (1.5, 0.6))
            out.append({"id": a.id, "kind": a.species, "lat": float(la), "lon": float(lo), "length": L, "width": W,
                        "heading": float(self.rng.uniform(0, 2 * math.pi)), "visible": True,
                        "surface_temp": None, "illness": a.illness})
        return out

    def farm_ambient(self, lat: float, lon: float, t: datetime) -> float:
        f = min(self.farms.values(), key=lambda f: math.hypot(*f.frame.to_en(lat, lon)))
        return self.ambient(f, t)
