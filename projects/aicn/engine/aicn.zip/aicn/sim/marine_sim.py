"""Marine digital twin: coastal waters, sea turtles, dolphin pods, dugong, rays, sharks, floating debris,
a nesting beach with nesting females and hatching, and an environmental buoy.

Ground truth stays here. The platform only receives what sensors, rangers and survey flights would report.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta

import numpy as np
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..geo import LocalFrame, centroid, polygon_rings
from ..models import Area, Device, Nest, NestEvent
from ..services import devices as device_svc
from .livestock_sim import local_hour

# group: (length m, width m, speed m/s, mean surface s, mean dive s, colour RGB)
PROFILES = {
    "sea_turtle": (1.0, 0.8, 0.3, 25, 170, (92, 78, 48)),
    "dolphin": (2.4, 0.6, 1.6, 4, 22, (95, 102, 110)),
    "dugong": (2.8, 0.9, 0.5, 20, 150, (120, 105, 95)),
    "ray": (2.2, 2.0, 0.6, 30, 120, (35, 38, 44)),
    "shark": (2.6, 0.6, 0.8, 60, 200, (70, 84, 96)),
    "debris": (0.9, 0.5, 0.0, 1e9, 1.0, (215, 210, 196)),
}
DEFAULT_POPULATION = {"sea_turtle": 22, "dolphin_pods": [9, 12], "dugong": 1, "ray": 5, "shark": 2, "debris": 6}


@dataclass
class SimMarineAnimal:
    id: str
    group: str
    e: float
    n: float
    heading: float
    speed: float
    visible: bool
    timer: float
    pod: int | None = None
    entangled: bool = False
    frames_seen: int = 0


@dataclass
class SimNestTruth:
    e: float
    n: float
    laid: datetime
    recorded: bool = False
    nest_id: str | None = None


class MarineSim:
    def __init__(self, db: Session, org_id: str, rng: np.random.Generator, population: dict | None = None):
        self.org_id = org_id
        self.rng = rng
        self.animals: list[SimMarineAnimal] = []
        self.pods: dict[int, dict] = {}
        self.nests: list[SimNestTruth] = []
        self.heat_anomaly_c = 0.0
        self.turbidity_event = 0.0
        self.current = (0.12, 0.05)
        self.frame = None
        self.habitat = None
        self.beach = None
        self.beach_area = None
        self.buoy = None
        self.nesting_females = 3
        self.load(db, population or DEFAULT_POPULATION)

    def load(self, db: Session, pop: dict):
        areas = list(db.scalars(select(Area).where(Area.org_id == self.org_id, Area.domain == "marine")))
        core = next((a for a in areas if a.kind == "survey_area"), None) or next((a for a in areas if a.kind == "marine_protected_area"), None)
        if core is None:
            return
        la, lo = centroid(core.geometry)
        self.frame = LocalFrame(la, lo)
        ring = polygon_rings(core.geometry)[0]
        e, n = self.frame.to_en(np.array([p[1] for p in ring]), np.array([p[0] for p in ring]))
        self.habitat = (float(e.min()), float(n.min()), float(e.max()), float(n.max()))
        beach = next((a for a in areas if a.kind == "nesting_beach"), None)
        if beach:
            self.beach_area = beach
            ring = polygon_rings(beach.geometry)[0]
            be, bn = self.frame.to_en(np.array([p[1] for p in ring]), np.array([p[0] for p in ring]))
            self.beach = np.stack([be, bn], 1)
        self.buoy = db.scalar(select(Device).where(Device.org_id == self.org_id, Device.device_type == "env_sensor",
                                                   Device.domain == "marine"))
        k = 0
        x0, y0, x1, y1 = self.habitat
        for group in ("sea_turtle", "dugong", "ray", "shark", "debris"):
            for _ in range(int(pop.get(group, 0))):
                k += 1
                L, W, sp, ms, md, _ = PROFILES[group]
                self.animals.append(SimMarineAnimal(f"M{k}", group, self.rng.uniform(x0, x1), self.rng.uniform(y0, y1),
                                                    self.rng.uniform(0, 2 * math.pi), sp * self.rng.uniform(0.6, 1.2),
                                                    self.rng.random() < ms / (ms + md), self.rng.exponential(ms)))
        for pi, size in enumerate(pop.get("dolphin_pods", [])):
            self.pods[pi] = {"e": self.rng.uniform(x0, x1), "n": self.rng.uniform(y0, y1),
                             "heading": self.rng.uniform(0, 2 * math.pi)}
            for _ in range(int(size)):
                k += 1
                self.animals.append(SimMarineAnimal(f"M{k}", "dolphin", self.pods[pi]["e"] + self.rng.normal(0, 12),
                                                    self.pods[pi]["n"] + self.rng.normal(0, 12), self.pods[pi]["heading"],
                                                    1.6, self.rng.random() < 0.15, self.rng.exponential(4), pod=pi))

    # ---------------------------------------------------------------- dynamics
    def step(self, dt: float, fine: bool = False):
        """Advance animals. `fine` is used during survey flights (seconds); otherwise large steps reposition."""
        if self.frame is None:
            return
        x0, y0, x1, y1 = self.habitat
        pad = 60  # animals favour the core habitat (seagrass / patch reef)
        rng = self.rng
        for pod in self.pods.values():
            pod["heading"] += rng.normal(0, 0.08 * math.sqrt(dt / 10))
            pod["e"] += math.sin(pod["heading"]) * 1.4 * min(dt, 600)
            pod["n"] += math.cos(pod["heading"]) * 1.4 * min(dt, 600)
            if not (x0 - pad < pod["e"] < x1 + pad):
                pod["heading"] = -pod["heading"]
                pod["e"] = float(np.clip(pod["e"], x0 - pad, x1 + pad))
            if not (y0 - pad < pod["n"] < y1 + pad):
                pod["heading"] = math.pi - pod["heading"]
                pod["n"] = float(np.clip(pod["n"], y0 - pad, y1 + pad))
        for a in self.animals:
            L, W, sp, ms, md, _ = PROFILES[a.group]
            if a.group == "debris":
                a.e += self.current[0] * dt * 0.3
                a.n += self.current[1] * dt * 0.3
            elif a.pod is not None:
                pod = self.pods[a.pod]
                a.heading = pod["heading"] + rng.normal(0, 0.15)
                a.e += (pod["e"] - a.e) * min(1, dt / 30) + rng.normal(0, 2 * math.sqrt(min(dt, 60)))
                a.n += (pod["n"] - a.n) * min(1, dt / 30) + rng.normal(0, 2 * math.sqrt(min(dt, 60)))
            elif a.entangled:
                a.e += self.current[0] * dt * 0.2
                a.n += self.current[1] * dt * 0.2
                a.visible = True
                continue
            else:
                a.heading += rng.normal(0, 0.3 * math.sqrt(min(dt, 600) / 60))
                d = a.speed * (min(dt, 600) if fine else min(dt, 900) * 0.3)
                a.e += math.sin(a.heading) * d
                a.n += math.cos(a.heading) * d
            if not (x0 - pad < a.e < x1 + pad):
                a.heading = -a.heading
                a.e = float(np.clip(a.e, x0 - pad, x1 + pad))
            if not (y0 - pad < a.n < y1 + pad):
                a.heading = math.pi - a.heading
                a.n = float(np.clip(a.n, y0 - pad, y1 + pad))
            if fine:
                a.timer -= dt
                if a.timer <= 0:
                    a.visible = not a.visible
                    a.timer = rng.exponential(ms if a.visible else md)
            else:
                a.visible = rng.random() < ms / (ms + md)
                a.timer = rng.exponential(ms if a.visible else md)

    def nesting_step(self, db: Session, t: datetime, dt: float, beach_events: list):
        """Night: females may nest. Morning patrol: rangers record new nests (85% found). Daily: hatching / inundation."""
        if self.beach is None:
            return
        hr = local_hour(t)
        prev = local_hour(t - timedelta(seconds=dt))
        crossed = lambda h: (prev < h <= hr) or (prev > hr and (h > prev or h <= hr))  # noqa: E731
        rng = self.rng
        if crossed(1.0):
            for _ in range(self.nesting_females):
                if rng.random() < 0.18:
                    c = self.beach[:-1].mean(0)
                    span = self.beach.max(0) - self.beach.min(0)
                    pt = c + (rng.random(2) - 0.5) * span * 0.6
                    self.nests.append(SimNestTruth(float(pt[0]), float(pt[1]), t))
        if crossed(6.5):
            from ..rbac import Principal
            from ..services import marine as marine_svc

            sysp = Principal(org_id=self.org_id, role="conservation_officer", name="Ranger patrol (simulated)", kind="system")
            for nt in self.nests:
                if nt.recorded or (t - nt.laid).total_seconds() > 36 * 3600:
                    continue
                if rng.random() < 0.85:
                    la, lo = self.frame.to_latlon(nt.e + rng.normal(0, 2), nt.n + rng.normal(0, 2))
                    count = db.scalar(select(func.count()).select_from(Nest).where(Nest.org_id == self.org_id)) or 0
                    d = marine_svc.create_nest(db, sysp, {"beach_area_id": self.beach_area.id, "code": f"N-{count + 1:03d}",
                                                          "species_id": "chelonia_mydas", "lat": float(la), "lon": float(lo),
                                                          "laid_on": (t - timedelta(hours=6)).date().isoformat(),
                                                          "clutch_size": int(rng.integers(90, 130)),
                                                          "notes": "recorded on morning patrol (simulated ranger)"})
                    nt.recorded, nt.nest_id = True, d["id"]
                    beach_events.append(("nest_recorded", d["id"]))
                else:
                    nt.recorded = True  # missed by the patrol: stays only in ground truth
            # hatching and inundation on recorded nests
            for n in db.scalars(select(Nest).where(Nest.org_id == self.org_id, Nest.status == "incubating")):
                if n.expected_hatch_from and t.date() >= n.expected_hatch_from and rng.random() < 0.3:
                    emerged = int((n.clutch_size or 100) * rng.uniform(0.55, 0.9))
                    marine_svc.add_nest_event(db, sysp, n.id, {"kind": "hatching", "hatchlings_emerged": emerged,
                                                               "detail": f"emergence tracks counted: ~{emerged} hatchlings"}, now=t)
                    beach_events.append(("hatching", n.id))
                elif rng.random() < 0.02:
                    marine_svc.add_nest_event(db, sysp, n.id, {"kind": "inundation",
                                                               "detail": "high spring tide reached the nest area"}, now=t)
                    from ..services import alerts

                    alerts.raise_alert(db, self.org_id, "marine", "nest_threat", f"Nest {n.code}: tidal inundation",
                                       "A high tide reached this nest. Consider relocation per the beach protocol "
                                       "(decision for the conservation officer).", subject_type="nest", subject_id=n.id,
                                       lat=n.lat, lon=n.lon, sensitive=True, confidence=0.9, dedupe_key=f"nest:{n.id}")
                    beach_events.append(("inundation", n.id))

    def buoy_step(self, db: Session, t: datetime):
        if not self.buoy:
            return
        dev = db.get(Device, self.buoy.id)
        hr = local_hour(t)
        rng = self.rng
        temp = 27.8 + 0.5 * math.sin(2 * math.pi * (hr - 14) / 24) + self.heat_anomaly_c + rng.normal(0, 0.05)
        turb = max(0.3, 1.4 + self.turbidity_event + abs(rng.normal(0, 0.25)))
        clarity = 18.0 / (1 + 0.6 * turb)
        if self.turbidity_event > 0:
            self.turbidity_event *= 0.93
        q = {}
        if rng.random() < 0.02:
            temp += rng.choice([-6, 6])  # occasional sensor spike: QC flags it
            q["water_temp"] = "suspect"
        rec = {"seq": dev.last_seq + 1, "t": int(t.timestamp()),
               "values": {"water_temp": round(temp, 2), "turbidity": round(turb, 2), "water_clarity": round(clarity, 1)},
               "units": {"water_temp": "degC", "turbidity": "NTU", "water_clarity": "m"}, "quality": q}
        device_svc.ingest(db, dev, {"encoding": "json", "records": [rec]}, now=t)
        if temp > 30.5 and not q:
            from ..services import alerts

            alerts.raise_alert(db, self.org_id, "marine", "environment_threshold", "Sea temperature above 30.5 °C",
                               f"Buoy {dev.name} measured {temp:.1f} °C. Sustained high temperatures can stress corals "
                               "(bleaching risk); check against the regional reference series.",
                               subject_type="device", subject_id=dev.id, lat=dev.last_lat, lon=dev.last_lon,
                               evidence={"water_temp_c": round(temp, 2)}, confidence=0.85, dedupe_key=f"sst:{dev.id}")

    def water_clarity(self) -> float:
        return 18.0 / (1 + 0.6 * (1.4 + self.turbidity_event))

    # ---------------------------------------------------------------- truth access
    def objects(self) -> list[dict]:
        if self.frame is None:
            return []
        out = []
        for a in self.animals:
            L, W, *_ = PROFILES[a.group]
            la, lo = self.frame.to_latlon(a.e, a.n)
            out.append({"id": a.id, "kind": a.group, "lat": float(la), "lon": float(lo), "length": L, "width": W,
                        "heading": a.heading, "visible": a.visible, "colour": PROFILES[a.group][5],
                        "entangled": a.entangled})
        return out

    def truth(self) -> dict:
        objs = self.objects()
        nests = []
        for nt in self.nests:
            la, lo = self.frame.to_latlon(nt.e, nt.n)
            nests.append({"lat": float(la), "lon": float(lo), "laid": nt.laid.isoformat(), "recorded_by_patrol": nt.nest_id is not None})
        return {"animals": objs, "nests": nests, "heat_anomaly_c": self.heat_anomaly_c,
                "water_clarity_m": round(self.water_clarity(), 1)}

    def reef_animals_en(self, frame: LocalFrame) -> list[dict]:
        out = []
        for a in self.animals:
            if a.group in ("sea_turtle", "ray", "shark"):
                la, lo = self.frame.to_latlon(a.e, a.n)
                e, n = frame.to_en(la, lo)
                out.append({"id": a.id, "group": a.group, "e": float(e), "n": float(n), "depth": float(self.rng.uniform(2, 12))})
        return out
