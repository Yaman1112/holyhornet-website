"""Digital twin orchestration: one virtual clock, a world per organisation, scenario injection, mission execution.

Each tick moves the virtual clock and lets the twin produce data the way field hardware would:
collars sample every 15 min and upload hourly when the gateway is reachable; sensors report hourly;
rangers patrol at dawn; the analysis engines run on what actually arrived. The platform clock
(`db.utcnow`) follows the virtual clock while the simulation drives the platform.
"""

from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone

import numpy as np
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import set_virtual_now
from ..errors import Invalid, NotFound
from ..models import Animal, Device, Herd, Mission, Organization
from ..services import devices as device_svc
from ..services import events
from ..services import livestock as lv_svc
from .flight import DiveRun, FlightRun
from .livestock_sim import LivestockSim, local_hour
from .marine_sim import PROFILES, MarineSim, SimMarineAnimal


def _crossed(prev: datetime, now: datetime, period_s: int, offset_s: int = 0) -> bool:
    a = (prev.timestamp() - offset_s) // period_s
    b = (now.timestamp() - offset_s) // period_s
    return b > a


class SimWorld:
    def __init__(self, db: Session, org: Organization, seed: int):
        self.org_id = org.id
        self.rng = np.random.default_rng(seed)
        cfg = (org.settings or {}).get("sim", {})
        self.livestock = LivestockSim(db, org.id, self.rng) if cfg.get("livestock", True) else None
        if self.livestock and not self.livestock.animals:
            self.livestock = None
        self.marine = MarineSim(db, org.id, self.rng, cfg.get("marine_population")) if cfg.get("marine", True) else None
        if self.marine and self.marine.frame is None:
            self.marine = None
        self.weather = {"wind_mps": 4.5, "gust_mps": 7.0, "rain_mm_h": 0.0, "visibility_km": 10.0, "source": "simulated"}
        self.weather_override: dict | None = None
        self.runs: dict[str, FlightRun | DiveRun] = {}
        self.log: list[dict] = []
        self.analysis = True  # off during warm-up (baselines are learned first)

    def _weather(self, t: datetime):
        if self.weather_override:
            self.weather = dict(self.weather_override, source="operator override (simulation)")
            return
        hr = local_hour(t)
        sea_breeze = 2.5 * max(0.0, math.sin(math.pi * (hr - 9) / 10))
        w = max(0.5, 3.5 + sea_breeze + self.rng.normal(0, 0.6))
        rain = 0.0
        if self.rng.random() < 0.04:
            rain = float(self.rng.gamma(2, 2))
        self.weather = {"wind_mps": round(w, 1), "gust_mps": round(w * self.rng.uniform(1.3, 1.6), 1), "rain_mm_h": round(rain, 1),
                        "visibility_km": 4.0 if rain > 3 else 10.0, "source": "simulated"}

    def tick(self, db: Session, prev: datetime, t: datetime, dt: float) -> dict:
        out = {}
        if _crossed(prev, t, 1800):
            self._weather(t)
        lv = self.livestock
        if lv:
            lv.step(t, dt, self.weather)
            if _crossed(prev, t, 900):
                lv.collar_records(t, self.weather)
                out["uplink"] = lv.uplink(db, t)
            hourly = _crossed(prev, t, 3600)
            lv.water_step(db, t, dt, hourly)
            lv.vegetation_step(db, t, dt)
            if _crossed(prev, t, 2 * 86400, offset_s=int(7.5 * 3600)):  # every 2nd day 10:30 EAT
                lv.satellite_pass(db, t)
        mar = self.marine
        if mar:
            if not any(isinstance(r, FlightRun) and r.domain == "marine" for r in self.runs.values()):
                mar.step(dt)
            beach_events: list = []
            mar.nesting_step(db, t, dt, beach_events)
            if beach_events:
                out["beach"] = beach_events
            if _crossed(prev, t, 3600):
                mar.buoy_step(db, t)
        for mid, run in list(self.runs.items()):
            run.advance(db, dt, t)
            if run.finished:
                del self.runs[mid]
        if _crossed(prev, t, 3600) and self.analysis:
            device_svc.refresh_connectivity(db, self.org_id, t)
            if lv:
                lv_svc.check_water(db, self.org_id, t)
                health = _crossed(prev, t, 6 * 3600)
                out["analysis"] = lv_svc.analyze_org(db, self.org_id, t, run_health=health)
        if lv and self.analysis and _crossed(prev, t, 86400, offset_s=0):  # 03:00 EAT: refresh baselines from the last 3 days
            lv_svc.learn_baselines(db, self.org_id, t)
        return out

    # ------------------------------------------------------------ missions
    def start_run(self, db: Session, m: Mission, now: datetime):
        dev = db.get(Device, m.device_id)
        if dev.device_type == "rov":
            self.runs[m.id] = DiveRun(self, db, m, dev, now)
        else:
            self.runs[m.id] = FlightRun(self, db, m, dev, now)

    def abort_run(self, db: Session, m: Mission, now: datetime, reason: str):
        run = self.runs.pop(m.id, None)
        if run:
            run.abort(db, m, now, reason)

    # ------------------------------------------------------------ scenarios
    def inject(self, db: Session, kind: str, prm: dict, now: datetime) -> str:
        rng = self.rng
        lv, mar = self.livestock, self.marine
        ts = now.timestamp()

        def pick_animal():
            if not lv or not lv.animals:
                raise Invalid("no simulated livestock in this organisation")
            if prm.get("animal_id"):
                a = lv.animals.get(prm["animal_id"])
                if not a:
                    raise NotFound("animal not in simulation")
                return a
            cands = [a for a in lv.animals.values() if not a.stray and a.illness == 0]
            return cands[int(rng.integers(len(cands)))]

        def pick_collar():
            if prm.get("device_id"):
                c = lv.collars.get(prm["device_id"]) if lv else None
                if not c:
                    raise NotFound("collar not in simulation")
                return c
            a = pick_animal()
            if not a.device_id:
                raise Invalid("animal has no collar")
            return lv.collars[a.device_id]

        if kind == "stray":
            a = pick_animal()
            h = lv.herds[a.herd_id]
            ang = rng.uniform(0, 2 * math.pi)
            a.stray = (math.sin(ang), math.cos(ang), float(prm.get("speed_mps", 0.35)), float(prm.get("distance_m", 2200)))
            return f"{a.tag} starts wandering away from its herd"
        if kind == "illness":
            a = pick_animal()
            a.illness = float(np.clip(prm.get("severity", 0.85), 0, 1))
            return f"{a.tag} becomes ill (severity {a.illness:.2f}) — truth only; the platform must notice it from collar data"
        if kind == "recover":
            a = pick_animal()
            a.illness, a.stray = 0.0, None
            a.oe = a.on = 0.0
            return f"{a.tag} recovers / returns to the herd"
        if kind == "collar_failure":
            c = pick_collar()
            c.failed = True
            return f"collar on {lv.animals[c.animal_id].tag} stops working"
        if kind == "collar_dropped":
            c = pick_collar()
            a = lv.animals[c.animal_id]
            c.dropped_at = (a.e, a.n)
            return f"collar falls off {a.tag} and lies on the ground"
        if kind == "sensor_drift":
            c = pick_collar()
            c.temp_bias = float(prm.get("bias_c", 2.5))
            return f"temperature sensor on {lv.animals[c.animal_id].tag}'s collar drifts by {c.temp_bias:+.1f} °C"
        if kind == "battery_drain":
            c = pick_collar()
            c.drain_mult = float(prm.get("factor", 60))
            return f"collar on {lv.animals[c.animal_id].tag} starts draining its battery fast"
        if kind == "gateway_outage":
            if not lv:
                raise Invalid("no livestock network in this organisation")
            hrs = float(prm.get("hours", 4))
            lv.gateway_down_until = ts + hrs * 3600
            return f"LoRaWAN gateway offline for {hrs:.0f} h — collars buffer their data"
        if kind in ("fence_breach", "night_disturbance"):
            if not lv:
                raise Invalid("no livestock in this organisation")
            hid = prm.get("herd_id") or list(lv.herds)[0]
            h = lv.herds[hid]
            farm = lv.farms[h.farm_id]
            if kind == "fence_breach":
                b = farm.boundary if farm.boundary is not None else h.grazing
                c = b[:-1].mean(0)
                far = b[np.argmax(np.hypot(*(b - c).T))]
                d = (far - c) / max(np.hypot(*(far - c)), 1)
                h.breach_target = (float(far[0] + d[0] * 350), float(far[1] + d[1] * 350))
                h.breach_until = ts + 3 * 3600
                return "herd breaks through the fence and heads outside the farm boundary for ~3 h"
            ang = rng.uniform(0, 2 * math.pi)
            h.flee_dir = (math.sin(ang), math.cos(ang))
            h.flee_until = ts + 45 * 60
            return "something disturbs the herd: it runs for ~45 min"
        if kind == "drought":
            if not lv:
                raise Invalid("no livestock in this organisation")
            lv.drought = bool(prm.get("on", True))
            return "drought conditions " + ("start: pasture dries, water points are not refilled" if lv.drought else "end")
        if kind == "pump_failure":
            if not lv or not lv.water:
                raise Invalid("no water points")
            wid = prm.get("water_point_id") or list(lv.water)[0]
            lv.pump_failure.add(wid)
            return "borehole pump fails: the water point is no longer refilled"
        if kind == "marine_heatwave":
            if not mar:
                raise Invalid("no marine simulation in this organisation")
            mar.heat_anomaly_c = float(prm.get("delta_c", 2.6))
            return f"sea temperature anomaly {mar.heat_anomaly_c:+.1f} °C"
        if kind == "turbidity_event":
            if not mar:
                raise Invalid("no marine simulation")
            mar.turbidity_event = float(prm.get("ntu", 6.0))
            return "run-off after heavy rain makes the water turbid"
        if kind == "entanglement":
            if not mar:
                raise Invalid("no marine simulation")
            cands = [a for a in mar.animals if a.group == "sea_turtle" and not a.entangled]
            if not cands:
                raise Invalid("no turtle available")
            a = cands[int(rng.integers(len(cands)))]
            a.entangled = True
            return f"a sea turtle ({a.id}) becomes entangled in fishing gear and stays at the surface"
        if kind == "debris_spill":
            if not mar:
                raise Invalid("no marine simulation")
            x0, y0, x1, y1 = mar.habitat
            n0 = len(mar.animals)
            for i in range(int(prm.get("count", 10))):
                mar.animals.append(SimMarineAnimal(f"D{n0 + i}", "debris", rng.uniform(x0, x1), rng.uniform(y0, y1), 0, 0, True, 1e9))
            return "floating debris (nets, plastics) drifts into the survey area"
        if kind == "add_marine_animals":
            if not mar:
                raise Invalid("no marine simulation")
            grp = prm.get("group", "sea_turtle")
            if grp not in PROFILES or grp == "dolphin":
                raise Invalid("group must be sea_turtle, dugong, ray, shark or debris")
            x0, y0, x1, y1 = mar.habitat
            L, W, sp, ms, md, _ = PROFILES[grp]
            n = int(prm.get("count", 3))
            for i in range(n):
                mar.animals.append(SimMarineAnimal(f"X{len(mar.animals)}", grp, rng.uniform(x0, x1), rng.uniform(y0, y1),
                                                   rng.uniform(0, 6.28), sp, rng.random() < 0.2, rng.exponential(ms)))
            return f"{n} × {grp} added to the marine twin"
        if kind == "weather":
            keys = ("wind_mps", "gust_mps", "rain_mm_h", "visibility_km")
            if prm.get("clear"):
                self.weather_override = None
                self._weather(now)
                return "weather back to the simulated forecast"
            self.weather_override = {k: float(prm.get(k, self.weather.get(k, 0))) for k in keys}
            self.weather = dict(self.weather_override, source="operator override (simulation)")
            return "weather set: " + ", ".join(f"{k}={self.weather_override[k]}" for k in keys)
        raise Invalid(f"unknown scenario '{kind}'")

    def truth(self) -> dict:
        return {"ground_truth": True, "warning": "Simulator ground truth — never shown as observations.",
                "livestock": self.livestock.truth() if self.livestock else [],
                "marine": self.marine.truth() if self.marine else {},
                "weather": self.weather,
                "runs": {mid: {"kind": r.kind, "position": r.position()} for mid, r in self.runs.items()}}


SCENARIOS = {
    "stray": "An animal wanders away from its herd (separation → missing-animal alerts)",
    "illness": "An animal becomes ill: less active, lies down more, warmer collar, lags behind",
    "recover": "Reset an animal (illness / straying ends)",
    "collar_failure": "A collar stops working (device offline)",
    "collar_dropped": "A collar falls off and lies still (inactivity at ambient temperature)",
    "sensor_drift": "A collar temperature sensor drifts (tests false-positive handling)",
    "battery_drain": "A collar battery drains fast (low-battery alert)",
    "gateway_outage": "LoRaWAN gateway offline: collars store-and-forward",
    "fence_breach": "A herd leaves the farm boundary",
    "night_disturbance": "A herd runs (predator / theft disturbance)",
    "drought": "Pasture dries and water is not refilled",
    "pump_failure": "Borehole pump fails",
    "marine_heatwave": "Sea temperature anomaly",
    "turbidity_event": "Turbid water after run-off",
    "entanglement": "A turtle gets entangled and stays at the surface",
    "debris_spill": "Floating debris drifts into the survey area",
    "add_marine_animals": "Add marine animals to the twin",
    "weather": "Set wind / rain / visibility (affects mission weather checks)",
}


class Simulation:
    """Process-wide twin: one virtual clock shared by all organisations."""

    def __init__(self, start: datetime, seed: int = 2026):
        self.clock = start
        self.seed = seed
        self.worlds: dict[str, SimWorld] = {}
        self.enabled = True
        set_virtual_now(start)

    def world(self, db: Session, org_id: str) -> SimWorld:
        w = self.worlds.get(org_id)
        if w is None:
            org = db.get(Organization, org_id)
            if org is None:
                raise NotFound("organisation not found")
            w = SimWorld(db, org, self.seed + len(self.worlds) * 101)
            self.worlds[org_id] = w
        return w

    def attach_all(self, db: Session):
        for org in db.scalars(select(Organization)):
            if (org.settings or {}).get("sim"):
                self.world(db, org.id)

    def step(self, db: Session, minutes: float) -> dict:
        total = float(minutes) * 60
        if total <= 0 or total > 7 * 86400:
            raise Invalid("minutes must be in (0, 10080]")
        summary: dict = {"from": self.clock.isoformat()}
        while total > 1e-6:
            busy = any(w.runs for w in self.worlds.values())
            base = 30.0 if busy else 900.0
            # align to the 15-min sampling grid
            to_grid = base - (self.clock.timestamp() % base) or base
            dt = min(total, to_grid)
            prev = self.clock
            self.clock = prev + timedelta(seconds=dt)
            set_virtual_now(self.clock)
            for org_id, w in self.worlds.items():
                res = w.tick(db, prev, self.clock, dt)
                if res.get("analysis"):
                    summary.setdefault("analysis", {})[org_id] = res["analysis"]
            total -= dt
            db.flush()
        db.commit()
        summary["to"] = self.clock.isoformat()
        for org_id in self.worlds:
            events.publish(org_id, "sim.tick", {"clock": self.clock.isoformat()})
        return summary

    def status(self, org_id: str | None = None) -> dict:
        w = self.worlds.get(org_id) if org_id else None
        return {"enabled": self.enabled, "clock": self.clock.isoformat(),
                "local_time_eat": (self.clock + timedelta(hours=3)).strftime("%Y-%m-%d %H:%M"),
                "worlds": len(self.worlds), "weather": w.weather if w else None,
                "active_runs": {mid: {"kind": r.kind, "position": r.position()} for mid, r in (w.runs.items() if w else [])},
                "has_livestock": bool(w and w.livestock), "has_marine": bool(w and w.marine),
                "scenarios": SCENARIOS}

    def add_livestock(self, db: Session, org_id: str, herd_id: str, count: int, species: str | None = None) -> list[str]:
        from ..models import Animal as A

        w = self.world(db, org_id)
        if not w.livestock or herd_id not in w.livestock.herds:
            raise Invalid("herd not in simulation")
        herd = db.get(Herd, herd_id)
        species = species or herd.species
        existing = db.scalars(select(A.tag).where(A.org_id == org_id)).all()
        nxt = len(existing) + 1
        made = []
        for i in range(count):
            tag = f"TZ-{nxt + i:04d}"
            a = A(org_id=org_id, farm_id=herd.farm_id, herd_id=herd_id, tag=tag, species=species,
                  breed="Zebu (simulated)" if species == "cattle" else "Small East African", sex="female")
            db.add(a)
            db.flush()
            from ..security import new_device_secret

            _, hsh = new_device_secret()
            d = Device(org_id=org_id, domain="livestock", device_type="collar", category="smart_collar", name=f"Collar {tag}",
                       serial=f"SIM-COL-{a.id[:8]}", manufacturer="AICN reference design", model="AC-1 (simulated)",
                       firmware="0.9.0-sim", comms=["lorawan", "ble"], secret_hash=hsh, battery_pct=100.0, animal_id=a.id,
                       simulated=True, specs={"sample_interval_s": 900, "uplink_interval_s": 3600})
            db.add(d)
            db.flush()
            w.livestock.add_animal(a, d)
            made.append(a.id)
        db.commit()
        return made


_SIM: Simulation | None = None


def get_sim() -> Simulation | None:
    return _SIM


def set_sim(s: Simulation | None):
    global _SIM
    _SIM = s


def default_start() -> datetime:
    return datetime(2026, 11, 2, 3, 0, tzinfo=timezone.utc)  # 06:00 EAT
