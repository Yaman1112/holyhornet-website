"""Digital twin. Simulated hardware produces data; the platform consumes it through its normal services."""
