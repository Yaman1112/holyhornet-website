"""Simulated mission execution: a UAV flies the approved plan, a synthetic camera renders frames from ground truth,
the real detector + tracker run on those frames, and results land in the platform like a real flight's would.
Also the ROV dive runner (tethered, operator-supervised).
"""

from __future__ import annotations

import math
import zlib
from datetime import datetime, timedelta

import numpy as np
from sqlalchemy.orm import Session

from ..engines import behaviour, rov as rov_engine
from ..engines.planner import UAVSpec, ROVSpec
from ..engines.tracking import MultiObjectTracker
from ..engines.vision import Camera, SeaSurfaceAnomalyDetector, ThermalBlobDetector, box_blur, encode_png, georeference
from ..geo import LocalFrame
from ..models import (AIDetection, BehaviourEvent, Device, HabitatObservation, MarineObservation, Media, Mission,
                      MissionLog, RovDive)
from ..services import alerts, events, media

SENSITIVE_GROUPS = {"dugong", "dolphin_or_dugong"}
GROUP_TO_SPECIES = {"sea_turtle": "sea_turtle", "dolphin_or_dugong": "dolphin_or_dugong", "large_animal": "other",
                    "whale": "whale", "unknown": "other"}


def log(db: Session, m: Mission, t: datetime, msg: str, level="info", data=None):
    db.add(MissionLog(mission_id=m.id, at=t, level=level, message=msg, data=data or {}))
    events.publish(m.org_id, "mission.log", {"mission_id": m.id, "message": msg, "level": level})


def _smooth_noise(rng, h, w, cells=(6, 8), amp=1.0):
    g = rng.normal(0, 1, cells)
    up = np.kron(g, np.ones((math.ceil(h / cells[0]), math.ceil(w / cells[1]))))[:h, :w]
    return box_blur(up, 6) * amp


def _ellipse_mask(h, w, cx, cy, a, b, ang):
    r = int(max(a, b)) + 2
    x0, x1 = max(0, int(cx) - r), min(w, int(cx) + r + 1)
    y0, y1 = max(0, int(cy) - r), min(h, int(cy) + r + 1)
    if x0 >= x1 or y0 >= y1:
        return None
    yy, xx = np.mgrid[y0:y1, x0:x1]
    u = (xx - cx) * math.cos(ang) + (yy - cy) * math.sin(ang)
    v = -(xx - cx) * math.sin(ang) + (yy - cy) * math.cos(ang)
    m = (u / max(a, 0.5)) ** 2 + (v / max(b, 0.5)) ** 2 <= 1
    return (slice(y0, y1), slice(x0, x1), m)


class FlightRun:
    kind = "uav"

    def __init__(self, world, db: Session, m: Mission, dev: Device, now: datetime):
        self.world, self.mission_id, self.device_id, self.org_id = world, m.id, dev.id, m.org_id
        self.domain = m.domain
        prm = m.params or {}
        self.sensor = prm.get("sensor", "thermal" if m.domain == "livestock" else "rgb")
        self.alt = float(prm.get("altitude_m", 60))
        self.spec = UAVSpec.from_specs(dev.specs)
        self.speed = min(self.spec.cruise_speed_mps, float(prm.get("speed_mps", 10)))
        hfov = self.spec.thermal_hfov_deg if self.sensor == "thermal" else self.spec.rgb_hfov_deg
        self.cam = Camera(hfov, self.spec.image_w, self.spec.image_h)
        wps = m.plan["waypoints"]
        home = (dev.last_lat, dev.last_lon) if dev.last_lat is not None else tuple(wps[0])
        self.home = home
        self.frame = LocalFrame(*wps[0])
        pts = [home] + [tuple(w[:2]) for w in wps] + [home]
        self.P = np.array([self.frame.to_en(a, b) for a, b in pts], float)
        seg = np.hypot(*np.diff(self.P, axis=0).T)
        self.cum = np.concatenate([[0], np.cumsum(seg)])
        self.L = float(self.cum[-1])
        self.s_start, self.s_end = float(self.cum[1]), float(self.cum[-2])
        fw, fh = self.cam.footprint_m(self.alt)
        self.fw, self.fh = fw, fh
        self.spacing = fh * (1 - float(prm.get("forward_overlap", 0.3)))
        self.next_s = self.s_start
        self.s = 0.0
        self.t0 = now
        self.rng = np.random.default_rng(zlib.crc32(m.id.encode()))
        self.detector = ThermalBlobDetector() if self.sensor == "thermal" else SeaSurfaceAnomalyDetector()
        self.tracker = MultiObjectTracker(meas_sigma_m=2.0, gate_chi2=11.0, min_hits=2, max_misses=2)
        self.tp = self.fp = self.fn = 0
        self.frames = 0
        self.truth_seen: set[str] = set()
        self.det_ids_by_track: dict[str, list[str]] = {}
        self.frames_saved = 0
        self.quarter = 0
        self.aborted = False
        self.finished = False
        self.battery_start = dev.battery_pct or 0
        self.energy_wh_per_m = self.spec.cruise_power_w / self.spec.cruise_speed_mps / 3600
        self.last_pose = None
        log(db, m, now, f"Take-off ({'simulation' if m.mode == 'simulation' else m.mode}); {len(wps)} waypoints, "
                        f"{self.L:.0f} m incl. transit, altitude {self.alt:.0f} m, {self.sensor} camera "
                        f"(footprint {fw:.0f}×{fh:.0f} m, {self.cam.gsd(self.alt) * 100:.0f} cm/px)")

    # ------------------------------------------------------------ geometry
    def pose_at(self, s):
        i = int(np.clip(np.searchsorted(self.cum, s, side="right") - 1, 0, len(self.P) - 2))
        a, b = self.P[i], self.P[i + 1]
        L = max(self.cum[i + 1] - self.cum[i], 1e-6)
        f = (s - self.cum[i]) / L
        pos = a + f * (b - a)
        yaw = math.degrees(math.atan2(b[0] - a[0], b[1] - a[1])) % 360
        return pos, yaw

    def _in_view(self, pos, yaw, e, n, margin=0.0):
        y = math.radians(yaw)
        de, dn = e - pos[0], n - pos[1]
        fwd = de * math.sin(y) + dn * math.cos(y)
        right = de * math.cos(y) - dn * math.sin(y)
        return abs(right) <= self.fw / 2 - margin and abs(fwd) <= self.fh / 2 - margin, right, fwd

    def position(self):
        pos, yaw = self.pose_at(min(self.s, self.L))
        la, lo = self.frame.to_latlon(pos[0], pos[1])
        return float(la), float(lo), yaw

    # ------------------------------------------------------------ advance
    def advance(self, db: Session, dt: float, now: datetime):
        if self.finished:
            return
        m = db.get(Mission, self.mission_id)
        if m.status != "active":
            self.finished = True
            return
        target = min(self.s + self.speed * dt, self.L)
        while self.next_s <= min(target, self.s_end):
            if self.domain == "marine" and self.world.marine:
                self.world.marine.step(self.spacing / self.speed, fine=True)
            t_frame = self.t0 + timedelta(seconds=self.next_s / self.speed)
            self._capture(db, m, t_frame)
            self.next_s += self.spacing
        self.s = target
        dev = db.get(Device, self.device_id)
        la, lo, _ = self.position()
        dev.last_lat, dev.last_lon, dev.last_seen_at = la, lo, now
        used = self.s * self.energy_wh_per_m / self.spec.battery_wh * 100
        dev.battery_pct = round(max(0.0, self.battery_start - used), 1)
        q = int(4 * self.s / max(self.L, 1))
        if q > self.quarter and q < 4:
            self.quarter = q
            log(db, m, now, f"{q * 25}% of route flown; {self.frames} frames, {len(self.tracker.confirmed_tracks())} confirmed tracks")
        events.publish(self.org_id, "uav.position", {"mission_id": m.id, "device_id": dev.id, "lat": la, "lon": lo,
                                                     "progress": round(self.s / self.L, 3)})
        if self.s >= self.L:
            self.finish(db, m, now)

    def abort(self, db: Session, m: Mission, now: datetime, reason: str):
        self.aborted = True
        log(db, m, now, f"ABORT: {reason}. Returning to launch point; partial results kept and flagged.", "warning")
        self.finish(db, m, now)

    # ------------------------------------------------------------ capture
    def _objects(self):
        if self.domain == "livestock" and self.world.livestock:
            return self.world.livestock.objects()
        if self.domain == "marine" and self.world.marine:
            return self.world.marine.objects()
        return []

    def _render(self, pos, yaw, objs, t: datetime):
        H, W = self.cam.height_px, self.cam.width_px
        g = self.cam.gsd(self.alt)
        rng = self.rng
        y = math.radians(yaw)
        visible_in_view = []
        if self.sensor == "thermal":
            lv = self.world.livestock
            amb = lv.farm_ambient(*self.frame.to_latlon(pos[0], pos[1]), t) if lv else 25.0
            hr = (t.hour + t.minute / 60 + 3) % 24
            solar = 10 * max(0.0, math.sin(math.pi * (hr - 6) / 12))
            img = amb + solar * (0.65 + 0.35 * np.tanh(_smooth_noise(rng, H, W, amp=1.2))) + rng.normal(0, 0.12, (H, W))
            for _ in range(rng.integers(0, 4)):  # tree canopies / shade patches
                mk = _ellipse_mask(H, W, rng.uniform(0, W), rng.uniform(0, H), rng.uniform(12, 30) * 0.3 / g,
                                   rng.uniform(10, 25) * 0.3 / g, rng.uniform(0, math.pi))
                if mk:
                    img[mk[0], mk[1]][mk[2]] -= solar * 0.6
        else:
            img = np.empty((H, W, 3))
            base = np.array([18.0, 92.0, 118.0])
            nz = _smooth_noise(rng, H, W, amp=3.0)
            for c in range(3):
                img[:, :, c] = base[c] + nz * (1 + 0.3 * c) + rng.normal(0, 3.5, (H, W))
            wind = self.world.weather.get("wind_mps", 4)
            n_glint = int(rng.poisson(8 + wind * 8))
            ys, xs = rng.integers(0, H, n_glint), rng.integers(0, W, n_glint)
            img[ys, xs] += rng.uniform(60, 140, (n_glint, 1))
            if wind > 7:  # whitecaps: bright streaks
                for _ in range(int(rng.poisson((wind - 7) * 3))):
                    mk = _ellipse_mask(H, W, rng.uniform(0, W), rng.uniform(0, H), rng.uniform(4, 9), 1.0, rng.uniform(0, math.pi))
                    if mk:
                        img[mk[0], mk[1]][mk[2]] = 235
        for o in objs:
            e, n = self.frame.to_en(o["lat"], o["lon"])
            inside, right, fwd = self._in_view(pos, yaw, float(e), float(n), margin=-3)
            if not inside:
                continue
            cx = W / 2 + right / g
            cy = H / 2 - fwd / g
            ang = o["heading"] - y
            mk = _ellipse_mask(H, W, cx, cy, o["length"] / 2 / g, o["width"] / 2 / g, ang - math.pi / 2)
            centre_in = self._in_view(pos, yaw, float(e), float(n))[0]
            if self.sensor == "thermal":
                lv = self.world.livestock
                surf = 0.35 * (img.mean()) + 23.5 + 1.6 * o.get("illness", 0)
                if mk is not None:
                    img[mk[0], mk[1]][mk[2]] = surf + rng.normal(0, 0.2)
                if centre_in:
                    visible_in_view.append((o, float(e), float(n)))
            else:
                if not o["visible"]:
                    continue
                if mk is not None:
                    alpha = 0.92 if o["kind"] in ("debris", "dolphin") else rng.uniform(0.6, 0.9)
                    col = np.array(o["colour"], float)
                    reg = img[mk[0], mk[1]]
                    reg[mk[2]] = alpha * col + (1 - alpha) * reg[mk[2]]
                if centre_in:
                    visible_in_view.append((o, float(e), float(n)))
        return img, visible_in_view

    def _capture(self, db: Session, m: Mission, t: datetime):
        pos, yaw = self.pose_at(self.next_s)
        objs = self._objects()
        img, truth_in = self._render(pos, yaw, objs, t)
        g = self.cam.gsd(self.alt)
        dets = self.detector.detect(img if self.sensor == "thermal" else np.clip(img, 0, 255).astype(np.uint8), g)
        # navigation error of the aircraft (what georeferencing really suffers from)
        pe, pn = pos + self.rng.normal(0, 1.5, 2)
        la, lo = self.frame.to_latlon(pe, pn)
        yaw_m = yaw + self.rng.normal(0, 1.0)
        meas = []
        for d in dets:
            d.lat, d.lon = georeference(d, self.cam, float(la), float(lo), self.alt, yaw_m)
            e, n = self.frame.to_en(d.lat, d.lon)
            meas.append((float(e), float(n), d.species_group or d.label, d.confidence))
        assoc = dict(self.tracker.update((t - self.t0).total_seconds(), meas,
                                         in_view=lambda e, n: self._in_view(pos, yaw, e, n)[0]))
        # evaluation against simulator truth (greedy within 3 m)
        used = set()
        for o, e, n in truth_in:
            self.truth_seen.add(o["id"])
            best, bd = None, 3.5
            for j, (me, mn, *_r) in enumerate(meas):
                if j in used:
                    continue
                dd = math.hypot(me - e, mn - n)
                if dd < bd:
                    best, bd = j, dd
            if best is None:
                self.fn += 1
            else:
                used.add(best)
                self.tp += 1
        self.fp += len(meas) - len(used)
        self.frames += 1
        media_id = None
        if dets and self.frames_saved < 40 or self.frames % 10 == 0 and self.frames_saved < 40:
            media_id = self._save_frame(db, m, img, t, float(la), float(lo), yaw, dets)
        for j, d in enumerate(dets):
            row = AIDetection(org_id=m.org_id, domain=m.domain, model_id=self.detector.id, media_id=media_id,
                              mission_id=m.id, label=d.label, species_group=d.species_group, confidence=d.confidence,
                              bbox=d.bbox, lat=d.lat, lon=d.lon, track_id=assoc.get(j), observed_at=t,
                              sensitive=d.species_group in SENSITIVE_GROUPS,
                              extra=dict(d.extra, size_m=d.size_m, synthetic_frame=True))
            db.add(row)
            db.flush()
            if assoc.get(j):
                self.det_ids_by_track.setdefault(assoc[j], []).append(row.id)

    def _save_frame(self, db, m, img, t, la, lo, yaw, dets):
        if self.sensor == "thermal":
            lo_, hi_ = np.percentile(img, [1, 99.5])
            v = np.clip((img - lo_) / max(hi_ - lo_, 1e-6), 0, 1)
            rgb = np.stack([np.clip(1.5 * v, 0, 1), np.clip(1.5 * v - 0.5, 0, 1) ** 1.2, np.clip(1 - 2 * v, 0, 1) * 0.6 + v ** 6], 2)
            png = encode_png((rgb * 255).astype(np.uint8))
        else:
            png = encode_png(np.clip(img, 0, 255).astype(np.uint8))
        med = Media(org_id=m.org_id, domain=m.domain, kind="thermal" if self.sensor == "thermal" else "image",
                    mission_id=m.id, width=self.cam.width_px, height=self.cam.height_px, lat=la, lon=lo, captured_at=t,
                    meta={"altitude_m": self.alt, "yaw_deg": round(yaw, 1), "gsd_m": round(self.cam.gsd(self.alt), 3),
                          "synthetic": True, "detections": len(dets)})
        db.add(med)
        db.flush()
        med.uri = media.store().put(med.id + ".png", png)
        self.frames_saved += 1
        return med.id

    # ------------------------------------------------------------ results
    def finish(self, db: Session, m: Mission, now: datetime):
        if self.finished:
            return
        self.finished = True
        tracks = self.tracker.confirmed_tracks()
        prec = self.tp / max(self.tp + self.fp, 1)
        rec = self.tp / max(self.tp + self.fn, 1)
        evaluation = {
            "frames": self.frames, "detections": self.tp + self.fp, "true_positives": self.tp, "false_positives": self.fp,
            "missed": self.fn, "precision": round(prec, 3), "recall": round(rec, 3),
            "unique_objects_in_view": len(self.truth_seen), "confirmed_tracks": len(tracks),
            "count_error": len(tracks) - len(self.truth_seen),
            "detector": self.detector.id,
            "note": "Measured on synthetic frames rendered from simulator ground truth; not field performance.",
        }
        outcome = {"evaluation": evaluation, "aborted": self.aborted, "distance_flown_m": round(self.s),
                   "energy_used_pct": round(self.battery_start - (db.get(Device, self.device_id).battery_pct or 0), 1)}
        if m.domain == "marine":
            outcome.update(self._marine_results(db, m, tracks, now))
        else:
            outcome.update(self._livestock_results(db, m, tracks, now))
        m.outcome = outcome
        m.status = "aborted" if self.aborted else "completed"
        m.ended_at = now
        dev = db.get(Device, self.device_id)
        dev.last_lat, dev.last_lon = self.home
        log(db, m, now, f"Landed. {self.frames} frames, {len(tracks)} confirmed tracks; synthetic-eval precision "
                        f"{prec:.2f}, recall {rec:.2f}.")
        events.publish(m.org_id, "mission.finished", {"mission_id": m.id, "status": m.status})

    def _track_latlon(self, tr):
        h = np.array(tr.history)
        la, lo = self.frame.to_latlon(h[:, 1].mean(), h[:, 2].mean())
        return float(la), float(lo)

    def _marine_results(self, db, m, tracks, now):
        n_obs = 0
        poss = 0
        groups: dict = {}
        for tr in tracks:
            grp = MultiObjectTracker.majority_label(tr)
            la, lo = self._track_latlon(tr)
            conf = float(np.mean([hh[3] for hh in tr.history]))
            sens = grp in SENSITIVE_GROUPS or grp == "sea_turtle"
            o = MarineObservation(org_id=m.org_id, species_group=GROUP_TO_SPECIES.get(grp, "other"), count=1, lat=la, lon=lo,
                                  observed_at=self.t0 + timedelta(seconds=tr.history[0][0]), method="uav_aerial", source="ai",
                                  confidence=round(conf, 2), verification="unverified", mission_id=m.id,
                                  detection_ids=self.det_ids_by_track.get(tr.id, []), sensitive=sens,
                                  environment={"wind_mps": self.world.weather.get("wind_mps"),
                                               "water_clarity_m": round(self.world.marine.water_clarity(), 1) if self.world.marine else None},
                                  notes=f"AI candidate from track {tr.id}; species group is a size-based hint. Needs review.")
            db.add(o)
            db.flush()
            n_obs += 1
            groups[o.species_group] = groups.get(o.species_group, 0) + 1
            frames_in_view = tr.hits + tr.misses
            b = behaviour.track_behaviour(tr.history, grp, frames_in_view)
            if b["observed"].get("samples", 0) >= 3:
                db.add(BehaviourEvent(org_id=m.org_id, observation_id=o.id, mission_id=m.id, track_id=tr.id, species_group=grp,
                                      at=o.observed_at, observed=b["observed"], interpretation=b["interpretation"],
                                      lat=la, lon=lo, sensitive=sens))
                if b["interpretation"]["label"] == "possible_entanglement_or_distress":
                    poss += 1
                    alerts.raise_alert(db, m.org_id, "marine", "possible_entanglement",
                                       f"Possible entanglement / distress ({grp}) — needs expert review",
                                       b["interpretation"]["basis"], subject_type="marine_observation", subject_id=o.id,
                                       lat=la, lon=lo, evidence=b, confidence=b["interpretation"]["confidence"],
                                       sensitive=sens, dedupe_key=f"entangle:{m.id}:{tr.id}")
        if n_obs:
            alerts.raise_alert(db, m.org_id, "marine", "marine_detection_review", f"{n_obs} AI candidates to verify ({m.name})",
                               "Survey flight produced candidate marine animal observations. Species groups are size-based "
                               "hints; confirm, correct or reject each one in the verification queue.",
                               subject_type="mission", subject_id=m.id, evidence={"by_group": groups},
                               requires_review=True, dedupe_key=f"review:{m.id}", priority="low")
        return {"observations_created": n_obs, "by_group": groups, "possible_entanglement": poss}

    def _livestock_results(self, db, m, tracks, now):
        lv = self.world.livestock
        from sqlalchemy import select

        from ..models import Animal

        animals = list(db.scalars(select(Animal).where(Animal.org_id == m.org_id, Animal.status.in_(["active", "missing"]))))
        expected = []
        for a in animals:
            if a.last_lat is None:
                continue
            e, n = self.frame.to_en(a.last_lat, a.last_lon)
            # animals whose last collar fix lies under the surveyed swath
            if any(math.hypot(e - pe, n - pn) < self.fw for pe, pn in self.P[1:-1]):
                expected.append((a, float(e), float(n)))
        unexplained = []
        for tr in tracks:
            h = np.array(tr.history)
            te, tn = h[:, 1].mean(), h[:, 2].mean()
            if not any(math.hypot(te - e, tn - n) < 60 for _, e, n in expected):
                unexplained.append(self._track_latlon(tr))
        res = {"animals_counted": len(tracks), "collar_animals_in_area": len(expected),
               "count_basis": "confirmed thermal tracks (each animal counted once across overlapping frames)",
               "unexplained_detections": [{"lat": a, "lon": b} for a, b in unexplained]}
        target = (m.params or {}).get("target_animal_id")
        if m.kind == "missing_animal_search" and target:
            a = db.get(Animal, target)
            if unexplained:
                la, lo = unexplained[0]
                alerts.raise_alert(db, m.org_id, "livestock", "missing_animal", f"Possible sighting during search for {a.tag}",
                                   f"The search flight found {len(unexplained)} warm body/bodies not explained by collar positions. "
                                   "This is a possible sighting only — send someone to confirm.", subject_type="animal",
                                   subject_id=a.id, lat=la, lon=lo, evidence=res, confidence=0.5,
                                   dedupe_key=f"search:{m.id}")
                res["search_result"] = "possible_sighting"
            else:
                res["search_result"] = "nothing_found_in_area"
        return res


class DiveRun:
    kind = "rov"

    def __init__(self, world, db: Session, m: Mission, dev: Device, now: datetime):
        self.world, self.mission_id, self.device_id, self.org_id = world, m.id, dev.id, m.org_id
        self.spec = ROVSpec.from_specs(dev.specs)
        wps = m.plan["waypoints"]
        launch = tuple((m.params or {}).get("launch") or wps[0][:2])
        self.launch = launch
        self.frame = LocalFrame(*launch)
        en = []
        for w in wps:
            e, n = self.frame.to_en(w[0], w[1])
            en.append((float(e), float(n), float(w[2])))
        en.append((0.0, 0.0, 1.0))
        c = (m.params or {}).get("conditions") or {}
        mar = world.marine
        cond = rov_engine.DiveConditions(current_e=c.get("current_e", 0.12), current_n=c.get("current_n", -0.04),
                                         visibility_m=c.get("visibility_m", mar.water_clarity() * 0.6 if mar else 8.0),
                                         seabed_depth_m=c.get("seabed_depth_m", max(w[2] for w in en) + 2.0))  # reef survey flies ~2 m above the bottom
        animals = mar.reef_animals_en(self.frame) if mar else []
        self.res = rov_engine.simulate_dive(en, cond, seed=zlib.crc32(m.id.encode()), speed=self.spec.speed_mps,
                                            tether_m=self.spec.tether_m, animals=animals)
        self.t0 = now
        self.elapsed = 0.0
        self.total = self.res.truth[-1][0] if self.res.truth else 0.0
        self.finished = False
        self.aborted = False
        log(db, m, now, f"ROV in the water at launch point; supervised dive, {len(wps)} waypoints, "
                        f"visibility ≈{cond.visibility_m:.1f} m, current ≈{math.hypot(cond.current_e, cond.current_n):.2f} m/s")

    def position(self):
        k = self._idx()
        if k < 0:
            return self.launch[0], self.launch[1], 0.0
        t, e, n, d, y = self.res.estimate[k]
        la, lo = self.frame.to_latlon(e, n)
        return float(la), float(lo), float(d)

    def _idx(self):
        if not self.res.truth:
            return -1
        ts = [r[0] for r in self.res.truth]
        return int(np.clip(np.searchsorted(ts, self.elapsed) - 1, 0, len(ts) - 1))

    def advance(self, db: Session, dt: float, now: datetime):
        if self.finished:
            return
        m = db.get(Mission, self.mission_id)
        if m.status != "active":
            self.finished = True
            return
        self.elapsed += dt
        la, lo, depth = self.position()
        dev = db.get(Device, self.device_id)
        dev.last_lat, dev.last_lon, dev.last_seen_at = la, lo, now
        events.publish(self.org_id, "rov.position", {"mission_id": m.id, "lat": la, "lon": lo, "depth_m": depth,
                                                     "progress": round(min(self.elapsed / max(self.total, 1), 1), 3)})
        if self.elapsed >= self.total:
            self.finish(db, m, now)

    def abort(self, db: Session, m: Mission, now: datetime, reason: str):
        self.aborted = True
        log(db, m, now, f"ABORT: {reason}. Pilot takes manual control; ROV ascends and is recovered on the tether.", "warning")
        self.finish(db, m, now)

    def finish(self, db: Session, m: Mission, now: datetime):
        if self.finished:
            return
        self.finished = True
        cut = self.elapsed
        r = self.res
        est = [x for x in r.estimate if x[0] <= cut]
        tru = [x for x in r.truth if x[0] <= cut]
        samples = [x for x in r.seabed_samples if x[0] <= cut]
        sights = [s for s in r.sightings if s["t"] <= cut]
        err = [math.hypot(a[1] - b[1], a[2] - b[2]) for a, b in zip(est, tru)]
        loc = dict(r.localization)
        if err:
            loc["rmse_m"] = round(float(np.sqrt(np.mean(np.square(err)))), 2)
        loc["launch"] = list(self.launch)
        dive = RovDive(org_id=m.org_id, mission_id=m.id, device_id=self.device_id, site=m.name, started_at=self.t0,
                       ended_at=now, max_depth_m=max((x[3] for x in est), default=0), duration_s=cut,
                       track=est[::4], localization=loc, simulated=True,
                       summary={"seabed_samples": len(samples), "sightings": len(sights), "aborted": self.aborted})
        db.add(dive)
        # habitat: coral cover in 30 m transect segments (estimate ± standard error)
        segs: dict[int, list] = {}
        for s in samples:
            d = math.hypot(s[1], s[2])
            segs.setdefault(int(d // 30), []).append(s)
        for k, ss in sorted(segs.items()):
            vals = [x[3] for x in ss]
            la, lo = self.frame.to_latlon(np.mean([x[1] for x in ss]), np.mean([x[2] for x in ss]))
            db.add(HabitatObservation(org_id=m.org_id, area_id=m.area_id, kind="coral_cover", value=round(float(np.mean(vals)), 3),
                                      unit="fraction", uncertainty=round(float(np.std(vals) / math.sqrt(len(vals)) + 0.04), 3),
                                      lat=float(la), lon=float(lo), method="rov_transect", observed_at=now, is_estimate=True,
                                      mission_id=m.id))
        for s in sights:
            la, lo = self.frame.to_latlon(s["e"], s["n"])
            db.add(MarineObservation(org_id=m.org_id, species_group=s["species_group"], count=1, lat=float(la), lon=float(lo),
                                     observed_at=self.t0 + timedelta(seconds=s["t"]), method="rov", source="ai",
                                     confidence=s["confidence"], verification="unverified", mission_id=m.id,
                                     environment={"depth_m": s["depth"], "range_m": s["range_m"]},
                                     sensitive=s["species_group"] == "sea_turtle",
                                     notes="ROV camera sighting (simulated); position is the ROV's estimated position."))
        m.outcome = {"localization": loc, "habitat_segments": len(segs), "sightings": len(sights), "aborted": self.aborted,
                     "true_coral_cover_mean": round(float(np.mean([x[4] for x in samples])), 3) if samples else None,
                     "estimated_coral_cover_mean": round(float(np.mean([x[3] for x in samples])), 3) if samples else None,
                     "note": "Localisation error and true coral cover come from simulator ground truth."}
        m.status = "aborted" if self.aborted else "completed"
        m.ended_at = now
        dev = db.get(Device, self.device_id)
        dev.last_lat, dev.last_lon = self.launch
        dev.battery_pct = round(max(0.0, (dev.battery_pct or 100) - self.spec.power_w * cut / 3600 / self.spec.battery_wh * 100), 1)
        log(db, m, now, f"Dive ended after {cut / 60:.1f} min: localisation RMSE {loc.get('rmse_m')} m "
                        f"(dead reckoning alone {loc.get('dead_reckoning_rmse_m')} m), {len(sights)} sightings, {len(segs)} reef segments.")
        events.publish(m.org_id, "mission.finished", {"mission_id": m.id, "status": m.status})
