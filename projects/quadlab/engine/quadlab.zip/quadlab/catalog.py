"""Component categories and their specification schemas.

A field definition tells the editor, the validator and (later) the compatibility and
performance engines what a value means. `core` marks fields those engines need; a
missing core field is reported as "missing information", never silently assumed.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict

from .units import SI_UNIT


@dataclass(frozen=True)
class Field:
    key: str
    label: str
    type: str = "number"          # number | text | list | bool
    quantity: str | None = None   # physical quantity (see units.SI_UNIT) for numbers
    unit: str | None = None       # fixed unit label for numbers with no convertible quantity
    group: str = "General"
    core: bool = False
    signed: bool = False          # negative values allowed (temperatures, dBm)
    help: str | None = None

    def as_dict(self) -> dict:
        d = asdict(self)
        d["si_unit"] = SI_UNIT.get(self.quantity) if self.quantity else self.unit
        return d


def F(key, label, type="number", q=None, unit=None, group="General", core=False, signed=False, help=None) -> Field:
    return Field(key, label, type, q, unit, group, core, signed, help)


MECH = "Mechanical"
ELEC = "Electrical"
IFACE = "Interfaces"
PERF = "Performance"
ENV = "Environment"

DIMENSIONS = [
    F("length", "Length", q="length", group=MECH),
    F("width", "Width", q="length", group=MECH),
    F("height", "Height", q="length", group=MECH),
]
TEMPS = [
    F("temp_min", "Operating temperature min", q="temperature", group=ENV, signed=True),
    F("temp_max", "Operating temperature max", q="temperature", group=ENV, signed=True),
]
WEIGHT = F("weight", "Weight", q="mass", group=MECH, core=True)
SUPPLY = [
    F("supply_voltage_min", "Supply voltage min", q="voltage", group=ELEC, core=True),
    F("supply_voltage_max", "Supply voltage max", q="voltage", group=ELEC, core=True),
    F("supply_current", "Supply current (typical/average)", q="current", group=ELEC),
    F("supply_current_peak", "Supply current (peak)", q="current", group=ELEC),
    F("power_consumption", "Power consumption", q="power", group=ELEC),
]
INTERFACE = [
    F("interfaces", "Interfaces / protocols", "list", group=IFACE, core=True, help="e.g. UART, I2C, CAN, SPI, USB"),
    F("connector", "Connector", "text", group=IFACE),
]

SENSOR_FIELDS = [
    F("sensor_type", "Sensor type", "text", core=True),
    F("range_min", "Measurement range min", unit=None, group=PERF, signed=True, help="Unit given in 'Range unit'"),
    F("range_max", "Measurement range max", unit=None, group=PERF, signed=True),
    F("range_unit", "Range unit", "text", group=PERF),
    F("accuracy", "Accuracy", "text", group=PERF, help="As stated by the source, including conditions"),
    F("resolution", "Resolution", "text", group=PERF),
    F("sample_rate_max", "Sampling frequency max", q="frequency", group=PERF),
    F("sample_rate_min", "Sampling frequency min", q="frequency", group=PERF),
    F("field_of_view", "Field of view", "text", group=PERF),
    *INTERFACE,
    *SUPPLY,
    WEIGHT,
    *DIMENSIONS,
    *TEMPS,
    F("driver_support", "Driver / firmware compatibility", "list", group=IFACE, help="e.g. PX4, ArduPilot driver names"),
]

CATEGORIES: dict[str, dict] = {
    "frame": {
        "label": "Frames",
        "singular": "Frame",
        "default_quantity": 1,
        "fields": [
            F("wheelbase", "Wheelbase (motor-to-motor diagonal)", q="length", group=MECH, core=True),
            WEIGHT,
            F("material", "Material", "text", group=MECH),
            F("arm_count", "Arm count", unit="", group=MECH, core=True),
            F("arm_tube_diameter", "Arm tube diameter", q="length", group=MECH),
            F("motor_mount_pattern", "Motor mount pattern", "text", group=MECH, core=True, help="Bolt spacing, e.g. 16x16 mm or 16/19 mm"),
            F("fc_mount_pattern", "Flight-controller mount pattern", "text", group=MECH),
            F("max_propeller_diameter", "Max propeller diameter", q="length", group=MECH, core=True),
            F("body_length", "Body plate length", q="length", group=MECH),
            F("body_width", "Body plate width", q="length", group=MECH),
            F("plate_spacing", "Space between plates", q="length", group=MECH),
            F("landing_gear_height", "Landing gear height", q="length", group=MECH),
            F("max_takeoff_weight", "Max take-off weight", q="mass", group=PERF),
            F("max_payload", "Max payload (as stated)", q="mass", group=PERF),
            F("recommended_battery", "Recommended battery", "text", group=ELEC),
        ],
    },
    "motor": {
        "label": "Motors",
        "singular": "Motor",
        "default_quantity": 4,
        "fields": [
            F("kv", "KV rating", unit="rpm/V", group=ELEC, core=True),
            F("cells_min", "LiPo cells min", unit="S", group=ELEC, core=True),
            F("cells_max", "LiPo cells max", unit="S", group=ELEC, core=True),
            F("max_voltage", "Maximum voltage", q="voltage", group=ELEC),
            F("max_current", "Maximum continuous current", q="current", group=ELEC, core=True),
            F("max_current_duration", "Max current rating duration", q="time", group=ELEC),
            F("max_power", "Maximum power", q="power", group=ELEC, core=True),
            F("internal_resistance", "Internal resistance", q="resistance", group=ELEC, core=True),
            F("idle_current", "Idle (no-load) current", q="current", group=ELEC),
            F("idle_current_voltage", "Idle current test voltage", q="voltage", group=ELEC),
            F("pole_config", "Stator/pole configuration", "text", group=ELEC),
            WEIGHT,
            F("weight_excl_cables", "Weight excluding cables", q="mass", group=MECH),
            F("shaft_diameter", "Shaft diameter", q="length", group=MECH, core=True),
            F("stator_diameter", "Stator diameter", q="length", group=MECH),
            F("stator_height", "Stator height", q="length", group=MECH),
            F("outer_diameter", "Motor outer diameter", q="length", group=MECH),
            F("body_length", "Motor body length", q="length", group=MECH),
            F("mount_pattern", "Mounting pattern", "text", group=MECH),
            F("lead_wire", "Lead wire", "text", group=MECH),
            F("recommended_propellers", "Recommended propellers", "list", group=PERF),
            F("recommended_esc", "Recommended ESC", "text", group=PERF),
            F("max_thrust", "Maximum thrust (as stated)", q="force", group=PERF),
        ],
    },
    "esc": {
        "label": "ESCs",
        "singular": "ESC",
        "default_quantity": 4,
        "fields": [
            F("continuous_current", "Continuous current", q="current", group=ELEC, core=True),
            F("burst_current", "Burst current", q="current", group=ELEC, core=True),
            F("burst_duration", "Burst duration", q="time", group=ELEC),
            F("cells_min", "LiPo cells min", unit="S", group=ELEC, core=True),
            F("cells_max", "LiPo cells max", unit="S", group=ELEC, core=True),
            F("max_voltage", "Maximum voltage", q="voltage", group=ELEC),
            F("bec", "BEC output", "text", group=ELEC, help="e.g. 5 V / 3 A, or 'none'"),
            F("firmware", "Firmware", "text", group=IFACE),
            F("protocols", "Signal protocols", "list", group=IFACE, core=True, help="e.g. PWM, OneShot125, DShot600, DroneCAN"),
            F("signal_frequency_max", "Max signal frequency", q="frequency", group=IFACE),
            F("telemetry", "ESC telemetry", "text", group=IFACE),
            WEIGHT,
            *DIMENSIONS,
            F("cooling", "Cooling requirements", "text", group=ENV),
            F("ingress_protection", "Ingress protection", "text", group=ENV),
            *TEMPS,
        ],
    },
    "propeller": {
        "label": "Propellers",
        "singular": "Propeller",
        "default_quantity": 4,
        "fields": [
            F("diameter", "Diameter", q="length", group=MECH, core=True),
            F("pitch", "Pitch", q="length", group=MECH, core=True),
            F("blade_count", "Blade count", unit="", group=MECH, core=True),
            F("material", "Material", "text", group=MECH),
            WEIGHT,
            F("weight_basis", "Weight basis", "text", group=MECH, help="What the stated weight covers (single blade, pair, with hub…)"),
            F("hub_mount", "Hub / mounting", "text", group=MECH, core=True),
            F("bore_diameter", "Bore diameter", q="length", group=MECH),
            F("rpm_min", "Recommended RPM min", q="angular_velocity", group=PERF),
            F("rpm_max", "Recommended RPM max", q="angular_velocity", group=PERF),
            F("thrust_limit", "Thrust limit", q="force", group=PERF),
            F("foldable", "Foldable", "bool", group=MECH),
            *TEMPS,
        ],
    },
    "battery": {
        "label": "Batteries",
        "singular": "Battery",
        "default_quantity": 1,
        "fields": [
            F("chemistry", "Chemistry", "text", group=ELEC, core=True),
            F("cell_count", "Cell count (series)", unit="S", group=ELEC, core=True),
            F("parallel_count", "Parallel groups", unit="P", group=ELEC),
            F("nominal_voltage", "Nominal voltage", q="voltage", group=ELEC, core=True),
            F("capacity", "Capacity", q="charge", group=ELEC, core=True),
            F("c_rating", "Continuous discharge rating", unit="C", group=ELEC, core=True),
            F("c_rating_burst", "Burst discharge rating", unit="C", group=ELEC),
            F("max_discharge_current", "Maximum continuous discharge current", q="current", group=ELEC, core=True),
            F("internal_resistance", "Internal resistance (pack)", q="resistance", group=ELEC),
            F("connector", "Discharge connector", "text", group=IFACE, core=True),
            F("balance_connector", "Balance connector", "text", group=IFACE),
            F("wire_gauge", "Discharge wire gauge", "text", group=IFACE),
            WEIGHT,
            *DIMENSIONS,
            F("part_number", "Part number / SKU", "text"),
        ],
    },
    "flight_controller": {
        "label": "Flight Controllers",
        "singular": "Flight controller",
        "default_quantity": 1,
        "fields": [
            F("processor", "FMU processor", "text", core=True),
            F("io_processor", "IO processor", "text"),
            F("imu", "IMU configuration", "list", core=True),
            F("barometer", "Barometer", "list", core=True),
            F("magnetometer", "Magnetometer", "list", core=True),
            F("uart_ports", "General-purpose UART ports", unit="", group=IFACE, core=True),
            F("gps_ports", "GPS ports", unit="", group=IFACE),
            F("can_interfaces", "CAN interfaces", unit="", group=IFACE, core=True),
            F("i2c_ports", "I2C ports", unit="", group=IFACE),
            F("pwm_outputs", "PWM outputs", unit="", group=IFACE, core=True),
            F("rc_inputs", "RC input", "list", group=IFACE),
            F("supported_firmware", "Supported firmware", "list", group=IFACE, core=True),
            F("supported_protocols", "Supported protocols", "list", group=IFACE),
            F("power_inputs", "Power inputs", "text", group=ELEC),
            F("max_input_voltage", "Max input voltage (power port)", q="voltage", group=ELEC, core=True),
            F("servo_rail_voltage_max", "Servo rail max voltage", q="voltage", group=ELEC),
            F("usb_voltage_min", "USB input min", q="voltage", group=ELEC),
            F("usb_voltage_max", "USB input max", q="voltage", group=ELEC),
            F("mount_pattern", "Mounting", "text", group=MECH),
            WEIGHT,
            *DIMENSIONS,
            *TEMPS,
        ],
    },
    "gps": {
        "label": "GPS / GNSS",
        "singular": "GNSS module",
        "default_quantity": 1,
        "fields": [
            F("receiver", "GNSS receiver", "text", core=True),
            F("constellations", "Constellations", "list", group=PERF),
            F("concurrent_gnss", "Concurrent constellations", unit="", group=PERF),
            F("bands", "Frequency bands", "list", group=PERF),
            F("position_accuracy", "Horizontal position accuracy", "text", group=PERF),
            F("update_rate_max", "Navigation update rate max", q="frequency", group=PERF),
            F("compass", "Integrated compass", "text"),
            F("protocols", "Output protocols", "list", group=IFACE),
            F("default_baud", "Default baud rate", unit="baud", group=IFACE),
            *INTERFACE,
            *SUPPLY,
            WEIGHT,
            F("diameter", "Diameter", q="length", group=MECH),
            F("height", "Height", q="length", group=MECH),
            F("cable_length", "Cable length", q="length", group=MECH),
            F("ingress_protection", "Ingress protection", "text", group=ENV),
            *TEMPS,
        ],
    },
    "imu": {"label": "IMUs", "singular": "IMU", "default_quantity": 1, "fields": SENSOR_FIELDS},
    "barometer": {"label": "Barometers", "singular": "Barometer", "default_quantity": 1, "fields": SENSOR_FIELDS},
    "magnetometer": {"label": "Magnetometers", "singular": "Magnetometer", "default_quantity": 1, "fields": SENSOR_FIELDS},
    "optical_flow": {"label": "Optical Flow", "singular": "Optical flow sensor", "default_quantity": 1, "fields": SENSOR_FIELDS},
    "rangefinder": {"label": "LiDAR / Distance", "singular": "Distance sensor", "default_quantity": 1, "fields": SENSOR_FIELDS},
    "camera": {
        "label": "Cameras",
        "singular": "Camera",
        "default_quantity": 1,
        "fields": [
            F("sensor", "Image sensor", "text"),
            F("resolution", "Resolution", "text", group=PERF),
            F("frame_rate", "Frame rate", "text", group=PERF),
            F("field_of_view", "Field of view", "text", group=PERF),
            *INTERFACE,
            *SUPPLY,
            WEIGHT,
            *DIMENSIONS,
            *TEMPS,
        ],
    },
    "telemetry": {
        "label": "Telemetry Radios",
        "singular": "Telemetry radio",
        "default_quantity": 1,
        "fields": [
            F("frequency_band", "Frequency band", "text", group=PERF, core=True),
            F("tx_power", "Max transmit power", unit="dBm", group=PERF, signed=True),
            F("rx_sensitivity", "Receive sensitivity", "text", group=PERF),
            F("air_data_rate", "Air data rate", "text", group=PERF),
            F("firmware", "Firmware", "text", group=IFACE),
            F("default_baud", "Default serial baud rate", unit="baud", group=IFACE),
            *INTERFACE,
            *SUPPLY,
            F("rx_current", "Receive current", q="current", group=ELEC),
            WEIGHT,
            F("weight_basis", "Weight basis", "text", group=MECH),
            *DIMENSIONS,
            *TEMPS,
        ],
    },
    "receiver": {
        "label": "RC Receivers",
        "singular": "RC receiver",
        "default_quantity": 1,
        "fields": [
            F("frequency_band", "Frequency band", "text", group=PERF, core=True),
            F("protocols", "Output protocols", "list", group=IFACE, core=True, help="e.g. SBUS, CRSF, PPM"),
            F("channels", "Channels", unit="", group=PERF),
            *INTERFACE,
            *SUPPLY,
            WEIGHT,
            *DIMENSIONS,
        ],
    },
    "companion": {
        "label": "Companion Computers",
        "singular": "Companion computer",
        "default_quantity": 1,
        "fields": [
            F("processor", "Processor", "text", core=True),
            F("memory", "Memory", "text"),
            F("storage", "Storage", "text"),
            *INTERFACE,
            *SUPPLY,
            WEIGHT,
            *DIMENSIONS,
            *TEMPS,
        ],
    },
    "power": {
        "label": "Power Modules / PDBs",
        "singular": "Power module / PDB",
        "default_quantity": 1,
        "fields": [
            F("cells_min", "LiPo cells min", unit="S", group=ELEC, core=True),
            F("cells_max", "LiPo cells max", unit="S", group=ELEC, core=True),
            F("continuous_current", "Continuous current", q="current", group=ELEC, core=True),
            F("burst_current", "Burst current", q="current", group=ELEC),
            F("current_sense_max", "Max current sensing", q="current", group=ELEC),
            F("output_voltage", "Regulated output voltage", q="voltage", group=ELEC, core=True),
            F("output_current_max", "Regulated output current max", q="current", group=ELEC, core=True),
            F("output_count", "Regulated outputs", unit="", group=ELEC),
            F("monitoring", "Monitoring interface", "text", group=IFACE),
            F("connectors", "Connectors", "list", group=IFACE, core=True),
            WEIGHT,
            *DIMENSIONS,
        ],
    },
    "payload": {
        "label": "Payloads / Other",
        "singular": "Payload / other",
        "default_quantity": 1,
        "fields": [
            F("description", "Function", "text"),
            *INTERFACE,
            *SUPPLY,
            WEIGHT,
            *DIMENSIONS,
        ],
    },
}

PROVENANCE: dict[str, dict] = {
    "manufacturer": {"label": "Manufacturer specification", "short": "MFR",
                     "description": "Published by the manufacturer (datasheet, product page, official documentation)."},
    "measured": {"label": "Measured data", "short": "MEAS",
                 "description": "Measured on a bench or in flight, with a traceable test record."},
    "estimate": {"label": "Estimate", "short": "EST",
                 "description": "Derived, inferred or taken from a non-authoritative source. Check the note for the basis."},
    "user": {"label": "User-entered", "short": "USER",
             "description": "Entered by a user without a linked source."},
}

SOURCE_KINDS = ["manufacturer_page", "datasheet", "official_docs", "test_report", "reseller", "other"]

# Airframe registry. Only quadcopters are implemented; the registry is the extension
# point for fixed-wing, VTOL and other multirotor layouts.
AIRFRAMES: dict[str, dict] = {
    "quadcopter": {
        "label": "Quadcopter",
        "available": True,
        "rotor_count": 4,
        "layouts": ["X", "+", "Custom"],
        "per_rotor_categories": ["motor", "esc", "propeller"],
    },
    "hexacopter": {"label": "Hexacopter", "available": False},
    "fixed_wing": {"label": "Fixed-wing", "available": False},
    "vtol": {"label": "VTOL", "available": False},
}

PROJECT_STATUSES = ["concept", "design", "build", "bench_test", "flight_test", "operational", "archived"]


def fields_for(category: str) -> list[Field]:
    return CATEGORIES[category]["fields"]


def field_map(category: str) -> dict[str, Field]:
    return {f.key: f for f in fields_for(category)}


def meta() -> dict:
    return {
        "categories": [
            {
                "key": k,
                "label": v["label"],
                "singular": v["singular"],
                "default_quantity": v["default_quantity"],
                "fields": [f.as_dict() for f in v["fields"]],
            }
            for k, v in CATEGORIES.items()
        ],
        "provenance": PROVENANCE,
        "source_kinds": SOURCE_KINDS,
        "airframes": AIRFRAMES,
        "project_statuses": PROJECT_STATUSES,
    }
