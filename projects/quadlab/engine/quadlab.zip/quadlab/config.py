from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "QuadLab Pro"
APP_VERSION = "1.0.0"
PHASE = 6

ROOT = Path(__file__).resolve().parents[2]            # .../quadlab


def data_dir() -> Path:
    d = Path(os.environ.get("QUADLAB_DATA_DIR") or ROOT / "data")
    d.mkdir(parents=True, exist_ok=True)
    return d


def database_url() -> str:
    """SQLite for standalone use; set QUADLAB_DATABASE_URL to a PostgreSQL URL for production."""
    return os.environ.get("QUADLAB_DATABASE_URL") or f"sqlite:///{(data_dir() / 'quadlab.db').as_posix()}"


def datasheet_dir() -> Path:
    d = data_dir() / "datasheets"
    d.mkdir(parents=True, exist_ok=True)
    return d


def log_path() -> Path:
    d = data_dir() / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d / "quadlab.log"


def frontend_dist() -> Path:
    return Path(os.environ.get("QUADLAB_FRONTEND_DIST") or ROOT / "frontend" / "dist")


def browser() -> bool:
    """True in the browser edition (backend on Pyodide inside a web page): no sockets, serial ports or threads."""
    return os.environ.get("QUADLAB_BROWSER") == "1"
