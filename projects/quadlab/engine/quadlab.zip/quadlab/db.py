from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, Text, create_engine, event
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker

from . import config


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Component(Base):
    __tablename__ = "components"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category: Mapped[str] = mapped_column(String(40), index=True)
    manufacturer: Mapped[str] = mapped_column(String(120), index=True)
    model: Mapped[str] = mapped_column(String(160), index=True)
    variant: Mapped[str] = mapped_column(String(160), default="")       # profile / revision label
    description: Mapped[str] = mapped_column(Text, default="")
    origin: Mapped[str] = mapped_column(String(20), default="custom")    # library | custom
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("components.id", ondelete="SET NULL"), nullable=True)
    specs: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    sources: Mapped[list["Source"]] = relationship(back_populates="component", cascade="all, delete-orphan", order_by="Source.id")
    thrust_tests: Mapped[list["ThrustTest"]] = relationship(back_populates="component", cascade="all, delete-orphan", order_by="ThrustTest.id", foreign_keys="ThrustTest.component_id")
    history: Mapped[list["ComponentRevision"]] = relationship(back_populates="component", cascade="all, delete-orphan", order_by="ComponentRevision.id.desc()")


class Source(Base):
    """Where a specification came from: a URL and/or a stored datasheet file."""
    __tablename__ = "sources"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    component_id: Mapped[int] = mapped_column(ForeignKey("components.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(30), default="other")
    title: Mapped[str] = mapped_column(String(300))
    url: Mapped[str | None] = mapped_column(Text, nullable=True)
    file_name: Mapped[str | None] = mapped_column(String(300), nullable=True)
    file_path: Mapped[str | None] = mapped_column(Text, nullable=True)
    file_size: Mapped[int | None] = mapped_column(Integer, nullable=True)
    retrieved_on: Mapped[str | None] = mapped_column(String(10), nullable=True)   # ISO date
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    component: Mapped[Component] = relationship(back_populates="sources")


class ThrustTest(Base):
    """A motor + propeller static thrust test at one supply voltage. Points are SI."""
    __tablename__ = "thrust_tests"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    component_id: Mapped[int] = mapped_column(ForeignKey("components.id", ondelete="CASCADE"), index=True)
    propeller: Mapped[str] = mapped_column(String(160))
    propeller_component_id: Mapped[int | None] = mapped_column(ForeignKey("components.id", ondelete="SET NULL"), nullable=True)
    voltage: Mapped[float] = mapped_column(Float)                     # nominal supply voltage, V
    provenance: Mapped[str] = mapped_column(String(20), default="user")
    source_id: Mapped[int | None] = mapped_column(ForeignKey("sources.id", ondelete="SET NULL"), nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")
    points: Mapped[list] = mapped_column(JSON, default=list)

    component: Mapped[Component] = relationship(back_populates="thrust_tests", foreign_keys=[component_id])


class ComponentRevision(Base):
    __tablename__ = "component_revisions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    component_id: Mapped[int] = mapped_column(ForeignKey("components.id", ondelete="CASCADE"), index=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    summary: Mapped[str] = mapped_column(String(300))
    changes: Mapped[list] = mapped_column(JSON, default=list)

    component: Mapped[Component] = relationship(back_populates="history")


class Project(Base):
    __tablename__ = "projects"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    code: Mapped[str] = mapped_column(String(40), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    airframe: Mapped[str] = mapped_column(String(30), default="quadcopter")
    layout: Mapped[str] = mapped_column(String(20), default="X")
    status: Mapped[str] = mapped_column(String(20), default="concept")
    owner: Mapped[str] = mapped_column(String(120), default="")
    # User overrides to the generated design: {"assembly": {"wheelbase", "placements"}, "electrical": {"ports"}}
    design: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    items: Mapped[list["ProjectItem"]] = relationship(back_populates="project", cascade="all, delete-orphan", order_by="ProjectItem.id")
    revisions: Mapped[list["ProjectRevision"]] = relationship(back_populates="project", cascade="all, delete-orphan", order_by="ProjectRevision.number.desc()")
    param_sets: Mapped[list["ParamSet"]] = relationship(cascade="all, delete-orphan")
    simulation_runs: Mapped[list["SimulationRun"]] = relationship(cascade="all, delete-orphan")
    telemetry_logs: Mapped[list["TelemetryLog"]] = relationship(cascade="all, delete-orphan")
    test_campaigns: Mapped[list["TestCampaign"]] = relationship(cascade="all, delete-orphan")
    flight_logs: Mapped[list["FlightLog"]] = relationship(cascade="all, delete-orphan")
    reports: Mapped[list["Report"]] = relationship(cascade="all, delete-orphan")


class ProjectItem(Base):
    __tablename__ = "project_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    component_id: Mapped[int] = mapped_column(ForeignKey("components.id", ondelete="RESTRICT"), index=True)
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    role: Mapped[str] = mapped_column(String(120), default="")
    note: Mapped[str] = mapped_column(Text, default="")

    project: Mapped[Project] = relationship(back_populates="items")
    component: Mapped[Component] = relationship()


class ProjectRevision(Base):
    """Immutable snapshot of a project's configuration, including the component
    specifications as they were at that moment."""
    __tablename__ = "project_revisions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    number: Mapped[int] = mapped_column(Integer)
    label: Mapped[str] = mapped_column(String(160), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    snapshot: Mapped[dict] = mapped_column(JSON, default=dict)

    project: Mapped[Project] = relationship(back_populates="revisions")


class ParamSet(Base):
    """A named flight-controller parameter set: generated from the design, imported from a file, or read from a vehicle."""
    __tablename__ = "param_sets"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    autopilot: Mapped[str] = mapped_column(String(20), default="unknown")
    source: Mapped[str] = mapped_column(String(20), default="imported")        # generated | imported | vehicle
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    params: Mapped[dict] = mapped_column(JSON, default=dict)


class SimulationRun(Base):
    """Result of one internal-simulator run. Always simulated data — never mixed with flight logs."""
    __tablename__ = "simulation_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    scenario: Mapped[str] = mapped_column(String(40))
    outcome: Mapped[str] = mapped_column(String(40))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    result: Mapped[dict] = mapped_column(JSON, default=dict)


class TelemetryLog(Base):
    """A recorded telemetry session. Frames and the raw MAVLink log live in data/telemetry/."""
    __tablename__ = "telemetry_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    source: Mapped[str] = mapped_column(String(20))                      # vehicle | simulator
    sim_evidence: Mapped[str] = mapped_column(Text, default="")
    autopilot: Mapped[str] = mapped_column(String(40), default="")
    device: Mapped[str] = mapped_column(String(200), default="")
    card_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    duration: Mapped[float] = mapped_column(Float, default=0.0)
    frames: Mapped[int] = mapped_column(Integer, default=0)
    messages: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str] = mapped_column(Text, default="")


class TestCampaign(Base):
    """A flight-test campaign for one pinned configuration (a project revision)."""
    __tablename__ = "test_campaigns"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    revision_id: Mapped[int] = mapped_column(Integer)
    name: Mapped[str] = mapped_column(String(200))
    objective: Mapped[str] = mapped_column(Text, default="")
    hardware_revision: Mapped[str] = mapped_column(String(120), default="")
    firmware_version: Mapped[str] = mapped_column(String(120), default="")
    waivers: Mapped[list] = mapped_column(JSON, default=list)             # [{stage, reason, by, at}]
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    cards: Mapped[list["TestCard"]] = relationship(back_populates="campaign", cascade="all, delete-orphan", order_by="TestCard.id")


class TestCard(Base):
    __tablename__ = "test_cards"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    campaign_id: Mapped[int] = mapped_column(ForeignKey("test_campaigns.id", ondelete="CASCADE"), index=True)
    code: Mapped[str] = mapped_column(String(40))
    stage: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default="planned")    # planned | authorised | in_progress | done
    verdict: Mapped[str | None] = mapped_column(String(20), nullable=True)   # pass | fail | inconclusive
    data: Mapped[dict] = mapped_column(JSON, default=dict)                # editable content of the card
    gate: Mapped[dict | None] = mapped_column(JSON, nullable=True)        # last safety-gate authorisation
    events: Mapped[list] = mapped_column(JSON, default=list)              # audit trail
    telemetry_log_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    campaign: Mapped[TestCampaign] = relationship(back_populates="cards")


class FlightLog(Base):
    """An imported flight log with its post-flight analysis. Channel data lives in data/flightlogs/<id>.json."""
    __tablename__ = "flight_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    format: Mapped[str] = mapped_column(String(20))
    source: Mapped[str] = mapped_column(String(20), default="unknown")        # vehicle | simulator | unknown
    autopilot: Mapped[str] = mapped_column(String(60), default="")
    duration: Mapped[float] = mapped_column(Float, default=0.0)
    file_name: Mapped[str] = mapped_column(String(300), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    imported_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    analysis: Mapped[dict] = mapped_column(JSON, default=dict)


class Report(Base):
    """A generated engineering report, stored as the HTML that was produced."""
    __tablename__ = "reports"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(20))
    title: Mapped[str] = mapped_column(String(300))
    ref_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    html: Mapped[str] = mapped_column(Text)


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)


class Flag(Base):
    """Internal bookkeeping (e.g. which seed version has been applied)."""
    __tablename__ = "flags"
    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[str] = mapped_column(String(200))


_engine = None
_Session = None

# Columns added after the first release: (table, column, DDL type, default literal).
ADDED_COLUMNS = [("projects", "design", "JSON", "'{}'")]


def _migrate(engine) -> None:
    """Additive schema upgrades for databases created by an earlier version."""
    from sqlalchemy import inspect, text
    insp = inspect(engine)
    with engine.begin() as conn:
        for table, column, ddl, default in ADDED_COLUMNS:
            if column not in {c["name"] for c in insp.get_columns(table)}:
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {column} {ddl} DEFAULT {default}"))


def init_engine(url: str | None = None):
    global _engine, _Session
    url = url or config.database_url()
    kwargs = {}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
    _engine = create_engine(url, **kwargs)
    if url.startswith("sqlite"):
        @event.listens_for(_engine, "connect")
        def _pragmas(dbapi_conn, _):
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA journal_mode=WAL")
            cur.close()
    _Session = sessionmaker(bind=_engine, expire_on_commit=False)
    Base.metadata.create_all(_engine)
    _migrate(_engine)
    return _engine


def get_session():
    if _Session is None:
        init_engine()
    session = _Session()
    try:
        yield session
    finally:
        session.close()


def session_factory():
    if _Session is None:
        init_engine()
    return _Session
