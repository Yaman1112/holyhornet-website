from __future__ import annotations

from fastapi import APIRouter, Body, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import Project, get_session
from ..services import assembly, compatibility, electrical
from ..services import projects as svc

router = APIRouter(prefix="/api/projects", tags=["projects"])
compare_router = APIRouter(prefix="/api/compare", tags=["comparison"])


@router.get("")
def list_projects(db: Session = Depends(get_session)):
    return [svc.list_dict(p) for p in db.scalars(select(Project).order_by(Project.updated_at.desc()))]


@router.post("", status_code=201)
def create_project(data: dict = Body(...), db: Session = Depends(get_session)):
    return svc.detail_dict(svc.create(db, data))


@router.get("/{project_id}")
def get_project(project_id: int, db: Session = Depends(get_session)):
    return svc.detail_dict(svc.get(db, project_id))


@router.put("/{project_id}")
def update_project(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return svc.detail_dict(svc.update(db, project_id, data))


@router.delete("/{project_id}", status_code=204)
def delete_project(project_id: int, db: Session = Depends(get_session)):
    svc.delete(db, project_id)


@router.post("/{project_id}/duplicate", status_code=201)
def duplicate_project(project_id: int, data: dict = Body(default={}), db: Session = Depends(get_session)):
    return svc.detail_dict(svc.duplicate(db, project_id, data.get("name")))


@router.post("/{project_id}/items", status_code=201)
def add_item(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    svc.add_item(db, project_id, data)
    return svc.detail_dict(svc.get(db, project_id))


@router.put("/{project_id}/items/{item_id}")
def update_item(project_id: int, item_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    svc.update_item(db, project_id, item_id, data)
    return svc.detail_dict(svc.get(db, project_id))


@router.delete("/{project_id}/items/{item_id}")
def remove_item(project_id: int, item_id: int, db: Session = Depends(get_session)):
    svc.remove_item(db, project_id, item_id)
    return svc.detail_dict(svc.get(db, project_id))


@router.post("/{project_id}/revisions", status_code=201)
def create_revision(project_id: int, data: dict = Body(default={}), db: Session = Depends(get_session)):
    svc.create_revision(db, project_id, data.get("label", ""), data.get("note", ""))
    return svc.detail_dict(svc.get(db, project_id))


@router.get("/{project_id}/revisions/diff")
def diff_revisions(project_id: int, a: str, b: str, db: Session = Depends(get_session)):
    return svc.diff(db, project_id, a, b)


@router.get("/{project_id}/revisions/{revision_id}")
def get_revision(project_id: int, revision_id: int, db: Session = Depends(get_session)):
    return svc.revision_dict(svc.get_revision(db, project_id, revision_id))


@router.post("/{project_id}/revisions/{revision_id}/restore")
def restore_revision(project_id: int, revision_id: int, db: Session = Depends(get_session)):
    report = svc.restore_revision(db, project_id, revision_id)
    return {"report": report, "project": svc.detail_dict(svc.get(db, project_id))}


# ---------------------------------------------------------------- phase 2: compatibility, 3D assembly, electrical

@router.get("/{project_id}/compatibility")
def get_compatibility(project_id: int, db: Session = Depends(get_session)):
    return compatibility.with_alternatives(db, svc.config_of(svc.get(db, project_id)))


@router.get("/{project_id}/assembly")
def get_assembly(project_id: int, db: Session = Depends(get_session)):
    return assembly.build(svc.config_of(svc.get(db, project_id)))


@router.put("/{project_id}/assembly")
def put_assembly(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return assembly.build(svc.config_of(svc.set_wheelbase(db, project_id, data.get("wheelbase"))))


@router.put("/{project_id}/assembly/parts/{key}")
def move_part(project_id: int, key: str, data: dict = Body(...), db: Session = Depends(get_session)):
    return assembly.build(svc.config_of(svc.set_placement(db, project_id, key, data)))


@router.delete("/{project_id}/assembly/parts/{key}")
def reset_part(project_id: int, key: str, db: Session = Depends(get_session)):
    return assembly.build(svc.config_of(svc.set_placement(db, project_id, key, None)))


@router.get("/{project_id}/electrical")
def get_electrical(project_id: int, db: Session = Depends(get_session)):
    return electrical.build(svc.config_of(svc.get(db, project_id)))


@router.put("/{project_id}/electrical/ports/{key}")
def assign_port(project_id: int, key: str, data: dict = Body(...), db: Session = Depends(get_session)):
    return electrical.build(svc.config_of(svc.set_port(db, project_id, key, data.get("port"))))


# ---------------------------------------------------------------- phase 3: performance and configuration comparison

@router.get("/{project_id}/performance")
def get_performance(project_id: int, db: Session = Depends(get_session)):
    return svc.performance_of(svc.get(db, project_id))


@router.put("/{project_id}/performance/params")
def put_performance_params(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return svc.performance_of(svc.set_performance_params(db, project_id, data))


@compare_router.get("/choices")
def compare_choices(db: Session = Depends(get_session)):
    return svc.config_choices(db)


@compare_router.post("")
def compare(data: dict = Body(...), db: Session = Depends(get_session)):
    return svc.compare_configs(db, data.get("configs"))
