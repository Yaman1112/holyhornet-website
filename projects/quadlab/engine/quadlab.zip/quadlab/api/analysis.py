"""Phase 6 routes: flight-log import and analysis, reports, AI assistant."""
from __future__ import annotations

import json
import uuid
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, Form, UploadFile
from fastapi.responses import HTMLResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..db import FlightLog, SimulationRun, TelemetryLog, get_session
from ..services import analysis, assistant, flightlog, reports, telemetry
from ..services import projects as psvc
from ..services.components import NotFound, ValidationError

router = APIRouter(prefix="/api", tags=["analysis"])
MAX_LOG = 200 * 1024 * 1024
SOURCES = ("vehicle", "simulator", "unknown")


def log_dir() -> Path:
    d = config.data_dir() / "flightlogs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _cfg_info(p) -> dict:
    cfg = psvc.config_of(p)
    batt = cfg.one("battery")
    return {"cells": batt.num("cell_count") if batt else None, "capacity_mah": batt.num("capacity") / 3.6 if batt and batt.num("capacity") else None,
            "battery": batt.name if batt else None}


def _sim_hover(run: SimulationRun | None) -> dict | None:
    if run is None:
        return None
    s = [x for x in run.result.get("samples", []) if x["alt"] > 0.5 and abs(x["vz"]) < 0.2 and (x["vx"] ** 2 + x["vy"] ** 2) ** 0.5 < 0.5]
    if len(s) < 10:
        return None
    return {"hover_power": sum(x["power"] for x in s) / len(s), "hover_current": sum(x["current"] for x in s) / len(s), "run_id": run.id, "scenario": run.scenario}


def _analyse(db: Session, p, ds: dict, sim_run_id: int | None = None) -> dict:
    a = analysis.analyse(ds, _cfg_info(p))
    perf = psvc.performance_of(p)
    run = db.get(SimulationRun, sim_run_id) if sim_run_id else db.scalars(
        select(SimulationRun).where(SimulationRun.project_id == p.id, SimulationRun.outcome == "completed").order_by(SimulationRun.id.desc())).first()
    sim = _sim_hover(run if run and run.project_id == p.id else None)
    a["comparison"] = {**analysis.compare(a["measured"], perf["metrics"], sim, perf["params"]), "simulation_run": {k: sim[k] for k in ("run_id", "scenario")} if sim else None}
    return a


def brief(r: FlightLog) -> dict:
    a = r.analysis or {}
    return {"id": r.id, "project_id": r.project_id, "name": r.name, "format": r.format, "source": r.source, "autopilot": r.autopilot, "duration": r.duration,
            "file_name": r.file_name, "imported_at": r.imported_at.isoformat(), "overall": a.get("overall"), "flew": a.get("flew"), "note": r.note,
            "statuses": {s["key"]: s["status"] for s in a.get("sections", [])}}


def _store(db: Session, p, name: str, source: str, ds: dict, file_name: str, note: str = "") -> FlightLog:
    if source not in SOURCES:
        raise ValidationError([f"source must be one of {', '.join(SOURCES)}"])
    a = _analyse(db, p, ds)                                  # analysis runs on the full-resolution data
    r = FlightLog(project_id=p.id, name=name.strip() or file_name, format=ds["meta"]["format"], source=source, autopilot=ds["meta"].get("autopilot", ""),
                  duration=ds["meta"]["duration"], file_name=file_name, note=note, analysis=a)
    db.add(r)
    db.commit()
    (log_dir() / f"{r.id}.json").write_text(json.dumps(flightlog.downsample(ds)), encoding="utf-8")
    return r


@router.get("/analysis/meta")
def analysis_meta():
    return {"formats": sorted(flightlog.FORMATS), "sources": SOURCES, "channels": {k: {"label": v[0], "unit": v[1]} for k, v in flightlog.CHANNEL_INFO.items()}}


@router.get("/projects/{project_id}/flight-logs")
def list_logs(project_id: int, db: Session = Depends(get_session)):
    psvc.get(db, project_id)
    return [brief(r) for r in db.scalars(select(FlightLog).where(FlightLog.project_id == project_id).order_by(FlightLog.id.desc()))]


@router.post("/projects/{project_id}/flight-logs/import", status_code=201)
async def import_log(project_id: int, file: UploadFile = File(...), name: str = Form(""), source: str = Form("unknown"), db: Session = Depends(get_session)):
    p = psvc.get(db, project_id)
    fname = Path(file.filename or "log").name
    ext = Path(fname).suffix.lower()
    if ext not in flightlog.FORMATS:
        raise ValidationError([f"unsupported log type '{ext or '(none)'}'. Supported: {', '.join(sorted(flightlog.FORMATS))}"])
    tmp = log_dir() / f"upload-{uuid.uuid4().hex}{ext}"
    size = 0
    try:
        with tmp.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_LOG:
                    raise ValidationError(["log file is larger than 200 MB"])
                out.write(chunk)
        if size == 0:
            raise ValidationError(["the file is empty"])
        ds = flightlog.parse(tmp)
    finally:
        tmp.unlink(missing_ok=True)
    return brief(_store(db, p, name, source, ds, fname))


@router.post("/telemetry/logs/{log_id}/analyse", status_code=201)
def analyse_recording(log_id: int, db: Session = Depends(get_session)):
    """Analyse a QuadLab telemetry recording from its raw MAVLink log."""
    t: TelemetryLog = telemetry.get_log(db, log_id)
    path = telemetry.log_dir() / f"{t.id}.tlog"
    if not path.is_file() or t.ended_at is None:
        raise ValidationError(["this recording has no finished raw MAVLink log to analyse"])
    ds = flightlog.parse(path, "tlog")
    return brief(_store(db, psvc.get(db, t.project_id), t.name, t.source, ds, f"telemetry-{t.id}.tlog", f"From telemetry recording #{t.id}."))


@router.get("/flight-logs/{log_id}")
def get_log(log_id: int, db: Session = Depends(get_session)):
    r = db.get(FlightLog, log_id)
    if r is None:
        raise NotFound(f"flight log {log_id} not found")
    path = log_dir() / f"{r.id}.json"
    ds = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {"channels": {}, "events": [], "meta": {}}
    return {**brief(r), "analysis": r.analysis, "channels": ds["channels"], "events": ds["events"], "meta": ds["meta"]}


@router.put("/flight-logs/{log_id}")
def update_log(log_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    r = db.get(FlightLog, log_id)
    if r is None:
        raise NotFound(f"flight log {log_id} not found")
    if "source" in data:
        if data["source"] not in SOURCES:
            raise ValidationError([f"source must be one of {', '.join(SOURCES)}"])
        r.source = data["source"]
    if "name" in data and str(data["name"]).strip():
        r.name = str(data["name"]).strip()
    db.commit()
    return brief(r)


@router.post("/flight-logs/{log_id}/compare")
def recompare(log_id: int, data: dict = Body(default={}), db: Session = Depends(get_session)):
    """Recompute the comparison against the current estimate and a chosen simulator run."""
    r = db.get(FlightLog, log_id)
    if r is None:
        raise NotFound(f"flight log {log_id} not found")
    p = psvc.get(db, r.project_id)
    perf = psvc.performance_of(p)
    run = db.get(SimulationRun, data.get("simulation_run_id") or 0)
    if data.get("simulation_run_id") and (run is None or run.project_id != p.id):
        raise ValidationError(["simulation run not found in this project"])
    sim = _sim_hover(run)
    a = dict(r.analysis)
    a["comparison"] = {**analysis.compare(a["measured"], perf["metrics"], sim, perf["params"]), "simulation_run": {k: sim[k] for k in ("run_id", "scenario")} if sim else None}
    r.analysis = a
    db.commit()
    return a["comparison"]


@router.delete("/flight-logs/{log_id}", status_code=204)
def delete_log(log_id: int, db: Session = Depends(get_session)):
    r = db.get(FlightLog, log_id)
    if r is None:
        raise NotFound(f"flight log {log_id} not found")
    (log_dir() / f"{r.id}.json").unlink(missing_ok=True)
    db.delete(r)
    db.commit()


# ---------------------------------------------------------------- reports

@router.get("/projects/{project_id}/reports")
def list_reports(project_id: int, db: Session = Depends(get_session)):
    psvc.get(db, project_id)
    return reports.list_reports(db, project_id)


@router.post("/projects/{project_id}/reports", status_code=201)
def create_report(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return reports.brief(reports.generate(db, project_id, data.get("kind"), data.get("ref_id")))


@router.get("/reports/{report_id}/html", response_class=HTMLResponse)
def report_html(report_id: int, download: bool = False, db: Session = Depends(get_session)):
    r = reports.get(db, report_id)
    headers = {"Content-Disposition": f'attachment; filename="quadlab-report-{r.id}.html"'} if download else {}
    return HTMLResponse(r.html, headers=headers)


@router.delete("/reports/{report_id}", status_code=204)
def delete_report(report_id: int, db: Session = Depends(get_session)):
    db.delete(reports.get(db, report_id))
    db.commit()


# ---------------------------------------------------------------- assistant

@router.get("/assistant/status")
def assistant_status():
    return assistant.status()


@router.put("/assistant/key")
def assistant_key(data: dict = Body(...)):
    return assistant.save_key(data.get("api_key"))


@router.post("/projects/{project_id}/assistant/ask")
def assistant_ask(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return assistant.ask(db, psvc.get(db, project_id), data.get("question"), data.get("history"))


@router.get("/projects/{project_id}/assistant/limiting-factors")
def assistant_limits(project_id: int, db: Session = Depends(get_session)):
    return assistant.limiting_factors(db, psvc.get(db, project_id))


@router.post("/projects/{project_id}/assistant/what-if")
def assistant_what_if(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return assistant.what_if(db, psvc.get(db, project_id), data.get("swaps"), data.get("payload_mass"))
