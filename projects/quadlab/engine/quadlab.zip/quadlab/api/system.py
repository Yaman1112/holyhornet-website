from __future__ import annotations

import platform
import sys

from fastapi import APIRouter, Body, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import catalog, config, units
from ..db import Component, ComponentRevision, Project, Setting, get_session
from ..services import components as csvc
from ..services import projects as psvc

router = APIRouter(prefix="/api", tags=["system"])

DEFAULT_SETTINGS = {"unit_system": "metric"}

# Module roadmap shown in the navigation. `available` is the single source of truth
# for what the UI lets the user open; nothing is presented as working before it is.
MODULES = [
    {"key": "dashboard", "label": "Dashboard", "phase": 1},
    {"key": "projects", "label": "Drone Projects", "phase": 1},
    {"key": "design", "label": "3D Design Studio", "phase": 2},
    {"key": "library", "label": "Component Library", "phase": 1},
    {"key": "compatibility", "label": "Hardware Compatibility", "phase": 2},
    {"key": "electrical", "label": "Electrical Architecture", "phase": 2},
    {"key": "performance", "label": "Performance Analysis", "phase": 3},
    {"key": "fc", "label": "Flight Controller", "phase": 4},
    {"key": "simulation", "label": "Simulation", "phase": 4},
    {"key": "testing", "label": "Flight Testing", "phase": 5},
    {"key": "telemetry", "label": "Live Telemetry", "phase": 5},
    {"key": "analysis", "label": "Post-Flight Analysis", "phase": 6},
    {"key": "assistant", "label": "AI Engineering Assistant", "phase": 6},
    {"key": "reports", "label": "Reports", "phase": 6},
    {"key": "settings", "label": "Settings", "phase": 1},
]


@router.get("/meta")
def meta():
    return {
        "app": {"name": config.APP_NAME, "version": config.APP_VERSION, "phase": config.PHASE},
        "modules": [{**m, "available": m["phase"] <= config.PHASE} for m in MODULES],
        **catalog.meta(),
        **units.meta(),
    }


def _settings(db: Session) -> dict:
    row = db.get(Setting, "app")
    return {**DEFAULT_SETTINGS, **(row.value if row else {})}


@router.get("/settings")
def get_settings(db: Session = Depends(get_session)):
    return _settings(db)


@router.put("/settings")
def put_settings(data: dict = Body(...), db: Session = Depends(get_session)):
    current = _settings(db)
    if "unit_system" in data:
        if data["unit_system"] not in units.DISPLAY:
            raise csvc.ValidationError([f"unit_system must be one of {', '.join(units.DISPLAY)}"])
        current["unit_system"] = data["unit_system"]
    row = db.get(Setting, "app")
    if row is None:
        db.add(Setting(key="app", value=current))
    else:
        row.value = current
    db.commit()
    return current


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_session)):
    comps = list(db.scalars(select(Component)))
    by_cat: dict[str, int] = {}
    prov = {k: 0 for k in catalog.PROVENANCE}
    incomplete = 0
    for c in comps:
        by_cat[c.category] = by_cat.get(c.category, 0) + 1
        for k, n in csvc.provenance_counts(c).items():
            prov[k] = prov.get(k, 0) + n
        if csvc.completeness(c)["missing"]:
            incomplete += 1
    projects = [psvc.list_dict(p) for p in db.scalars(select(Project).order_by(Project.updated_at.desc()))]
    recent = db.execute(
        select(ComponentRevision, Component).join(Component, Component.id == ComponentRevision.component_id)
        .order_by(ComponentRevision.id.desc()).limit(8)).all()
    return {
        "components": {
            "total": len(comps),
            "library": sum(1 for c in comps if c.origin == "library"),
            "custom": sum(1 for c in comps if c.origin == "custom"),
            "incomplete": incomplete,
            "by_category": [{"key": k, "label": catalog.CATEGORIES[k]["label"], "count": by_cat.get(k, 0)} for k in catalog.CATEGORIES],
            "spec_values_by_provenance": prov,
            "thrust_tests": sum(len(c.thrust_tests) for c in comps),
        },
        "projects": {
            "total": len(projects),
            "by_status": {s: sum(1 for p in projects if p["status"] == s) for s in catalog.PROJECT_STATUSES},
            "unsaved": sum(1 for p in projects if p["has_unsaved_changes"]),
            "recent": projects[:6],
        },
        "recent_component_changes": [
            {"component_id": c.id, "name": csvc.display_name(c), "category": c.category, "at": h.at.isoformat(), "summary": h.summary}
            for h, c in recent
        ],
    }


@router.get("/diagnostics")
def diagnostics(lines: int = 200, db: Session = Depends(get_session)):
    path = config.log_path()
    tail: list[str] = []
    if path.is_file():
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            tail = fh.readlines()[-max(1, min(lines, 2000)):]
    url = config.database_url()
    return {
        "app": {"name": config.APP_NAME, "version": config.APP_VERSION, "phase": config.PHASE},
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "database": url.split("@")[-1] if "@" in url else url,
        "data_dir": str(config.data_dir()),
        "log_file": str(path),
        "counts": {"components": db.scalar(select(func.count()).select_from(Component)),
                   "projects": db.scalar(select(func.count()).select_from(Project))},
        "log_tail": [line.rstrip("\n") for line in tail],
    }
