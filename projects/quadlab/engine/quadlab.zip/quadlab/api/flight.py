"""Phase 4 routes: flight-controller configuration, MAVLink link, simulation."""
from __future__ import annotations

from fastapi import APIRouter, Body, Depends, File, Form, UploadFile
from fastapi.responses import PlainTextResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import SimulationRun, get_session
from ..services import autopilot, simulation
from ..services import projects as psvc
from ..services.components import NotFound, ValidationError
from ..services.link import LINK

router = APIRouter(prefix="/api", tags=["flight"])
MAX_PARAM_FILE = 2 * 1024 * 1024
KEEP_RUNS = 20


# ---------------------------------------------------------------- proposed configuration and parameter sets

@router.get("/projects/{project_id}/autopilot/proposal")
def proposal(project_id: int, autopilot_name: str = "px4", db: Session = Depends(get_session)):
    p = psvc.get(db, project_id)
    hover = psvc.performance_of(p)["metrics"].get("hover_throttle")
    return autopilot.propose(psvc.config_of(p), autopilot_name, hover)


@router.post("/projects/{project_id}/autopilot/proposal/save", status_code=201)
def save_proposal(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    p = psvc.get(db, project_id)
    ap = data.get("autopilot", "px4")
    prop = autopilot.propose(psvc.config_of(p), ap, psvc.performance_of(p)["metrics"].get("hover_throttle"))
    params = {e["name"]: {"value": e["value"], "type": e["type"]} for e in prop["entries"]}
    s = autopilot.save_set(db, p.id, data.get("name") or f"Proposed {prop['autopilot_label']} configuration", params, ap, "generated",
                           "Generated from the project design. Review before use.")
    return autopilot.set_brief(s)


@router.get("/projects/{project_id}/param-sets")
def list_param_sets(project_id: int, db: Session = Depends(get_session)):
    psvc.get(db, project_id)
    return autopilot.list_sets(db, project_id)


@router.post("/projects/{project_id}/param-sets/import", status_code=201)
async def import_param_set(project_id: int, file: UploadFile = File(...), name: str = Form(""), db: Session = Depends(get_session)):
    psvc.get(db, project_id)
    raw = await file.read(MAX_PARAM_FILE + 1)
    if len(raw) > MAX_PARAM_FILE:
        raise ValidationError(["parameter file is larger than 2 MB"])
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValidationError(["parameter file is not text"])
    params, fmt, warnings = autopilot.parse_param_file(text)
    s = autopilot.save_set(db, project_id, name.strip() or (file.filename or "Imported parameters"), params, autopilot.guess_autopilot(params),
                           "imported", f"Imported from {file.filename} ({fmt.replace('_', ' ')} format).")
    return {**autopilot.set_brief(s), "format": fmt, "warnings": warnings}


@router.get("/param-sets/{set_id}")
def get_param_set(set_id: int, db: Session = Depends(get_session)):
    return autopilot.set_detail(autopilot.get_set(db, set_id))


@router.delete("/param-sets/{set_id}", status_code=204)
def delete_param_set(set_id: int, db: Session = Depends(get_session)):
    autopilot.delete_set(db, set_id)


@router.get("/param-sets/{set_id}/export", response_class=PlainTextResponse)
def export_param_set(set_id: int, format: str = "qgroundcontrol", db: Session = Depends(get_session)):
    s = autopilot.get_set(db, set_id)
    text, warnings = autopilot.export_param_file(s.params, format)
    ext = "params" if format == "qgroundcontrol" else "param"
    headers = {"Content-Disposition": f'attachment; filename="paramset-{s.id}.{ext}"'}
    if warnings:
        headers["X-QuadLab-Warning"] = warnings[0].encode("ascii", "replace").decode()
    return PlainTextResponse(text, headers=headers)


def _side(db: Session, ref: str) -> tuple[str, dict]:
    if ref == "vehicle":
        if not LINK.params:
            raise ValidationError(["no parameters have been read from the vehicle"])
        return "Connected vehicle", {k: {"value": v["value"], "type": v["type"]} for k, v in LINK.params.items()}
    try:
        s = autopilot.get_set(db, int(ref))
    except ValueError:
        raise ValidationError(["compare references must be a parameter-set id or 'vehicle'"])
    return s.name, s.params


@router.get("/param-sets-diff")
def diff_param_sets(a: str, b: str, db: Session = Depends(get_session)):
    name_a, pa = _side(db, a)
    name_b, pb = _side(db, b)
    return {"a": {"ref": a, "name": name_a, "count": len(pa)}, "b": {"ref": b, "name": name_b, "count": len(pb)}, **autopilot.diff(pa, pb)}


# ---------------------------------------------------------------- vehicle link

@router.get("/link/status")
def link_status():
    return LINK.status()


@router.post("/link/connect")
def link_connect(data: dict = Body(...)):
    return LINK.connect(data)


@router.post("/link/disconnect")
def link_disconnect(db: Session = Depends(get_session)):
    from ..services import telemetry
    telemetry.stop_recording(db, LINK)            # close any recording cleanly before the link goes away
    LINK.disconnect()
    return LINK.status()


@router.get("/link/telemetry")
def link_telemetry():
    return LINK.telemetry()


@router.post("/link/params/read")
def link_read_params(data: dict = Body(default={}), db: Session = Depends(get_session)):
    result = LINK.read_params()
    saved = None
    if data.get("save_to_project"):
        psvc.get(db, int(data["save_to_project"]))
        hb = LINK.heartbeat or {}
        s = autopilot.save_set(db, int(data["save_to_project"]), data.get("name") or "Read from vehicle", result["params"],
                               hb.get("autopilot") if hb.get("autopilot") in autopilot.AUTOPILOTS else "unknown", "vehicle",
                               f"Read over {LINK.device}" + ("" if result["complete"] else " — INCOMPLETE: some parameters were not received") + ".")
        saved = autopilot.set_brief(s)
    return {**result, "saved": saved}


@router.post("/link/params/write")
def link_write_params(data: dict = Body(...)):
    return LINK.write_params(data.get("changes"), data.get("confirm"))


# ---------------------------------------------------------------- simulation

@router.get("/simulation/meta")
def simulation_meta():
    return simulation.meta()


def _run_brief(r: SimulationRun) -> dict:
    return {"id": r.id, "scenario": r.scenario, "outcome": r.outcome, "created_at": r.created_at.isoformat(),
            "scene": r.result.get("scene"), "summary": r.result.get("summary"), "env": r.result.get("env")}


@router.post("/projects/{project_id}/simulation/run", status_code=201)
def run_simulation(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    p = psvc.get(db, project_id)
    result = simulation.run(psvc.config_of(p), data.get("scenario", "hover"), data.get("env"), data.get("scene", "field"))
    if not result["ok"]:
        return {"id": None, **result}
    run = SimulationRun(project_id=p.id, scenario=result["scenario"], outcome=result["outcome"], result=result)
    db.add(run)
    db.commit()
    old = list(db.scalars(select(SimulationRun).where(SimulationRun.project_id == p.id).order_by(SimulationRun.id.desc()).offset(KEEP_RUNS)))
    for r in old:
        db.delete(r)
    db.commit()
    return {"id": run.id, "created_at": run.created_at.isoformat(), **result}


@router.get("/projects/{project_id}/simulation/runs")
def list_runs(project_id: int, db: Session = Depends(get_session)):
    psvc.get(db, project_id)
    return [_run_brief(r) for r in db.scalars(select(SimulationRun).where(SimulationRun.project_id == project_id).order_by(SimulationRun.id.desc()))]


@router.get("/simulation/runs/{run_id}")
def get_run(run_id: int, db: Session = Depends(get_session)):
    r = db.get(SimulationRun, run_id)
    if r is None:
        raise NotFound(f"simulation run {run_id} not found")
    return {"id": r.id, "created_at": r.created_at.isoformat(), **r.result}


@router.delete("/simulation/runs/{run_id}", status_code=204)
def delete_run(run_id: int, db: Session = Depends(get_session)):
    r = db.get(SimulationRun, run_id)
    if r is None:
        raise NotFound(f"simulation run {run_id} not found")
    db.delete(r)
    db.commit()
