from __future__ import annotations

import json
import uuid
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, Form, Query, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..db import Component, Source, get_session
from ..services import components as svc

router = APIRouter(prefix="/api", tags=["components"])

MAX_UPLOAD = 25 * 1024 * 1024
ALLOWED_EXT = {".pdf", ".png", ".jpg", ".jpeg", ".csv", ".txt", ".xlsx", ".step", ".stp", ".stl", ".obj", ".glb"}


@router.get("/components")
def list_components(category: str | None = None, q: str | None = None, origin: str | None = None, db: Session = Depends(get_session)):
    return svc.search(db, category, q, origin)


@router.post("/components", status_code=201)
def create_component(data: dict = Body(...), db: Session = Depends(get_session)):
    return svc.detail_dict(db, svc.create(db, data))


@router.get("/components/compare")
def compare_components(ids: str = Query(...), db: Session = Depends(get_session)):
    try:
        id_list = [int(x) for x in ids.split(",") if x.strip()]
    except ValueError:
        raise svc.ValidationError(["ids must be a comma-separated list of component ids"])
    return svc.compare(db, id_list)


@router.get("/components/export")
def export_components(ids: str | None = None, db: Session = Depends(get_session)):
    stmt = select(Component).order_by(Component.category, Component.manufacturer, Component.model)
    if ids:
        stmt = stmt.where(Component.id.in_([int(x) for x in ids.split(",") if x.strip()]))
    payload = {"format": "quadlab.components/1", "units": "SI (see /api/meta)",
               "components": [svc.export_component(c) for c in db.scalars(stmt)]}
    return JSONResponse(payload, headers={"Content-Disposition": 'attachment; filename="quadlab-components.json"'})


@router.post("/components/import", status_code=201)
async def import_components(file: UploadFile = File(...), db: Session = Depends(get_session)):
    raw = await file.read(MAX_UPLOAD + 1)
    if len(raw) > MAX_UPLOAD:
        raise svc.ValidationError(["file is larger than 25 MB"])
    try:
        payload = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise svc.ValidationError([f"file is not valid JSON: {exc}"])
    created = svc.import_components(db, payload)
    return {"imported": len(created), "components": [svc.summary_dict(c) for c in created]}


@router.get("/components/{component_id}")
def get_component(component_id: int, db: Session = Depends(get_session)):
    return svc.detail_dict(db, svc.get(db, component_id))


@router.put("/components/{component_id}")
def update_component(component_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return svc.detail_dict(db, svc.update(db, component_id, data))


@router.delete("/components/{component_id}", status_code=204)
def delete_component(component_id: int, db: Session = Depends(get_session)):
    c = svc.get(db, component_id)
    paths = [s.file_path for s in c.sources if s.file_path]
    svc.delete(db, component_id)
    for p in paths:
        _remove_file_if_unreferenced(db, p)


@router.post("/components/{component_id}/duplicate", status_code=201)
def duplicate_component(component_id: int, data: dict = Body(default={}), db: Session = Depends(get_session)):
    return svc.detail_dict(db, svc.duplicate(db, component_id, data.get("variant")))


@router.get("/components/{component_id}/history")
def component_history(component_id: int, db: Session = Depends(get_session)):
    c = svc.get(db, component_id)
    return [{"id": h.id, "at": h.at.isoformat(), "summary": h.summary, "changes": h.changes} for h in c.history]


@router.post("/components/{component_id}/sources", status_code=201)
def add_source(component_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    data = {k: v for k, v in data.items() if k not in ("file_path", "file_name", "file_size")}
    return svc.source_dict(svc.add_source(db, component_id, data))


@router.post("/components/{component_id}/datasheets", status_code=201)
async def upload_datasheet(component_id: int, file: UploadFile = File(...), title: str = Form(""), kind: str = Form("datasheet"),
                           url: str = Form(""), note: str = Form(""), db: Session = Depends(get_session)):
    svc.get(db, component_id)
    name = Path(file.filename or "datasheet").name
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED_EXT:
        raise svc.ValidationError([f"file type '{ext or '(none)'}' is not accepted; allowed: {', '.join(sorted(ALLOWED_EXT))}"])
    raw = await file.read(MAX_UPLOAD + 1)
    if len(raw) > MAX_UPLOAD:
        raise svc.ValidationError(["file is larger than 25 MB"])
    if not raw:
        raise svc.ValidationError(["file is empty"])
    folder = config.datasheet_dir() / str(component_id)
    folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"{uuid.uuid4().hex}{ext}"
    stored.write_bytes(raw)
    try:
        s = svc.add_source(db, component_id, {"title": title.strip() or name, "kind": kind, "url": url, "note": note,
                                               "file_name": name, "file_path": str(stored), "file_size": len(raw)})
    except Exception:
        stored.unlink(missing_ok=True)
        raise
    return svc.source_dict(s)


@router.get("/sources/{source_id}/file")
def source_file(source_id: int, db: Session = Depends(get_session)):
    s = db.get(Source, source_id)
    if s is None or not s.file_path or not Path(s.file_path).is_file():
        raise svc.NotFound("no stored file for this source")
    return FileResponse(s.file_path, filename=s.file_name or Path(s.file_path).name)


@router.delete("/sources/{source_id}", status_code=204)
def delete_source(source_id: int, db: Session = Depends(get_session)):
    s = svc.delete_source(db, source_id)
    if s.file_path:
        _remove_file_if_unreferenced(db, s.file_path)


def _remove_file_if_unreferenced(db: Session, path: str) -> None:
    if db.scalar(select(Source.id).where(Source.file_path == path).limit(1)) is None:
        Path(path).unlink(missing_ok=True)


@router.post("/components/{component_id}/thrust-tests", status_code=201)
def add_thrust_test(component_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return svc.thrust_dict(svc.save_thrust_test(db, component_id, data))


@router.put("/components/{component_id}/thrust-tests/{test_id}")
def update_thrust_test(component_id: int, test_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return svc.thrust_dict(svc.save_thrust_test(db, component_id, data, test_id))


@router.delete("/components/{component_id}/thrust-tests/{test_id}", status_code=204)
def delete_thrust_test(component_id: int, test_id: int, db: Session = Depends(get_session)):
    svc.delete_thrust_test(db, component_id, test_id)
