"""Phase 5 routes: live telemetry (frames, recording, replay, export) and flight-test management."""
from __future__ import annotations

from fastapi import APIRouter, Body, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session

from ..db import get_session
from ..services import flight_test as ft
from ..services import projects as psvc
from ..services import telemetry
from ..services.link import LINK

router = APIRouter(prefix="/api", tags=["testing"])


# ---------------------------------------------------------------- live telemetry

@router.get("/telemetry/meta")
def telemetry_meta():
    return telemetry.field_meta()


@router.get("/telemetry/live")
def telemetry_live(since: float = 0.0):
    """Latest frame plus the history frames newer than `since` (epoch seconds)."""
    return {**LINK.frame(), "status": LINK.status(), "history": LINK.history_since(since) if since >= 0 else []}


@router.post("/projects/{project_id}/telemetry/record", status_code=201)
def record_start(project_id: int, data: dict = Body(default={}), db: Session = Depends(get_session)):
    psvc.get(db, project_id)
    card_id = data.get("card_id")
    if card_id is not None:
        ft.get_card(db, card_id)
    log = telemetry.start_recording(db, LINK, project_id, data.get("name", ""), card_id)
    if card_id is not None:
        ft.link_log(db, card_id, log.id)
    return telemetry.log_brief(log)


@router.post("/telemetry/record/stop")
def record_stop(db: Session = Depends(get_session)):
    log = telemetry.stop_recording(db, LINK)
    return telemetry.log_brief(log) if log else {"id": None}


@router.get("/projects/{project_id}/telemetry/logs")
def telemetry_logs(project_id: int, db: Session = Depends(get_session)):
    psvc.get(db, project_id)
    return telemetry.list_logs(db, project_id)


@router.get("/telemetry/logs/{log_id}")
def telemetry_log(log_id: int, db: Session = Depends(get_session)):
    r = telemetry.get_log(db, log_id)
    return {**telemetry.log_brief(r), "frames_data": telemetry.read_frames(r)}


@router.get("/telemetry/logs/{log_id}/export")
def telemetry_export(log_id: int, format: str = "csv", db: Session = Depends(get_session)):
    content, media, name = telemetry.export(telemetry.get_log(db, log_id), format)
    return Response(content, media_type=media, headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.delete("/telemetry/logs/{log_id}", status_code=204)
def telemetry_delete(log_id: int, db: Session = Depends(get_session)):
    telemetry.delete_log(db, LINK, log_id)


# ---------------------------------------------------------------- flight testing

@router.get("/testing/meta")
def testing_meta():
    return ft.meta()


@router.get("/projects/{project_id}/campaigns")
def campaigns(project_id: int, db: Session = Depends(get_session)):
    psvc.get(db, project_id)
    return ft.list_campaigns(db, project_id)


@router.post("/projects/{project_id}/campaigns", status_code=201)
def create_campaign(project_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.campaign_detail(db, ft.create_campaign(db, project_id, data))


@router.get("/campaigns/{campaign_id}")
def campaign(campaign_id: int, db: Session = Depends(get_session)):
    return ft.campaign_detail(db, ft.get_campaign(db, campaign_id))


@router.delete("/campaigns/{campaign_id}", status_code=204)
def delete_campaign(campaign_id: int, db: Session = Depends(get_session)):
    ft.delete_campaign(db, campaign_id)


@router.post("/campaigns/{campaign_id}/waivers")
def waive(campaign_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.campaign_detail(db, ft.waive_stage(db, campaign_id, data))


@router.post("/campaigns/{campaign_id}/cards", status_code=201)
def create_card(campaign_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.card_detail(ft.create_card(db, campaign_id, data))


@router.get("/cards/{card_id}")
def card(card_id: int, db: Session = Depends(get_session)):
    return ft.card_detail(ft.get_card(db, card_id))


@router.put("/cards/{card_id}")
def update_card(card_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.card_detail(ft.update_card(db, card_id, data))


@router.delete("/cards/{card_id}", status_code=204)
def delete_card(card_id: int, db: Session = Depends(get_session)):
    ft.delete_card(db, card_id)


@router.post("/cards/{card_id}/authorise")
def authorise(card_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.card_detail(ft.authorise(db, card_id, data, LINK.status()))


@router.post("/cards/{card_id}/start")
def start(card_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.card_detail(ft.start(db, card_id, data))


@router.post("/cards/{card_id}/complete")
def complete(card_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.card_detail(ft.complete(db, card_id, data))


@router.post("/cards/{card_id}/reopen")
def reopen(card_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.card_detail(ft.reopen(db, card_id, data))


@router.put("/cards/{card_id}/telemetry-log")
def link_log(card_id: int, data: dict = Body(...), db: Session = Depends(get_session)):
    return ft.card_detail(ft.link_log(db, card_id, data.get("log_id")))
