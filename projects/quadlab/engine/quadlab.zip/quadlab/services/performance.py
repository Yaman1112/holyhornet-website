"""Flight performance calculator.

Everything here is an *estimate* built on bench data, and every number says how it
was obtained:

  data          taken directly from a recorded specification or bench-test point
  interpolated  linear interpolation between two bench-test points
  extrapolated  scaled beyond the tested range with a stated physical law
  calculated    arithmetic on recorded values (mass sums, energy = capacity x voltage)
  model         first-order physical model with stated assumptions
  input         an analysis parameter chosen by the user

Nothing is calculated from a thrust curve the motor was not tested with: if there is
no bench test of the selected motor with the selected propeller size, the propulsion
results are reported as blocked, not approximated from a different propeller.

Equations (SI units throughout)
-------------------------------
Hover thrust per motor        T = m g0 / n
Bench look-up at density rho  T_b = T rho0/rho ;  P = P_b(T_b) rho/rho0        (same rpm, C_T and C_P constant)
Below the lowest test point   P_b = P_1 (T_b/T_1)^1.5 ;  omega = omega_1 (T_b/T_1)^0.5   (momentum theory, constant efficiency)
Battery energy                E = Q V_nom ;  usable E_u = f E
Battery current               I = (V - sqrt(V^2 - 4 R P)) / (2 R)   with pack resistance R, else I = P / V
Endurance                     t = E_u / (P + I^2 R)
Disk loading                  DL = m g0 / (n pi D^2 / 4)
Ideal induced power           P_i = n T^1.5 / sqrt(2 rho A)
Forward flight (optional)     D = 0.5 rho CdA v^2 ;  T_total = sqrt((m g0)^2 + D^2) ;  range = v t
Motor model                   E_b = omega / Kv ;  R I_m^2 + E_b I_m - P_in = 0 ;  P_shaft = E_b (I_m - I_0) ;  Q = P_shaft / omega
Propeller coefficients        C_T = T / (rho n^2 D^4) ;  C_P = P_shaft / (rho n^3 D^5)   (n in rev/s)
"""
from __future__ import annotations

import math

from .components import ValidationError
from .context import Config, Part, matching_test

G0 = 9.80665
RHO0 = 1.225            # kg/m^3, ISA sea level; bench data are assumed to have been taken at this density

PARAMS = {
    # key: (default, min, max, label, unit, help)
    "usable_fraction": (0.80, 0.10, 1.00, "Usable battery fraction", "", "Share of rated capacity drawn before landing. 0.8 is common LiPo practice; it is a choice, not a specification."),
    "air_density": (RHO0, 0.50, 1.50, "Air density", "kg/m³", "1.225 is ISA sea level. Lower density (altitude, heat) needs more power for the same thrust."),
    "payload_mass": (0.0, 0.0, 100.0, "What-if payload mass", "kg", "Extra mass added to the recorded total for this analysis only."),
    "extra_power": (0.0, 0.0, 5000.0, "Additional electrical load", "W", "Loads with no recorded consumption (flight controller, companion computer, payload, lights)."),
    "target_tw": (2.0, 1.1, 10.0, "Minimum thrust-to-weight for MTOW", "", "Design margin used to derive a thrust-limited maximum take-off weight."),
    "cruise_speed": (None, 0.5, 60.0, "Cruise airspeed", "m/s", "Needed for the range estimate."),
    "drag_area": (None, 0.001, 2.0, "Drag area CdA", "m²", "Airframe drag area. Not derivable from component data: measure or estimate it, then enter it here."),
}


def clean_params(raw: dict | None, strict: bool = False) -> dict:
    out, errors = {}, []
    for key, (default, lo, hi, label, unit, _) in PARAMS.items():
        v = (raw or {}).get(key, default)
        if v in (None, ""):
            out[key] = None if default is None else default
            continue
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not lo <= v <= hi:
            errors.append(f"{label} must be a number between {lo:g} and {hi:g} {unit}".strip())
            out[key] = default
            continue
        out[key] = float(v)
    for key in (raw or {}):
        if key not in PARAMS:
            errors.append(f"unknown parameter '{key}'")
    if errors and strict:
        raise ValidationError(errors)
    return out


def param_meta() -> list[dict]:
    return [{"key": k, "default": d, "min": lo, "max": hi, "label": label, "unit": unit, "help": help_}
            for k, (d, lo, hi, label, unit, help_) in PARAMS.items()]


# ------------------------------------------------------------------ propulsion model

class PropulsionModel:
    """Thrust / power relationship of one motor + propeller, from one bench test."""

    def __init__(self, test: dict):
        self.test = test
        v_test = test["voltage"]
        pts = []
        for p in test["points"]:
            power = p.get("power")
            if power is None and p.get("current") is not None:
                power = p["current"] * (p.get("voltage") or v_test)
            if power is not None and p.get("thrust"):
                pts.append({**p, "power": power})
        self.points = sorted(pts, key=lambda p: p["thrust"])
        self.ok = len(self.points) >= 2
        self.t_min = self.points[0]["thrust"] if self.points else None
        self.t_max = self.points[-1]["thrust"] if self.points else None

    def bench(self, thrust: float) -> dict | None:
        """Operating point at `thrust` (N) under bench conditions."""
        pts = self.points
        if thrust <= 0 or thrust > self.t_max * (1 + 1e-9):
            return None
        if thrust < self.t_min:
            p1 = pts[0]
            k = thrust / p1["thrust"]
            out = {"thrust": thrust, "power": p1["power"] * k ** 1.5, "basis": "extrapolated"}
            if p1.get("speed") is not None:
                out["speed"] = p1["speed"] * math.sqrt(k)
                fit = self._throttle_vs_speed()
                if fit:
                    out["throttle"] = max(0.0, fit[0] + fit[1] * out["speed"])
            return out
        for a, b in zip(pts, pts[1:]):
            if a["thrust"] <= thrust <= b["thrust"] * (1 + 1e-9):
                f = (thrust - a["thrust"]) / (b["thrust"] - a["thrust"]) if b["thrust"] > a["thrust"] else 0.0
                out = {"thrust": thrust, "basis": "data" if f in (0.0, 1.0) or abs(f - 1) < 1e-9 else "interpolated"}
                for key in ("power", "throttle", "speed", "torque"):
                    if a.get(key) is not None and b.get(key) is not None:
                        out[key] = a[key] + f * (b[key] - a[key])
                return out
        return None

    def _throttle_vs_speed(self) -> tuple[float, float] | None:
        """Least-squares line throttle = a + b*speed through the bench points."""
        xy = [(p["speed"], p["throttle"]) for p in self.points if p.get("speed") is not None and p.get("throttle") is not None]
        if len(xy) < 2:
            return None
        n = len(xy)
        mx, my = sum(x for x, _ in xy) / n, sum(y for _, y in xy) / n
        sxx = sum((x - mx) ** 2 for x, _ in xy)
        if sxx == 0:
            return None
        b = sum((x - mx) * (y - my) for x, y in xy) / sxx
        return my - b * mx, b

    def at(self, thrust: float, rho: float) -> dict | None:
        """Operating point delivering `thrust` at air density `rho`."""
        b = self.bench(thrust * RHO0 / rho)
        if b is None:
            return None
        return {**b, "thrust": thrust, "power": b["power"] * rho / RHO0}

    def max_thrust(self, rho: float) -> float:
        return self.t_max * rho / RHO0


def battery_draw(power: float, voltage: float, resistance: float | None) -> tuple[float, float]:
    """(current, internal loss) for a terminal power demand."""
    if not resistance:
        return power / voltage, 0.0
    disc = voltage * voltage - 4 * resistance * power
    if disc < 0:
        return float("nan"), float("nan")
    i = (voltage - math.sqrt(disc)) / (2 * resistance)
    return i, i * i * resistance


def motor_model(motor: Part, test: dict) -> dict:
    """First-order DC motor model evaluated at each bench point."""
    kv, r, i0 = motor.num("kv"), motor.num("internal_resistance"), motor.num("idle_current")
    missing = [motor.label(k) for k, v in (("kv", kv), ("internal_resistance", r), ("idle_current", i0)) if v is None]
    if missing:
        return {"available": False, "missing": missing, "rows": []}
    kv_rad = kv * 2 * math.pi / 60          # rad/s per volt
    rows = []
    for p in test["points"]:
        power = p.get("power") if p.get("power") is not None else (p["current"] * (p.get("voltage") or test["voltage"]) if p.get("current") is not None else None)
        if power is None or p.get("speed") is None:
            continue
        e = p["speed"] / kv_rad
        im = (-e + math.sqrt(e * e + 4 * r * power)) / (2 * r)
        shaft = max(0.0, e * (im - i0))
        row = {"throttle": p.get("throttle"), "speed": p["speed"], "input_power": power, "back_emf": e, "motor_current": im,
               "copper_loss": im * im * r, "iron_loss": e * i0, "shaft_power": shaft, "torque": shaft / p["speed"], "efficiency": shaft / power}
        if p.get("torque") is not None:
            row["measured_torque"] = p["torque"]
            row["measured_efficiency"] = p["torque"] * p["speed"] / power
        rows.append(row)
    return {
        "available": True, "rows": rows,
        "inputs": [motor.cite("kv"), motor.cite("internal_resistance"), motor.cite("idle_current")],
        "assumptions": ["ESC losses are not separated: all input power is treated as reaching the motor, so shaft power and "
                        "efficiency are upper estimates.",
                        "No-load current is taken as constant; it actually rises with speed.",
                        "Winding resistance is the recorded (cold) value; it rises with temperature."],
    }


def prop_coefficients(model: PropulsionModel, diameter: float) -> dict | None:
    cts, cps = [], []
    for p in model.points:
        if not p.get("speed"):
            continue
        n = p["speed"] / (2 * math.pi)
        cts.append(p["thrust"] / (RHO0 * n * n * diameter ** 4))
        if p.get("torque") is not None:
            cps.append(p["torque"] * p["speed"] / (RHO0 * n ** 3 * diameter ** 5))
    if not cts:
        return None
    out = {"ct_mean": sum(cts) / len(cts), "ct_min": min(cts), "ct_max": max(cts), "points": len(cts)}
    if cps:
        out.update(cp_mean=sum(cps) / len(cps), cp_min=min(cps), cp_max=max(cps))
    return out


# ------------------------------------------------------------------ evaluation

def row(key, label, value, quantity=None, unit=None, kind="calculated", note=None):
    return {"key": key, "label": label, "value": value, "quantity": quantity, "unit": unit, "kind": kind, "note": note}


RAIL_CATS = ["gps", "telemetry", "receiver", "rangefinder", "optical_flow", "imu", "barometer", "magnetometer", "companion", "camera", "payload"]


def avionics_power(cfg: Config) -> tuple[float, list[str], list[str]]:
    """Sum of recorded peripheral consumption; names of items counted and not on record."""
    pm = cfg.one("power")
    rail = pm.num("output_voltage") if pm else None
    total, counted, unknown = 0.0, [], []
    for cat in RAIL_CATS:
        for p in cfg.all(cat):
            w = p.num("power_consumption")
            if w is None:
                amps = p.num("supply_current") or p.num("supply_current_peak")
                volts = rail if rail is not None else p.num("supply_voltage_max")
                w = amps * volts if amps is not None and volts is not None else None
            if w is None:
                unknown.append(p.name)
            else:
                total += w * p.quantity
                counted.append(f"{p.name} {w:.2f} W")
    fc = cfg.one("flight_controller")
    if fc:
        unknown.append(fc.name)
    return total, counted, unknown


def evaluate(cfg: Config, mass: dict, raw_params: dict | None = None) -> dict:
    """`mass` is the roll-up from projects.summarise()['mass']."""
    prm = clean_params(raw_params)
    rho, n = prm["air_density"], cfg.rotor_count
    motor, prop, batt, esc, pm, frame = (cfg.one(c) for c in ("motor", "propeller", "battery", "esc", "power", "frame"))
    blockers: list[str] = []
    warnings: list[str] = []
    sections: list[dict] = []
    metrics: dict[str, float | None] = {}

    # ---------------- mass
    m_rec = mass["known_total"]
    m = m_rec + prm["payload_mass"]
    lower = mass["is_lower_bound"]
    if lower:
        warnings.append(f"{mass['items_total'] - mass['items_with_mass']} line item(s) have no recorded weight, so the mass is a lower bound "
                        "and every result that depends on it (hover, endurance, payload) is optimistic.")
    non_empty = sum((p.num("weight") or 0.0) * p.quantity for p in cfg.parts if p.category in ("battery", "payload"))
    mass_rows = [
        row("mass", "Total aircraft mass", m, "mass", kind="calculated",
            note=("Recorded component weights" + (f" + {prm['payload_mass']:g} kg what-if payload" if prm["payload_mass"] else "")
                  + ("; lower bound" if lower else "") + ". Wiring and fasteners not included.")),
        row("empty_mass", "Empty weight", m_rec - non_empty, "mass", note="Recorded mass without battery and payload items."),
    ]
    if mass.get("uncertainty"):
        mass_rows.append(row("mass_tol", "Mass tolerance (stated)", mass["uncertainty"], "mass", note="Worst-case sum of stated component tolerances."))
    metrics.update(mass=m, empty_mass=m_rec - non_empty)

    # ---------------- propulsion model
    model, test = None, None
    if motor is None or prop is None:
        blockers.append("Select a motor and a propeller to calculate thrust, hover and endurance.")
    else:
        test = matching_test(motor, prop)
        if test is None:
            blockers.append(f"No bench thrust test of {motor.name} with a propeller the size of {prop.name} is on record. "
                            "Thrust, hover throttle, current and endurance are not calculated from a different propeller's data — "
                            "add a test for this pairing in the component library.")
        else:
            model = PropulsionModel(test)
            if not model.ok:
                blockers.append(f"The bench test “{test['propeller']} @ {test['voltage']:g} V” needs at least two points with thrust and power (or current).")
                model = None

    v_nom = batt.num("nominal_voltage") if batt else None
    cap = batt.num("capacity") if batt else None
    r_pack = batt.num("internal_resistance") if batt else None
    if batt is None:
        blockers.append("Select a battery to calculate current, energy and endurance.")
    elif v_nom is None or cap is None:
        blockers.append(f"{batt.name}: nominal voltage and capacity are needed for the energy calculation.")

    av_w, av_counted, av_unknown = avionics_power(cfg)
    p_aux = av_w + prm["extra_power"]
    hover, full = None, None
    assumptions = [
        "Bench thrust data are static (no airflow through the rotor) and assumed taken at 1.225 kg/m³.",
        "Rotor-to-rotor and rotor-to-airframe interference is not modelled; installed thrust is typically a few percent lower.",
        "Electrical power for a given thrust is taken as independent of battery voltage (the ESC adjusts duty cycle); "
        "current is that power divided by pack voltage.",
        "Endurance assumes constant power at nominal pack voltage until the usable fraction is consumed, in still air.",
    ]

    if model:
        if test["provenance"] != "measured":
            warnings.append(f"Propulsion data: {test['provenance']} bench test “{test['propeller']} @ {test['voltage']:g} V”. "
                            "Verify with your own thrust-stand measurement before relying on these figures.")
        if v_nom and abs(v_nom - test["voltage"]) / test["voltage"] > 0.05:
            warnings.append(f"The bench test was run at {test['voltage']:g} V; the pack is {v_nom:g} V nominal. Maximum thrust changes roughly "
                            "with voltage squared — this is not applied, so maximum thrust and T/W are stated at the test voltage.")
        t_max = model.max_thrust(rho)
        t_avail = n * t_max
        tw = t_avail / (m * G0) if m > 0 else None
        full = model.at(t_max, rho)
        t_hover = m * G0 / n
        hover = model.at(t_hover, rho) if m > 0 else None
        thrust_rows = [
            row("thrust_available", "Total available thrust", t_avail, "force", kind="data",
                note=f"{n} × full-throttle bench thrust at {test['voltage']:g} V" + (f", scaled by ρ/ρ₀ = {rho / RHO0:.3f}" if rho != RHO0 else "") + "."),
            row("tw", "Thrust-to-weight ratio", tw, unit=":1", note="Static, at the bench-test voltage."),
            row("hover_thrust", "Hover thrust per motor", t_hover, "force", note="T = m·g₀ / n"),
        ]
        metrics.update(thrust=t_avail, tw=tw)
        if hover is None:
            blockers.append(f"Hover needs {t_hover / G0 * 1000:.0f} gf per motor but the bench test tops out at {t_max / G0 * 1000:.0f} gf: "
                            "the aircraft cannot hover at this mass.")
        else:
            kind = hover["basis"]
            ex_note = (" Below the lowest bench point: scaled with P ∝ T^1.5 from that point." if kind == "extrapolated" else "")
            if kind == "extrapolated":
                warnings.append(f"Hover thrust ({t_hover / G0 * 1000:.0f} gf per motor) is below the lowest bench point "
                                f"({model.t_min / G0 * 1000:.0f} gf). Hover power and throttle are extrapolated with momentum-theory scaling; "
                                "a bench point near hover thrust would remove this assumption.")
            thrust_rows.append(row("hover_throttle", "Estimated hover throttle", hover["throttle"] * 100 if hover.get("throttle") is not None else None,
                                   unit="%", kind=kind, note="Throttle of the bench ESC at hover thrust; autopilot throttle scaling differs." + ex_note))
            metrics["hover_throttle"] = hover.get("throttle")
        sections.append({"title": "Thrust", "rows": thrust_rows})

        # ---------------- power and current
        if hover and v_nom:
            p_prop = n * hover["power"]
            p_hover = p_prop + p_aux
            i_hover, loss = battery_draw(p_hover, v_nom, r_pack)
            p_full = n * full["power"] + p_aux
            i_full, _ = battery_draw(p_full, v_nom, r_pack)
            power_rows = [
                row("motor_power_hover", "Motor electrical power at hover", hover["power"], "power", kind=hover["basis"], note="Per motor, including ESC losses as measured on the bench."),
                row("motor_current_hover", "Motor operating current at hover", hover["power"] / v_nom, "current", kind=hover["basis"], note=f"Per ESC input, at {v_nom:g} V nominal."),
                row("aux_power", "Avionics and other loads", p_aux, "power", kind="calculated" if not prm["extra_power"] else "input",
                    note=("Recorded: " + (", ".join(av_counted) or "none") + (f"; plus {prm['extra_power']:g} W entered" if prm["extra_power"] else "")
                          + (f". Not on record (not included): {', '.join(av_unknown)}." if av_unknown else "."))),
                row("hover_power", "Total power consumption at hover", p_hover, "power", kind=hover["basis"]),
                row("hover_current", "Battery current at hover", i_hover, "current", kind=hover["basis"]),
                row("full_power", "Total power at full throttle", p_full, "power", kind="data"),
                row("full_current", "Battery current at full throttle", i_full, "current", kind="data"),
                row("efficiency", "Hover power efficiency", m * 1000 / p_hover, unit="g/W", kind=hover["basis"], note="Aircraft mass ÷ total electrical power."),
            ]
            metrics.update(hover_power=p_hover, hover_current=i_hover, full_current=i_full, efficiency=m * 1000 / p_hover)
            sections.append({"title": "Power and current", "rows": power_rows})

            # ---------------- battery and endurance
            if cap:
                f = prm["usable_fraction"]
                energy = cap * v_nom
                t_end = energy * f / (p_hover + loss)
                batt_rows = [
                    row("energy", "Battery energy", energy / 3600, unit="Wh", note="E = capacity × nominal voltage."),
                    row("usable_energy", "Usable energy", energy * f / 3600, unit="Wh", kind="input", note=f"{f * 100:.0f}% of rated capacity (analysis parameter)."),
                    row("c_rate_hover", "Discharge rate at hover", i_hover / (cap / 3600), unit="C"),
                    row("endurance", "Estimated hover endurance", t_end, "time", kind=hover["basis"],
                        note="t = usable energy ÷ hover power" + (" (including I²R loss in the pack)." if r_pack else ". Pack internal resistance is not on record, so voltage sag and pack heating are not modelled.")),
                ]
                metrics.update(energy=energy, endurance=t_end, capacity=cap)
                if mass.get("uncertainty") and m > 0:
                    rel = 1.5 * mass["uncertainty"] / m
                    batt_rows.append(row("endurance_tol", "Endurance sensitivity to stated mass tolerance", rel * 100, unit="± %",
                                         note="δt/t ≈ 1.5 δm/m (power ∝ m^1.5). Covers stated weight tolerances only — not bench-data or model error."))
                if not r_pack:
                    warnings.append("Battery internal resistance is not on record: endurance ignores voltage sag and is optimistic at high current.")
                # range
                v, cda = prm["cruise_speed"], prm["drag_area"]
                if v and cda:
                    drag = 0.5 * rho * cda * v * v
                    t_total = math.hypot(m * G0, drag)
                    cruise = model.at(t_total / n, rho)
                    if cruise is None:
                        batt_rows.append(row("range", "Estimated range", None, "length", kind="model",
                                             note=f"At {v:g} m/s the required thrust ({t_total / G0:.2f} kgf) exceeds what the bench data cover."))
                    else:
                        p_cr = n * cruise["power"] + p_aux
                        i_cr, loss_cr = battery_draw(p_cr, v_nom, r_pack)
                        t_cr = energy * f / (p_cr + loss_cr)
                        batt_rows += [
                            row("cruise_power", f"Power at {v:g} m/s", p_cr, "power", kind="model",
                                note=f"Drag {drag:.2f} N from CdA = {cda:g} m²; tilt {math.degrees(math.atan2(drag, m * G0)):.1f}°. Uses the static thrust-power curve: "
                                     "the reduction of induced power in forward flight is not modelled, so this is conservative at moderate speed."),
                            row("cruise_endurance", f"Endurance at {v:g} m/s", t_cr, "time", kind="model"),
                            row("range", "Estimated range", v * t_cr, "length_km", kind="model", note="Still air, no climb, no reserve beyond the usable fraction."),
                        ]
                        metrics["range"] = v * t_cr
                else:
                    batt_rows.append(row("range", "Estimated range", None, "length_km", kind="model",
                                         note="Needs a cruise airspeed and the airframe drag area (CdA). Drag area cannot be derived from component data — enter both under Analysis parameters."))
                sections.append({"title": "Battery and endurance", "rows": batt_rows})

        # ---------------- weight limits
        mtow_thrust = t_avail / (G0 * prm["target_tw"])
        mtow_frame = frame.num("max_takeoff_weight") if frame else None
        mtow = min(x for x in (mtow_thrust, mtow_frame) if x is not None)
        limit_rows = [row("mtow_thrust", f"Thrust-limited MTOW (T/W ≥ {prm['target_tw']:g})", mtow_thrust, "mass", kind="input",
                          note="Mass at which static thrust-to-weight falls to the chosen margin.")]
        limit_rows.append(row("mtow_frame", "Frame maximum take-off weight", mtow_frame, "mass", kind="data",
                              note=None if mtow_frame is not None else "Not on record for the selected frame — only the thrust limit applies."))
        limit_rows.append(row("mtow", "Maximum take-off weight (governing)", mtow, "mass",
                              note="Lower of the limits above." if mtow_frame is not None else "Thrust-limited; no structural limit on record."))
        limit_rows.append(row("payload_capacity", "Payload capacity", mtow - m, "mass",
                              note="Governing MTOW − current mass." + (" Negative: the aircraft is already above the limit." if mtow < m else "")))
        metrics.update(mtow=mtow, payload_capacity=mtow - m)
        sections.insert(1, {"title": "Weight limits", "rows": limit_rows})

        # ---------------- rotor and loading
        d = prop.num("diameter")
        load_rows = []
        if d:
            area = math.pi * d * d / 4
            dl = m * G0 / (n * area)
            load_rows.append(row("disk_loading", "Propeller disk loading", dl, unit="N/m²", note=f"= {dl / G0:.2f} kg/m². DL = m·g₀ / (n·π·D²/4)."))
            metrics["disk_loading"] = dl
            if hover:
                p_ideal = n * (m * G0 / n) ** 1.5 / math.sqrt(2 * rho * area)
                load_rows.append(row("ideal_power", "Ideal induced hover power", p_ideal, "power", kind="model", note="Momentum theory: P = n·T^1.5 / √(2ρA)."))
                load_rows.append(row("hover_fom", "Overall hover efficiency", p_ideal / (n * hover["power"]) * 100, unit="%", kind=hover["basis"],
                                     note="Ideal induced power ÷ electrical propulsion power (propeller, motor and ESC losses combined)."))
        i_max_motor, p_max_motor = motor.num("max_current"), motor.num("max_power")
        if hover and v_nom:
            ih, i_f = hover["power"] / v_nom, full["power"] / v_nom
            if i_max_motor:
                load_rows.append(row("motor_load_hover", "Motor loading at hover", ih / i_max_motor * 100, unit="%", kind=hover["basis"], note=f"Hover current ÷ {i_max_motor:g} A maximum rating."))
                load_rows.append(row("motor_load_full", "Motor loading at full throttle", i_f / i_max_motor * 100, unit="%", kind="data", note="Full-throttle current ÷ maximum rating."))
                metrics["motor_load_full"] = i_f / i_max_motor
            if p_max_motor:
                load_rows.append(row("motor_power_full", "Motor power at full throttle", full["power"] / p_max_motor * 100, unit="%", kind="data", note=f"÷ {p_max_motor:g} W maximum rating."))
        if load_rows:
            sections.append({"title": "Rotor and motor loading", "rows": load_rows})

        # ---------------- electrical margins
        if v_nom:
            i_f = full["power"] / v_nom
            margin_rows = []
            for part, key, label, demand in ((esc, "continuous_current", "ESC continuous rating", i_f),
                                             (batt, "max_discharge_current", "Battery continuous discharge", n * i_f + p_aux / v_nom),
                                             (pm, "continuous_current", "Power module continuous rating", n * i_f)):
                if part is None:
                    continue
                rating = part.num(key)
                margin_rows.append(row(f"margin_{part.category}", f"{label} margin at full throttle",
                                       (rating / demand - 1) * 100 if rating else None, unit="%", kind="data" if rating else "calculated",
                                       note=(f"{rating:g} A rating against {demand:.3g} A." + (" Negative: rating exceeded." if rating < demand else ""))
                                       if rating else f"{part.name}: “{part.label(key)}” is not on record."))
            if margin_rows:
                sections.append({"title": "Electrical system margins", "rows": margin_rows})

    sections.insert(0, {"title": "Mass", "rows": mass_rows})

    # ---------------- chart data
    charts: dict = {}
    if model and v_nom:
        charts["throttle_sweep"] = [
            {"throttle": p["throttle"], "thrust": n * p["thrust"] * rho / RHO0, "power": n * p["power"] * rho / RHO0 + p_aux,
             "current": (n * p["power"] * rho / RHO0 + p_aux) / v_nom}
            for p in model.points if p.get("throttle") is not None]
        if hover and hover.get("throttle") is not None:
            charts["hover_point"] = {"throttle": hover["throttle"], "thrust": m * G0, "power": metrics.get("hover_power"), "basis": hover["basis"]}
        if cap and metrics.get("mtow"):
            series = []
            top = max(0.0, model.max_thrust(rho) * n / (G0 * 1.15) - m_rec)        # stop at T/W = 1.15
            for k in range(13):
                pay = top * k / 12
                mk = m_rec + pay
                op = model.at(mk * G0 / n, rho)
                if op is None:
                    break
                pk = n * op["power"] + p_aux
                _, lk = battery_draw(pk, v_nom, r_pack)
                series.append({"payload": pay, "mass": mk, "endurance": cap * v_nom * prm["usable_fraction"] / (pk + lk),
                               "tw": n * model.max_thrust(rho) / (mk * G0), "throttle": op.get("throttle"), "basis": op["basis"]})
            charts["payload_curve"] = series

    return {
        "available": not blockers, "blockers": blockers, "warnings": warnings, "sections": sections, "metrics": metrics,
        "params": prm, "param_meta": param_meta(), "charts": charts, "assumptions": assumptions,
        "propulsion_source": ({"motor": motor.name, "propeller": prop.name, "test": f"{test['propeller']} @ {test['voltage']:g} V",
                               "provenance": test["provenance"], "points": len(model.points), "note": test.get("note")} if model else None),
        "motor_model": motor_model(motor, test) if model else None,
        "prop_coefficients": prop_coefficients(model, prop.num("diameter")) if model and prop.num("diameter") else None,
        "kinds": {"data": "Bench or specification data", "interpolated": "Interpolated between bench points",
                  "extrapolated": "Extrapolated beyond bench data", "calculated": "Calculated from recorded values",
                  "model": "First-order model", "input": "Depends on an analysis parameter"},
    }
