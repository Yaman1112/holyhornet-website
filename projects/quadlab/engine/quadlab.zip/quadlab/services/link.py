"""MAVLink connection to a flight controller or a SITL instance.

Scope in this phase: monitor the vehicle, read its parameters, and write parameters
the user has explicitly confirmed. This module never sends arm, takeoff, mode-change
or actuator commands.

Safety rules enforced here (not in the UI):
  * parameters are written only with confirm=True and an explicit list of changes
  * every name must exist in the vehicle's own parameter list
  * the value on the vehicle must still equal the value the user was shown (expected_old)
  * nothing is written while the vehicle reports it is armed
  * every write is read back and reported per parameter
"""
from __future__ import annotations

import collections
import logging
import math
import struct
import threading
import time

from .components import Conflict, ValidationError

log = logging.getLogger("quadlab.link")

AUTOPILOT_NAMES = {3: "ardupilot", 12: "px4"}
VEHICLE_TYPES = {1: "Fixed wing", 2: "Quadrotor", 13: "Hexarotor", 14: "Octorotor", 4: "Helicopter", 10: "Ground rover", 20: "VTOL"}
PX4_MAIN_MODES = {1: "Manual", 2: "Altitude", 3: "Position", 4: "Auto", 5: "Acro", 6: "Offboard", 7: "Stabilized", 8: "Rattitude"}
PX4_AUTO_SUB = {1: "Ready", 2: "Takeoff", 3: "Hold", 4: "Mission", 5: "Return", 6: "Land", 8: "Follow"}
COPTER_MODES = {0: "Stabilize", 1: "Acro", 2: "AltHold", 3: "Auto", 4: "Guided", 5: "Loiter", 6: "RTL", 7: "Circle", 9: "Land",
                11: "Drift", 13: "Sport", 15: "AutoTune", 16: "PosHold", 17: "Brake", 21: "Smart_RTL"}
MAV_MODE_FLAG_SAFETY_ARMED = 128
INT_TYPES = {1, 2, 3, 4, 5, 6, 7, 8}      # MAV_PARAM_TYPE integer kinds


def connection_string(spec: dict) -> tuple[str, dict]:
    """Validate a connection request and build the pymavlink device string."""
    kind = spec.get("kind")
    errors = []
    kwargs: dict = {}
    host = str(spec.get("host") or "").strip()
    port = spec.get("port")
    if kind in ("udp_listen", "udp_out", "tcp"):
        if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
            errors.append("port must be between 1 and 65535")
        if kind != "udp_listen" and not host:
            errors.append("host is required")
        if host and not all(c.isalnum() or c in ".-:" for c in host):
            errors.append("host contains invalid characters")
        dev = {"udp_listen": f"udpin:{host or '0.0.0.0'}:{port}", "udp_out": f"udpout:{host}:{port}", "tcp": f"tcp:{host}:{port}"}[kind]
    elif kind == "serial":
        dev = str(spec.get("device") or "").strip()
        baud = spec.get("baud", 57600)
        if not dev:
            errors.append("serial device is required (for example COM5)")
        if isinstance(baud, bool) or not isinstance(baud, int) or not 1200 <= baud <= 3_000_000:
            errors.append("baud rate must be between 1200 and 3000000")
        kwargs["baud"] = baud
    else:
        errors.append("kind must be udp_listen, udp_out, tcp or serial")
        dev = ""
    if errors:
        raise ValidationError(errors)
    return dev, kwargs


def decode_param(msg) -> float:
    """PARAM_VALUE carries integers either as a float (ArduPilot) or as raw bytes in the
    float field (PX4, 'bytewise' encoding)."""
    return float(msg.param_value)


def px4_int(value: float) -> int:
    return struct.unpack("<i", struct.pack("<f", value))[0]


def px4_float(value: int) -> float:
    return struct.unpack("<f", struct.pack("<i", int(value)))[0]


class Link:
    def __init__(self):
        self._lock = threading.RLock()
        self._conn = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._reset()

    def _reset(self):
        self.spec: dict | None = None
        self.device = None
        self.error: str | None = None
        self.connected_at: float | None = None
        self.heartbeat: dict | None = None
        self.last_heartbeat: float | None = None
        self.params: dict[str, dict] = {}
        self.param_count: int | None = None
        self.params_complete = False
        self.tm: dict = {}
        self.texts: list[dict] = []
        self.sim_evidence: set[str] = set()
        self.msg_counts: dict[str, int] = {}
        self.target = (1, 1)
        self.history: collections.deque = collections.deque(maxlen=3000)
        self.recorder = None

    # ------------------------------------------------------------ lifecycle
    def connect(self, spec: dict) -> dict:
        from .. import config
        if config.browser():
            raise Conflict("A vehicle link needs a UDP or TCP socket or a serial port, which a web page cannot open. "
                           "Use the QuadLab Pro desktop application to connect to a flight controller or simulator.")
        from pymavlink import mavutil
        dev, kwargs = connection_string(spec)
        self.disconnect()
        with self._lock:
            self._reset()
            self.spec, self.device = spec, dev
            try:
                self._conn = mavutil.mavlink_connection(dev, source_system=255, source_component=190, autoreconnect=False, **kwargs)
            except Exception as exc:                       # pymavlink raises many types (OSError, SerialException…)
                self._conn = None
                self.error = f"could not open {dev}: {exc}"
                log.warning(self.error)
                raise Conflict(self.error)
            self.connected_at = time.time()
            self._stop.clear()
            self._thread = threading.Thread(target=self._run, name="mavlink-reader", daemon=True)
            self._thread.start()
        log.info("link opened: %s", dev)
        return self.status()

    def disconnect(self) -> None:
        self._stop.set()
        t = self._thread
        if t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=2.0)
        with self._lock:
            if self.recorder is not None:
                self.recorder.close()
            if self._conn is not None:
                try:
                    self._conn.close()
                except Exception:
                    pass
                log.info("link closed: %s", self.device)
            self._conn = None
            self._thread = None
            self._reset()

    # ------------------------------------------------------------ reader thread
    def _run(self):
        from pymavlink import mavutil
        conn = self._conn
        from . import telemetry
        last_hb = 0.0
        last_frame = 0.0
        requested = False
        while not self._stop.is_set():
            now = time.time()
            if now >= last_frame + telemetry.SAMPLE_PERIOD:
                last_frame = max(last_frame + telemetry.SAMPLE_PERIOD, now - telemetry.SAMPLE_PERIOD)      # fixed rate, no drift
                with self._lock:
                    if self.heartbeat:
                        frame = telemetry.build_frame(self, now)
                        self.history.append(frame)
                        if self.recorder is not None:
                            self.recorder.frame(frame)
            try:
                if now - last_hb >= 1.0:
                    # A ground station announces itself; PX4 only streams to a peer it has heard from.
                    conn.mav.heartbeat_send(mavutil.mavlink.MAV_TYPE_GCS, mavutil.mavlink.MAV_AUTOPILOT_INVALID, 0, 0, 0)
                    last_hb = now
                msg = conn.recv_match(blocking=True, timeout=0.05)
            except Exception as exc:
                with self._lock:
                    self.error = f"link error: {exc}"
                log.warning(self.error)
                break
            if msg is None:
                continue
            mtype = msg.get_type()
            if mtype == "BAD_DATA":
                continue
            with self._lock:
                self.msg_counts[mtype] = self.msg_counts.get(mtype, 0) + 1
                self._handle(mtype, msg)
                if self.recorder is not None:
                    self.recorder.raw(msg)
                if self.heartbeat and not requested:
                    requested = True
                    try:                                    # ask for telemetry streams (ArduPilot needs this; harmless on PX4)
                        conn.mav.request_data_stream_send(self.target[0], self.target[1], mavutil.mavlink.MAV_DATA_STREAM_ALL, 10, 1)
                    except Exception:
                        pass

    def _handle(self, mtype: str, m) -> None:
        now = time.time()
        if mtype == "HEARTBEAT":
            if m.type == 6 or m.autopilot == 8:            # another ground station / component without autopilot
                return
            self.target = (m.get_srcSystem(), m.get_srcComponent())
            ap = AUTOPILOT_NAMES.get(m.autopilot, f"autopilot {m.autopilot}")
            if ap == "px4":
                main, sub = (m.custom_mode >> 16) & 0xFF, (m.custom_mode >> 24) & 0xFF
                mode = PX4_MAIN_MODES.get(main, f"mode {main}") + (f" / {PX4_AUTO_SUB.get(sub, sub)}" if main == 4 else "")
            elif ap == "ardupilot":
                mode = COPTER_MODES.get(m.custom_mode, f"mode {m.custom_mode}")
            else:
                mode = f"mode {m.custom_mode}"
            self.heartbeat = {"autopilot": ap, "vehicle_type": VEHICLE_TYPES.get(m.type, f"type {m.type}"), "mode": mode,
                              "armed": bool(m.base_mode & MAV_MODE_FLAG_SAFETY_ARMED), "system_status": m.system_status,
                              "system_id": self.target[0], "component_id": self.target[1]}
            self.last_heartbeat = now
        elif mtype == "PARAM_VALUE":
            name = m.param_id if isinstance(m.param_id, str) else m.param_id.decode("ascii", "ignore")
            name = name.rstrip("\x00")
            if not name or name.startswith("_"):            # PX4's _HASH_CHECK pseudo-parameter is protocol metadata
                return
            value = float(m.param_value)
            if self.heartbeat and self.heartbeat["autopilot"] == "px4" and m.param_type in INT_TYPES:
                value = float(px4_int(m.param_value))
            self.params[name] = {"value": value, "type": int(m.param_type), "index": int(m.param_index)}
            if m.param_count and m.param_count != 65535:
                self.param_count = int(m.param_count)
            if name.startswith("SIM_") or name.startswith("SIH_"):
                self.sim_evidence.add("simulation parameters (SIM_* / SIH_*) present")
        elif mtype == "ATTITUDE":
            self.tm["attitude"] = {"roll": m.roll, "pitch": m.pitch, "yaw": m.yaw, "rates": [m.rollspeed, m.pitchspeed, m.yawspeed], "t": now}
        elif mtype == "LOCAL_POSITION_NED":
            self.tm["local"] = {"x": m.x, "y": m.y, "z": m.z, "vx": m.vx, "vy": m.vy, "vz": m.vz, "t": now}
        elif mtype == "GLOBAL_POSITION_INT":
            self.tm["global"] = {"lat": m.lat / 1e7, "lon": m.lon / 1e7, "alt": m.alt / 1000, "relative_alt": m.relative_alt / 1000,
                                 "vx": m.vx / 100, "vy": m.vy / 100, "vz": m.vz / 100, "heading": None if m.hdg == 65535 else m.hdg / 100, "t": now}
        elif mtype == "SYS_STATUS":
            self.tm["battery"] = {"voltage": None if m.voltage_battery == 65535 else m.voltage_battery / 1000,
                                  "current": None if m.current_battery < 0 else m.current_battery / 100,          # negative = not measured
                                  "remaining": None if m.battery_remaining == -1 else m.battery_remaining, "t": now}
            self.tm["sensors"] = {"present": m.onboard_control_sensors_present, "enabled": m.onboard_control_sensors_enabled,
                                  "health": m.onboard_control_sensors_health, "load": m.load / 10, "t": now}
        elif mtype == "GPS_RAW_INT":
            self.tm["gps"] = {"fix_type": m.fix_type, "satellites": None if m.satellites_visible == 255 else m.satellites_visible,
                              "eph": None if m.eph == 65535 else m.eph / 100, "t": now}
        elif mtype == "VFR_HUD":
            self.tm["hud"] = {"airspeed": m.airspeed, "groundspeed": m.groundspeed, "heading": m.heading, "throttle": m.throttle, "alt": m.alt, "climb": m.climb, "t": now}
        elif mtype == "SERVO_OUTPUT_RAW":
            self.tm["outputs"] = {"pwm": [m.servo1_raw, m.servo2_raw, m.servo3_raw, m.servo4_raw, m.servo5_raw, m.servo6_raw, m.servo7_raw, m.servo8_raw], "t": now}
        elif mtype == "BATTERY_STATUS":
            self.tm["battery_status"] = {"consumed": None if m.current_consumed == -1 else m.current_consumed, "t": now}
        elif mtype == "RC_CHANNELS":
            self.tm["rc"] = {"rssi": None if m.rssi == 255 else m.rssi, "channels": m.chancount, "t": now}
        elif mtype == "EXTENDED_SYS_STATE":
            self.tm["extended"] = {"landed": m.landed_state, "t": now}
        elif mtype == "STATUSTEXT":
            text = m.text if isinstance(m.text, str) else m.text.decode("utf-8", "ignore")
            self.texts = (self.texts + [{"severity": m.severity, "text": text.rstrip("\x00"), "t": now}])[-30:]
        elif mtype in ("SIMSTATE", "SIM_STATE", "HIL_STATE_QUATERNION", "HIL_STATE"):
            self.sim_evidence.add(f"{mtype} messages received")

    # ------------------------------------------------------------ queries
    def _require(self):
        if self._conn is None:
            raise Conflict("not connected to a vehicle")
        if not self.heartbeat:
            raise Conflict("connected, but no heartbeat from an autopilot has been received yet")

    def status(self) -> dict:
        with self._lock:
            now = time.time()
            age = now - self.last_heartbeat if self.last_heartbeat else None
            return {
                "open": self._conn is not None, "device": self.device, "error": self.error,
                "declared_simulator": bool(self.spec and self.spec.get("simulator")),
                "heartbeat": self.heartbeat, "heartbeat_age": age, "alive": age is not None and age < 3.0,
                "uptime": now - self.connected_at if self.connected_at else None,
                "params_loaded": len(self.params), "param_count": self.param_count, "params_complete": self.params_complete,
                "sim_evidence": sorted(self.sim_evidence), "messages": dict(sorted(self.msg_counts.items(), key=lambda kv: -kv[1])[:12]),
                "texts": self.texts[-8:],
            }

    def telemetry(self) -> dict:
        with self._lock:
            now = time.time()
            out = {k: {**v, "age": now - v["t"]} for k, v in self.tm.items()}
            return {"heartbeat": self.heartbeat, "alive": bool(self.last_heartbeat and now - self.last_heartbeat < 3.0), **out}

    # ------------------------------------------------------------ live frames and recording
    def frame(self) -> dict:
        from . import telemetry
        with self._lock:
            f = telemetry.build_frame(self)
            return {"open": self._conn is not None, "alive": bool(self.last_heartbeat and time.time() - self.last_heartbeat < telemetry.STALE),
                    "frame": f, "failsafe": telemetry.failsafe_summary(f, self.texts),
                    "recording": ({"log_id": self.recorder.log_id, "frames": self.recorder.frames, "messages": self.recorder.messages,
                                   "elapsed": round(time.time() - self.recorder.started, 1)} if self.recorder else None)}

    def history_since(self, since: float = 0.0) -> list[dict]:
        with self._lock:
            return [f for f in self.history if f["t"] > since]

    def start_recorder(self, recorder) -> None:
        with self._lock:
            self.recorder = recorder

    def stop_recorder(self):
        with self._lock:
            rec, self.recorder = self.recorder, None
        if rec is not None:
            rec.close()
        return rec

    # ------------------------------------------------------------ parameters
    def read_params(self, timeout: float = 25.0) -> dict:
        """Fetch the full parameter list, re-requesting any that were dropped."""
        self._require()
        conn = self._conn
        with self._lock:
            self.params, self.param_count, self.params_complete = {}, None, False
            conn.mav.param_request_list_send(*self.target)
        deadline, last_n, last_change, retried = time.time() + timeout, -1, time.time(), 0
        while time.time() < deadline:
            time.sleep(0.15)
            with self._lock:
                n, total = len(self.params), self.param_count
                if total is not None and n >= total:
                    self.params_complete = True
                    break
                if n != last_n:
                    last_n, last_change = n, time.time()
                elif time.time() - last_change > 1.5:
                    if total is None:
                        conn.mav.param_request_list_send(*self.target)
                    else:
                        have = {p["index"] for p in self.params.values()}
                        missing = [i for i in range(total) if i not in have][:40]
                        for i in missing:
                            conn.mav.param_request_read_send(self.target[0], self.target[1], b"", i)
                    retried += 1
                    last_change = time.time()
                    if retried > 12:
                        break
        with self._lock:
            if not self.params:
                raise Conflict("the vehicle did not send any parameters")
            log.info("read %d of %s parameters", len(self.params), self.param_count)
            return {"complete": self.params_complete, "count": len(self.params), "expected": self.param_count,
                    "params": {k: {"value": v["value"], "type": v["type"]} for k, v in sorted(self.params.items())}}

    def write_params(self, changes: list, confirm: bool) -> dict:
        from .autopilot import same
        self._require()
        if confirm is not True:
            raise ValidationError(["writing parameters requires explicit confirmation"])
        if not isinstance(changes, list) or not changes:
            raise ValidationError(["no parameter changes were given"])
        errors, plan = [], []
        with self._lock:
            if not self.heartbeat or time.time() - (self.last_heartbeat or 0) > 3.0:
                raise Conflict("no recent heartbeat from the vehicle; refusing to write")
            if self.heartbeat["armed"]:
                raise Conflict("the vehicle is ARMED — parameters are not written to an armed vehicle")
            if not self.params_complete:
                raise Conflict("read the vehicle's full parameter list first, so each change can be checked against it")
            for ch in changes:
                name, value, old = ch.get("name"), ch.get("value"), ch.get("expected_old")
                cur = self.params.get(name)
                if cur is None:
                    errors.append(f"{name}: not a parameter of this vehicle (it may have been renamed in this firmware version)")
                    continue
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                    errors.append(f"{name}: value must be a finite number")
                    continue
                if old is None or not same(cur["value"], float(old)):
                    errors.append(f"{name}: the vehicle now holds {cur['value']:g}, not the value that was reviewed — re-read and review again")
                    continue
                if cur["type"] in INT_TYPES and not float(value).is_integer():
                    errors.append(f"{name}: is an integer parameter; {value} is not a whole number")
                    continue
                plan.append((name, float(value), cur))
        if errors:
            raise ValidationError(errors)
        px4 = self.heartbeat["autopilot"] == "px4"
        results = []
        for name, value, cur in plan:
            wire = px4_float(value) if px4 and cur["type"] in INT_TYPES else value
            ok, got = False, None
            for _ in range(3):
                with self._lock:
                    self.params.pop(name, None)
                    self._conn.mav.param_set_send(self.target[0], self.target[1], name.encode("ascii"), wire, cur["type"])
                t0 = time.time()
                while time.time() - t0 < 1.5:
                    time.sleep(0.05)
                    with self._lock:
                        echoed = self.params.get(name)
                    if echoed is not None:
                        got = echoed["value"]
                        ok = same(got, value)
                        break
                if got is not None:
                    break
            with self._lock:
                if name not in self.params:                 # no echo: restore what we last knew so the list stays complete
                    self.params[name] = cur
            results.append({"name": name, "requested": value, "previous": cur["value"], "readback": got, "ok": ok,
                            "note": None if ok else ("no confirmation from the vehicle" if got is None else "vehicle reports a different value (rejected or clamped)")})
            log.info("param write %s: %g -> %g (%s)", name, cur["value"], value, "ok" if ok else "FAILED")
        return {"results": results, "written": sum(r["ok"] for r in results), "failed": sum(not r["ok"] for r in results)}


LINK = Link()
