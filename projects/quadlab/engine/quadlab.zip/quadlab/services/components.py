"""Component management service: validation, provenance, history, comparison."""
from __future__ import annotations

import math
import re
from typing import Any

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from .. import catalog
from ..db import Component, ComponentRevision, ProjectItem, Source, ThrustTest, utcnow


class ValidationError(Exception):
    def __init__(self, errors: list[str]):
        super().__init__("; ".join(errors))
        self.errors = errors


class NotFound(Exception):
    pass


class Conflict(Exception):
    pass


def _commit(db: Session) -> None:
    """Commit unless a multi-step operation has deferred it (see import_components)."""
    if db.info.get("defer_commit"):
        db.flush()
    else:
        db.commit()


CUSTOM_KEY = re.compile(r"^custom_[a-z0-9_]{1,40}$")
POINT_KEYS = {"throttle", "voltage", "current", "power", "thrust", "speed", "torque", "temperature"}


def _number(v: Any, label: str, errors: list[str], signed: bool = False) -> float | None:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        errors.append(f"{label}: must be a number")
        return None
    v = float(v)
    if not math.isfinite(v):
        errors.append(f"{label}: must be finite")
        return None
    if v < 0 and not signed:
        errors.append(f"{label}: must not be negative")
        return None
    return v


def validate_specs(category: str, specs: dict, source_ids: set[int]) -> dict:
    """Return a cleaned spec dict. Empty values are dropped: a missing value is
    represented by absence, never by zero or a placeholder."""
    if category not in catalog.CATEGORIES:
        raise ValidationError([f"unknown category '{category}'"])
    fields = catalog.field_map(category)
    errors: list[str] = []
    out: dict = {}
    for key, entry in (specs or {}).items():
        field = fields.get(key)
        if field is None and not CUSTOM_KEY.match(key):
            errors.append(f"{key}: not a field of category '{category}' (custom fields must be named custom_*)")
            continue
        if not isinstance(entry, dict):
            errors.append(f"{key}: must be an object with value and provenance")
            continue
        value = entry.get("value")
        label = field.label if field else str(entry.get("label") or key)
        ftype = field.type if field else entry.get("type", "text")
        if value is None or value == "" or value == []:
            continue
        clean: dict = {}
        if ftype == "number":
            n = _number(value, label, errors, signed=bool(field and field.signed) or field is None)
            if n is None:
                continue
            clean["value"] = n
            unc = entry.get("uncertainty")
            if unc not in (None, ""):
                u = _number(unc, f"{label} uncertainty", errors)
                if u is not None:
                    clean["uncertainty"] = u
        elif ftype == "list":
            if isinstance(value, str):
                value = [s.strip() for s in value.split(",")]
            if not isinstance(value, list) or not all(isinstance(s, str) for s in value):
                errors.append(f"{label}: must be a list of text values")
                continue
            value = [s.strip() for s in value if s.strip()]
            if not value:
                continue
            clean["value"] = value
        elif ftype == "bool":
            if not isinstance(value, bool):
                errors.append(f"{label}: must be true or false")
                continue
            clean["value"] = value
        else:
            if not isinstance(value, str):
                errors.append(f"{label}: must be text")
                continue
            clean["value"] = value.strip()
            if not clean["value"]:
                continue
        prov = entry.get("provenance") or "user"
        if prov not in catalog.PROVENANCE:
            errors.append(f"{label}: unknown provenance '{prov}'")
            continue
        clean["provenance"] = prov
        sid = entry.get("source_id")
        if sid is not None:
            if sid not in source_ids:
                errors.append(f"{label}: source {sid} does not belong to this component")
                continue
            clean["source_id"] = sid
        if prov == "manufacturer" and sid is None:
            errors.append(f"{label}: a manufacturer specification must cite a source")
            continue
        note = (entry.get("note") or "").strip()
        if note:
            clean["note"] = note
        if field is None:
            clean["label"] = label
            clean["type"] = "number" if ftype == "number" else "text"
            if entry.get("unit"):
                clean["unit"] = str(entry["unit"]).strip()
        out[key] = clean
    if errors:
        raise ValidationError(errors)
    return out


def validate_points(points: list) -> list[dict]:
    errors: list[str] = []
    out: list[dict] = []
    if not isinstance(points, list) or not points:
        raise ValidationError(["thrust test needs at least one data point"])
    for i, p in enumerate(points, 1):
        if not isinstance(p, dict):
            errors.append(f"point {i}: must be an object")
            continue
        row: dict = {}
        for k, v in p.items():
            if k not in POINT_KEYS:
                errors.append(f"point {i}: unknown key '{k}'")
                continue
            if v is None or v == "":
                continue
            n = _number(v, f"point {i} {k}", errors, signed=(k == "temperature"))
            if n is not None:
                row[k] = n
        if "thrust" not in row:
            errors.append(f"point {i}: thrust is required")
        if "throttle" in row and not 0 <= row["throttle"] <= 1:
            errors.append(f"point {i}: throttle must be a fraction between 0 and 1")
        out.append(row)
    if errors:
        raise ValidationError(errors)
    out.sort(key=lambda r: (r.get("throttle", 0), r["thrust"]))
    return out


def display_name(c: Component) -> str:
    name = f"{c.manufacturer} {c.model}".strip()
    return f"{name} — {c.variant}" if c.variant else name


def completeness(c: Component) -> dict:
    core = [f for f in catalog.fields_for(c.category) if f.core]
    missing = [f.key for f in core if f.key not in (c.specs or {})]
    return {"core_total": len(core), "core_present": len(core) - len(missing), "missing": missing}


def provenance_counts(c: Component) -> dict:
    counts = {k: 0 for k in catalog.PROVENANCE}
    for entry in (c.specs or {}).values():
        counts[entry.get("provenance", "user")] = counts.get(entry.get("provenance", "user"), 0) + 1
    return counts


def source_dict(s: Source) -> dict:
    return {
        "id": s.id, "kind": s.kind, "title": s.title, "url": s.url, "file_name": s.file_name,
        "file_size": s.file_size, "has_file": bool(s.file_path), "retrieved_on": s.retrieved_on, "note": s.note,
    }


def thrust_dict(t: ThrustTest) -> dict:
    return {
        "id": t.id, "propeller": t.propeller, "propeller_component_id": t.propeller_component_id,
        "voltage": t.voltage, "provenance": t.provenance, "source_id": t.source_id, "note": t.note, "points": t.points,
    }


def summary_dict(c: Component, usage: int = 0) -> dict:
    return {
        "id": c.id, "category": c.category, "manufacturer": c.manufacturer, "model": c.model, "variant": c.variant,
        "name": display_name(c), "description": c.description, "origin": c.origin, "parent_id": c.parent_id,
        "weight": (c.specs or {}).get("weight"),
        "completeness": completeness(c), "provenance": provenance_counts(c),
        "source_count": len(c.sources), "thrust_test_count": len(c.thrust_tests), "usage": usage,
        "updated_at": c.updated_at.isoformat(),
    }


def detail_dict(db: Session, c: Component) -> dict:
    d = summary_dict(c, usage_count(db, c.id))
    d.update(
        specs=c.specs or {},
        sources=[source_dict(s) for s in c.sources],
        thrust_tests=[thrust_dict(t) for t in c.thrust_tests],
        created_at=c.created_at.isoformat(),
    )
    return d


def usage_count(db: Session, component_id: int) -> int:
    return db.scalar(select(func.count()).select_from(ProjectItem).where(ProjectItem.component_id == component_id)) or 0


def get(db: Session, component_id: int) -> Component:
    c = db.get(Component, component_id)
    if c is None:
        raise NotFound(f"component {component_id} not found")
    return c


def search(db: Session, category: str | None = None, q: str | None = None, origin: str | None = None) -> list[dict]:
    stmt = select(Component)
    if category:
        stmt = stmt.where(Component.category == category)
    if origin:
        stmt = stmt.where(Component.origin == origin)
    for term in (q or "").split():
        like = f"%{term}%"
        stmt = stmt.where(or_(Component.manufacturer.ilike(like), Component.model.ilike(like),
                              Component.variant.ilike(like), Component.description.ilike(like)))
    stmt = stmt.order_by(Component.category, Component.manufacturer, Component.model, Component.variant)
    usage = dict(db.execute(select(ProjectItem.component_id, func.count()).group_by(ProjectItem.component_id)).all())
    return [summary_dict(c, usage.get(c.id, 0)) for c in db.scalars(stmt)]


def _header(data: dict, errors: list[str]) -> dict:
    out = {}
    for key, required in (("manufacturer", True), ("model", True), ("variant", False), ("description", False)):
        v = (data.get(key) or "").strip()
        if required and not v:
            errors.append(f"{key} is required")
        out[key] = v
    return out


def _record(db: Session, c: Component, summary: str, changes: list[dict]) -> None:
    db.add(ComponentRevision(component_id=c.id, summary=summary, changes=changes))


def diff_specs(before: dict, after: dict) -> list[dict]:
    changes = []
    for key in sorted(set(before) | set(after)):
        b, a = before.get(key), after.get(key)
        if b != a:
            changes.append({"field": key, "before": b, "after": a})
    return changes


def create(db: Session, data: dict, origin: str = "custom") -> Component:
    errors: list[str] = []
    header = _header(data, errors)
    category = data.get("category")
    if category not in catalog.CATEGORIES:
        errors.append(f"unknown category '{category}'")
    if errors:
        raise ValidationError(errors)
    c = Component(category=category, origin=origin, parent_id=data.get("parent_id"), specs={}, **header)
    db.add(c)
    db.flush()
    # A new component has no sources yet, so only unsourced values can be set here.
    c.specs = validate_specs(category, data.get("specs") or {}, set())
    _record(db, c, "Component created", diff_specs({}, c.specs))
    _commit(db)
    return c


def update(db: Session, component_id: int, data: dict) -> Component:
    c = get(db, component_id)
    errors: list[str] = []
    changes: list[dict] = []
    if any(k in data for k in ("manufacturer", "model", "variant", "description")):
        merged = {k: data.get(k, getattr(c, k)) for k in ("manufacturer", "model", "variant", "description")}
        header = _header(merged, errors)
        if errors:
            raise ValidationError(errors)
        for k, v in header.items():
            if getattr(c, k) != v:
                changes.append({"field": k, "before": getattr(c, k), "after": v})
                setattr(c, k, v)
    if "specs" in data:
        new_specs = validate_specs(c.category, data["specs"] or {}, {s.id for s in c.sources})
        changes += diff_specs(c.specs or {}, new_specs)
        c.specs = new_specs
    if changes:
        c.updated_at = utcnow()
        _record(db, c, f"{len(changes)} field(s) changed", changes)
    _commit(db)
    return c


def duplicate(db: Session, component_id: int, variant: str | None = None) -> Component:
    """Create a reusable profile derived from an existing component. Sources and
    thrust tests are copied so every value keeps its citation."""
    src = get(db, component_id)
    c = Component(
        category=src.category, manufacturer=src.manufacturer, model=src.model,
        variant=(variant or "").strip() or f"{src.variant + ' ' if src.variant else ''}copy".strip(),
        description=src.description, origin="custom", parent_id=src.id, specs={},
    )
    db.add(c)
    db.flush()
    id_map: dict[int, int] = {}
    for s in src.sources:
        ns = Source(component_id=c.id, kind=s.kind, title=s.title, url=s.url, file_name=s.file_name,
                    file_path=s.file_path, file_size=s.file_size, retrieved_on=s.retrieved_on, note=s.note)
        db.add(ns)
        db.flush()
        id_map[s.id] = ns.id
    specs = {}
    for key, entry in (src.specs or {}).items():
        e = dict(entry)
        if "source_id" in e:
            e["source_id"] = id_map.get(e["source_id"])
            if e["source_id"] is None:
                e.pop("source_id")
        specs[key] = e
    c.specs = specs
    for t in src.thrust_tests:
        db.add(ThrustTest(component_id=c.id, propeller=t.propeller, propeller_component_id=t.propeller_component_id,
                          voltage=t.voltage, provenance=t.provenance, source_id=id_map.get(t.source_id),
                          note=t.note, points=list(t.points)))
    _record(db, c, f"Profile created from '{display_name(src)}' (#{src.id})", [])
    _commit(db)
    return c


def delete(db: Session, component_id: int) -> None:
    c = get(db, component_id)
    n = usage_count(db, c.id)
    if n:
        raise Conflict(f"'{display_name(c)}' is used in {n} project configuration item(s); remove it there first")
    db.delete(c)
    _commit(db)


def add_source(db: Session, component_id: int, data: dict) -> Source:
    c = get(db, component_id)
    errors = []
    title = (data.get("title") or "").strip()
    url = (data.get("url") or "").strip() or None
    kind = data.get("kind") or "other"
    if not title:
        errors.append("title is required")
    if kind not in catalog.SOURCE_KINDS:
        errors.append(f"unknown source kind '{kind}'")
    if url and not re.match(r"^https?://", url):
        errors.append("url must start with http:// or https://")
    if not url and not data.get("file_path"):
        errors.append("a source needs a URL or an uploaded file")
    if errors:
        raise ValidationError(errors)
    s = Source(component_id=c.id, kind=kind, title=title, url=url, file_name=data.get("file_name"),
               file_path=data.get("file_path"), file_size=data.get("file_size"),
               retrieved_on=data.get("retrieved_on") or utcnow().date().isoformat(), note=(data.get("note") or "").strip())
    db.add(s)
    _record(db, c, f"Source added: {title}", [])
    c.updated_at = utcnow()
    _commit(db)
    return s


def delete_source(db: Session, source_id: int) -> Source:
    s = db.get(Source, source_id)
    if s is None:
        raise NotFound(f"source {source_id} not found")
    c = s.component
    cited = [k for k, e in (c.specs or {}).items() if e.get("source_id") == source_id]
    cited_tests = [t.id for t in c.thrust_tests if t.source_id == source_id]
    if cited or cited_tests:
        raise Conflict(
            f"source is cited by {len(cited)} specification(s) and {len(cited_tests)} thrust test(s); "
            "re-attribute those values before removing it")
    _record(db, c, f"Source removed: {s.title}", [])
    db.delete(s)
    _commit(db)
    return s


def save_thrust_test(db: Session, component_id: int, data: dict, test_id: int | None = None) -> ThrustTest:
    c = get(db, component_id)
    if c.category != "motor":
        raise ValidationError(["thrust tests belong to motors"])
    errors: list[str] = []
    propeller = (data.get("propeller") or "").strip()
    if not propeller:
        errors.append("propeller is required")
    voltage = _number(data.get("voltage"), "voltage", errors)
    if voltage is not None and voltage <= 0:
        errors.append("voltage must be positive")
    prov = data.get("provenance") or "user"
    if prov not in catalog.PROVENANCE:
        errors.append(f"unknown provenance '{prov}'")
    sid = data.get("source_id")
    if sid is not None and sid not in {s.id for s in c.sources}:
        errors.append("source does not belong to this component")
    if prov == "manufacturer" and sid is None:
        errors.append("manufacturer thrust data must cite a source")
    if errors:
        raise ValidationError(errors)
    points = validate_points(data.get("points"))
    if test_id is None:
        t = ThrustTest(component_id=c.id)
        db.add(t)
        verb = "added"
    else:
        t = db.get(ThrustTest, test_id)
        if t is None or t.component_id != c.id:
            raise NotFound(f"thrust test {test_id} not found")
        verb = "updated"
    t.propeller, t.voltage, t.provenance, t.source_id = propeller, voltage, prov, sid
    t.propeller_component_id = data.get("propeller_component_id")
    t.note, t.points = (data.get("note") or "").strip(), points
    c.updated_at = utcnow()
    _record(db, c, f"Thrust test {verb}: {propeller} @ {voltage:g} V ({len(points)} points)", [])
    _commit(db)
    return t


def delete_thrust_test(db: Session, component_id: int, test_id: int) -> None:
    t = db.get(ThrustTest, test_id)
    if t is None or t.component_id != component_id:
        raise NotFound(f"thrust test {test_id} not found")
    _record(db, t.component, f"Thrust test removed: {t.propeller} @ {t.voltage:g} V", [])
    db.delete(t)
    _commit(db)


def compare(db: Session, ids: list[int]) -> dict:
    comps = [get(db, i) for i in ids]
    if len(comps) < 2:
        raise ValidationError(["select at least two components to compare"])
    cats = {c.category for c in comps}
    if len(cats) > 1:
        raise ValidationError(["components must be in the same category to be compared"])
    category = comps[0].category
    rows = []
    for f in catalog.fields_for(category):
        cells = [(c.specs or {}).get(f.key) for c in comps]
        if not any(cells):
            continue
        values = [cell.get("value") if cell else None for cell in cells]
        rows.append({"field": f.as_dict(), "cells": cells, "differs": len({repr(v) for v in values}) > 1})
    custom_keys = sorted({k for c in comps for k in (c.specs or {}) if CUSTOM_KEY.match(k)})
    for key in custom_keys:
        cells = [(c.specs or {}).get(key) for c in comps]
        first = next(cell for cell in cells if cell)
        rows.append({
            "field": {"key": key, "label": first.get("label", key), "type": first.get("type", "text"), "quantity": None,
                      "unit": first.get("unit"), "si_unit": first.get("unit"), "group": "Custom", "core": False},
            "cells": cells, "differs": True,
        })
    return {"category": category, "components": [summary_dict(c) for c in comps], "rows": rows}


def export_component(c: Component) -> dict:
    return {
        "category": c.category, "manufacturer": c.manufacturer, "model": c.model, "variant": c.variant,
        "description": c.description,
        "sources": [{"ref": s.id, "kind": s.kind, "title": s.title, "url": s.url, "retrieved_on": s.retrieved_on, "note": s.note}
                    for s in c.sources if s.url],
        "specs": c.specs or {},
        "thrust_tests": [{k: v for k, v in thrust_dict(t).items() if k not in ("id", "propeller_component_id")} for t in c.thrust_tests],
    }


def import_components(db: Session, payload: dict, origin: str = "custom") -> list[Component]:
    """Import components exported by this application (format 'quadlab.components/1').
    All-or-nothing: one invalid component rejects the whole file."""
    if not isinstance(payload, dict) or payload.get("format") != "quadlab.components/1":
        raise ValidationError(["not a QuadLab component export (expected format 'quadlab.components/1')"])
    created: list[Component] = []
    db.info["defer_commit"] = True
    try:
        for n, item in enumerate(payload.get("components") or [], 1):
            try:
                c = create(db, {**item, "specs": {}}, origin=origin)
                db.flush()
                ref_map: dict[Any, int] = {}
                for s in item.get("sources") or []:
                    src = add_source(db, c.id, s)
                    db.flush()
                    ref_map[s.get("ref")] = src.id
                db.refresh(c)

                def remap(sid):
                    if sid is None:
                        return None
                    if sid not in ref_map:
                        raise ValidationError([f"cites unknown source ref {sid!r}"])
                    return ref_map[sid]

                specs = {}
                for key, entry in (item.get("specs") or {}).items():
                    e = dict(entry)
                    e["source_id"] = remap(e.get("source_id"))
                    specs[key] = e
                update(db, c.id, {"specs": specs})
                for t in item.get("thrust_tests") or []:
                    save_thrust_test(db, c.id, {**t, "source_id": remap(t.get("source_id"))})
                created.append(c)
            except ValidationError as exc:
                raise ValidationError([f"component {n} ({item.get('manufacturer', '?')} {item.get('model', '?')}): {e}" for e in exc.errors])
        db.info.pop("defer_commit", None)
        db.commit()
    except Exception:
        db.info.pop("defer_commit", None)
        db.rollback()
        raise
    return created
