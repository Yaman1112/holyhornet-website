"""Electrical architecture: generates the wiring diagram (nodes, links, port map) from
the configuration and checks it.

Port names are generic (TELEM1, GPS1, MAIN OUT 1…), derived from the *number* of each
interface recorded for the flight controller. They are not a board pinout: confirm
against the manufacturer's pinout drawing before wiring.
"""
from __future__ import annotations

import math

from .assembly import ROTORS
from .context import Config, Part, has_iface, motor_demand, norm

# Conservative free-air "chassis wiring" ampacity for copper conductors, as tabulated
# in the Handbook of Electronic Tables and Formulas (the widely reproduced AWG table).
# Used as guidance only: silicone-insulated RC wire is commonly run above these
# figures for short lengths, and bundled or enclosed wiring must be derated.
AMPACITY = [(26, 2.2), (24, 3.5), (22, 7.0), (20, 11.0), (18, 16.0), (16, 22.0), (14, 32.0), (12, 41.0), (10, 55.0), (8, 73.0), (6, 101.0), (4, 135.0)]
WIRE_MARGIN = 1.25
RHO_CU = 1.724e-8         # ohm*m, annealed copper at 20 degC


def awg_resistance(awg: int) -> float:
    """Ohm per metre. AWG diameter d = 0.127 mm * 92^((36-n)/39)."""
    d = 0.127e-3 * 92 ** ((36 - awg) / 39)
    return RHO_CU / (math.pi * d * d / 4)


def recommend_wire(current: float | None) -> dict | None:
    if current is None:
        return None
    for awg, amps in AMPACITY:
        if amps >= current * WIRE_MARGIN:
            return {"awg": awg, "ampacity": amps, "resistance_per_m": awg_resistance(awg),
                    "basis": f"smallest gauge with chassis-wiring ampacity ≥ {WIRE_MARGIN:g} × {current:.3g} A"}
    return {"awg": None, "ampacity": None, "resistance_per_m": None,
            "basis": f"{current:.3g} A × {WIRE_MARGIN:g} exceeds the table (4 AWG, 135 A): use parallel conductors or a bus bar"}


def _ports(fc: Part | None) -> list[dict]:
    if fc is None:
        return []
    ports = []

    def add(kind, prefix, key, shared=False):
        n = fc.num(key)
        for i in range(int(n or 0)):
            ports.append({"name": f"{prefix}{i + 1}", "kind": kind, "shared": shared})
        return n

    add("uart", "TELEM", "uart_ports")
    add("gps", "GPS", "gps_ports")
    add("can", "CAN", "can_interfaces", shared=True)
    add("i2c", "I2C", "i2c_ports", shared=True)
    for i in range(int(fc.num("pwm_outputs") or 0)):
        ports.append({"name": f"MAIN OUT {i + 1}", "kind": "pwm", "shared": False})
    if fc.items("rc_inputs"):
        ports.append({"name": "RC IN", "kind": "rc", "shared": False})
    ports.append({"name": "POWER1", "kind": "power", "shared": False})
    return ports


def _device_kinds(part: Part) -> list[str]:
    """Port kinds this device can use, in order of preference."""
    if part.category == "gps":
        return ["gps", "can"] if has_iface(part, "can") else ["gps"]
    if part.category == "receiver":
        return ["rc", "uart"]
    kinds = []
    if has_iface(part, "uart") or has_iface(part, "serial"):
        kinds.append("uart")
    if has_iface(part, "can"):
        kinds.append("can")
    if has_iface(part, "i2c"):
        kinds.append("i2c")
    return kinds


SIGNAL_CATS = ["gps", "telemetry", "receiver", "companion", "rangefinder", "optical_flow", "imu", "barometer", "magnetometer", "camera", "payload"]
RAIL_POWERED = {"gps", "telemetry", "receiver", "rangefinder", "optical_flow", "imu", "barometer", "magnetometer"}


def build(cfg: Config) -> dict:
    overrides = (cfg.design.get("electrical") or {}).get("ports") or {}
    batt, pm, fc = cfg.one("battery"), cfg.one("power"), cfg.one("flight_controller")
    motor, esc = cfg.one("motor"), cfg.one("esc")
    n = cfg.rotor_count
    demand = motor_demand(cfg)
    nodes, links, findings, assumptions = [], [], [], []

    def node(id, kind, part: Part | None, label=None, **extra):
        nodes.append({"id": id, "kind": kind, "name": part.name if part else None, "label": label or (part.name if part else id),
                      "component_id": part.comp["id"] if part else None, **extra})

    def link(a, b, kind, label, **extra):
        links.append({"id": f"{a}>{b}:{kind}", "from": a, "to": b, "kind": kind, "label": label, **extra})

    def finding(level, message, nodes_=()):
        findings.append({"level": level, "message": message, "nodes": list(nodes_)})

    v_batt = batt.num("nominal_voltage") if batt else None
    per_motor = demand.per_motor if demand else None
    total = per_motor * n if per_motor is not None else None
    if demand:
        assumptions.append(f"Propulsion design current: {demand.text}. Total = {n} × per-motor current; avionics are not included.")
    assumptions.append(f"Wire gauges: smallest gauge with ampacity ≥ {WIRE_MARGIN:g} × design current, from the chassis-wiring "
                       "ampacity table (Handbook of Electronic Tables and Formulas). Guidance only — verify against the wire "
                       "manufacturer's rating, length and bundling.")
    assumptions.append("Port names are generic, derived from the interface counts on record; they are not the board pinout.")

    # ---------------- power train
    if batt:
        node("battery", "battery", batt, voltage=v_batt, connector=batt.text("connector"), wire=batt.text("wire_gauge"))
    else:
        finding("missing", "No battery in the configuration.")
    if pm:
        node("power", "power", pm, connectors=pm.items("connectors"), output_voltage=pm.num("output_voltage"))
    dist = "power" if pm else "battery" if batt else None
    if batt and pm:
        bc, pc = batt.text("connector"), pm.items("connectors")
        mate = bc and pc and any(norm(bc) in norm(c) or norm(c) in norm(bc) for c in pc)
        link("battery", "power", "power_main", "Battery main", voltage=v_batt, current=total,
             current_basis=demand.basis if demand else None, wire=recommend_wire(total),
             connector_from=bc, connector_to=", ".join(pc) or None, wire_stated=batt.text("wire_gauge"))
        if bc and pc and not mate:
            finding("conflict", f"Battery connector ({bc}) does not mate with the power module connectors on record ({', '.join(pc)}). "
                                "An adapter or re-termination rated for the full current is required.", ["battery", "power"])
        cont = pm.num("continuous_current")
        if cont is not None and total is not None and total > cont:
            finding("conflict", f"Propulsion design current {total:.3g} A exceeds the {cont:g} A continuous rating of {pm.name}.", ["power"])
    elif batt and not pm and cfg.count("esc"):
        finding("missing", "No power module or PDB: there is no defined way to distribute battery power to the ESCs, "
                           "measure battery voltage/current, or supply the flight controller.", ["battery"])

    rotors = ROTORS.get(cfg.layout, ROTORS["X"])
    esc_n, motor_n = cfg.count("esc"), cfg.count("motor")
    for i in range(max(esc_n, motor_n)):
        r = i + 1
        spin = rotors[i % len(rotors)][1]
        if i < esc_n:
            node(f"esc{r}", "esc", esc, label=f"ESC {r}", rotor=r)
            if dist:
                link(dist, f"esc{r}", "power_main", f"ESC {r} supply", voltage=v_batt, current=per_motor,
                     current_basis=demand.basis if demand else None, wire=recommend_wire(per_motor),
                     connector_from="B+ / GND pads" if pm and any("pad" in c.lower() for c in pm.items("connectors")) else None)
        if i < motor_n:
            node(f"motor{r}", "motor", motor, label=f"Motor {r} ({spin})", rotor=r, spin=spin)
            if i < esc_n:
                link(f"esc{r}", f"motor{r}", "phase", f"3-phase, rotor {r}", current=per_motor,
                     current_basis=demand.basis if demand else None, wire_stated=motor.text("lead_wire"),
                     note="Swap any two phase wires to reverse rotation. Phase current differs from the DC input current.")
            else:
                finding("missing", f"Motor {r} has no ESC.", [f"motor{r}"])
    if esc_n > motor_n:
        finding("conflict", f"{esc_n} ESCs for {motor_n} motors.")
    if esc and batt:
        s, lo, hi = batt.num("cell_count"), esc.num("cells_min"), esc.num("cells_max")
        if None not in (s, lo, hi) and not lo <= s <= hi:
            finding("conflict", f"Incorrect voltage level: {batt.name} ({s:g}S) is outside the {lo:g}S–{hi:g}S range of {esc.name}.",
                    [f"esc{i + 1}" for i in range(esc_n)])

    # ---------------- flight controller and regulated rail
    ports = _ports(fc)
    used: dict[str, list[str]] = {}
    rail_v = pm.num("output_voltage") if pm else None
    if fc:
        node("fc", "flight_controller", fc, ports=ports)
        if pm:
            vmax = fc.num("max_input_voltage")
            link("power", "fc", "power_reg", "FC supply + battery monitor", voltage=rail_v, current=pm.num("output_current_max"),
                 current_basis="regulator limit", port="POWER1", wire=recommend_wire(pm.num("output_current_max")),
                 connector_from=next((c for c in pm.items("connectors") if "pin" in c.lower()), None),
                 note="Carries the regulated supply and the voltage/current sense signals.")
            if rail_v is not None and vmax is not None and rail_v > vmax:
                finding("conflict", f"Incorrect voltage level: {pm.name} outputs {rail_v:g} V, above the {vmax:g} V maximum input of {fc.name}.", ["fc", "power"])
        else:
            finding("missing", f"{fc.name} has no power source: add a power module or PDB with a regulated output.", ["fc"])
        proto = esc.items("protocols") if esc else []
        pwm = [p for p in ports if p["kind"] == "pwm"]
        for i in range(esc_n):
            if i < len(pwm):
                used.setdefault(pwm[i]["name"], []).append(f"esc{i + 1}")
                link("fc", f"esc{i + 1}", "signal", f"Motor {i + 1} command", port=pwm[i]["name"],
                     protocol=", ".join(proto) if proto else None,
                     note=None if proto else "ESC signal protocol is not on record.")
            else:
                finding("missing", f"ESC {i + 1} has no motor output: {fc.name} has {len(pwm)} PWM output(s) on record.", [f"esc{i + 1}"])
    elif cfg.parts:
        finding("missing", "No flight controller in the configuration.")

    # ---------------- peripherals
    rail_load, rail_unknown = 0.0, []
    seen: dict[int, int] = {}
    port_by_name = {p["name"]: p for p in ports}
    for cat in SIGNAL_CATS:
        for part in cfg.all(cat):
            for _ in range(part.quantity):
                k = seen.get(part.comp["id"], 0)
                seen[part.comp["id"]] = k + 1
                key = f"{part.comp['id']}:{k}"
                nid = f"dev{key}"
                kinds = _device_kinds(part)
                node(nid, cat, part, key=key, port_kinds=kinds,
                     supply=[part.num("supply_voltage_min"), part.num("supply_voltage_max")], supply_current=part.num("supply_current"))
                if not fc:
                    continue
                if not kinds:
                    finding("missing", f"{part.name}: communication interfaces are not on record, so no port can be assigned.", [nid])
                    continue
                chosen = overrides.get(key)
                manual = chosen is not None
                if manual and (chosen not in port_by_name or port_by_name[chosen]["kind"] not in kinds):
                    finding("conflict", f"{part.name} is assigned to {chosen}, which is not a compatible port on {fc.name}.", [nid])
                    continue
                if not manual:
                    for kind in kinds:
                        free = [p for p in ports if p["kind"] == kind and (p["shared"] or p["name"] not in used)]
                        if free:
                            chosen = free[0]["name"]
                            break
                if chosen is None:
                    finding("missing", f"{part.name} has no free port on {fc.name} "
                                       f"(needs one of: {', '.join(k.upper() for k in kinds)}).", [nid])
                    continue
                port = port_by_name[chosen]
                used.setdefault(chosen, []).append(nid)
                proto = {"uart": "UART", "gps": "UART (GNSS)" + (" + I2C compass" if part.text("compass") else ""),
                         "can": "CAN", "i2c": "I2C", "rc": ", ".join(part.items("protocols")) or "RC"}[port["kind"]]
                link("fc", nid, "signal", part.name, port=chosen, protocol=proto, manual=manual,
                     baud=part.num("default_baud"), connector_to=part.text("connector"))
                if cat in RAIL_POWERED:
                    lo, hi = part.num("supply_voltage_min"), part.num("supply_voltage_max")
                    amps = part.num("supply_current_peak") or part.num("supply_current")
                    link("fc", nid, "power_reg", f"{part.name} supply", voltage=rail_v, current=amps,
                         current_basis="recorded supply current" if amps is not None else None, port=chosen)
                    if amps is None:
                        rail_unknown.append(part.name)
                    else:
                        rail_load += amps
                    if None not in (lo, hi, rail_v) and not (lo <= rail_v <= hi) and not (lo == hi and abs(rail_v - lo) / lo <= 0.10):
                        finding("conflict", f"Incorrect voltage level: {part.name} accepts {lo:g}–{hi:g} V; the regulated rail is {rail_v:g} V.", [nid])
                else:
                    finding("missing", f"{part.name}: power source is not defined. It is not assumed to be powered from the "
                                       "flight-controller port — add a regulated supply (BEC) sized for it.", [nid])
    for name, devs in used.items():
        if len(devs) > 1 and not port_by_name[name]["shared"]:
            finding("conflict", f"Port conflict: {name} is assigned to {len(devs)} devices.", devs)

    port_map = [{**p, "devices": [next(n_["label"] for n_ in nodes if n_["id"] == d) for d in used.get(p["name"], [])]} for p in ports]
    rails = []
    if v_batt is not None:
        rails.append({"name": "Battery bus", "voltage": v_batt, "load": total, "capacity": batt.num("max_discharge_current"),
                      "note": "Nominal voltage; a full pack is higher and a loaded pack sags lower."})
    if pm and rail_v is not None:
        cap = pm.num("output_current_max")
        rails.append({"name": f"{rail_v:g} V regulated ({pm.name})", "voltage": rail_v, "load": rail_load, "capacity": cap,
                      "note": "Load is the sum of recorded peripheral currents. The flight controller's own draw is not on record"
                              + (f"; also not on record: {', '.join(rail_unknown)}." if rail_unknown else ".")})
        if cap is not None and rail_load > cap:
            finding("conflict", f"Regulated rail overload: peripherals draw {rail_load:.2f} A against {cap:g} A available from {pm.name}.", ["power"])
    return {"nodes": nodes, "links": links, "port_map": port_map, "rails": rails, "findings": findings, "assumptions": assumptions,
            "ampacity_table": [{"awg": a, "ampacity": amps, "resistance_per_m": awg_resistance(a)} for a, amps in AMPACITY]}


def valid_port_keys(cfg: Config) -> set[str]:
    return {n["key"] for n in build(cfg)["nodes"] if n.get("key")}
