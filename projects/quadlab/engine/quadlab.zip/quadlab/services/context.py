"""Read-only view of a configuration shared by the compatibility, assembly and
electrical services. It is built from plain dicts so the same code evaluates the
working configuration, a saved revision, or a what-if substitution."""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field, replace

from .. import catalog

INCH = 0.0254
PROP_DIMS = re.compile(r"(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)", re.I)


@dataclass(frozen=True, eq=False)       # identity hash: parts hold dicts
class Part:
    comp: dict                 # {id, category, name, specs, thrust_tests?}
    quantity: int = 1
    item_id: int | None = None

    @property
    def name(self) -> str:
        return self.comp["name"]

    @property
    def category(self) -> str:
        return self.comp["category"]

    def entry(self, key: str) -> dict | None:
        return (self.comp.get("specs") or {}).get(key)

    def num(self, key: str) -> float | None:
        e = self.entry(key)
        return float(e["value"]) if e and isinstance(e["value"], (int, float)) and not isinstance(e["value"], bool) else None

    def text(self, key: str) -> str | None:
        e = self.entry(key)
        return e["value"] if e and isinstance(e["value"], str) else None

    def items(self, key: str) -> list[str]:
        e = self.entry(key)
        if not e:
            return []
        return list(e["value"]) if isinstance(e["value"], list) else [str(e["value"])]

    def label(self, key: str) -> str:
        f = catalog.field_map(self.category).get(key)
        return f.label if f else key

    def cite(self, key: str) -> dict:
        """Evidence record for a value used in a check."""
        e = self.entry(key)
        f = catalog.field_map(self.category).get(key)
        return {"component": self.name, "field": self.label(key), "key": key,
                "value": e["value"] if e else None, "quantity": f.quantity if f else None, "unit": f.unit if f else None,
                "provenance": e.get("provenance") if e else None, "note": e.get("note") if e else None}


@dataclass(frozen=True)
class Config:
    airframe: str
    layout: str
    parts: tuple[Part, ...]
    design: dict = field(default_factory=dict)

    @property
    def rotor_count(self) -> int:
        return catalog.AIRFRAMES[self.airframe]["rotor_count"]

    def all(self, category: str) -> list[Part]:
        return [p for p in self.parts if p.category == category]

    def one(self, category: str) -> Part | None:
        found = self.all(category)
        return found[0] if found else None

    def count(self, category: str) -> int:
        return sum(p.quantity for p in self.all(category))

    def swap(self, category: str, comp: dict) -> "Config":
        """What-if: replace every part of `category` with `comp` (quantities kept)."""
        parts = tuple(replace(p, comp=comp) if p.category == category else p for p in self.parts)
        return replace(self, parts=parts)


def from_items(airframe: str, layout: str, items: list[dict], design: dict | None = None) -> Config:
    return Config(airframe, layout,
                  tuple(Part(i["component"], i["quantity"], i.get("id")) for i in items), design or {})


def prop_inches(prop: Part) -> tuple[float, float] | None:
    d, p = prop.num("diameter"), prop.num("pitch")
    return (d / INCH, p / INCH) if d and p else None


def matching_test(motor: Part, prop: Part) -> dict | None:
    """Thrust test of `motor` run with a propeller of the same diameter and pitch."""
    dims = prop_inches(prop)
    if not dims:
        return None
    for t in motor.comp.get("thrust_tests") or []:
        m = PROP_DIMS.search(t["propeller"])
        if m and abs(float(m.group(1)) - dims[0]) < 0.06 and abs(float(m.group(2)) - dims[1]) < 0.06:
            return t
    return None


def tested_diameters(motor: Part) -> list[float]:
    out = []
    for t in motor.comp.get("thrust_tests") or []:
        m = PROP_DIMS.search(t["propeller"])
        if m:
            out.append(float(m.group(1)))
    return sorted(set(out))


def full_throttle(test: dict) -> dict | None:
    pts = [p for p in test["points"] if p.get("throttle") is not None]
    return max(pts, key=lambda p: p["throttle"]) if pts else None


@dataclass(frozen=True)
class Demand:
    """Design current per motor and where the number comes from."""
    per_motor: float
    basis: str            # "tested" | "rating"
    text: str
    thrust: float | None = None      # N per motor at that point (tested only)
    voltage: float | None = None


def motor_demand(cfg: Config) -> Demand | None:
    motor, prop = cfg.one("motor"), cfg.one("propeller")
    if motor is None:
        return None
    if prop is not None:
        t = matching_test(motor, prop)
        pt = full_throttle(t) if t else None
        if pt and pt.get("current") is not None:
            return Demand(pt["current"], "tested",
                          f"{pt['current']:.3g} A per motor at {pt['throttle'] * 100:.0f}% throttle, "
                          f"{t['voltage']:g} V, {t['propeller']} ({t['provenance']} bench test of {motor.name})",
                          pt.get("thrust"), t["voltage"])
    rated = motor.num("max_current")
    if rated is not None:
        return Demand(rated, "rating", f"{rated:.3g} A per motor — the maximum continuous current rating of {motor.name} "
                                       "(no bench test on record for this motor with the selected propeller)")
    return None


def fmt_len(m: float) -> str:
    return f"{m * 1000:.4g} mm"


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", s.lower())


def has_iface(part: Part, token: str) -> bool:
    return any(token.lower() in s.lower() for s in part.items("interfaces") + part.items("protocols"))


def hyp(a: tuple[float, float], b: tuple[float, float]) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])
