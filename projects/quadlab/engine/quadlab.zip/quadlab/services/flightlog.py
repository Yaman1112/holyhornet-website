"""Flight-log import: turn a log file into one normalised dataset.

Supported inputs
  .tlog              MAVLink telemetry log (timestamped frames) — verified with QuadLab's own recordings
  .bin / .log        ArduPilot dataflash log — parsed with pymavlink's DFReader using ArduCopter's documented
                     message names (ATT, BAT, GPS, VIBE, RCOU, MODE, MSG, CTUN, POS). Tested with a synthetic
                     dataflash file, not with a log from a real ArduPilot flight.
  .ulg               PX4 ULog (pyulog) — verified with logs written by PX4 v1.15.4
  .json              QuadLab telemetry export (quadlab.telemetry/1)
  .csv               QuadLab telemetry export, or any CSV with a time column (t / elapsed / time) and
                     columns named like QuadLab telemetry fields

A dataset is {"channels": {name: {"t": [...], "v": [...]}}, "events": [...], "meta": {...}} with time in
seconds from the start of the log, angles in degrees, SI units otherwise, motor outputs normalised to 0..1.
A channel exists only if the log carried it: nothing is synthesised.
"""
from __future__ import annotations

import csv
import io
import json
import math
from pathlib import Path

from .components import ValidationError
from .link import COPTER_MODES, PX4_AUTO_SUB, PX4_MAIN_MODES

MAX_POINTS = 6000         # per channel kept for charts (analysis runs on the full-resolution data first)
FORMATS = {".tlog": "tlog", ".bin": "dataflash", ".log": "dataflash", ".ulg": "ulog", ".json": "json", ".csv": "csv"}
CHANNEL_INFO = {
    "roll": ("Roll", "deg"), "pitch": ("Pitch", "deg"), "yaw": ("Yaw", "deg"), "roll_sp": ("Roll setpoint", "deg"), "pitch_sp": ("Pitch setpoint", "deg"),
    "roll_rate": ("Roll rate", "deg/s"), "pitch_rate": ("Pitch rate", "deg/s"), "yaw_rate": ("Yaw rate", "deg/s"),
    "alt": ("Altitude above start", "m"), "north": ("Local north", "m"), "east": ("Local east", "m"), "north_sp": ("North setpoint", "m"), "east_sp": ("East setpoint", "m"),
    "ground_speed": ("Ground speed", "m/s"), "climb": ("Vertical speed", "m/s"),
    "voltage": ("Battery voltage", "V"), "current": ("Battery current", "A"), "consumed": ("Charge consumed", "mAh"), "remaining": ("Battery remaining", "%"),
    "sats": ("Satellites", ""), "hdop": ("HDOP", ""), "fix": ("GNSS fix type", ""),
    "vibe_x": ("Vibration X", "m/s²"), "vibe_y": ("Vibration Y", "m/s²"), "vibe_z": ("Vibration Z", "m/s²"), "clip": ("Accelerometer clipping count", ""),
    "out1": ("Motor output 1", "0..1"), "out2": ("Motor output 2", "0..1"), "out3": ("Motor output 3", "0..1"), "out4": ("Motor output 4", "0..1"),
    "throttle": ("Throttle", "%"), "load": ("Autopilot load", "%"), "armed": ("Armed", "0/1"), "landed": ("Landed", "0/1"),
}


class Builder:
    def __init__(self, fmt: str):
        self.fmt = fmt
        self.ch: dict[str, tuple[list, list]] = {}
        self.events: list[dict] = []
        self.t0: float | None = None
        self.notes: list[str] = []
        self.autopilot = "unknown"
        self.vibration_source: str | None = None

    def rel(self, t: float) -> float:
        if self.t0 is None:
            self.t0 = t
        return t - self.t0

    def add(self, name: str, t: float, v) -> None:
        if v is None:
            return
        v = float(v)
        if not math.isfinite(v):
            return
        ts, vs = self.ch.setdefault(name, ([], []))
        ts.append(round(t, 4))
        vs.append(v)

    def event(self, t: float, kind: str, text: str, severity: int | None = None) -> None:
        self.events.append({"t": round(max(0.0, t), 2), "kind": kind, "text": text, "severity": severity})

    def dataset(self) -> dict:
        if not self.ch:
            raise ValidationError(["no usable flight data found in the file"])
        alt = self.ch.get("alt")
        if alt:                                             # altitude relative to the first sample
            a0 = alt[1][0]
            self.ch["alt"] = (alt[0], [v - a0 for v in alt[1]])
        end = max(ts[-1] for ts, _ in self.ch.values())
        self.events.sort(key=lambda e: e["t"])
        return {"channels": {k: {"t": ts, "v": vs} for k, (ts, vs) in self.ch.items()}, "events": self.events,
                "meta": {"format": self.fmt, "duration": round(end, 2), "autopilot": self.autopilot, "notes": self.notes,
                         "vibration_source": self.vibration_source, "channels": sorted(self.ch)}}


def _euler(w: float, x: float, y: float, z: float) -> tuple[float, float, float]:
    roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    pitch = math.asin(max(-1.0, min(1.0, 2 * (w * y - z * x))))
    yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    return math.degrees(roll), math.degrees(pitch), math.degrees(yaw)


def _pwm(v: float) -> float | None:
    return None if not v else max(0.0, min(1.0, (v - 1000.0) / 1000.0))


# ------------------------------------------------------------------ MAVLink tlog and ArduPilot dataflash

def parse_mavlink(path: Path, fmt: str) -> dict:
    from pymavlink import mavutil
    b = Builder(fmt)
    try:
        conn = mavutil.mavlink_connection(str(path), dialect="ardupilotmega")
    except Exception as exc:
        raise ValidationError([f"could not open the log: {exc}"])
    last_mode, last_armed, autopilot = None, None, None
    n = 0
    try:
        while True:
            try:
                m = conn.recv_match()
            except Exception:
                break                                       # truncated final record
            if m is None:
                break
            typ = m.get_type()
            if typ in ("BAD_DATA", "FMT", "FMTU", "PARM", "UNIT", "MULT"):
                continue
            ts = getattr(m, "_timestamp", None)
            if not ts:
                continue
            t = b.rel(ts)
            n += 1
            d = math.degrees
            if typ == "HEARTBEAT":
                if m.type == 6 or m.autopilot == 8:
                    continue
                autopilot = {3: "ardupilot", 12: "px4"}.get(m.autopilot, autopilot)
                if autopilot == "px4":
                    main, sub = (m.custom_mode >> 16) & 0xFF, (m.custom_mode >> 24) & 0xFF
                    mode = PX4_MAIN_MODES.get(main, f"mode {main}") + (f" / {PX4_AUTO_SUB.get(sub, sub)}" if main == 4 else "")
                else:
                    mode = COPTER_MODES.get(m.custom_mode, f"mode {m.custom_mode}")
                armed = bool(m.base_mode & 128)
                b.add("armed", t, 1.0 if armed else 0.0)
                if mode != last_mode:
                    b.event(t, "mode", f"Flight mode: {mode}")
                    last_mode = mode
                if last_armed is not None and armed != last_armed:
                    b.event(t, "arming", "Armed" if armed else "Disarmed")
                last_armed = armed
            elif typ == "ATTITUDE":
                b.add("roll", t, d(m.roll)); b.add("pitch", t, d(m.pitch)); b.add("yaw", t, d(m.yaw))
                b.add("roll_rate", t, d(m.rollspeed)); b.add("pitch_rate", t, d(m.pitchspeed)); b.add("yaw_rate", t, d(m.yawspeed))
            elif typ == "ATTITUDE_TARGET":
                r, p, _ = _euler(*m.q)
                b.add("roll_sp", t, r); b.add("pitch_sp", t, p)
            elif typ == "LOCAL_POSITION_NED":
                b.add("north", t, m.x); b.add("east", t, m.y); b.add("alt", t, -m.z)
                b.add("ground_speed", t, math.hypot(m.vx, m.vy)); b.add("climb", t, -m.vz)
            elif typ == "POSITION_TARGET_LOCAL_NED":
                if not (m.type_mask & 0b11):                # x and y not ignored
                    b.add("north_sp", t, m.x); b.add("east_sp", t, m.y)
            elif typ == "GLOBAL_POSITION_INT" and "alt" not in b.ch:
                b.add("alt", t, m.relative_alt / 1000.0)
            elif typ == "SYS_STATUS":
                if m.voltage_battery != 65535:
                    b.add("voltage", t, m.voltage_battery / 1000.0)
                if m.current_battery >= 0:
                    b.add("current", t, m.current_battery / 100.0)
                if m.battery_remaining >= 0:
                    b.add("remaining", t, m.battery_remaining)
                b.add("load", t, m.load / 10.0)
            elif typ == "BATTERY_STATUS":
                if m.current_consumed >= 0:
                    b.add("consumed", t, m.current_consumed)
            elif typ == "GPS_RAW_INT":
                b.add("fix", t, m.fix_type)
                if m.satellites_visible != 255:
                    b.add("sats", t, m.satellites_visible)
                if m.eph != 65535:
                    b.add("hdop", t, m.eph / 100.0)
            elif typ == "VFR_HUD":
                b.add("throttle", t, m.throttle)
            elif typ == "SERVO_OUTPUT_RAW":
                for i, raw in enumerate((m.servo1_raw, m.servo2_raw, m.servo3_raw, m.servo4_raw), 1):
                    b.add(f"out{i}", t, _pwm(raw))
            elif typ == "VIBRATION":
                b.add("vibe_x", t, m.vibration_x); b.add("vibe_y", t, m.vibration_y); b.add("vibe_z", t, m.vibration_z)
                b.add("clip", t, m.clipping_0 + m.clipping_1 + m.clipping_2)
                b.vibration_source = "MAVLink VIBRATION message"
            elif typ == "EXTENDED_SYS_STATE":
                if m.landed_state in (1, 2, 3, 4):
                    b.add("landed", t, 1.0 if m.landed_state == 1 else 0.0)
            elif typ == "STATUSTEXT":
                text = m.text if isinstance(m.text, str) else m.text.decode("utf-8", "ignore")
                b.event(t, "message", text.rstrip("\x00"), int(m.severity))
            # ---- ArduPilot dataflash messages
            elif typ == "ATT":
                b.add("roll", t, m.Roll); b.add("pitch", t, m.Pitch); b.add("yaw", t, m.Yaw)
                b.add("roll_sp", t, m.DesRoll); b.add("pitch_sp", t, m.DesPitch)
            elif typ == "BAT":
                if getattr(m, "Inst", getattr(m, "Instance", 0)) == 0:
                    b.add("voltage", t, m.Volt); b.add("current", t, m.Curr); b.add("consumed", t, m.CurrTot)
            elif typ == "GPS":
                if getattr(m, "I", 0) == 0:
                    b.add("fix", t, m.Status); b.add("sats", t, m.NSats); b.add("hdop", t, m.HDop); b.add("ground_speed", t, m.Spd)
            elif typ == "VIBE":
                if getattr(m, "IMU", 0) == 0:
                    b.add("vibe_x", t, m.VibeX); b.add("vibe_y", t, m.VibeY); b.add("vibe_z", t, m.VibeZ)
                    clip = getattr(m, "Clip", None)
                    if clip is None:
                        clip = sum(getattr(m, f"Clip{i}", 0) for i in range(3))
                    b.add("clip", t, clip)
                    b.vibration_source = "ArduPilot VIBE log message (m/s²)"
            elif typ == "RCOU":
                for i in range(1, 5):
                    b.add(f"out{i}", t, _pwm(getattr(m, f"C{i}", 0)))
            elif typ == "CTUN":
                b.add("throttle", t, m.ThO * 100.0); b.add("alt", t, m.Alt); b.add("climb", t, m.CRt / 100.0)
            elif typ == "MODE":
                mode = COPTER_MODES.get(int(m.ModeNum), str(m.Mode))
                b.event(t, "mode", f"Flight mode: {mode}")
                autopilot = autopilot or "ardupilot"
            elif typ == "MSG":
                b.event(t, "message", str(m.Message), None)
            elif typ == "ERR":
                b.event(t, "message", f"Error: subsystem {m.Subsys}, code {m.ECode}", 3)
            elif typ == "EV":
                ev = {10: "Armed", 11: "Disarmed", 18: "Land complete", 28: "Not landed"}.get(int(m.Id))
                if ev:
                    b.event(t, "arming" if int(m.Id) in (10, 11) else "state", ev)
                    if int(m.Id) in (10, 11):
                        b.add("armed", t, 1.0 if int(m.Id) == 10 else 0.0)
    finally:
        conn.close()
    if n == 0:
        raise ValidationError(["the file contains no readable MAVLink or dataflash messages"])
    b.autopilot = autopilot or "unknown"
    if b.vibration_source == "MAVLink VIBRATION message":
        # ArduPilot's published limits apply to ArduPilot's vibration levels only; PX4 fills this message with its own metric.
        b.vibration_source = ("ArduPilot vibration levels from the MAVLink VIBRATION message (m/s²)" if b.autopilot == "ardupilot"
                              else f"MAVLink VIBRATION message from {b.autopilot} (not ArduPilot's vibration levels; no published limit applies)")
    if fmt == "dataflash":
        b.notes.append("Dataflash parsing follows ArduCopter's documented log messages and was tested with a synthetic log only — check the channels against a known flight.")
    return b.dataset()


# ------------------------------------------------------------------ PX4 ULog

def parse_ulog(path: Path) -> dict:
    try:
        from pyulog import ULog
        u = ULog(str(path))
    except Exception as exc:
        raise ValidationError([f"could not read the ULog file: {exc}"])
    b = Builder("ulog")
    b.autopilot = "px4"
    b.t0 = u.start_timestamp / 1e6
    topics = {}
    for d in u.data_list:
        if d.multi_id == 0 and d.name not in topics:
            topics[d.name] = d.data

    def series(topic: str, stride: int = 1):
        data = topics.get(topic)
        if data is None:
            return None, None
        ts = [x / 1e6 - b.t0 for x in data["timestamp"][::stride]]
        return ts, {k: v[::stride] for k, v in data.items()}

    ts, a = series("vehicle_attitude", 5)
    if ts:
        for i, t in enumerate(ts):
            r, p, y = _euler(a["q[0]"][i], a["q[1]"][i], a["q[2]"][i], a["q[3]"][i])
            b.add("roll", t, r); b.add("pitch", t, p); b.add("yaw", t, y)
    ts, a = series("vehicle_attitude_setpoint")
    if ts:
        for i, t in enumerate(ts):
            r, p, _ = _euler(a["q_d[0]"][i], a["q_d[1]"][i], a["q_d[2]"][i], a["q_d[3]"][i])
            b.add("roll_sp", t, r); b.add("pitch_sp", t, p)
    ts, a = series("vehicle_angular_velocity", 5)
    if ts:
        for i, t in enumerate(ts):
            b.add("roll_rate", t, math.degrees(a["xyz[0]"][i])); b.add("pitch_rate", t, math.degrees(a["xyz[1]"][i])); b.add("yaw_rate", t, math.degrees(a["xyz[2]"][i]))
    ts, a = series("vehicle_local_position", 5)
    if ts:
        for i, t in enumerate(ts):
            b.add("north", t, a["x"][i]); b.add("east", t, a["y"][i]); b.add("alt", t, -a["z"][i])
            b.add("ground_speed", t, math.hypot(a["vx"][i], a["vy"][i])); b.add("climb", t, -a["vz"][i])
    ts, a = series("vehicle_local_position_setpoint", 2)
    if ts:
        for i, t in enumerate(ts):
            b.add("north_sp", t, a["x"][i]); b.add("east_sp", t, a["y"][i])
    ts, a = series("battery_status")
    if ts:
        for i, t in enumerate(ts):
            b.add("voltage", t, a["voltage_v"][i])
            if a["current_a"][i] >= 0:
                b.add("current", t, a["current_a"][i])
            b.add("consumed", t, a["discharged_mah"][i]); b.add("remaining", t, a["remaining"][i] * 100.0)
    for topic in ("sensor_gps", "vehicle_gps_position"):
        ts, a = series(topic)
        if ts:
            for i, t in enumerate(ts):
                b.add("sats", t, a["satellites_used"][i])
                if "hdop" in a:
                    b.add("hdop", t, a["hdop"][i])
                if "fix_type" in a:
                    b.add("fix", t, a["fix_type"][i])
            break
    ts, a = series("actuator_motors")
    if ts:
        for i, t in enumerate(ts):
            for k in range(4):
                v = a[f"control[{k}]"][i]
                if math.isfinite(v):
                    b.add(f"out{k + 1}", t, max(0.0, min(1.0, v)))
    ts, a = series("vehicle_imu_status")
    if ts:
        for i, t in enumerate(ts):
            b.add("vibe_x", t, a["accel_vibration_metric"][i])
            if "accel_clipping[0]" in a:
                b.add("clip", t, a["accel_clipping[0]"][i] + a["accel_clipping[1]"][i] + a["accel_clipping[2]"][i])
        b.vibration_source = "PX4 vehicle_imu_status.accel_vibration_metric (m/s², a single combined metric)"
    ts, a = series("cpuload")
    if ts:
        for i, t in enumerate(ts):
            b.add("load", t, a["load"][i] * 100.0)
    ts, a = series("vehicle_land_detected")
    if ts:
        for i, t in enumerate(ts):
            b.add("landed", t, 1.0 if a["landed"][i] else 0.0)
    ts, a = series("vehicle_status")
    if ts:
        last_arm, last_nav = None, None
        nav_names = {0: "Manual", 1: "Altitude", 2: "Position", 3: "Mission", 4: "Hold", 5: "Return", 10: "Acro", 14: "Offboard", 15: "Stabilized", 17: "Takeoff", 18: "Land"}
        for i, t in enumerate(ts):
            armed = int(a["arming_state"][i]) == 2
            b.add("armed", t, 1.0 if armed else 0.0)
            if last_arm is not None and armed != last_arm:
                b.event(t, "arming", "Armed" if armed else "Disarmed")
            last_arm = armed
            nav = int(a["nav_state"][i])
            if nav != last_nav:
                b.event(t, "mode", f"Flight mode: {nav_names.get(nav, f'nav state {nav}')}")
                last_nav = nav
            if "failsafe" in a and a["failsafe"][i] and (i == 0 or not a["failsafe"][i - 1]):
                b.event(t, "failsafe", "Failsafe activated (vehicle_status.failsafe)", 2)
    level = {"EMERGENCY": 0, "ALERT": 1, "CRITICAL": 2, "ERROR": 3, "WARNING": 4, "NOTICE": 5, "INFO": 6, "DEBUG": 7}
    for msg in u.logged_messages:
        sev = level.get(msg.log_level_str(), 6)
        if sev <= 5:
            b.event(msg.timestamp / 1e6 - b.t0, "message", msg.message, sev)
    return b.dataset()


# ------------------------------------------------------------------ QuadLab JSON / CSV, generic CSV

FRAME_MAP = {"roll": "roll", "pitch": "pitch", "yaw": "yaw", "roll_rate": "roll_rate", "pitch_rate": "pitch_rate", "yaw_rate": "yaw_rate",
             "alt_rel": "alt", "north": "north", "east": "east", "ground_speed": "ground_speed", "climb": "climb", "voltage": "voltage", "current": "current",
             "consumed": "consumed", "remaining": "remaining", "satellites": "sats", "hdop": "hdop", "throttle": "throttle", "cpu_load": "load"}


def _frames_to_dataset(frames: list[dict], fmt: str, autopilot: str = "unknown") -> dict:
    b = Builder(fmt)
    b.autopilot = autopilot
    last_mode, last_armed = None, None
    for f in frames:
        if f.get("t") is None:
            continue
        t = b.rel(float(f["t"]))
        for src, dst in FRAME_MAP.items():
            if f.get(src) not in (None, ""):
                b.add(dst, t, f[src])
        for i in range(1, 5):
            if f.get(f"out{i}") not in (None, ""):
                b.add(f"out{i}", t, _pwm(float(f[f"out{i}"])))
        armed = f.get("armed")
        if isinstance(armed, str):
            armed = armed.lower() in ("true", "1")
        if armed is not None and armed != "":
            b.add("armed", t, 1.0 if armed else 0.0)
            if last_armed is not None and bool(armed) != last_armed:
                b.event(t, "arming", "Armed" if armed else "Disarmed")
            last_armed = bool(armed)
        if f.get("mode") and f["mode"] != last_mode:
            b.event(t, "mode", f"Flight mode: {f['mode']}")
            last_mode = f["mode"]
        if f.get("landed"):
            b.add("landed", t, 1.0 if f["landed"] == "on ground" else 0.0)
    b.notes.append("Imported from sampled telemetry frames (5 Hz): too coarse for oscillation analysis, and vibration is not included.")
    return b.dataset()


def parse_json(path: Path) -> dict:
    try:
        doc = json.loads(path.read_text(encoding="utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationError([f"not valid JSON: {exc}"])
    if not isinstance(doc, dict) or doc.get("format") != "quadlab.telemetry/1" or not isinstance(doc.get("frames"), list):
        raise ValidationError(["JSON import expects a QuadLab telemetry export (format 'quadlab.telemetry/1')"])
    return _frames_to_dataset(doc["frames"], "json", (doc.get("log") or {}).get("autopilot", "unknown"))


def parse_csv(path: Path) -> dict:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        raise ValidationError(["CSV file is not text"])
    lines = [ln for ln in text.splitlines() if ln.strip() and not ln.lstrip().startswith("#")]
    rows = list(csv.DictReader(io.StringIO("\n".join(lines))))
    if not rows:
        raise ValidationError(["the CSV file has no data rows"])
    cols = {c.strip().lower(): c for c in rows[0]}
    tcol = next((cols[c] for c in ("t", "elapsed", "time", "time_s", "timestamp") if c in cols), None)
    if tcol is None:
        raise ValidationError(["the CSV needs a time column named t, elapsed, time, time_s or timestamp (seconds)"])
    known = set(FRAME_MAP) | {f"out{i}" for i in range(1, 5)} | {"mode", "armed", "landed"}
    if not known & set(cols):
        raise ValidationError(["no recognised data columns. Expected QuadLab telemetry field names such as roll, pitch, alt_rel, voltage, current, out1…"])
    frames = []
    for r in rows:
        try:
            f = {"t": float(r[tcol])}
        except (TypeError, ValueError):
            continue
        for key, col in cols.items():
            if key in known and r[col] not in (None, ""):
                f[key] = r[col]
        frames.append(f)
    return _frames_to_dataset(frames, "csv")


def parse(path: Path, fmt: str | None = None) -> dict:
    fmt = fmt or FORMATS.get(path.suffix.lower())
    if fmt is None:
        raise ValidationError([f"unsupported log type '{path.suffix}'. Supported: {', '.join(sorted(FORMATS))}"])
    if fmt in ("tlog", "dataflash"):
        return parse_mavlink(path, fmt)
    if fmt == "ulog":
        return parse_ulog(path)
    if fmt == "json":
        return parse_json(path)
    return parse_csv(path)


def from_simulation(result: dict) -> dict:
    """A simulator run as a dataset, so the same analysis can be applied for comparison."""
    b = Builder("simulation")
    b.autopilot = "QuadLab reference controller"
    for s in result.get("samples") or []:
        t = b.rel(s["t"])
        b.add("roll", t, math.degrees(s["roll"])); b.add("pitch", t, math.degrees(s["pitch"])); b.add("yaw", t, math.degrees(s["yaw"]))
        b.add("alt", t, s["alt"]); b.add("north", t, s["x"]); b.add("east", t, s["y"])
        b.add("ground_speed", t, math.hypot(s["vx"], s["vy"])); b.add("climb", t, -s["vz"])
        b.add("voltage", t, s["voltage"]); b.add("current", t, s["current"]); b.add("consumed", t, s["used_mah"])
        b.add("landed", t, 0.0 if s["alt"] > 0.05 else 1.0)
    for e in result.get("events") or []:
        b.event(e["t"], "state", e["message"])
    return b.dataset()


def downsample(ds: dict, limit: int = MAX_POINTS) -> dict:
    out = {}
    for name, c in ds["channels"].items():
        n = len(c["t"])
        step = max(1, math.ceil(n / limit))
        out[name] = {"t": c["t"][::step], "v": [round(v, 5) for v in c["v"][::step]]}
    return {**ds, "channels": out}
