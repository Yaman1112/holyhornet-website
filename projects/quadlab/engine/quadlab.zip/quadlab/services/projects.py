"""Project management and revision control."""
from __future__ import annotations

import json
import math

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import catalog
from ..db import Component, Project, ProjectItem, ProjectRevision, utcnow
from . import assembly, compatibility, context, electrical, performance
from .components import Conflict, NotFound, ValidationError, completeness, display_name, thrust_dict

REQUIRED_CATEGORIES = ["frame", "flight_controller", "motor", "esc", "propeller", "battery"]


def _lc(label: str) -> str:
    """Lower-case a label for use mid-sentence, leaving acronyms (ESC, IMU, RC) intact."""
    first = label.split()[0]
    return label if first.isupper() else label[0].lower() + label[1:]


def get(db: Session, project_id: int) -> Project:
    p = db.get(Project, project_id)
    if p is None:
        raise NotFound(f"project {project_id} not found")
    return p


def _validate_header(data: dict, current: Project | None = None) -> dict:
    errors: list[str] = []
    out: dict = {}
    for key in ("name", "code", "description", "owner", "airframe", "layout", "status"):
        if key in data:
            out[key] = (data[key] or "").strip() if isinstance(data[key], str) or data[key] is None else data[key]
    if current is None or "name" in out:
        if not out.get("name"):
            errors.append("name is required")
    airframe = out.get("airframe", current.airframe if current else "quadcopter")
    spec = catalog.AIRFRAMES.get(airframe)
    if spec is None or not spec["available"]:
        errors.append(f"airframe '{airframe}' is not available in this version")
    elif "layout" in out and out["layout"] not in spec["layouts"]:
        errors.append(f"layout must be one of {', '.join(spec['layouts'])}")
    if "status" in out and out["status"] not in catalog.PROJECT_STATUSES:
        errors.append(f"status must be one of {', '.join(catalog.PROJECT_STATUSES)}")
    if errors:
        raise ValidationError(errors)
    return out


def create(db: Session, data: dict) -> Project:
    p = Project(**_validate_header(data))
    db.add(p)
    db.commit()
    return p


def update(db: Session, project_id: int, data: dict) -> Project:
    p = get(db, project_id)
    for k, v in _validate_header(data, p).items():
        setattr(p, k, v)
    p.updated_at = utcnow()
    db.commit()
    return p


def delete(db: Session, project_id: int) -> None:
    db.delete(get(db, project_id))
    db.commit()


def _touch(p: Project) -> None:
    p.updated_at = utcnow()


def _check_item(db: Session, data: dict, partial: bool = False) -> dict:
    errors: list[str] = []
    out: dict = {}
    if "component_id" in data or not partial:
        comp = db.get(Component, data.get("component_id") or 0)
        if comp is None:
            errors.append("component not found")
        else:
            out["component_id"] = comp.id
    if "quantity" in data:
        q = data["quantity"]
        if isinstance(q, bool) or not isinstance(q, int) or not 1 <= q <= 99:
            errors.append("quantity must be a whole number between 1 and 99")
        else:
            out["quantity"] = q
    for key in ("role", "note"):
        if key in data:
            out[key] = (data[key] or "").strip()
    if errors:
        raise ValidationError(errors)
    return out


def add_item(db: Session, project_id: int, data: dict) -> ProjectItem:
    p = get(db, project_id)
    fields = _check_item(db, data)
    comp = db.get(Component, fields["component_id"])
    if "quantity" not in fields:
        airframe = catalog.AIRFRAMES[p.airframe]
        fields["quantity"] = airframe["rotor_count"] if comp.category in airframe["per_rotor_categories"] else 1
    item = ProjectItem(project_id=p.id, **fields)
    db.add(item)
    _touch(p)
    db.commit()
    return item


def update_item(db: Session, project_id: int, item_id: int, data: dict) -> ProjectItem:
    """Change quantity/role/note, or replace the component (same slot, new part)."""
    p = get(db, project_id)
    item = db.get(ProjectItem, item_id)
    if item is None or item.project_id != p.id:
        raise NotFound(f"item {item_id} not found")
    for k, v in _check_item(db, data, partial=True).items():
        setattr(item, k, v)
    _touch(p)
    db.commit()
    db.refresh(item)
    return item


def remove_item(db: Session, project_id: int, item_id: int) -> None:
    p = get(db, project_id)
    item = db.get(ProjectItem, item_id)
    if item is None or item.project_id != p.id:
        raise NotFound(f"item {item_id} not found")
    db.delete(item)
    _touch(p)
    db.commit()


# ---------------------------------------------------------------- configuration summary

def _item_rows(items: list[dict]) -> list[dict]:
    """items: [{component: {...category, name, specs}, quantity, role, note}]"""
    rows = []
    for it in items:
        comp = it["component"]
        w = (comp.get("specs") or {}).get("weight")
        unit_mass = w["value"] if w else None
        rows.append({
            **{k: it.get(k) for k in ("id", "quantity", "role", "note")},
            "component_id": comp.get("id"),
            "category": comp["category"],
            "name": comp["name"],
            "unit_mass": unit_mass,
            "unit_mass_uncertainty": w.get("uncertainty") if w else None,
            "mass_provenance": w.get("provenance") if w else None,
            "mass_note": ((comp.get("specs") or {}).get("weight_basis") or {}).get("value"),
            "line_mass": unit_mass * it["quantity"] if unit_mass is not None else None,
            "missing_core": comp.get("missing_core", []),
        })
    return rows


def summarise(airframe_key: str, items: list[dict]) -> dict:
    """Mass roll-up and structural completeness of a configuration.

    Equation:  m_known = sum_i (n_i * m_i)   over items with a stated weight.
    Uncertainty is the linear (worst-case) sum of stated tolerances:  u = sum_i (n_i * u_i).
    Items without a stated weight are listed, not assumed to weigh zero, so the
    result is reported as a lower bound whenever anything is missing.
    """
    rows = _item_rows(items)
    known = [r for r in rows if r["line_mass"] is not None]
    by_prov: dict[str, float] = {}
    by_cat: dict[str, float] = {}
    for r in known:
        by_prov[r["mass_provenance"]] = by_prov.get(r["mass_provenance"], 0.0) + r["line_mass"]
        by_cat[r["category"]] = by_cat.get(r["category"], 0.0) + r["line_mass"]
    airframe = catalog.AIRFRAMES[airframe_key]
    counts: dict[str, int] = {}
    for r in rows:
        counts[r["category"]] = counts.get(r["category"], 0) + r["quantity"]
    findings: list[dict] = []
    for cat in REQUIRED_CATEGORIES:
        if not counts.get(cat):
            findings.append({"level": "missing", "category": cat,
                             "message": f"No {_lc(catalog.CATEGORIES[cat]['singular'])} selected."})
    for cat in airframe["per_rotor_categories"]:
        n = counts.get(cat, 0)
        if n and n != airframe["rotor_count"]:
            findings.append({"level": "warning", "category": cat,
                             "message": f"{n} × {_lc(catalog.CATEGORIES[cat]['singular'])} selected; "
                                        f"a {_lc(airframe['label'])} needs {airframe['rotor_count']}."})
    for cat in ("frame", "flight_controller"):
        if counts.get(cat, 0) > 1:
            findings.append({"level": "warning", "category": cat,
                             "message": f"{counts[cat]} × {_lc(catalog.CATEGORIES[cat]['singular'])} selected; expected 1."})
    for r in rows:
        if r["line_mass"] is None:
            findings.append({"level": "missing", "category": r["category"],
                             "message": f"{r['name']}: no weight on record — excluded from the mass total."})
    return {
        "rows": rows,
        "mass": {
            "known_total": sum(r["line_mass"] for r in known),
            "uncertainty": sum((r["unit_mass_uncertainty"] or 0.0) * r["quantity"] for r in known),
            "is_lower_bound": len(known) < len(rows),
            "items_total": len(rows),
            "items_with_mass": len(known),
            "by_provenance": by_prov,
            "by_category": by_cat,
            "basis": "Sum of stated component weights × quantity. Wiring, fasteners, adhesives and "
                     "unlisted hardware are not included.",
        },
        "counts": counts,
        "findings": findings,
    }


def _live_items(p: Project) -> list[dict]:
    out = []
    for it in p.items:
        c = it.component
        out.append({
            "id": it.id, "quantity": it.quantity, "role": it.role, "note": it.note,
            "component": {"id": c.id, "category": c.category, "name": display_name(c), "manufacturer": c.manufacturer,
                          "model": c.model, "variant": c.variant, "specs": c.specs or {},
                          "missing_core": completeness(c)["missing"],
                          "thrust_tests": [thrust_dict(t) for t in c.thrust_tests]},
        })
    order = list(catalog.CATEGORIES)
    out.sort(key=lambda i: (order.index(i["component"]["category"]), i["id"]))
    return out


def header_dict(p: Project) -> dict:
    return {
        "id": p.id, "name": p.name, "code": p.code, "description": p.description, "owner": p.owner,
        "airframe": p.airframe, "layout": p.layout, "status": p.status,
        "created_at": p.created_at.isoformat(), "updated_at": p.updated_at.isoformat(),
    }


def list_dict(p: Project) -> dict:
    s = summarise(p.airframe, _live_items(p))
    latest = p.revisions[0] if p.revisions else None
    return {
        **header_dict(p),
        "item_count": len(p.items),
        "mass": {k: s["mass"][k] for k in ("known_total", "is_lower_bound", "items_total", "items_with_mass")},
        "finding_count": len(s["findings"]),
        "revision_count": len(p.revisions),
        "latest_revision": {"number": latest.number, "label": latest.label, "created_at": latest.created_at.isoformat()} if latest else None,
        "has_unsaved_changes": _dirty(p),
    }


def config_of(p: Project) -> context.Config:
    return context.from_items(p.airframe, p.layout, _live_items(p), p.design or {})


def detail_dict(p: Project) -> dict:
    items = _live_items(p)
    compat = compatibility.evaluate(context.from_items(p.airframe, p.layout, items, p.design or {}))
    return {
        **header_dict(p),
        "summary": summarise(p.airframe, items),
        "compatibility": {k: compat[k] for k in ("overall", "overall_label", "counts")} if items else None,
        "revisions": [revision_brief(r) for r in p.revisions],
        "has_unsaved_changes": _dirty(p),
    }


# ---------------------------------------------------------------- revisions

def _config_key(items: list[dict]) -> list:
    return sorted((i["component"]["id"], i["quantity"], i.get("role") or "", json.dumps(i["component"]["specs"], sort_keys=True)) for i in items)


def _dirty(p: Project) -> bool:
    """True when the working configuration differs from the latest saved revision."""
    if not p.revisions:
        return bool(p.items)
    snap = p.revisions[0].snapshot
    return (_config_key(_live_items(p)) != _config_key(snap["items"])
            or any(snap["project"].get(k) != getattr(p, k) for k in ("airframe", "layout"))
            or json.dumps(snap.get("design") or {}, sort_keys=True) != json.dumps(p.design or {}, sort_keys=True))


def revision_brief(r: ProjectRevision) -> dict:
    return {
        "id": r.id, "number": r.number, "label": r.label, "note": r.note, "created_at": r.created_at.isoformat(),
        "item_count": len(r.snapshot.get("items", [])),
        "mass": r.snapshot.get("summary", {}).get("mass", {}).get("known_total"),
        "mass_is_lower_bound": r.snapshot.get("summary", {}).get("mass", {}).get("is_lower_bound"),
    }


def create_revision(db: Session, project_id: int, label: str = "", note: str = "") -> ProjectRevision:
    p = get(db, project_id)
    items = _live_items(p)
    if not items:
        raise ValidationError(["the configuration is empty; add components before saving a revision"])
    number = (db.scalar(select(func.max(ProjectRevision.number)).where(ProjectRevision.project_id == p.id)) or 0) + 1
    r = ProjectRevision(
        project_id=p.id, number=number, label=(label or "").strip(), note=(note or "").strip(),
        snapshot={"project": header_dict(p), "items": items, "summary": summarise(p.airframe, items), "design": p.design or {}},
    )
    db.add(r)
    _touch(p)
    db.commit()
    db.refresh(p)
    return r


def get_revision(db: Session, project_id: int, revision_id: int) -> ProjectRevision:
    r = db.get(ProjectRevision, revision_id)
    if r is None or r.project_id != project_id:
        raise NotFound(f"revision {revision_id} not found")
    return r


def revision_dict(r: ProjectRevision) -> dict:
    return {**revision_brief(r), "snapshot": r.snapshot}


def restore_revision(db: Session, project_id: int, revision_id: int) -> dict:
    """Replace the working configuration with a saved revision. Components are
    re-linked to the current library entries; the report lists any that no longer
    exist or whose specifications changed since the revision was saved."""
    p = get(db, project_id)
    r = get_revision(db, project_id, revision_id)
    missing, changed, new_items = [], [], []
    for it in r.snapshot["items"]:
        comp = db.get(Component, it["component"]["id"])
        if comp is None:
            missing.append(it["component"]["name"])
            continue
        if (comp.specs or {}) != it["component"]["specs"]:
            changed.append(display_name(comp))
        new_items.append(ProjectItem(project_id=p.id, component_id=comp.id, quantity=it["quantity"],
                                     role=it.get("role") or "", note=it.get("note") or ""))
    if missing and not new_items:
        raise Conflict("none of the components in this revision exist in the library any more")
    for it in list(p.items):
        db.delete(it)
    db.flush()
    db.add_all(new_items)
    p.layout = r.snapshot["project"].get("layout", p.layout)
    p.design = r.snapshot.get("design") or {}
    _touch(p)
    db.commit()
    db.refresh(p)
    return {"restored": r.number, "missing_components": missing, "changed_components": changed}


def _snapshot_of(db: Session, p: Project, ref: str) -> tuple[str, dict]:
    if ref == "working":
        items = _live_items(p)
        return "Working configuration", {"items": items, "summary": summarise(p.airframe, items)}
    r = get_revision(db, p.id, int(ref))
    return f"Rev {r.number}" + (f" — {r.label}" if r.label else ""), r.snapshot


def diff(db: Session, project_id: int, a: str, b: str) -> dict:
    """Compare two configurations (revision ids or 'working')."""
    p = get(db, project_id)
    try:
        name_a, snap_a = _snapshot_of(db, p, a)
        name_b, snap_b = _snapshot_of(db, p, b)
    except ValueError:
        raise ValidationError(["revision references must be a revision id or 'working'"])

    def index(snap):
        out: dict[int, dict] = {}
        for it in snap["items"]:
            cid = it["component"]["id"]
            if cid in out:
                out[cid] = {**out[cid], "quantity": out[cid]["quantity"] + it["quantity"]}
            else:
                out[cid] = it
        return out

    ia, ib = index(snap_a), index(snap_b)
    changes = []
    for cid in sorted(set(ia) | set(ib), key=lambda c: ((ia.get(c) or ib.get(c))["component"]["category"], c)):
        x, y = ia.get(cid), ib.get(cid)
        ref = (x or y)["component"]
        base = {"component_id": cid, "category": ref["category"], "name": ref["name"]}
        if x and not y:
            changes.append({**base, "change": "removed", "quantity_a": x["quantity"], "quantity_b": None})
        elif y and not x:
            changes.append({**base, "change": "added", "quantity_a": None, "quantity_b": y["quantity"]})
        else:
            spec_changes = [k for k in sorted(set(x["component"]["specs"]) | set(y["component"]["specs"]))
                            if x["component"]["specs"].get(k) != y["component"]["specs"].get(k)]
            if x["quantity"] != y["quantity"] or spec_changes:
                changes.append({**base, "change": "modified", "quantity_a": x["quantity"], "quantity_b": y["quantity"],
                                "spec_fields_changed": spec_changes})
    ma, mb = snap_a["summary"]["mass"], snap_b["summary"]["mass"]
    return {
        "a": {"ref": a, "name": name_a, "mass": ma, "counts": snap_a["summary"]["counts"]},
        "b": {"ref": b, "name": name_b, "mass": mb, "counts": snap_b["summary"]["counts"]},
        "changes": changes,
        "mass_delta": mb["known_total"] - ma["known_total"],
        "mass_delta_reliable": not (ma["is_lower_bound"] or mb["is_lower_bound"]),
    }


def duplicate(db: Session, project_id: int, name: str | None = None) -> Project:
    src = get(db, project_id)
    p = Project(name=(name or "").strip() or f"{src.name} (copy)", code=src.code, description=src.description,
                owner=src.owner, airframe=src.airframe, layout=src.layout, status="concept", design=dict(src.design or {}))
    db.add(p)
    db.flush()
    for it in src.items:
        db.add(ProjectItem(project_id=p.id, component_id=it.component_id, quantity=it.quantity, role=it.role, note=it.note))
    db.commit()
    db.refresh(p)
    return p


# ---------------------------------------------------------------- design overrides (3D assembly, port map)

def _set_design(db: Session, p: Project, design: dict) -> None:
    p.design = design            # reassigned (not mutated) so the JSON column is flagged dirty
    _touch(p)
    db.commit()


def _design_copy(p: Project) -> dict:
    return json.loads(json.dumps(p.design or {}))


def set_wheelbase(db: Session, project_id: int, wheelbase) -> Project:
    p = get(db, project_id)
    design = _design_copy(p)
    asm = design.setdefault("assembly", {})
    if wheelbase in (None, ""):
        asm.pop("wheelbase", None)
    else:
        if isinstance(wheelbase, bool) or not isinstance(wheelbase, (int, float)) or not 0.05 <= wheelbase <= 3.0:
            raise ValidationError(["wheelbase must be between 0.05 m and 3 m"])
        asm["wheelbase"] = float(wheelbase)
    _set_design(db, p, design)
    return p


def set_placement(db: Session, project_id: int, key: str, data: dict | None) -> Project:
    """Move one part in the 3D assembly, or reset it to automatic placement (data=None)."""
    p = get(db, project_id)
    if key not in {part["key"] for part in assembly.build(config_of(p))["parts"]}:
        raise NotFound(f"no part '{key}' in this assembly")
    design = _design_copy(p)
    placements = design.setdefault("assembly", {}).setdefault("placements", {})
    if data is None:
        placements.pop(key, None)
    else:
        placements[key] = assembly.validate_placement(data)
    _set_design(db, p, design)
    return p


def set_port(db: Session, project_id: int, key: str, port: str | None) -> Project:
    """Assign a peripheral to a flight-controller port, or return it to automatic assignment."""
    p = get(db, project_id)
    built = electrical.build(config_of(p))
    if key not in {n["key"] for n in built["nodes"] if n.get("key")}:
        raise NotFound(f"no peripheral '{key}' in this configuration")
    design = _design_copy(p)
    ports = design.setdefault("electrical", {}).setdefault("ports", {})
    if port in (None, ""):
        ports.pop(key, None)
    else:
        if port not in {x["name"] for x in built["port_map"]}:
            raise ValidationError([f"'{port}' is not a port of the selected flight controller"])
        ports[key] = port
    _set_design(db, p, design)
    return p


# ---------------------------------------------------------------- performance and configuration comparison

def performance_of(p: Project) -> dict:
    items = _live_items(p)
    cfg = context.from_items(p.airframe, p.layout, items, p.design or {})
    return performance.evaluate(cfg, summarise(p.airframe, items)["mass"], (p.design or {}).get("performance"))


def set_performance_params(db: Session, project_id: int, params: dict) -> Project:
    p = get(db, project_id)
    design = _design_copy(p)
    merged = {**(design.get("performance") or {}), **(params or {})}
    cleaned = performance.clean_params(merged, strict=True)
    design["performance"] = {k: v for k, v in cleaned.items() if v != performance.PARAMS[k][0]}     # store only non-defaults
    _set_design(db, p, design)
    return p


COMPARE_ROWS = [
    # key, label, quantity, unit, better ("high" | "low" | None)
    ("mass", "Total mass", "mass", None, None),
    ("empty_mass", "Empty weight", "mass", None, None),
    ("thrust", "Total available thrust", "force", None, "high"),
    ("tw", "Thrust-to-weight ratio", None, ":1", "high"),
    ("hover_throttle", "Hover throttle", None, "%", "low"),
    ("hover_current", "Battery current at hover", "current", None, "low"),
    ("full_current", "Battery current at full throttle", "current", None, None),
    ("hover_power", "Hover power", "power", None, "low"),
    ("capacity", "Battery capacity", "charge", None, "high"),
    ("energy", "Battery energy", None, "Wh", "high"),
    ("endurance", "Estimated hover endurance", "time", None, "high"),
    ("range", "Estimated range", "length_km", None, "high"),
    ("efficiency", "Hover power efficiency", None, "g/W", "high"),
    ("payload_capacity", "Payload capacity", "mass", None, "high"),
    ("disk_loading", "Disk loading", None, "N/m²", None),
]
KEY_CATEGORIES = ["frame", "flight_controller", "motor", "esc", "propeller", "battery", "power"]


def _evaluate_snapshot(name: str, ref: dict, airframe: str, layout: str, items: list[dict], design: dict) -> dict:
    cfg = context.from_items(airframe, layout, items, design)
    summary = summarise(airframe, items)
    perf = performance.evaluate(cfg, summary["mass"], (design or {}).get("performance"))
    compat = compatibility.evaluate(cfg)
    m = dict(perf["metrics"])
    if m.get("hover_throttle") is not None:
        m["hover_throttle"] *= 100
    if m.get("energy") is not None:
        m["energy"] /= 3600
    return {
        "ref": ref, "name": name,
        "components": {cat: [f"{i['quantity']} × {i['component']['name']}" if i["quantity"] > 1 else i["component"]["name"]
                             for i in items if i["component"]["category"] == cat] for cat in KEY_CATEGORIES},
        "metrics": m, "mass_is_lower_bound": summary["mass"]["is_lower_bound"],
        "compatibility": {k: compat[k] for k in ("overall", "overall_label", "counts")} if items else None,
        "blockers": perf["blockers"], "params": perf["params"],
        "propulsion_source": perf["propulsion_source"],
    }


def compare_configs(db: Session, refs: list) -> dict:
    """Side-by-side performance and compatibility of any number of configurations.
    Each ref is {"project_id": int, "revision_id": int | None} (None = working configuration)."""
    if not isinstance(refs, list) or len(refs) < 2:
        raise ValidationError(["select at least two configurations to compare"])
    out = []
    for ref in refs:
        if not isinstance(ref, dict) or not isinstance(ref.get("project_id"), int):
            raise ValidationError(["each configuration needs a project_id"])
        p = get(db, ref["project_id"])
        rid = ref.get("revision_id")
        clean = {"project_id": p.id, "revision_id": rid}
        if rid is None:
            out.append(_evaluate_snapshot(f"{p.name} — working", clean, p.airframe, p.layout, _live_items(p), p.design or {}))
        else:
            r = get_revision(db, p.id, rid)
            snap = r.snapshot
            out.append(_evaluate_snapshot(f"{p.name} — Rev {r.number}" + (f" ({r.label})" if r.label else ""), clean,
                                          snap["project"].get("airframe", p.airframe), snap["project"].get("layout", p.layout),
                                          snap["items"], snap.get("design") or {}))
    rows = []
    for key, label, quantity, unit, better in COMPARE_ROWS:
        values = [c["metrics"].get(key) for c in out]
        known = [v for v in values if v is not None]
        best = None
        if better and len(known) >= 2 and max(known) != min(known):
            target = max(known) if better == "high" else min(known)
            best = [i for i, v in enumerate(values) if v is not None and math.isclose(v, target, rel_tol=1e-9)]
        rows.append({"key": key, "label": label, "quantity": quantity, "unit": unit, "better": better, "values": values, "best": best})
    params_differ = len({json.dumps(c["params"], sort_keys=True) for c in out}) > 1
    return {"configs": out, "rows": rows, "categories": KEY_CATEGORIES, "params_differ": params_differ}


def config_choices(db: Session) -> list[dict]:
    """Every configuration that can be compared: each project's working copy and its revisions."""
    out = []
    for p in db.scalars(select(Project).order_by(Project.name)):
        out.append({"project_id": p.id, "revision_id": None, "label": f"{p.name} — working configuration", "items": len(p.items)})
        for r in p.revisions:
            out.append({"project_id": p.id, "revision_id": r.id, "items": len(r.snapshot.get("items", [])),
                        "label": f"{p.name} — Rev {r.number}" + (f" ({r.label})" if r.label else "")})
    return out
