"""Live telemetry: normalised frames, rolling history, recording, replay and export.

A frame is a flat snapshot of the vehicle state built from the most recent MAVLink
messages. A value is included only while its source message is fresh (< STALE s old);
otherwise the field is None. The dashboard therefore never shows an old number as live.

Recording writes two files per session:
  * <id>.jsonl  one frame per line at the sampling rate — used for replay and CSV/JSON export
  * <id>.tlog   every received MAVLink frame with an 8-byte big-endian microsecond timestamp —
                the standard telemetry-log format read by Mission Planner, MAVProxy and pymavlink

Everything recorded is measured data from the link. Whether the source was a physical
vehicle or a simulator is stored with the log (declared by the user, plus any simulator
evidence seen on the link) so simulated and real measurements are never confused later.
"""
from __future__ import annotations

import csv
import io
import json
import math
import struct
import time
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..db import TelemetryLog, utcnow
from .components import Conflict, NotFound, ValidationError

STALE = 3.0               # seconds after which a value is no longer reported
SAMPLE_PERIOD = 0.2       # frame rate for history and recording (5 Hz)
HISTORY = 3000            # frames kept in memory (10 minutes)

MAV_STATE = {0: "uninitialised", 1: "booting", 2: "calibrating", 3: "standby", 4: "active", 5: "CRITICAL", 6: "EMERGENCY", 7: "powering off", 8: "FLIGHT TERMINATION"}
GPS_FIX = {0: "no GPS", 1: "no fix", 2: "2D fix", 3: "3D fix", 4: "DGPS", 5: "RTK float", 6: "RTK fixed", 7: "static", 8: "PPP"}
LANDED = {0: "undefined", 1: "on ground", 2: "in air", 3: "taking off", 4: "landing"}
SENSOR_BITS = [(1, "Gyroscope"), (2, "Accelerometer"), (4, "Magnetometer"), (8, "Barometer"), (32, "GNSS"), (64, "Optical flow"),
               (256, "Laser / rangefinder"), (32768, "Motor outputs"), (65536, "RC receiver"), (2097152, "AHRS"), (16777216, "Logging"),
               (33554432, "Battery"), (268435456, "Pre-arm checks")]

# field -> (label, unit) : the catalogue the dashboard and exports use
FIELDS = {
    "roll": ("Roll", "deg"), "pitch": ("Pitch", "deg"), "yaw": ("Yaw", "deg"), "heading": ("Heading", "deg"),
    "alt_rel": ("Altitude above home", "m"), "alt_msl": ("Altitude MSL", "m"), "ground_speed": ("Ground speed", "m/s"),
    "climb": ("Vertical speed", "m/s"), "lat": ("Latitude", "deg"), "lon": ("Longitude", "deg"),
    "north": ("Local north", "m"), "east": ("Local east", "m"),
    "voltage": ("Battery voltage", "V"), "current": ("Battery current", "A"), "remaining": ("Battery remaining", "%"),
    "consumed": ("Charge consumed", "mAh"), "throttle": ("Throttle", "%"),
    "satellites": ("Satellites", ""), "hdop": ("HDOP", ""), "cpu_load": ("Autopilot load", "%"), "rssi": ("RC RSSI", ""),
    "out1": ("Output 1", "µs"), "out2": ("Output 2", "µs"), "out3": ("Output 3", "µs"), "out4": ("Output 4", "µs"),
    "roll_rate": ("Roll rate", "deg/s"), "pitch_rate": ("Pitch rate", "deg/s"), "yaw_rate": ("Yaw rate", "deg/s"),
}
TEXT_FIELDS = ["mode", "armed", "state", "gps_fix", "landed"]


def _fresh(tm: dict, key: str, now: float) -> dict | None:
    v = tm.get(key)
    return v if v and now - v["t"] < STALE else None


def build_frame(link, now: float | None = None) -> dict:
    """Snapshot of the link's latest data. Caller holds the link lock."""
    now = now or time.time()
    tm = link.tm
    hb = link.heartbeat if link.last_heartbeat and now - link.last_heartbeat < STALE else None
    f: dict = {"t": round(now, 3), "mode": hb["mode"] if hb else None, "armed": hb["armed"] if hb else None,
               "state": MAV_STATE.get(hb["system_status"], str(hb["system_status"])) if hb else None}
    d = lambda r: round(math.degrees(r), 3)          # noqa: E731
    att = _fresh(tm, "attitude", now)
    f.update(roll=d(att["roll"]) if att else None, pitch=d(att["pitch"]) if att else None, yaw=d(att["yaw"]) if att else None,
             roll_rate=d(att["rates"][0]) if att else None, pitch_rate=d(att["rates"][1]) if att else None, yaw_rate=d(att["rates"][2]) if att else None)
    g = _fresh(tm, "global", now)
    f.update(lat=g["lat"] if g else None, lon=g["lon"] if g else None, alt_msl=g["alt"] if g else None, alt_rel=g["relative_alt"] if g else None,
             heading=g["heading"] if g else None)
    loc = _fresh(tm, "local", now)
    f.update(north=round(loc["x"], 3) if loc else None, east=round(loc["y"], 3) if loc else None)
    if f["alt_rel"] is None and loc:
        f["alt_rel"] = round(-loc["z"], 3)
    hud = _fresh(tm, "hud", now)
    f.update(ground_speed=round(hud["groundspeed"], 3) if hud else (round(math.hypot(g["vx"], g["vy"]), 3) if g else None),
             climb=round(hud["climb"], 3) if hud else (round(-g["vz"], 3) if g else None), throttle=hud["throttle"] if hud else None)
    if f["heading"] is None and hud:
        f["heading"] = hud["heading"]
    b = _fresh(tm, "battery", now)
    f.update(voltage=b["voltage"] if b else None, current=b["current"] if b else None, remaining=b["remaining"] if b else None)
    bs = _fresh(tm, "battery_status", now)
    f["consumed"] = bs["consumed"] if bs else None
    gps = _fresh(tm, "gps", now)
    f.update(gps_fix=GPS_FIX.get(gps["fix_type"], str(gps["fix_type"])) if gps else None, satellites=gps["satellites"] if gps else None,
             hdop=gps["eph"] if gps else None)
    s = _fresh(tm, "sensors", now)
    f["cpu_load"] = s["load"] if s else None
    f["sensors"] = ({name: ("not present" if not s["present"] & bit else "disabled" if not s["enabled"] & bit else "ok" if s["health"] & bit else "FAULT")
                     for bit, name in SENSOR_BITS if s["present"] & bit} if s else None)
    o = _fresh(tm, "outputs", now)
    for i in range(4):
        f[f"out{i + 1}"] = o["pwm"][i] if o else None
    rc = _fresh(tm, "rc", now)
    f["rssi"] = rc["rssi"] if rc else None
    ext = _fresh(tm, "extended", now)
    f["landed"] = LANDED.get(ext["landed"], str(ext["landed"])) if ext else None
    return f


def failsafe_summary(frame: dict, texts: list[dict]) -> dict:
    """What the link itself reports about abnormal states — nothing inferred."""
    alerts = []
    if frame.get("state") in ("CRITICAL", "EMERGENCY", "FLIGHT TERMINATION"):
        alerts.append(f"Autopilot system state: {frame['state']}")
    for name, st in (frame.get("sensors") or {}).items():
        if st == "FAULT":
            alerts.append(f"{name}: reported unhealthy")
    recent = [t for t in texts if t["severity"] <= 4 and time.time() - t["t"] < 60]       # MAV_SEVERITY 0-4: emergency…warning
    return {"alerts": alerts, "messages": [{"severity": t["severity"], "text": t["text"], "age": round(time.time() - t["t"], 1)} for t in recent[-8:]]}


# ------------------------------------------------------------------ recorder (owned by the link)

class Recorder:
    def __init__(self, log_id: int, folder: Path):
        self.log_id = log_id
        self.jsonl_path = folder / f"{log_id}.jsonl"
        self.tlog_path = folder / f"{log_id}.tlog"
        self._jsonl = self.jsonl_path.open("w", encoding="utf-8")
        self._tlog = self.tlog_path.open("wb")
        self.frames = 0
        self.messages = 0
        self.started = time.time()

    def frame(self, f: dict) -> None:
        self._jsonl.write(json.dumps(f, separators=(",", ":")) + "\n")
        self.frames += 1

    def raw(self, msg) -> None:
        buf = msg.get_msgbuf()
        if buf:
            self._tlog.write(struct.pack(">Q", int(time.time() * 1e6)) + bytes(buf))
            self.messages += 1

    def close(self) -> None:
        self._jsonl.close()
        self._tlog.close()


# ------------------------------------------------------------------ stored logs

def log_dir() -> Path:
    d = config.data_dir() / "telemetry"
    d.mkdir(parents=True, exist_ok=True)
    return d


def log_brief(r: TelemetryLog) -> dict:
    return {"id": r.id, "project_id": r.project_id, "name": r.name, "source": r.source, "autopilot": r.autopilot, "device": r.device,
            "started_at": r.started_at.isoformat(), "duration": r.duration, "frames": r.frames, "messages": r.messages,
            "recording": r.ended_at is None, "card_id": r.card_id, "note": r.note, "sim_evidence": r.sim_evidence}


def get_log(db: Session, log_id: int) -> TelemetryLog:
    r = db.get(TelemetryLog, log_id)
    if r is None:
        raise NotFound(f"telemetry log {log_id} not found")
    return r


def list_logs(db: Session, project_id: int) -> list[dict]:
    return [log_brief(r) for r in db.scalars(select(TelemetryLog).where(TelemetryLog.project_id == project_id).order_by(TelemetryLog.id.desc()))]


def start_recording(db: Session, link, project_id: int, name: str = "", card_id: int | None = None) -> TelemetryLog:
    st = link.status()
    if not st["open"] or not st["alive"]:
        raise Conflict("no live vehicle link to record — connect to a vehicle first")
    if link.recorder is not None:
        raise Conflict("a recording is already in progress")
    hb = st["heartbeat"]
    source = "simulator" if st["declared_simulator"] or st["sim_evidence"] else "vehicle"
    r = TelemetryLog(project_id=project_id, name=(name or "").strip() or f"Telemetry {utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC",
                     source=source, autopilot=hb["autopilot"], device=st["device"] or "", card_id=card_id,
                     sim_evidence="; ".join(st["sim_evidence"]) + (" (declared by operator)" if st["declared_simulator"] else ""))
    db.add(r)
    db.commit()
    link.start_recorder(Recorder(r.id, log_dir()))
    return r


def stop_recording(db: Session, link) -> TelemetryLog | None:
    rec = link.stop_recorder()
    if rec is None:
        return None
    r = db.get(TelemetryLog, rec.log_id)
    if r is not None:
        r.ended_at = utcnow()
        r.duration = round(time.time() - rec.started, 2)
        r.frames, r.messages = rec.frames, rec.messages
        db.commit()
    return r


def close_orphans(db: Session) -> None:
    """Logs left 'recording' by a crash or restart are closed from what is on disk."""
    for r in db.scalars(select(TelemetryLog).where(TelemetryLog.ended_at.is_(None))):
        frames = read_frames(r)
        r.ended_at = utcnow()
        r.frames = len(frames)
        r.duration = round(frames[-1]["t"] - frames[0]["t"], 2) if len(frames) > 1 else 0.0
        r.note = (r.note + " " if r.note else "") + "Recording was interrupted (application restart)."
    db.commit()


def read_frames(r: TelemetryLog) -> list[dict]:
    path = log_dir() / f"{r.id}.jsonl"
    if not path.is_file():
        return []
    out = []
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    break                                     # a torn final line from an interrupted recording
    return out


def export(r: TelemetryLog, fmt: str) -> tuple[bytes, str, str]:
    """(content, media type, filename)."""
    if fmt == "tlog":
        path = log_dir() / f"{r.id}.tlog"
        if not path.is_file():
            raise NotFound("no raw MAVLink log stored for this recording")
        return path.read_bytes(), "application/octet-stream", f"telemetry-{r.id}.tlog"
    frames = read_frames(r)
    if fmt == "json":
        doc = {"format": "quadlab.telemetry/1", "log": log_brief(r), "fields": {k: {"label": v[0], "unit": v[1]} for k, v in FIELDS.items()}, "frames": frames}
        return json.dumps(doc).encode("utf-8"), "application/json", f"telemetry-{r.id}.json"
    if fmt == "csv":
        cols = ["t", "elapsed", *TEXT_FIELDS, *FIELDS]
        buf = io.StringIO()
        w = csv.writer(buf, lineterminator="\n")
        w.writerow([f"# QuadLab telemetry log {r.id}: {r.name} | source: {r.source} | autopilot: {r.autopilot} | started {r.started_at.isoformat()}"])
        w.writerow(cols)
        t0 = frames[0]["t"] if frames else 0.0
        for f in frames:
            w.writerow([f["t"], round(f["t"] - t0, 3)] + ["" if f.get(c) is None else f.get(c) for c in cols[2:]])
        return buf.getvalue().encode("utf-8"), "text/csv", f"telemetry-{r.id}.csv"
    raise ValidationError(["format must be csv, json or tlog"])


def delete_log(db: Session, link, log_id: int) -> None:
    r = get_log(db, log_id)
    if link.recorder is not None and link.recorder.log_id == r.id:
        raise Conflict("this log is still recording — stop the recording first")
    for ext in ("jsonl", "tlog"):
        (log_dir() / f"{r.id}.{ext}").unlink(missing_ok=True)
    db.delete(r)
    db.commit()


def field_meta() -> dict:
    return {"fields": [{"key": k, "label": v[0], "unit": v[1]} for k, v in FIELDS.items()], "sample_period": SAMPLE_PERIOD, "stale_after": STALE}
