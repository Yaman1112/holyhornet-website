"""3D assembly: parametric geometry, automatic placement, clearances and centre of gravity.

Coordinate system: aircraft body frame, FRD — x forward, y right, z down, origin at
the geometric centre of the frame, metres. (The viewport converts to its own y-up
frame; nothing else does.)

Geometry is built from recorded dimensions only. When a dimension is not on record
the part is drawn at a nominal marker size and flagged `nominal`, and it is excluded
from interference checks — a guessed size must not produce a pass or a fail.
"""
from __future__ import annotations

import math

from .context import Config, Part

# Motor azimuths (degrees clockwise from forward, seen from above) and spin direction.
# Numbering follows the ArduPilot / PX4 quadrotor conventions.
ROTORS = {
    "X": [(45, "CCW"), (-135, "CCW"), (-45, "CW"), (135, "CW")],
    "+": [(90, "CCW"), (-90, "CCW"), (0, "CW"), (180, "CW")],
}
ROTORS["Custom"] = ROTORS["X"]

NOMINAL = {  # marker sizes used only when dimensions are missing (metres)
    "wheelbase": 0.45, "plate": 0.12, "plate_spacing": 0.03, "arm_diameter": 0.016,
    "box": (0.04, 0.03, 0.012), "cylinder": (0.04, 0.03), "disc": 0.25,
}
PROP_GAP = 0.005          # propeller plane above the motor bell
MAST = 0.08               # GNSS mast height above the top plate


def _shape(part: Part) -> tuple[str, list[float], bool]:
    """(shape, size, nominal). box: [length x, width y, height z]; cylinder: [diameter, height]; disc: [diameter]."""
    cat = part.category
    if cat == "propeller":
        d = part.num("diameter")
        return "disc", [d or NOMINAL["disc"]], d is None
    if cat == "motor":
        d, h = part.num("outer_diameter") or part.num("stator_diameter"), part.num("body_length")
        return "cylinder", [d or NOMINAL["cylinder"][0], h or NOMINAL["cylinder"][1]], d is None or h is None
    if cat == "gps":
        d, h = part.num("diameter"), part.num("height")
        return "cylinder", [d or NOMINAL["cylinder"][0], h or NOMINAL["cylinder"][1]], d is None or h is None
    dims = [part.num("length"), part.num("width"), part.num("height")]
    nominal = any(v is None for v in dims)
    return "box", [v or n for v, n in zip(dims, NOMINAL["box"])], nominal


def frame_geometry(cfg: Config) -> dict:
    frame = cfg.one("frame")
    design = cfg.design.get("assembly") or {}
    nominal: list[str] = []

    def pick(spec_key: str, nominal_key: str, label: str) -> float:
        v = frame.num(spec_key) if frame else None
        if v is None:
            nominal.append(label)
            return NOMINAL[nominal_key]
        return v

    override = design.get("wheelbase")
    if override:
        wheelbase, source = float(override), "project override"
    elif frame and frame.num("wheelbase"):
        wheelbase, source = frame.num("wheelbase"), f"{frame.name} specification"
    else:
        wheelbase, source = NOMINAL["wheelbase"], "nominal placeholder — no frame wheelbase on record"
        nominal.append("wheelbase")
    return {
        "name": frame.name if frame else None,
        "wheelbase": wheelbase, "wheelbase_source": source, "wheelbase_override": override or None,
        "layout": cfg.layout,
        "plate": [pick("body_length", "plate", "body plate length"), pick("body_width", "plate", "body plate width")],
        "plate_spacing": pick("plate_spacing", "plate_spacing", "plate spacing"),
        "arm_diameter": pick("arm_tube_diameter", "arm_diameter", "arm tube diameter"),
        "nominal_fields": nominal,
    }


def _expand(cfg: Config) -> list[tuple[str, Part, int]]:
    """One entry per physical unit: (key, part, index-within-category). Keys are
    `<component id>:<n>` so placements survive a revision restore."""
    seen: dict[int, int] = {}
    per_cat: dict[str, int] = {}
    out = []
    for part in cfg.parts:
        if part.category == "frame":
            continue
        for _ in range(part.quantity):
            n = seen.get(part.comp["id"], 0)
            seen[part.comp["id"]] = n + 1
            i = per_cat.get(part.category, 0)
            per_cat[part.category] = i + 1
            out.append((f"{part.comp['id']}:{n}", part, i))
    return out


def build(cfg: Config) -> dict:
    frame = frame_geometry(cfg)
    placements = (cfg.design.get("assembly") or {}).get("placements") or {}
    R = frame["wheelbase"] / 2
    pl, pw = frame["plate"]
    ps, arm_d = frame["plate_spacing"], frame["arm_diameter"]
    top, bottom = -ps / 2, ps / 2
    rotors = ROTORS.get(cfg.layout, ROTORS["X"])
    units = _expand(cfg)
    fc = cfg.one("flight_controller")
    fc_half = ((fc.num("length") if fc else None) or NOMINAL["box"][0]) / 2

    def rotor_xy(i: int) -> tuple[float, float, float]:
        az = rotors[i % len(rotors)][0]
        a = math.radians(az)
        return R * math.cos(a), R * math.sin(a), az

    # Pass 1: motors (other propulsion parts follow the motor of the same rotor, wherever it was moved to).
    motor_pos: dict[int, tuple[float, float, float, float]] = {}       # rotor -> x, y, z_top_of_bell, azimuth
    motor_h: dict[int, float] = {}
    parts: list[dict] = []
    stack_top = top                                                     # running height of the centre stack
    stack_bottom = bottom

    for key, part, i in units:
        shape, size, nominal = _shape(part)
        cat = part.category
        rotor, spin, yaw = None, None, 0.0
        if cat == "motor":
            x, y, az = rotor_xy(i)
            z = -(arm_d / 2 + size[1] / 2)
            rotor, spin = i + 1, rotors[i % len(rotors)][1]
        elif cat in ("propeller", "esc"):
            continue
        elif cat == "flight_controller":
            x, y, z = 0.0, 0.0, stack_top - size[2] / 2
            stack_top -= size[2] + 0.004
        elif cat == "companion":
            x, y, z = 0.0, 0.0, stack_top - 0.01 - size[2] / 2
            stack_top -= size[2] + 0.014
        elif cat == "power":
            x, y, z = 0.0, 0.0, 0.0
        elif cat == "battery":
            x, y, z = 0.0, 0.0, stack_bottom + size[2] / 2
            stack_bottom += size[2] + 0.004
        elif cat == "payload":
            x, y, z = 0.0, 0.0, stack_bottom + 0.006 + size[2] / 2
            stack_bottom += size[2] + 0.01
        elif cat == "gps":
            x, y, z = -pl / 2 + 0.02 + i * 0.07, 0.0, top - MAST - size[1] / 2
        elif cat == "telemetry":                                        # behind the flight controller, long side across
            x, y, z, yaw = -(fc_half + 0.005 + size[1] / 2), 0.004 + size[0] / 2 + i * (size[0] + 0.004), top - size[2] / 2, 90.0
        elif cat == "receiver":
            x, y, z, yaw = -(fc_half + 0.005 + size[1] / 2), -(0.004 + size[0] / 2 + i * (size[0] + 0.004)), top - size[2] / 2, 90.0
        elif cat == "camera":
            x, y, z = pl / 2 + size[0] / 2, i * 0.04, 0.0
        else:                                                           # rangefinders, optical flow, IMU, baro, mag
            x, y, z = (i // 2) * 0.03, (1 if i % 2 == 0 else -1) * (pw / 2 - size[1] / 2), bottom + size[2] / 2
        parts.append(_part(key, part, shape, size, nominal, [x, y, z], yaw, rotor, spin, placements))
        if cat == "motor":
            px, py, pz = parts[-1]["position"]
            motor_pos[i] = (px, py, pz - size[1] / 2, parts[-1]["yaw"] if parts[-1]["auto"] else math.degrees(math.atan2(py, px)))
            motor_h[i] = size[1]

    # Pass 2: propellers and ESCs.
    for key, part, i in units:
        cat = part.category
        if cat not in ("propeller", "esc"):
            continue
        shape, size, nominal = _shape(part)
        if i in motor_pos:
            mx, my, bell_top, _ = motor_pos[i]
        else:
            mx, my, _ = rotor_xy(i)
            bell_top = -(arm_d / 2 + NOMINAL["cylinder"][1])
        az = math.degrees(math.atan2(my, mx))
        if cat == "propeller":
            pos, yaw = [mx, my, bell_top - PROP_GAP], 0.0
        else:
            pos, yaw = [mx * 0.5, my * 0.5, arm_d / 2 + size[2] / 2], az
        parts.append(_part(key, part, shape, size, nominal, pos, yaw, i + 1, rotors[i % len(rotors)][1], placements))

    motors_xy = [(p["position"][0], p["position"][1]) for p in parts if p["category"] == "motor"]
    frame["motor_positions"] = motors_xy or [rotor_xy(i)[:2] for i in range(cfg.rotor_count)]
    result = {"frame": frame, "parts": parts}
    result["clearances"], result["findings"] = _clearances(frame, parts)
    result["cg"] = _centre_of_gravity(cfg, parts)
    result["conventions"] = {
        "axes": "Body frame FRD: x forward, y right, z down; origin at the frame centre.",
        "rotors": "Motor numbering and spin directions follow the ArduPilot / PX4 quadrotor convention for the selected layout. "
                  "Verify against the airframe selected in the autopilot before fitting propellers.",
    }
    return result


def _part(key, part: Part, shape, size, nominal, auto_pos, auto_yaw, rotor, spin, placements) -> dict:
    ov = placements.get(key)
    return {
        "key": key, "item_id": part.item_id, "component_id": part.comp["id"], "name": part.name, "category": part.category,
        "shape": shape, "size": size, "nominal": nominal,
        "position": list(ov["position"]) if ov else auto_pos, "yaw": ov.get("yaw", auto_yaw) if ov else auto_yaw,
        "auto": ov is None, "auto_position": auto_pos, "rotor": rotor, "spin": spin, "mass": part.num("weight"),
    }


def _extent(p: dict) -> tuple[float, float, float]:
    """Half-extents of the yaw-rotated bounding box."""
    if p["shape"] == "box":
        l, w, h = p["size"]
        c, s = abs(math.cos(math.radians(p["yaw"]))), abs(math.sin(math.radians(p["yaw"])))
        return (l * c + w * s) / 2, (l * s + w * c) / 2, h / 2
    if p["shape"] == "cylinder":
        return p["size"][0] / 2, p["size"][0] / 2, p["size"][1] / 2
    return p["size"][0] / 2, p["size"][0] / 2, 0.004


def _clearances(frame: dict, parts: list[dict]) -> tuple[list[dict], list[dict]]:
    clearances, findings = [], []
    props = [p for p in parts if p["category"] == "propeller"]
    for i, a in enumerate(props):
        for b in props[i + 1:]:
            centre = math.dist(a["position"][:2], b["position"][:2])
            gap = centre - (a["size"][0] + b["size"][0]) / 2
            c = {"kind": "propeller tip-to-tip", "a": a["key"], "b": b["key"], "label": f"Rotor {a['rotor']} ↔ rotor {b['rotor']}",
                 "distance": gap, "nominal": a["nominal"] or b["nominal"]}
            clearances.append(c)
            if gap <= 0 and not c["nominal"]:
                findings.append({"level": "interference", "parts": [a["key"], b["key"]],
                                 "message": f"Propeller discs of rotors {a['rotor']} and {b['rotor']} overlap by {-gap * 1000:.1f} mm."})
    clearances.sort(key=lambda c: c["distance"])
    del clearances[4:]                                                   # the four adjacent pairs (smallest gaps)

    solids = [p for p in parts if p["category"] != "propeller"]
    for prop in props:
        if prop["nominal"]:
            continue
        r, pz = prop["size"][0] / 2, prop["position"][2]
        for s in solids:
            if s["nominal"] or (s["category"] == "motor" and s["rotor"] == prop["rotor"]):
                continue
            ex, ey, ez = _extent(s)
            reach = math.dist(prop["position"][:2], s["position"][:2]) - math.hypot(ex, ey)
            if reach < r and abs(s["position"][2] - pz) <= ez + 0.01:
                findings.append({"level": "interference", "parts": [prop["key"], s["key"]],
                                 "message": f"{s['name']} is inside the propeller disc of rotor {prop['rotor']} "
                                            f"({(r - reach) * 1000:.0f} mm inside the tip radius, within 10 mm of the propeller plane)."})
    for i, a in enumerate(solids):
        for b in solids[i + 1:]:
            if a["nominal"] or b["nominal"]:
                continue
            ea, eb = _extent(a), _extent(b)
            overlap = [ea[k] + eb[k] - abs(a["position"][k] - b["position"][k]) for k in range(3)]
            if all(o > 0.0005 for o in overlap):
                findings.append({"level": "interference", "parts": [a["key"], b["key"]],
                                 "message": f"{a['name']} and {b['name']} occupy the same space "
                                            f"(bounding boxes overlap by {min(overlap) * 1000:.1f} mm)."})
    for p in parts:
        if p["nominal"]:
            findings.append({"level": "missing", "parts": [p["key"]],
                             "message": f"{p['name']}: dimensions not on record — drawn as a nominal marker and excluded from clearance checks."})
    if frame["nominal_fields"]:
        findings.append({"level": "missing", "parts": [],
                         "message": "Frame geometry uses nominal placeholders for: " + ", ".join(frame["nominal_fields"]) + "."})
    return clearances, findings


def _centre_of_gravity(cfg: Config, parts: list[dict]) -> dict:
    """r_cg = sum(m_i r_i) / sum(m_i) over parts with a recorded weight. The frame's
    own mass is taken at the origin (its mass distribution is not on record)."""
    frame = cfg.one("frame")
    fm = frame.num("weight") if frame else None
    total = fm or 0.0
    moment = [0.0, 0.0, 0.0]
    excluded = [] if fm is not None or frame is None else [frame.name]
    for p in parts:
        if p["mass"] is None:
            if p["name"] not in excluded:
                excluded.append(p["name"])
            continue
        total += p["mass"]
        for k in range(3):
            moment[k] += p["mass"] * p["position"][k]
    return {
        "position": [m / total for m in moment] if total else None,
        "mass": total, "excluded": excluded,
        "assumptions": ["Each part's mass acts at its geometric centre.", "Frame mass acts at the frame centre.",
                        "Wiring and fasteners are not included."],
    }


def motor_spacing(cfg: Config) -> float | None:
    """Smallest centre distance between two motors, from the current assembly."""
    pts = build(cfg)["frame"]["motor_positions"]
    d = [math.dist(a, b) for i, a in enumerate(pts) for b in pts[i + 1:]]
    return min(d) if d else None


def validate_placement(data: dict) -> dict:
    from .components import ValidationError
    pos = data.get("position")
    if (not isinstance(pos, list) or len(pos) != 3
            or not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and abs(v) <= 5 for v in pos)):
        raise ValidationError(["position must be three finite numbers in metres (|value| ≤ 5 m)"])
    yaw = data.get("yaw", 0.0)
    if isinstance(yaw, bool) or not isinstance(yaw, (int, float)) or not math.isfinite(yaw):
        raise ValidationError(["yaw must be a number in degrees"])
    return {"position": [float(v) for v in pos], "yaw": float(yaw) % 360}
