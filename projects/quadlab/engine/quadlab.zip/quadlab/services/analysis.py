"""Post-flight analysis of a normalised flight dataset.

Each section reports measured quantities and, where a published or commonly used
limit exists, compares against it and says where the limit comes from. A section
whose channels are missing is reported as "not assessable" — it is never filled in.

Limits used
  vibration     ArduPilot documentation: below 30 m/s² normally acceptable, above 30 may have problems,
                above 60 nearly always has problems; clipping should be zero, under 100 is likely fine.
                Applied only to ArduPilot vibration data. PX4's vibration metric has no published limit and is reported without a verdict.
  GNSS          fewer than 6 satellites: PX4's default requirement to use GNSS (EKF2_REQ_NSATS).
                HDOP above 2.0: common guidance, not a firmware limit.
  CPU load      PX4 refuses to arm above 95 % (COM_CPU_MAX); above 80 % is flagged for attention (guidance).
  cell voltage  below 3.3 V per cell under load is flagged (common LiPo guidance; set your own limit from the cell datasheet).
  the rest      motor spread, saturation, tracking error and oscillation thresholds are engineering heuristics, labelled as such.
"""
from __future__ import annotations

import math

import numpy as np

GRID_HZ = 5.0
VIBE_OK, VIBE_BAD = 30.0, 60.0
STATUS_RANK = {"ok": 0, "info": 0, "not_assessable": 1, "attention": 2, "problem": 3}


def _arr(ds: dict, name: str):
    c = ds["channels"].get(name)
    if not c or len(c["t"]) < 2:
        return None, None
    return np.asarray(c["t"], dtype=float), np.asarray(c["v"], dtype=float)


def _on(grid: np.ndarray, t: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Sample-and-hold a channel onto the common grid (NaN before its first sample and after long gaps)."""
    idx = np.searchsorted(t, grid, side="right") - 1
    out = np.where(idx >= 0, v[np.clip(idx, 0, len(v) - 1)], np.nan)
    age = grid - t[np.clip(idx, 0, len(t) - 1)]
    return np.where((idx >= 0) & (age <= 3.0), out, np.nan)


def _metric(label, value, unit="", note=None):
    return {"label": label, "value": None if value is None or (isinstance(value, float) and not math.isfinite(value)) else value, "unit": unit, "note": note}


def _section(key, title, status, metrics=(), findings=(), basis=None):
    return {"key": key, "title": title, "status": status, "metrics": [m for m in metrics if m], "findings": list(findings), "basis": basis}


def _missing(key, title, needs: str):
    return _section(key, title, "not_assessable", findings=[{"level": "not_assessable", "text": f"Not assessable: the log does not contain {needs}."}])


def analyse(ds: dict, cfg: dict | None = None) -> dict:
    """cfg (optional): {"cells": int, "capacity_mah": float, "battery": name} from the project configuration."""
    cfg = cfg or {}
    dur = ds["meta"]["duration"]
    grid = np.arange(0.0, max(dur, 1.0 / GRID_HZ) + 1e-9, 1.0 / GRID_HZ)
    g: dict[str, np.ndarray] = {}
    for name in ds["channels"]:
        t, v = _arr(ds, name)
        if t is not None:
            g[name] = _on(grid, t, v)

    # ---- flight phases
    how = None
    if "landed" in g and np.isfinite(g["landed"]).any():
        in_air = g["landed"] == 0
        how = "the autopilot's landed state"
    elif "alt" in g:
        in_air = np.nan_to_num(g["alt"], nan=0.0) > 0.5
        if "armed" in g:
            in_air &= np.nan_to_num(g["armed"], nan=0.0) > 0.5
        how = "altitude more than 0.5 m above the start" + (" while armed" if "armed" in g else "")
    else:
        in_air = np.zeros(len(grid), dtype=bool)
    air_time = float(in_air.sum()) / GRID_HZ
    hover = in_air.copy()
    if "ground_speed" in g:
        hover &= np.nan_to_num(g["ground_speed"], nan=99.0) < 1.0
    if "climb" in g:
        hover &= np.abs(np.nan_to_num(g["climb"], nan=99.0)) < 0.5
    hover_time = float(hover.sum()) / GRID_HZ
    flew = air_time >= 2.0

    def over(mask, name):
        if name not in g:
            return np.array([])
        x = g[name][mask]
        return x[np.isfinite(x)]

    sections = []

    # ---- summary
    alt_max = float(np.nanmax(g["alt"])) if "alt" in g and np.isfinite(g["alt"]).any() else None
    dist = None
    if "north" in g and "east" in g and flew:
        n_, e_ = g["north"][in_air], g["east"][in_air]
        ok = np.isfinite(n_) & np.isfinite(e_)
        if ok.sum() > 1:
            dist = float(np.hypot(np.diff(n_[ok]), np.diff(e_[ok])).sum())
    spd = over(in_air, "ground_speed")
    summary_findings = []
    if not flew:
        summary_findings.append({"level": "info", "text": "No flight detected in this log (the aircraft stayed on the ground, or airborne state could not be determined). "
                                                          "In-flight sections below are limited to what can be assessed on the ground."})
    sections.append(_section("summary", "Flight summary", "info", [
        _metric("Log duration", dur, "s"), _metric("Time in the air", air_time, "s", f"From {how}." if how else "Could not be determined: no landed state or altitude in the log."),
        _metric("Time in hover", hover_time, "s", "In the air, ground speed < 1 m/s and |vertical speed| < 0.5 m/s."),
        _metric("Maximum altitude above start", alt_max, "m"), _metric("Maximum ground speed", float(spd.max()) if len(spd) else None, "m/s"),
        _metric("Distance flown", dist, "m")], summary_findings))

    # ---- attitude / stability
    if "roll" not in g:
        sections.append(_missing("attitude", "Flight stability and attitude response", "attitude data"))
    elif not flew:
        sections.append(_section("attitude", "Flight stability and attitude response", "not_assessable",
                                 findings=[{"level": "not_assessable", "text": "Not assessable: no flight in this log."}]))
    else:
        metrics, findings, status = [], [], "ok"
        mask = hover if hover_time >= 3 else in_air
        scope = "hover" if hover_time >= 3 else "flight"
        for ax in ("roll", "pitch"):
            x = over(mask, ax)
            if len(x):
                metrics.append(_metric(f"{ax.capitalize()} standard deviation in {scope}", float(np.std(x)), "deg"))
        if "roll_sp" in g:
            for ax in ("roll", "pitch"):
                err = (g[ax] - g[f"{ax}_sp"])[in_air]
                err = err[np.isfinite(err)]
                if len(err):
                    rms, mx = float(np.sqrt(np.mean(err ** 2))), float(np.max(np.abs(err)))
                    metrics.append(_metric(f"{ax.capitalize()} tracking error RMS", rms, "deg", f"Maximum {mx:.1f}°."))
                    if rms > 5:
                        status = "attention"
                        findings.append({"level": "attention", "text": f"{ax.capitalize()} tracking error is {rms:.1f}° RMS. Above about 5° suggests poor tuning, an overloaded or saturated powertrain, or strong disturbance (heuristic threshold)."})
        else:
            findings.append({"level": "info", "text": "No attitude setpoint in the log, so tracking error cannot be computed; only attitude spread is reported."})
        for ax in ("roll_rate", "pitch_rate"):
            osc = _oscillation(ds, ax, in_air, grid)
            if osc:
                metrics.append(_metric(f"Dominant {ax.replace('_', ' ')} oscillation", osc["freq"], "Hz", f"Amplitude {osc['amp']:.1f} deg/s, from a {osc['rate']:.0f} Hz spectrum of in-flight data."))
                if osc["amp"] > 10:
                    status = "attention"
                    findings.append({"level": "attention", "text": f"Sustained {ax.replace('_', ' ')} oscillation at {osc['freq']:.1f} Hz, amplitude {osc['amp']:.0f} deg/s. "
                                                                   "Low frequencies (below ~5 Hz) point to attitude gains; higher ones to rate gains, noise or structural resonance (heuristic)."})
        if not any("oscillation" in m["label"] for m in metrics):
            findings.append({"level": "info", "text": "Angular-rate data is too sparse (below 20 Hz) or absent, so oscillation frequency is not assessed."})
        if not [f for f in findings if f["level"] == "attention"]:
            findings.insert(0, {"level": "ok", "text": "No stability concern found in the available data."})
        sections.append(_section("attitude", "Flight stability and attitude response", status, metrics, findings, "Tracking and oscillation thresholds are engineering heuristics."))

    # ---- vibration
    if "vibe_x" not in g:
        sections.append(_missing("vibration", "Vibration levels", "vibration data (ArduPilot VIBE / VIBRATION, or PX4 vehicle_imu_status)"))
    else:
        axes = [a for a in ("vibe_x", "vibe_y", "vibe_z") if a in g]
        mask = in_air if flew else np.ones(len(grid), dtype=bool)
        metrics, findings, status = [], [], "ok"
        peak = 0.0
        for a in axes:
            x = over(mask, a)
            if len(x):
                label = "Vibration metric" if len(axes) == 1 else f"Vibration {a[-1].upper()}"
                metrics.append(_metric(f"{label} mean / max", float(np.mean(x)), "m/s²", f"Maximum {float(np.max(x)):.1f} m/s²."))
                peak = max(peak, float(np.max(x)))
        src = ds["meta"].get("vibration_source") or ""
        if src.startswith("ArduPilot"):
            if peak > VIBE_BAD:
                status = "problem"
                findings.append({"level": "problem", "text": f"Peak vibration {peak:.0f} m/s² exceeds 60 m/s²: ArduPilot's documentation says this nearly always causes position or altitude hold problems."})
            elif peak > VIBE_OK:
                status = "attention"
                findings.append({"level": "attention", "text": f"Peak vibration {peak:.0f} m/s² is above 30 m/s²: ArduPilot's documentation says this may cause problems."})
            else:
                findings.append({"level": "ok", "text": f"Peak vibration {peak:.1f} m/s² is below 30 m/s², which ArduPilot's documentation describes as normally acceptable."})
        else:
            status = "info"
            findings.append({"level": "info", "text": f"Peak vibration metric {peak:.2f} m/s². This is not ArduPilot's vibration level (it comes from PX4 or an unidentified autopilot); "
                                                      "no published acceptance limit is applied, so no verdict is given. Compare it between flights of the same airframe."})
        if "clip" in g:
            c = g["clip"][np.isfinite(g["clip"])]
            if len(c):
                rise = float(c[-1] - c[0])
                metrics.append(_metric("Accelerometer clipping events during the log", rise, ""))
                if rise >= 100:
                    status = "problem" if status != "problem" else status
                    findings.append({"level": "problem", "text": f"{rise:.0f} accelerometer clipping events. ArduPilot's documentation: ideally zero; a count that keeps rising indicates a serious vibration problem."})
                elif rise > 0:
                    findings.append({"level": "info", "text": f"{rise:.0f} accelerometer clipping events (ArduPilot's documentation: under 100 is likely acceptable, e.g. from a hard landing)."})
        if not flew:
            findings.append({"level": "info", "text": "Measured on the ground: vibration in flight will differ."})
        sections.append(_section("vibration", "Vibration levels", status, metrics, findings, src))

    # ---- motors
    outs = [f"out{i}" for i in range(1, 5) if f"out{i}" in g]
    if len(outs) < 4:
        sections.append(_missing("motors", "Motor performance", "four motor outputs"))
    elif not flew:
        sections.append(_section("motors", "Motor performance", "not_assessable", findings=[{"level": "not_assessable", "text": "Not assessable: no flight in this log."}]))
    else:
        mask = hover if hover_time >= 3 else in_air
        means = [float(np.mean(over(mask, o))) if len(over(mask, o)) else float("nan") for o in outs]
        spread = max(means) - min(means)
        stack = np.vstack([np.nan_to_num(g[o][in_air], nan=0.0) for o in outs])
        sat = float((stack.max(axis=0) >= 0.95).mean())
        metrics = [_metric(f"Output {i + 1} mean in {'hover' if hover_time >= 3 else 'flight'}", means[i] * 100, "%") for i in range(4)]
        metrics += [_metric("Spread between highest and lowest motor", spread * 100, "% of range"), _metric("Time with any motor at or above 95 %", sat * 100, "% of flight")]
        findings, status = [], "ok"
        if spread > 0.10:
            status = "attention"
            hi, lo = means.index(max(means)) + 1, means.index(min(means)) + 1
            findings.append({"level": "attention", "text": f"Motor outputs are uneven: output {hi} averages {max(means) * 100:.0f} % and output {lo} {min(means) * 100:.0f} %. "
                                                           "Check the centre of gravity, a twisted arm or motor mount, a damaged propeller, or a weak motor/ESC (heuristic threshold: 10 % of range)."})
        if sat > 0.01:
            status = "problem" if sat > 0.05 else "attention"
            findings.append({"level": status, "text": f"A motor was at or above 95 % output for {sat * 100:.1f} % of the flight: the powertrain is running out of control margin."})
        if np.mean(means) > 0.7:
            status = "attention" if status == "ok" else status
            findings.append({"level": "attention", "text": f"Average hover output is {np.mean(means) * 100:.0f} %: little thrust margin remains (heuristic: hover above 70 % of range)."})
        if not findings:
            findings.append({"level": "ok", "text": "Motor outputs are balanced with margin to spare."})
        metrics.append(_metric("Average hover output", float(np.mean(means)) * 100, "%"))
        sections.append(_section("motors", "Motor performance", status, metrics, findings, "Outputs normalised to 0–100 % (PWM 1000–2000 µs, or PX4 actuator_motors). Thresholds are engineering heuristics."))

    # ---- battery, current
    hover_power = hover_current = None
    if "voltage" not in g:
        sections.append(_missing("battery", "Battery performance", "battery voltage"))
    else:
        v = g["voltage"][np.isfinite(g["voltage"])]
        cells = cfg.get("cells")
        metrics = [_metric("Voltage at start / minimum / end", float(v[0]), "V", f"Minimum {float(v.min()):.2f} V, end {float(v[-1]):.2f} V.")]
        findings, status = [], "ok"
        if cells and not 3.0 <= float(v[0]) / cells <= 4.4:
            findings.append({"level": "info", "text": f"The log starts at {float(v[0]):.1f} V, which is not a plausible voltage for the project's {cells:g}-cell battery "
                                                      f"({float(v[0]) / cells:.2f} V per cell). The flight used a different pack, so per-cell voltage is not assessed."})
        elif cells:
            vmin_cell = float(v.min()) / cells
            metrics.append(_metric("Minimum voltage per cell", vmin_cell, "V", f"{cells:g} cells in series, from the project's battery."))
            if vmin_cell < 3.3:
                status = "attention"
                findings.append({"level": "attention", "text": f"Pack voltage fell to {vmin_cell:.2f} V per cell under load, below 3.3 V (common LiPo guidance). Land earlier or check the pack's health."})
        else:
            findings.append({"level": "info", "text": "Cell count is not known (no battery in the project), so per-cell voltage is not assessed."})
        step = int(GRID_HZ)
        vg = g["voltage"]
        if len(vg) > step:
            drop = vg[:-step] - vg[step:]
            drop = drop[np.isfinite(drop)]
            if len(drop):
                metrics.append(_metric("Largest voltage drop within 1 s", float(drop.max()), "V"))
        if "current" in g:
            both = np.isfinite(g["voltage"]) & np.isfinite(g["current"])
            i_, v_ = g["current"][both], g["voltage"][both]
            if len(i_) > 20 and float(i_.max() - i_.min()) > 3.0:
                slope, intercept = np.polyfit(i_, v_, 1)
                r2 = float(np.corrcoef(i_, v_)[0, 1] ** 2)
                if slope < 0 and r2 > 0.3:
                    metrics.append(_metric("Apparent pack resistance (voltage sag per ampere)", float(-slope) * 1000, "mΩ",
                                           f"Linear fit of voltage against current, R² = {r2:.2f}. Includes wiring and connectors up to the voltage sensor, and the state-of-charge trend."))
                    findings.append({"level": "info", "text": f"Measured sag suggests about {-slope * 1000:.0f} mΩ between cells and voltage sensor. If the battery has no internal resistance on record, "
                                                              "consider recording this as a measured value so performance estimates include voltage sag."})
        if not [f for f in findings if f["level"] != "info"]:
            findings.insert(0, {"level": "ok", "text": "No battery voltage concern found."})
        sections.append(_section("battery", "Battery performance and voltage drops", status, metrics, findings, "3.3 V per cell under load is common LiPo guidance, not a datasheet limit."))

    if "current" not in g:
        sections.append(_missing("current", "Current consumption", "battery current (the vehicle did not report it)"))
    else:
        mask = in_air if flew else np.ones(len(grid), dtype=bool)
        i_ = over(mask, "current")
        metrics = [_metric("Mean current" + (" in flight" if flew else ""), float(i_.mean()) if len(i_) else None, "A"), _metric("Peak current", float(i_.max()) if len(i_) else None, "A")]
        if "consumed" in g and np.isfinite(g["consumed"]).any():
            c = g["consumed"][np.isfinite(g["consumed"])]
            used = float(c[-1] - c[0])
            metrics.append(_metric("Charge consumed", used, "mAh", "As reported by the autopilot."))
        else:
            ii = np.nan_to_num(g["current"], nan=0.0)
            used = float(ii.sum() / GRID_HZ / 3.6)
            metrics.append(_metric("Charge consumed", used, "mAh", "Integrated from the current channel."))
        if cfg.get("capacity_mah"):
            metrics.append(_metric("Share of rated capacity used", used / cfg["capacity_mah"] * 100, "%", f"{cfg['capacity_mah']:.0f} mAh rated ({cfg.get('battery', 'project battery')})."))
        if "voltage" in g:
            p = g["voltage"] * g["current"]
            ph = p[hover & np.isfinite(p)]
            if len(ph) >= 10:
                hover_power, hover_current = float(ph.mean()), float(over(hover, "current").mean())
                metrics.append(_metric("Measured hover power", hover_power, "W", f"Mean of voltage × current over {hover_time:.0f} s of hover."))
                metrics.append(_metric("Measured hover current", hover_current, "A"))
            e = np.nan_to_num(p, nan=0.0).sum() / GRID_HZ / 3600
            metrics.append(_metric("Energy drawn", float(e), "Wh"))
        sections.append(_section("current", "Current consumption", "info", metrics, [{"level": "info", "text": "Measured values; compare them with the estimate below."}]))

    # ---- GNSS
    if "sats" not in g and "hdop" not in g:
        sections.append(_missing("gnss", "GNSS quality", "GNSS status"))
    else:
        metrics, findings, status = [], [], "ok"
        mask = in_air if flew else np.ones(len(grid), dtype=bool)
        s = over(mask, "sats")
        if len(s):
            metrics.append(_metric("Satellites minimum / mean", float(s.min()), "", f"Mean {float(s.mean()):.1f}."))
            if s.min() < 6:
                status = "attention"
                findings.append({"level": "attention", "text": f"Satellite count dropped to {s.min():.0f}. PX4 requires 6 by default to use GNSS (EKF2_REQ_NSATS)."})
        h = over(mask, "hdop")
        if len(h):
            metrics.append(_metric("HDOP maximum", float(h.max()), "", f"Mean {float(h.mean()):.2f}."))
            if h.max() > 2.0:
                status = "attention"
                findings.append({"level": "attention", "text": f"HDOP reached {h.max():.1f}; above 2.0 the horizontal position solution is weak (common guidance, not a firmware limit)."})
        f_ = over(mask, "fix")
        if len(f_):
            lost = float((f_ < 3).mean())
            metrics.append(_metric("Time without a 3D fix", lost * 100, "%"))
            if lost > 0 and flew:
                status = "problem"
                findings.append({"level": "problem", "text": f"3D fix was lost for {lost * 100:.1f} % of the flight."})
        if not findings:
            findings.append({"level": "ok", "text": "GNSS quality was adequate throughout."})
        sections.append(_section("gnss", "GNSS quality", status, metrics, findings))

    # ---- position accuracy
    if "north_sp" in g and "north" in g and flew:
        err = np.hypot(g["north"] - g["north_sp"], g["east"] - g["east_sp"])[hover]
        err = err[np.isfinite(err)]
        if len(err) >= 10:
            rms = float(np.sqrt(np.mean(err ** 2)))
            st = "attention" if rms > 2.0 else "ok"
            sections.append(_section("position", "Position accuracy", st, [_metric("Horizontal error against setpoint in hover, RMS", rms, "m", f"Maximum {float(err.max()):.2f} m.")],
                                     [{"level": st, "text": ("Position hold error is large: check GNSS quality, compass interference and vibration." if st == "attention" else "Position was held close to the setpoint.") + " This is the controller's error against its own position estimate, not absolute accuracy."}],
                                     "2 m RMS threshold is an engineering heuristic."))
        else:
            sections.append(_section("position", "Position accuracy", "not_assessable", findings=[{"level": "not_assessable", "text": "Not assessable: too little hover time with a position setpoint."}]))
    else:
        sections.append(_missing("position", "Position accuracy", "a position setpoint to compare against (or no flight was detected)"))

    # ---- flight controller
    if "load" in g:
        ld = g["load"][np.isfinite(g["load"])]
        st = "problem" if ld.max() > 95 else "attention" if ld.max() > 80 else "ok"
        sections.append(_section("fc", "Flight-controller performance", st, [_metric("Processor load mean / max", float(ld.mean()), "%", f"Maximum {float(ld.max()):.0f} %.")],
                                 [{"level": st, "text": "Processor load is high." if st != "ok" else "Processor load has ample margin."}],
                                 "PX4 refuses to arm above 95 % (COM_CPU_MAX); 80 % is a guidance threshold."))
    else:
        sections.append(_missing("fc", "Flight-controller performance", "processor load"))

    # ---- events
    msgs = [e for e in ds["events"] if e["kind"] in ("message", "failsafe") and (e.get("severity") is None or e["severity"] <= 4)]
    failsafes = [e for e in ds["events"] if e["kind"] == "failsafe" or "failsafe" in e["text"].lower()]
    critical = [e for e in msgs if e.get("severity") is not None and e["severity"] <= 3]
    st = "problem" if failsafes else "attention" if critical else "ok"
    findings = [{"level": "problem", "text": f"{len(failsafes)} failsafe event(s) recorded — see the event list."}] if failsafes else []
    if critical and not failsafes:
        findings.append({"level": "attention", "text": f"{len(critical)} error-level message(s) from the autopilot — see the event list."})
    if not findings:
        findings.append({"level": "ok", "text": "No failsafe or error-level message in the log."})
    sections.append(_section("events", "Failsafe events and warnings", st, [_metric("Warnings and errors logged", len(msgs)), _metric("Failsafe events", len(failsafes)),
                                                                             _metric("Mode changes", sum(e["kind"] == "mode" for e in ds["events"]))], findings))

    # ---- data quality / sensor anomalies
    gaps, findings = [], []
    t_att, _ = _arr(ds, "roll")
    if t_att is not None:
        dt = np.diff(t_att)
        gaps = [(float(t_att[i]), float(dt[i])) for i in np.where(dt > 2.0)[0]]
    st = "attention" if gaps else "ok"
    if gaps:
        findings.append({"level": "attention", "text": f"{len(gaps)} gap(s) longer than 2 s in the attitude stream (longest {max(g_[1] for g_ in gaps):.1f} s at t = {max(gaps, key=lambda x: x[1])[0]:.0f} s): telemetry dropouts or a logging problem."})
    absent = [k for k in ("roll", "alt", "voltage", "current", "sats", "vibe_x", "out1") if k not in g]
    if absent:
        findings.append({"level": "info", "text": "Not in this log: " + ", ".join({"roll": "attitude", "alt": "altitude", "voltage": "battery voltage", "current": "battery current", "sats": "GNSS status",
                                                                               "vibe_x": "vibration", "out1": "motor outputs"}[k] for k in absent) + "."})
    for note in ds["meta"].get("notes", []):
        findings.append({"level": "info", "text": note})
    if not findings:
        findings.append({"level": "ok", "text": "All analysed data streams are continuous."})
    sections.append(_section("data", "Sensor anomalies and data quality", st, [_metric("Channels in the log", len(ds["channels"]))], findings))

    overall = max((s["status"] for s in sections), key=lambda st: STATUS_RANK[st])
    return {"overall": overall if overall in ("attention", "problem") else "ok", "flew": bool(flew), "sections": sections,
            "measured": {"hover_power": hover_power, "hover_current": hover_current, "air_time": air_time, "hover_time": hover_time,
                         "max_altitude": alt_max, "duration": dur}}


def _oscillation(ds: dict, name: str, in_air: np.ndarray, grid: np.ndarray) -> dict | None:
    """Dominant 2-25 Hz component of an angular-rate channel during flight."""
    t, v = _arr(ds, name)
    if t is None or not in_air.any():
        return None
    t0, t1 = grid[in_air][0], grid[in_air][-1]
    sel = (t >= t0) & (t <= t1)
    t, v = t[sel], v[sel]
    if len(t) < 128:
        return None
    rate = (len(t) - 1) / (t[-1] - t[0])
    if rate < 20:
        return None
    fs = min(rate, 100.0)
    tu = np.arange(t[0], t[-1], 1.0 / fs)
    x = np.interp(tu, t, v)
    x = x - x.mean()
    win = np.hanning(len(x))
    spec = np.abs(np.fft.rfft(x * win)) * 2.0 / win.sum()
    freqs = np.fft.rfftfreq(len(x), 1.0 / fs)
    band = (freqs >= 2.0) & (freqs <= min(25.0, fs / 2.5))
    if not band.any():
        return None
    k = int(np.argmax(np.where(band, spec, 0.0)))
    return {"freq": float(freqs[k]), "amp": float(spec[k]), "rate": float(fs)}


def compare(measured: dict, estimate: dict | None, sim: dict | None, params: dict | None = None) -> dict:
    """Measured hover figures against the Phase 3 estimate and (optionally) a simulator run."""
    rows, suggestions = [], []
    est_p = (estimate or {}).get("hover_power")
    est_i = (estimate or {}).get("hover_current")
    sim_p = (sim or {}).get("hover_power")
    act_p, act_i = measured.get("hover_power"), measured.get("hover_current")

    def pct(a, b):
        return None if a is None or b in (None, 0) else (a / b - 1) * 100

    rows.append({"label": "Hover power", "unit": "W", "estimate": est_p, "simulated": sim_p, "actual": act_p, "delta_pct": pct(act_p, est_p)})
    rows.append({"label": "Hover current", "unit": "A", "estimate": est_i, "simulated": (sim or {}).get("hover_current"), "actual": act_i, "delta_pct": pct(act_i, est_i)})
    cap, frac = (estimate or {}).get("capacity"), (params or {}).get("usable_fraction")
    proj = None
    if act_i and cap and frac:
        proj = cap * frac / act_i                             # capacity in A*s
    rows.append({"label": "Hover endurance", "unit": "s", "estimate": (estimate or {}).get("endurance"), "simulated": None, "actual": proj,
                 "delta_pct": pct(proj, (estimate or {}).get("endurance")),
                 "note": "Actual: projected from measured hover current and the same usable battery fraction." if proj else None})
    if act_p is None:
        suggestions.append("The log has no measured hover power (needs battery voltage and current, and at least a few seconds of hover), so the estimate cannot be checked against this flight.")
    elif est_p is None:
        suggestions.append("There is no performance estimate for this configuration (no bench test for the selected motor and propeller), so there is nothing to compare the measurement with.")
    else:
        d = pct(act_p, est_p)
        if abs(d) <= 15:
            suggestions.append(f"Measured hover power is within {abs(d):.0f} % of the estimate: the bench data and recorded mass describe this aircraft reasonably well.")
        elif d > 15:
            suggestions.append(f"Measured hover power is {d:.0f} % above the estimate. Areas to investigate:")
            suggestions += ["Mass: weigh the flight-ready aircraft. The roll-up excludes wiring, fasteners and any item without a recorded weight.",
                            "Bench data: manufacturer thrust tables are static, single-motor, and often optimistic. Measure this motor and propeller on a thrust stand.",
                            "Installed losses: arm and airframe blockage, propeller overlap or tight tip clearance reduce installed thrust.",
                            "Voltage: a sagging pack draws more current for the same power; record the pack's internal resistance.",
                            "Conditions: wind and manoeuvring raise power above still-air hover; check the wind during the hover segment.",
                            "Unrecorded loads: the flight controller, companion computer and payload draw power not included in the estimate."]
        else:
            suggestions.append(f"Measured hover power is {abs(d):.0f} % below the estimate. Areas to investigate:")
            suggestions += ["Current sensor calibration: an uncalibrated power module commonly under- or over-reads. Verify it against a calibrated meter.",
                            "Mass: the flown aircraft may be lighter than the recorded configuration (payload or battery not fitted).",
                            "Ground effect: hover within about one rotor diameter of the ground needs less power.",
                            "Hover detection: check that the hover segment really was steady flight."]
    if sim_p is not None and est_p is not None and abs(pct(sim_p, est_p)) > 3:
        suggestions.append("The simulator's hover power differs from the estimate because its run used different conditions (wind, payload or air density).")
    return {"rows": rows, "suggestions": suggestions,
            "basis": "Estimate: Performance Analysis (bench data). Simulated: QuadLab internal simulator. Actual: measured in this log. The three are stored and labelled separately."}
