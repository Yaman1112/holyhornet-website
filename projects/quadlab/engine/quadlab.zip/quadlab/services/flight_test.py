"""Flight-test management: campaigns, test cards, progressive stages and the safety gate.

The application never arms, launches or commands an aircraft. The safety gate does one
thing: it records that a named operator confirmed the safety conditions before a test
that involves spinning motors, and it refuses to let such a card be started without
that record. The operator flies the aircraft; QuadLab keeps the test honest.

Rules enforced here
  * a campaign is bound to a saved project revision — the configuration under test is pinned
  * stages are progressive: a card can start only when every earlier stage has a passed
    card, or a recorded waiver with a reason
  * stages that energise motors need a safety-gate authorisation: every checklist item
    confirmed, a named operator, and the stage's confirmation phrase typed exactly
  * flight stages are refused while the configuration has open "incompatible" findings,
    unless the operator records a written justification
  * an authorisation expires after 30 minutes and is consumed when the card is started
  * a card passes only if actual results are recorded and every pass criterion is marked met
  * completed cards are read-only; reopening one needs a reason and is logged
"""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import ProjectRevision, TelemetryLog, TestCampaign, TestCard, utcnow
from . import compatibility, context
from . import projects as psvc
from .components import Conflict, NotFound, ValidationError

GATE_VALID_MINUTES = 30
VERDICTS = ("pass", "fail", "inconclusive")
TEXT_FIELDS = ["title", "objectives", "preconditions", "environment", "weather", "expected_results", "actual_results", "observations",
               "hardware_revision", "firmware_version"]

STAGES = [
    {"n": 1, "name": "Component inspection", "motors": False, "flight": False, "phrase": None,
     "objectives": "Confirm every component is the one in the configuration, undamaged and correctly assembled.",
     "checklist": ["Part numbers match the configuration revision", "Frame, arms and landing gear free of cracks and delamination",
                   "Motor bells spin freely with no bearing noise or shaft play", "Connectors and solder joints inspected; no exposed conductors",
                   "Battery free of swelling, damage and leaking; balance lead intact", "All fasteners present, torqued and thread-locked where required"],
     "criteria": ["All components match the pinned configuration", "No damage or assembly defect found"]},
    {"n": 2, "name": "Electrical continuity and power checks", "motors": False, "flight": False, "phrase": None,
     "objectives": "Verify wiring against the electrical architecture before and after first power-up, with propellers removed.",
     "checklist": ["Propellers removed", "No short between battery positive and negative measured at the main connector",
                   "Polarity verified at the power module and every ESC", "First power-up through a current-limited supply or smoke stopper",
                   "Regulated rail voltage measured at the flight controller", "No component heating at idle after 5 minutes"],
     "criteria": ["No short circuit and correct polarity throughout", "Regulated rail within the flight controller's input range", "Idle current as expected and stable"]},
    {"n": 3, "name": "Sensor verification", "motors": False, "flight": False, "phrase": None,
     "objectives": "Confirm every sensor is detected, calibrated and reporting plausible values.",
     "checklist": ["Propellers removed", "Accelerometer, gyroscope and compass calibrated", "Attitude display follows the aircraft when moved by hand",
                   "Barometric altitude stable on the bench", "GNSS reaches a 3D fix outdoors with adequate satellites", "Rangefinder and other sensors read plausible values"],
     "criteria": ["All sensors report healthy on the ground station", "Attitude and heading agree with the physical orientation", "GNSS position plausible"]},
    {"n": 4, "name": "Flight-controller configuration verification", "motors": False, "flight": False, "phrase": None,
     "objectives": "Verify the parameters on the vehicle against the reviewed parameter set, including failsafes.",
     "checklist": ["Propellers removed", "Vehicle parameters read and compared with the reviewed parameter set", "Frame type and motor order match the airframe",
                   "RC calibrated; flight-mode switch selects the intended modes", "RC-loss, battery and data-link failsafe actions verified",
                   "Battery monitor voltage agrees with a multimeter"],
     "criteria": ["No unexplained difference between vehicle and reviewed parameters", "Failsafe actions behave as configured", "Battery voltage reading within tolerance"]},
    {"n": 5, "name": "Motor direction and output checks", "motors": True, "flight": False, "phrase": "PROPELLERS REMOVED",
     "objectives": "Confirm each motor is on the correct output and turns in the correct direction. Propellers stay off.",
     "checklist": ["ALL PROPELLERS REMOVED — verified by a second look", "Aircraft secured so it cannot move", "Loose items, cables and clothing clear of the motors",
                   "Motor test performed one motor at a time at low throttle", "Each motor matches its output number and position",
                   "Each motor spins in the direction required by the airframe diagram"],
     "criteria": ["Every motor responds on its assigned output", "Every motor spins in the correct direction", "No abnormal vibration, noise or heating"]},
    {"n": 6, "name": "Propeller installation inspection", "motors": False, "flight": False, "phrase": None,
     "objectives": "Fit propellers and verify type, orientation and security. Battery disconnected throughout.",
     "checklist": ["Battery disconnected", "Correct CW / CCW propeller on each motor", "Propellers seated and fasteners torqued", "Blades free of nicks, cracks and imbalance",
                   "Propeller tip clearance to the frame and to other propellers checked by hand rotation"],
     "criteria": ["Each propeller matches its motor's rotation", "All propellers secure", "Clearances adequate through a full rotation"]},
    {"n": 7, "name": "Bench testing with restraints", "motors": True, "flight": False, "phrase": "AIRCRAFT RESTRAINED",
     "objectives": "Run the powertrain with propellers fitted while the aircraft is physically restrained; check vibration, temperatures and currents.",
     "checklist": ["Aircraft restrained by a fixture rated for more than its maximum thrust", "Test area clear; everyone behind a barrier or at a safe distance",
                   "Eye protection worn", "A means of cutting power immediately is in hand", "Fire extinguisher suitable for LiPo fires within reach",
                   "Throttle raised gradually; run stopped at the first abnormal sign"],
     "criteria": ["No structural resonance or abnormal vibration", "Motor and ESC temperatures within limits after the run", "Measured current consistent with the performance estimate"]},
    {"n": 8, "name": "Controlled low-risk flight evaluation", "motors": True, "flight": True, "phrase": "AREA CLEAR",
     "objectives": "First hover at low altitude in a controlled area: basic stability and control response.",
     "checklist": ["Flight is permitted at this location and airspace; required authorisations held", "Weather within limits: wind, precipitation, visibility",
                   "Flight area clear of people, animals and obstacles; spectators briefed and behind the pilot", "Battery fully charged and secured; CG checked",
                   "Failsafes and return behaviour briefed; abort criteria agreed", "Pilot ready to take manual control; observer assigned",
                   "Pre-arm checks passed on the ground station; GNSS fix adequate"],
     "criteria": ["Stable hover without oscillation", "Control response correct in all axes", "No failsafe, warning or abnormal behaviour", "Normal landing"]},
    {"n": 9, "name": "Flight performance evaluation", "motors": True, "flight": True, "phrase": "AREA CLEAR",
     "objectives": "Measure hover power, endurance, speed and handling against the performance estimate.",
     "checklist": ["Flight is permitted at this location and airspace; required authorisations held", "Weather within limits and recorded",
                   "Flight area clear; observer assigned", "Battery fully charged and secured; payload secured", "Telemetry recording started",
                   "Landing reserve defined and the flight ends at it", "Abort criteria agreed"],
     "criteria": ["Planned test points flown", "Telemetry recorded for the whole flight", "Battery landed at or above the planned reserve", "No failsafe or abnormal behaviour"]},
    {"n": 10, "name": "Post-flight inspection", "motors": False, "flight": False, "phrase": None,
     "objectives": "Inspect the aircraft after flight and record findings and log references.",
     "checklist": ["Battery disconnected; temperature and voltage recorded", "Motors, ESCs and battery checked for excessive heat", "Propellers and fasteners inspected",
                   "Frame and landing gear inspected", "Flight log downloaded and linked to this card"],
     "criteria": ["No damage or loosening found", "Component temperatures normal", "Logs archived"]},
]
STAGE = {s["n"]: s for s in STAGES}


def _now() -> str:
    return utcnow().isoformat()


def _event(card: TestCard, action: str, by: str = "", detail: str = "") -> None:
    card.events = [*(card.events or []), {"at": _now(), "action": action, "by": by, "detail": detail}]
    card.updated_at = utcnow()


# ------------------------------------------------------------------ campaigns

def get_campaign(db: Session, campaign_id: int) -> TestCampaign:
    c = db.get(TestCampaign, campaign_id)
    if c is None:
        raise NotFound(f"test campaign {campaign_id} not found")
    return c


def get_card(db: Session, card_id: int) -> TestCard:
    c = db.get(TestCard, card_id)
    if c is None:
        raise NotFound(f"test card {card_id} not found")
    return c


def stage_status(c: TestCampaign) -> list[dict]:
    """Per stage: cards, whether it is satisfied (passed or waived) and whether it may be started."""
    waived = {w["stage"]: w for w in c.waivers or []}
    out, earlier_ok = [], True
    for s in STAGES:
        cards = [k for k in c.cards if k.stage == s["n"]]
        passed = any(k.verdict == "pass" and k.status == "done" for k in cards)
        failed = any(k.verdict == "fail" and k.status == "done" for k in cards) and not passed
        satisfied = passed or s["n"] in waived
        out.append({"n": s["n"], "name": s["name"], "motors": s["motors"], "flight": s["flight"], "cards": len(cards), "passed": passed,
                    "failed": failed, "waiver": waived.get(s["n"]), "satisfied": satisfied, "unlocked": earlier_ok})
        earlier_ok = earlier_ok and satisfied
    return out


def campaign_brief(c: TestCampaign) -> dict:
    st = stage_status(c)
    return {"id": c.id, "project_id": c.project_id, "revision_id": c.revision_id, "name": c.name, "objective": c.objective,
            "hardware_revision": c.hardware_revision, "firmware_version": c.firmware_version, "created_at": c.created_at.isoformat(),
            "cards": len(c.cards), "stages_satisfied": sum(s["satisfied"] for s in st), "current_stage": next((s["n"] for s in st if not s["satisfied"]), None)}


def campaign_detail(db: Session, c: TestCampaign) -> dict:
    rev = db.get(ProjectRevision, c.revision_id)
    return {**campaign_brief(c), "waivers": c.waivers or [], "stages": stage_status(c), "cards": [card_brief(k) for k in c.cards],
            "revision": {"id": rev.id, "number": rev.number, "label": rev.label, "created_at": rev.created_at.isoformat(),
                         "items": [f"{i['quantity']} × {i['component']['name']}" for i in rev.snapshot["items"]]} if rev else None}


def list_campaigns(db: Session, project_id: int) -> list[dict]:
    return [campaign_brief(c) for c in db.scalars(select(TestCampaign).where(TestCampaign.project_id == project_id).order_by(TestCampaign.id.desc()))]


def create_campaign(db: Session, project_id: int, data: dict) -> TestCampaign:
    p = psvc.get(db, project_id)
    name = (data.get("name") or "").strip()
    errors = []
    if not name:
        errors.append("campaign name is required")
    rev = db.get(ProjectRevision, data.get("revision_id") or 0)
    if rev is None or rev.project_id != p.id:
        errors.append("choose a saved revision of this project: a campaign tests one pinned configuration")
    if errors:
        raise ValidationError(errors)
    c = TestCampaign(project_id=p.id, revision_id=rev.id, name=name, objective=(data.get("objective") or "").strip(),
                     hardware_revision=(data.get("hardware_revision") or "").strip(), firmware_version=(data.get("firmware_version") or "").strip(), waivers=[])
    db.add(c)
    db.commit()
    return c


def delete_campaign(db: Session, campaign_id: int) -> None:
    db.delete(get_campaign(db, campaign_id))
    db.commit()


def waive_stage(db: Session, campaign_id: int, data: dict) -> TestCampaign:
    c = get_campaign(db, campaign_id)
    stage, reason, by = data.get("stage"), (data.get("reason") or "").strip(), (data.get("by") or "").strip()
    errors = []
    if stage not in STAGE:
        errors.append("stage must be 1 to 10")
    elif STAGE[stage]["motors"]:
        errors.append(f"stage {stage} ({STAGE[stage]['name']}) energises motors and cannot be waived")
    if len(reason) < 15:
        errors.append("a waiver needs a reason of at least 15 characters")
    if not by:
        errors.append("the name of the person granting the waiver is required")
    if errors:
        raise ValidationError(errors)
    c.waivers = [w for w in (c.waivers or []) if w["stage"] != stage] + [{"stage": stage, "reason": reason, "by": by, "at": _now()}]
    db.commit()
    return c


# ------------------------------------------------------------------ cards

def card_brief(k: TestCard) -> dict:
    return {"id": k.id, "campaign_id": k.campaign_id, "code": k.code, "stage": k.stage, "stage_name": STAGE[k.stage]["name"], "status": k.status,
            "verdict": k.verdict, "title": k.data.get("title", ""), "updated_at": k.updated_at.isoformat(), "telemetry_log_id": k.telemetry_log_id}


def gate_state(k: TestCard) -> dict:
    s = STAGE[k.stage]
    g = k.gate
    valid = False
    if g and not g.get("consumed"):
        from datetime import datetime
        valid = utcnow() - datetime.fromisoformat(g["at"]) <= timedelta(minutes=GATE_VALID_MINUTES)
    return {"required": s["motors"], "phrase": s["phrase"], "authorised": valid, "record": g, "valid_minutes": GATE_VALID_MINUTES}


def card_detail(k: TestCard) -> dict:
    stages = {s["n"]: s for s in stage_status(k.campaign)}
    return {**card_brief(k), "data": k.data, "events": k.events or [], "gate": gate_state(k), "stage_info": STAGE[k.stage],
            "unlocked": stages[k.stage]["unlocked"], "blocking_stages": [s["n"] for s in stage_status(k.campaign) if s["n"] < k.stage and not s["satisfied"]],
            "campaign": {"id": k.campaign.id, "name": k.campaign.name, "revision_id": k.campaign.revision_id}}


def create_card(db: Session, campaign_id: int, data: dict) -> TestCard:
    c = get_campaign(db, campaign_id)
    stage = data.get("stage")
    if stage not in STAGE:
        raise ValidationError(["stage must be 1 to 10"])
    s = STAGE[stage]
    n = sum(1 for k in c.cards if k.stage == stage) + 1
    k = TestCard(campaign_id=c.id, stage=stage, code=f"C{c.id}-S{stage:02d}-{n:02d}", status="planned", events=[], data={
        "title": (data.get("title") or "").strip() or s["name"], "objectives": s["objectives"], "preconditions": "", "environment": "", "weather": "",
        "expected_results": "", "actual_results": "", "observations": "",
        "hardware_revision": c.hardware_revision, "firmware_version": c.firmware_version,
        "checklist": [{"text": t, "checked": False} for t in s["checklist"]],
        "criteria": [{"text": t, "met": None} for t in s["criteria"]],
    })
    db.add(k)
    db.flush()
    _event(k, "created", detail=f"Stage {stage}: {s['name']} — from the stage template")
    db.commit()
    return k


def update_card(db: Session, card_id: int, data: dict) -> TestCard:
    k = get_card(db, card_id)
    if k.status == "done":
        raise Conflict("this card is completed and read-only; reopen it (with a reason) to change it")
    d = dict(k.data)
    errors = []
    for f in TEXT_FIELDS:
        if f in data:
            if not isinstance(data[f], str):
                errors.append(f"{f} must be text")
            else:
                d[f] = data[f].strip()
    if "checklist" in data:
        items = data["checklist"]
        if not isinstance(items, list) or not all(isinstance(i, dict) and isinstance(i.get("text"), str) and i["text"].strip() and isinstance(i.get("checked"), bool) for i in items):
            errors.append("checklist items need text and a checked flag")
        else:
            required = {t for t in STAGE[k.stage]["checklist"]}
            if not required <= {i["text"].strip() for i in items}:
                errors.append("the stage's standard safety checklist items cannot be removed (add your own alongside them)")
            if k.status in ("authorised", "in_progress") and [i["checked"] for i in items] != [i["checked"] for i in d["checklist"]][:len(items)]:
                errors.append("the safety checklist is frozen once the card is authorised or in progress")
            d["checklist"] = [{"text": i["text"].strip(), "checked": i["checked"]} for i in items]
    if "criteria" in data:
        items = data["criteria"]
        if not isinstance(items, list) or not items or not all(isinstance(i, dict) and isinstance(i.get("text"), str) and i["text"].strip() and i.get("met") in (True, False, None) for i in items):
            errors.append("pass/fail criteria need text and met = true, false or null; at least one criterion is required")
        else:
            d["criteria"] = [{"text": i["text"].strip(), "met": i["met"]} for i in items]
    if not d.get("title"):
        errors.append("title is required")
    if errors:
        raise ValidationError(errors)
    k.data = d
    k.updated_at = utcnow()
    db.commit()
    return k


def delete_card(db: Session, card_id: int) -> None:
    k = get_card(db, card_id)
    if k.status in ("in_progress", "done"):
        raise Conflict("a started or completed test card is part of the record and cannot be deleted")
    db.delete(k)
    db.commit()


def _open_incompatibilities(db: Session, k: TestCard) -> list[str]:
    rev = db.get(ProjectRevision, k.campaign.revision_id)
    if rev is None:
        return ["the pinned configuration revision no longer exists"]
    snap = rev.snapshot
    cfg = context.from_items(snap["project"].get("airframe", "quadcopter"), snap["project"].get("layout", "X"), snap["items"], snap.get("design") or {})
    return [f"{c['title']}: {c['explanation']}" for c in compatibility.evaluate(cfg)["checks"] if c["status"] == "incompatible"]


def authorise(db: Session, card_id: int, data: dict, link_status: dict | None = None) -> TestCard:
    """The safety gate. Records an operator's confirmation; does not act on the aircraft."""
    k = get_card(db, card_id)
    s = STAGE[k.stage]
    if not s["motors"]:
        raise ValidationError(["this stage does not energise motors and needs no safety-gate authorisation"])
    if k.status != "planned":
        raise Conflict(f"the card is {k.status.replace('_', ' ')}; only a planned card can be authorised")
    errors = []
    blocking = [x["n"] for x in stage_status(k.campaign) if x["n"] < k.stage and not x["satisfied"]]
    if blocking:
        errors.append("earlier stages are not passed or waived: " + ", ".join(f"{n} ({STAGE[n]['name']})" for n in blocking))
    operator = (data.get("operator") or "").strip()
    if len(operator) < 2:
        errors.append("the operator's name is required")
    unchecked = [i["text"] for i in k.data["checklist"] if not i["checked"]]
    if unchecked:
        errors.append(f"{len(unchecked)} safety checklist item(s) are not confirmed: " + "; ".join(unchecked[:3]) + ("…" if len(unchecked) > 3 else ""))
    if data.get("phrase") != s["phrase"]:
        errors.append(f"type the confirmation phrase exactly: {s['phrase']}")
    if data.get("operator_in_control") is not True:
        errors.append("confirm that a human operator is in direct control and that QuadLab will not arm or command the aircraft")
    issues = _open_incompatibilities(db, k) if s["flight"] else []
    justification = (data.get("incompatibility_justification") or "").strip()
    if issues and len(justification) < 30:
        errors.append(f"the configuration has {len(issues)} open incompatibility finding(s); a flight stage needs a written justification "
                      "of at least 30 characters to proceed: " + " | ".join(issues))
    if link_status and link_status.get("alive") and link_status["heartbeat"]["armed"]:
        errors.append("the connected vehicle reports ARMED — disarm before authorising a test")
    if errors:
        raise ValidationError(errors)
    k.gate = {"at": _now(), "operator": operator, "phrase": s["phrase"], "checklist": [i["text"] for i in k.data["checklist"]],
              "open_incompatibilities": issues, "justification": justification if issues else "", "consumed": False,
              "vehicle": ({"autopilot": link_status["heartbeat"]["autopilot"], "mode": link_status["heartbeat"]["mode"], "armed": False,
                           "declared_simulator": link_status.get("declared_simulator")} if link_status and link_status.get("alive") else None)}
    k.status = "authorised"
    _event(k, "safety gate passed", operator, f"{len(k.data['checklist'])} checklist items confirmed; phrase “{s['phrase']}”"
           + (f"; proceeding with {len(issues)} open incompatibility finding(s): {justification}" if issues else ""))
    db.commit()
    return k


def start(db: Session, card_id: int, data: dict) -> TestCard:
    k = get_card(db, card_id)
    s = STAGE[k.stage]
    by = (data.get("by") or "").strip()
    if k.status not in ("planned", "authorised"):
        raise Conflict(f"the card is already {k.status.replace('_', ' ')}")
    errors = []
    if not by:
        errors.append("the name of the engineer starting the test is required")
    blocking = [x["n"] for x in stage_status(k.campaign) if x["n"] < k.stage and not x["satisfied"]]
    if blocking:
        errors.append("earlier stages are not passed or waived: " + ", ".join(f"{n} ({STAGE[n]['name']})" for n in blocking))
    if s["motors"]:
        if not gate_state(k)["authorised"]:
            if k.status == "authorised":            # expired: back to planned so it can be authorised again
                k.status = "planned"
                _event(k, "authorisation expired", detail=f"Not started within {GATE_VALID_MINUTES} minutes")
                db.commit()
            raise Conflict(f"this stage energises motors: pass the safety gate first (authorisation is valid for {GATE_VALID_MINUTES} minutes)")
    else:
        unchecked = [i["text"] for i in k.data["checklist"] if not i["checked"]]
        if unchecked:
            errors.append(f"{len(unchecked)} checklist item(s) are not confirmed")
    if errors:
        raise ValidationError(errors)
    if k.gate:
        k.gate = {**k.gate, "consumed": True}
    k.status = "in_progress"
    _event(k, "started", by)
    db.commit()
    return k


def complete(db: Session, card_id: int, data: dict) -> TestCard:
    k = get_card(db, card_id)
    if k.status != "in_progress":
        raise Conflict("only a card that is in progress can be completed")
    verdict, by = data.get("verdict"), (data.get("by") or "").strip()
    errors = []
    if verdict not in VERDICTS:
        errors.append(f"verdict must be one of {', '.join(VERDICTS)}")
    if not by:
        errors.append("the name of the engineer recording the result is required")
    if not k.data.get("actual_results"):
        errors.append("record the actual results before completing the card")
    crit = k.data["criteria"]
    if verdict == "pass" and not all(c["met"] is True for c in crit):
        errors.append("a pass needs every pass/fail criterion marked as met")
    if verdict == "fail" and not any(c["met"] is False for c in crit):
        errors.append("a fail needs at least one criterion marked as not met")
    if errors:
        raise ValidationError(errors)
    k.status, k.verdict = "done", verdict
    _event(k, f"completed: {verdict}", by, f"{sum(c['met'] is True for c in crit)} of {len(crit)} criteria met")
    db.commit()
    return k


def reopen(db: Session, card_id: int, data: dict) -> TestCard:
    k = get_card(db, card_id)
    if k.status != "done":
        raise Conflict("only a completed card can be reopened")
    reason, by = (data.get("reason") or "").strip(), (data.get("by") or "").strip()
    if len(reason) < 15 or not by:
        raise ValidationError(["reopening a completed card needs a name and a reason of at least 15 characters"])
    prev = k.verdict
    k.status, k.verdict, k.gate = "planned", None, None
    d = dict(k.data)
    d["checklist"] = [{**i, "checked": False} for i in d["checklist"]]       # the safety checklist is confirmed afresh for every run
    k.data = d
    _event(k, "reopened", by, f"Previous verdict: {prev}. Reason: {reason}")
    db.commit()
    return k


def link_log(db: Session, card_id: int, log_id: int | None) -> TestCard:
    k = get_card(db, card_id)
    if log_id is not None:
        log = db.get(TelemetryLog, log_id)
        if log is None or log.project_id != k.campaign.project_id:
            raise ValidationError(["telemetry log not found in this project"])
        log.card_id = k.id
        _event(k, "telemetry log linked", detail=f"{log.name} ({log.source}, {log.frames} frames)")
    else:
        _event(k, "telemetry log unlinked")
    k.telemetry_log_id = log_id
    db.commit()
    return k


def meta() -> dict:
    return {"stages": STAGES, "verdicts": VERDICTS, "gate_valid_minutes": GATE_VALID_MINUTES,
            "principle": "QuadLab never arms, launches or commands an aircraft. The safety gate records an operator's confirmation; the operator flies."}
