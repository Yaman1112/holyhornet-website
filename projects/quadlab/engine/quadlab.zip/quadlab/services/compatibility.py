"""Hardware compatibility engine.

Every check is a pure function of the configuration. It returns one of five verdicts
and always says which recorded values it used. A check never assumes a value that is
not on record: it returns "missing" and names the field instead.

Explanations quote values in metric engineering units.
"""
from __future__ import annotations

import math

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import catalog
from ..db import Component
from . import assembly
from .components import display_name
from .context import (INCH, Config, Part, fmt_len, has_iface, matching_test, full_throttle, motor_demand, norm,
                      prop_inches, tested_diameters)

STATUS = {
    "compatible": {"label": "Compatible", "rank": 0},
    "limited": {"label": "Compatible with limitations", "rank": 2},
    "config": {"label": "Requires configuration", "rank": 1},
    "missing": {"label": "Missing information", "rank": 3},
    "incompatible": {"label": "Incompatible", "rank": 4},
}
G0 = 9.80665
TW_GUIDE = 2.0            # thrust-to-weight design guidance (assumption, stated in the result)
TIP_CLEARANCE_RATIO = 0.05


def res(id, group, title, status, explanation, parts=(), basis=(), assumptions=(), swap=()):
    return {"id": id, "group": group, "title": title, "status": status, "status_label": STATUS[status]["label"],
            "explanation": explanation, "parts": [p.name for p in parts if p], "basis": [b for b in basis if b and b["value"] is not None],
            "assumptions": list(assumptions), "swap": list(swap), "alternatives": []}


def need(id, group, title, *missing: tuple[Part | None, str, str]):
    """`missing` result naming every absent part or field: (part, category, key)."""
    gaps, parts = [], []
    for part, cat, key in missing:
        if part is None:
            gaps.append(f"no {catalog.CATEGORIES[cat]['singular']} in the configuration")
        elif part.entry(key) is None:
            gaps.append(f"{part.name}: “{part.label(key)}” is not on record")
            parts.append(part)
    if not gaps:
        return None
    return res(id, group, title, "missing", "Cannot be evaluated — " + "; ".join(gaps) + ".", parts)


# ------------------------------------------------------------------ electrical: voltage

def _cells(id, title, user_cat):
    def rule(cfg: Config):
        batt, user = cfg.one("battery"), cfg.one(user_cat)
        if user is None and user_cat == "power":
            return []
        gap = need(id, "Voltage", title, (batt, "battery", "cell_count"), (user, user_cat, "cells_min"), (user, user_cat, "cells_max"))
        if gap:
            return [gap]
        s, lo, hi = batt.num("cell_count"), user.num("cells_min"), user.num("cells_max")
        basis = [batt.cite("cell_count"), batt.cite("nominal_voltage"), user.cite("cells_min"), user.cite("cells_max")]
        if lo <= s <= hi:
            return [res(id, "Voltage", title, "compatible",
                        f"{batt.name} is a {s:g}S pack; {user.name} is rated for {lo:g}S to {hi:g}S.", (batt, user), basis)]
        why = "above the maximum" if s > hi else "below the minimum"
        risk = " Over-voltage can destroy the component." if s > hi else ""
        return [res(id, "Voltage", title, "incompatible",
                    f"{batt.name} is a {s:g}S pack, {why} cell count of {user.name} ({lo:g}S to {hi:g}S).{risk}",
                    (batt, user), basis, swap=("battery", user_cat))]
    rule.swap = ("battery", user_cat)
    return rule


# ------------------------------------------------------------------ electrical: current

def esc_motor_current(cfg: Config):
    id, title = "esc_motor_current", "ESC current rating vs motor"
    esc, motor = cfg.one("esc"), cfg.one("motor")
    gap = need(id, "Current", title, (esc, "esc", "continuous_current"), (motor, "motor", "max_current"))
    if gap:
        return [gap]
    cont, mmax = esc.num("continuous_current"), motor.num("max_current")
    basis = [esc.cite("continuous_current"), esc.cite("burst_current"), motor.cite("max_current")]
    if cont >= mmax:
        return [res(id, "Current", title, "compatible",
                    f"{esc.name} is rated {cont:g} A continuous; {motor.name} is rated {mmax:g} A maximum. Margin {(cont / mmax - 1) * 100:.0f}%.",
                    (esc, motor), basis)]
    d = motor_demand(cfg)
    if d and d.basis == "tested" and cont >= d.per_motor:
        return [res(id, "Current", title, "limited",
                    f"{esc.name} ({cont:g} A continuous) is below the {mmax:g} A maximum rating of {motor.name}, but above the measured "
                    f"full-throttle draw with the selected propeller: {d.text}. A larger propeller or higher voltage would exceed the ESC.",
                    (esc, motor), basis, swap=("esc",))]
    extra = f" Measured full-throttle draw with the selected propeller is {d.text}." if d and d.basis == "tested" else ""
    return [res(id, "Current", title, "incompatible",
                f"{esc.name} is rated {cont:g} A continuous, less than the {mmax:g} A the {motor.name} can draw.{extra}",
                (esc, motor), basis, swap=("esc",))]


esc_motor_current.swap = ("esc",)


def _supply_capacity(id, title, cat, key, what):
    def rule(cfg: Config):
        src, motor = cfg.one(cat), cfg.one("motor")
        if src is None and cat == "power":
            return []
        gap = need(id, "Current", title, (src, cat, key), (motor, "motor", "max_current"))
        if gap:
            return [gap]
        n = cfg.rotor_count
        cap, rated = src.num(key), motor.num("max_current") * n
        d = motor_demand(cfg)
        tested = d.per_motor * n if d and d.basis == "tested" else None
        basis = [src.cite(key), motor.cite("max_current")]
        assume = [f"Total demand = {n} × per-motor current. Avionics and payload current are not included."]
        if cap >= rated:
            return [res(id, "Current", title, "compatible",
                        f"{src.name} {what} {cap:g} A; {n} × {motor.name} at their {motor.num('max_current'):g} A maximum is {rated:g} A. "
                        f"Margin {(cap / rated - 1) * 100:.0f}%.", (src, motor), basis, assume)]
        if tested is not None and cap >= tested:
            return [res(id, "Current", title, "limited",
                        f"{src.name} {what} {cap:g} A — below {rated:g} A ({n} motors at maximum rating) but above the measured "
                        f"full-throttle total of {tested:.3g} A ({d.text}).", (src, motor), basis, assume, swap=(cat,))]
        extra = f" Measured full-throttle total with the selected propeller is {tested:.3g} A." if tested is not None else ""
        return [res(id, "Current", title, "incompatible",
                    f"{src.name} {what} only {cap:g} A; {n} × {motor.name} can draw up to {rated:g} A.{extra}",
                    (src, motor), basis, assume, swap=(cat,))]
    rule.swap = (cat,)
    return rule


# ------------------------------------------------------------------ propulsion

def motor_propeller(cfg: Config):
    id, title = "motor_propeller", "Motor and propeller pairing"
    motor, prop = cfg.one("motor"), cfg.one("propeller")
    gap = need(id, "Propulsion", title, (motor, "motor", "kv"), (prop, "propeller", "diameter"), (prop, "propeller", "pitch"))
    if gap:
        return [gap]
    d_in, p_in = prop_inches(prop)
    size = f"{d_in:.3g}×{p_in:.3g} in"
    basis = [prop.cite("diameter"), prop.cite("pitch"), motor.cite("recommended_propellers"), prop.cite("rpm_max"), prop.cite("thrust_limit")]
    test = matching_test(motor, prop)
    if test:
        pt = full_throttle(test)
        notes, status = [], "compatible"
        rpm_max, limit = prop.num("rpm_max"), prop.num("thrust_limit")
        if pt and pt.get("speed") and rpm_max and pt["speed"] > rpm_max * 1.001:
            status = "limited"
            notes.append(f"At full throttle the test reached {pt['speed'] * 60 / (2 * math.pi):.0f} rpm, above the propeller's "
                         f"recommended maximum of {rpm_max * 60 / (2 * math.pi):.0f} rpm.")
        if pt and limit and pt["thrust"] > limit:
            status = "incompatible"
            notes.append(f"Full-throttle thrust {pt['thrust'] / G0 * 1000:.0f} gf exceeds the propeller thrust limit {limit / G0 * 1000:.0f} gf.")
        return [res(id, "Propulsion", title, status,
                    f"{motor.name} has a {test['provenance']} bench test with a {size} propeller ({test['propeller']}, {test['voltage']:g} V)"
                    + (f": {pt['thrust'] / G0 * 1000:.0f} gf at {pt['current']:.3g} A, full throttle." if pt and pt.get("current") else ".")
                    + (" " + " ".join(notes) if notes else ""), (motor, prop), basis,
                    ["The bench test may have used a different propeller model of the same size."], swap=("propeller",))]
    tested = tested_diameters(motor)
    if not tested:
        return [res(id, "Propulsion", title, "missing",
                    f"No thrust test data on record for {motor.name}, so loading with a {size} propeller cannot be confirmed. "
                    "Add bench data for this pairing in the component library.", (motor, prop), basis)]
    lo, hi = tested[0], tested[-1]
    if lo - 0.06 <= d_in <= hi + 0.06:
        return [res(id, "Propulsion", title, "limited",
                    f"No bench test of {motor.name} with a {size} propeller is on record. The diameter is within the tested range "
                    f"({lo:g}–{hi:g} in), so loading is expected to lie between the tested cases, but pitch differs — measure before flight.",
                    (motor, prop), basis, swap=("propeller",))]
    side = "larger than the largest" if d_in > hi else "smaller than the smallest"
    risk = " A larger propeller raises motor current and temperature beyond anything on record." if d_in > hi else ""
    return [res(id, "Propulsion", title, "missing",
                f"The {size} propeller is {side} propeller tested with {motor.name} ({lo:g}–{hi:g} in). "
                f"There is no data to confirm this pairing.{risk}", (motor, prop), basis, swap=("propeller",))]


motor_propeller.swap = ("propeller",)


def thrust_to_weight(cfg: Config):
    id, title = "thrust_weight", "Static thrust vs aircraft mass"
    motor, prop = cfg.one("motor"), cfg.one("propeller")
    if motor is None or prop is None:
        return []
    d = motor_demand(cfg)
    if not d or d.basis != "tested" or d.thrust is None:
        return [res(id, "Weight", title, "missing",
                    f"No bench thrust data for {motor.name} with the selected propeller, so available thrust cannot be stated.", (motor, prop))]
    masses = [(p, p.num("weight")) for p in cfg.parts]
    unknown = [p.name for p, m in masses if m is None]
    mass = sum(m * p.quantity for p, m in masses if m is not None)
    n = cfg.rotor_count
    thrust = d.thrust * n
    tw = thrust / (mass * G0) if mass else None
    assume = [f"Static bench thrust at {d.voltage:g} V; in-flight thrust and a sagging battery give less.",
              "Mass is the sum of recorded component weights; wiring and fasteners are not included.",
              f"The {TW_GUIDE:g}:1 threshold is common multirotor design guidance, not a manufacturer limit."]
    text = f"{n} × {d.thrust / G0 * 1000:.0f} gf = {thrust / G0:.2f} kgf static thrust against {mass:.3f} kg of recorded mass"
    if unknown:
        return [res(id, "Weight", title, "missing",
                    f"{text}, but {len(unknown)} item(s) have no weight on record ({', '.join(unknown)}), so the ratio "
                    f"({tw:.2f}:1 at best) is an upper bound.", (motor, prop), assumptions=assume)]
    if tw <= 1.0:
        return [res(id, "Weight", title, "incompatible", f"{text}: thrust-to-weight {tw:.2f}:1. The aircraft cannot hover.",
                    (motor, prop), assumptions=assume, swap=("motor", "propeller", "battery"))]
    if tw < TW_GUIDE:
        return [res(id, "Weight", title, "limited",
                    f"{text}: thrust-to-weight {tw:.2f}:1, below the {TW_GUIDE:g}:1 guidance. Expect high hover throttle and reduced control margin.",
                    (motor, prop), assumptions=assume, swap=("motor", "propeller", "battery"))]
    return [res(id, "Weight", title, "compatible", f"{text}: thrust-to-weight {tw:.2f}:1.", (motor, prop), assumptions=assume)]


thrust_to_weight.swap = ("motor", "propeller", "battery")


def frame_weight(cfg: Config):
    frame = cfg.one("frame")
    if frame is None:
        return []
    id, title = "frame_mtow", "Frame maximum take-off weight"
    limit = frame.num("max_takeoff_weight")
    if limit is None:
        return [res(id, "Weight", title, "missing", f"{frame.name}: “Max take-off weight” is not on record.", (frame,))]
    masses = [p.num("weight") for p in cfg.parts]
    mass = sum(m * p.quantity for p, m in zip(cfg.parts, masses) if m is not None)
    bound = " (lower bound: some weights are not on record)" if any(m is None for m in masses) else ""
    status = "compatible" if mass <= limit and not bound else "missing" if mass <= limit else "incompatible"
    return [res(id, "Weight", title, status, f"Recorded mass {mass:.3f} kg{bound} against a frame limit of {limit:.3f} kg.",
                (frame,), [frame.cite("max_takeoff_weight")])]


# ------------------------------------------------------------------ physical

def propeller_clearance(cfg: Config):
    id, title = "prop_clearance", "Propeller clearance on the frame"
    frame, prop = cfg.one("frame"), cfg.one("propeller")
    gap = need(id, "Physical", title, (prop, "propeller", "diameter"))
    if gap:
        return [gap]
    geo = assembly.frame_geometry(cfg)
    if "wheelbase" in geo["nominal_fields"]:
        return [res(id, "Physical", title, "missing",
                    "No frame wheelbase on record (and no project override), so motor spacing is unknown.", (frame, prop))]
    spacing = assembly.motor_spacing(cfg)
    d = prop.num("diameter")
    clearance = spacing - d
    basis = [prop.cite("diameter"), frame.cite("wheelbase") if frame else None, frame.cite("max_propeller_diameter") if frame else None]
    assume = [f"Motor spacing {fmt_len(spacing)} is the smallest centre distance between motors in the current 3D assembly "
              f"({cfg.layout} layout, wheelbase {fmt_len(geo['wheelbase'])} from {geo['wheelbase_source']}).",
              "All propellers are in one plane."]
    out = []
    if clearance <= 0:
        out.append(res(id, "Physical", title, "incompatible",
                       f"Adjacent propeller discs overlap by {fmt_len(-clearance)}: propeller diameter {fmt_len(d)}, motor spacing {fmt_len(spacing)}. "
                       f"The largest propeller that clears on this geometry is below {spacing / INCH:.1f} in.",
                       (frame, prop), basis, assume, swap=("propeller", "frame")))
    elif clearance < TIP_CLEARANCE_RATIO * d:
        out.append(res(id, "Physical", title, "limited",
                       f"Tip-to-tip clearance is {fmt_len(clearance)} ({clearance / d * 100:.1f}% of diameter). Tightly spaced rotors lose "
                       "efficiency and are noisier; check clearance under arm flex.", (frame, prop), basis,
                       assume + [f"The {TIP_CLEARANCE_RATIO * 100:g}% threshold is a design rule of thumb."], swap=("propeller", "frame")))
    else:
        out.append(res(id, "Physical", title, "compatible",
                       f"Tip-to-tip clearance between adjacent propellers is {fmt_len(clearance)} ({clearance / d * 100:.0f}% of diameter).",
                       (frame, prop), basis, assume))
    fmax = frame.num("max_propeller_diameter") if frame else None
    if fmax is not None and d > fmax:
        out.append(res("prop_frame_limit", "Physical", "Frame maximum propeller size", "incompatible",
                       f"{prop.name} ({fmt_len(d)}) exceeds the frame's stated maximum propeller diameter ({fmt_len(fmax)}).",
                       (frame, prop), basis, swap=("propeller", "frame")))
    return out


propeller_clearance.swap = ("propeller", "frame")


def _text_match(id, group, title, a_cat, a_key, b_cat, b_key, verb):
    def rule(cfg: Config):
        a, b = cfg.one(a_cat), cfg.one(b_cat)
        if a is None or b is None:
            return []
        gap = need(id, group, title, (a, a_cat, a_key), (b, b_cat, b_key))
        if gap:
            return [gap]
        va, vb = a.items(a_key), b.items(b_key)
        basis = [a.cite(a_key), b.cite(b_key)]
        na, nb = [norm(s) for s in va], [norm(s) for s in vb]
        if any(x and (x in y or y in x) for x in na for y in nb):
            return [res(id, group, title, "compatible", f"{a.name}: {', '.join(va)}. {b.name}: {', '.join(vb)}.", (a, b), basis,
                        ["Matched by comparing the recorded text; confirm physically."])]
        return [res(id, group, title, "incompatible",
                    f"{a.name} ({', '.join(va)}) does not {verb} {b.name} ({', '.join(vb)}) as recorded.", (a, b), basis,
                    ["Compared as recorded text. An adapter or re-termination rated for the full current may resolve a connector mismatch."],
                    swap=(a_cat, b_cat))]
    rule.swap = (a_cat, b_cat)
    return rule


def shaft_bore(cfg: Config):
    motor, prop = cfg.one("motor"), cfg.one("propeller")
    if motor is None or prop is None:
        return []
    id, title = "shaft_bore", "Propeller mounting on the motor"
    gap = need(id, "Physical", title, (motor, "motor", "shaft_diameter"), (prop, "propeller", "bore_diameter"))
    if gap:
        gap["explanation"] += " Large multirotor propellers are often bolted to the motor bell rather than fitted on the shaft — record the hub mounting pattern."
        return [gap]
    s, b = motor.num("shaft_diameter"), prop.num("bore_diameter")
    ok = abs(s - b) < 0.00011
    return [res(id, "Physical", title, "compatible" if ok else "incompatible",
                f"Motor shaft {fmt_len(s)}, propeller bore {fmt_len(b)}.", (motor, prop), [motor.cite("shaft_diameter"), prop.cite("bore_diameter")],
                swap=() if ok else ("propeller",))]


# ------------------------------------------------------------------ flight controller interfaces

def fc_power(cfg: Config):
    fc, pm = cfg.one("flight_controller"), cfg.one("power")
    if fc is None:
        return []
    id, title = "fc_power", "Flight-controller power input"
    if pm is None:
        return [res(id, "Voltage", title, "missing",
                    f"No power module or PDB in the configuration, so the supply to {fc.name} is undefined. "
                    "Never connect battery voltage to the flight-controller power port.", (fc,))]
    gap = need(id, "Voltage", title, (pm, "power", "output_voltage"), (fc, "flight_controller", "max_input_voltage"))
    if gap:
        return [gap]
    v, vmax = pm.num("output_voltage"), fc.num("max_input_voltage")
    basis = [pm.cite("output_voltage"), pm.cite("output_current_max"), fc.cite("max_input_voltage")]
    if v <= vmax:
        return [res(id, "Voltage", title, "compatible",
                    f"{pm.name} supplies {v:g} V regulated; {fc.name} accepts up to {vmax:g} V on its power input.", (pm, fc), basis,
                    ["The flight controller's minimum input voltage and current draw are not on record."])]
    return [res(id, "Voltage", title, "incompatible",
                f"{pm.name} supplies {v:g} V, above the {vmax:g} V maximum input of {fc.name}.", (pm, fc), basis, swap=("power", "flight_controller"))]


fc_power.swap = ("power", "flight_controller")


def pwm_outputs(cfg: Config):
    fc, esc = cfg.one("flight_controller"), cfg.one("esc")
    if fc is None or esc is None:
        return []
    id, title = "pwm_outputs", "Motor outputs and ESC signal protocol"
    n = cfg.count("esc")
    protos = esc.items("protocols")
    can_only = protos and all("can" in p.lower() for p in protos)
    if can_only:
        gap = need(id, "Interfaces", title, (fc, "flight_controller", "can_interfaces"))
        if gap:
            return [gap]
        ok = fc.num("can_interfaces") >= 1
        return [res(id, "Interfaces", title, "config" if ok else "incompatible",
                    f"{esc.name} is controlled over {', '.join(protos)}; {fc.name} has {fc.num('can_interfaces'):g} CAN interface(s)."
                    + (" The CAN ESC driver and node IDs must be configured in the autopilot." if ok else ""),
                    (fc, esc), [esc.cite("protocols"), fc.cite("can_interfaces")], swap=() if ok else ("flight_controller", "esc"))]
    gap = need(id, "Interfaces", title, (fc, "flight_controller", "pwm_outputs"))
    if gap:
        return [gap]
    outs = fc.num("pwm_outputs")
    basis = [fc.cite("pwm_outputs"), esc.cite("protocols"), esc.cite("signal_frequency_max")]
    if outs < n:
        return [res(id, "Interfaces", title, "incompatible", f"{n} ESCs need {n} motor outputs; {fc.name} has {outs:g}.", (fc, esc), basis,
                    swap=("flight_controller",))]
    if not protos:
        return [res(id, "Interfaces", title, "missing",
                    f"{fc.name} has {outs:g} PWM outputs for {n} ESCs, but the signal protocols accepted by {esc.name} are not on record. "
                    "Confirm the protocol (PWM, OneShot, DShot…) before configuring the autopilot outputs.", (fc, esc), basis)]
    return [res(id, "Interfaces", title, "config",
                f"{fc.name} has {outs:g} PWM outputs for {n} ESCs; {esc.name} accepts {', '.join(protos)}. "
                "Select the matching output protocol and run ESC calibration in the autopilot.", (fc, esc), basis)]


pwm_outputs.swap = ("flight_controller",)

SERIAL_CATS = ["telemetry", "companion", "rangefinder", "optical_flow", "imu", "barometer", "magnetometer", "camera", "payload"]


def serial_ports(cfg: Config):
    fc = cfg.one("flight_controller")
    if fc is None:
        return []
    out = []
    gps_n = cfg.count("gps")
    if gps_n:
        id, title = "gps_ports", "GNSS ports"
        gap = need(id, "Interfaces", title, (fc, "flight_controller", "gps_ports"))
        if gap:
            out.append(gap)
        else:
            have = fc.num("gps_ports")
            ok = gps_n <= have
            out.append(res(id, "Interfaces", title, "compatible" if ok else "incompatible",
                           f"{gps_n} GNSS module(s) for {have:g} GPS port(s) on {fc.name}.", (fc, *cfg.all("gps")),
                           [fc.cite("gps_ports")], swap=() if ok else ("flight_controller",)))
    users, unknown, i2c_capable = [], [], 0
    for cat in SERIAL_CATS:
        for p in cfg.all(cat):
            if not p.items("interfaces"):
                unknown.append(p)
            elif has_iface(p, "uart") or has_iface(p, "serial"):
                users += [p] * p.quantity
                i2c_capable += p.quantity if has_iface(p, "i2c") or has_iface(p, "can") else 0
    if users or unknown:
        id, title = "uart_ports", "UART availability"
        gap = need(id, "Interfaces", title, (fc, "flight_controller", "uart_ports"))
        if gap:
            out.append(gap)
        else:
            have = fc.num("uart_ports")
            names = ", ".join(p.name for p in users) or "none"
            basis = [fc.cite("uart_ports")] + [p.cite("interfaces") for p in dict.fromkeys(users)]
            if unknown:
                out.append(res(id, "Interfaces", title, "missing",
                               f"Interfaces are not on record for: {', '.join(p.name for p in unknown)}. "
                               f"Known serial devices ({names}) need {len(users)} of {have:g} UART port(s).", (fc, *unknown), basis))
            elif len(users) <= have:
                needs_cfg = any(p.category != "telemetry" for p in users)
                out.append(res(id, "Interfaces", title, "config" if needs_cfg else "compatible",
                               f"{len(users)} serial device(s) ({names}) for {have:g} general-purpose UART port(s) on {fc.name}."
                               + (" Each sensor's serial port, baud rate and driver must be set in the autopilot parameters." if needs_cfg else ""),
                               (fc, *dict.fromkeys(users)), basis))
            elif len(users) - i2c_capable <= have:
                out.append(res(id, "Interfaces", title, "config",
                               f"{len(users)} serial device(s) ({names}) exceed the {have:g} UART port(s) on {fc.name}, but "
                               f"{i2c_capable} of them also support I2C or CAN and can be moved to that bus.", (fc, *dict.fromkeys(users)), basis))
            else:
                out.append(res(id, "Interfaces", title, "incompatible",
                               f"{len(users)} serial device(s) ({names}) need more than the {have:g} UART port(s) on {fc.name}.",
                               (fc, *dict.fromkeys(users)), basis, swap=("flight_controller",)))
    can_users = [p for p in cfg.parts if p.category not in ("flight_controller", "esc") and has_iface(p, "can")
                 and not (has_iface(p, "uart") or has_iface(p, "i2c"))]
    if can_users:
        id, title = "can_bus", "CAN bus"
        gap = need(id, "Interfaces", title, (fc, "flight_controller", "can_interfaces"))
        if gap:
            out.append(gap)
        else:
            ok = fc.num("can_interfaces") >= 1
            out.append(res(id, "Interfaces", title, "config" if ok else "incompatible",
                           f"{', '.join(p.name for p in can_users)} use CAN; {fc.name} has {fc.num('can_interfaces'):g} CAN interface(s)."
                           + (" Enable the CAN driver and assign node IDs in the autopilot." if ok else ""),
                           (fc, *can_users), [fc.cite("can_interfaces")], swap=() if ok else ("flight_controller",)))
    return out


serial_ports.swap = ("flight_controller",)

RAIL_CATS = ["gps", "telemetry", "receiver", "rangefinder", "optical_flow", "imu", "barometer", "magnetometer"]


def peripheral_supply(cfg: Config):
    """Peripherals powered from the flight-controller port rail."""
    pm = cfg.one("power")
    rail = pm.num("output_voltage") if pm else None
    out = []
    for cat in RAIL_CATS:
        for p in cfg.all(cat):
            id, title = f"supply_{p.comp['id']}", f"Supply voltage — {p.name}"
            lo, hi = p.num("supply_voltage_min"), p.num("supply_voltage_max")
            if lo is None or hi is None:
                out.append(res(id, "Voltage", title, "missing", f"{p.name}: supply voltage range is not on record.", (p,)))
                continue
            if rail is None:
                out.append(res(id, "Voltage", title, "missing",
                               f"{p.name} needs {lo:g}–{hi:g} V, but no regulated supply (power module output voltage) is on record.", (p,),
                               [p.cite("supply_voltage_min"), p.cite("supply_voltage_max")]))
                continue
            basis = [pm.cite("output_voltage"), p.cite("supply_voltage_min"), p.cite("supply_voltage_max")]
            assume = [f"Peripheral ports are assumed to carry the {rail:g} V regulated output of {pm.name}; "
                      "the voltage drop through the flight controller is not on record."]
            if lo < hi and lo <= rail <= hi:
                edge = " — at the upper limit" if math.isclose(rail, hi) else ""
                out.append(res(id, "Voltage", title, "compatible", f"{p.name} accepts {lo:g}–{hi:g} V; the regulated rail is {rail:g} V{edge}.",
                               (p, pm), basis, assume))
            elif lo == hi and abs(rail - lo) / lo <= 0.10:
                out.append(res(id, "Voltage", title, "limited",
                               f"{p.name} is specified for a nominal {lo:g} V with no stated tolerance; the regulated rail is {rail:g} V "
                               f"({(rail / lo - 1) * 100:+.0f}%). Confirm the tolerance in the datasheet.", (p, pm), basis, assume))
            else:
                out.append(res(id, "Voltage", title, "incompatible",
                               f"{p.name} accepts {lo:g}–{hi:g} V; the regulated rail is {rail:g} V.", (p, pm), basis, assume, swap=(cat,)))
    return out


def thermal(cfg: Config):
    out = []
    esc = cfg.one("esc")
    if esc is not None:
        cooling = esc.text("cooling")
        if cooling:
            out.append(res("esc_cooling", "Thermal", "ESC cooling", "limited",
                           f"{esc.name} states a cooling requirement: {cooling}. Confirm the mounting position provides it.",
                           (esc,), [esc.cite("cooling")]))
        else:
            out.append(res("esc_cooling", "Thermal", "ESC cooling", "missing",
                           f"{esc.name}: no cooling requirement or thermal rating on record, so thermal margin cannot be assessed.", (esc,)))
    motor, prop = cfg.one("motor"), cfg.one("propeller")
    if motor and prop:
        t = matching_test(motor, prop)
        if t and "°C" in (t.get("note") or ""):
            out.append(res("motor_temp", "Thermal", "Motor temperature in bench test", "compatible",
                           f"Bench-test note for {motor.name} with {t['propeller']}: {t['note']}", (motor,),
                           assumptions=["Reported for reference; no winding temperature limit is on record to compare against."]))
    return out


RULES = [
    _cells("battery_motor_voltage", "Battery voltage vs motor", "motor"),
    _cells("battery_esc_voltage", "Battery voltage vs ESC", "esc"),
    _cells("battery_power_voltage", "Battery voltage vs power module", "power"),
    esc_motor_current,
    _supply_capacity("battery_discharge", "Battery discharge capability", "battery", "max_discharge_current", "can deliver"),
    _supply_capacity("power_module_current", "Power module current rating", "power", "continuous_current", "is rated for"),
    motor_propeller,
    thrust_to_weight,
    frame_weight,
    propeller_clearance,
    _text_match("motor_mount", "Physical", "Motor mounting pattern", "frame", "motor_mount_pattern", "motor", "mount_pattern", "match"),
    shaft_bore,
    _text_match("battery_connector", "Connectors", "Battery connector", "battery", "connector", "power", "connectors", "mate with"),
    fc_power,
    pwm_outputs,
    serial_ports,
    peripheral_supply,
    thermal,
]

GROUPS = ["Voltage", "Current", "Propulsion", "Weight", "Physical", "Connectors", "Interfaces", "Thermal"]


def _notes(cfg: Config) -> list[str]:
    notes = []
    for cat in ("frame", "flight_controller", "motor", "esc", "propeller", "battery", "power"):
        kinds = cfg.all(cat)
        if len(kinds) > 1:
            notes.append(f"{len(kinds)} different {catalog.CATEGORIES[cat]['label'].lower()} are in the configuration; "
                         f"checks use the first: {kinds[0].name}.")
    return notes


def evaluate(cfg: Config) -> dict:
    checks = []
    for rule in RULES if cfg.parts else []:
        checks += rule(cfg)
    counts = {k: sum(1 for c in checks if c["status"] == k) for k in STATUS}
    overall = max((c["status"] for c in checks), key=lambda s: STATUS[s]["rank"], default="missing")
    return {"overall": overall, "overall_label": STATUS[overall]["label"] if checks else "No checks apply yet",
            "counts": counts, "checks": checks, "notes": _notes(cfg), "groups": GROUPS,
            "statuses": {k: v["label"] for k, v in STATUS.items()}}


def _comp_dict(c: Component) -> dict:
    from .components import thrust_dict
    return {"id": c.id, "category": c.category, "name": display_name(c), "specs": c.specs or {},
            "thrust_tests": [thrust_dict(t) for t in c.thrust_tests]}


def with_alternatives(db: Session, cfg: Config, limit: int = 4) -> dict:
    """Evaluate, then for each failing check look for library components that would
    pass that same check if swapped in. Only a verified "compatible" result counts."""
    result = evaluate(cfg)
    library: dict[str, list[dict]] = {}
    rule_of = {}
    for rule in RULES if cfg.parts else []:
        for c in rule(cfg):
            rule_of[c["id"]] = rule
    for check in result["checks"]:
        if check["status"] not in ("incompatible", "limited") or not check["swap"]:
            continue
        rule = rule_of[check["id"]]
        for cat in check["swap"]:
            current = {p.comp["id"] for p in cfg.all(cat)}
            if cat not in library:
                library[cat] = [_comp_dict(c) for c in db.scalars(select(Component).where(Component.category == cat))]
            for cand in library[cat]:
                if cand["id"] in current:
                    continue
                trial = [c for c in rule(cfg.swap(cat, cand)) if c["id"] == check["id"]]
                if trial and all(c["status"] == "compatible" for c in trial):
                    check["alternatives"].append({"id": cand["id"], "name": cand["name"], "category": cat,
                                                  "category_label": catalog.CATEGORIES[cat]["singular"],
                                                  "result": trial[0]["explanation"]})
            check["alternatives"] = check["alternatives"][:limit * len(check["swap"])]
        if not check["alternatives"]:
            check["no_alternative_note"] = ("No component in the library passes this check as a direct replacement. "
                                            "Add candidate parts to the library to have them evaluated.")
    return result
