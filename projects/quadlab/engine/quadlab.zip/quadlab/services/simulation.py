"""QuadLab internal flight simulator: a 6-DOF rigid-body model of the designed aircraft.

What it is: physics driven by the project's own data — mass and inertia from the 3D
assembly, rotor geometry and spin directions, thrust/speed/power from the bench test
of the selected motor and propeller, the recorded battery, plus an environment.

What it is not: PX4 or ArduPilot. The aircraft is flown by QuadLab's own reference
controller (cascaded position → velocity → attitude → rate), with gains derived from
the airframe. Results show what the airframe can do, not how a particular autopilot
tune will behave. For firmware-in-the-loop, connect a PX4/ArduPilot SITL instance.

Model (body frame FRD, world frame NED, SI units)
  rotor thrust        T_i = kT w_i^2 (rho/rho0)        kT least-squares fit to the bench points
  rotor drag torque   Q_i = kQ w_i^2 (rho/rho0)        from measured torque, else the motor model, else 0.05 T (PX4 default)
  motor response      dw/dt = (w_cmd - w)/tau           first-order lag (tau is an analysis parameter)
  speed limit         w_max = w_bench_full min(1, V/V_test)   sags with terminal voltage; never above the tested maximum
  forces              m dv/dt = m g + R(q)[0,0,-sum T] - 0.5 rho CdA |v_air| v_air
  moments             I dw/dt = sum(r_i x F_i) + sum(-s_i Q_i z) - w x I w      (s_i = +1 for CW)
  electrical          P = sum P_bench(T_i) + avionics ;  I = P / V_term ;  V_term = V_oc(SoC) - I R
  open-circuit        generic single-cell LiPo curve x cell count (an assumption, not pack data)
"""
from __future__ import annotations

import math
import random

from . import assembly
from .components import ValidationError
from .context import Config, matching_test
from .performance import G0, RHO0, PropulsionModel, avionics_power, motor_model

DT = 0.002                # integration step, s
OUT_DT = 0.04             # output sample period, s
MAX_DURATION = 180.0

# Generic LiPo open-circuit voltage per cell vs state of charge.
OCV = [(0.0, 3.27), (0.05, 3.50), (0.10, 3.60), (0.20, 3.70), (0.40, 3.78), (0.60, 3.87), (0.80, 4.02), (1.0, 4.20)]

ENV = {
    # key: (default, min, max, label, unit, help)
    "wind_speed": (0.0, 0.0, 25.0, "Mean wind speed", "m/s", "Steady wind."),
    "wind_direction": (0.0, 0.0, 360.0, "Wind from", "°", "Compass direction the wind blows from (0 = from north)."),
    "gust_sigma": (0.0, 0.0, 10.0, "Gust intensity (σ)", "m/s", "Standard deviation of turbulence about the mean wind."),
    "air_density": (RHO0, 0.5, 1.5, "Air density", "kg/m³", "1.225 is ISA sea level."),
    "drag_area": (0.03, 0.001, 2.0, "Drag area CdA", "m²", "Airframe drag area. Not derivable from component data: 0.03 m² is a placeholder — enter your own estimate."),
    "motor_tau": (0.05, 0.005, 0.5, "Motor/ESC time constant", "s", "First-order thrust response. Not on record for any component: measure it, or treat 0.05 s as a placeholder."),
    "gps_noise": (0.0, 0.0, 1.0, "Simulate GNSS position noise", "0/1", "Uses the horizontal accuracy recorded for the GNSS module, if any."),
    "start_soc": (1.0, 0.05, 1.0, "Starting state of charge", "", "Battery charge at take-off (1 = full)."),
    "payload_mass": (0.0, 0.0, 100.0, "Added payload", "kg", "Extra mass at the centre of gravity."),
    "seed": (1.0, 0.0, 1e6, "Random seed", "", "Same seed, same turbulence and sensor noise."),
}

SCENARIOS = {
    "hover": {"label": "Take-off and hover", "description": "Climb to 5 m, hold position for 20 s, land.", "duration": 40.0,
              "plan": [(0.0, (0, 0, 5)), (30.0, (0, 0, 0))]},
    "altitude_step": {"label": "Altitude step", "description": "Hover at 5 m, step to 15 m, step back — vertical response and thrust margin.", "duration": 45.0,
                      "plan": [(0.0, (0, 0, 5)), (12.0, (0, 0, 15)), (27.0, (0, 0, 5)), (39.0, (0, 0, 0))]},
    "position_step": {"label": "Position step", "description": "Hover, then a 10 m step north — horizontal response, tilt and overshoot.", "duration": 40.0,
                      "plan": [(0.0, (0, 0, 8)), (10.0, (10, 0, 8)), (32.0, (10, 0, 0))]},
    "square": {"label": "Square pattern", "description": "20 m square at 10 m altitude, then return and land.", "duration": 80.0,
               "plan": [(0.0, (0, 0, 10)), (8.0, (20, 0, 10)), (22.0, (20, 20, 10)), (36.0, (0, 20, 10)), (50.0, (0, 0, 10)), (66.0, (0, 0, 0))]},
    "wind_hold": {"label": "Station keeping in wind", "description": "Hold position at 10 m for 40 s. Set wind and gusts in the environment.", "duration": 55.0,
                  "plan": [(0.0, (0, 0, 10)), (46.0, (0, 0, 0))]},
}

SCENES = {
    "field": {"label": "Open field", "obstacles": [{"kind": "pad", "x": 0, "y": 0, "r": 1.0}]},
    "urban": {"label": "Urban block", "obstacles": [
        {"kind": "pad", "x": 0, "y": 0, "r": 1.0},
        {"kind": "building", "x": 32, "y": -6, "w": 10, "d": 12, "h": 18}, {"kind": "building", "x": 30, "y": 30, "w": 12, "d": 10, "h": 26},
        {"kind": "building", "x": -16, "y": 28, "w": 14, "d": 9, "h": 12}, {"kind": "building", "x": 10, "y": -24, "w": 9, "d": 9, "h": 15}]},
    "trees": {"label": "Tree line", "obstacles": [
        {"kind": "pad", "x": 0, "y": 0, "r": 1.0},
        *({"kind": "tree", "x": 27 + (i % 2) * 3, "y": -15 + i * 6.5, "r": 2.2, "h": 9 + (i * 7) % 4} for i in range(8)),
        {"kind": "pad", "x": 20, "y": 20, "r": 1.0}]},
}


def clean_env(raw: dict | None) -> dict:
    out, errors = {}, []
    for key, (default, lo, hi, label, unit, _) in ENV.items():
        v = (raw or {}).get(key, default)
        if v in (None, ""):
            v = default
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not lo <= v <= hi:
            errors.append(f"{label} must be between {lo:g} and {hi:g} {unit}".strip())
            continue
        out[key] = float(v)
    for key in (raw or {}):
        if key not in ENV:
            errors.append(f"unknown environment parameter '{key}'")
    if errors:
        raise ValidationError(errors)
    return out


def meta() -> dict:
    return {
        "scenarios": [{"key": k, **{f: v[f] for f in ("label", "description", "duration")}} for k, v in SCENARIOS.items()],
        "scenes": [{"key": k, "label": v["label"], "obstacles": list(v["obstacles"])} for k, v in SCENES.items()],
        "env": [{"key": k, "default": d, "min": lo, "max": hi, "label": label, "unit": unit, "help": h} for k, (d, lo, hi, label, unit, h) in ENV.items()],
    }


# ------------------------------------------------------------------ vehicle model

def _fit_through_origin(xs: list[float], ys: list[float]) -> float | None:
    den = sum(x * x for x in xs)
    return sum(x * y for x, y in zip(xs, ys)) / den if den > 0 else None


def inertia(cfg: Config, asm: dict, extra_mass: float = 0.0) -> dict:
    """Mass, centre of gravity and principal moments about the CG (diagonal terms only).

    Each part: its own box / cylinder / disc inertia about its centre plus the
    parallel-axis term. The frame's mass distribution is not on record: half is placed
    in the central plates and half in slender arms running to the motors.
    """
    bodies: list[tuple[float, tuple[float, float, float], tuple[float, float, float]]] = []     # mass, position, own Ixx/Iyy/Izz
    excluded: list[str] = []
    for p in asm["parts"]:
        m = p["mass"]
        if m is None:
            if p["name"] not in excluded:
                excluded.append(p["name"])
            continue
        if p["shape"] == "box":
            l, w, h = p["size"]
            c, s = math.cos(math.radians(p["yaw"])), math.sin(math.radians(p["yaw"]))
            ixx_b, iyy_b = m * (w * w + h * h) / 12, m * (l * l + h * h) / 12
            own = (ixx_b * c * c + iyy_b * s * s, ixx_b * s * s + iyy_b * c * c, m * (l * l + w * w) / 12)
        else:
            r = p["size"][0] / 2
            h = p["size"][1] if p["shape"] == "cylinder" else 0.0
            own = (m * (3 * r * r + h * h) / 12, m * (3 * r * r + h * h) / 12, m * r * r / 2)
        bodies.append((m, tuple(p["position"]), own))
    frame = cfg.one("frame")
    fm = frame.num("weight") if frame else None
    if frame is not None and fm is None:
        excluded.append(frame.name)
    if fm:
        f = asm["frame"]
        pl, pw = f["plate"]
        half = fm / 2
        bodies.append((half, (0.0, 0.0, 0.0), (half * pw * pw / 12, half * pl * pl / 12, half * (pl * pl + pw * pw) / 12)))
        arms = f["motor_positions"]
        for x, y in arms:
            ma, length = half / len(arms), math.hypot(x, y)
            az = math.atan2(y, x)
            rod = ma * length * length / 12
            bodies.append((ma, (x / 2, y / 2, 0.0), (rod * math.sin(az) ** 2, rod * math.cos(az) ** 2, rod)))
    mass = sum(b[0] for b in bodies)
    if mass <= 0:
        return {"mass": 0.0, "cg": [0.0, 0.0, 0.0], "I": [0.0, 0.0, 0.0], "excluded": excluded}
    cg = [sum(b[0] * b[1][k] for b in bodies) / mass for k in range(3)]
    I = [0.0, 0.0, 0.0]
    for m, pos, own in bodies:
        d = [pos[k] - cg[k] for k in range(3)]
        I[0] += own[0] + m * (d[1] ** 2 + d[2] ** 2)
        I[1] += own[1] + m * (d[0] ** 2 + d[2] ** 2)
        I[2] += own[2] + m * (d[0] ** 2 + d[1] ** 2)
    return {"mass": mass + extra_mass, "cg": cg, "I": I, "excluded": excluded}


def build_vehicle(cfg: Config, env: dict) -> dict:
    """Assemble the simulation model. Returns {'ok': False, 'blockers': [...]} when the
    data on record cannot support a simulation."""
    blockers: list[str] = []
    notes: list[str] = []
    motor, prop, batt = cfg.one("motor"), cfg.one("propeller"), cfg.one("battery")
    asm = assembly.build(cfg)
    motors = sorted((p for p in asm["parts"] if p["category"] == "motor"), key=lambda p: p["rotor"])
    if len(motors) != cfg.rotor_count:
        blockers.append(f"The simulator needs {cfg.rotor_count} motors; the configuration has {len(motors)}.")
    if "wheelbase" in asm["frame"]["nominal_fields"]:
        blockers.append("No frame wheelbase on record (and no project override): rotor geometry is unknown.")
    test = matching_test(motor, prop) if motor and prop else None
    model = PropulsionModel(test) if test else None
    if motor is None or prop is None:
        blockers.append("Select a motor and a propeller.")
    elif model is None or not model.ok:
        blockers.append(f"No usable bench thrust test of {motor.name} with a propeller the size of {prop.name}: rotor thrust cannot be modelled.")
    pts = [p for p in (model.points if model and model.ok else []) if p.get("speed")]
    if model and model.ok and len(pts) < 2:
        blockers.append("The bench test has no rotor speed data, so thrust cannot be related to motor speed.")
    v_nom, cap, cells = (batt.num(k) if batt else None for k in ("nominal_voltage", "capacity", "cell_count"))
    if batt is None or not (v_nom and cap and cells):
        blockers.append("Select a battery with cell count, nominal voltage and capacity on record.")
    inert = inertia(cfg, asm, env["payload_mass"])
    if inert["mass"] <= 0:
        blockers.append("No component weights on record.")
    if inert["excluded"]:
        notes.append("No weight on record (excluded from mass and inertia): " + ", ".join(inert["excluded"]) + ".")
    if any(v <= 0 for v in inert["I"]) and inert["mass"] > 0:
        blockers.append("Moments of inertia could not be computed from the recorded dimensions.")
    if blockers:
        return {"ok": False, "blockers": blockers, "notes": notes}

    kt = _fit_through_origin([p["speed"] ** 2 for p in pts], [p["thrust"] for p in pts])
    if any(p.get("torque") is not None for p in pts):
        tp = [p for p in pts if p.get("torque") is not None]
        kq = _fit_through_origin([p["speed"] ** 2 for p in tp], [p["torque"] for p in tp])
        kq_basis = "measured torque in the bench test"
    else:
        mm = motor_model(motor, test)
        if mm["available"] and mm["rows"]:
            kq = _fit_through_origin([r["speed"] ** 2 for r in mm["rows"]], [r["torque"] for r in mm["rows"]])
            kq_basis = "first-order motor model (no torque measured on the bench) — an upper estimate"
        else:
            kq = 0.05 * kt
            kq_basis = "0.05 × thrust (PX4's default moment coefficient) — no torque data and no motor constants on record"
    full = max(pts, key=lambda p: p["speed"])
    cg = inert["cg"]
    rotors = [{"x": m["position"][0] - cg[0], "y": m["position"][1] - cg[1], "spin": 1.0 if m["spin"] == "CW" else -1.0, "label": f"M{m['rotor']} {m['spin']}"} for m in motors]
    gps = cfg.one("gps")
    sigma = None
    if gps and gps.text("position_accuracy"):
        import re
        mt = re.search(r"([\d.]+)\s*m\s*CEP", gps.text("position_accuracy"))
        if mt:
            sigma = float(mt.group(1)) / 1.1774            # CEP = 1.1774 sigma for a circular normal distribution
    rate = min(gps.num("update_rate_max") or 5.0, 10.0) if gps else 5.0
    aux, _, _ = avionics_power(cfg)
    r_pack = batt.num("internal_resistance")
    if not r_pack:
        notes.append("Battery internal resistance is not on record: terminal voltage follows the open-circuit curve with no sag under load.")
    notes += [
        f"Thrust coefficient kT = {kt:.3e} N·s²/rad² fitted to {len(pts)} bench points ({test['propeller']} @ {test['voltage']:g} V, {test['provenance']}).",
        f"Torque coefficient kQ = {kq:.3e} N·m·s²/rad² from {kq_basis}.",
        "Frame mass distribution is not on record: half in the central plates, half in slender arms to the motors.",
        "Open-circuit voltage uses a generic LiPo cell curve, not data for this pack.",
        "Products of inertia are neglected; rotor gyroscopic and blade-flapping effects, ground effect and rotor inflow changes in forward flight are not modelled.",
    ]
    if sigma is not None and env["gps_noise"]:
        notes.append(f"GNSS noise: σ = {sigma:.2f} m per axis at {rate:g} Hz (from the recorded CEP). Position feedback dead-reckons on "
                     "velocity and is pulled toward each fix with gain 0.15 — a stand-in for a navigation filter, not EKF2/EKF3.")
    if sigma is None and env["gps_noise"]:
        notes.append("GNSS noise requested, but no horizontal accuracy (… m CEP) is on record for a GNSS module: position feedback is noise-free.")
    return {
        "ok": True, "blockers": [], "notes": notes, "mass": inert["mass"], "I": inert["I"], "cg": cg, "rotors": rotors,
        "kt": kt, "kq": kq, "kq_basis": kq_basis, "w_full": full["speed"], "v_test": test["voltage"], "model": model,
        "cells": cells, "capacity": cap, "r_pack": r_pack or 0.0, "aux_power": aux,
        "gps_sigma": sigma if env["gps_noise"] else None, "gps_rate": rate,
        "source": {"motor": motor.name, "propeller": prop.name, "battery": batt.name, "test": f"{test['propeller']} @ {test['voltage']:g} V", "provenance": test["provenance"]},
    }


def ocv_cell(soc: float) -> float:
    soc = min(1.0, max(0.0, soc))
    for (s0, v0), (s1, v1) in zip(OCV, OCV[1:]):
        if soc <= s1:
            return v0 + (v1 - v0) * (soc - s0) / (s1 - s0)
    return OCV[-1][1]


def _solve4(A: list[list[float]], b: list[float]) -> list[float]:
    """Gaussian elimination with partial pivoting for the 4x4 mixer."""
    n = 4
    M = [row[:] + [b[i]] for i, row in enumerate(A)]
    for c in range(n):
        piv = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-12:
            raise ValidationError(["rotor geometry is degenerate: roll, pitch, yaw and thrust cannot be controlled independently"])
        M[c], M[piv] = M[piv], M[c]
        for r in range(c + 1, n):
            f = M[r][c] / M[c][c]
            for k in range(c, n + 1):
                M[r][k] -= f * M[c][k]
    x = [0.0] * n
    for r in range(n - 1, -1, -1):
        x[r] = (M[r][n] - sum(M[r][k] * x[k] for k in range(r + 1, n))) / M[r][r]
    return x


def mixer_matrix(veh: dict) -> list[list[float]]:
    """Rows: total thrust, roll moment, pitch moment, yaw moment as linear functions of the rotor thrusts.
    A rotor at (x, y) pushing up (-z) gives moments (-y T, +x T); a CW rotor's drag torque turns the body CCW (-z)."""
    c = veh["kq"] / veh["kt"]
    return [[1.0] * 4, [-r["y"] for r in veh["rotors"]], [r["x"] for r in veh["rotors"]], [-r["spin"] * c for r in veh["rotors"]]]


def invert_mixer(veh: dict) -> list[list[float]]:
    A = mixer_matrix(veh)
    cols = [_solve4(A, [1.0 if i == k else 0.0 for i in range(4)]) for k in range(4)]
    return [[cols[k][i] for k in range(4)] for i in range(4)]            # inv[i][k]: thrust of rotor i per unit of demand k


# ------------------------------------------------------------------ simulation

def _setpoint(plan: list, t: float) -> tuple[float, float, float]:
    cur = plan[0][1]
    for t0, sp in plan:
        if t >= t0:
            cur = sp
    return cur


def run(cfg: Config, scenario: str, raw_env: dict | None = None, scene: str = "field", plan: list | None = None, duration: float | None = None) -> dict:
    if scenario not in SCENARIOS and plan is None:
        raise ValidationError([f"unknown scenario '{scenario}'"])
    if scene not in SCENES:
        raise ValidationError([f"unknown scene '{scene}'"])
    env = clean_env(raw_env)
    veh = build_vehicle(cfg, env)
    base = {"scenario": scenario, "scene": scene, "env": env, "obstacles": SCENES[scene]["obstacles"]}
    if not veh["ok"]:
        return {**base, "ok": False, "blockers": veh["blockers"], "notes": veh["notes"]}
    sc = SCENARIOS.get(scenario, {})
    plan = plan or sc["plan"]
    T_end = min(duration or sc.get("duration", 40.0), MAX_DURATION)

    m, (Ix, Iy, Iz) = veh["mass"], veh["I"]
    rotors, kt, kq, model = veh["rotors"], veh["kt"], veh["kq"], veh["model"]
    rho = env["air_density"]
    kt_e, kq_e = kt * rho / RHO0, kq * rho / RHO0
    inv = invert_mixer(veh)
    tau = env["motor_tau"]
    weight = m * G0
    t_bench_max = model.t_max
    rng = random.Random(int(env["seed"]))

    # reference controller gains, derived from the actuator bandwidth (successive loops ~3x slower)
    k_rate = min(0.5 / tau, 25.0)
    k_att = k_rate / 3.0
    k_vel = k_att / 2.5
    k_pos = k_vel / 2.5
    k_vel_i = k_vel / 6.0
    kz_vel, kz_pos = min(1.0 / tau, 6.0) / 2.0, min(1.0 / tau, 6.0) / 6.0
    k_yaw_rate, k_yaw = k_rate / 3.0, k_rate / 9.0
    max_tilt = math.radians(30)
    v_max_xy, v_up, v_down = 6.0, 3.0, 1.5

    # wind: steady vector (blowing *from* wind_direction) plus first-order Gauss-Markov gusts
    wd = math.radians(env["wind_direction"])
    wind_mean = (-env["wind_speed"] * math.cos(wd), -env["wind_speed"] * math.sin(wd), 0.0)
    gust = [0.0, 0.0, 0.0]
    gust_tc = 2.0

    # state
    p = [0.0, 0.0, 0.0]
    v = [0.0, 0.0, 0.0]
    q = [1.0, 0.0, 0.0, 0.0]                 # body -> world
    w = [0.0, 0.0, 0.0]
    omega = [0.0, 0.0, 0.0, 0.0]
    soc = env["start_soc"]
    used = 0.0                               # A*s
    energy = 0.0                             # J
    vi = [0.0, 0.0]
    gps_meas = [0.0, 0.0]
    gps_next = 0.0
    v_term = veh["cells"] * ocv_cell(soc)
    airborne = False
    landed_at = None
    events: list[dict] = []
    samples: list[dict] = []
    sat_steps = 0
    air_steps = 0
    next_out = 0.0
    obstacles = [o for o in SCENES[scene]["obstacles"] if o["kind"] != "pad"]
    peak = {"tilt": 0.0, "current": 0.0, "power": 0.0, "speed": 0.0, "alt": 0.0}
    v_min = v_term
    err2, err_n = 0.0, 0
    outcome = "completed"
    steps = int(round(T_end / DT))
    current = power = 0.0
    thrusts = [0.0] * 4

    for step in range(steps + 1):
        t = step * DT
        sp = _setpoint(plan, t)
        land = sp[2] <= 0.0
        alt = -p[2]

        # ---- rotation matrix body -> world
        qw, qx, qy, qz = q
        r00, r01, r02 = 1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qw * qz), 2 * (qx * qz + qw * qy)
        r10, r11, r12 = 2 * (qx * qy + qw * qz), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qw * qx)
        r20, r21, r22 = 2 * (qx * qz - qw * qy), 2 * (qy * qz + qw * qx), 1 - 2 * (qx * qx + qy * qy)
        roll, pitch, yaw = math.atan2(r21, r22), -math.asin(max(-1.0, min(1.0, r20))), math.atan2(r10, r00)

        # ---- sensors
        if veh["gps_sigma"]:
            # stand-in for a navigation filter: dead-reckon on velocity, pull toward each GNSS fix
            gps_meas[0] += v[0] * DT
            gps_meas[1] += v[1] * DT
            if t >= gps_next:
                gps_meas[0] += 0.15 * (p[0] + rng.gauss(0, veh["gps_sigma"]) - gps_meas[0])
                gps_meas[1] += 0.15 * (p[1] + rng.gauss(0, veh["gps_sigma"]) - gps_meas[1])
                gps_next = t + 1.0 / veh["gps_rate"]
        px, py = (gps_meas if veh["gps_sigma"] else (p[0], p[1]))

        # ---- position -> velocity -> acceleration
        ex, ey = sp[0] - px, sp[1] - py
        vx_c, vy_c = k_pos * ex, k_pos * ey
        sp_h = math.hypot(vx_c, vy_c)
        if sp_h > v_max_xy:
            vx_c, vy_c = vx_c * v_max_xy / sp_h, vy_c * v_max_xy / sp_h
        if not airborne or alt < 0.3:
            vx_c = vy_c = 0.0
        ax_c = k_vel * (vx_c - v[0]) + vi[0]
        ay_c = k_vel * (vy_c - v[1]) + vi[1]
        vz_c = max(-v_up, min(v_down, kz_pos * (-sp[2] - p[2])))        # NED: positive vz is down
        if land:
            vz_c = min(v_down, 0.3 + 0.6 * alt) if alt > 0.02 else 0.3
        az_c = kz_vel * (vz_c - v[2])
        lim = G0 * math.tan(max_tilt)
        a_h = math.hypot(ax_c, ay_c)
        if a_h > lim:
            ax_c, ay_c = ax_c * lim / a_h, ay_c * lim / a_h
        elif airborne:
            vi[0] += k_vel_i * (vx_c - v[0]) * DT
            vi[1] += k_vel_i * (vy_c - v[1]) * DT

        # desired thrust vector (world): F = m (a_cmd - g), body -z must point along it
        fx, fy, fz = m * ax_c, m * ay_c, m * (az_c - G0)
        f_norm = math.sqrt(fx * fx + fy * fy + fz * fz) or 1e-9
        t_total = max(0.0, -(fx * r02 + fy * r12 + fz * r22))            # projection on the current body -z
        bz = (-fx / f_norm, -fy / f_norm, -fz / f_norm)                   # desired body z axis (down), world frame
        # attitude error: rotate current body z (world) onto desired; expressed in body axes
        cz = (r02, r12, r22)
        cxw = (cz[1] * bz[2] - cz[2] * bz[1], cz[2] * bz[0] - cz[0] * bz[2], cz[0] * bz[1] - cz[1] * bz[0])
        e_roll = r00 * cxw[0] + r10 * cxw[1] + r20 * cxw[2]
        e_pitch = r01 * cxw[0] + r11 * cxw[1] + r21 * cxw[2]
        e_yaw = -yaw                                                       # hold north
        w_cx, w_cy, w_cz = k_att * e_roll, k_att * e_pitch, k_yaw * e_yaw
        al_x, al_y, al_z = k_rate * (w_cx - w[0]), k_rate * (w_cy - w[1]), k_yaw_rate * (w_cz - w[2])
        tq = (Ix * al_x + (Iz - Iy) * w[1] * w[2], Iy * al_y + (Ix - Iz) * w[0] * w[2], Iz * al_z + (Iy - Ix) * w[0] * w[1])
        if not airborne and (land or t_total < 0.2 * weight):
            tq = (0.0, 0.0, 0.0)

        # ---- mixer and motors
        w_max = veh["w_full"] * min(1.0, v_term / veh["v_test"])          # never faster than the highest tested speed
        t_lim = kt_e * w_max * w_max
        demand = (t_total, tq[0], tq[1], tq[2])
        saturated = False
        cmd = []
        for i in range(4):
            ti = inv[i][0] * demand[0] + inv[i][1] * demand[1] + inv[i][2] * demand[2] + inv[i][3] * demand[3]
            if ti > t_lim:
                ti, saturated = t_lim, True
            elif ti < 0.0:
                ti, saturated = 0.0, saturated or airborne
            cmd.append(math.sqrt(ti / kt_e))
        if landed_at is not None:
            cmd = [0.0] * 4
        power = veh["aux_power"]
        fz_b = 0.0
        mx = my = mz = 0.0
        for i in range(4):
            omega[i] += (cmd[i] - omega[i]) * DT / tau
            ti = kt_e * omega[i] * omega[i]
            thrusts[i] = ti
            fz_b -= ti
            mx -= rotors[i]["y"] * ti
            my += rotors[i]["x"] * ti
            mz -= rotors[i]["spin"] * kq_e * omega[i] * omega[i]
            tb = min(ti * RHO0 / rho, t_bench_max)
            if tb > 1e-6:
                power += model.bench(tb)["power"] * rho / RHO0

        # ---- battery
        v_oc = veh["cells"] * ocv_cell(soc)
        if veh["r_pack"] > 0:
            disc = v_oc * v_oc - 4 * veh["r_pack"] * power
            current = (v_oc - math.sqrt(disc)) / (2 * veh["r_pack"]) if disc > 0 else v_oc / (2 * veh["r_pack"])
        else:
            current = power / v_oc
        v_term = v_oc - current * veh["r_pack"]
        used += current * DT
        energy += current * v_term * DT
        soc = env["start_soc"] - used / veh["capacity"]

        # ---- wind and drag
        if env["gust_sigma"] > 0:
            a = DT / gust_tc
            s = env["gust_sigma"] * math.sqrt(2 * a)
            for k in range(3):
                gust[k] += -gust[k] * a + s * rng.gauss(0, 1) * (0.5 if k == 2 else 1.0)
        wx, wy, wz = wind_mean[0] + gust[0], wind_mean[1] + gust[1], gust[2]
        vax, vay, vaz = v[0] - wx, v[1] - wy, v[2] - wz
        va = math.sqrt(vax * vax + vay * vay + vaz * vaz)
        kd = 0.5 * rho * env["drag_area"] * va
        dx, dy, dz = -kd * vax, -kd * vay, -kd * vaz

        # ---- dynamics (semi-implicit Euler)
        acc = [(r02 * fz_b + dx) / m, (r12 * fz_b + dy) / m, G0 + (r22 * fz_b + dz) / m]
        on_ground = p[2] >= 0.0 and (v[2] > 0.0 or acc[2] >= 0.0)
        if on_ground:
            if airborne:                                    # touchdown
                impact, tilt_now = v[2], math.degrees(math.acos(max(-1.0, min(1.0, r22))))
                airborne = False
                if impact > 2.5 or tilt_now > 35:
                    outcome = "crashed"
                    events.append({"t": round(t, 2), "kind": "crash", "message": f"Ground impact at {impact:.1f} m/s, tilt {tilt_now:.0f}°."})
                    samples.append(_sample(t, p, v, (roll, pitch, yaw), w, omega, thrusts, v_term, current, power, soc, used, sp, (wx, wy, wz), saturated))
                    break
                landed_at = t
                events.append({"t": round(t, 2), "kind": "landed", "message": f"Touchdown at {impact:.2f} m/s."})
            p[2] = 0.0
            v = [0.0, 0.0, 0.0]
            w = [0.0, 0.0, 0.0]
            q = [math.cos(yaw / 2), 0.0, 0.0, math.sin(yaw / 2)]
            acc = [0.0, 0.0, 0.0]
        else:
            if not airborne:
                airborne = True
                events.append({"t": round(t, 2), "kind": "takeoff", "message": "Lift-off."})
            wd0 = (mx - (Iz - Iy) * w[1] * w[2]) / Ix
            wd1 = (my - (Ix - Iz) * w[0] * w[2]) / Iy
            wd2 = (mz - (Iy - Ix) * w[0] * w[1]) / Iz
            w[0] += wd0 * DT
            w[1] += wd1 * DT
            w[2] += wd2 * DT
            for k in range(3):
                v[k] += acc[k] * DT
                p[k] += v[k] * DT
            h = 0.5 * DT
            q = [qw - h * (qx * w[0] + qy * w[1] + qz * w[2]), qx + h * (qw * w[0] + qy * w[2] - qz * w[1]),
                 qy + h * (qw * w[1] + qz * w[0] - qx * w[2]), qz + h * (qw * w[2] + qx * w[1] - qy * w[0])]
            nq = math.sqrt(sum(c * c for c in q))
            q = [c / nq for c in q]

        # ---- bookkeeping
        if airborne:
            air_steps += 1
            sat_steps += saturated
            tilt = math.degrees(math.acos(max(-1.0, min(1.0, r22))))
            peak["tilt"] = max(peak["tilt"], tilt)
            peak["speed"] = max(peak["speed"], math.hypot(v[0], v[1]))
            peak["alt"] = max(peak["alt"], -p[2])
            if not land:
                err2 += (sp[0] - p[0]) ** 2 + (sp[1] - p[1]) ** 2
                err_n += 1
            if tilt > 80:
                outcome = "lost control"
                events.append({"t": round(t, 2), "kind": "upset", "message": f"Attitude exceeded 80° (tilt {tilt:.0f}°): control lost."})
                samples.append(_sample(t, p, v, (roll, pitch, yaw), w, omega, thrusts, v_term, current, power, soc, used, sp, (wx, wy, wz), saturated))
                break
            hit = _collision(p, obstacles)
            if hit:
                outcome = "collision"
                events.append({"t": round(t, 2), "kind": "collision", "message": f"Collision with a {hit}."})
                samples.append(_sample(t, p, v, (roll, pitch, yaw), w, omega, thrusts, v_term, current, power, soc, used, sp, (wx, wy, wz), saturated))
                break
        peak["current"], peak["power"] = max(peak["current"], current), max(peak["power"], power)
        v_min = min(v_min, v_term)
        if soc <= 0.0:
            outcome = "battery depleted"
            events.append({"t": round(t, 2), "kind": "battery", "message": "Battery fully discharged."})
            break
        if t >= next_out - 1e-9:
            samples.append(_sample(t, p, v, (roll, pitch, yaw), w, omega, thrusts, v_term, current, power, soc, used, sp, (wx, wy, wz), saturated))
            next_out += OUT_DT
        if landed_at is not None and t - landed_at > 1.5:
            break
    else:
        if airborne:
            outcome = "time limit reached in flight"
    if not any(e["kind"] == "takeoff" for e in events) and outcome == "completed":
        outcome = "did not take off"
        events.append({"t": 0.0, "kind": "no_takeoff", "message": "Maximum thrust never exceeded the aircraft weight."})

    t_flown = samples[-1]["t"] if samples else 0.0
    hover_thrust = weight / 4
    hover_ok = hover_thrust * RHO0 / rho <= t_bench_max
    return {
        **base, "ok": True, "blockers": [], "notes": veh["notes"], "outcome": outcome, "events": events,
        "vehicle": {"mass": m, "inertia": veh["I"], "cg": veh["cg"], "kt": kt, "kq": kq, "kq_basis": veh["kq_basis"],
                    "rotors": rotors, "hover_thrust_per_motor": hover_thrust, "max_thrust_per_motor": t_bench_max * rho / RHO0,
                    "can_hover": hover_ok, "source": veh["source"], "gps_sigma": veh["gps_sigma"]},
        "controller": {"rate_gain": k_rate, "attitude_gain": k_att, "velocity_gain": k_vel, "position_gain": k_pos, "max_tilt_deg": 30.0,
                       "note": "QuadLab reference controller. Gains follow from the motor time constant; this is not PX4 or ArduPilot."},
        "summary": {
            "duration": t_flown, "max_altitude": peak["alt"], "max_tilt_deg": peak["tilt"], "max_ground_speed": peak["speed"],
            "peak_current": peak["current"], "peak_power": peak["power"], "mean_power": energy / t_flown if t_flown else 0.0,
            "energy_wh": energy / 3600, "charge_used_mah": used / 3.6, "soc_end": soc, "min_voltage": v_min,
            "horizontal_rms_error": math.sqrt(err2 / err_n) if err_n else None,
            "saturation_fraction": sat_steps / air_steps if air_steps else 0.0,
        },
        "samples": samples, "dt": OUT_DT, "plan": [{"t": t0, "x": s[0], "y": s[1], "alt": s[2]} for t0, s in plan],
    }


def _collision(p: list[float], obstacles: list[dict]) -> str | None:
    alt = -p[2]
    for o in obstacles:
        if o["kind"] == "building":
            if abs(p[0] - o["x"]) <= o["w"] / 2 and abs(p[1] - o["y"]) <= o["d"] / 2 and alt <= o["h"]:
                return "building"
        elif o["kind"] == "tree":
            if math.hypot(p[0] - o["x"], p[1] - o["y"]) <= o["r"] and alt <= o["h"]:
                return "tree"
    return None


def _sample(t, p, v, euler, w, omega, thrusts, v_term, current, power, soc, used, sp, wind, saturated) -> dict:
    r = lambda x, n=4: round(x, n)        # noqa: E731
    return {
        "t": r(t, 3), "x": r(p[0]), "y": r(p[1]), "alt": r(-p[2]), "vx": r(v[0]), "vy": r(v[1]), "vz": r(v[2]),
        "roll": r(euler[0], 5), "pitch": r(euler[1], 5), "yaw": r(euler[2], 5), "p": r(w[0]), "q": r(w[1]), "r": r(w[2]),
        "rpm": [round(o * 60 / (2 * math.pi), 1) for o in omega], "thrust": [r(x, 3) for x in thrusts],
        "voltage": r(v_term, 3), "current": r(current, 3), "power": r(power, 2), "soc": r(soc, 5), "used_mah": r(used / 3.6, 2),
        "sp_x": sp[0], "sp_y": sp[1], "sp_alt": sp[2], "wind": [r(wind[0], 2), r(wind[1], 2), r(wind[2], 2)], "sat": bool(saturated),
    }
