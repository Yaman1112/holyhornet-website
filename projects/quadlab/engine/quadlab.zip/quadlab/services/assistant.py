"""AI engineering assistant.

The assistant is Claude with a set of engineering tools. It has no component knowledge
of its own that it is allowed to use: every number in an answer has to come from a tool
call against this project's recorded data and the same calculation services the rest of
the application uses. The tools are plain functions and are also exposed directly
(`limiting_factors`, `what_if`), so the engineering checks work without an API key.

Credentials: resolved by the Anthropic SDK from the environment (ANTHROPIC_API_KEY, or
an `ant auth login` profile), or from a key the user saves in Settings, which is kept in
the local data directory (data/assistant.json) and never returned by the API.
"""
from __future__ import annotations

import json
import logging
import os

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import catalog, config
from ..units import SI_UNIT
from ..db import Component, FlightLog, Project
from . import compatibility, context, performance
from . import projects as psvc
from .components import Conflict, ValidationError, display_name

log = logging.getLogger("quadlab.assistant")

MODEL = "claude-opus-5-5"
MAX_TURNS = 10
MAX_TOKENS = 16000

SYSTEM = """You are the engineering assistant inside QuadLab Pro, a tool for designing and flight-testing quadcopters built from real commercial components. You are talking to an engineer about one drone project.

How to work
- Every number, component property and compatibility statement in your answer must come from a tool result in this conversation. Call the tools first; do not answer from memory about what a product "usually" is.
- If the data needed to answer is not on record, say exactly what is missing and what the engineer should measure or look up. Never fill a gap with a typical value or an assumption presented as fact.
- Tool results label where each value comes from. Carry those labels into your answer: say whether a figure is a manufacturer specification, measured, an estimate, bench data, interpolated, extrapolated, or the output of a first-order model. Keep confirmed facts and assumptions visibly separate.
- Performance figures are estimates from static bench data. Say so when you quote them, and do not present them as guaranteed flight performance.
- To answer "what happens if I change X", use the what_if tool with a component from search_library. Do not predict the effect of a part that is not in the library; say it needs to be added first.
- When something is unsafe or incompatible, say it plainly and say why.
- You cannot arm, launch or command an aircraft and you must not walk the engineer around the application's safety gate.

How to write
- Lead with the answer. Then give the figures that support it, with their units and basis. Then, only if useful, what would change the answer.
- Be concise and concrete. Plain prose and short lists; a small table only when comparing options.
- Use metric units."""

TOOLS = [
    {"name": "get_configuration",
     "description": "The project's current component list with every recorded specification, its provenance (manufacturer / measured / estimate / user) and which core specifications are missing. Call this first for any question about the drone.",
     "input_schema": {"type": "object", "properties": {}, "additionalProperties": False}},
    {"name": "get_compatibility",
     "description": "Rule-based hardware compatibility checks for the current configuration: voltage, current, motor/propeller pairing, thrust-to-weight, propeller clearance, connectors, flight-controller ports, thermal. Each check has a verdict, an explanation and the values it used.",
     "input_schema": {"type": "object", "properties": {"only_problems": {"type": "boolean", "description": "Return only checks that are not 'compatible'."}}, "additionalProperties": False}},
    {"name": "get_performance",
     "description": "Estimated flight performance from bench data: mass, thrust, thrust-to-weight, hover throttle, power, current, endurance, payload capacity, motor loading, electrical margins. Each row is labelled data / interpolated / extrapolated / calculated / model / input. Optional what-if parameters apply to this call only.",
     "input_schema": {"type": "object", "properties": {
         "payload_mass": {"type": "number", "description": "Extra payload in kg."},
         "usable_fraction": {"type": "number", "description": "Usable share of battery capacity, 0.1 to 1."},
         "air_density": {"type": "number", "description": "Air density in kg/m3."}}, "additionalProperties": False}},
    {"name": "limiting_factors",
     "description": "Ranked list of what limits this design: thrust margin, hover throttle, electrical margins, motor loading, mass breakdown, open incompatibilities, and gaps in the data that limit confidence.",
     "input_schema": {"type": "object", "properties": {}, "additionalProperties": False}},
    {"name": "search_library",
     "description": "Search the component library. Returns matching components with their recorded specifications. Use it to find candidate replacements before calling what_if.",
     "input_schema": {"type": "object", "properties": {
         "category": {"type": "string", "enum": list(catalog.CATEGORIES)},
         "query": {"type": "string", "description": "Manufacturer or model text, optional."}}, "required": ["category"], "additionalProperties": False}},
    {"name": "what_if",
     "description": "Evaluate the design with one or more components swapped for library components (by id), and/or extra payload. Returns baseline and variant figures side by side plus compatibility checks that change. Nothing is saved.",
     "input_schema": {"type": "object", "properties": {
         "swaps": {"type": "array", "items": {"type": "object", "properties": {"component_id": {"type": "integer"}}, "required": ["component_id"], "additionalProperties": False},
                   "description": "Each entry replaces every project item of that component's category."},
         "payload_mass": {"type": "number"}}, "additionalProperties": False}},
    {"name": "get_flight_logs",
     "description": "Imported flight logs for this project. Without log_id: the list. With log_id: that log's post-flight analysis (stability, vibration, motors, battery, GNSS, events) and its comparison with the estimate.",
     "input_schema": {"type": "object", "properties": {"log_id": {"type": "integer"}}, "additionalProperties": False}},
]


# ------------------------------------------------------------------ tool implementations

def _spec_view(comp_specs: dict, category: str) -> dict:
    fields = catalog.field_map(category)
    out = {}
    for key, e in comp_specs.items():
        f = fields.get(key)
        unit = SI_UNIT.get(f.quantity) if f and f.quantity else (f.unit if f else e.get("unit"))
        out[f.label if f else e.get("label", key)] = {"value": e["value"], "unit_si": unit or "", "provenance": e.get("provenance"), **({"note": e["note"]} if e.get("note") else {})}
    return out


def tool_configuration(db: Session, p: Project) -> dict:
    items = psvc._live_items(p)
    summary = psvc.summarise(p.airframe, items)
    return {
        "project": {"name": p.name, "airframe": p.airframe, "motor_layout": p.layout},
        "components": [{"category": i["component"]["category"], "name": i["component"]["name"], "component_id": i["component"]["id"], "quantity": i["quantity"],
                        "specifications": _spec_view(i["component"]["specs"], i["component"]["category"]),
                        "missing_core_specifications": [catalog.field_map(i["component"]["category"])[k].label for k in i["component"]["missing_core"]],
                        "bench_thrust_tests": [f"{t['propeller']} @ {t['voltage']:g} V ({t['provenance']}, {len(t['points'])} points)" for t in i["component"].get("thrust_tests", [])]}
                       for i in items],
        "mass_kg": {"known_total": round(summary["mass"]["known_total"], 4), "is_lower_bound": summary["mass"]["is_lower_bound"], "basis": summary["mass"]["basis"]},
        "structural_findings": [f["message"] for f in summary["findings"]],
        "units": "All numeric specification values are SI (kg, m, V, A, W, ohm, A*s for capacity, rad/s for speed, N for thrust).",
    }


def tool_compatibility(db: Session, p: Project, only_problems: bool = False) -> dict:
    r = compatibility.with_alternatives(db, psvc.config_of(p))
    checks = [c for c in r["checks"] if not only_problems or c["status"] != "compatible"]
    return {"overall": r["overall_label"], "counts": r["counts"],
            "checks": [{"title": c["title"], "verdict": c["status_label"], "explanation": c["explanation"], "assumptions": c["assumptions"],
                        "values_used": [{"component": b["component"], "field": b["field"], "value": b["value"], "provenance": b["provenance"]} for b in c["basis"]],
                        "library_alternatives_that_pass": [{"component_id": a["id"], "name": a["name"]} for a in c["alternatives"]]} for c in checks]}


def _perf_view(perf: dict) -> dict:
    return {"available": perf["available"], "blockers": perf["blockers"], "warnings": perf["warnings"],
            "results": [{"section": s["title"], "quantity": r["label"], "value": r["value"], "unit": r["unit"] or {"mass": "kg", "force": "N", "power": "W", "current": "A", "time": "s", "length_km": "m"}.get(r["quantity"], ""),
                         "basis": r["kind"], "how": r["note"]} for s in perf["sections"] for r in s["rows"]],
            "propulsion_data": perf["propulsion_source"], "assumptions": perf["assumptions"], "parameters_used": perf["params"]}


def tool_performance(db: Session, p: Project, **overrides) -> dict:
    items = psvc._live_items(p)
    cfg = context.from_items(p.airframe, p.layout, items, p.design or {})
    params = {**((p.design or {}).get("performance") or {}), **{k: v for k, v in overrides.items() if v is not None}}
    return _perf_view(performance.evaluate(cfg, psvc.summarise(p.airframe, items)["mass"], performance.clean_params(params, strict=True)))


def tool_search_library(db: Session, category: str, query: str = "") -> dict:
    if category not in catalog.CATEGORIES:
        raise ValidationError([f"unknown category '{category}'"])
    stmt = select(Component).where(Component.category == category)
    for term in (query or "").split():
        like = f"%{term}%"
        stmt = stmt.where(Component.manufacturer.ilike(like) | Component.model.ilike(like) | Component.variant.ilike(like))
    comps = list(db.scalars(stmt.order_by(Component.manufacturer, Component.model).limit(25)))
    return {"category": category, "count": len(comps),
            "components": [{"component_id": c.id, "name": display_name(c), "origin": c.origin, "specifications": _spec_view(c.specs or {}, c.category),
                            "bench_thrust_tests": [f"{t.propeller} @ {t.voltage:g} V" for t in c.thrust_tests]} for c in comps],
            "note": "Only components in this library can be evaluated. If a part is not listed, it has to be added with its datasheet first."}


KEY_METRICS = [("mass", "Total mass", "kg"), ("thrust", "Total static thrust", "N"), ("tw", "Thrust-to-weight", ":1"), ("hover_throttle", "Hover throttle", "fraction"),
               ("hover_power", "Hover power", "W"), ("hover_current", "Hover battery current", "A"), ("full_current", "Full-throttle battery current", "A"),
               ("endurance", "Hover endurance", "s"), ("payload_capacity", "Payload capacity", "kg"), ("efficiency", "Hover efficiency", "g/W")]


def what_if(db: Session, p: Project, swaps: list | None = None, payload_mass: float | None = None) -> dict:
    items = psvc._live_items(p)
    design = p.design or {}
    base_params = dict(design.get("performance") or {})

    def run(its, params):
        cfg = context.from_items(p.airframe, p.layout, its, design)
        perf = performance.evaluate(cfg, psvc.summarise(p.airframe, its)["mass"], params)
        return perf, compatibility.evaluate(cfg)

    base_perf, base_compat = run(items, base_params)
    variant_items = [dict(i) for i in items]
    changes = []
    for sw in swaps or []:
        comp = db.get(Component, sw.get("component_id") or 0)
        if comp is None:
            raise ValidationError([f"component {sw.get('component_id')} is not in the library"])
        cd = compatibility._comp_dict(comp)
        cd["missing_core"] = []
        hit = [i for i in variant_items if i["component"]["category"] == comp.category]
        if not hit:
            raise ValidationError([f"the project has no {catalog.CATEGORIES[comp.category]['singular']} to replace with {cd['name']}"])
        for i in hit:
            changes.append(f"{i['component']['name']} → {cd['name']}")
            i["component"] = cd
    params = dict(base_params)
    if payload_mass is not None:
        params["payload_mass"] = payload_mass
        changes.append(f"payload {payload_mass:g} kg")
    if not changes:
        raise ValidationError(["what_if needs at least one swap or a payload mass"])
    var_perf, var_compat = run(variant_items, performance.clean_params(params, strict=True))
    rows = []
    for key, label, unit in KEY_METRICS:
        a, b = base_perf["metrics"].get(key), var_perf["metrics"].get(key)
        rows.append({"quantity": label, "unit": unit, "baseline": a, "variant": b,
                     "change_pct": round((b / a - 1) * 100, 1) if a not in (None, 0) and b is not None else None})
    bc = {c["id"]: c for c in base_compat["checks"]}
    compat_changes = [{"check": c["title"], "baseline": bc[c["id"]]["status_label"] if c["id"] in bc else "not applicable", "variant": c["status_label"], "explanation": c["explanation"]}
                      for c in var_compat["checks"] if c["id"] not in bc or bc[c["id"]]["status"] != c["status"]]
    return {"changes": changes, "figures": rows, "compatibility_changes": compat_changes,
            "baseline_overall": base_compat["overall_label"], "variant_overall": var_compat["overall_label"],
            "variant_blockers": var_perf["blockers"], "variant_warnings": var_perf["warnings"],
            "basis": "Estimates from static bench data, same method as Performance Analysis. A blocker means the variant has no bench test for its motor and propeller, so its performance is not calculated."}


def limiting_factors(db: Session, p: Project) -> dict:
    items = psvc._live_items(p)
    cfg = context.from_items(p.airframe, p.layout, items, p.design or {})
    summary = psvc.summarise(p.airframe, items)
    perf = performance.evaluate(cfg, summary["mass"], (p.design or {}).get("performance"))
    compat = compatibility.evaluate(cfg)
    m = perf["metrics"]
    rows = {r["key"]: r for s in perf["sections"] for r in s["rows"]}
    out: list[dict] = []

    def add(severity, area, finding, evidence):
        out.append({"severity": severity, "area": area, "finding": finding, "evidence": evidence})

    for b in perf["blockers"]:
        add("blocking", "Data", "Performance cannot be calculated.", b)
    for c in compat["checks"]:
        if c["status"] == "incompatible":
            add("blocking", "Compatibility", c["title"], c["explanation"])
    if m.get("tw") is not None:
        tw = m["tw"]
        add("high" if tw < 1.5 else "medium" if tw < 2 else "low", "Thrust margin", f"Static thrust-to-weight is {tw:.2f}:1.",
            "Below 2:1 leaves little margin for manoeuvring, wind and a sagging battery (design guidance). Static bench thrust at the test voltage.")
    if m.get("hover_throttle") is not None:
        h = m["hover_throttle"]
        add("high" if h > 0.7 else "medium" if h > 0.55 else "low", "Hover throttle", f"Estimated hover throttle is {h * 100:.0f} %.",
            f"Basis: {rows['hover_throttle']['kind']}. " + (rows["hover_throttle"]["note"] or ""))
    margins = [(rows[k]["label"], rows[k]["value"], rows[k]["note"]) for k in ("margin_esc", "margin_battery", "margin_power") if k in rows and rows[k]["value"] is not None]
    if margins:
        label, val, note = min(margins, key=lambda x: x[1])
        add("high" if val < 0 else "medium" if val < 20 else "low", "Electrical margin", f"The tightest electrical margin is {label.lower()}: {val:.0f} %.", note)
    if "motor_load_full" in rows:
        v = rows["motor_load_full"]["value"]
        add("high" if v > 100 else "medium" if v > 85 else "low", "Motor loading", f"Motor current at full throttle is {v:.0f} % of its maximum rating.", rows["motor_load_full"]["note"])
    if m.get("mass"):
        by = summary["mass"]["by_category"]
        top = sorted(by.items(), key=lambda kv: -kv[1])[:3]
        add("info", "Mass breakdown", "Heaviest groups: " + ", ".join(f"{catalog.CATEGORIES[k]['label']} {v / m['mass'] * 100:.0f} %" for k, v in top) + ".",
            f"Recorded mass {m['mass']:.3f} kg" + (" (lower bound: some items have no recorded weight)" if summary["mass"]["is_lower_bound"] else "") + ". Hover power scales roughly with mass to the power 1.5.")
    if m.get("endurance") and m.get("hover_power"):
        aux = rows["aux_power"]["value"] if "aux_power" in rows else 0.0
        add("info", "Endurance", f"Estimated hover endurance {m['endurance'] / 60:.1f} min at {m['hover_power']:.0f} W.",
            f"Propulsion {m['hover_power'] - aux:.0f} W, avionics and other recorded loads {aux:.1f} W; hover efficiency {m.get('efficiency', 0):.1f} g/W. An estimate from static bench data.")
    for w in perf["warnings"]:
        add("confidence", "Data quality", "This limits confidence in the figures above.", w)
    missing = [c for c in compat["checks"] if c["status"] == "missing"]
    if missing:
        add("confidence", "Data quality", f"{len(missing)} compatibility check(s) could not be run for lack of data.", "; ".join(c["title"] for c in missing))
    order = {"blocking": 0, "high": 1, "medium": 2, "low": 3, "info": 4, "confidence": 5}
    out.sort(key=lambda r: order[r["severity"]])
    return {"factors": out, "compatibility_overall": compat["overall_label"] if items else "No components"}


def tool_flight_logs(db: Session, p: Project, log_id: int | None = None) -> dict:
    if log_id is None:
        logs = list(db.scalars(select(FlightLog).where(FlightLog.project_id == p.id).order_by(FlightLog.id.desc())))
        return {"logs": [{"log_id": r.id, "name": r.name, "format": r.format, "source": r.source, "duration_s": r.duration, "overall": (r.analysis or {}).get("overall"),
                          "flew": (r.analysis or {}).get("flew")} for r in logs]}
    r = db.get(FlightLog, log_id)
    if r is None or r.project_id != p.id:
        raise ValidationError([f"flight log {log_id} not found in this project"])
    a = r.analysis or {}
    return {"name": r.name, "source": r.source, "format": r.format, "overall": a.get("overall"), "flew": a.get("flew"),
            "sections": [{"title": s["title"], "status": s["status"], "metrics": [{"label": m["label"], "value": m["value"], "unit": m["unit"], "note": m["note"]} for m in s["metrics"]],
                          "findings": [f["text"] for f in s["findings"]], "basis": s.get("basis")} for s in a.get("sections", [])],
            "comparison_with_estimate": a.get("comparison"),
            "note": "source = 'simulator' means the log came from a simulation, not a real flight."}


def run_tool(db: Session, p: Project, name: str, args: dict) -> dict:
    args = args or {}
    if name == "get_configuration":
        return tool_configuration(db, p)
    if name == "get_compatibility":
        return tool_compatibility(db, p, bool(args.get("only_problems")))
    if name == "get_performance":
        return tool_performance(db, p, **{k: args.get(k) for k in ("payload_mass", "usable_fraction", "air_density")})
    if name == "limiting_factors":
        return limiting_factors(db, p)
    if name == "search_library":
        return tool_search_library(db, args.get("category"), args.get("query", ""))
    if name == "what_if":
        return what_if(db, p, args.get("swaps"), args.get("payload_mass"))
    if name == "get_flight_logs":
        return tool_flight_logs(db, p, args.get("log_id"))
    raise ValidationError([f"unknown tool '{name}'"])


# ------------------------------------------------------------------ credentials

def _key_file():
    return config.data_dir() / "assistant.json"


def saved_key() -> str | None:
    f = _key_file()
    if f.is_file():
        try:
            return (json.loads(f.read_text(encoding="utf-8")).get("api_key") or "").strip() or None
        except (OSError, json.JSONDecodeError):
            return None
    return None


BROWSER_NOTE = ("The AI assistant calls the Anthropic API with your own key, which the browser edition neither stores nor sends. "
                "It is available in the QuadLab Pro desktop application. The limiting-factor and what-if tools on this page work here.")


def status() -> dict:
    if config.browser():
        return {"configured": False, "available": False, "note": BROWSER_NOTE, "source": None, "model": MODEL,
                "tools": [{"name": t["name"], "description": t["description"]} for t in TOOLS]}
    env = bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
    saved = saved_key() is not None
    return {"configured": env or saved, "source": "environment" if env else "saved in the application data folder" if saved else None, "model": MODEL,
            "tools": [{"name": t["name"], "description": t["description"]} for t in TOOLS]}


def save_key(key: str | None) -> dict:
    if config.browser():
        raise Conflict(BROWSER_NOTE)
    key = (key or "").strip()
    f = _key_file()
    if not key:
        f.unlink(missing_ok=True)
    else:
        if len(key) < 20 or any(c.isspace() for c in key):
            raise ValidationError(["that does not look like an API key"])
        f.write_text(json.dumps({"api_key": key}), encoding="utf-8")
    return status()


def _client():
    import anthropic
    if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"):
        return anthropic.Anthropic()
    key = saved_key()
    if key:
        return anthropic.Anthropic(api_key=key)
    raise Conflict("The assistant is not configured. Set ANTHROPIC_API_KEY in the environment before starting QuadLab, or save a key under AI Engineering Assistant → Setup.")


# ------------------------------------------------------------------ conversation

def ask(db: Session, p: Project, question: str, history: list | None = None, client=None) -> dict:
    """One user turn. `history` is prior turns as [{"role": "user"|"assistant", "content": text}]."""
    if config.browser():
        raise Conflict(BROWSER_NOTE)
    import anthropic
    question = (question or "").strip()
    if not question:
        raise ValidationError(["ask a question"])
    if len(question) > 8000:
        raise ValidationError(["the question is too long (8000 characters maximum)"])
    messages = []
    for h in (history or [])[-12:]:
        if h.get("role") in ("user", "assistant") and isinstance(h.get("content"), str) and h["content"].strip():
            messages.append({"role": h["role"], "content": h["content"]})
    messages.append({"role": "user", "content": question})
    client = client or _client()
    system = SYSTEM + f"\n\nThe project is “{p.name}” (id {p.id})."
    calls: list[dict] = []
    usage = {"input_tokens": 0, "output_tokens": 0}
    for _ in range(MAX_TURNS):
        try:
            # Opus 5.5 can decline a request; the server-side fallback re-runs it on another model in the same call.
            resp = client.beta.messages.create(model=MODEL, max_tokens=MAX_TOKENS, system=system, tools=TOOLS, messages=messages,
                                               betas=["server-side-fallback-2026-07-01"], fallbacks="default")
        except anthropic.AuthenticationError:
            raise Conflict("The Anthropic API rejected the credentials. Check the API key.")
        except anthropic.PermissionDeniedError:
            raise Conflict("The API key does not have permission to use this model.")
        except anthropic.RateLimitError:
            raise Conflict("The Anthropic API rate limit was reached. Try again shortly.")
        except anthropic.APIStatusError as exc:
            log.warning("assistant API error %s: %s", exc.status_code, exc.message)
            raise Conflict(f"The Anthropic API returned an error ({exc.status_code}): {exc.message}")
        except anthropic.APIConnectionError:
            raise Conflict("Could not reach the Anthropic API. Check the internet connection.")
        usage["input_tokens"] += getattr(resp.usage, "input_tokens", 0) or 0
        usage["output_tokens"] += getattr(resp.usage, "output_tokens", 0) or 0
        text = "\n".join(b.text for b in resp.content if b.type == "text").strip()
        if resp.stop_reason == "refusal":
            return {"answer": text or "The model declined to answer this request.", "tool_calls": calls, "usage": usage, "model": resp.model, "stopped": "refusal"}
        if resp.stop_reason != "tool_use":
            note = "\n\n(The answer was cut off at the output limit.)" if resp.stop_reason == "max_tokens" else ""
            return {"answer": (text or "(no answer text returned)") + note, "tool_calls": calls, "usage": usage, "model": resp.model, "stopped": resp.stop_reason}
        messages.append({"role": "assistant", "content": resp.content})          # full content: thinking and tool_use blocks must be returned unchanged
        results = []
        for block in resp.content:
            if block.type != "tool_use":
                continue
            args = block.input if isinstance(block.input, dict) else {}
            try:
                out = run_tool(db, p, block.name, args)
                payload, err = json.dumps(out, default=str), False
            except ValidationError as exc:
                payload, err = "Error: " + "; ".join(exc.errors), True
            except Exception as exc:                        # a tool bug must not end the conversation
                log.exception("assistant tool %s failed", block.name)
                payload, err = f"Error: the tool failed ({type(exc).__name__}).", True
            calls.append({"name": block.name, "input": args, "ok": not err, "bytes": len(payload)})
            results.append({"type": "tool_result", "tool_use_id": block.id, "content": payload, **({"is_error": True} if err else {})})
        messages.append({"role": "user", "content": results})                    # all results in one message
    return {"answer": "The assistant used the maximum number of tool rounds without finishing. Ask a narrower question.", "tool_calls": calls,
            "usage": usage, "model": MODEL, "stopped": "max_turns"}
