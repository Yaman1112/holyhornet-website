"""Starter component library.

Every value below was transcribed from the cited manufacturer / official
documentation page on the retrieval date shown. Nothing is filled in from memory:
where a page did not state a value, the field is simply absent and the application
reports it as missing. Values that are derived or come from a non-authoritative
source are tagged "estimate" with the basis in the note.

Web pages change and transcription can introduce errors. Treat this library as a
starting point and verify against the current datasheet before relying on a value
for a flight-critical decision.
"""
from __future__ import annotations

from .units import delta_to_si, to_si

RETRIEVED = "2026-11-16"
SEED_VERSION = "1"


def v(value, unit=None, p="manufacturer", s="s1", note=None, tol=None):
    """Spec value; numeric values are converted from the source's unit to SI."""
    entry = {"value": to_si(value, unit) if unit else value, "provenance": p}
    if isinstance(entry["value"], int) and not isinstance(entry["value"], bool):
        entry["value"] = float(entry["value"])
    if s and p != "user":
        entry["source_id"] = s
    if p == "estimate" and s is None:
        entry.pop("source_id", None)
    if note:
        entry["note"] = note
    if tol is not None:
        entry["uncertainty"] = delta_to_si(tol, unit)
    return entry


def src(ref, kind, title, url, note=""):
    return {"ref": ref, "kind": kind, "title": title, "url": url, "retrieved_on": RETRIEVED, "note": note}


def thrust(propeller, voltage, rows, note, s="s1", cols=("throttle", "current", "power", "thrust", "speed")):
    """rows are in the source's units: throttle %, V, A, W, gf, rpm, N*m."""
    conv = {"throttle": lambda x: x / 100.0, "voltage": float, "current": float, "power": float,
            "thrust": lambda x: to_si(x, "gf"), "speed": lambda x: to_si(x, "rpm"), "torque": float}
    return {"propeller": propeller, "voltage": voltage, "provenance": "manufacturer", "source_id": s, "note": note,
            "points": [{c: conv[c](x) for c, x in zip(cols, row)} for row in rows]}


TM_NOTE = ("Manufacturer static bench test; T-Motor states the data is for reference only. "
           "Motor surface temperature in the note is at 100% throttle after 10 minutes.")
MN5008_COLS = ("throttle", "voltage", "current", "power", "speed", "torque", "thrust")

COMPONENTS = [
    # ------------------------------------------------------------------ motors
    {
        "category": "motor", "manufacturer": "T-Motor", "model": "MN4014 KV330",
        "description": "Navigator-series outrunner for large multirotors.",
        "sources": [src("s1", "manufacturer_page", "T-Motor store — MN4014 KV330 product page (specifications and test report MN.00026)",
                        "https://store.tmotor.com/product/mn4014-kv330-motor-navigator-type.html",
                        "The page states max thrust as 2.6 kg in one place and 3.3 kg in another; the 22.2 V test table peaks at 2600 g, so 2.6 kg is recorded.")],
        "specs": {
            "kv": v(330), "cells_min": v(4), "cells_max": v(8),
            "max_current": v(25, "A"), "max_current_duration": v(180, "s"), "max_power": v(750, "W"),
            "internal_resistance": v(85, "mohm"),
            "idle_current": v(1.1, "A"), "idle_current_voltage": v(10, "V"),
            "pole_config": v("18N24P"),
            "weight": v(171, "g", note="Including cables."), "weight_excl_cables": v(150, "g"),
            "shaft_diameter": v(4, "mm"), "stator_diameter": v(40, "mm"), "stator_height": v(14, "mm"),
            "outer_diameter": v(44.7, "mm"), "body_length": v(34.5, "mm"),
            "lead_wire": v("18 AWG, 600 mm"),
            "recommended_propellers": v(["T-Motor P17x5.8"]), "recommended_esc": v("T-Motor AIR 40A (2-6S)"),
            "max_thrust": v(2.6, "kgf", note="Page is inconsistent (2.6 kg / 3.3 kg); 2.6 kg matches the 22.2 V test table with the 17x5.8 propeller."),
        },
        "thrust_tests": [
            thrust("T-Motor 15x5 CF", 22.2, [(50, 3.6, 79.92, 830, 3900), (65, 5.9, 130.98, 1150, 4600), (75, 7.8, 173.16, 1430, 5100),
                                             (85, 10.1, 224.22, 1690, 5600), (100, 11.9, 264.18, 1920, 6000)], TM_NOTE + " 45 °C."),
            thrust("T-Motor 16x5.4 CF", 22.2, [(50, 4.3, 95.46, 950, 3700), (65, 7.0, 155.40, 1420, 4400), (75, 9.6, 213.12, 1750, 4900),
                                               (85, 12.5, 277.50, 2060, 5400), (100, 14.7, 326.34, 2390, 5600)], TM_NOTE + " 50 °C."),
            thrust("T-Motor 17x5.8 CF", 22.2, [(50, 4.7, 104.34, 1050, 3400), (65, 8.0, 177.60, 1580, 4100), (75, 10.7, 237.54, 1970, 4600),
                                               (85, 14.4, 319.68, 2300, 5100), (100, 17.0, 377.40, 2600, 5400)], TM_NOTE + " 55 °C."),
        ],
    },
    {
        "category": "motor", "manufacturer": "T-Motor", "model": "MN5008 KV340",
        "description": "Antigravity-series low-profile outrunner.",
        "sources": [src("s1", "manufacturer_page", "T-Motor store — MN5008 KV340 product page (specifications and thrust test)",
                        "https://store.tmotor.com/product/mn5008-kv340-motor-antigravity-type.html")],
        "specs": {
            "kv": v(340),
            "cells_min": v(6, note="Page lists 6S for KV340; the MN5008 product range as a whole is listed as 6-12S."),
            "cells_max": v(6, note="See LiPo cells min."),
            "max_current": v(35, "A"), "max_current_duration": v(180, "s"), "max_power": v(760, "W"),
            "internal_resistance": v(55, "mohm"),
            "idle_current": v(0.9, "A"), "idle_current_voltage": v(22, "V"),
            "pole_config": v("24N28P"),
            "weight": v(135, "g", note="Including cable."),
            "shaft_diameter": v(6, "mm"), "outer_diameter": v(55.6, "mm"), "body_length": v(32, "mm"),
            "recommended_propellers": v(["T-Motor P17", "T-Motor P18"]), "recommended_esc": v("T-Motor AIR 40A"),
        },
        "thrust_tests": [
            thrust("T-Motor P17x5.8 CF", 23.1, [
                (40, 23.47, 2.88, 68, 3057, 0.16, 776), (45, 23.43, 3.98, 93, 3443, 0.19, 986), (50, 23.38, 5.33, 125, 3835, 0.24, 1224),
                (55, 23.33, 6.86, 160, 4191, 0.28, 1455), (60, 23.27, 8.53, 199, 4511, 0.34, 1697), (65, 23.21, 10.38, 241, 4808, 0.38, 1936),
                (70, 23.15, 12.40, 287, 5097, 0.42, 2176), (75, 23.08, 14.71, 339, 5392, 0.48, 2440), (80, 23.00, 17.16, 395, 5674, 0.53, 2701),
                (90, 22.82, 23.18, 529, 6230, 0.65, 3277), (100, 22.72, 26.39, 600, 6482, 0.69, 3556)],
                TM_NOTE + " 61 °C. Supply voltage was measured per point (22.72-23.47 V); the header value is the mean.", cols=MN5008_COLS),
            thrust("T-Motor P18x6.1 CF", 23.1, [
                (40, 23.44, 3.76, 88, 2958, 0.21, 996), (45, 23.39, 5.12, 120, 3314, 0.27, 1238), (50, 23.33, 6.93, 162, 3677, 0.32, 1541),
                (55, 23.26, 8.95, 208, 4013, 0.38, 1822), (60, 23.19, 11.12, 258, 4303, 0.45, 2120), (65, 23.11, 13.46, 311, 4579, 0.50, 2394),
                (70, 23.04, 16.01, 369, 4846, 0.56, 2675), (75, 22.95, 18.83, 432, 5111, 0.62, 2966), (80, 22.86, 22.02, 503, 5370, 0.70, 3262),
                (90, 22.63, 29.46, 667, 5842, 0.83, 3909), (100, 22.51, 33.50, 754, 6049, 0.89, 4215)],
                TM_NOTE + " 88 °C. Supply voltage was measured per point (22.51-23.44 V); the header value is the mean.", cols=MN5008_COLS),
        ],
    },
    # ------------------------------------------------------------------ ESC
    {
        "category": "esc", "manufacturer": "T-Motor", "model": "AIR 40A",
        "variant": "2-6S, no BEC",
        "description": "Multirotor ESC. The manufacturer store page gives only headline figures; burst current, weight and dimensions are not stated there.",
        "sources": [
            src("s1", "manufacturer_page", "T-Motor store — AIR 40A 2-6S (no BEC) product page", "https://store.tmotor.com/goods.php?id=368",
                "No specification table on this page: continuous/burst breakdown, weight and size are not listed."),
            src("s2", "reseller", "Reseller listings for the AIR 40A (RobotShop, GetFPV)", "https://www.getfpv.com/tiger-motor-air-esc-40a-600hz-2-6s.html",
                "Resellers agree on 26 g but disagree on dimensions and on burst current (50 A vs 60 A)."),
        ],
        "specs": {
            "continuous_current": v(40, "A", note="Page describes the product as a '40A' ESC without a continuous/burst breakdown."),
            "cells_min": v(2), "cells_max": v(6),
            "bec": v("none"),
            "signal_frequency_max": v(621, "Hz"),
            "weight": v(26, "g", p="estimate", s="s2", note="Not on the manufacturer page. Reseller listings agree on 26 g; unverified."),
        },
    },
    # ------------------------------------------------------------------ propeller
    {
        "category": "propeller", "manufacturer": "T-Motor", "model": "P15x5",
        "variant": "polished carbon fibre",
        "description": "15 x 5 in carbon-fibre multirotor propeller, sold as a CW/CCW pair.",
        "sources": [src("s1", "manufacturer_page", "T-Motor store — P15*5 Prop (2 pcs/pair) product page", "https://store.tmotor.com/goods.php?id=381")],
        "specs": {
            "diameter": v(381, "mm"), "pitch": v(127, "mm"),
            "blade_count": v(2, p="estimate", s=None, note="Not labelled on the page; the product is a conventional two-blade propeller."),
            "material": v("CF + epoxy"),
            "weight": v(21, "g", tol=1.5), "weight_basis": v("Stated as 'single blade' (one propeller of the pair)."),
            "rpm_min": v(5200, "rpm"), "rpm_max": v(7000, "rpm"),
            "thrust_limit": v(6, "kgf"),
            "temp_min": v(-40, "degC"), "temp_max": v(65, "degC"),
        },
    },
    # ------------------------------------------------------------------ battery
    {
        "category": "battery", "manufacturer": "Tattu", "model": "12000mAh 6S1P 15C",
        "variant": "AS150+XT150",
        "description": "22.2 V LiPo pack (SKU TA-15C-12000-6S1P-AS150).",
        "sources": [src("s1", "manufacturer_page", "Gens Ace / Tattu — 12000mAh 6S1P 15C LiPo with AS150+XT150 plug",
                        "https://genstattu.com/tattu-12000mah-6s1p-15c-lipo-battery-pack-with-as150-xt150-plug.html",
                        "Internal resistance is not stated ('low IR value' only).")],
        "specs": {
            "chemistry": v("LiPo"), "cell_count": v(6), "parallel_count": v(1),
            "nominal_voltage": v(22.2, "V"), "capacity": v(12000, "mAh", note="Stated as minimum capacity."),
            "c_rating": v(15), "c_rating_burst": v(30),
            "max_discharge_current": v(180, "A", p="estimate", s=None, note="Derived: continuous C-rating × capacity = 15 × 12 Ah."),
            "connector": v("AS150 + XT150"), "balance_connector": v("JST-XHR"), "wire_gauge": v("10 AWG"),
            "weight": v(1620, "g", tol=20),
            "length": v(184, "mm"), "width": v(71, "mm"), "height": v(61, "mm"),
            "part_number": v("TA-15C-12000-6S1P-AS150"),
        },
    },
    # ------------------------------------------------------------------ flight controllers
    {
        "category": "flight_controller", "manufacturer": "Holybro", "model": "Pixhawk 6C",
        "variant": "aluminium case",
        "description": "FMUv6C autopilot.",
        "sources": [
            src("s1", "official_docs", "Holybro docs — Pixhawk 6C technical specification", "https://docs.holybro.com/autopilot/pixhawk-6c/technical-specification"),
            src("s2", "official_docs", "PX4 user guide — Holybro Pixhawk 6C", "https://docs.px4.io/main/en/flight_controller/pixhawk6c.html",
                "Lists the second IMU as BMI055 and a 0-42 V absolute maximum for the servo rail."),
        ],
        "specs": {
            "processor": v("STM32H743 (Arm Cortex-M7, 480 MHz, 2 MB flash, 1 MB RAM)"),
            "io_processor": v("STM32F103 (Arm Cortex-M3, 72 MHz, 64 KB SRAM)"),
            "imu": v(["ICM-42688-P", "BMI088"], note="Standard version per Holybro. Holybro also lists a newer sensor set, and the PX4 guide lists BMI055 as the second IMU — check the revision of the board in hand."),
            "barometer": v(["MS5611"]), "magnetometer": v(["IST8310"]),
            "uart_ports": v(3, note="TELEM1, TELEM2, TELEM3."), "gps_ports": v(2),
            "can_interfaces": v(2), "i2c_ports": v(1),
            "pwm_outputs": v(16, note="8 from IO, 8 from FMU."),
            "rc_inputs": v(["Spektrum/DSM", "S.BUS", "CPPM"], s="s2"),
            "supported_firmware": v(["PX4"], s="s2", note="Only firmware confirmed from a retrieved source is listed."),
            "power_inputs": v("2 analog power input ports"),
            "max_input_voltage": v(6, "V"), "servo_rail_voltage_max": v(36, "V"),
            "usb_voltage_min": v(4.75, "V"), "usb_voltage_max": v(5.25, "V"),
            "weight": v(59.3, "g", note="Aluminium case. Plastic case: 34.6 g."),
            "length": v(84.8, "mm"), "width": v(44, "mm"), "height": v(12.4, "mm"),
            "temp_min": v(-25, "degC"), "temp_max": v(85, "degC"),
        },
    },
    {
        "category": "flight_controller", "manufacturer": "Holybro", "model": "Pixhawk 6X",
        "variant": "Rev 8 module + standard baseboard",
        "description": "FMUv6X autopilot module on the Holybro standard baseboard.",
        "sources": [src("s1", "official_docs", "Holybro docs — Pixhawk 6X technical specification", "https://docs.holybro.com/autopilot/pixhawk-6x/technical-specification")],
        "specs": {
            "processor": v("STM32H753 (Arm Cortex-M7, 480 MHz, 2 MB flash, 1 MB RAM)"),
            "io_processor": v("STM32F103 (Arm Cortex-M3, 72 MHz, 64 KB SRAM)"),
            "imu": v(["3x ICM-45686"], note="Rev 8. Rev 3/4 boards carry BMI088 or ICM-20649, ICM-42688-P and ICM-42670-P."),
            "barometer": v(["ICP20100", "BMP388/580/581"], note="Rev 8. Rev 3/4: 2x BMP388."),
            "magnetometer": v(["BMM150"]),
            "uart_ports": v(4), "gps_ports": v(2), "can_interfaces": v(2),
            "pwm_outputs": v(16, note="3.3 V / 5 V signal level is hardware-switchable (requires baseboard modification)."),
            "max_input_voltage": v(6, "V"), "servo_rail_voltage_max": v(36, "V"),
            "usb_voltage_min": v(4.75, "V"), "usb_voltage_max": v(5.25, "V"),
            "weight": v(74, "g", p="estimate", note="Sum of the stated module (23 g) and standard baseboard (51 g) weights."),
            "length": v(103.4, "mm", note="Standard baseboard."), "width": v(52.4, "mm"), "height": v(16.7, "mm"),
        },
    },
    {
        "category": "flight_controller", "manufacturer": "CubePilot", "model": "Cube Orange",
        "description": "Autopilot module. The retrieved CubePilot page lists interfaces only; processor, sensor part numbers, weight and electrical limits were not on it.",
        "sources": [src("s1", "official_docs", "CubePilot docs — The Cube specifications", "https://docs.cubepilot.org/autopilot/the-cube/introduction/specifications.md")],
        "specs": {
            "uart_ports": v(5, note="Five general-purpose serial ports, two with full flow control."),
            "can_interfaces": v(2, note="CAN FD supported."), "i2c_ports": v(2),
            "pwm_outputs": v(14, note="8 from the IO chip, 6 from the FMU."),
        },
    },
    # ------------------------------------------------------------------ GNSS
    {
        "category": "gps", "manufacturer": "Holybro", "model": "M10 GPS", "variant": "V2 (IP67)",
        "description": "u-blox M10 GNSS module with compass, LED, buzzer and safety switch.",
        "sources": [src("s1", "official_docs", "Holybro docs — Standard M10/M9N/M8N GPS overview",
                        "https://docs.holybro.com/gps-and-rtk-system/m8n-m9n-m10-gps/standard-m10-m9n-m8n-gps/overview.md")],
        "specs": {
            "receiver": v("u-blox M10"), "constellations": v(["BeiDou", "Galileo", "GLONASS", "GPS", "QZSS"]), "concurrent_gnss": v(4),
            "bands": v(["GPS L1", "Galileo E1", "GLONASS L1", "BeiDou B1", "SBAS L1", "QZSS L1"]),
            "position_accuracy": v("2.0 m CEP"),
            "update_rate_max": v(25, "Hz", note="Single GNSS. Up to 10 Hz with 4 concurrent constellations."),
            "compass": v("IST8310"), "protocols": v(["UBX", "NMEA"]), "default_baud": v(115200),
            "interfaces": v(["UART", "I2C"], p="estimate", note="Not listed as such on the page: inferred from the UBX/NMEA serial output and the I2C IST8310 compass on the 10-pin connector."),
            "connector": v("JST-GH 10-pin"),
            "supply_voltage_min": v(4.7, "V"), "supply_voltage_max": v(5.2, "V"),
            "supply_current": v(200, "mA", note="Stated as 'less than 200 mA @ 5 V'."),
            "weight": v(36.8, "g", note="V2. V1: 32 g."),
            "diameter": v(51, "mm", note="V2. V1: 50 mm."), "height": v(18.5, "mm", note="V2. V1: 14.4 mm."),
            "cable_length": v(26, "cm"), "ingress_protection": v("IP67 (V2 only)"),
            "temp_min": v(-40, "degC"), "temp_max": v(80, "degC"),
        },
    },
    {
        "category": "gps", "manufacturer": "Holybro", "model": "M9N GPS", "variant": "V2 (IP67)",
        "description": "u-blox M9N GNSS module with compass, LED, buzzer and safety switch.",
        "sources": [src("s1", "official_docs", "Holybro docs — Standard M10/M9N/M8N GPS overview",
                        "https://docs.holybro.com/gps-and-rtk-system/m8n-m9n-m10-gps/standard-m10-m9n-m8n-gps/overview.md")],
        "specs": {
            "receiver": v("u-blox M9N"), "constellations": v(["BeiDou", "Galileo", "GLONASS", "GPS", "QZSS"]), "concurrent_gnss": v(4),
            "bands": v(["GPS L1", "Galileo E1", "GLONASS L1", "BeiDou B1", "SBAS L1", "QZSS L1"]),
            "position_accuracy": v("1.5 m CEP"),
            "update_rate_max": v(25, "Hz", note="With 4 concurrent constellations."),
            "compass": v("IST8310"), "protocols": v(["UBX", "NMEA"]), "default_baud": v(115200),
            "interfaces": v(["UART", "I2C"], p="estimate", note="Not listed as such on the page: inferred from the UBX/NMEA serial output and the I2C IST8310 compass on the 10-pin connector."),
            "connector": v("JST-GH 10-pin"),
            "supply_voltage_min": v(4.7, "V"), "supply_voltage_max": v(5.2, "V"),
            "supply_current": v(200, "mA", note="Stated as 'less than 200 mA @ 5 V'."),
            "weight": v(36.8, "g", note="V2. V1: 32 g."),
            "diameter": v(51, "mm", note="V2. V1: 50 mm."), "height": v(18.5, "mm", note="V2. V1: 14.4 mm."),
            "cable_length": v(26, "cm"), "ingress_protection": v("IP67 (V2 only)"),
            "temp_min": v(-40, "degC"), "temp_max": v(80, "degC"),
        },
    },
    # ------------------------------------------------------------------ telemetry
    {
        "category": "telemetry", "manufacturer": "Holybro", "model": "SiK Telemetry Radio V3", "variant": "100 mW",
        "description": "SiK-firmware telemetry radio, sold in 915 MHz and 433 MHz versions.",
        "sources": [src("s1", "official_docs", "Holybro docs — SiK Telemetry Radio V3", "https://docs.holybro.com/radio/sik-telemetry-radio-v3")],
        "specs": {
            "frequency_band": v("902-928 MHz or 414-460 MHz (model dependent)"),
            "tx_power": v(20, note="100 mW."),
            "rx_sensitivity": v("-121 dBm at 2 kbps; -105 dBm at 64 kbps"),
            "air_data_rate": v("2 to 250 kbps (default 64 kbps)"),
            "firmware": v("Open-source SiK"), "default_baud": v(57600),
            "interfaces": v(["UART (3.3 V TTL)", "Micro-USB"]), "connector": v("JST-GH 6-pin"),
            "supply_voltage_min": v(5, "V"), "supply_voltage_max": v(5, "V"),
            "supply_current_peak": v(100, "mA", note="Transmit at 20 dBm."), "rx_current": v(25, "mA", note="At 5 V."),
            "weight": v(23.5, "g"), "weight_basis": v("With antenna."),
            "length": v(53, "mm", note="Without antenna."), "width": v(28, "mm"), "height": v(10.7, "mm"),
        },
    },
    # ------------------------------------------------------------------ power
    {
        "category": "power", "manufacturer": "Holybro", "model": "PM02 V3",
        "description": "Inline power module with regulated 5.2 V output for the flight controller.",
        "sources": [src("s1", "official_docs", "Holybro docs — Power module comparison", "https://docs.holybro.com/power-module-and-pdb/power-module-comparison.md",
                        "Current ratings are the page's 'PCB continuous / burst' figures. Monitoring type is not stated on this page.")],
        "specs": {
            "cells_min": v(2), "cells_max": v(12),
            "continuous_current": v(60, "A"), "burst_current": v(100, "A"), "current_sense_max": v(120, "A"),
            "output_voltage": v(5.2, "V"), "output_current_max": v(3, "A"), "output_count": v(1),
            "connectors": v(["XT60", "JST-GH 1.25 mm 6-pin"]),
            "weight": v(20, "g"), "length": v(25, "mm"), "width": v(25, "mm"), "height": v(10, "mm"),
        },
    },
    {
        "category": "power", "manufacturer": "Holybro", "model": "PM07",
        "description": "Power distribution board with current/voltage sensing and two regulated 5.2 V outputs.",
        "sources": [src("s1", "official_docs", "Holybro docs — Power module comparison", "https://docs.holybro.com/power-module-and-pdb/power-module-comparison.md",
                        "Current ratings are the page's 'PCB continuous / burst' figures. Monitoring type is not stated on this page.")],
        "specs": {
            "cells_min": v(2), "cells_max": v(14),
            "continuous_current": v(90, "A"), "burst_current": v(140, "A"), "current_sense_max": v(120, "A"),
            "output_voltage": v(5.2, "V"), "output_current_max": v(3, "A", note="Per output."), "output_count": v(2),
            "connectors": v(["XT60", "JST-GH 1.25 mm 6-pin x2", "B+ pads x8", "PWM header"]),
            "weight": v(43.8, "g"), "length": v(68, "mm"), "width": v(50, "mm"), "height": v(10, "mm"),
        },
    },
    # ------------------------------------------------------------------ frame
    {
        "category": "frame", "manufacturer": "Holybro", "model": "X500 V2", "variant": "frame kit",
        "description": "500 mm carbon-fibre quadcopter development frame.",
        "sources": [src("s1", "official_docs", "Holybro docs — PX4 Development Kit X500 V2", "https://docs.holybro.com/drone-development-kit/px4-development-kit-x500v2",
                        "Payload and flight-time claims on this page are for the kit's own 2216 KV920 motors, 1045 propellers and a 4S 5000 mAh battery.")],
        "specs": {
            "wheelbase": v(500, "mm"), "weight": v(610, "g"), "arm_count": v(4),
            "material": v("Carbon-fibre twill plates; carbon-fibre tube arms with fibre-reinforced nylon connectors"),
            "arm_tube_diameter": v(16, "mm"), "motor_mount_pattern": v("16 x 16 mm"),
            "body_length": v(144, "mm"), "body_width": v(144, "mm"), "plate_spacing": v(28, "mm"),
            "landing_gear_height": v(215, "mm"),
            "max_payload": v(1, "kg", note="'About 1 kg' with the kit powertrain and a 4S 5000 mAh battery at 70% throttle — not a structural limit."),
            "recommended_battery": v("4S 2000-5000 mAh LiPo"),
        },
    },
    # ------------------------------------------------------------------ rangefinder
    {
        "category": "rangefinder", "manufacturer": "Benewake", "model": "TFmini-S",
        "description": "Single-point ToF LiDAR distance sensor.",
        "sources": [src("s1", "manufacturer_page", "Benewake — TFmini-S product page", "https://en.benewake.com/TFminiS/index.html",
                        "Supply voltage, field of view and distance resolution are not stated on this page.")],
        "specs": {
            "sensor_type": v("Single-point ToF LiDAR"),
            "range_min": v(0.1), "range_max": v(12), "range_unit": v("m"),
            "accuracy": v("± 6 cm within 0.1-6 m"),
            "sample_rate_min": v(1, "Hz"), "sample_rate_max": v(1000, "Hz"),
            "interfaces": v(["UART", "I2C", "I/O"]),
            "supply_current": v(140, "mA", note="Stated as average current ≤ 140 mA."),
            "power_consumption": v(0.7, "W", note="Stated as ≤ 0.7 W."),
            "weight": v(5, "g", tol=0.3),
            "length": v(42, "mm"), "width": v(15, "mm"), "height": v(16, "mm"),
        },
    },
]
