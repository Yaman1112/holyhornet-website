from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import config, db, seed_data
from .api import components as components_api
from .api import projects as projects_api
from .api import system as system_api
from .api import flight as flight_api
from .api import testing as testing_api
from .api import analysis as analysis_api
from .services import components as csvc

log = logging.getLogger("quadlab")


def setup_logging() -> None:
    if any(isinstance(h, RotatingFileHandler) for h in log.handlers):
        return
    handler = RotatingFileHandler(config.log_path(), maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(name)s  %(message)s"))
    log.addHandler(handler)
    log.setLevel(logging.INFO)


def seed_library() -> None:
    """Load the starter library once per database."""
    Session = db.session_factory()
    with Session() as session:
        if session.get(db.Flag, "seed_version") is not None:
            return
        created = csvc.import_components(
            session, {"format": "quadlab.components/1", "components": seed_data.COMPONENTS}, origin="library")
        session.add(db.Flag(key="seed_version", value=seed_data.SEED_VERSION))
        session.commit()
        log.info("seeded starter library: %d components", len(created))


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    db.init_engine()
    seed_library()
    from .services import telemetry
    with db.session_factory()() as session:
        telemetry.close_orphans(session)
    log.info("%s %s started (database %s)", config.APP_NAME, config.APP_VERSION, config.database_url().split("@")[-1])
    yield
    from .services.link import LINK
    LINK.disconnect()


def create_app() -> FastAPI:
    app = FastAPI(title=config.APP_NAME, version=config.APP_VERSION, lifespan=lifespan)
    app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3850", "http://127.0.0.1:3850"],
                       allow_methods=["*"], allow_headers=["*"])

    @app.middleware("http")
    async def access_log(request: Request, call_next):
        start = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            log.exception("unhandled error: %s %s", request.method, request.url.path)
            return JSONResponse({"detail": "Internal error. See Settings → Diagnostics for the log."}, status_code=500)
        if request.url.path.startswith("/api") and (request.method != "GET" or response.status_code >= 400):
            log.info("%s %s -> %d (%.0f ms)", request.method, request.url.path, response.status_code,
                     (time.perf_counter() - start) * 1000)
        return response

    @app.exception_handler(csvc.ValidationError)
    async def _validation(_: Request, exc: csvc.ValidationError):
        return JSONResponse({"detail": "Validation failed", "errors": exc.errors}, status_code=422)

    @app.exception_handler(csvc.NotFound)
    async def _not_found(_: Request, exc: csvc.NotFound):
        return JSONResponse({"detail": str(exc)}, status_code=404)

    @app.exception_handler(csvc.Conflict)
    async def _conflict(_: Request, exc: csvc.Conflict):
        return JSONResponse({"detail": str(exc)}, status_code=409)

    app.include_router(system_api.router)
    app.include_router(components_api.router)
    app.include_router(projects_api.router)
    app.include_router(projects_api.compare_router)
    app.include_router(flight_api.router)
    app.include_router(testing_api.router)
    app.include_router(analysis_api.router)

    dist = config.frontend_dist()
    if (dist / "index.html").is_file():
        app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

        @app.get("/{path:path}", include_in_schema=False)
        def spa(path: str):
            target = (dist / path).resolve()
            if path and target.is_file() and dist.resolve() in target.parents:
                return FileResponse(target)
            return FileResponse(dist / "index.html")

    return app


app = create_app()
