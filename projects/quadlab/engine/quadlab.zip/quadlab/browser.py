"""Browser edition bridge: the unmodified QuadLab FastAPI application inside Pyodide (CPython on WebAssembly).

The Web Worker (frontend/public/engine/worker.js) prepares the data folder, calls ``boot(data_dir)`` once and then
``request(method, path, headers_json, body)`` for every API call. Requests run through the real ASGI app, so
validation, the engineering services and the database behave exactly as in the desktop edition.

Deliberate differences from the desktop edition:
* no threads: sync endpoints run inline;
* no vehicle link, live telemetry or recording: a web page cannot open UDP/TCP sockets or serial ports, and the
  link endpoints say so instead of pretending (see services/link.py);
* no AI assistant: it needs the user's own Anthropic API key, which the browser edition does not store or send;
* data lives in the visitor's browser storage only; nothing is sent anywhere.
"""
from __future__ import annotations

import json
import os

_app = None


def _no_threads() -> None:
    import anyio.to_thread

    async def run_sync(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):  # noqa: ARG001
        return func(*args)

    anyio.to_thread.run_sync = run_sync


def boot(data_dir: str) -> dict:
    global _app
    import time

    t = time.time()
    # MAVLINK_DIALECT: only the ardupilotmega dialect is shipped (it is the one the log importers ask for)
    os.environ.update({"QUADLAB_BROWSER": "1", "QUADLAB_DATA_DIR": data_dir, "QUADLAB_FRONTEND_DIST": "/nonexistent",
                       "MAVLINK_DIALECT": "ardupilotmega"})
    _no_threads()
    from . import config, db, main
    from .services import telemetry

    # what the server's lifespan does at start-up
    main.setup_logging()
    db.init_engine()
    main.seed_library()
    with db.session_factory()() as session:
        telemetry.close_orphans(session)
    _app = main.app
    return {"ok": True, "boot_s": round(time.time() - t, 2), "version": config.APP_VERSION}


async def request(method: str, path: str, headers_json: str = "{}", body: bytes | None = None) -> dict:
    if _app is None:
        raise RuntimeError("call boot() first")
    headers = json.loads(headers_json or "{}")
    p, _, qs = path.partition("?")
    raw_body = bytes(body) if body is not None and type(body).__name__ != "JsNull" else b""
    hdrs = [(k.lower().encode(), str(v).encode()) for k, v in headers.items()]
    hdrs.append((b"host", b"quadlab.local"))
    if raw_body:
        hdrs.append((b"content-length", str(len(raw_body)).encode()))
    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(), "scheme": "http",
             "path": p, "raw_path": p.encode(), "query_string": qs.encode(), "root_path": "", "headers": hdrs,
             "client": ("browser", 0), "server": ("quadlab.local", 80)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": raw_body, "more_body": False}
        return {"type": "http.disconnect"}

    out = {"status": 500, "headers": [], "body": b""}
    chunks: list[bytes] = []

    async def send(msg):
        if msg["type"] == "http.response.start":
            out["status"] = msg["status"]
            out["headers"] = [[k.decode(), v.decode()] for k, v in msg.get("headers", [])]
        elif msg["type"] == "http.response.body":
            chunks.append(msg.get("body", b""))

    await _app(scope, receive, send)
    out["body"] = b"".join(chunks)
    return out
