"""Unit system.

All numeric specifications are stored in the internal (SI-coherent) unit of their
quantity. Display units are a presentation concern: the frontend converts with the
same table, served by /api/meta, so there is exactly one conversion table.

Conversion model:  si = x * factor + offset

Documented exceptions to strict SI (industry-standard, kept because converting them
adds no engineering value and invites transcription errors):
  * temperature is stored in degrees Celsius (an SI-accepted unit) rather than kelvin
  * motor velocity constant KV is stored in rpm/V
  * battery C-rating is stored as a multiple of capacity per hour (1/h)
"""
from __future__ import annotations

import math

# unit -> (quantity, factor, offset)
UNITS: dict[str, tuple[str, float, float]] = {
    "kg": ("mass", 1.0, 0.0),
    "g": ("mass", 1e-3, 0.0),
    "oz": ("mass", 0.028349523125, 0.0),
    "lb": ("mass", 0.45359237, 0.0),
    "m": ("length", 1.0, 0.0),
    "cm": ("length", 1e-2, 0.0),
    "mm": ("length", 1e-3, 0.0),
    "in": ("length", 0.0254, 0.0),
    "V": ("voltage", 1.0, 0.0),
    "A": ("current", 1.0, 0.0),
    "mA": ("current", 1e-3, 0.0),
    "W": ("power", 1.0, 0.0),
    "ohm": ("resistance", 1.0, 0.0),
    "mohm": ("resistance", 1e-3, 0.0),
    "Hz": ("frequency", 1.0, 0.0),
    "kHz": ("frequency", 1e3, 0.0),
    "MHz": ("frequency", 1e6, 0.0),
    "N": ("force", 1.0, 0.0),
    "gf": ("force", 9.80665e-3, 0.0),
    "kgf": ("force", 9.80665, 0.0),
    "lbf": ("force", 4.4482216152605, 0.0),
    "As": ("charge", 1.0, 0.0),
    "Ah": ("charge", 3600.0, 0.0),
    "mAh": ("charge", 3.6, 0.0),
    "rad/s": ("angular_velocity", 1.0, 0.0),
    "rpm": ("angular_velocity", 2.0 * math.pi / 60.0, 0.0),
    "degC": ("temperature", 1.0, 0.0),
    "degF": ("temperature", 5.0 / 9.0, -160.0 / 9.0),
    "N*m": ("torque", 1.0, 0.0),
    "s": ("time", 1.0, 0.0),
}

# quantity -> internal unit
SI_UNIT: dict[str, str] = {
    "mass": "kg",
    "length": "m",
    "voltage": "V",
    "current": "A",
    "power": "W",
    "resistance": "ohm",
    "frequency": "Hz",
    "force": "N",
    "charge": "As",
    "angular_velocity": "rad/s",
    "temperature": "degC",
    "torque": "N*m",
    "time": "s",
}

# quantity -> display unit per unit system (falls back to the internal unit)
DISPLAY: dict[str, dict[str, str]] = {
    "metric": {
        "mass": "g",
        "length": "mm",
        "resistance": "mohm",
        "charge": "mAh",
        "angular_velocity": "rpm",
    },
    "imperial": {
        "mass": "oz",
        "length": "in",
        "resistance": "mohm",
        "charge": "mAh",
        "angular_velocity": "rpm",
        "force": "lbf",
        "temperature": "degF",
    },
}

LABELS: dict[str, str] = {
    "ohm": "Ω",
    "mohm": "mΩ",
    "degC": "°C",
    "degF": "°F",
    "As": "A·s",
    "N*m": "N·m",
}

G0 = 9.80665  # standard gravity, m/s^2


def to_si(value: float, unit: str) -> float:
    try:
        _, factor, offset = UNITS[unit]
    except KeyError as exc:
        raise ValueError(f"unknown unit '{unit}'") from exc
    return value * factor + offset


def from_si(value: float, unit: str) -> float:
    try:
        _, factor, offset = UNITS[unit]
    except KeyError as exc:
        raise ValueError(f"unknown unit '{unit}'") from exc
    return (value - offset) / factor


def delta_to_si(value: float, unit: str) -> float:
    """Convert a difference / tolerance (no offset applied)."""
    return value * UNITS[unit][1]


def quantity_of(unit: str) -> str:
    return UNITS[unit][0]


def meta() -> dict:
    return {
        "units": {u: {"quantity": q, "factor": f, "offset": o, "label": LABELS.get(u, u)} for u, (q, f, o) in UNITS.items()},
        "si_unit": SI_UNIT,
        "display": DISPLAY,
    }
