"""Customers, customer projects, lifecycle stage, milestones, team, feedback, dashboard."""
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..schemas import (AcceptanceIn, CustomerIn, FeedbackIn, FeedbackResponseIn, MemberIn, MilestoneIn,
                       MilestonePatch, ProjectIn, ProjectPatch, StageIn)
from ..security import (ROLES, audit, can, check_project_write, current_user, get_project_or_404, require,
                        visible_project_ids)
from ..services import engineering as E
from ..services.records import record_revision, revision_count, to_dict

router = APIRouter(prefix="/api/v1", tags=["projects"])
STAGE_LABEL = dict(M.STAGES)


# ---------------------------------------------------------------- customers
@router.get("/customers")
def list_customers(user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    q = db.query(M.Customer).order_by(M.Customer.name)
    if user.role == "CUSTOMER_VIEWER":
        ids = visible_project_ids(db, user) or set()
        cust = {c for (c,) in db.query(M.Project.customer_id).filter(M.Project.id.in_(ids))}
        q = q.filter(M.Customer.id.in_(cust))
    counts = dict(db.query(M.Project.customer_id, func.count(M.Project.id)).group_by(M.Project.customer_id).all())
    return [to_dict(c) | {"project_count": counts.get(c.id, 0)} for c in q]


@router.post("/customers", status_code=201)
def create_customer(body: CustomerIn, request: Request, user: M.User = Depends(require("customers.write")),
                    db: Session = Depends(get_db)):
    c = M.Customer(**body.model_dump())
    db.add(c)
    db.flush()
    audit(db, user, "create", "customer", c.id, summary=f"Registered customer {c.name}", request=request)
    db.commit()
    return to_dict(c)


@router.patch("/customers/{cid}")
def update_customer(cid: int, body: CustomerIn, request: Request, user: M.User = Depends(require("customers.write")),
                    db: Session = Depends(get_db)):
    c = db.get(M.Customer, cid)
    if not c:
        raise HTTPException(404, "Customer not found")
    for k, v in body.model_dump().items():
        setattr(c, k, v)
    audit(db, user, "update", "customer", c.id, summary=f"Updated customer {c.name}", request=request)
    db.commit()
    return to_dict(c)


# ---------------------------------------------------------------- projects
def _project_out(db: Session, p: M.Project, user: M.User, full: bool = False) -> dict:
    reqs = E.load_requirements(db, p.id)
    d = to_dict(p)
    if not can(user, "internal.view"):
        d.pop("internal_notes", None)
    d["customer_name"] = p.customer.name if p.customer else None
    d["stage_label"] = STAGE_LABEL.get(p.stage, p.stage)
    lead = db.get(M.User, p.lead_engineer_id) if p.lead_engineer_id else None
    d["lead_engineer"] = lead.full_name if lead else None
    d["readiness"] = E.readiness(db, p, reqs)
    cov = E.coverage(db, p.id, reqs)
    d["requirements_summary"] = {k: cov[k] for k in ("total", "mandatory", "by_status", "allocated",
                                                     "with_validation_evidence")}
    d["alerts"] = E.alerts(db, p, reqs)
    d["hardware_count"] = db.query(func.count(M.HardwareItem.id)).filter_by(project_id=p.id).scalar()
    d["software_count"] = db.query(func.count(M.SoftwareItem.id)).filter_by(project_id=p.id).scalar()
    d["revision"] = revision_count(db, "project", p.id)
    if full:
        d["customer"] = to_dict(p.customer)
        d["delivery_gate"] = E.delivery_gate(db, p.id, reqs)
        from ..services.delivery import final_gate
        d["final_gate"] = final_gate(db, p.id)
        d["milestones"] = [to_dict(m) for m in db.query(M.Milestone).filter_by(project_id=p.id)
                           .order_by(M.Milestone.due_date.is_(None), M.Milestone.due_date)]
        d["members"] = [{"id": m.id, "user_id": m.user_id, "full_name": m.user.full_name,
                         "role_label": ROLES.get(m.user.role), "project_role": m.project_role}
                        for m in db.query(M.ProjectMember).filter_by(project_id=p.id)]
        d["stage_history"] = [to_dict(h) for h in db.query(M.StageHistory).filter_by(project_id=p.id)
                              .order_by(M.StageHistory.id.desc())]
        d["feedback"] = [to_dict(f) for f in db.query(M.CustomerFeedback).filter_by(project_id=p.id)
                         .order_by(M.CustomerFeedback.id.desc())]
    return d


@router.get("/projects")
def list_projects(stage: str | None = None, domain: str | None = None, customer_id: int | None = None,
                  q: str | None = None, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    qry = db.query(M.Project).order_by(M.Project.code)
    ids = visible_project_ids(db, user)
    if ids is not None:
        qry = qry.filter(M.Project.id.in_(ids))
    if stage:
        qry = qry.filter(M.Project.stage == stage)
    if domain:
        qry = qry.filter(M.Project.domain == domain)
    if customer_id:
        qry = qry.filter(M.Project.customer_id == customer_id)
    if q:
        like = f"%{q}%"
        qry = qry.filter(M.Project.name.ilike(like) | M.Project.code.ilike(like))
    return [_project_out(db, p, user) for p in qry]


def _next_code(db: Session) -> str:
    year = date.today().year
    n = db.query(func.count(M.Project.id)).filter(M.Project.code.like(f"INT-{year}-%")).scalar() or 0
    while True:
        n += 1
        code = f"INT-{year}-{n:03d}"
        if not db.query(M.Project.id).filter_by(code=code).first():
            return code


@router.post("/projects", status_code=201)
def create_project(body: ProjectIn, request: Request, user: M.User = Depends(require("projects.create")),
                   db: Session = Depends(get_db)):
    if not db.get(M.Customer, body.customer_id):
        raise HTTPException(422, "customer_id: customer does not exist")
    if body.start_date and body.target_date and body.target_date < body.start_date:
        raise HTTPException(422, "target_date is before start_date")
    p = M.Project(code=_next_code(db), **body.model_dump())
    db.add(p)
    db.flush()
    db.add(M.StageHistory(project_id=p.id, from_stage=None, to_stage=p.stage, changed_by=user.username,
                          note="Project created"))
    db.add(M.ProjectMember(project_id=p.id, user_id=user.id, project_role="Project creator"))
    record_revision(db, "project", p, user.username, "Created")
    audit(db, user, "create", "project", p.id, project_id=p.id, summary=f"Created project {p.code} {p.name}",
          request=request)
    db.commit()
    return _project_out(db, p, user, full=True)


@router.get("/projects/{pid}")
def get_project(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    return _project_out(db, get_project_or_404(db, user, pid), user, full=True)


@router.patch("/projects/{pid}")
def update_project(pid: int, body: ProjectPatch, request: Request, user: M.User = Depends(require("projects.write")),
                   db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    changes = body.model_dump(exclude_unset=True)
    comment = changes.pop("comment", None)
    if "customer_id" in changes and not db.get(M.Customer, changes["customer_id"]):
        raise HTTPException(422, "customer_id: customer does not exist")
    for k, v in changes.items():
        setattr(p, k, v)
    if p.start_date and p.target_date and p.target_date < p.start_date:
        raise HTTPException(422, "target_date is before start_date")
    db.flush()
    rev = record_revision(db, "project", p, user.username, comment)
    audit(db, user, "update", "project", p.id, project_id=p.id, summary=f"Updated {p.code}",
          detail={"fields": rev.changed_fields if rev else []}, request=request)
    db.commit()
    return _project_out(db, p, user, full=True)


@router.post("/projects/{pid}/stage")
def change_stage(pid: int, body: StageIn, request: Request, user: M.User = Depends(require("projects.stage")),
                 db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    if body.stage == p.stage:
        raise HTTPException(400, f"Project is already in stage '{p.stage}'")
    if body.stage == "approved_for_delivery":
        from ..services.delivery import final_gate
        fg = final_gate(db, p.id)
        if not fg["passed"]:
            raise HTTPException(409, {"message": f"Final delivery gate blocks '{STAGE_LABEL[body.stage]}': "
                                                 f"{len(fg['blockers'])} blocker(s) (requirements, approved release, "
                                                 "signed final acceptance)", "blockers": fg["blockers"]})
    elif body.stage in M.GATED_STAGES:
        gate = E.delivery_gate(db, p.id)
        if not gate["passed"]:
            raise HTTPException(409, {"message": f"Delivery gate blocks '{STAGE_LABEL[body.stage]}': "
                                                 f"{len(gate['blockers'])} mandatory requirement(s) lack verified "
                                                 f"status or validation evidence", "blockers": gate["blockers"]})
    old = p.stage
    p.stage = body.stage
    db.add(M.StageHistory(project_id=p.id, from_stage=old, to_stage=p.stage, changed_by=user.username, note=body.note))
    db.flush()
    record_revision(db, "project", p, user.username, f"Stage {old} -> {p.stage}")
    audit(db, user, "stage_change", "project", p.id, project_id=p.id,
          summary=f"{p.code}: {STAGE_LABEL[old]} -> {STAGE_LABEL[p.stage]}", request=request)
    db.commit()
    return _project_out(db, p, user, full=True)


@router.post("/projects/{pid}/acceptance")
def set_acceptance(pid: int, body: AcceptanceIn, request: Request,
                   user: M.User = Depends(require("projects.acceptance")), db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    if body.acceptance_status == "accepted":
        gate = E.delivery_gate(db, p.id)
        if not gate["passed"]:
            raise HTTPException(409, {"message": "Customer acceptance cannot be recorded: mandatory requirements "
                                                 "lack validation evidence", "blockers": gate["blockers"]})
        if not db.query(M.AcceptanceRecord.id).filter_by(project_id=p.id, kind="final", status="accepted").first():
            raise HTTPException(409, {"message": "Customer acceptance is recorded by signing a final acceptance record "
                                                 "(Customer Delivery)", "blockers": []})
    old = p.acceptance_status
    p.acceptance_status = body.acceptance_status
    db.flush()
    record_revision(db, "project", p, user.username, f"Acceptance {old} -> {p.acceptance_status}: {body.note or ''}")
    audit(db, user, "acceptance", "project", p.id, project_id=p.id,
          summary=f"{p.code}: acceptance {old} -> {p.acceptance_status}", detail={"note": body.note}, request=request)
    db.commit()
    return _project_out(db, p, user, full=True)


@router.get("/projects/{pid}/gate")
def gate(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return E.delivery_gate(db, pid)


# ---------------------------------------------------------------- members
@router.post("/projects/{pid}/members", status_code=201)
def add_member(pid: int, body: MemberIn, request: Request, user: M.User = Depends(require("projects.members")),
               db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    u = db.get(M.User, body.user_id)
    if not u:
        raise HTTPException(422, "user_id: user does not exist")
    if db.query(M.ProjectMember).filter_by(project_id=pid, user_id=u.id).first():
        raise HTTPException(409, f"{u.full_name} is already a member")
    m = M.ProjectMember(project_id=pid, user_id=u.id, project_role=body.project_role)
    db.add(m)
    audit(db, user, "member_add", "project", pid, project_id=pid, summary=f"{p.code}: added {u.username} as "
                                                                           f"{body.project_role}", request=request)
    db.commit()
    return {"id": m.id}


@router.delete("/projects/{pid}/members/{mid}")
def remove_member(pid: int, mid: int, request: Request, user: M.User = Depends(require("projects.members")),
                  db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    m = db.query(M.ProjectMember).filter_by(id=mid, project_id=pid).first()
    if not m:
        raise HTTPException(404, "Member not found")
    audit(db, user, "member_remove", "project", pid, project_id=pid, summary=f"{p.code}: removed {m.user.username}",
          request=request)
    db.delete(m)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- milestones
@router.post("/projects/{pid}/milestones", status_code=201)
def add_milestone(pid: int, body: MilestoneIn, request: Request, user: M.User = Depends(require("milestones.write")),
                  db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    m = M.Milestone(project_id=pid, **body.model_dump())
    if m.status == "done":
        m.completed_at = M.utcnow()
    db.add(m)
    db.flush()
    audit(db, user, "create", "milestone", m.id, project_id=pid, summary=f"{p.code}: milestone '{m.name}'",
          request=request)
    db.commit()
    return to_dict(m)


@router.patch("/projects/{pid}/milestones/{mid}")
def update_milestone(pid: int, mid: int, body: MilestonePatch, request: Request,
                     user: M.User = Depends(require("milestones.write")), db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    m = db.query(M.Milestone).filter_by(id=mid, project_id=pid).first()
    if not m:
        raise HTTPException(404, "Milestone not found")
    changes = body.model_dump(exclude_unset=True)
    for k, v in changes.items():
        setattr(m, k, v)
    if changes.get("status") == "done" and not m.completed_at:
        m.completed_at = M.utcnow()
    elif "status" in changes and changes["status"] != "done":
        m.completed_at = None
    audit(db, user, "update", "milestone", m.id, project_id=pid, summary=f"{p.code}: milestone '{m.name}' updated",
          detail={k: str(v) for k, v in changes.items()}, request=request)
    db.commit()
    return to_dict(m)


# ---------------------------------------------------------------- feedback
@router.post("/projects/{pid}/feedback", status_code=201)
def add_feedback(pid: int, body: FeedbackIn, request: Request, user: M.User = Depends(require("feedback.write")),
                 db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    f = M.CustomerFeedback(project_id=pid, author=user.username, category=body.category, text=body.text)
    db.add(f)
    db.flush()
    audit(db, user, "create", "feedback", f.id, project_id=pid, summary=f"{p.code}: {body.category} from "
                                                                        f"{user.username}", request=request)
    db.commit()
    return to_dict(f)


@router.post("/projects/{pid}/feedback/{fid}/response")
def respond_feedback(pid: int, fid: int, body: FeedbackResponseIn, request: Request,
                     user: M.User = Depends(require("feedback.respond")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    f = db.query(M.CustomerFeedback).filter_by(id=fid, project_id=pid).first()
    if not f:
        raise HTTPException(404, "Feedback not found")
    f.response, f.responded_by = body.response, user.username
    audit(db, user, "respond", "feedback", f.id, project_id=pid, request=request)
    db.commit()
    return to_dict(f)


# ---------------------------------------------------------------- dashboard
@router.get("/dashboard")
def dashboard(user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    ids = visible_project_ids(db, user)
    pq = db.query(M.Project)
    if ids is not None:
        pq = pq.filter(M.Project.id.in_(ids))
    projects = pq.order_by(M.Project.code).all()
    rows, all_alerts = [], []
    req_status = {s: 0 for s in M.REQ_STATUS}
    for p in projects:
        reqs = E.load_requirements(db, p.id)
        r = E.readiness(db, p, reqs)
        al = E.alerts(db, p, reqs)
        all_alerts += al
        for x in reqs:
            req_status[x.status] += 1
        rows.append({"id": p.id, "code": p.code, "name": p.name, "customer": p.customer.name, "domain": p.domain,
                     "stage": p.stage, "stage_label": STAGE_LABEL[p.stage], "priority": p.priority,
                     "acceptance_status": p.acceptance_status, "target_date": p.target_date and p.target_date.isoformat(),
                     "readiness": r["score"], "missing_records": r["missing_records"],
                     "requirements": len(reqs), "alerts": len(al),
                     "release": next(({"version": x.version, "status": x.status} for x in db.query(M.Release)
                                      .filter_by(project_id=p.id).order_by(M.Release.id.desc()).limit(1)), None),
                     "critical": sum(1 for a in al if a["severity"] == "critical")})
    pids = [p.id for p in projects]
    internal = can(user, "internal.view")
    hw_q = db.query(M.HardwareItem.status, func.count(M.HardwareItem.id)).group_by(M.HardwareItem.status)
    sw_q = db.query(M.SoftwareItem.status, func.count(M.SoftwareItem.id)).group_by(M.SoftwareItem.status)
    if not internal:
        hw_q = hw_q.filter(M.HardwareItem.project_id.in_(pids))
        sw_q = sw_q.filter(M.SoftwareItem.project_id.in_(pids))
    stage_counts = {k: 0 for k in M.STAGE_KEYS}
    for p in projects:
        stage_counts[p.stage] += 1
    activity = []
    if internal:
        aq = db.query(M.AuditLog).filter(M.AuditLog.action.notin_(["login", "login_failed"]))
        if ids is not None:
            aq = aq.filter((M.AuditLog.project_id.is_(None)) | (M.AuditLog.project_id.in_(ids)))
        activity = [to_dict(a, exclude={"detail", "ip"}) for a in aq.order_by(M.AuditLog.id.desc()).limit(25)]
    sev = {"critical": 0, "warning": 1, "info": 2}
    return {
        "projects": rows,
        "stage_counts": stage_counts,
        "requirement_status": req_status,
        "hardware_status": dict(hw_q.all()),
        "software_status": dict(sw_q.all()),
        "alerts": sorted(all_alerts, key=lambda a: sev.get(a["severity"], 3)),
        "activity": activity,
        "releases": [{"id": r.id, "project_code": code, "version": r.version, "status": r.status,
                      "commit_sha": r.commit_sha, "approved_at": r.approved_at and r.approved_at.isoformat(timespec="seconds")}
                     for r, code in db.query(M.Release, M.Project.code).join(M.Project, M.Project.id == M.Release.project_id)
                     .filter(M.Release.project_id.in_(pids or [-1])).order_by(M.Release.id.desc()).limit(10)],
        "acceptance_records": {s: db.query(M.AcceptanceRecord).filter(M.AcceptanceRecord.project_id.in_(pids or [-1]),
                                                                      M.AcceptanceRecord.status == s).count()
                               for s in M.ACCEPT_STATUS},
    }


@router.get("/alerts")
def all_alerts(severity: str | None = Query(None), user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    out = []
    ids = visible_project_ids(db, user)
    pq = db.query(M.Project)
    if ids is not None:
        pq = pq.filter(M.Project.id.in_(ids))
    for p in pq:
        out += E.alerts(db, p)
    return [a for a in out if not severity or a["severity"] == severity]
