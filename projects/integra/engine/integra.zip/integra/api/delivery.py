"""Customer delivery (Phase 7, module M): customer sites (infrastructure, installed hardware, integration checks,
diagnostics, site issues), requirements verification matrix, acceptance records with customer signature, and the
final delivery gate."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Annotated, Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from pydantic import Field
from sqlalchemy.orm import Session

from .. import config
from .. import models as M
from ..db import get_db
from ..schemas import In, one_of
from ..security import audit, can, check_project_write, current_user, get_project_or_404, is_member, require
from ..services import delivery as D
from ..services import engineering as E
from ..services.records import record_revision, to_dict

router = APIRouter(prefix="/api/v1", tags=["customer delivery"])
MAX_DIAG = 50 * 1024 * 1024


# ---------------------------------------------------------------- sites
class InfraItem(In):
    category: Annotated[str, one_of(M.INFRA_CATEGORIES)]
    item: Annotated[str, Field(min_length=1, max_length=200)]
    detail: Annotated[str, Field(max_length=2000)] | None = None


class SiteIn(In):
    name: Annotated[str, Field(min_length=1, max_length=160)]
    location: str | None = None
    address: str | None = None
    contact_name: str | None = None
    contact_phone: str | None = None
    access_notes: str | None = None
    infrastructure: list[InfraItem] = []


class SitePatch(In):
    name: Annotated[str, Field(min_length=1, max_length=160)] | None = None
    location: str | None = None
    address: str | None = None
    contact_name: str | None = None
    contact_phone: str | None = None
    access_notes: str | None = None
    infrastructure: list[InfraItem] | None = None
    status: Annotated[str, one_of(["planned", "installing", "commissioned", "decommissioned"])] | None = None


def _get_site(db: Session, user: M.User, sid: int) -> tuple[M.Site, M.Project]:
    s = db.get(M.Site, sid)
    if not s:
        raise HTTPException(404, "Site not found")
    return s, get_project_or_404(db, user, s.project_id)


def _site_out(db: Session, s: M.Site, detail: bool = False) -> dict:
    d = to_dict(s)
    inst = D.active_installations(db, s.id)
    chk = D.latest_site_check(db, s.id)
    d["installed"] = len(inst)
    d["latest_check"] = {"id": chk.id, "status": chk.status} if chk else None
    d["open_issues"] = db.query(M.Issue).filter(M.Issue.site_id == s.id, M.Issue.status.notin_(["closed", "rejected"])).count()
    if detail:
        d["installations"] = []
        for i in db.query(M.SiteInstallation).filter_by(site_id=s.id).order_by(M.SiteInstallation.id):
            h = db.get(M.HardwareItem, i.hardware_id)
            d["installations"].append(to_dict(i) | {"asset_tag": h.asset_tag, "name": h.name, "model": h.model,
                                                    "manufacturer": h.manufacturer, "inventory_status": h.status})
        d["checks"] = [to_dict(c) for c in db.query(M.SiteCheck).filter_by(site_id=s.id).order_by(M.SiteCheck.id.desc())]
        d["diagnostics"] = [to_dict(x) for x in db.query(M.SiteDiagnostic).filter_by(site_id=s.id).order_by(M.SiteDiagnostic.id.desc())]
        d["issues"] = [{"id": i.id, "ref": i.ref, "title": i.title, "severity": i.severity, "status": i.status,
                        "corrective_action": i.corrective_action, "owner": i.owner}
                       for i in db.query(M.Issue).filter_by(site_id=s.id).order_by(M.Issue.ref)]
        d["deployments"] = [to_dict(x) | {"version": db.get(M.Release, x.release_id).version}
                            for x in db.query(M.Deployment).filter_by(site_id=s.id).order_by(M.Deployment.id.desc())]
    return d


@router.get("/projects/{pid}/sites")
def list_sites(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_site_out(db, s) for s in db.query(M.Site).filter_by(project_id=pid).order_by(M.Site.name)]


@router.post("/projects/{pid}/sites", status_code=201)
def create_site(pid: int, body: SiteIn, request: Request, user: M.User = Depends(require("sites.write")),
                db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    if db.query(M.Site.id).filter_by(project_id=pid, name=body.name).first():
        raise HTTPException(409, "A site with this name exists in the project")
    s = M.Site(project_id=pid, created_by=user.username, **body.model_dump())
    db.add(s)
    db.flush()
    audit(db, user, "site_create", "site", s.id, project_id=pid, summary=f"{p.code}: site '{s.name}'", request=request)
    db.commit()
    return _site_out(db, s, detail=True)


@router.get("/sites/{sid}")
def get_site(sid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    s, _ = _get_site(db, user, sid)
    return _site_out(db, s, detail=True)


@router.patch("/sites/{sid}")
def update_site(sid: int, body: SitePatch, request: Request, user: M.User = Depends(require("sites.write")),
                db: Session = Depends(get_db)):
    s, p = _get_site(db, user, sid)
    check_project_write(db, user, p)
    ch = body.model_dump(exclude_unset=True)
    if ch.get("status") == "commissioned":
        chk = D.latest_site_check(db, s.id)
        if not chk or chk.status != "complete":
            raise HTTPException(409, "A site is commissioned only after a complete site integration check")
    if s.status == "accepted" and "status" in ch:
        raise HTTPException(409, "Site acceptance is recorded by a signed acceptance record")
    for k, v in ch.items():
        setattr(s, k, v)
    audit(db, user, "site_update", "site", s.id, project_id=p.id, summary=f"{p.code} site '{s.name}': {', '.join(sorted(ch))}",
          request=request)
    db.commit()
    return _site_out(db, s, detail=True)


class InstallIn(In):
    hardware_id: int
    position: Annotated[str, Field(min_length=1, max_length=200)]
    configuration: dict[str, Any] = {}
    notes: str | None = None


@router.post("/sites/{sid}/installations", status_code=201)
def install(sid: int, body: InstallIn, request: Request, user: M.User = Depends(require("sites.write")),
            db: Session = Depends(get_db)):
    s, p = _get_site(db, user, sid)
    check_project_write(db, user, p)
    h = db.get(M.HardwareItem, body.hardware_id)
    if not h or h.project_id != p.id:
        raise HTTPException(422, "hardware_id: a hardware item assigned to this project")
    other = (db.query(M.SiteInstallation).filter_by(hardware_id=h.id, removed_at=None).first())
    if other:
        raise HTTPException(409, f"{h.asset_tag} is already installed at site #{other.site_id} ({other.position}); remove it first")
    i = M.SiteInstallation(site_id=s.id, hardware_id=h.id, position=body.position, configuration=body.configuration,
                           notes=body.notes, serial_number=h.serial_number, hardware_revision=h.hardware_revision,
                           firmware_version=h.firmware_version, installed_by=user.username)
    db.add(i)
    db.add(M.HardwareConfigRecord(hardware_id=h.id, title=f"Installed at {s.name}: {body.position}",
                                  parameters=body.configuration, notes=body.notes, recorded_by=user.username))
    db.flush()
    audit(db, user, "site_install", "site", s.id, project_id=p.id,
          summary=f"{p.code} {s.name}: installed {h.asset_tag} S/N {h.serial_number} at {body.position}", request=request)
    db.commit()
    return to_dict(i)


class RemoveIn(In):
    notes: str | None = None


@router.post("/installations/{iid}/remove")
def remove_installation(iid: int, body: RemoveIn, request: Request, user: M.User = Depends(require("sites.write")),
                        db: Session = Depends(get_db)):
    i = db.get(M.SiteInstallation, iid)
    if not i:
        raise HTTPException(404, "Installation not found")
    s, p = _get_site(db, user, i.site_id)
    check_project_write(db, user, p)
    if i.removed_at:
        raise HTTPException(409, "Already removed")
    i.removed_at, i.removed_by = M.utcnow(), user.username
    if body.notes:
        i.notes = f"{i.notes or ''}\nRemoved: {body.notes}".strip()
    audit(db, user, "site_uninstall", "site", s.id, project_id=p.id, summary=f"{p.code} {s.name}: removed installation #{i.id}",
          request=request)
    db.commit()
    return to_dict(i)


# ---------------------------------------------------------------- site integration checks
class CheckIn(In):
    release_id: int | None = None


class CheckItemIn(In):
    status: Annotated[str, one_of(["pass", "fail", "na", "pending"])]
    detail: Annotated[str, Field(max_length=2000)] | None = None


def _get_check(db: Session, user: M.User, cid: int) -> tuple[M.SiteCheck, M.Site, M.Project]:
    c = db.get(M.SiteCheck, cid)
    if not c:
        raise HTTPException(404, "Site check not found")
    s, p = _get_site(db, user, c.site_id)
    return c, s, p


@router.post("/sites/{sid}/checks", status_code=201)
def start_check(sid: int, body: CheckIn, request: Request, user: M.User = Depends(require("sites.write")),
                db: Session = Depends(get_db)):
    s, p = _get_site(db, user, sid)
    check_project_write(db, user, p)
    rel = None
    if body.release_id:
        rel = db.get(M.Release, body.release_id)
        if not rel or rel.project_id != p.id:
            raise HTTPException(422, "release_id: a release of this project")
    if db.query(M.SiteCheck.id).filter_by(site_id=s.id, status="open").first():
        raise HTTPException(409, "An open check exists for this site; complete it first")
    c = M.SiteCheck(site_id=s.id, release_id=rel.id if rel else None, started_by=user.username,
                    items=D.new_site_check_items(db, s, rel, user.username))
    db.add(c)
    db.flush()
    audit(db, user, "site_check_start", "site", s.id, project_id=p.id, summary=f"{p.code} {s.name}: check #{c.id} started",
          request=request)
    db.commit()
    return to_dict(c)


@router.post("/site-checks/{cid}/refresh")
def refresh_check(cid: int, user: M.User = Depends(require("sites.write")), db: Session = Depends(get_db)):
    c, s, p = _get_check(db, user, cid)
    if c.status != "open":
        raise HTTPException(409, "Check is closed")
    auto = D.site_auto(db, s, db.get(M.Release, c.release_id) if c.release_id else None)
    items = []
    for it in c.items:
        if it["auto"] and it["key"] in auto:
            it = it | {"status": auto[it["key"]][0], "detail": auto[it["key"]][1], "by": "INTEGRA",
                       "at": M.utcnow().isoformat(timespec="seconds")}
        items.append(it)
    c.items = items
    db.commit()
    return to_dict(c)


@router.post("/site-checks/{cid}/items/{key}")
def set_check_item(cid: int, key: str, body: CheckItemIn, request: Request, user: M.User = Depends(require("sites.write")),
                   db: Session = Depends(get_db)):
    c, s, p = _get_check(db, user, cid)
    check_project_write(db, user, p)
    if c.status != "open":
        raise HTTPException(409, "Check is closed")
    items = [dict(x) for x in c.items]
    it = next((x for x in items if x["key"] == key), None)
    if not it:
        raise HTTPException(404, "Item not found")
    if it["auto"]:
        raise HTTPException(409, "Automatic items are evaluated from records; fix the records and refresh")
    if body.status in ("pass", "fail") and not (body.detail or "").strip():
        raise HTTPException(422, "detail: record what was measured or observed")
    it.update(status=body.status, detail=body.detail, by=user.username, at=M.utcnow().isoformat(timespec="seconds"))
    c.items = items
    audit(db, user, "site_check_item", "site", s.id, project_id=p.id, summary=f"{s.name} check #{c.id} {key} -> {body.status}",
          request=request)
    db.commit()
    return to_dict(c)


@router.post("/site-checks/{cid}/complete")
def complete_check(cid: int, request: Request, user: M.User = Depends(require("sites.write")), db: Session = Depends(get_db)):
    c, s, p = _get_check(db, user, cid)
    check_project_write(db, user, p)
    if c.status != "open":
        raise HTTPException(409, "Check is closed")
    pending = [x["key"] for x in c.items if x["status"] == "pending"]
    if pending:
        raise HTTPException(409, f"{len(pending)} item(s) pending: {', '.join(pending)}")
    failed = [x["key"] for x in c.items if x["status"] == "fail"]
    c.status = "failed" if failed else "complete"
    c.completed_by, c.completed_at = user.username, M.utcnow()
    audit(db, user, "site_check_close", "site", s.id, project_id=p.id,
          summary=f"{p.code} {s.name}: check #{c.id} {c.status}" + (f" ({', '.join(failed)})" if failed else ""), request=request)
    db.commit()
    return to_dict(c)


# ---------------------------------------------------------------- site diagnostics
@router.post("/sites/{sid}/diagnostics", status_code=201)
async def upload_diagnostic(sid: int, request: Request, file: UploadFile = File(...),
                            kind: str = Form("log"), description: str | None = Form(None),
                            import_log: bool = Form(False), year: int | None = Form(None),
                            user: M.User = Depends(require("sites.write")), db: Session = Depends(get_db)):
    s, p = _get_site(db, user, sid)
    check_project_write(db, user, p)
    if kind not in ("log", "config", "measurement", "other"):
        raise HTTPException(422, "kind: log, config, measurement or other")
    raw = await file.read()
    if len(raw) > MAX_DIAG:
        raise HTTPException(413, "File larger than 50 MB")
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", Path(file.filename or "diagnostic").name)[:200] or "diagnostic"
    sha = hashlib.sha256(raw).hexdigest()
    d = M.SiteDiagnostic(site_id=s.id, filename=name, kind=kind, description=description, size=len(raw), sha256=sha,
                         uploaded_by=user.username)
    db.add(d)
    db.flush()
    folder = config.settings.data_dir / "site_diagnostics"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / f"{d.id}_{name}").write_bytes(raw)
    imported = None
    if import_log:
        if not can(user, "debug.write"):
            raise HTTPException(403, "Importing into the debugging timeline needs the debug.write permission")
        from ..services import analysis as A
        src_name = f"site: {s.name}"[:120]
        src = db.query(M.LogSource).filter_by(project_id=p.id, name=src_name).first()
        if not src:
            src = M.LogSource(project_id=p.id, name=src_name, component=f"Customer site {s.name}", kind="system",
                              created_by=user.username)
            db.add(src)
            db.flush()
        imp = A.import_text(db, src, name, raw, user.username, year)
        d.log_import_id = imp.id
        imported = {"source_id": src.id, "events": imp.events, "unparsed": imp.unparsed, "format": imp.detected_format}
    audit(db, user, "site_diagnostic", "site", s.id, project_id=p.id,
          summary=f"{p.code} {s.name}: diagnostic {name} ({len(raw)} B)" + (f", {imported['events']} events imported" if imported else ""),
          detail={"sha256": sha}, request=request)
    db.commit()
    return to_dict(d) | {"imported": imported}


@router.get("/site-diagnostics/{did}/download")
def download_diagnostic(did: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    d = db.get(M.SiteDiagnostic, did)
    if not d:
        raise HTTPException(404, "Diagnostic not found")
    _get_site(db, user, d.site_id)
    f = config.settings.data_dir / "site_diagnostics" / f"{d.id}_{d.filename}"
    if not f.exists():
        raise HTTPException(410, "Stored file is missing")
    return FileResponse(f, filename=d.filename, media_type="application/octet-stream")


# ---------------------------------------------------------------- verification & final gate
@router.get("/projects/{pid}/verification")
def verification(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return D.verification_matrix(db, pid)


@router.get("/projects/{pid}/final-gate")
def final_gate(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return D.final_gate(db, pid)


# ---------------------------------------------------------------- acceptance
class AcceptanceIn(In):
    kind: Annotated[str, one_of(M.ACCEPT_KINDS)]
    title: Annotated[str, Field(min_length=1, max_length=240)]
    site_id: int | None = None
    release_id: int | None = None


class AcceptancePatch(In):
    title: Annotated[str, Field(min_length=1, max_length=240)] | None = None
    site_id: int | None = None
    release_id: int | None = None
    customer_representative: str | None = None
    conditions: str | None = None


class ItemIn(In):
    result: Annotated[str, one_of(M.ACCEPT_RESULTS)] | None = None
    comment: Annotated[str, Field(max_length=2000)] | None = None
    customer_comment: Annotated[str, Field(max_length=2000)] | None = None


class SignIn(In):
    decision: Annotated[str, one_of(["accept", "reject"])]
    customer_representative: Annotated[str, Field(max_length=160)] | None = None
    conditions: str | None = None
    confirm: bool = False


def _get_acc(db: Session, user: M.User, aid: int) -> tuple[M.AcceptanceRecord, M.Project]:
    a = db.get(M.AcceptanceRecord, aid)
    if not a:
        raise HTTPException(404, "Acceptance record not found")
    return a, get_project_or_404(db, user, a.project_id)


def _acc_out(db: Session, a: M.AcceptanceRecord, detail: bool = False) -> dict:
    d = to_dict(a, exclude=None if detail else {"items"})
    rel = db.get(M.Release, a.release_id) if a.release_id else None
    site = db.get(M.Site, a.site_id) if a.site_id else None
    d["release"] = {"id": rel.id, "version": rel.version, "status": rel.status} if rel else None
    d["site"] = {"id": site.id, "name": site.name, "status": site.status} if site else None
    items = a.items
    d["counts"] = {k: sum(1 for i in items if i["result"] == k) for k in M.ACCEPT_RESULTS}
    if detail:
        d["blockers"] = D.acceptance_blockers(db, a) if a.status in ("draft", "in_review") else []
        if a.sha256:
            d["hash_valid"] = D.acceptance_hash(a, rel, site, "accept" if a.status == "accepted" else "reject") == a.sha256
    return d


def _check_links(db: Session, pid: int, data: dict) -> None:
    if data.get("site_id"):
        s = db.get(M.Site, data["site_id"])
        if not s or s.project_id != pid:
            raise HTTPException(422, "site_id: a site of this project")
    if data.get("release_id"):
        r = db.get(M.Release, data["release_id"])
        if not r or r.project_id != pid:
            raise HTTPException(422, "release_id: a release of this project")


@router.get("/projects/{pid}/acceptance-records")
def list_acceptance(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_acc_out(db, a) for a in db.query(M.AcceptanceRecord).filter_by(project_id=pid).order_by(M.AcceptanceRecord.id.desc())]


@router.post("/projects/{pid}/acceptance-records", status_code=201)
def create_acceptance(pid: int, body: AcceptanceIn, request: Request, user: M.User = Depends(require("acceptance.write")),
                      db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    _check_links(db, pid, body.model_dump())
    prefix = body.kind.upper()
    nums = [int(m.group(1)) for (r,) in db.query(M.AcceptanceRecord.ref).filter_by(project_id=pid)
            if (m := re.fullmatch(rf"{prefix}-(\d+)", r))]
    a = M.AcceptanceRecord(project_id=pid, ref=f"{prefix}-{(max(nums) + 1 if nums else 1):03d}", created_by=user.username,
                           items=D.acceptance_items(db, pid), **body.model_dump())
    if not a.items:
        raise HTTPException(409, "The project has no requirements to accept")
    db.add(a)
    db.flush()
    audit(db, user, "acceptance_create", "acceptance", a.id, project_id=pid, summary=f"{p.code}: {a.ref} '{a.title}'",
          request=request)
    db.commit()
    return _acc_out(db, a, detail=True)


@router.get("/acceptance-records/{aid}")
def get_acceptance(aid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    a, _ = _get_acc(db, user, aid)
    return _acc_out(db, a, detail=True)


@router.patch("/acceptance-records/{aid}")
def update_acceptance(aid: int, body: AcceptancePatch, request: Request, user: M.User = Depends(require("acceptance.write")),
                      db: Session = Depends(get_db)):
    a, p = _get_acc(db, user, aid)
    check_project_write(db, user, p)
    if a.status not in ("draft", "in_review"):
        raise HTTPException(409, f"{a.ref} is {a.status} and immutable")
    ch = body.model_dump(exclude_unset=True)
    _check_links(db, p.id, ch)
    for k, v in ch.items():
        setattr(a, k, v)
    db.commit()
    return _acc_out(db, a, detail=True)


@router.post("/acceptance-records/{aid}/items/{req_id}")
def set_item(aid: int, req_id: int, body: ItemIn, request: Request, user: M.User = Depends(current_user),
             db: Session = Depends(get_db)):
    a, p = _get_acc(db, user, aid)
    if a.status not in ("draft", "in_review"):
        raise HTTPException(409, f"{a.ref} is {a.status} and immutable")
    engineer = can(user, "acceptance.write")
    customer = user.role == "CUSTOMER_VIEWER" and is_member(db, user, p.id)
    if (body.result is not None or body.comment is not None) and not engineer:
        raise HTTPException(403, "Only engineers/project managers record results")
    if body.customer_comment is not None and not (customer or can(user, "acceptance.sign")):
        raise HTTPException(403, "Customer comments are recorded by the customer or on their behalf by the project manager")
    if not engineer and not customer and not can(user, "acceptance.sign"):
        raise HTTPException(403, "Not allowed")
    if not customer:
        check_project_write(db, user, p)
    items = [dict(x) for x in a.items]
    it = next((x for x in items if x["requirement_id"] == req_id), None)
    if not it:
        raise HTTPException(404, "Requirement not in this record")
    if body.result == "waived" and it["mandatory"]:
        raise HTTPException(422, "Mandatory requirements cannot be waived")
    if body.result == "pass":
        r = db.get(M.Requirement, req_id)
        if not any(e.result == "pass" for e in r.evidence):
            raise HTTPException(409, f"{it['ref']} has no passing validation evidence to present")
    for k in ("result", "comment", "customer_comment"):
        v = getattr(body, k)
        if v is not None:
            it[k] = v
    it["by"], it["at"] = user.username, M.utcnow().isoformat(timespec="seconds")
    a.items = items
    audit(db, user, "acceptance_item", "acceptance", a.id, project_id=p.id,
          summary=f"{a.ref} {it['ref']}: " + (f"result={body.result}" if body.result else "comment"), request=request)
    db.commit()
    return _acc_out(db, a, detail=True)


@router.post("/acceptance-records/{aid}/submit")
def submit(aid: int, request: Request, user: M.User = Depends(require("acceptance.write")), db: Session = Depends(get_db)):
    a, p = _get_acc(db, user, aid)
    check_project_write(db, user, p)
    if a.status != "draft":
        raise HTTPException(409, f"{a.ref} is {a.status}")
    pend = [i["ref"] for i in a.items if i["result"] == "pending"]
    if pend:
        raise HTTPException(409, f"{len(pend)} item(s) without a result: {', '.join(pend[:10])}")
    a.status = "in_review"
    audit(db, user, "acceptance_submit", "acceptance", a.id, project_id=p.id, summary=f"{a.ref} submitted for customer review",
          request=request)
    db.commit()
    return _acc_out(db, a, detail=True)


@router.post("/acceptance-records/{aid}/reopen")
def reopen(aid: int, request: Request, user: M.User = Depends(require("acceptance.write")), db: Session = Depends(get_db)):
    a, p = _get_acc(db, user, aid)
    if a.status not in ("in_review", "rejected"):
        raise HTTPException(409, f"{a.ref} is {a.status}")
    if a.status == "rejected":
        raise HTTPException(409, "A rejected record stays as signed evidence; create a new record for the next attempt")
    a.status = "draft"
    audit(db, user, "acceptance_reopen", "acceptance", a.id, project_id=p.id, summary=f"{a.ref} back to draft", request=request)
    db.commit()
    return _acc_out(db, a, detail=True)


@router.post("/acceptance-records/{aid}/sign")
def sign(aid: int, body: SignIn, request: Request, user: M.User = Depends(require("acceptance.sign")),
         db: Session = Depends(get_db)):
    a, p = _get_acc(db, user, aid)
    if not body.confirm:
        raise HTTPException(400, "Signing must be explicitly confirmed (confirm=true)")
    if a.status != "in_review":
        raise HTTPException(409, f"{a.ref} is '{a.status}' (submit it for review first)")
    is_customer = user.role == "CUSTOMER_VIEWER"
    if is_customer and not is_member(db, user, p.id):
        raise HTTPException(403, "Only customer representatives assigned to this project sign")
    if not is_customer:
        check_project_write(db, user, p)
    rep = (body.customer_representative or "").strip() or (user.full_name if is_customer else "")
    if not rep:
        raise HTTPException(422, "customer_representative: name the customer representative you sign on behalf of")
    if body.decision == "accept":
        blockers = D.acceptance_blockers(db, a)
        if blockers:
            raise HTTPException(409, {"message": f"{a.ref} cannot be accepted", "blockers": blockers})
    elif not (body.conditions or "").strip():
        raise HTTPException(422, "conditions: give the reason for rejection")
    rel = db.get(M.Release, a.release_id) if a.release_id else None
    site = db.get(M.Site, a.site_id) if a.site_id else None
    a.customer_representative, a.conditions = rep, body.conditions
    a.signed_by, a.signed_at = user.username, M.utcnow()
    a.signature_role = "customer" if is_customer else "on_behalf"
    a.status = "accepted" if body.decision == "accept" else "rejected"
    a.sha256 = D.acceptance_hash(a, rel, site, body.decision)
    approved = []
    if body.decision == "accept":
        reqs = {r.id: r for r in E.load_requirements(db, p.id)}
        for it in a.items:
            if it["result"] != "pass":
                continue
            r = reqs[it["requirement_id"]]
            db.add(M.Evidence(requirement_id=r.id, kind="customer_signoff", result="pass",
                              title=f"Accepted in {a.ref} ({a.kind.upper()}) by {rep}",
                              reference=f"acceptance:{a.id} sha256:{a.sha256[:16]}",
                              software_config=f"{rel.version} @ {(rel.commit_sha or '-')[:12]}" if rel else None,
                              hardware_config=site.name if site else None,
                              notes=it.get("customer_comment"), recorded_by=user.username))
            if r.status == "passed":
                r.status = "approved"
                db.flush()
                record_revision(db, "requirement", r, user.username, f"Customer approval via {a.ref}")
                approved.append(r.ref)
        if site and a.kind in ("sat", "final"):
            site.status = "accepted"
    old = p.acceptance_status
    if a.kind == "final":
        p.acceptance_status = "accepted" if body.decision == "accept" else "rejected"
    elif p.acceptance_status == "not_started":
        p.acceptance_status = "in_review"
    if p.acceptance_status != old:
        db.flush()
        record_revision(db, "project", p, user.username, f"Acceptance {old} -> {p.acceptance_status} via {a.ref}")
    audit(db, user, f"acceptance_{body.decision}", "acceptance", a.id, project_id=p.id,
          summary=f"{p.code} {a.ref} {a.status} by {user.username} ({a.signature_role}: {rep})",
          detail={"sha256": a.sha256, "approved_requirements": approved, "conditions": body.conditions}, request=request)
    db.commit()
    return _acc_out(db, a, detail=True) | {"approved_requirements": approved}
