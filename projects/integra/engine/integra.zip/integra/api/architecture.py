"""System Architecture Designer (Module B) and interface/dependency validation (Module F, static part)."""
from __future__ import annotations

import re

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..schemas import (ArchModelIn, BaselineIn, ComponentIn, ComponentPatch, ConnectionIn, ConnectionPatch, LayoutIn,
                       VerifyIn)
from ..security import audit, check_project_write, current_user, get_project_or_404, require
from ..services import validation as V
from ..services.records import diff, to_dict

router = APIRouter(prefix="/api/v1", tags=["architecture"])

TECH_FIELDS = {"kind", "interface_type", "protocol", "data_type", "rate_hz", "bandwidth_mbps", "latency_budget_ms",
               "config_requirements"}


# ---------------------------------------------------------------- helpers
def _model(db: Session, user: M.User, mid: int, write: bool = False) -> tuple[M.ArchModel, M.Project]:
    m = db.get(M.ArchModel, mid)
    if not m:
        raise HTTPException(404, "Architecture not found")
    p = get_project_or_404(db, user, m.project_id)
    if write:
        check_project_write(db, user, p)
    return m, p


def _slug(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_").lower()[:40] or "c"


def _unique_key(db: Session, table, model_id: int, base: str) -> str:
    key, n = base, 1
    while db.query(table.id).filter_by(model_id=model_id, key=key).first():
        n += 1
        key = f"{base}_{n}"
    return key


def _check_kind(layer: str, kind: str) -> None:
    allowed = M.ARCH_HW_KINDS if layer == "hardware" else M.ARCH_SW_KINDS
    if kind not in allowed:
        raise HTTPException(422, f"kind: '{kind}' is not a {layer} component kind ({', '.join(allowed)})")


def _check_links(db: Session, p: M.Project, layer: str, hardware_id, software_id) -> None:
    if hardware_id is not None:
        if layer != "hardware":
            raise HTTPException(422, "Only hardware components can link a hardware item")
        h = db.get(M.HardwareItem, hardware_id)
        if not h:
            raise HTTPException(422, "hardware_id: hardware item does not exist")
        if h.project_id not in (None, p.id):
            raise HTTPException(422, f"{h.asset_tag} is assigned to another project")
    if software_id is not None:
        if layer != "software":
            raise HTTPException(422, "Only software components can link a software item")
        s = db.get(M.SoftwareItem, software_id)
        if not s:
            raise HTTPException(422, "software_id: software item does not exist")
        if s.project_id not in (None, p.id):
            raise HTTPException(422, f"{s.name} {s.version} is assigned to another project")


def _check_parent(db: Session, model_id: int, comp_id: int | None, layer: str, parent_id: int | None) -> None:
    if parent_id is None:
        return
    par = db.get(M.ArchComponent, parent_id)
    if not par or par.model_id != model_id:
        raise HTTPException(422, "parent_id: parent must be a component of the same architecture")
    if layer == "software" and par.layer != "hardware":
        # software may be nested in software (e.g. node inside a container) only if it eventually reaches hardware
        pass
    if layer == "hardware" and par.layer != "hardware":
        raise HTTPException(422, "A hardware component can only be part of another hardware component")
    cur, seen = par, set()
    while cur is not None:
        if comp_id is not None and cur.id == comp_id:
            raise HTTPException(422, "parent_id would create a cycle in the component hierarchy")
        if cur.id in seen:
            break
        seen.add(cur.id)
        cur = db.get(M.ArchComponent, cur.parent_id) if cur.parent_id else None


def _comp_out(c: M.ArchComponent, ctx: V.Ctx) -> dict:
    d = to_dict(c)
    if c.hardware_id and c.hardware_id in ctx.hw:
        h = ctx.hw[c.hardware_id]
        d["inventory"] = {"asset_tag": h.asset_tag, "model": h.model, "manufacturer": h.manufacturer,
                          "hardware_revision": h.hardware_revision, "firmware_version": h.firmware_version,
                          "status": h.status, "interfaces": h.interfaces}
    if c.software_id and c.software_id in ctx.sw:
        s = ctx.sw[c.software_id]
        d["inventory"] = {"name": s.name, "version": s.version, "status": s.status, "kind": s.kind}
    host = ctx.host(c)
    d["host_id"] = host.id if host else None
    return d


def model_payload(db: Session, m: M.ArchModel) -> dict:
    ctx = V.Ctx(db, m.id)
    results = {r["id"]: r for r in (V.validate_connection(ctx, cn) for cn in ctx.conns)}
    summary = {r: 0 for r in V.RESULT_ORDER}
    for r in results.values():
        summary[r["result"]] += 1
    conns = []
    for cn in ctx.conns:
        d = to_dict(cn)
        d["source"], d["target"] = ctx.comps[cn.source_id].name, ctx.comps[cn.target_id].name
        d["validation"] = results[cn.id]
        conns.append(d)
    return {"model": to_dict(m), "components": [_comp_out(c, ctx) for c in ctx.comps.values()],
            "connections": conns, "summary": summary, "dependencies": V.dependency_analysis(ctx),
            "software_dependencies": _sw_dependency_edges(db, ctx),
            "baselines": db.query(func.count(M.ArchBaseline.id)).filter_by(model_id=m.id).scalar()}


def _sw_dependency_edges(db: Session, ctx: V.Ctx) -> list[dict]:
    """Registered software dependencies between components of this architecture (dependency diagram view)."""
    by_sw = {c.software_id: c for c in ctx.comps.values() if c.software_id}
    out = []
    if not by_sw:
        return out
    for d in db.query(M.SoftwareDependency).filter(M.SoftwareDependency.software_id.in_(list(by_sw))):
        if d.depends_on_id in by_sw:
            out.append({"source_id": by_sw[d.software_id].id, "target_id": by_sw[d.depends_on_id].id,
                        "constraint": d.version_constraint, "kind": d.kind})
    return out


# ---------------------------------------------------------------- models
@router.get("/architecture/catalogue")
def catalogue(_: M.User = Depends(current_user)):
    return {"hardware_kinds": M.ARCH_HW_KINDS, "software_kinds": M.ARCH_SW_KINDS,
            "interfaces": M.HW_INTERFACES + M.LOGICAL_INTERFACES, "logical_interfaces": M.LOGICAL_INTERFACES,
            "protocols": {k: sorted(v) for k, v in V.PROTOCOLS.items()}, "capacity_mbps": V.CAPACITY_MBPS,
            "connection_kinds": M.CONN_KINDS, "connection_status": M.CONN_STATUS, "results": V.RESULT_ORDER,
            "runtime_checks": V.RUNTIME_CHECKS}


@router.get("/projects/{pid}/architectures")
def list_models(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    out = []
    for m in db.query(M.ArchModel).filter_by(project_id=pid).order_by(M.ArchModel.id):
        v = V.validate_model(db, m.id)
        out.append(to_dict(m) | {
            "components": db.query(func.count(M.ArchComponent.id)).filter_by(model_id=m.id).scalar(),
            "connections": len(v["connections"]), "summary": v["summary"],
            "critical_findings": sum(1 for f in v["dependencies"] if f["severity"] == "critical")})
    return out


@router.post("/projects/{pid}/architectures", status_code=201)
def create_model(pid: int, body: ArchModelIn, request: Request, user: M.User = Depends(require("architecture.write")),
                 db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    if db.query(M.ArchModel.id).filter_by(project_id=pid, name=body.name).first():
        raise HTTPException(409, f"Architecture '{body.name}' already exists in {p.code}")
    m = M.ArchModel(project_id=pid, name=body.name, description=body.description, created_by=user.username)
    db.add(m)
    db.flush()
    audit(db, user, "create", "architecture", m.id, project_id=pid, summary=f"{p.code}: architecture '{m.name}'",
          request=request)
    db.commit()
    return model_payload(db, m)


@router.get("/architectures/{mid}")
def get_model(mid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    m, _ = _model(db, user, mid)
    return model_payload(db, m)


@router.patch("/architectures/{mid}")
def rename_model(mid: int, body: ArchModelIn, request: Request, user: M.User = Depends(require("architecture.write")),
                 db: Session = Depends(get_db)):
    m, p = _model(db, user, mid, write=True)
    m.name, m.description = body.name, body.description
    audit(db, user, "update", "architecture", m.id, project_id=p.id, summary=f"{p.code}: architecture renamed",
          request=request)
    db.commit()
    return to_dict(m)


# ---------------------------------------------------------------- components
@router.post("/architectures/{mid}/components", status_code=201)
def add_component(mid: int, body: ComponentIn, request: Request, user: M.User = Depends(require("architecture.write")),
                  db: Session = Depends(get_db)):
    m, p = _model(db, user, mid, write=True)
    _check_kind(body.layer, body.kind)
    _check_links(db, p, body.layer, body.hardware_id, body.software_id)
    _check_parent(db, mid, None, body.layer, body.parent_id)
    data = body.model_dump()
    if data["key"]:
        if db.query(M.ArchComponent.id).filter_by(model_id=mid, key=data["key"]).first():
            raise HTTPException(409, f"Component key '{data['key']}' already used")
    else:
        data["key"] = _unique_key(db, M.ArchComponent, mid, _slug(body.name))
    c = M.ArchComponent(model_id=mid, **data)
    db.add(c)
    db.flush()
    audit(db, user, "component_add", "architecture", m.id, project_id=p.id,
          summary=f"{p.code}/{m.name}: + {c.layer} '{c.name}'", request=request)
    db.commit()
    return to_dict(c)


def _comp(db: Session, user: M.User, cid: int) -> tuple[M.ArchComponent, M.ArchModel, M.Project]:
    c = db.get(M.ArchComponent, cid)
    if not c:
        raise HTTPException(404, "Component not found")
    m, p = _model(db, user, c.model_id, write=True)
    return c, m, p


@router.patch("/components/{cid}")
def update_component(cid: int, body: ComponentPatch, request: Request,
                     user: M.User = Depends(require("architecture.write")), db: Session = Depends(get_db)):
    c, m, p = _comp(db, user, cid)
    ch = body.model_dump(exclude_unset=True)
    if "kind" in ch:
        _check_kind(c.layer, ch["kind"])
    if "hardware_id" in ch or "software_id" in ch:
        _check_links(db, p, c.layer, ch.get("hardware_id"), ch.get("software_id"))
    if "parent_id" in ch:
        _check_parent(db, m.id, c.id, c.layer, ch["parent_id"])
    for k, v in ch.items():
        setattr(c, k, v)
    if set(ch) - {"x", "y"}:
        audit(db, user, "component_update", "architecture", m.id, project_id=p.id,
              summary=f"{p.code}/{m.name}: '{c.name}' updated ({', '.join(sorted(set(ch) - {'x', 'y'}))})",
              request=request)
    db.commit()
    return to_dict(c)


@router.delete("/components/{cid}")
def delete_component(cid: int, request: Request, user: M.User = Depends(require("architecture.write")),
                     db: Session = Depends(get_db)):
    c, m, p = _comp(db, user, cid)
    n = db.query(M.ArchConnection).filter((M.ArchConnection.source_id == cid) | (M.ArchConnection.target_id == cid)).delete()
    db.query(M.ArchComponent).filter_by(parent_id=cid).update({"parent_id": None})
    audit(db, user, "component_delete", "architecture", m.id, project_id=p.id,
          summary=f"{p.code}/{m.name}: - '{c.name}' and {n} connection(s)", detail={"snapshot": to_dict(c)},
          request=request)
    db.delete(c)
    db.commit()
    return {"ok": True, "connections_removed": n}


@router.put("/architectures/{mid}/layout")
def save_layout(mid: int, body: LayoutIn, user: M.User = Depends(require("architecture.write")),
                db: Session = Depends(get_db)):
    _model(db, user, mid, write=True)
    comps = {c.id: c for c in db.query(M.ArchComponent).filter_by(model_id=mid)}
    for cid, (x, y) in body.positions.items():
        if cid in comps:
            comps[cid].x, comps[cid].y = x, y
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- connections
@router.post("/architectures/{mid}/connections", status_code=201)
def add_connection(mid: int, body: ConnectionIn, request: Request,
                   user: M.User = Depends(require("architecture.write")), db: Session = Depends(get_db)):
    m, p = _model(db, user, mid, write=True)
    s, t = db.get(M.ArchComponent, body.source_id), db.get(M.ArchComponent, body.target_id)
    if not s or not t or s.model_id != mid or t.model_id != mid:
        raise HTTPException(422, "source_id/target_id must be components of this architecture")
    if s.id == t.id:
        raise HTTPException(422, "A component cannot connect to itself")
    data = body.model_dump()
    if data["key"]:
        if db.query(M.ArchConnection.id).filter_by(model_id=mid, key=data["key"]).first():
            raise HTTPException(409, f"Connection key '{data['key']}' already used")
    else:
        data["key"] = _unique_key(db, M.ArchConnection, mid, f"{s.key}__{t.key}"[:44])
    cn = M.ArchConnection(model_id=mid, **data)
    db.add(cn)
    db.flush()
    audit(db, user, "connection_add", "architecture", m.id, project_id=p.id,
          summary=f"{p.code}/{m.name}: {s.name} -> {t.name} ({cn.interface_type}/{cn.protocol or '-'})", request=request)
    db.commit()
    return to_dict(cn)


def _conn(db: Session, user: M.User, cid: int) -> tuple[M.ArchConnection, M.ArchModel, M.Project]:
    cn = db.get(M.ArchConnection, cid)
    if not cn:
        raise HTTPException(404, "Connection not found")
    m, p = _model(db, user, cn.model_id, write=True)
    return cn, m, p


@router.patch("/connections/{cid}")
def update_connection(cid: int, body: ConnectionPatch, request: Request,
                      user: M.User = Depends(require("architecture.write")), db: Session = Depends(get_db)):
    cn, m, p = _conn(db, user, cid)
    ch = body.model_dump(exclude_unset=True)
    technical = {k for k in ch if k in TECH_FIELDS and ch[k] != getattr(cn, k)}
    for k, v in ch.items():
        setattr(cn, k, v)
    reset = False
    if technical and cn.status in ("verified", "failed"):
        # a recorded verification no longer applies to a changed interface definition
        cn.status, cn.verification_ref, cn.verified_by, cn.verified_at = "configured", None, None, None
        reset = True
    audit(db, user, "connection_update", "architecture", m.id, project_id=p.id,
          summary=f"{p.code}/{m.name}: connection {cn.key} updated" + (" (verification reset)" if reset else ""),
          detail={"fields": sorted(ch)}, request=request)
    db.commit()
    return to_dict(cn) | {"verification_reset": reset}


@router.delete("/connections/{cid}")
def delete_connection(cid: int, request: Request, user: M.User = Depends(require("architecture.write")),
                      db: Session = Depends(get_db)):
    cn, m, p = _conn(db, user, cid)
    audit(db, user, "connection_delete", "architecture", m.id, project_id=p.id,
          summary=f"{p.code}/{m.name}: connection {cn.key} removed", detail={"snapshot": to_dict(cn)}, request=request)
    db.delete(cn)
    db.commit()
    return {"ok": True}


@router.post("/connections/{cid}/verify")
def verify_connection(cid: int, body: VerifyIn, request: Request, user: M.User = Depends(require("connections.verify")),
                      db: Session = Depends(get_db)):
    cn, m, p = _conn(db, user, cid)
    if body.result == "verified":
        ctx = V.Ctx(db, m.id)
        static = [c for c in V.validate_connection(ctx, cn)["checks"] if c["result"] in ("fail", "missing")
                  and c["check"] not in V.RUNTIME_CHECKS]
        if static:
            raise HTTPException(409, {"message": "Static validation has failures or missing information; "
                                                 "resolve them before recording a verification",
                                      "checks": static})
    cn.status, cn.verification_ref, cn.verified_by, cn.verified_at = body.result, body.reference, user.username, M.utcnow()
    audit(db, user, "connection_verify", "architecture", m.id, project_id=p.id,
          summary=f"{p.code}/{m.name}: {cn.key} recorded {body.result} ({body.reference})", request=request)
    db.commit()
    return V.validate_connection(V.Ctx(db, m.id), cn)


@router.get("/architectures/{mid}/validation")
def validation(mid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    m, _ = _model(db, user, mid)
    return V.validate_model(db, m.id)


# ---------------------------------------------------------------- baselines & comparison
def _snapshot(db: Session, mid: int) -> dict:
    comps = db.query(M.ArchComponent).filter_by(model_id=mid).all()
    keys = {c.id: c.key for c in comps}
    cs = {}
    for c in comps:
        d = to_dict(c, exclude={"id", "model_id", "x", "y"})
        d["parent"] = keys.get(c.parent_id)
        d.pop("parent_id")
        cs[c.key] = d
    ns = {}
    for cn in db.query(M.ArchConnection).filter_by(model_id=mid):
        d = to_dict(cn, exclude={"id", "model_id", "verified_at"})
        d["source"], d["target"] = keys.get(d.pop("source_id")), keys.get(d.pop("target_id"))
        ns[cn.key] = d
    return {"components": cs, "connections": ns}


@router.get("/architectures/{mid}/baselines")
def list_baselines(mid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    _model(db, user, mid)
    return [{"id": b.id, "revision": b.revision, "label": b.label, "comment": b.comment, "created_by": b.created_by,
             "created_at": b.created_at.isoformat(timespec="seconds"), "validation_summary": b.validation_summary,
             "components": len(b.snapshot["components"]), "connections": len(b.snapshot["connections"])}
            for b in db.query(M.ArchBaseline).filter_by(model_id=mid).order_by(M.ArchBaseline.revision.desc())]


@router.post("/architectures/{mid}/baselines", status_code=201)
def create_baseline(mid: int, body: BaselineIn, request: Request,
                    user: M.User = Depends(require("architecture.baseline")), db: Session = Depends(get_db)):
    m, p = _model(db, user, mid, write=True)
    snap = _snapshot(db, mid)
    last = db.query(M.ArchBaseline).filter_by(model_id=mid).order_by(M.ArchBaseline.revision.desc()).first()
    if last and last.snapshot == snap:
        raise HTTPException(409, f"No changes since revision {last.revision} ({last.label})")
    rev = (last.revision + 1) if last else 1
    b = M.ArchBaseline(model_id=mid, revision=rev, label=body.label, comment=body.comment, snapshot=snap,
                       validation_summary=V.validate_model(db, mid)["summary"], created_by=user.username)
    db.add(b)
    audit(db, user, "baseline", "architecture", m.id, project_id=p.id,
          summary=f"{p.code}/{m.name}: baseline Rev {rev} '{body.label}'", request=request)
    db.commit()
    return {"revision": rev, "label": b.label}


def _compare(a: dict, b: dict) -> dict:
    out = {}
    for part in ("components", "connections"):
        A, B = a[part], b[part]
        out[part] = {
            "added": [{"key": k, "item": B[k]} for k in sorted(set(B) - set(A))],
            "removed": [{"key": k, "item": A[k]} for k in sorted(set(A) - set(B))],
            "changed": [{"key": k, "name": B[k].get("name") or f"{B[k].get('source')} -> {B[k].get('target')}",
                         "changes": diff(A[k], B[k])} for k in sorted(set(A) & set(B)) if A[k] != B[k]],
        }
    out["identical"] = all(not v[x] for v in (out["components"], out["connections"]) for x in ("added", "removed", "changed"))
    return out


@router.get("/architectures/{mid}/compare")
def compare(mid: int, a: int = Query(..., description="baseline revision"),
            b: str = Query("current", description="baseline revision or 'current'"),
            user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    _model(db, user, mid)

    def load(rev):
        if rev == "current":
            return _snapshot(db, mid), "Working copy"
        bl = db.query(M.ArchBaseline).filter_by(model_id=mid, revision=int(rev)).first()
        if not bl:
            raise HTTPException(404, f"Revision {rev} not found")
        return bl.snapshot, f"Rev {bl.revision} {bl.label}"

    sa, la = load(a)
    sb, lb = load(b)
    return {"from": la, "to": lb} | _compare(sa, sb)


# ---------------------------------------------------------------- runtime probes (Phase 3)
from typing import Annotated, Any  # noqa: E402

from ..schemas import In, one_of  # noqa: E402


class ProbeIn(In):
    kind: Annotated[str, one_of(M.PROBE_KINDS)]
    params: dict[str, Any] = {}


@router.post("/connections/{cid}/probe", status_code=201)
def run_probe(cid: int, body: ProbeIn, request: Request, user: M.User = Depends(require("probes.run")),
              db: Session = Depends(get_db)):
    from ..services.probes import run_probe as runner
    cn, m, p = _conn(db, user, cid)
    r = runner(db, cn, body.kind, body.params)
    pr = M.ConnectionProbe(connection_id=cn.id, kind=body.kind, params=body.params, environment=r["environment"],
                           result=r["result"], measured=r["measured"], detail=r["detail"], ran_by=user.username)
    db.add(pr)
    db.flush()
    audit(db, user, "probe", "architecture", m.id, project_id=p.id,
          summary=f"{p.code}/{m.name}: {body.kind} on {cn.key} -> {r['result']} ({r['environment']})", request=request)
    db.commit()
    return {"probe": to_dict(pr), "validation": V.validate_connection(V.Ctx(db, m.id), cn)}


@router.get("/connections/{cid}/probes")
def list_probes(cid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    cn = db.get(M.ArchConnection, cid)
    if not cn:
        raise HTTPException(404, "Connection not found")
    _model(db, user, cn.model_id)
    return [to_dict(p) for p in db.query(M.ConnectionProbe).filter_by(connection_id=cid)
            .order_by(M.ConnectionProbe.id.desc()).limit(50)]
