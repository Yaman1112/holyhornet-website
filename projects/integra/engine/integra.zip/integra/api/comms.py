"""Hardware connection manager and Communication Analyzer (Phase 3): discovery, authorisations, CAN / serial / UDP
captures, DBC decoding, traffic generation, replay, transmit, exports and Ethernet diagnostics."""
from __future__ import annotations

import hashlib
import io
import socket
import statistics
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Annotated, Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..hal import adapters, authz, discovery
from ..hal import sessions as S
from ..schemas import In, one_of
from ..security import audit, current_user, get_project_or_404, require
from ..services.records import to_dict

router = APIRouter(prefix="/api/v1", tags=["hardware connections & communication"])

CAN_IFACES = ["virtual"] + list(adapters.CAN_PHYSICAL)


# ---------------------------------------------------------------- schemas
class AuthRequestIn(In):
    project_id: int | None = None
    interface: Annotated[str, one_of(CAN_IFACES + ["serial", "scpi", "rig"])]
    channel: Annotated[str, Field(min_length=1, max_length=120)]
    actions: list[Annotated[str, one_of(M.AUTH_ACTIONS)]]
    purpose: Annotated[str, Field(min_length=5)]
    isolation: Annotated[str, Field(min_length=5)]
    isolation_confirmed: bool
    hours: Annotated[float, Field(gt=0, le=72)] = 8


class AuthDecisionIn(In):
    decision: Annotated[str, one_of(["approved", "rejected", "revoked"])]
    note: str | None = None


class CanCfg(In):
    interface: Annotated[str, one_of(CAN_IFACES)] = "virtual"
    channel: Annotated[str, Field(min_length=1, max_length=120)] = "vbus0"
    bitrate: Annotated[int, Field(ge=10000, le=1000000)] | None = 500000
    fd: bool = False
    data_bitrate: Annotated[int, Field(ge=500000, le=12000000)] | None = None
    listen_only: bool = True


class CaptureCanIn(CanCfg):
    name: str | None = None
    project_id: int | None = None
    dbc_id: int | None = None


class SerialCfg(In):
    port: Annotated[str, Field(min_length=1, max_length=200)]
    baudrate: Annotated[int, Field(ge=50, le=4000000)] = 115200
    bytesize: Annotated[int, Field(ge=5, le=8)] = 8
    parity: Annotated[str, one_of(["N", "E", "O", "M", "S"])] = "N"
    stopbits: Annotated[float, Field(ge=1, le=2)] = 1
    decoder: Annotated[str, one_of(["ascii", "nmea", "ubx", "raw"])] = "ascii"
    simulate: Annotated[str, one_of(["nmea", "ubx"])] | None = None
    simulate_rate_hz: Annotated[float, Field(gt=0, le=100)] = 10


class CaptureSerialIn(SerialCfg):
    name: str | None = None
    project_id: int | None = None


class CaptureUdpIn(In):
    host: str = "127.0.0.1"
    port: Annotated[int, Field(ge=1, le=65535)]
    name: str | None = None
    project_id: int | None = None


class GeneratorIn(CanCfg):
    dbc_id: int
    messages: list[str] | None = None
    listen_only: bool = False


class ReplayIn(CanCfg):
    capture_id: int
    speed: Annotated[float, Field(gt=0, le=100)] = 1.0
    loop: bool = False
    listen_only: bool = False


class TransmitIn(CanCfg):
    arbitration_id: Annotated[int, Field(ge=0, le=0x1FFFFFFF)]
    data_hex: Annotated[str, Field(pattern=r"^([0-9a-fA-F]{2}){0,64}$")] = ""
    extended: bool = False
    listen_only: bool = False


class SerialWriteIn(In):
    text: Annotated[str, Field(max_length=2000)] | None = None
    hex: Annotated[str, Field(pattern=r"^([0-9a-fA-F]{2})*$", max_length=4000)] | None = None
    append_crlf: bool = True


class TcpProbeIn(In):
    host: Annotated[str, Field(min_length=1, max_length=253)]
    port: Annotated[int, Field(ge=1, le=65535)]
    count: Annotated[int, Field(ge=1, le=20)] = 5
    timeout_s: Annotated[float, Field(gt=0, le=5)] = 1.0


class LinkIn(In):
    hardware_id: int | None = None


# ---------------------------------------------------------------- adapters & discovery
@router.get("/hal/adapters")
def list_adapters(_: M.User = Depends(require("internal.view"))):
    return adapters.registry()


@router.get("/devices")
def list_devices(include_absent: bool = False, user: M.User = Depends(require("internal.view")),
                 db: Session = Depends(get_db)):
    q = db.query(M.DetectedDevice).order_by(M.DetectedDevice.bus, M.DetectedDevice.identifier)
    if not include_absent:
        q = q.filter(M.DetectedDevice.present.is_(True))
    hw = {h.id: h for h in db.query(M.HardwareItem)}
    return [to_dict(d) | {"hardware": f"{hw[d.hardware_id].asset_tag} {hw[d.hardware_id].name}"
                          if d.hardware_id in hw else None} for d in q]


@router.post("/devices/scan")
def scan(request: Request, user: M.User = Depends(require("devices.scan")), db: Session = Depends(get_db)):
    t0 = time.time()
    found, warnings = discovery.scan_host()
    rows = discovery.persist(db, found, {"serial", "usb", "can", "network"})
    audit(db, user, "device_scan", "host", summary=f"Device scan: {len(rows)} device(s), "
                                                    f"{sum(1 for r in rows if r.hardware_id)} matched to inventory")
    db.commit()
    return {"devices": len(rows), "matched": sum(1 for r in rows if r.hardware_id), "warnings": warnings,
            "duration_s": round(time.time() - t0, 2)}


@router.put("/devices/{did}/link")
def link_device(did: int, body: LinkIn, request: Request, user: M.User = Depends(require("hardware.write")),
                db: Session = Depends(get_db)):
    d = db.get(M.DetectedDevice, did)
    if not d:
        raise HTTPException(404, "Device not found")
    if body.hardware_id is not None and not db.get(M.HardwareItem, body.hardware_id):
        raise HTTPException(422, "hardware_id: hardware item does not exist")
    d.hardware_id, d.match_rule = body.hardware_id, "manual" if body.hardware_id else None
    audit(db, user, "device_link", "device", d.id, summary=f"{d.bus}:{d.identifier} -> hardware {body.hardware_id}",
          request=request)
    db.commit()
    return to_dict(d)


# ---------------------------------------------------------------- authorisations
def _auth_out(a: M.DeviceAuthorization) -> dict:
    d = to_dict(a)
    d["active"] = a.status == "approved" and a.valid_until is not None and a.valid_until > M.utcnow()
    return d


@router.get("/authorizations")
def list_auth(_: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return [_auth_out(a) for a in db.query(M.DeviceAuthorization).order_by(M.DeviceAuthorization.id.desc())]


@router.post("/authorizations", status_code=201)
def request_auth(body: AuthRequestIn, request: Request, user: M.User = Depends(require("devices.authorize.request")),
                 db: Session = Depends(get_db)):
    if authz.is_virtual(body.interface, body.channel):
        raise HTTPException(422, "Virtual interfaces are isolated and need no authorisation")
    if not body.isolation_confirmed:
        raise HTTPException(422, "Isolation from vehicle networks must be confirmed to request an authorisation")
    if not body.actions:
        raise HTTPException(422, "At least one action is required")
    if body.project_id:
        get_project_or_404(db, user, body.project_id)
    a = M.DeviceAuthorization(project_id=body.project_id, interface=body.interface, channel=body.channel,
                              actions=sorted(set(body.actions)), purpose=body.purpose, isolation=body.isolation,
                              isolation_confirmed=True, requested_by=user.username,
                              valid_until=M.utcnow() + timedelta(hours=body.hours))
    db.add(a)
    db.flush()
    audit(db, user, "auth_request", "authorization", a.id, project_id=body.project_id,
          summary=f"Requested {', '.join(a.actions)} on {a.interface}:{a.channel}", request=request)
    db.commit()
    return _auth_out(a)


@router.post("/authorizations/{aid}/decision")
def decide_auth(aid: int, body: AuthDecisionIn, request: Request,
                user: M.User = Depends(require("devices.authorize.approve")), db: Session = Depends(get_db)):
    a = db.get(M.DeviceAuthorization, aid)
    if not a:
        raise HTTPException(404, "Authorisation not found")
    if body.decision in ("approved", "rejected"):
        if a.status != "requested":
            raise HTTPException(409, f"Authorisation is already {a.status}")
        if a.requested_by == user.username:
            raise HTTPException(403, "Four-eyes rule: the requester cannot approve or reject their own request")
    elif a.status != "approved":
        raise HTTPException(409, "Only an approved authorisation can be revoked")
    a.status, a.decided_by, a.decided_at, a.decision_note = body.decision, user.username, M.utcnow(), body.note
    audit(db, user, f"auth_{body.decision}", "authorization", a.id, project_id=a.project_id,
          summary=f"{body.decision} {', '.join(a.actions)} on {a.interface}:{a.channel}", request=request)
    db.commit()
    return _auth_out(a)


# ---------------------------------------------------------------- DBC
@router.get("/dbc")
def list_dbc(_: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return [to_dict(d, exclude={"content"}) for d in db.query(M.DbcFile).order_by(M.DbcFile.id.desc())]


def load_dbc(db: Session, dbc_id: int):
    import cantools
    d = db.get(M.DbcFile, dbc_id)
    if not d:
        raise HTTPException(404, "DBC not found")
    return d, cantools.database.load_string(d.content, database_format="dbc")


@router.post("/dbc", status_code=201)
async def upload_dbc(request: Request, file: UploadFile = File(...), project_id: int | None = Form(None),
                     user: M.User = Depends(require("comms.capture")), db: Session = Depends(get_db)):
    import cantools
    raw = await file.read()
    if len(raw) > 5_000_000:
        raise HTTPException(413, "DBC larger than 5 MB")
    text = raw.decode("utf-8", errors="replace")
    try:
        cdb = cantools.database.load_string(text, database_format="dbc")
    except Exception as e:
        raise HTTPException(422, f"Not a valid DBC file: {e}")
    sha = hashlib.sha256(raw).hexdigest()
    name = Path(file.filename or "upload.dbc").name
    existing = db.query(M.DbcFile).filter_by(name=name, sha256=sha).first()
    if existing:
        return to_dict(existing, exclude={"content"})
    d = M.DbcFile(project_id=project_id, name=name, content=text, sha256=sha, messages=len(cdb.messages),
                  signals=sum(len(m.signals) for m in cdb.messages), uploaded_by=user.username)
    db.add(d)
    db.flush()
    audit(db, user, "dbc_upload", "dbc", d.id, project_id=project_id,
          summary=f"DBC {name}: {d.messages} messages, {d.signals} signals", request=request)
    db.commit()
    return to_dict(d, exclude={"content"})


@router.get("/dbc/{dbc_id}")
def get_dbc(dbc_id: int, _: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    d, cdb = load_dbc(db, dbc_id)
    return to_dict(d, exclude={"content"}) | {"message_list": [
        {"name": m.name, "id": m.frame_id, "hex": f"0x{m.frame_id:X}", "dlc": m.length, "extended": m.is_extended_frame,
         "fd": m.is_fd, "cycle_ms": m.cycle_time, "senders": m.senders,
         "signals": [{"name": s.name, "start": s.start, "length": s.length, "scale": s.scale, "offset": s.offset,
                      "min": s.minimum, "max": s.maximum, "unit": s.unit,
                      "choices": {int(k): str(v) for k, v in (s.choices or {}).items()}} for s in m.signals]}
        for m in cdb.messages]}


# ---------------------------------------------------------------- captures
def _capture_out(c: M.Capture) -> dict:
    d = to_dict(c)
    s = S.SESSIONS.get(c.id)
    if s:
        d["stats"], d["records"], d["status"] = s.stats(), s.seq, "running"
    return d


def _new_capture(db: Session, user: M.User, kind: str, name: str | None, cfg: dict, env: str,
                 project_id: int | None, dbc_id: int | None = None) -> M.Capture:
    if project_id:
        get_project_or_404(db, user, project_id)
    c = M.Capture(project_id=project_id, kind=kind, name=name or f"{kind.upper()} {cfg.get('channel') or cfg.get('port')}",
                  config=cfg, environment=env, dbc_id=dbc_id, started_by=user.username)
    db.add(c)
    db.flush()
    return c


@router.get("/captures")
def list_captures(kind: str | None = None, _: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    q = db.query(M.Capture).order_by(M.Capture.id.desc())
    if kind:
        q = q.filter(M.Capture.kind == kind)
    return [_capture_out(c) for c in q.limit(200)]


@router.post("/captures/can", status_code=201)
def start_can(body: CaptureCanIn, request: Request, user: M.User = Depends(require("comms.capture")),
              db: Session = Depends(get_db)):
    cfg = body.model_dump(exclude={"name", "project_id", "dbc_id"})
    env = "virtual" if authz.is_virtual(body.interface) else "physical"
    if body.dbc_id:
        load_dbc(db, body.dbc_id)
    try:
        bus, _ = S.open_can_bus(cfg)  # fail fast with a clear message if the interface cannot open
        bus.shutdown()
    except Exception as e:
        raise HTTPException(409, f"Cannot open {body.interface}:{body.channel}: {e}")
    c = _new_capture(db, user, "can", body.name, cfg, env, body.project_id, body.dbc_id)
    audit(db, user, "capture_start", "capture", c.id, project_id=body.project_id,
          summary=f"CAN capture {body.interface}:{body.channel} ({env}, listen_only={body.listen_only})", request=request)
    db.commit()
    S.CanSession(c.id, cfg).start()
    return _capture_out(c)


@router.post("/captures/serial", status_code=201)
def start_serial(body: CaptureSerialIn, request: Request, user: M.User = Depends(require("comms.capture")),
                 db: Session = Depends(get_db)):
    if body.simulate and not body.port.startswith("loop://"):
        raise HTTPException(422, "Simulated sources are only allowed on loop:// ports")
    cfg = body.model_dump(exclude={"name", "project_id"})
    env = "virtual" if body.port.startswith("loop://") else "physical"
    try:
        S.open_serial(cfg).close()
    except Exception as e:
        raise HTTPException(409, f"Cannot open serial port {body.port}: {e}")
    c = _new_capture(db, user, "serial", body.name, cfg, env, body.project_id)
    audit(db, user, "capture_start", "capture", c.id, project_id=body.project_id,
          summary=f"Serial capture {body.port} @ {body.baudrate} ({env}, decoder {body.decoder})", request=request)
    db.commit()
    S.SerialSession(c.id, cfg).start()
    return _capture_out(c)


@router.post("/captures/udp", status_code=201)
def start_udp(body: CaptureUdpIn, request: Request, user: M.User = Depends(require("comms.capture")),
              db: Session = Depends(get_db)):
    cfg = body.model_dump(exclude={"name", "project_id"})
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((body.host, body.port))
        s.close()
    except OSError as e:
        raise HTTPException(409, f"Cannot bind UDP {body.host}:{body.port}: {e}")
    c = _new_capture(db, user, "udp", body.name, cfg, "network", body.project_id)
    audit(db, user, "capture_start", "capture", c.id, project_id=body.project_id,
          summary=f"UDP capture on {body.host}:{body.port}", request=request)
    db.commit()
    S.UdpSession(c.id, cfg).start()
    return _capture_out(c)


def _capture(db: Session, cid: int) -> M.Capture:
    c = db.get(M.Capture, cid)
    if not c:
        raise HTTPException(404, "Capture not found")
    return c


@router.get("/captures/{cid}")
def get_capture(cid: int, _: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return _capture_out(_capture(db, cid))


@router.post("/captures/{cid}/stop")
def stop_capture(cid: int, request: Request, user: M.User = Depends(require("comms.capture")),
                 db: Session = Depends(get_db)):
    _capture(db, cid)
    db.rollback()  # end our read snapshot so the session thread can commit its final state (SQLite WAL)
    s = S.SESSIONS.get(cid)
    if s:
        s.stop()
    db.expire_all()
    c = db.get(M.Capture, cid)
    audit(db, user, "capture_stop", "capture", cid, project_id=c.project_id, summary=f"Capture {cid} stopped "
                                                                                    f"({c.records} records)")
    db.commit()
    return _capture_out(c)


@router.get("/captures/{cid}/records")
def capture_records(cid: int, after: int = 0, limit: int = Query(500, le=5000), decode: bool = True,
                    _: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    c = _capture(db, cid)
    s = S.SESSIONS.get(cid)
    recs = s.since(after, limit) if s and (not s.ring or s.ring[0]["seq"] <= after + 1) else \
        S.read_records(cid, after, limit)
    if decode and c.kind == "can" and c.dbc_id:
        _, cdb = load_dbc(db, c.dbc_id)
        ids = {m.frame_id: m for m in cdb.messages}
        for r in recs:
            m = ids.get(r["id"])
            if m and not r.get("err"):
                try:
                    r["message"] = m.name
                    r["signals"] = {k: (str(v) if not isinstance(v, (int, float)) else round(v, 6))
                                    for k, v in m.decode(bytes.fromhex(r["data"]), decode_choices=True).items()}
                except Exception as e:
                    r["decode_error"] = str(e)
    return {"records": recs, "last_seq": recs[-1]["seq"] if recs else after, "running": cid in S.SESSIONS}


@router.get("/captures/{cid}/signal")
def signal_series(cid: int, message: str, signal: str, max_points: int = Query(5000, le=50000),
                  _: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    c = _capture(db, cid)
    if c.kind != "can" or not c.dbc_id:
        raise HTTPException(422, "Signal series need a CAN capture with a DBC")
    _, cdb = load_dbc(db, c.dbc_id)
    try:
        m = cdb.get_message_by_name(message)
    except KeyError:
        raise HTTPException(404, f"Message {message} not in DBC")
    t, v = [], []
    for r in S.read_records(cid):
        if r.get("err") or r["id"] != m.frame_id:
            continue
        try:
            val = m.decode(bytes.fromhex(r["data"]), decode_choices=False)[signal]
        except Exception:
            continue
        t.append(r["t"])
        v.append(float(val))
    step = max(1, len(t) // max_points)
    sig = next((s for s in m.signals if s.name == signal), None)
    return {"message": message, "signal": signal, "unit": sig.unit if sig else None, "t": t[::step], "v": v[::step],
            "points": len(t)}


EXPORT = {"asc": "ASCWriter", "blf": "BLFWriter", "csv": "CSVWriter", "log": "CanutilsLogWriter"}


@router.get("/captures/{cid}/export")
def export_capture(cid: int, fmt: str = Query("asc", pattern="^(asc|blf|csv|log|jsonl)$"),
                   user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    import can
    c = _capture(db, cid)
    recs = S.read_records(cid)
    name = f"capture_{cid}.{fmt}"
    if fmt == "jsonl" or c.kind != "can":
        if fmt not in ("jsonl", "csv"):
            raise HTTPException(422, f"{fmt} export is only available for CAN captures")
        if fmt == "jsonl":
            data = "".join(__import__("json").dumps(r) + "\n" for r in recs).encode()
        else:
            import csv
            buf = io.StringIO()
            keys = sorted({k for r in recs for k in r if k != "decoded"})
            w = csv.DictWriter(buf, fieldnames=keys + ["decoded"], extrasaction="ignore")
            w.writeheader()
            for r in recs:
                w.writerow({**r, "decoded": __import__("json").dumps(r.get("decoded")) if r.get("decoded") else ""})
            data = buf.getvalue().encode()
        return Response(data, media_type="application/octet-stream",
                        headers={"Content-Disposition": f'attachment; filename="{name}"'})
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / name
        writer = getattr(can, EXPORT[fmt])(str(path))
        for r in recs:
            writer.on_message_received(can.Message(
                timestamp=r["t"], arbitration_id=r["id"], is_extended_id=r["ext"], is_fd=r.get("fd", False),
                bitrate_switch=r.get("brs", False), is_error_frame=r.get("err", False), is_remote_frame=r.get("rtr", False),
                dlc=r["dlc"], data=bytes.fromhex(r["data"]), channel=c.config.get("channel")))
        writer.stop()
        data = path.read_bytes()
    audit(db, user, "capture_export", "capture", cid, project_id=c.project_id, summary=f"Exported capture {cid} as {fmt}")
    db.commit()
    return Response(data, media_type="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ---------------------------------------------------------------- transmit, generator, replay
def _can_cfg(body: CanCfg) -> dict:
    return body.model_dump(include={"interface", "channel", "bitrate", "fd", "data_bitrate"})


@router.post("/can/transmit")
def can_transmit(body: TransmitIn, request: Request, user: M.User = Depends(require("comms.transmit")),
                 db: Session = Depends(get_db)):
    a = authz.require(db, body.interface, body.channel, "transmit")
    data = bytes.fromhex(body.data_hex)
    if len(data) > 8 and not body.fd:
        raise HTTPException(422, "Classical CAN frames carry at most 8 bytes (enable CAN FD for up to 64)")
    try:
        S.send_can(_can_cfg(body), body.arbitration_id, data, body.extended, body.fd)
    except Exception as e:
        raise HTTPException(409, f"Transmit failed: {e}")
    audit(db, user, "can_transmit", "bus", f"{body.interface}:{body.channel}",
          summary=f"TX 0x{body.arbitration_id:X} [{len(data)}] {body.data_hex} on {body.interface}:{body.channel}"
                  + (f" under authorisation #{a.id}" if a else " (virtual)"), request=request)
    db.commit()
    return {"ok": True, "environment": "virtual" if a is None else "physical", "authorization_id": a.id if a else None}


@router.get("/can/tasks")
def list_tasks(_: M.User = Depends(require("internal.view"))):
    return [t.info() for t in S.TASKS.values()]


@router.post("/can/generator", status_code=201)
def start_generator(body: GeneratorIn, request: Request, user: M.User = Depends(require("comms.transmit")),
                    db: Session = Depends(get_db)):
    a = authz.require(db, body.interface, body.channel, "generate")
    d, _ = load_dbc(db, body.dbc_id)
    key = f"gen:{body.interface}:{body.channel}"
    try:
        S.DbcGenerator(key, _can_cfg(body), user.username, d.content, body.messages).start()
    except RuntimeError as e:
        raise HTTPException(409, str(e))
    audit(db, user, "can_generator", "bus", key, summary=f"Synthetic traffic from {d.name} on {body.interface}:"
                                                         f"{body.channel}" + (f" (auth #{a.id})" if a else " (virtual)"),
          request=request)
    db.commit()
    return S.TASKS[key].info()


@router.post("/can/replay", status_code=201)
def start_replay(body: ReplayIn, request: Request, user: M.User = Depends(require("comms.transmit")),
                 db: Session = Depends(get_db)):
    c = _capture(db, body.capture_id)
    if c.kind != "can":
        raise HTTPException(422, "Only CAN captures can be replayed")
    a = authz.require(db, body.interface, body.channel, "replay")
    key = f"replay:{body.interface}:{body.channel}"
    try:
        S.CanReplay(key, _can_cfg(body), user.username, c.id, body.speed, body.loop).start()
    except RuntimeError as e:
        raise HTTPException(409, str(e))
    audit(db, user, "can_replay", "bus", key, project_id=c.project_id,
          summary=f"Replay capture {c.id} x{body.speed} on {body.interface}:{body.channel}"
                  + (f" (auth #{a.id})" if a else " (virtual)"), request=request)
    db.commit()
    return S.TASKS[key].info()


@router.post("/can/tasks/stop")
def stop_task(key: str, request: Request, user: M.User = Depends(require("comms.transmit"))):
    t = S.TASKS.get(key)
    if not t:
        raise HTTPException(404, "Task not found")
    t.stop()
    return t.info()


@router.post("/captures/{cid}/serial-write")
def serial_write(cid: int, body: SerialWriteIn, request: Request, user: M.User = Depends(require("comms.transmit")),
                 db: Session = Depends(get_db)):
    c = _capture(db, cid)
    s = S.SESSIONS.get(cid)
    if c.kind != "serial" or not isinstance(s, S.SerialSession):
        raise HTTPException(409, "Serial capture is not running")
    a = authz.require(db, "serial", c.config["port"], "transmit")
    data = bytes.fromhex(body.hex) if body.hex else (body.text or "").encode()
    if body.text is not None and body.append_crlf:
        data += b"\r\n"
    s.write(data)
    audit(db, user, "serial_write", "capture", cid, summary=f"Wrote {len(data)} bytes to {c.config['port']}"
                                                          + (f" (auth #{a.id})" if a else " (virtual)"), request=request)
    db.commit()
    return {"ok": True, "bytes": len(data)}


@router.get("/serial/ports")
def serial_ports(_: M.User = Depends(require("internal.view"))):
    from serial.tools import list_ports
    return [{"port": p.device, "description": p.description, "hwid": p.hwid, "manufacturer": p.manufacturer,
             "serial_number": p.serial_number} for p in list_ports.comports()] + \
        [{"port": "loop://", "description": "Virtual loopback (isolated, supports simulated NMEA/UBX source)",
          "hwid": "virtual", "manufacturer": None, "serial_number": None}]


# ---------------------------------------------------------------- Ethernet diagnostics
_last_io: dict[str, tuple[float, Any]] = {}


@router.get("/net/interfaces")
def net_interfaces(_: M.User = Depends(require("internal.view"))):
    import psutil
    now = time.time()
    io_now = psutil.net_io_counters(pernic=True)
    stats = psutil.net_if_stats()
    out = []
    for name, addrs in psutil.net_if_addrs().items():
        st, c = stats.get(name), io_now.get(name)
        rates = None
        prev = _last_io.get(name)
        if prev and c and now > prev[0]:
            dt = now - prev[0]
            rates = {"rx_mbps": round((c.bytes_recv - prev[1].bytes_recv) * 8 / dt / 1e6, 4),
                     "tx_mbps": round((c.bytes_sent - prev[1].bytes_sent) * 8 / dt / 1e6, 4)}
        if c:
            _last_io[name] = (now, c)
        out.append({"name": name, "up": bool(st and st.isup), "speed_mbps": st.speed if st else None,
                    "mtu": st.mtu if st else None, "duplex": str(st.duplex).split(".")[-1] if st else None,
                    "addresses": [{"family": a.family.name, "address": a.address, "netmask": a.netmask} for a in addrs],
                    "counters": c._asdict() if c else None, "rates": rates})
    return out


def tcp_probe(host: str, port: int, count: int, timeout_s: float) -> dict:
    lat, errors = [], []
    for _ in range(count):
        t0 = time.perf_counter()
        try:
            with socket.create_connection((host, port), timeout=timeout_s):
                lat.append((time.perf_counter() - t0) * 1000)
        except OSError as e:
            errors.append(str(e))
    ok = len(lat)
    return {"host": host, "port": port, "attempts": count, "succeeded": ok,
            "loss_pct": round(100 * (count - ok) / count, 1),
            "latency_ms": {"min": round(min(lat), 3), "avg": round(statistics.mean(lat), 3), "max": round(max(lat), 3),
                           "jitter": round(statistics.pstdev(lat), 3)} if lat else None,
            "errors": sorted(set(errors))[:3]}


@router.post("/net/tcp-probe")
def net_tcp_probe(body: TcpProbeIn, request: Request, user: M.User = Depends(require("comms.capture")),
                  db: Session = Depends(get_db)):
    r = tcp_probe(body.host, body.port, body.count, body.timeout_s)
    audit(db, user, "tcp_probe", "network", f"{body.host}:{body.port}",
          summary=f"TCP probe {body.host}:{body.port}: {r['succeeded']}/{r['attempts']}", request=request)
    db.commit()
    return r


# ---------------------------------------------------------------- offline CAN logs: import & protocol analysis (Phase 5)
READERS = {".asc": "ASCReader", ".blf": "BLFReader", ".csv": "CSVReader", ".log": "CanutilsLogReader", ".trc": "TRCReader"}


@router.post("/captures/import", status_code=201)
async def import_capture(request: Request, file: UploadFile = File(...), project_id: int | None = Form(None),
                         dbc_id: int | None = Form(None), user: M.User = Depends(require("comms.capture")),
                         db: Session = Depends(get_db)):
    """Import a CAN log recorded elsewhere (Vector ASC/BLF, python-can CSV, candump .log, PEAK TRC)."""
    import json as _json

    import can
    name = Path(file.filename or "log.asc").name
    ext = Path(name).suffix.lower()
    if ext not in READERS:
        raise HTTPException(422, f"Unsupported CAN log type '{ext}' (supported: {', '.join(READERS)})")
    raw = await file.read()
    if len(raw) > 200_000_000:
        raise HTTPException(413, "CAN log larger than 200 MB")
    if project_id:
        get_project_or_404(db, user, project_id)
    if dbc_id:
        load_dbc(db, dbc_id)
    c = M.Capture(project_id=project_id, kind="can", name=f"Imported {name}", environment="imported", dbc_id=dbc_id,
                  config={"source_file": name, "sha256": hashlib.sha256(raw).hexdigest()}, started_by=user.username,
                  status="stopped")
    db.add(c)
    db.flush()
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / name
        p.write_bytes(raw)
        kw = {"relative_timestamp": False} if ext == ".asc" else {}
        try:
            reader = getattr(can, READERS[ext])(str(p), **kw)
            n = 0
            with open(S.capture_file(c.id), "w", encoding="utf-8") as out:
                for m in reader:
                    n += 1
                    out.write(_json.dumps({"seq": n, "t": round(m.timestamp, 6), "id": m.arbitration_id,
                                           "ext": m.is_extended_id, "fd": m.is_fd, "brs": m.bitrate_switch, "dlc": m.dlc,
                                           "data": bytes(m.data).hex(), "err": m.is_error_frame, "rtr": m.is_remote_frame},
                                          separators=(",", ":")) + "\n")
        except Exception as e:
            db.rollback()
            raise HTTPException(422, f"Could not read {name}: {type(e).__name__}: {e}")
    if n == 0:
        db.rollback()
        raise HTTPException(422, f"{name} contains no CAN frames")
    recs = S.read_records(c.id)
    t = [r["t"] for r in recs]
    c.records, c.started_at = n, datetime.utcfromtimestamp(min(t))
    c.stopped_at = datetime.utcfromtimestamp(max(t))
    c.stats = {"records": n, "error_frames": sum(1 for r in recs if r.get("err")), "duration_s": round(max(t) - min(t), 3)}
    audit(db, user, "capture_import", "capture", c.id, project_id=project_id, summary=f"Imported CAN log {name}: {n} frames",
          request=request)
    db.commit()
    return _capture_out(c)


@router.get("/captures/{cid}/analysis")
def capture_analysis(cid: int, dbc_id: int | None = None, tolerance_pct: float = Query(10, gt=0, le=100),
                     _: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    from ..services.analysis import can_analysis
    c = _capture(db, cid)
    if c.kind != "can":
        raise HTTPException(422, "Protocol analysis is available for CAN captures")
    did = dbc_id or c.dbc_id
    cdb = load_dbc(db, did)[1] if did else None
    return can_analysis(S.read_records(cid), cdb, tolerance_pct / 100) | {"capture_id": cid, "dbc_id": did}


@router.post("/captures/{cid}/analysis/to-timeline")
def analysis_to_timeline(cid: int, request: Request, dbc_id: int | None = None, user: M.User = Depends(require("debug.write")),
                         db: Session = Depends(get_db)):
    """Publish protocol findings (and error frames) as events on the project debugging timeline."""
    from ..services.analysis import _internal_source, can_analysis, store_events
    from ..services.logparse import Parsed
    c = _capture(db, cid)
    if not c.project_id:
        raise HTTPException(422, "Assign the capture to a project first")
    did = dbc_id or c.dbc_id
    cdb = load_dbc(db, did)[1] if did else None
    recs = S.read_records(cid)
    res = can_analysis(recs, cdb)
    src = _internal_source(db, c.project_id, f"CAN analysis: capture #{c.id}", "communication", f"CAN {c.config.get('channel') or c.name}")
    db.query(M.LogEvent).filter_by(source_id=src.id).delete()
    lvl = {"error": "error", "warning": "warning", "info": "info"}
    t0 = datetime.utcfromtimestamp(recs[0]["t"]) if recs else (c.started_at or M.utcnow())
    parsed = [Parsed(t0, lvl[f["severity"]], f"[{f['check']}] {f['detail']}", src.component, {"can_id": f["id"]}) for f in res["findings"]]
    parsed += [Parsed(datetime.utcfromtimestamp(r["t"]), "error", "CAN error frame", src.component, {}) for r in recs if r.get("err")][:2000]
    n = store_events(db, src, parsed)
    audit(db, user, "capture_to_timeline", "capture", cid, project_id=c.project_id, summary=f"{n} CAN analysis event(s) published",
          request=request)
    db.commit()
    return {"events": n, "source_id": src.id}
