"""Authentication, users, audit log, backups, metadata."""
from __future__ import annotations

import sqlite3
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session

from .. import config
from .. import models as M
from ..db import get_db, get_engine
from ..schemas import LoginIn, PasswordChangeIn, UserIn, UserPatch
from ..security import (ROLES, audit, create_token, current_user, hash_password, password_problems, permissions_for,
                        require, verify_password)
from ..services.records import to_dict

router = APIRouter(prefix="/api/v1", tags=["auth & administration"])


def user_out(u: M.User) -> dict:
    d = to_dict(u, exclude={"password_hash"})
    d["role_label"] = ROLES.get(u.role, u.role)
    return d


@router.get("/health")
def health():
    return {"status": "ok", "app": config.APP_NAME, "version": config.APP_VERSION, "phase": config.PHASE}


@router.post("/auth/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    u = db.query(M.User).filter(M.User.username == body.username.lower()).first()
    if not u or not u.active or not verify_password(body.password, u.password_hash):
        audit(db, body.username[:64] or "?", "login_failed", "user", request=request)
        db.commit()
        raise HTTPException(401, "Invalid username or password")
    u.last_login = M.utcnow()
    audit(db, u, "login", "user", u.id, request=request)
    db.commit()
    return {"token": create_token(u), "user": user_out(u), "permissions": permissions_for(u.role)}


@router.get("/auth/me")
def me(user: M.User = Depends(current_user)):
    return {"user": user_out(user), "permissions": permissions_for(user.role)}


@router.post("/auth/password")
def change_password(body: PasswordChangeIn, request: Request, user: M.User = Depends(current_user),
                    db: Session = Depends(get_db)):
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(400, "Current password is wrong")
    if probs := password_problems(body.new_password):
        raise HTTPException(422, "Password needs " + ", ".join(probs))
    user = db.merge(user)
    user.password_hash = hash_password(body.new_password)
    audit(db, user, "password_changed", "user", user.id, request=request)
    db.commit()
    return {"token": create_token(user)}


@router.get("/meta")
def meta(_: M.User = Depends(current_user)):
    """Controlled vocabularies for the UI."""
    return {
        "stages": [{"key": k, "label": l} for k, l in M.STAGES],
        "gated_stages": sorted(M.GATED_STAGES),
        "domains": M.DOMAINS, "priorities": M.PRIORITIES, "acceptance": M.ACCEPTANCE,
        "milestone_status": M.MILESTONE_STATUS,
        "req_categories": M.REQ_CATEGORIES, "req_priority": M.REQ_PRIORITY, "verification": M.VERIFICATION,
        "req_status": M.REQ_STATUS, "trace_targets": M.TRACE_TARGETS, "trace_relations": M.TRACE_RELATIONS,
        "evidence_kinds": M.EVIDENCE_KINDS, "evidence_results": M.EVIDENCE_RESULTS,
        "hw_categories": M.HW_CATEGORIES, "hw_interfaces": M.HW_INTERFACES, "hw_status": M.HW_STATUS,
        "sw_kinds": M.SW_KINDS, "sw_languages": M.SW_LANGUAGES, "sw_status": M.SW_STATUS,
        "dep_kinds": M.DEP_KINDS, "compat_status": M.COMPAT_STATUS,
        "roles": [{"key": k, "label": l} for k, l in ROLES.items()],
    }


# ---------------------------------------------------------------- users
@router.get("/users")
def list_users(user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    users = db.query(M.User).order_by(M.User.full_name).all()
    if user.role == "CUSTOMER_VIEWER":
        return [{"id": u.id, "full_name": u.full_name, "role_label": ROLES.get(u.role)} for u in users if u.active]
    return [user_out(u) for u in users]


@router.post("/users", status_code=201)
def create_user(body: UserIn, request: Request, admin: M.User = Depends(require("admin.users")),
                db: Session = Depends(get_db)):
    if body.role not in ROLES:
        raise HTTPException(422, f"Unknown role {body.role}")
    if probs := password_problems(body.password):
        raise HTTPException(422, "Password needs " + ", ".join(probs))
    if db.query(M.User).filter_by(username=body.username).first():
        raise HTTPException(409, "Username already exists")
    u = M.User(username=body.username, full_name=body.full_name, email=body.email, role=body.role,
               password_hash=hash_password(body.password))
    db.add(u)
    db.flush()
    audit(db, admin, "create", "user", u.id, summary=f"Created user {u.username} ({ROLES[u.role]})", request=request)
    db.commit()
    return user_out(u)


@router.patch("/users/{user_id}")
def update_user(user_id: int, body: UserPatch, request: Request, admin: M.User = Depends(require("admin.users")),
                db: Session = Depends(get_db)):
    u = db.get(M.User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    changes = body.model_dump(exclude_unset=True)
    if "role" in changes and changes["role"] not in ROLES:
        raise HTTPException(422, f"Unknown role {changes['role']}")
    if u.id == admin.id and (changes.get("active") is False or changes.get("role", "ADMIN") != "ADMIN"):
        raise HTTPException(400, "You cannot deactivate or demote your own administrator account")
    if pw := changes.pop("password", None):
        if probs := password_problems(pw):
            raise HTTPException(422, "Password needs " + ", ".join(probs))
        u.password_hash = hash_password(pw)
    for k, v in changes.items():
        setattr(u, k, v)
    audit(db, admin, "update", "user", u.id, summary=f"Updated user {u.username}",
          detail={k: v for k, v in changes.items()} | ({"password": "reset"} if pw else {}), request=request)
    db.commit()
    return user_out(u)


# ---------------------------------------------------------------- audit
@router.get("/audit")
def audit_log(limit: int = Query(200, le=2000), project_id: int | None = None, username: str | None = None,
              _: M.User = Depends(require("admin.audit")), db: Session = Depends(get_db)):
    q = db.query(M.AuditLog).order_by(M.AuditLog.id.desc())
    if project_id:
        q = q.filter(M.AuditLog.project_id == project_id)
    if username:
        q = q.filter(M.AuditLog.username == username)
    return [to_dict(a) for a in q.limit(limit)]


# ---------------------------------------------------------------- backup (SQLite)
@router.post("/admin/backup")
def backup(request: Request, admin: M.User = Depends(require("admin.backup")), db: Session = Depends(get_db)):
    s = config.settings
    if not s.is_sqlite:
        raise HTTPException(400, "Online backup is implemented for SQLite only; use pg_dump for PostgreSQL")
    s.ensure_dirs()
    target = s.backup_dir / f"integra-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.db"
    raw = get_engine().raw_connection()
    try:
        dst = sqlite3.connect(target)
        with dst:
            raw.driver_connection.backup(dst)
        dst.close()
    finally:
        raw.close()
    audit(db, admin, "backup", "database", summary=f"Backup {target.name}", request=request)
    db.commit()
    return {"file": target.name, "bytes": target.stat().st_size}


@router.get("/admin/backups")
def list_backups(_: M.User = Depends(require("admin.backup"))):
    d = config.settings.backup_dir
    files = sorted(d.glob("*.db"), reverse=True) if d.exists() else []
    return [{"file": f.name, "bytes": f.stat().st_size,
             "created": datetime.fromtimestamp(f.stat().st_mtime).isoformat(timespec="seconds")} for f in files]
