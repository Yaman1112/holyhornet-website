"""AI systems integration assistant (Phase 8, module O): settings, built-in record analyses (no AI), conversations with
the Claude-backed assistant, and proposals that engineers turn into draft records."""
from __future__ import annotations

import hashlib
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import Field
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..schemas import In, one_of
from ..security import audit, can, check_project_write, get_project_or_404, require
from ..services import assistant as AS
from ..services import assistant_tools as T
from ..services.records import to_dict

router = APIRouter(prefix="/api/v1", tags=["assistant"])


# ---------------------------------------------------------------- status & settings
@router.get("/assistant/status")
def status(user: M.User = Depends(require("assistant.use")), db: Session = Depends(get_db)):
    s = AS.get_settings(db)
    return {"settings": s, "provider": AS.provider_status(), "models": AS.MODELS, "efforts": AS.EFFORTS,
            "analyses": [{"key": k, "title": v[0], "needs_component": v[1] == "connection_diagnosis"} for k, v in T.ANALYSES.items()],
            "can_configure": can(user, "assistant.admin"),
            "data_notice": "When enabled, the records the assistant reads for a question (requirements, architecture, "
                           "inventory, test results, log excerpts, issues, releases) are sent to Anthropic's API for "
                           "processing. Built-in analyses run locally and send nothing."}


class SettingsIn(In):
    enabled: bool
    model: Annotated[str, one_of(AS.MODELS)] = AS.DEFAULT_MODEL
    effort: Annotated[str, one_of(AS.EFFORTS)] = "high"
    max_tool_rounds: Annotated[int, Field(ge=2, le=30)] = 12
    acknowledge_data_sharing: bool = False


@router.put("/assistant/settings")
def put_settings(body: SettingsIn, request: Request, user: M.User = Depends(require("assistant.admin")),
                 db: Session = Depends(get_db)):
    cur = AS.get_settings(db)
    if body.enabled and not cur["enabled"] and not body.acknowledge_data_sharing:
        raise HTTPException(422, "acknowledge_data_sharing: enabling sends project records to Anthropic's API; confirm it")
    val = {"enabled": body.enabled, "model": body.model, "effort": body.effort, "max_tool_rounds": body.max_tool_rounds,
           "acknowledged_by": user.username if body.enabled and not cur["enabled"] else cur.get("acknowledged_by")}
    row = db.get(M.AppSetting, "assistant")
    if row:
        row.value, row.updated_by, row.updated_at = val, user.username, M.utcnow()
    else:
        db.add(M.AppSetting(key="assistant", value=val, updated_by=user.username))
    audit(db, user, "assistant_settings", "app_setting", "assistant", summary=f"Assistant {'enabled' if body.enabled else 'disabled'} "
          f"({body.model}, effort {body.effort})", detail=val, request=request)
    db.commit()
    return AS.get_settings(db)


# ---------------------------------------------------------------- built-in analyses (no AI)
class AnalysisIn(In):
    component: str | None = None
    hardware_query: str | None = None
    since_version: str | None = None
    a_version: str | None = None
    b_version: str | None = None
    capture_id: int | None = None


@router.post("/projects/{pid}/assistant/analyses/{key}")
def run_analysis(pid: int, key: str, body: AnalysisIn, request: Request, user: M.User = Depends(require("assistant.use")),
                 db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    r = AS.analysis_answer(db, pid, key, body.model_dump(exclude_none=True))
    audit(db, user, "assistant_analysis", "project", pid, project_id=pid, summary=f"Analysis: {r['title']}", request=request)
    db.commit()
    return r


# ---------------------------------------------------------------- conversations
def _conv(db: Session, user: M.User, cid: int) -> M.AssistantConversation:
    c = db.get(M.AssistantConversation, cid)
    if not c or (c.username != user.username and user.role != "ADMIN"):
        raise HTTPException(404, "Conversation not found")
    get_project_or_404(db, user, c.project_id)
    return c


def _conv_out(db: Session, c: M.AssistantConversation, full: bool = False) -> dict:
    d = to_dict(c)
    if full:
        d["messages"] = [to_dict(m) for m in db.query(M.AssistantMessage).filter_by(conversation_id=c.id).order_by(M.AssistantMessage.id)]
        d["proposals"] = [to_dict(p) for p in db.query(M.AssistantProposal).filter_by(conversation_id=c.id).order_by(M.AssistantProposal.id)]
    return d


class ConvIn(In):
    title: Annotated[str, Field(min_length=1, max_length=200)] = "New conversation"


@router.get("/projects/{pid}/assistant/conversations")
def list_convs(pid: int, user: M.User = Depends(require("assistant.use")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_conv_out(db, c) for c in db.query(M.AssistantConversation).filter_by(project_id=pid, username=user.username)
            .order_by(M.AssistantConversation.updated_at.desc())]


@router.post("/projects/{pid}/assistant/conversations", status_code=201)
def create_conv(pid: int, body: ConvIn, user: M.User = Depends(require("assistant.use")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    c = M.AssistantConversation(project_id=pid, username=user.username, title=body.title)
    db.add(c)
    db.commit()
    return _conv_out(db, c, full=True)


@router.get("/assistant/conversations/{cid}")
def get_conv(cid: int, user: M.User = Depends(require("assistant.use")), db: Session = Depends(get_db)):
    return _conv_out(db, _conv(db, user, cid), full=True)


@router.delete("/assistant/conversations/{cid}")
def delete_conv(cid: int, user: M.User = Depends(require("assistant.use")), db: Session = Depends(get_db)):
    c = _conv(db, user, cid)
    db.delete(c)
    db.commit()
    return {"ok": True}


class AskIn(In):
    question: Annotated[str, Field(min_length=2, max_length=4000)]


@router.post("/assistant/conversations/{cid}/ask")
def ask(cid: int, body: AskIn, request: Request, user: M.User = Depends(require("assistant.use")), db: Session = Depends(get_db)):
    c = _conv(db, user, cid)
    if db.query(M.AssistantMessage).filter_by(conversation_id=c.id).count() == 0 and c.title == "New conversation":
        c.title = body.question[:120]
    msg = AS.ask(db, c, body.question, user)
    audit(db, user, "assistant_query", "assistant_conversation", c.id, project_id=c.project_id,
          summary=f"Assistant: {body.question[:200]}",
          detail={"tools": [t["name"] for t in msg.tool_calls], "usage": msg.usage, "model": msg.model, "error": msg.error},
          request=request)
    db.commit()
    return _conv_out(db, c, full=True)


# ---------------------------------------------------------------- proposals -> draft records
def _proposal(db: Session, user: M.User, prid: int) -> tuple[M.AssistantProposal, M.Project]:
    pr = db.get(M.AssistantProposal, prid)
    if not pr:
        raise HTTPException(404, "Proposal not found")
    _conv(db, user, pr.conversation_id)
    return pr, get_project_or_404(db, user, pr.project_id)


@router.post("/assistant/proposals/{prid}/create")
def create_from_proposal(prid: int, request: Request, user: M.User = Depends(require("assistant.use")),
                         db: Session = Depends(get_db)):
    pr, p = _proposal(db, user, prid)
    check_project_write(db, user, p)
    if pr.status != "proposed":
        raise HTTPException(409, f"Proposal is {pr.status}")
    d = pr.payload
    note = f"Drafted by the AI assistant (proposal P-{pr.id}); accepted by {user.username}. Review before use."
    if pr.kind == "test_case":
        if not can(user, "tests.write"):
            raise HTTPException(403, "Creating test cases needs the tests.write permission")
        import re
        nums = [int(m.group(1)) for (r,) in db.query(M.TestCase.ref).filter_by(project_id=p.id) if (m := re.fullmatch(r"TC-(\d+)", r))]
        code = d.get("code") or None
        tc = M.TestCase(project_id=p.id, ref=f"TC-{(max(nums) + 1 if nums else 1):03d}", name=str(d.get("name"))[:200],
                        description=note, objective=d.get("objective"), test_type=d.get("test_type") if d.get("test_type") in M.TEST_TYPES else "integration",
                        environments=[e for e in d.get("environments") or [] if e in M.TEST_ENVS] or ["sil"],
                        procedure=d.get("procedure"), expected_output=d.get("expected_output"),
                        acceptance_criteria=d.get("acceptance_criteria"), automation="pytest" if code else "manual",
                        code=code, code_version=1 if code else 0, code_status="draft", created_by=user.username)
        db.add(tc)
        db.flush()
        for ref in d.get("requirement_refs") or []:
            if T.ref_label(db, p.id, ref) and ref.startswith("requirement:"):
                rq = db.get(M.Requirement, int(ref.split(":")[1]))
                db.add(M.TraceLink(requirement_id=rq.id, target_type="test_case", target_ref=str(tc.id),
                                   target_label=f"{tc.ref} {tc.name}", relation="verified_by", created_by=user.username))
        pr.record_ref = f"test_case:{tc.id}"
        summary = f"{tc.ref} created as draft from assistant proposal P-{pr.id}" + (
            f" (code sha256 {hashlib.sha256(code.encode()).hexdigest()[:12]}, not approved)" if code else "")
    elif pr.kind == "test_rig":
        if not can(user, "rigs.write"):
            raise HTTPException(403, "Creating rigs needs the rigs.write permission")
        rig = M.TestRig(project_id=p.id, name=str(d.get("name"))[:160], description=f"{d.get('description') or ''}\n\n{note}".strip(),
                        kind=d.get("kind") if d.get("kind") in M.RIG_KINDS else "virtual", status="draft", created_by=user.username)
        db.add(rig)
        db.flush()
        ids = {}
        for n, c in enumerate(d.get("components") or []):
            hw = None
            if c.get("hardware_ref") and T.ref_label(db, p.id, c["hardware_ref"]):
                hw = int(c["hardware_ref"].split(":")[1])
            key = str(c.get("key") or f"c{n}")[:48]
            if key in ids:
                continue
            rc = M.RigComponent(rig_id=rig.id, key=key, name=str(c.get("name") or key)[:160],
                                role=c.get("role") if c.get("role") in M.RIG_ROLES else "other", hardware_id=hw,
                                x=(n % 3) * 300, y=(n // 3) * 180)
            db.add(rc)
            db.flush()
            ids[key] = rc.id
        for l in d.get("links") or []:
            if l.get("source") in ids and l.get("target") in ids:
                db.add(M.RigConnection(rig_id=rig.id, source_id=ids[l["source"]], target_id=ids[l["target"]],
                                       kind=l.get("kind") if l.get("kind") in M.RIG_LINKS else "communication", interface=l.get("interface")))
        pr.record_ref = f"test_rig:{rig.id}"
        summary = f"Rig '{rig.name}' created as draft from assistant proposal P-{pr.id}"
    else:
        raise HTTPException(422, "Unknown proposal kind")
    pr.status, pr.decided_by, pr.decided_at = "created", user.username, M.utcnow()
    audit(db, user, "assistant_proposal_accept", "assistant_proposal", pr.id, project_id=p.id, summary=summary, request=request)
    db.commit()
    return to_dict(pr)


@router.post("/assistant/proposals/{prid}/dismiss")
def dismiss(prid: int, request: Request, user: M.User = Depends(require("assistant.use")), db: Session = Depends(get_db)):
    pr, p = _proposal(db, user, prid)
    if pr.status != "proposed":
        raise HTTPException(409, f"Proposal is {pr.status}")
    pr.status, pr.decided_by, pr.decided_at = "dismissed", user.username, M.utcnow()
    audit(db, user, "assistant_proposal_dismiss", "assistant_proposal", pr.id, project_id=p.id, summary=f"Dismissed P-{pr.id}", request=request)
    db.commit()
    return to_dict(pr)
