"""Hardware inventory (components, configuration records) and software inventory (versions, dependencies,
hardware compatibility). Records only: device detection and live interfaces arrive with Phase 3 adapters."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..schemas import (CompatIn, ConfigRecordIn, DependencyIn, HardwareIn, HardwarePatch, SoftwareIn, SoftwarePatch)
from ..security import audit, can, check_project_write, current_user, get_project_or_404, require, visible_project_ids
from ..services.records import record_revision, revision_count, to_dict

router = APIRouter(prefix="/api/v1", tags=["inventory"])


def _scope(db: Session, user: M.User, q, col):
    """Customer viewers only see items assigned to their projects; restricted projects hide their items."""
    ids = visible_project_ids(db, user)
    if ids is None:
        return q
    if user.role == "CUSTOMER_VIEWER":
        return q.filter(col.in_(ids))
    return q.filter(col.is_(None) | col.in_(ids))


def _check_item_visible(db: Session, user: M.User, project_id: int | None) -> None:
    if project_id is not None:
        get_project_or_404(db, user, project_id)
    elif user.role == "CUSTOMER_VIEWER":
        raise HTTPException(404, "Not found")


def _check_assign(db: Session, user: M.User, project_id: int | None) -> None:
    if project_id is not None:
        check_project_write(db, user, get_project_or_404(db, user, project_id))


# ---------------------------------------------------------------- hardware
def _hw_out(db: Session, h: M.HardwareItem, detail: bool = False) -> dict:
    d = to_dict(h)
    p = db.get(M.Project, h.project_id) if h.project_id else None
    d["project_code"] = p.code if p else None
    d["revision"] = revision_count(db, "hardware", h.id)
    if detail:
        d["config_records"] = [to_dict(c) for c in sorted(h.config_records, key=lambda c: c.id, reverse=True)]
        d["software"] = [{"software_id": c.software_id, "name": s.name, "version": s.version, "status": c.status,
                          "notes": c.notes}
                         for c, s in db.query(M.HardwareCompatibility, M.SoftwareItem)
                         .join(M.SoftwareItem, M.SoftwareItem.id == M.HardwareCompatibility.software_id)
                         .filter(M.HardwareCompatibility.hardware_id == h.id)]
        d["requirements"] = [{"id": r.id, "ref": r.ref, "title": r.title, "relation": l.relation}
                             for l, r in db.query(M.TraceLink, M.Requirement)
                             .join(M.Requirement, M.Requirement.id == M.TraceLink.requirement_id)
                             .filter(M.TraceLink.target_type == "hardware", M.TraceLink.target_ref == str(h.id))]
    return d


@router.get("/hardware")
def list_hardware(project_id: int | None = None, category: str | None = None, status: str | None = None,
                  q: str | None = None, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    qry = _scope(db, user, db.query(M.HardwareItem), M.HardwareItem.project_id).order_by(M.HardwareItem.asset_tag)
    if project_id:
        qry = qry.filter(M.HardwareItem.project_id == project_id)
    if category:
        qry = qry.filter(M.HardwareItem.category == category)
    if status:
        qry = qry.filter(M.HardwareItem.status == status)
    if q:
        like = f"%{q}%"
        qry = qry.filter(M.HardwareItem.name.ilike(like) | M.HardwareItem.model.ilike(like) |
                         M.HardwareItem.serial_number.ilike(like) | M.HardwareItem.manufacturer.ilike(like) |
                         M.HardwareItem.asset_tag.ilike(like))
    return [_hw_out(db, h) for h in qry]


def _next_tag(db: Session) -> str:
    n = db.query(func.count(M.HardwareItem.id)).scalar() or 0
    while True:
        n += 1
        tag = f"HW-{n:04d}"
        if not db.query(M.HardwareItem.id).filter_by(asset_tag=tag).first():
            return tag


def _check_power(v_min, v_max):
    if v_min is not None and v_max is not None and v_min > v_max:
        raise HTTPException(422, "supply_voltage_min is greater than supply_voltage_max")


@router.post("/hardware", status_code=201)
def create_hardware(body: HardwareIn, request: Request, user: M.User = Depends(require("hardware.write")),
                    db: Session = Depends(get_db)):
    _check_assign(db, user, body.project_id)
    _check_power(body.supply_voltage_min, body.supply_voltage_max)
    data = body.model_dump()
    data["asset_tag"] = data["asset_tag"] or _next_tag(db)
    if db.query(M.HardwareItem.id).filter_by(manufacturer=body.manufacturer, model=body.model,
                                             serial_number=body.serial_number).first():
        raise HTTPException(409, f"{body.manufacturer} {body.model} S/N {body.serial_number} is already registered")
    h = M.HardwareItem(**data)
    db.add(h)
    db.flush()
    record_revision(db, "hardware", h, user.username, "Registered")
    audit(db, user, "create", "hardware", h.id, project_id=h.project_id,
          summary=f"Registered {h.asset_tag} {h.manufacturer} {h.model} S/N {h.serial_number}", request=request)
    db.commit()
    return _hw_out(db, h, detail=True)


@router.get("/hardware/{hid}")
def get_hardware(hid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    h = db.get(M.HardwareItem, hid)
    if not h:
        raise HTTPException(404, "Hardware item not found")
    _check_item_visible(db, user, h.project_id)
    return _hw_out(db, h, detail=True)


@router.patch("/hardware/{hid}")
def update_hardware(hid: int, body: HardwarePatch, request: Request, user: M.User = Depends(require("hardware.write")),
                    db: Session = Depends(get_db)):
    h = db.get(M.HardwareItem, hid)
    if not h:
        raise HTTPException(404, "Hardware item not found")
    _check_item_visible(db, user, h.project_id)
    _check_assign(db, user, h.project_id)
    changes = body.model_dump(exclude_unset=True)
    comment = changes.pop("comment", None)
    if changes.pop("unassign_project", False):
        changes["project_id"] = None
    if changes.get("project_id"):
        _check_assign(db, user, changes["project_id"])
    for k, v in changes.items():
        setattr(h, k, v)
    _check_power(h.supply_voltage_min, h.supply_voltage_max)
    db.flush()
    rev = record_revision(db, "hardware", h, user.username, comment)
    audit(db, user, "update", "hardware", h.id, project_id=h.project_id, summary=f"Updated {h.asset_tag}",
          detail={"fields": rev.changed_fields if rev else []}, request=request)
    db.commit()
    return _hw_out(db, h, detail=True)


@router.post("/hardware/{hid}/config-records", status_code=201)
def add_config_record(hid: int, body: ConfigRecordIn, request: Request,
                      user: M.User = Depends(require("hardware.write")), db: Session = Depends(get_db)):
    h = db.get(M.HardwareItem, hid)
    if not h:
        raise HTTPException(404, "Hardware item not found")
    _check_item_visible(db, user, h.project_id)
    _check_assign(db, user, h.project_id)
    c = M.HardwareConfigRecord(hardware_id=h.id, recorded_by=user.username, **body.model_dump())
    db.add(c)
    db.flush()
    audit(db, user, "config_record", "hardware", h.id, project_id=h.project_id,
          summary=f"{h.asset_tag}: configuration record '{c.title}'", request=request)
    db.commit()
    return to_dict(c)


# ---------------------------------------------------------------- software
def _sw_out(db: Session, s: M.SoftwareItem, detail: bool = False) -> dict:
    d = to_dict(s)
    p = db.get(M.Project, s.project_id) if s.project_id else None
    d["project_code"] = p.code if p else None
    d["revision"] = revision_count(db, "software", s.id)
    d["dependency_count"] = len(s.dependencies)
    if detail:
        deps = []
        for dep in s.dependencies:
            x = to_dict(dep)
            if dep.depends_on_id:
                t = db.get(M.SoftwareItem, dep.depends_on_id)
                x["depends_on"] = f"{t.name} {t.version}" if t else None
            deps.append(x)
        d["dependencies"] = deps
        d["compatibility"] = [to_dict(c) | {"asset_tag": c.hardware.asset_tag, "hardware": f"{c.hardware.name} "
                                            f"({c.hardware.model} rev {c.hardware.hardware_revision or '-'})"}
                              for c in s.compatibility]
        d["used_by"] = [{"id": x.id, "name": x.name, "version": x.version}
                        for x in db.query(M.SoftwareItem).join(M.SoftwareDependency,
                                                               M.SoftwareDependency.software_id == M.SoftwareItem.id)
                        .filter(M.SoftwareDependency.depends_on_id == s.id)]
        d["requirements"] = [{"id": r.id, "ref": r.ref, "title": r.title, "relation": l.relation}
                             for l, r in db.query(M.TraceLink, M.Requirement)
                             .join(M.Requirement, M.Requirement.id == M.TraceLink.requirement_id)
                             .filter(M.TraceLink.target_type == "software", M.TraceLink.target_ref == str(s.id))]
    return d


def _get_sw(db: Session, user: M.User, sid: int) -> M.SoftwareItem:
    s = db.get(M.SoftwareItem, sid)
    if not s:
        raise HTTPException(404, "Software item not found")
    _check_item_visible(db, user, s.project_id)
    return s


@router.get("/software")
def list_software(project_id: int | None = None, kind: str | None = None, status: str | None = None,
                  q: str | None = None, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    qry = _scope(db, user, db.query(M.SoftwareItem), M.SoftwareItem.project_id).order_by(M.SoftwareItem.name,
                                                                                         M.SoftwareItem.version)
    if project_id:
        qry = qry.filter(M.SoftwareItem.project_id == project_id)
    if kind:
        qry = qry.filter(M.SoftwareItem.kind == kind)
    if status:
        qry = qry.filter(M.SoftwareItem.status == status)
    if q:
        qry = qry.filter(M.SoftwareItem.name.ilike(f"%{q}%"))
    return [_sw_out(db, s) for s in qry]


@router.post("/software", status_code=201)
def create_software(body: SoftwareIn, request: Request, user: M.User = Depends(require("software.write")),
                    db: Session = Depends(get_db)):
    _check_assign(db, user, body.project_id)
    if db.query(M.SoftwareItem.id).filter_by(name=body.name, version=body.version).first():
        raise HTTPException(409, f"{body.name} {body.version} is already registered")
    s = M.SoftwareItem(**body.model_dump())
    db.add(s)
    db.flush()
    record_revision(db, "software", s, user.username, "Registered")
    audit(db, user, "create", "software", s.id, project_id=s.project_id, summary=f"Registered {s.name} {s.version}",
          request=request)
    db.commit()
    return _sw_out(db, s, detail=True)


@router.get("/software/{sid}")
def get_software(sid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    return _sw_out(db, _get_sw(db, user, sid), detail=True)


@router.patch("/software/{sid}")
def update_software(sid: int, body: SoftwarePatch, request: Request, user: M.User = Depends(require("software.write")),
                    db: Session = Depends(get_db)):
    s = _get_sw(db, user, sid)
    _check_assign(db, user, s.project_id)
    changes = body.model_dump(exclude_unset=True)
    comment = changes.pop("comment", None)
    if changes.pop("unassign_project", False):
        changes["project_id"] = None
    if changes.get("project_id"):
        _check_assign(db, user, changes["project_id"])
    for k, v in changes.items():
        setattr(s, k, v)
    db.flush()
    rev = record_revision(db, "software", s, user.username, comment)
    audit(db, user, "update", "software", s.id, project_id=s.project_id, summary=f"Updated {s.name} {s.version}",
          detail={"fields": rev.changed_fields if rev else []}, request=request)
    db.commit()
    return _sw_out(db, s, detail=True)


def _would_cycle(db: Session, src: int, target: int) -> bool:
    """True if `target` already (transitively) depends on `src`."""
    seen, stack = set(), [target]
    while stack:
        cur = stack.pop()
        if cur == src:
            return True
        if cur in seen:
            continue
        seen.add(cur)
        stack += [d for (d,) in db.query(M.SoftwareDependency.depends_on_id)
                  .filter(M.SoftwareDependency.software_id == cur, M.SoftwareDependency.depends_on_id.isnot(None))]
    return False


@router.post("/software/{sid}/dependencies", status_code=201)
def add_dependency(sid: int, body: DependencyIn, request: Request, user: M.User = Depends(require("software.write")),
                   db: Session = Depends(get_db)):
    s = _get_sw(db, user, sid)
    _check_assign(db, user, s.project_id)
    if body.depends_on_id is not None:
        if body.depends_on_id == s.id:
            raise HTTPException(422, "A component cannot depend on itself")
        if not db.get(M.SoftwareItem, body.depends_on_id):
            raise HTTPException(422, "depends_on_id: software item does not exist")
        if _would_cycle(db, s.id, body.depends_on_id):
            raise HTTPException(422, "Dependency would create a cycle")
    d = M.SoftwareDependency(software_id=s.id, **body.model_dump())
    db.add(d)
    db.flush()
    audit(db, user, "dependency", "software", s.id, project_id=s.project_id,
          summary=f"{s.name} {s.version} depends on {d.name} {d.version_constraint or ''}", request=request)
    db.commit()
    return to_dict(d)


@router.delete("/software/{sid}/dependencies/{did}")
def remove_dependency(sid: int, did: int, request: Request, user: M.User = Depends(require("software.write")),
                      db: Session = Depends(get_db)):
    s = _get_sw(db, user, sid)
    _check_assign(db, user, s.project_id)
    d = db.query(M.SoftwareDependency).filter_by(id=did, software_id=sid).first()
    if not d:
        raise HTTPException(404, "Dependency not found")
    audit(db, user, "dependency_remove", "software", s.id, project_id=s.project_id,
          summary=f"{s.name}: removed dependency {d.name}", request=request)
    db.delete(d)
    db.commit()
    return {"ok": True}


@router.put("/software/{sid}/compatibility")
def set_compatibility(sid: int, body: CompatIn, request: Request, user: M.User = Depends(require("software.write")),
                      db: Session = Depends(get_db)):
    s = _get_sw(db, user, sid)
    _check_assign(db, user, s.project_id)
    h = db.get(M.HardwareItem, body.hardware_id)
    if not h:
        raise HTTPException(422, "hardware_id: hardware item does not exist")
    c = db.query(M.HardwareCompatibility).filter_by(software_id=s.id, hardware_id=h.id).first()
    if c is None:
        c = M.HardwareCompatibility(software_id=s.id, hardware_id=h.id, recorded_by=user.username)
        db.add(c)
    c.status, c.notes, c.recorded_by, c.recorded_at = body.status, body.notes, user.username, M.utcnow()
    db.flush()
    audit(db, user, "compatibility", "software", s.id, project_id=s.project_id,
          summary=f"{s.name} {s.version} on {h.asset_tag}: {body.status}", request=request)
    db.commit()
    return to_dict(c)


@router.get("/inventory/summary")
def inventory_summary(user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    hw = _scope(db, user, db.query(M.HardwareItem), M.HardwareItem.project_id).all()
    sw = _scope(db, user, db.query(M.SoftwareItem), M.SoftwareItem.project_id).all()
    by = lambda items, attr: {k: sum(1 for i in items if getattr(i, attr) == k)  # noqa: E731
                              for k in sorted({getattr(i, attr) for i in items})}
    return {"hardware_total": len(hw), "hardware_by_status": by(hw, "status"), "hardware_by_category": by(hw, "category"),
            "software_total": len(sw), "software_by_status": by(sw, "status"), "software_by_kind": by(sw, "kind"),
            "can_edit_hardware": can(user, "hardware.write"), "can_edit_software": can(user, "software.write")}
