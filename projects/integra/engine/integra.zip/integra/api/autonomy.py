"""Autonomous Systems (Module K) and Simulation (Module L): data-flow overview, fault-injection scenarios, scenario
runs, simulator adapters and plugins, ROS 2 bag import / analysis / replay."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Annotated, Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from pydantic import Field
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..schemas import In, one_of
from ..security import audit, get_project_or_404, require
from ..services import autonomy as AU
from ..services.records import to_dict
from .architecture import model_payload

router = APIRouter(prefix="/api/v1", tags=["autonomous systems & simulation"])

FAULT_PARAMS = {
    "sensor_dropout": {"sensor": "sensor", "help": "The sensor publishes nothing"},
    "stale_timestamps": {"sensor": "sensor", "delay_ms": 300, "help": "Header stamps lag capture time (stale data)"},
    "timestamp_jitter": {"sensor": "sensor", "jitter_ms": 60, "help": "Random stamp noise; stamps may run backwards"},
    "comm_interruption": {"sensors": "sensor list", "help": "Link down: all listed sensors drop out"},
    "latency_increase": {"sensor": "sensor", "add_ms": 250, "help": "Delivery delayed; stamps unchanged"},
    "invalid_messages": {"sensor": "sensor", "mode": "nan | out_of_range", "probability": 1.0, "help": "Corrupted values"},
    "localization_degradation": {"sensor": "gnss", "noise_factor": 60, "help": "GNSS noise × factor, fix quality drops"},
    "process_restart": {"help": "The system under test is stopped for the window, then restarted fresh"},
    "compute_limit": {"cpu_load_pct": 98, "output_delay_ms": 200, "help": "CPU saturated; SUT outputs delayed"},
}
TEMPLATES = {
    "sensor_availability": ("Lidar unavailable for 4 s", [{"type": "sensor_dropout", "sensor": "lidar_roof", "start_s": 10, "end_s": 14}],
                            [{"type": "no_false_alarm"}, {"type": "detect", "fault": 0, "within_ms": 500, "match": "lidar"},
                             {"type": "state", "fault": 0, "allowed": ["MINIMAL_RISK"], "within_ms": 600}, {"type": "recover", "fault": 0, "within_s": 3}]),
    "missing_data": ("Radar data missing", [{"type": "sensor_dropout", "sensor": "radar_front", "start_s": 8, "end_s": 12}],
                     [{"type": "detect", "fault": 0, "within_ms": 500, "match": "radar"}, {"type": "never_state", "state": "MINIMAL_RISK"},
                      {"type": "recover", "fault": 0, "within_s": 3}]),
    "timestamp": ("Lidar timestamps jittered / non-monotonic", [{"type": "timestamp_jitter", "sensor": "lidar_roof", "start_s": 10, "end_s": 16, "jitter_ms": 60}],
                  [{"type": "detect", "fault": 0, "within_ms": 500, "match": "lidar"}, {"type": "recover", "fault": 0, "within_s": 3}]),
    "comm_interruption": ("Vehicle CAN link interrupted", [{"type": "comm_interruption", "sensors": ["vehicle_state"], "start_s": 10, "end_s": 12}],
                          [{"type": "detect", "fault": 0, "within_ms": 300, "match": "vehicle_state", "min_level": "ERROR"},
                           {"type": "state", "fault": 0, "allowed": ["MINIMAL_RISK"], "within_ms": 500}, {"type": "recover", "fault": 0, "within_s": 3}]),
    "latency": ("Camera pipeline latency +250 ms", [{"type": "latency_increase", "sensor": "camera_front", "start_s": 10, "end_s": 15, "add_ms": 250}],
                [{"type": "detect", "fault": 0, "within_ms": 500, "match": "camera"}, {"type": "state", "fault": 0, "within_ms": 800},
                 {"type": "recover", "fault": 0, "within_s": 3}]),
    "invalid_input": ("Radar sends NaN ranges", [{"type": "invalid_messages", "sensor": "radar_front", "start_s": 10, "end_s": 14, "mode": "nan"}],
                      [{"type": "detect", "fault": 0, "within_ms": 300, "match": "invalid"}, {"type": "never_state", "state": "MINIMAL_RISK"},
                       {"type": "recover", "fault": 0, "within_s": 3}]),
    "localization": ("GNSS degraded (multipath)", [{"type": "localization_degradation", "sensor": "gnss", "start_s": 10, "end_s": 25, "noise_factor": 60}],
                     [{"type": "detect", "fault": 0, "within_ms": 500, "match": "localization"}, {"type": "state", "fault": 0, "allowed": ["DEGRADED"], "within_ms": 1000},
                      {"type": "never_state", "state": "MINIMAL_RISK"}, {"type": "recover", "fault": 0, "within_s": 3}]),
    "restart_recovery": ("Supervisor process restart", [{"type": "process_restart", "start_s": 12, "end_s": 14}],
                         [{"type": "recover", "fault": 0, "within_s": 1.5}]),
    "compute_limits": ("CPU saturation 98 %", [{"type": "compute_limit", "start_s": 10, "end_s": 18, "cpu_load_pct": 98, "output_delay_ms": 200}],
                       [{"type": "detect", "fault": 0, "within_ms": 2000, "match": "compute"}, {"type": "recover", "fault": 0, "within_s": 3}]),
}


class ScenarioIn(In):
    name: Annotated[str, Field(min_length=1, max_length=200)]
    category: Annotated[str, one_of(M.SCENARIO_CATEGORIES)] = "custom"
    description: str | None = None
    adapter: Annotated[str, Field(min_length=1, max_length=48)] = "integra_kinematic"
    bag_id: int | None = None
    duration_s: Annotated[float, Field(ge=1, le=600)] = 30
    seed: int = 1
    world: dict[str, Any] = {}
    sensors: dict[str, Any] = {}
    faults: list[dict[str, Any]] = []
    expectations: list[dict[str, Any]] = []
    sut: str = "reference_supervisor"
    from_template: bool = False


class ScenarioPatch(In):
    name: str | None = None
    description: str | None = None
    adapter: str | None = None
    bag_id: int | None = None
    duration_s: Annotated[float, Field(ge=1, le=600)] | None = None
    seed: int | None = None
    world: dict[str, Any] | None = None
    sensors: dict[str, Any] | None = None
    faults: list[dict[str, Any]] | None = None
    expectations: list[dict[str, Any]] | None = None
    sut: str | None = None


def _validate(sc: dict) -> None:
    from integra_testkit import sim
    errs = sim.validate_scenario(sc) if sc.get("adapter", "integra_kinematic") == "integra_kinematic" else \
        [e for e in sim.validate_scenario({**sc, "sensors": {}}) if "unknown sensor" not in e]
    if errs:
        raise HTTPException(422, "; ".join(errs))


# ---------------------------------------------------------------- catalogue & data flow
@router.get("/simulation/catalogue")
def catalogue(_: M.User = Depends(require("internal.view"))):
    from integra_testkit import sim
    return {"fault_types": FAULT_PARAMS, "expectation_types": sim.EXPECTATION_TYPES, "categories": M.SCENARIO_CATEGORIES,
            "default_sensors": sim.DEFAULT_SENSORS, "default_world": sim.DEFAULT_WORLD, "states": sim.STATES,
            "templates": {k: {"name": v[0], "faults": v[1], "expectations": v[2]} for k, v in TEMPLATES.items()}}


@router.get("/architectures/{mid}/dataflow")
def dataflow(mid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    m = db.get(M.ArchModel, mid)
    if not m:
        raise HTTPException(404, "Architecture not found")
    get_project_or_404(db, user, m.project_id)
    return AU.dataflow(model_payload(db, m)) | {"model": {"id": m.id, "name": m.name}}


@router.get("/simulation/adapters")
def adapters(_: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return AU.adapter_list(db)


@router.get("/simulation/plugins")
def plugins(_: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return {"directory": str(AU.plugins_dir()), "plugins": AU.list_plugins(db)}


@router.post("/simulation/plugins", status_code=201)
async def upload_plugin(request: Request, file: UploadFile = File(...), user: M.User = Depends(require("admin.users")),
                        db: Session = Depends(get_db)):
    name = Path(file.filename or "").name
    if not re.fullmatch(r"[A-Za-z0-9_]{1,80}\.py", name):
        raise HTTPException(422, "Plugin file name must be <identifier>.py")
    raw = await file.read()
    (AU.plugins_dir() / name).write_bytes(raw)
    audit(db, user, "plugin_upload", "plugin", name, summary=f"Plugin {name} uploaded (sha256 {hashlib.sha256(raw).hexdigest()[:12]}), not approved",
          request=request)
    db.commit()
    return {"filename": name, "approved": False}


@router.post("/simulation/plugins/{filename}/approve")
def approve_plugin(filename: str, request: Request, user: M.User = Depends(require("admin.users")), db: Session = Depends(get_db)):
    p = next((x for x in AU.list_plugins(db) if x["filename"] == filename), None)
    if not p:
        raise HTTPException(404, "Plugin not found")
    a = db.query(M.PluginApproval).filter_by(filename=filename).first() or M.PluginApproval(filename=filename, sha256="", approved_by="")
    a.sha256, a.approved_by, a.approved_at = p["sha256"], user.username, M.utcnow()
    db.add(a)
    audit(db, user, "plugin_approve", "plugin", filename, summary=f"Plugin {filename} approved (sha256 {p['sha256'][:12]}); it runs inside the backend",
          request=request)
    db.commit()
    _, _, errors = AU.load_plugins(db)
    return {"filename": filename, "approved": True, "load_errors": errors}


# ---------------------------------------------------------------- scenarios
def _scn(db: Session, user: M.User, sid: int) -> M.Scenario:
    s = db.get(M.Scenario, sid)
    if not s:
        raise HTTPException(404, "Scenario not found")
    get_project_or_404(db, user, s.project_id)
    return s


def _scn_out(db: Session, s: M.Scenario) -> dict:
    last = db.query(M.ScenarioRun).filter_by(scenario_id=s.id).order_by(M.ScenarioRun.id.desc()).first()
    return to_dict(s) | {"last_run": {"id": last.id, "status": last.status, "at": last.started_at.isoformat(timespec="seconds"),
                                      "passed": sum(e["passed"] for e in last.expectations or []), "total": len(last.expectations or [])} if last else None}


@router.get("/projects/{pid}/scenarios")
def list_scenarios(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_scn_out(db, s) for s in db.query(M.Scenario).filter_by(project_id=pid).order_by(M.Scenario.ref)]


@router.post("/projects/{pid}/scenarios", status_code=201)
def create_scenario(pid: int, body: ScenarioIn, request: Request, user: M.User = Depends(require("autonomy.write")),
                    db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    data = body.model_dump(exclude={"from_template"})
    if body.from_template and body.category in TEMPLATES and not body.faults:
        _, data["faults"], data["expectations"] = TEMPLATES[body.category]
    _validate(data)
    if data["bag_id"] and not db.get(M.BagFile, data["bag_id"]):
        raise HTTPException(422, "bag_id: bag not found")
    nums = [int(m.group(1)) for (r,) in db.query(M.Scenario.ref).filter_by(project_id=pid) if (m := re.fullmatch(r"SC-(\d+)", r))]
    s = M.Scenario(project_id=pid, ref=f"SC-{(max(nums) + 1 if nums else 1):03d}", created_by=user.username, **data)
    db.add(s)
    db.flush()
    audit(db, user, "scenario_create", "scenario", s.id, project_id=pid, summary=f"{p.code} {s.ref} {s.name}", request=request)
    db.commit()
    return _scn_out(db, s)


@router.get("/scenarios/{sid}")
def get_scenario(sid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    s = _scn(db, user, sid)
    return _scn_out(db, s) | {"runs": [to_dict(r, exclude={"timeline", "trajectory", "scenario_snapshot"})
                                       for r in db.query(M.ScenarioRun).filter_by(scenario_id=s.id).order_by(M.ScenarioRun.id.desc()).limit(30)]}


@router.patch("/scenarios/{sid}")
def patch_scenario(sid: int, body: ScenarioPatch, request: Request, user: M.User = Depends(require("autonomy.write")),
                   db: Session = Depends(get_db)):
    s = _scn(db, user, sid)
    ch = body.model_dump(exclude_unset=True)
    merged = to_dict(s) | ch
    _validate(merged)
    for k, v in ch.items():
        setattr(s, k, v)
    audit(db, user, "scenario_update", "scenario", s.id, project_id=s.project_id, summary=f"{s.ref} updated ({', '.join(sorted(ch))})",
          request=request)
    db.commit()
    return _scn_out(db, s)


@router.post("/scenarios/{sid}/run", status_code=201)
def run(sid: int, request: Request, user: M.User = Depends(require("simulation.run")), db: Session = Depends(get_db)):
    s = _scn(db, user, sid)
    r = AU.run_scenario(db, s, user.username)
    audit(db, user, "scenario_run", "scenario", s.id, project_id=s.project_id,
          summary=f"{s.ref} run #{r.id} ({r.adapter}, SUT {r.sut}): {r.status}", request=request)
    db.commit()
    return to_dict(r)


@router.get("/scenario-runs/{rid}")
def get_run(rid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    r = db.get(M.ScenarioRun, rid)
    if not r:
        raise HTTPException(404, "Run not found")
    get_project_or_404(db, user, r.project_id)
    return to_dict(r)


@router.post("/scenario-runs/{rid}/to-timeline")
def to_timeline(rid: int, request: Request, user: M.User = Depends(require("debug.write")), db: Session = Depends(get_db)):
    r = db.get(M.ScenarioRun, rid)
    if not r:
        raise HTTPException(404, "Run not found")
    get_project_or_404(db, user, r.project_id)
    n = AU.run_to_timeline(db, r)
    audit(db, user, "scenario_to_timeline", "scenario", r.scenario_id, project_id=r.project_id, summary=f"Run #{r.id}: {n} events", request=request)
    db.commit()
    return {"events": n}


# ---------------------------------------------------------------- ROS 2 bags
@router.post("/bags/import", status_code=201)
async def import_bag(request: Request, file: UploadFile = File(...), project_id: int | None = Form(None),
                     environment: str = Form("unknown"), user: M.User = Depends(require("autonomy.write")),
                     db: Session = Depends(get_db)):
    if environment not in ("physical", "simulated", "unknown"):
        raise HTTPException(422, "environment must be physical, simulated or unknown")
    if project_id:
        get_project_or_404(db, user, project_id)
    raw = await file.read()
    if len(raw) > 500_000_000:
        raise HTTPException(413, "Bag larger than 500 MB")
    b = M.BagFile(project_id=project_id, name=Path(file.filename or "bag.zip").stem, sha256=hashlib.sha256(raw).hexdigest(),
                  storage="?", environment=environment, imported_by=user.username)
    db.add(b)
    db.flush()
    path = AU.store_bag(raw, file.filename or "bag.zip", b.id)
    b.storage = "mcap" if any(path.glob("*.mcap")) else "sqlite3"
    try:
        a = AU.analyse_bag(path)
    except Exception as e:
        db.rollback()
        raise HTTPException(422, f"Could not read the bag: {type(e).__name__}: {e}")
    b.messages, b.topics, b.findings, b.sync = a["messages"], a["topics"], a["findings"], a["sync"]
    b.start, b.end, b.duration_s = AU.fmt_ts(a["start"]), AU.fmt_ts(a["end"]), a["duration_s"]
    audit(db, user, "bag_import", "bag", b.id, project_id=project_id,
          summary=f"ROS 2 bag {b.name}: {b.messages} messages on {len(b.topics)} topics, {len(b.findings)} finding(s)", request=request)
    db.commit()
    return to_dict(b)


@router.get("/projects/{pid}/bags")
def list_bags(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [to_dict(b) for b in db.query(M.BagFile).filter_by(project_id=pid).order_by(M.BagFile.id.desc())]


def _bag(db: Session, user: M.User, bid: int) -> M.BagFile:
    b = db.get(M.BagFile, bid)
    if not b:
        raise HTTPException(404, "Bag not found")
    if b.project_id:
        get_project_or_404(db, user, b.project_id)
    return b


@router.post("/bags/{bid}/to-timeline")
def bag_to_timeline(bid: int, request: Request, user: M.User = Depends(require("debug.write")), db: Session = Depends(get_db)):
    from datetime import datetime as dt

    from ..services.analysis import _internal_source, store_events
    from ..services.logparse import Parsed
    b = _bag(db, user, bid)
    if not b.project_id:
        raise HTTPException(422, "Assign the bag to a project first")
    src = _internal_source(db, b.project_id, f"ROS 2 bag: {b.name}", "communication", "ROS 2")
    db.query(M.LogEvent).filter_by(source_id=src.id).delete()
    lvl = {"error": "error", "warning": "warning", "info": "info"}
    parsed = [Parsed(dt.utcfromtimestamp(f["t"]) if f.get("t") else (b.start or M.utcnow()), lvl[f["severity"]], f"[{f['check']}] {f['detail']}",
                     f["topic"], {}) for f in b.findings]
    n = store_events(db, src, parsed)
    audit(db, user, "bag_to_timeline", "bag", b.id, project_id=b.project_id, summary=f"{n} bag finding(s) published", request=request)
    db.commit()
    return {"events": n}


def _norm_type(t: str | None) -> str:
    return (t or "").replace("/msg/", "/").strip().lower()


@router.post("/bags/{bid}/probes")
def bag_probes(bid: int, request: Request, user: M.User = Depends(require("probes.run")), db: Session = Depends(get_db)):
    """Record measured topic rates as runtime probes on 'ROS 2 topic' interfaces whose data type matches exactly one
    bag topic. Environment comes from the bag (physical recordings count as hardware results)."""
    b = _bag(db, user, bid)
    if not b.project_id:
        raise HTTPException(422, "Assign the bag to a project first")
    by_type: dict[str, list[dict]] = {}
    for t in b.topics:
        by_type.setdefault(_norm_type(t["msgtype"]), []).append(t)
    env = "physical" if b.environment == "physical" else "virtual"
    made, skipped = [], []
    model_ids = [i for (i,) in db.query(M.ArchModel.id).filter_by(project_id=b.project_id)]
    for cn in db.query(M.ArchConnection).filter(M.ArchConnection.model_id.in_(model_ids or [-1]), M.ArchConnection.interface_type == "ROS 2 topic"):
        cands = by_type.get(_norm_type(cn.data_type), [])
        if len(cands) != 1:
            skipped.append({"connection": cn.key, "reason": "no matching topic" if not cands else f"{len(cands)} topics of that type"})
            continue
        t = cands[0]
        rate = t.get("rate_hz") or 0
        ok = rate > 0 and (cn.rate_hz is None or rate >= 0.9 * cn.rate_hz) and not t.get("stamp_backwards")
        detail = (f"bag {b.name}: {t['topic']} at {rate} Hz" + (f" vs expected {cn.rate_hz:g} Hz" if cn.rate_hz else "")
                  + (f", max gap {t.get('max_gap_ms')} ms" if t.get("max_gap_ms") else "")
                  + (f", {t['stamp_backwards']} stamp reversal(s)" if t.get("stamp_backwards") else "")
                  + ("" if env == "physical" else f" ({b.environment} recording)"))
        db.add(M.ConnectionProbe(connection_id=cn.id, kind="ros2_topic", params={"bag_id": b.id, "topic": t["topic"]}, environment=env,
                                 result="pass" if ok else "fail", measured={k: t.get(k) for k in ("rate_hz", "max_gap_ms", "latency_ms_median", "count")},
                                 detail=detail, ran_by=user.username))
        made.append({"connection": cn.key, "topic": t["topic"], "result": "pass" if ok else "fail"})
    audit(db, user, "bag_probes", "bag", b.id, project_id=b.project_id, summary=f"{len(made)} probe(s) from bag {b.name}", request=request)
    db.commit()
    return {"probes": made, "skipped": skipped}
