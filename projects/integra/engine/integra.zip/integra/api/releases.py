"""CI/CD & release management (Phase 7, module N): builds (approved local build scripts, GitHub Actions runs), release
records with a computed release gate, two-person approval, deployment and rollback records, notes and comparison.

INTEGRA never pushes, tags or deploys: Git access stays read-only, CI access is read-only, and deployments are records
of what an engineer performed."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import Field
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..schemas import In, one_of
from ..security import ROLES, audit, can, check_project_write, current_user, get_project_or_404, require
from ..services import delivery as D
from ..services.records import to_dict

router = APIRouter(prefix="/api/v1", tags=["CI/CD & releases"])

VERSION_RE = r"^[0-9]+\.[0-9]+\.[0-9]+([-+][0-9A-Za-z.+-]+)?$"


# ---------------------------------------------------------------- builds
class BuildRunIn(In):
    repository_id: int
    script_id: int
    args: list[Annotated[str, Field(max_length=200)]] = Field(default_factory=list, max_length=20)
    artifact_globs: list[Annotated[str, Field(max_length=200)]] = Field(default_factory=list, max_length=20)
    timeout_s: Annotated[int, Field(ge=1, le=600)] = 300
    confirm: bool = False


def _build_out(b: M.Build, log: bool = False) -> dict:
    return to_dict(b, exclude=None if log else {"log"})


@router.get("/projects/{pid}/builds")
def list_builds(pid: int, limit: int = Query(100, le=500), user: M.User = Depends(require("internal.view")),
                db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_build_out(b) for b in db.query(M.Build).filter_by(project_id=pid).order_by(M.Build.started_at.desc(), M.Build.id.desc()).limit(limit)]


@router.get("/builds/{bid}")
def get_build(bid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    b = db.get(M.Build, bid)
    if not b:
        raise HTTPException(404, "Build not found")
    get_project_or_404(db, user, b.project_id)
    return _build_out(b, log=True)


@router.post("/projects/{pid}/builds/run", status_code=201)
def run_build(pid: int, body: BuildRunIn, request: Request, user: M.User = Depends(require("builds.run")),
              db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    if not body.confirm:
        raise HTTPException(400, "Build execution must be explicitly confirmed (confirm=true)")
    repo, script = db.get(M.Repository, body.repository_id), db.get(M.Script, body.script_id)
    if not repo or repo.project_id not in (None, pid):
        raise HTTPException(422, "repository_id: not a repository of this project")
    if not script or script.project_id not in (None, pid):
        raise HTTPException(422, "script_id: not a script of this project")
    b = D.run_local_build(db, p, repo, script, body.args, body.timeout_s, body.artifact_globs, user)
    audit(db, user, "build_run", "build", b.id, project_id=pid,
          summary=f"{p.code}: build {repo.name} @ {b.commit_sha[:12]} with {script.name} -> {b.status}",
          detail={"args": body.args, "dirty": b.dirty, "artifacts": len(b.artifacts)}, request=request)
    db.commit()
    return _build_out(b, log=True)


# ---------------------------------------------------------------- CI connections
class CiIn(In):
    owner_repo: Annotated[str, Field(pattern=D.OWNER_REPO_RE.pattern)]
    repository_id: int | None = None
    api_base: str = "https://api.github.com"
    workflow: str | None = None
    branch: str | None = None
    token_env: Annotated[str, Field(pattern=r"^[A-Z_][A-Z0-9_]{1,79}$")] | None = None


@router.get("/projects/{pid}/ci")
def list_ci(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [to_dict(c) | {"builds": db.query(M.Build).filter_by(ci_connection_id=c.id).count()}
            for c in db.query(M.CiConnection).filter_by(project_id=pid).order_by(M.CiConnection.id)]


@router.post("/projects/{pid}/ci", status_code=201)
def add_ci(pid: int, body: CiIn, request: Request, user: M.User = Depends(require("ci.write")), db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    api_base = D.check_api_base(body.api_base)
    if body.repository_id:
        r = db.get(M.Repository, body.repository_id)
        if not r or r.project_id not in (None, pid):
            raise HTTPException(422, "repository_id: not a repository of this project")
    c = M.CiConnection(project_id=pid, created_by=user.username, **(body.model_dump() | {"api_base": api_base}))
    db.add(c)
    db.flush()
    audit(db, user, "ci_add", "ci_connection", c.id, project_id=pid, summary=f"{p.code}: GitHub Actions {c.owner_repo}",
          request=request)
    db.commit()
    return to_dict(c)


@router.post("/ci/{cid}/sync")
def sync_ci(cid: int, request: Request, user: M.User = Depends(require("ci.write")), db: Session = Depends(get_db)):
    c = db.get(M.CiConnection, cid)
    if not c:
        raise HTTPException(404, "CI connection not found")
    get_project_or_404(db, user, c.project_id)
    try:
        r = D.sync_ci(db, c, user.username)
    except HTTPException:
        db.commit()  # keep last_error
        raise
    audit(db, user, "ci_sync", "ci_connection", c.id, project_id=c.project_id,
          summary=f"Synced {c.owner_repo}: {r['runs']} run(s), {r['created']} new", request=request)
    db.commit()
    return r | {"connection": to_dict(c)}


@router.delete("/ci/{cid}")
def delete_ci(cid: int, request: Request, user: M.User = Depends(require("ci.write")), db: Session = Depends(get_db)):
    c = db.get(M.CiConnection, cid)
    if not c:
        raise HTTPException(404, "CI connection not found")
    get_project_or_404(db, user, c.project_id)
    audit(db, user, "ci_delete", "ci_connection", c.id, project_id=c.project_id, summary=f"Removed {c.owner_repo}",
          request=request)
    db.delete(c)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- releases
class ReleaseIn(In):
    version: Annotated[str, Field(pattern=VERSION_RE, max_length=64)]
    name: str | None = None
    repository_id: int | None = None
    commit_sha: str | None = None  # SHA, or a ref resolvable in a local working copy
    tag: Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._/+-]{0,119}$")] | None = None
    build_id: int | None = None
    integration_config_id: int | None = None
    required_suite_ids: list[int] = []
    test_run_ids: list[int] = []
    known_limitations: list[Annotated[str, Field(min_length=1, max_length=500)]] = []
    release_notes: str | None = None
    rollback_plan: str | None = None


class ReleasePatch(In):
    name: str | None = None
    repository_id: int | None = None
    commit_sha: str | None = None
    tag: Annotated[str, Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._/+-]{0,119}$")] | None = None
    build_id: int | None = None
    integration_config_id: int | None = None
    required_suite_ids: list[int] | None = None
    test_run_ids: list[int] | None = None
    known_limitations: list[Annotated[str, Field(min_length=1, max_length=500)]] | None = None
    release_notes: str | None = None
    rollback_plan: str | None = None


CANDIDATE_EDITABLE = {"build_id", "required_suite_ids", "test_run_ids", "known_limitations", "release_notes", "rollback_plan"}


def _validate_refs(db: Session, pid: int, data: dict, repo_id: int | None) -> dict:
    if data.get("repository_id"):
        r = db.get(M.Repository, data["repository_id"])
        if not r or r.project_id not in (None, pid):
            raise HTTPException(422, "repository_id: not a repository of this project")
    if data.get("commit_sha"):
        ref = data["commit_sha"].strip()
        repo = db.get(M.Repository, data.get("repository_id") or repo_id) if (data.get("repository_id") or repo_id) else None
        if ref.startswith("-"):
            raise HTTPException(422, "commit_sha: invalid ref")
        full = D.resolve_commit(repo, ref)
        if repo and repo.path:
            if not full:
                raise HTTPException(422, f"commit_sha: '{ref}' does not resolve to a commit in {repo.name}")
            data["commit_sha"] = full
        elif not D.SHA_RE.match(ref):
            raise HTTPException(422, "commit_sha: give a 7-64 character hexadecimal SHA (no local working copy to resolve refs)")
    if data.get("build_id"):
        b = db.get(M.Build, data["build_id"])
        if not b or b.project_id != pid:
            raise HTTPException(422, "build_id: not a build of this project")
    if data.get("integration_config_id"):
        c = db.get(M.IntegrationConfig, data["integration_config_id"])
        if not c or c.project_id != pid:
            raise HTTPException(422, "integration_config_id: not a configuration of this project")
    for sid in data.get("required_suite_ids") or []:
        s = db.get(M.TestSuite, sid)
        if not s or s.project_id != pid:
            raise HTTPException(422, f"required_suite_ids: suite {sid} not in this project")
    for rid in data.get("test_run_ids") or []:
        r = db.get(M.TestRun, rid)
        if not r or r.project_id != pid:
            raise HTTPException(422, f"test_run_ids: run {rid} not in this project")
    return data


def _approvals(db: Session, rel: M.Release) -> list[M.ReleaseApproval]:
    return db.query(M.ReleaseApproval).filter_by(release_id=rel.id).order_by(M.ReleaseApproval.id).all()


def _release_out(db: Session, rel: M.Release, user: M.User, detail: bool = False) -> dict:
    d = to_dict(rel)
    chk = D.release_checks(db, rel)
    d["gate"] = chk if detail else {"passed": chk["passed"], "counts": chk["counts"]}
    b = db.get(M.Build, rel.build_id) if rel.build_id else None
    d["build"] = {"id": b.id, "name": b.name, "status": b.status, "source": b.source, "commit_sha": b.commit_sha} if b else None
    cfg = db.get(M.IntegrationConfig, rel.integration_config_id) if rel.integration_config_id else None
    d["config"] = {"id": cfg.id, "name": cfg.name, "status": cfg.status} if cfg else None
    repo = db.get(M.Repository, rel.repository_id) if rel.repository_id else None
    d["repository"] = {"id": repo.id, "name": repo.name, "local": bool(repo.path)} if repo else None
    if detail:
        d["manifest_frozen"] = bool(rel.manifest)
        d["manifest"] = rel.manifest or D.manifest(db, rel)
        d["approvals"] = [to_dict(a) for a in _approvals(db, rel)]
        d["deployments"] = [to_dict(x) for x in db.query(M.Deployment).filter_by(release_id=rel.id).order_by(M.Deployment.id)]
        d["suites"] = [{"id": s.id, "name": s.name} for s in db.query(M.TestSuite).filter(M.TestSuite.id.in_(rel.required_suite_ids or [-1]))]
        d["can"] = {"approve_engineering": can(user, "releases.approve.engineering"),
                    "approve_project": can(user, "releases.approve.project")}
    if not can(user, "internal.view"):
        d.pop("manifest", None)
    return d


def _get_rel(db: Session, user: M.User, rid: int) -> tuple[M.Release, M.Project]:
    r = db.get(M.Release, rid)
    if not r:
        raise HTTPException(404, "Release not found")
    return r, get_project_or_404(db, user, r.project_id)


@router.get("/projects/{pid}/releases")
def list_releases(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_release_out(db, r, user) for r in db.query(M.Release).filter_by(project_id=pid).order_by(M.Release.id.desc())]


@router.post("/projects/{pid}/releases", status_code=201)
def create_release(pid: int, body: ReleaseIn, request: Request, user: M.User = Depends(require("releases.write")),
                   db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    if db.query(M.Release.id).filter_by(project_id=pid, version=body.version).first():
        raise HTTPException(409, f"Release {body.version} already exists in {p.code}")
    data = _validate_refs(db, pid, body.model_dump(), None)
    rel = M.Release(project_id=pid, created_by=user.username, **data)
    db.add(rel)
    db.flush()
    audit(db, user, "release_create", "release", rel.id, project_id=pid, summary=f"{p.code}: release {rel.version} drafted",
          request=request)
    db.commit()
    return _release_out(db, rel, user, detail=True)


@router.get("/releases/compare")
def compare(a: int, b: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    ra, _ = _get_rel(db, user, a)
    rb, _ = _get_rel(db, user, b)
    if ra.project_id != rb.project_id:
        raise HTTPException(422, "Compare releases of the same project")
    return D.compare_releases(db, ra, rb)


@router.get("/releases/{rid}")
def get_release(rid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    r, _ = _get_rel(db, user, rid)
    return _release_out(db, r, user, detail=True)


def _supersede(db: Session, rel: M.Release) -> int:
    n = 0
    for a in _approvals(db, rel):
        if not a.superseded:
            a.superseded, n = True, n + 1
    return n


@router.patch("/releases/{rid}")
def update_release(rid: int, body: ReleasePatch, request: Request, user: M.User = Depends(require("releases.write")),
                   db: Session = Depends(get_db)):
    rel, p = _get_rel(db, user, rid)
    check_project_write(db, user, p)
    changes = body.model_dump(exclude_unset=True)
    if rel.status in ("approved", "released", "withdrawn"):
        raise HTTPException(409, f"Release {rel.version} is '{rel.status}' and immutable; draft a new version")
    if rel.status == "candidate" and set(changes) - CANDIDATE_EDITABLE:
        raise HTTPException(409, f"Candidate {rel.version}: {', '.join(sorted(set(changes) - CANDIDATE_EDITABLE))} are frozen; "
                                 "return it to draft to change them")
    changes = _validate_refs(db, p.id, changes, rel.repository_id)
    for k, v in changes.items():
        setattr(rel, k, v)
    superseded = _supersede(db, rel) if rel.status == "candidate" else 0
    db.flush()
    audit(db, user, "release_update", "release", rel.id, project_id=p.id,
          summary=f"{p.code} {rel.version}: updated {', '.join(sorted(changes))}" + (f"; {superseded} approval(s) superseded" if superseded else ""),
          request=request)
    db.commit()
    return _release_out(db, rel, user, detail=True)


@router.post("/releases/{rid}/candidate")
def to_candidate(rid: int, request: Request, user: M.User = Depends(require("releases.write")), db: Session = Depends(get_db)):
    rel, p = _get_rel(db, user, rid)
    check_project_write(db, user, p)
    if rel.status != "draft":
        raise HTTPException(409, f"Release is '{rel.status}', only drafts become candidates")
    chk = D.release_checks(db, rel)
    hard = [c for c in chk["checks"] if c["key"] in ("source", "config") and c["result"] == "fail"]
    if hard:
        raise HTTPException(409, {"message": "A candidate needs a verifiable source revision and a frozen configuration",
                                  "checks": hard})
    rel.manifest = D.manifest(db, rel)
    rel.status, rel.candidate_at = "candidate", M.utcnow()
    audit(db, user, "release_candidate", "release", rel.id, project_id=p.id,
          summary=f"{p.code} {rel.version}: release candidate (gate {chk['counts']})", request=request)
    db.commit()
    return _release_out(db, rel, user, detail=True)


@router.post("/releases/{rid}/draft")
def to_draft(rid: int, request: Request, user: M.User = Depends(require("releases.write")), db: Session = Depends(get_db)):
    rel, p = _get_rel(db, user, rid)
    check_project_write(db, user, p)
    if rel.status != "candidate":
        raise HTTPException(409, f"Release is '{rel.status}'; only candidates return to draft")
    n = _supersede(db, rel)
    rel.status, rel.manifest, rel.candidate_at = "draft", {}, None
    audit(db, user, "release_reopen", "release", rel.id, project_id=p.id,
          summary=f"{p.code} {rel.version}: back to draft ({n} approval(s) superseded)", request=request)
    db.commit()
    return _release_out(db, rel, user, detail=True)


class ApproveIn(In):
    kind: Annotated[str, one_of(["engineering", "project"])]
    decision: Annotated[str, one_of(["approve", "reject"])]
    comment: str | None = None


@router.post("/releases/{rid}/approve")
def approve(rid: int, body: ApproveIn, request: Request, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    rel, p = _get_rel(db, user, rid)
    perm = f"releases.approve.{body.kind}"
    if not can(user, perm):
        raise HTTPException(403, f"Role '{ROLES.get(user.role)}' may not give the {body.kind} approval")
    check_project_write(db, user, p)
    if rel.status != "candidate":
        raise HTTPException(409, f"Only release candidates can be approved (status '{rel.status}')")
    if user.username == rel.created_by:
        raise HTTPException(409, "Four-eyes rule: the author of a release cannot approve it")
    active = [a for a in _approvals(db, rel) if not a.superseded and a.decision == "approve"]
    if any(a.username == user.username for a in active):
        raise HTTPException(409, "You already approved this candidate; the second approval must come from another person")
    if any(a.kind == body.kind for a in active):
        raise HTTPException(409, f"The {body.kind} approval is already given")
    chk = D.release_checks(db, rel)
    if body.decision == "approve" and not chk["passed"]:
        raise HTTPException(409, {"message": f"Release gate has {chk['counts']['fail']} failing check(s)",
                                  "checks": [c for c in chk["checks"] if c["result"] == "fail"]})
    if body.decision == "reject" and not (body.comment or "").strip():
        raise HTTPException(422, "comment: a rejection needs a reason")
    db.add(M.ReleaseApproval(release_id=rel.id, kind=body.kind, decision=body.decision, username=user.username, role=user.role,
                             comment=body.comment, gate_summary=chk["counts"]))
    if body.decision == "reject":
        db.flush()
        _supersede(db, rel)
        rel.status, rel.manifest, rel.candidate_at = "draft", {}, None
    elif len({a.kind for a in active} | {body.kind}) == 2:
        rel.status, rel.approved_at = "approved", M.utcnow()
    db.flush()
    audit(db, user, f"release_{body.decision}", "release", rel.id, project_id=p.id,
          summary=f"{p.code} {rel.version}: {body.kind} {body.decision} -> {rel.status}", detail={"comment": body.comment},
          request=request)
    db.commit()
    return _release_out(db, rel, user, detail=True)


class WithdrawIn(In):
    reason: Annotated[str, Field(min_length=3)]


@router.post("/releases/{rid}/withdraw")
def withdraw(rid: int, body: WithdrawIn, request: Request, user: M.User = Depends(require("releases.approve.project")),
             db: Session = Depends(get_db)):
    rel, p = _get_rel(db, user, rid)
    if rel.status not in ("approved", "released", "candidate"):
        raise HTTPException(409, f"Release is '{rel.status}'")
    old = rel.status
    rel.status, rel.withdrawn_reason = "withdrawn", body.reason
    audit(db, user, "release_withdraw", "release", rel.id, project_id=p.id, summary=f"{p.code} {rel.version}: {old} -> withdrawn",
          detail={"reason": body.reason}, request=request)
    db.commit()
    return _release_out(db, rel, user, detail=True)


@router.get("/releases/{rid}/notes/draft")
def notes_draft(rid: int, user: M.User = Depends(require("releases.write")), db: Session = Depends(get_db)):
    rel, _ = _get_rel(db, user, rid)
    return {"text": D.release_notes_draft(db, rel), "note": "Generated from records; review and edit before saving."}


# ---------------------------------------------------------------- deployments (records)
class DeploymentIn(In):
    environment: Annotated[str, one_of(M.DEPLOY_ENVS)]
    site_id: int | None = None
    target: Annotated[str, Field(min_length=1, max_length=240)]
    status: Annotated[str, one_of(["planned", "performed", "failed"])] = "performed"
    performed_by: str | None = None
    performed_at: datetime | None = None
    procedure_ref: str | None = None
    notes: str | None = None


@router.get("/projects/{pid}/deployments")
def list_deployments(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    out = []
    for d in db.query(M.Deployment).filter_by(project_id=pid).order_by(M.Deployment.id.desc()):
        rel = db.get(M.Release, d.release_id)
        site = db.get(M.Site, d.site_id) if d.site_id else None
        out.append(to_dict(d) | {"version": rel.version, "site": site.name if site else None})
    return out


@router.post("/releases/{rid}/deployments", status_code=201)
def record_deployment(rid: int, body: DeploymentIn, request: Request, user: M.User = Depends(require("deployments.write")),
                      db: Session = Depends(get_db)):
    rel, p = _get_rel(db, user, rid)
    check_project_write(db, user, p)
    if rel.status not in ("approved", "released"):
        raise HTTPException(409, f"Only approved releases can be installed (release {rel.version} is '{rel.status}')")
    site = None
    if body.environment == "customer_site":
        site = db.get(M.Site, body.site_id) if body.site_id else None
        if not site or site.project_id != p.id:
            raise HTTPException(422, "site_id: a customer-site deployment needs a site of this project")
    elif body.site_id:
        raise HTTPException(422, "site_id is only used for customer_site deployments")
    d = M.Deployment(project_id=p.id, release_id=rel.id, recorded_by=user.username,
                     **(body.model_dump() | {"performed_at": body.performed_at or (M.utcnow() if body.status != "planned" else None),
                                             "performed_by": body.performed_by or (user.full_name if body.status != "planned" else None)}))
    db.add(d)
    if body.status == "performed" and body.environment == "customer_site":
        if rel.status == "approved":
            rel.status, rel.released_at = "released", M.utcnow()
        if site.status == "planned":
            site.status = "installing"
    db.flush()
    audit(db, user, "deployment", "release", rel.id, project_id=p.id,
          summary=f"{p.code} {rel.version} {body.status} on {body.environment}: {body.target}", request=request)
    db.commit()
    return to_dict(d)


class RollbackIn(In):
    to_release_id: int
    notes: Annotated[str, Field(min_length=3)]
    performed_by: str | None = None


@router.post("/deployments/{did}/rollback", status_code=201)
def rollback(did: int, body: RollbackIn, request: Request, user: M.User = Depends(require("deployments.write")),
             db: Session = Depends(get_db)):
    d = db.get(M.Deployment, did)
    if not d:
        raise HTTPException(404, "Deployment not found")
    p = get_project_or_404(db, user, d.project_id)
    check_project_write(db, user, p)
    if d.status != "performed":
        raise HTTPException(409, f"Only performed deployments can be rolled back (status '{d.status}')")
    to = db.get(M.Release, body.to_release_id)
    if not to or to.project_id != p.id or to.id == d.release_id:
        raise HTTPException(422, "to_release_id: another release of this project")
    if to.status not in ("approved", "released"):
        raise HTTPException(409, f"Rollback target {to.version} is '{to.status}' (needs approved or released)")
    d.status = "rolled_back"
    nd = M.Deployment(project_id=p.id, release_id=to.id, environment=d.environment, site_id=d.site_id, target=d.target,
                      status="performed", rollback_of_id=d.id, notes=body.notes, recorded_by=user.username,
                      performed_by=body.performed_by or user.full_name, performed_at=M.utcnow(),
                      procedure_ref=(db.get(M.Release, d.release_id).rollback_plan or "")[:300] or None)
    db.add(nd)
    db.flush()
    audit(db, user, "rollback", "deployment", d.id, project_id=p.id,
          summary=f"{p.code}: rolled back deployment #{d.id} on {d.target} to {to.version}", detail={"notes": body.notes},
          request=request)
    db.commit()
    return to_dict(nd)
