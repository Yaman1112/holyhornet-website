"""Test Rig Designer & Management (Module G): rigs, components, connections, templates, setup checklists,
monitoring (device presence, SCPI instrument readings) and authorised power control."""
from __future__ import annotations

import re
from datetime import date, timedelta
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import Field
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..hal import authz, scpi
from ..schemas import In, one_of
from ..security import audit, get_project_or_404, require
from ..services.records import to_dict

router = APIRouter(prefix="/api/v1", tags=["test rigs"])
CHECKLIST_VALID_H = 24


class RigIn(In):
    name: Annotated[str, Field(min_length=1, max_length=160)]
    project_id: int | None = None
    description: str | None = None
    kind: Annotated[str, one_of(M.RIG_KINDS)] = "physical"
    location: str | None = None
    is_template: bool = False


class RigPatch(In):
    name: str | None = None
    description: str | None = None
    location: str | None = None
    status: Annotated[str, one_of(M.RIG_STATUS)] | None = None


class RigCompIn(In):
    name: Annotated[str, Field(min_length=1, max_length=160)]
    role: Annotated[str, one_of(M.RIG_ROLES)]
    hardware_id: int | None = None
    properties: dict[str, Any] = {}
    x: float = 0
    y: float = 0


class RigCompPatch(In):
    name: str | None = None
    role: Annotated[str, one_of(M.RIG_ROLES)] | None = None
    hardware_id: int | None = None
    properties: dict[str, Any] | None = None
    x: float | None = None
    y: float | None = None
    unlink_hardware: bool = False


class RigConnIn(In):
    source_id: int
    target_id: int
    kind: Annotated[str, one_of(M.RIG_LINKS)]
    interface: str | None = None
    label: str | None = None
    notes: str | None = None


class ChecklistItemIn(In):
    key: str
    status: Annotated[str, one_of(["pass", "fail", "na", "open"])]
    note: str | None = None


class PowerIn(In):
    output: bool | None = None
    voltage: Annotated[float, Field(ge=0, le=60)] | None = None
    current_limit: Annotated[float, Field(ge=0, le=20)] | None = None


class InstantiateIn(In):
    name: Annotated[str, Field(min_length=1, max_length=160)]
    project_id: int | None = None
    kind: Annotated[str, one_of(M.RIG_KINDS)] | None = None


# ---------------------------------------------------------------- helpers
def _rig(db: Session, user: M.User, rid: int, write: bool = False) -> M.TestRig:
    r = db.get(M.TestRig, rid)
    if not r:
        raise HTTPException(404, "Rig not found")
    if r.project_id:
        get_project_or_404(db, user, r.project_id)
    if write and r.status == "in_use":
        raise HTTPException(409, "Rig is in use by a test run")
    return r


def _slug(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_").lower()[:40] or "c"


def _check_hw(db: Session, hid: int | None) -> None:
    if hid is not None and not db.get(M.HardwareItem, hid):
        raise HTTPException(422, "hardware_id: hardware item does not exist")


def _validate_props(kind: str, props: dict) -> None:
    sc = (props or {}).get("scpi")
    if sc:
        if kind == "virtual" and not sc.get("virtual"):
            raise HTTPException(422, "A virtual rig can only use virtual SCPI instruments (scpi.virtual=true)")
        if not sc.get("virtual") and not sc.get("host"):
            raise HTTPException(422, "scpi.host is required for a physical instrument")
    can = (props or {}).get("can")
    if can and kind == "virtual" and can.get("interface", "virtual") != "virtual":
        raise HTTPException(422, "A virtual rig can only use virtual CAN interfaces")


def rig_payload(db: Session, r: M.TestRig) -> dict:
    comps = db.query(M.RigComponent).filter_by(rig_id=r.id).all()
    hw = {h.id: h for h in db.query(M.HardwareItem).filter(M.HardwareItem.id.in_([c.hardware_id for c in comps if c.hardware_id]))}
    names = {c.id: c.name for c in comps}
    last = db.query(M.RigChecklist).filter_by(rig_id=r.id).order_by(M.RigChecklist.id.desc()).first()
    return to_dict(r) | {
        "components": [to_dict(c) | {"hardware": {"asset_tag": hw[c.hardware_id].asset_tag, "model": hw[c.hardware_id].model,
                                                   "status": hw[c.hardware_id].status} if c.hardware_id in hw else None}
                       for c in comps],
        "connections": [to_dict(x) | {"source": names.get(x.source_id), "target": names.get(x.target_id)}
                        for x in db.query(M.RigConnection).filter_by(rig_id=r.id)],
        "checklist": to_dict(last) if last else None, "hil_ready": hil_readiness(db, r)}


def hil_readiness(db: Session, r: M.TestRig) -> dict:
    """Conditions for running HIL tests on this rig."""
    reasons = []
    if r.kind != "physical":
        reasons.append("virtual rig: runs are recorded as 'virtual_rig', not HIL")
    if r.is_template:
        reasons.append("templates cannot run tests")
    last = db.query(M.RigChecklist).filter_by(rig_id=r.id).order_by(M.RigChecklist.id.desc()).first()
    fresh = last is not None and last.status == "complete" and last.completed_at and \
        last.completed_at > M.utcnow() - timedelta(hours=CHECKLIST_VALID_H)
    if not fresh:
        reasons.append(f"no setup checklist completed in the last {CHECKLIST_VALID_H} h")
    auth = authz.find_authorization(db, "rig", f"rig:{r.id}", "hil_execution")
    if r.kind == "physical" and auth is None:
        reasons.append(f"no approved 'hil_execution' authorisation for rig:{r.id}")
    return {"ready": not reasons, "reasons": reasons, "checklist_id": last.id if fresh else None,
            "authorization_id": auth.id if auth else None}


# ---------------------------------------------------------------- rigs
@router.get("/rigs")
def list_rigs(project_id: int | None = None, templates: bool | None = None, user: M.User = Depends(require("internal.view")),
              db: Session = Depends(get_db)):
    q = db.query(M.TestRig).order_by(M.TestRig.is_template, M.TestRig.name)
    if project_id:
        q = q.filter((M.TestRig.project_id == project_id) | (M.TestRig.project_id.is_(None)))
    if templates is not None:
        q = q.filter(M.TestRig.is_template.is_(templates))
    out = []
    for r in q:
        n = db.query(M.RigComponent).filter_by(rig_id=r.id).count()
        out.append(to_dict(r) | {"components": n, "hil_ready": hil_readiness(db, r)})
    return out


@router.post("/rigs", status_code=201)
def create_rig(body: RigIn, request: Request, user: M.User = Depends(require("rigs.write")), db: Session = Depends(get_db)):
    if body.project_id:
        get_project_or_404(db, user, body.project_id)
    r = M.TestRig(**body.model_dump(), created_by=user.username)
    db.add(r)
    db.flush()
    audit(db, user, "rig_create", "rig", r.id, project_id=r.project_id, summary=f"Rig '{r.name}' ({r.kind})", request=request)
    db.commit()
    return rig_payload(db, r)


@router.get("/rigs/{rid}")
def get_rig(rid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return rig_payload(db, _rig(db, user, rid))


@router.patch("/rigs/{rid}")
def update_rig(rid: int, body: RigPatch, request: Request, user: M.User = Depends(require("rigs.write")),
               db: Session = Depends(get_db)):
    r = _rig(db, user, rid)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(r, k, v)
    audit(db, user, "rig_update", "rig", r.id, project_id=r.project_id, summary=f"Rig '{r.name}' updated", request=request)
    db.commit()
    return rig_payload(db, r)


@router.post("/rigs/{rid}/instantiate", status_code=201)
def instantiate(rid: int, body: InstantiateIn, request: Request, user: M.User = Depends(require("rigs.write")),
                db: Session = Depends(get_db)):
    """Create a rig from a template (or save a rig as a template by passing an existing rig)."""
    src = _rig(db, user, rid)
    kind = body.kind or src.kind
    new = M.TestRig(name=body.name, project_id=body.project_id, description=src.description, kind=kind,
                    location=src.location, is_template=False,
                    template_id=src.id if src.is_template else None, created_by=user.username)
    db.add(new)
    db.flush()
    idmap = {}
    for c in db.query(M.RigComponent).filter_by(rig_id=src.id):
        props = dict(c.properties or {})
        if kind == "virtual":
            if props.get("scpi"):
                props["scpi"] = {**props["scpi"], "virtual": True}
            if props.get("can"):
                props["can"] = {**props["can"], "interface": "virtual"}
        n = M.RigComponent(rig_id=new.id, key=c.key, name=c.name, role=c.role, properties=props, x=c.x, y=c.y,
                           hardware_id=None if src.is_template else c.hardware_id)
        db.add(n)
        db.flush()
        idmap[c.id] = n.id
    for x in db.query(M.RigConnection).filter_by(rig_id=src.id):
        db.add(M.RigConnection(rig_id=new.id, source_id=idmap[x.source_id], target_id=idmap[x.target_id], kind=x.kind,
                               interface=x.interface, label=x.label, notes=x.notes))
    audit(db, user, "rig_instantiate", "rig", new.id, project_id=new.project_id,
          summary=f"Rig '{new.name}' created from '{src.name}'", request=request)
    db.commit()
    return rig_payload(db, new)


@router.post("/rigs/{rid}/save-template", status_code=201)
def save_template(rid: int, body: InstantiateIn, request: Request, user: M.User = Depends(require("rigs.write")),
                  db: Session = Depends(get_db)):
    src = _rig(db, user, rid)
    t = M.TestRig(name=body.name, description=src.description, kind=src.kind, is_template=True, created_by=user.username)
    db.add(t)
    db.flush()
    idmap = {}
    for c in db.query(M.RigComponent).filter_by(rig_id=src.id):
        n = M.RigComponent(rig_id=t.id, key=c.key, name=c.name, role=c.role, properties=c.properties, x=c.x, y=c.y)
        db.add(n)
        db.flush()
        idmap[c.id] = n.id
    for x in db.query(M.RigConnection).filter_by(rig_id=src.id):
        db.add(M.RigConnection(rig_id=t.id, source_id=idmap[x.source_id], target_id=idmap[x.target_id], kind=x.kind,
                               interface=x.interface, label=x.label, notes=x.notes))
    audit(db, user, "rig_template", "rig", t.id, summary=f"Template '{t.name}' saved from rig '{src.name}'", request=request)
    db.commit()
    return rig_payload(db, t)


# ---------------------------------------------------------------- components & connections
@router.post("/rigs/{rid}/components", status_code=201)
def add_comp(rid: int, body: RigCompIn, request: Request, user: M.User = Depends(require("rigs.write")),
             db: Session = Depends(get_db)):
    r = _rig(db, user, rid, write=True)
    _check_hw(db, body.hardware_id)
    _validate_props(r.kind, body.properties)
    key, n = _slug(body.name), 1
    while db.query(M.RigComponent.id).filter_by(rig_id=rid, key=key).first():
        n += 1
        key = f"{_slug(body.name)}_{n}"
    c = M.RigComponent(rig_id=rid, key=key, **body.model_dump())
    db.add(c)
    db.flush()
    audit(db, user, "rig_component", "rig", rid, project_id=r.project_id, summary=f"Rig '{r.name}': + {c.role} '{c.name}'",
          request=request)
    db.commit()
    return to_dict(c)


def _comp(db: Session, user: M.User, cid: int) -> tuple[M.RigComponent, M.TestRig]:
    c = db.get(M.RigComponent, cid)
    if not c:
        raise HTTPException(404, "Component not found")
    return c, _rig(db, user, c.rig_id, write=True)


@router.patch("/rig-components/{cid}")
def patch_comp(cid: int, body: RigCompPatch, user: M.User = Depends(require("rigs.write")), db: Session = Depends(get_db)):
    c, r = _comp(db, user, cid)
    ch = body.model_dump(exclude_unset=True)
    if ch.pop("unlink_hardware", False):
        ch["hardware_id"] = None
    if ch.get("hardware_id"):
        _check_hw(db, ch["hardware_id"])
    if "properties" in ch:
        _validate_props(r.kind, ch["properties"])
    for k, v in ch.items():
        setattr(c, k, v)
    db.commit()
    return to_dict(c)


@router.delete("/rig-components/{cid}")
def delete_comp(cid: int, request: Request, user: M.User = Depends(require("rigs.write")), db: Session = Depends(get_db)):
    c, r = _comp(db, user, cid)
    db.query(M.RigConnection).filter((M.RigConnection.source_id == cid) | (M.RigConnection.target_id == cid)).delete()
    audit(db, user, "rig_component_delete", "rig", r.id, project_id=r.project_id, summary=f"Rig '{r.name}': - '{c.name}'",
          request=request)
    db.delete(c)
    db.commit()
    return {"ok": True}


@router.post("/rigs/{rid}/connections", status_code=201)
def add_conn(rid: int, body: RigConnIn, user: M.User = Depends(require("rigs.write")), db: Session = Depends(get_db)):
    _rig(db, user, rid, write=True)
    s, t = db.get(M.RigComponent, body.source_id), db.get(M.RigComponent, body.target_id)
    if not s or not t or s.rig_id != rid or t.rig_id != rid or s.id == t.id:
        raise HTTPException(422, "source_id/target_id must be two different components of this rig")
    x = M.RigConnection(rig_id=rid, **body.model_dump())
    db.add(x)
    db.commit()
    return to_dict(x)


@router.delete("/rig-connections/{xid}")
def delete_conn(xid: int, user: M.User = Depends(require("rigs.write")), db: Session = Depends(get_db)):
    x = db.get(M.RigConnection, xid)
    if not x:
        raise HTTPException(404, "Connection not found")
    _rig(db, user, x.rig_id, write=True)
    db.delete(x)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- checklist
def _scpi_status(c: M.RigComponent, rig: M.TestRig) -> dict | None:
    ep = scpi.endpoint(c.properties, f"rig{rig.id}:{c.key}")
    if not ep:
        return None
    try:
        return scpi.ScpiClient(ep[0], ep[1]).status() | {"endpoint": f"{ep[0]}:{ep[1]}", "virtual": ep[2], "ok": True}
    except Exception as e:
        return {"ok": False, "endpoint": f"{ep[0]}:{ep[1]}", "virtual": ep[2], "error": f"{type(e).__name__}: {e}"}


def generate_items(db: Session, r: M.TestRig) -> list[dict]:
    comps = {c.id: c for c in db.query(M.RigComponent).filter_by(rig_id=r.id)}
    items: list[dict] = []

    def add(key, text, auto=False, status="open", detail=""):
        items.append({"key": key, "text": text, "auto": auto, "status": status, "detail": detail, "by": "auto" if auto else None})

    for c in comps.values():
        if c.hardware_id:
            h = db.get(M.HardwareItem, c.hardware_id)
            ok = h.status not in ("faulty", "retired")
            add(f"hw_status:{c.key}", f"{c.name}: inventory item {h.asset_tag} usable", True, "pass" if ok else "fail",
                f"{h.model} S/N {h.serial_number} status {h.status}, FW {h.firmware_version or '-'}")
            if r.kind == "physical":
                det = db.query(M.DetectedDevice).filter_by(hardware_id=h.id, present=True).first()
                add(f"present:{c.key}", f"{c.name}: device detected on the rig host", True if det else False,
                    "pass" if det else "open", f"{det.bus}:{det.identifier}" if det else "Not detected at last scan — confirm manually or scan")
        elif r.kind == "physical" and c.role not in ("other",):
            add(f"identify:{c.key}", f"{c.name}: record unit identity (asset / serial) — not linked to inventory")
        sc = _scpi_status(c, r)
        if sc is not None:
            add(f"scpi:{c.key}", f"{c.name}: instrument responds on SCPI", True, "pass" if sc["ok"] else "fail",
                sc.get("idn") or sc.get("error", ""))
        due = (c.properties or {}).get("calibration_due")
        if c.role in ("measurement_instrument", "oscilloscope", "logic_analyzer", "programmable_power", "power_supply",
                      "signal_generator") and r.kind == "physical":
            if due:
                try:
                    ok = date.fromisoformat(str(due)) >= date.today()
                    add(f"cal:{c.key}", f"{c.name}: calibration valid", True, "pass" if ok else "fail", f"due {due}")
                except ValueError:
                    add(f"cal:{c.key}", f"{c.name}: calibration valid", detail=f"unreadable date {due}")
            else:
                add(f"cal:{c.key}", f"{c.name}: calibration valid (no due date recorded)")
    for x in db.query(M.RigConnection).filter_by(rig_id=r.id):
        s, t = comps.get(x.source_id), comps.get(x.target_id)
        if not s or not t:
            continue
        if x.kind == "power":
            vmin = vmax = None
            if t.hardware_id:
                h = db.get(M.HardwareItem, t.hardware_id)
                vmin, vmax = h.supply_voltage_min, h.supply_voltage_max
            sc = _scpi_status(s, r)
            if sc and sc.get("ok") and vmin is not None and vmax is not None and sc["output_on"]:
                ok = vmin <= sc["voltage_v"] <= vmax
                add(f"power:{x.id}", f"Supply {s.name} → {t.name} within {vmin:g}–{vmax:g} V", True, "pass" if ok else "fail",
                    f"measured {sc['voltage_v']} V / {sc['current_a']} A")
            else:
                add(f"power:{x.id}", f"Supply {s.name} → {t.name}: polarity, voltage"
                    + (f" {vmin:g}–{vmax:g} V" if vmin is not None and vmax is not None else "") + " and current limit verified")
        elif x.kind == "communication":
            add(f"comm:{x.id}", f"{x.interface or 'Link'} {s.name} ↔ {t.name}: cable, connector and pin-out checked")
            if (x.interface or "").upper().startswith("CAN"):
                add(f"term:{x.id}", f"CAN {s.name} ↔ {t.name}: 120 Ω termination at both bus ends (≈60 Ω measured)")
        elif x.kind == "measurement":
            add(f"meas:{x.id}", f"Measurement point {x.label or ''} {s.name} → {t.name}: probe/ground connected")
    if r.kind == "physical":
        add("isolation", "Rig is isolated from any vehicle network and actuators are disabled or simulated")
        add("estop", "Emergency stop / power cut-off reachable and tested")
        auth = authz.find_authorization(db, "rig", f"rig:{r.id}", "hil_execution")
        add("auth", "Approved HIL execution authorisation for this rig", True, "pass" if auth else "fail",
            f"authorisation #{auth.id} valid until {auth.valid_until:%Y-%m-%d %H:%M}" if auth else
            f"request one for interface 'rig', channel 'rig:{r.id}', action 'hil_execution'")
    return items


def _status(items: list[dict]) -> str:
    st = {i["status"] for i in items}
    if "fail" in st:
        return "failed"
    if "open" in st:
        return "open"
    return "complete"


@router.post("/rigs/{rid}/checklist", status_code=201)
def new_checklist(rid: int, request: Request, user: M.User = Depends(require("rigs.checklist")), db: Session = Depends(get_db)):
    r = _rig(db, user, rid)
    if r.is_template:
        raise HTTPException(409, "Templates have no setup checklist")
    items = generate_items(db, r)
    c = M.RigChecklist(rig_id=rid, items=items, status=_status(items), started_by=user.username)
    if c.status == "complete":
        c.completed_by, c.completed_at = user.username, M.utcnow()
    db.add(c)
    db.flush()
    audit(db, user, "rig_checklist", "rig", rid, project_id=r.project_id, summary=f"Checklist #{c.id} for '{r.name}' ({c.status})",
          request=request)
    db.commit()
    return to_dict(c)


@router.put("/rig-checklists/{cid}/items")
def update_item(cid: int, body: ChecklistItemIn, request: Request, user: M.User = Depends(require("rigs.checklist")),
                db: Session = Depends(get_db)):
    c = db.get(M.RigChecklist, cid)
    if not c:
        raise HTTPException(404, "Checklist not found")
    r = _rig(db, user, c.rig_id)
    if c.status == "complete":
        raise HTTPException(409, "Checklist already complete; start a new one")
    items = [dict(i) for i in c.items]
    it = next((i for i in items if i["key"] == body.key), None)
    if it is None:
        raise HTTPException(404, "Item not found")
    if it["auto"] and body.status != it["status"] and body.status in ("pass", "na"):
        raise HTTPException(409, "Automatic checks cannot be overridden; fix the cause and regenerate the checklist")
    it["status"], it["by"] = body.status, user.username
    if body.note:
        it["detail"] = (it.get("detail") or "") + f" | {user.username}: {body.note}"
    c.items = items
    c.status = _status(items)
    if c.status == "complete":
        c.completed_by, c.completed_at = user.username, M.utcnow()
    audit(db, user, "rig_checklist_item", "rig", r.id, project_id=r.project_id,
          summary=f"Checklist #{c.id}: {body.key} -> {body.status}", request=request)
    db.commit()
    return to_dict(c)


# ---------------------------------------------------------------- monitoring & power
@router.get("/rigs/{rid}/monitor")
def monitor(rid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    r = _rig(db, user, rid)
    out = []
    for c in db.query(M.RigComponent).filter_by(rig_id=rid):
        d = {"id": c.id, "key": c.key, "name": c.name, "role": c.role}
        if c.hardware_id:
            h = db.get(M.HardwareItem, c.hardware_id)
            det = db.query(M.DetectedDevice).filter_by(hardware_id=h.id, present=True).first()
            d["hardware"] = {"asset_tag": h.asset_tag, "status": h.status}
            d["detected"] = f"{det.bus}:{det.identifier}" if det else None
        sc = _scpi_status(c, r)
        if sc is not None:
            d["instrument"] = sc
        can = (c.properties or {}).get("can")
        if can:
            d["can"] = can
        out.append(d)
    return {"rig": r.name, "kind": r.kind, "at": M.utcnow().isoformat(timespec="seconds"), "components": out}


@router.post("/rig-components/{cid}/power")
def power(cid: int, body: PowerIn, request: Request, user: M.User = Depends(require("rigs.power")),
          db: Session = Depends(get_db)):
    c = db.get(M.RigComponent, cid)
    if not c:
        raise HTTPException(404, "Component not found")
    r = _rig(db, user, c.rig_id)
    ep = scpi.endpoint(c.properties, f"rig{r.id}:{c.key}")
    if not ep:
        raise HTTPException(422, "Component has no SCPI instrument")
    host, port, virtual = ep
    a = None if virtual else authz.require(db, "scpi", f"{host}:{port}", "power_control")
    cl = scpi.ScpiClient(host, port)
    try:
        if body.current_limit is not None:
            cl.write(f"CURR {body.current_limit}")
        if body.voltage is not None:
            cl.write(f"VOLT {body.voltage}")
        if body.output is not None:
            cl.write(f"OUTP {'ON' if body.output else 'OFF'}")
        st = cl.status()
    except Exception as e:
        raise HTTPException(409, f"Instrument error: {e}")
    audit(db, user, "power_control", "rig", r.id, project_id=r.project_id,
          summary=f"{r.name}/{c.name}: {body.model_dump(exclude_none=True)} -> {st['voltage_v']} V {st['current_a']} A"
                  + (" (virtual)" if virtual else f" (auth #{a.id})"), request=request)
    db.commit()
    return st | {"virtual": virtual}
