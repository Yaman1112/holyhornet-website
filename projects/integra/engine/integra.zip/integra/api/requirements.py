"""Requirements, traceability links, validation evidence, coverage matrix, revisions."""
from __future__ import annotations

import re

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from .. import models as M
from ..db import get_db
from ..schemas import EvidenceIn, ReqStatusIn, RequirementIn, RequirementPatch, TraceIn
from ..security import audit, can, check_project_write, current_user, get_project_or_404, require
from ..services import engineering as E
from ..services.records import diff, record_revision, revision_count, to_dict

router = APIRouter(prefix="/api/v1", tags=["requirements"])

# status changes that need the approval permission, and transitions that need evidence
APPROVAL_STATUSES = {"approved"}
EVIDENCE_STATUSES = {"passed", "approved"}


def _req_out(db: Session, r: M.Requirement, detail: bool = False) -> dict:
    d = to_dict(r)
    d["link_count"] = len(r.links)
    d["evidence_count"] = len(r.evidence)
    d["validation_evidence"] = E.has_validation_evidence(r)
    d["revision"] = revision_count(db, "requirement", r.id)
    if detail:
        d["links"] = [to_dict(l) for l in r.links]
        d["evidence"] = [to_dict(e) for e in sorted(r.evidence, key=lambda e: e.id, reverse=True)]
        d["children"] = [{"id": c.id, "ref": c.ref, "title": c.title} for c in
                         db.query(M.Requirement).filter_by(parent_id=r.id)]
    return d


def _get_req(db: Session, user: M.User, rid: int) -> tuple[M.Requirement, M.Project]:
    r = db.get(M.Requirement, rid)
    if not r:
        raise HTTPException(404, "Requirement not found")
    return r, get_project_or_404(db, user, r.project_id)


def _next_ref(db: Session, pid: int) -> str:
    nums = [int(m.group(1)) for (ref,) in db.query(M.Requirement.ref).filter_by(project_id=pid)
            if (m := re.fullmatch(r"REQ-(\d+)", ref))]
    return f"REQ-{(max(nums) + 1 if nums else 1):03d}"


@router.get("/projects/{pid}/requirements")
def list_requirements(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_req_out(db, r) for r in E.load_requirements(db, pid)]


@router.post("/projects/{pid}/requirements", status_code=201)
def create_requirement(pid: int, body: RequirementIn, request: Request,
                       user: M.User = Depends(require("requirements.write")), db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    data = body.model_dump()
    data["ref"] = data["ref"] or _next_ref(db, pid)
    if db.query(M.Requirement.id).filter_by(project_id=pid, ref=data["ref"]).first():
        raise HTTPException(409, f"Requirement {data['ref']} already exists in {p.code}")
    if data["parent_id"]:
        parent = db.get(M.Requirement, data["parent_id"])
        if not parent or parent.project_id != pid:
            raise HTTPException(422, "parent_id: parent must be a requirement of the same project")
    r = M.Requirement(project_id=pid, created_by=user.username, **data)
    db.add(r)
    db.flush()
    record_revision(db, "requirement", r, user.username, "Created")
    audit(db, user, "create", "requirement", r.id, project_id=pid, summary=f"{p.code} {r.ref}: {r.title}",
          request=request)
    db.commit()
    return _req_out(db, r, detail=True)


@router.get("/requirements/{rid}")
def get_requirement(rid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    r, _ = _get_req(db, user, rid)
    return _req_out(db, r, detail=True)


@router.patch("/requirements/{rid}")
def update_requirement(rid: int, body: RequirementPatch, request: Request,
                       user: M.User = Depends(require("requirements.write")), db: Session = Depends(get_db)):
    r, p = _get_req(db, user, rid)
    check_project_write(db, user, p)
    changes = body.model_dump(exclude_unset=True)
    comment = changes.pop("comment", None)
    if changes.get("parent_id"):
        if changes["parent_id"] == r.id:
            raise HTTPException(422, "A requirement cannot be its own parent")
        parent = db.get(M.Requirement, changes["parent_id"])
        if not parent or parent.project_id != r.project_id:
            raise HTTPException(422, "parent_id: parent must be a requirement of the same project")
        # cycle check
        cur = parent
        while cur.parent_id:
            if cur.parent_id == r.id:
                raise HTTPException(422, "parent_id would create a cycle")
            cur = db.get(M.Requirement, cur.parent_id)
    for k, v in changes.items():
        setattr(r, k, v)
    db.flush()
    rev = record_revision(db, "requirement", r, user.username, comment)
    audit(db, user, "update", "requirement", r.id, project_id=p.id, summary=f"{p.code} {r.ref} updated",
          detail={"fields": rev.changed_fields if rev else []}, request=request)
    db.commit()
    return _req_out(db, r, detail=True)


@router.post("/requirements/{rid}/status")
def set_status(rid: int, body: ReqStatusIn, request: Request, user: M.User = Depends(current_user),
               db: Session = Depends(get_db)):
    r, p = _get_req(db, user, rid)
    needed = "requirements.approve" if body.status in APPROVAL_STATUSES or r.status == "approved" \
        else "requirements.status"
    if not can(user, needed):
        raise HTTPException(403, f"Your role may not set status '{body.status}' (needs {needed})")
    check_project_write(db, user, p)
    if body.status in EVIDENCE_STATUSES and not E.has_validation_evidence(r):
        raise HTTPException(409, f"{r.ref} cannot be '{body.status}' without validation evidence "
                                 "(record a passing result or a customer sign-off first)")
    if body.status == "approved" and r.status != "passed":
        raise HTTPException(409, f"{r.ref} must be 'passed' before customer approval")
    old = r.status
    r.status = body.status
    db.flush()
    record_revision(db, "requirement", r, user.username, f"Status {old} -> {r.status}: {body.comment or ''}")
    audit(db, user, "status", "requirement", r.id, project_id=p.id, summary=f"{p.code} {r.ref}: {old} -> {r.status}",
          detail={"comment": body.comment}, request=request)
    db.commit()
    return _req_out(db, r, detail=True)


@router.delete("/requirements/{rid}")
def delete_requirement(rid: int, request: Request, user: M.User = Depends(require("requirements.write")),
                       db: Session = Depends(get_db)):
    r, p = _get_req(db, user, rid)
    check_project_write(db, user, p)
    if r.evidence:
        raise HTTPException(409, f"{r.ref} has {len(r.evidence)} evidence record(s); evidence is retained for "
                                 "traceability, so the requirement cannot be deleted")
    audit(db, user, "delete", "requirement", r.id, project_id=p.id, summary=f"{p.code} {r.ref} deleted",
          detail={"snapshot": to_dict(r)}, request=request)
    db.delete(r)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- trace links
def _resolve_target(db: Session, project_id: int, target_type: str, ref: str) -> str:
    """Validate links to record types that exist in this phase; return a label."""
    if target_type == "hardware":
        h = db.get(M.HardwareItem, int(ref)) if ref.isdigit() else None
        if not h:
            raise HTTPException(422, f"Hardware item {ref} does not exist")
        if h.project_id not in (None, project_id):
            raise HTTPException(422, f"{h.asset_tag} is assigned to another project")
        return f"{h.asset_tag} {h.name} ({h.model}, rev {h.hardware_revision or '-'})"
    if target_type == "software":
        s = db.get(M.SoftwareItem, int(ref)) if ref.isdigit() else None
        if not s:
            raise HTTPException(422, f"Software item {ref} does not exist")
        if s.project_id not in (None, project_id):
            raise HTTPException(422, f"{s.name} is assigned to another project")
        return f"{s.name} {s.version}"
    if target_type == "architecture_component":
        c = db.get(M.ArchComponent, int(ref)) if ref.isdigit() else None
        m = db.get(M.ArchModel, c.model_id) if c else None
        if not c or m.project_id != project_id:
            raise HTTPException(422, f"Architecture component {ref} does not exist in this project")
        return f"{m.name}: {c.name} ({c.layer})"
    if target_type == "test_case":
        tc = db.get(M.TestCase, int(ref)) if ref.isdigit() else None
        if not tc or tc.project_id != project_id:
            raise HTTPException(422, f"Test case {ref} does not exist in this project")
        return f"{tc.ref} {tc.name}"
    if target_type == "interface":
        cn = db.get(M.ArchConnection, int(ref)) if ref.isdigit() else None
        m = db.get(M.ArchModel, cn.model_id) if cn else None
        if not cn or m.project_id != project_id:
            raise HTTPException(422, f"Interface {ref} does not exist in this project")
        s, t = db.get(M.ArchComponent, cn.source_id), db.get(M.ArchComponent, cn.target_id)
        return f"{m.name}: {s.name} -> {t.name} ({cn.interface_type}/{cn.protocol or '-'})"
    return ""


@router.post("/requirements/{rid}/links", status_code=201)
def add_link(rid: int, body: TraceIn, request: Request, user: M.User = Depends(require("trace.write")),
             db: Session = Depends(get_db)):
    r, p = _get_req(db, user, rid)
    check_project_write(db, user, p)
    label = _resolve_target(db, p.id, body.target_type, body.target_ref) or body.target_label
    if not label:
        raise HTTPException(422, f"target_label is required for '{body.target_type}' links "
                                 "(that record type is managed by a later module)")
    if db.query(M.TraceLink.id).filter_by(requirement_id=r.id, target_type=body.target_type,
                                          target_ref=body.target_ref, relation=body.relation).first():
        raise HTTPException(409, "This trace link already exists")
    l = M.TraceLink(requirement_id=r.id, target_type=body.target_type, target_ref=body.target_ref,
                    target_label=label, relation=body.relation, created_by=user.username)
    db.add(l)
    db.flush()
    audit(db, user, "link", "requirement", r.id, project_id=p.id,
          summary=f"{p.code} {r.ref} {body.relation} {body.target_type}:{label}", request=request)
    db.commit()
    return to_dict(l)


@router.delete("/requirements/{rid}/links/{lid}")
def remove_link(rid: int, lid: int, request: Request, user: M.User = Depends(require("trace.write")),
                db: Session = Depends(get_db)):
    r, p = _get_req(db, user, rid)
    check_project_write(db, user, p)
    l = db.query(M.TraceLink).filter_by(id=lid, requirement_id=rid).first()
    if not l:
        raise HTTPException(404, "Link not found")
    audit(db, user, "unlink", "requirement", r.id, project_id=p.id,
          summary=f"{p.code} {r.ref} unlinked {l.target_type}:{l.target_label}", request=request)
    db.delete(l)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- evidence (append-only)
@router.post("/requirements/{rid}/evidence", status_code=201)
def add_evidence(rid: int, body: EvidenceIn, request: Request, user: M.User = Depends(current_user),
                 db: Session = Depends(get_db)):
    r, p = _get_req(db, user, rid)
    if body.kind == "customer_signoff":
        if not can(user, "requirements.approve"):
            raise HTTPException(403, "Only project managers/administrators record customer sign-off")
    elif not can(user, "evidence.write"):
        raise HTTPException(403, "Your role may not record verification evidence")
    check_project_write(db, user, p)
    e = M.Evidence(requirement_id=r.id, recorded_by=user.username, **body.model_dump())
    db.add(e)
    db.flush()
    audit(db, user, "evidence", "requirement", r.id, project_id=p.id,
          summary=f"{p.code} {r.ref}: {e.kind} '{e.title}' result={e.result}", request=request)
    # a failing result on a passed requirement re-opens it
    if e.result == "fail" and r.status in ("passed", "approved", "tested"):
        old = r.status
        r.status = "failed"
        db.flush()
        record_revision(db, "requirement", r, user.username, f"Auto: failing evidence #{e.id} ({old} -> failed)")
        audit(db, "system", "status", "requirement", r.id, project_id=p.id,
              summary=f"{p.code} {r.ref}: {old} -> failed (failing evidence #{e.id})")
    db.commit()
    return to_dict(e)


# ---------------------------------------------------------------- coverage & revisions
@router.get("/projects/{pid}/coverage")
def coverage(pid: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    reqs = E.load_requirements(db, pid)
    return E.coverage(db, pid, reqs) | {"gate": E.delivery_gate(db, pid, reqs)}


VERSIONED = {"project": M.Project, "requirement": M.Requirement, "hardware": M.HardwareItem, "software": M.SoftwareItem,
             "issue": M.Issue}


@router.get("/revisions/{entity_type}/{entity_id}")
def revisions(entity_type: str, entity_id: int, user: M.User = Depends(current_user), db: Session = Depends(get_db)):
    if entity_type not in VERSIONED:
        raise HTTPException(404, "Unknown entity type")
    obj = db.get(VERSIONED[entity_type], entity_id)
    if not obj:
        raise HTTPException(404, "Record not found")
    pid = obj.id if entity_type == "project" else obj.project_id
    if pid is not None:
        get_project_or_404(db, user, pid)
    elif not can(user, "internal.view"):
        raise HTTPException(404, "Record not found")
    revs = (db.query(M.EntityRevision).filter_by(entity_type=entity_type, entity_id=entity_id)
            .order_by(M.EntityRevision.revision).all())
    hidden = set() if can(user, "internal.view") else {"internal_notes"}
    out, prev = [], {}
    for rv in revs:
        snap = {k: v for k, v in rv.snapshot.items() if k not in hidden}
        out.append({"revision": rv.revision, "changed_by": rv.changed_by,
                    "changed_at": rv.changed_at.isoformat(timespec="seconds"), "comment": rv.comment,
                    "changes": diff(prev, snap) if prev else [], "snapshot": snap})
        prev = snap
    return out
