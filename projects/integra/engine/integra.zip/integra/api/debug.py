"""Debugging & Diagnostics (Module J): log sources and imports, timestamp synchronisation, event search, timeline,
correlation, incidents, anomaly detection, and the issue / root-cause-analysis workflow."""
from __future__ import annotations

import hashlib
import re
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse
from pydantic import Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import config
from .. import models as M
from ..db import get_db
from ..schemas import In, one_of
from ..security import audit, can, get_project_or_404, require
from ..services import analysis as A
from ..services.records import record_revision, to_dict

router = APIRouter(prefix="/api/v1", tags=["debugging & root cause analysis"])
MAX_LOG_BYTES = 50_000_000


# ---------------------------------------------------------------- schemas
class SourceIn(In):
    name: Annotated[str, Field(min_length=1, max_length=120)]
    component: str | None = None
    kind: Annotated[str, one_of(M.LOG_KINDS)] = "application"
    format: Annotated[str, one_of(M.LOG_FORMATS)] = "auto"
    clock_offset_ms: float = 0.0
    timezone_offset_min: Annotated[int, Field(ge=-840, le=840)] = 0


class SourcePatch(In):
    name: str | None = None
    component: str | None = None
    kind: Annotated[str, one_of(M.LOG_KINDS)] | None = None
    format: Annotated[str, one_of(M.LOG_FORMATS)] | None = None
    clock_offset_ms: float | None = None


class AlignIn(In):
    event_id: int  # an event of this source ...
    reference_event_id: int  # ... that happened at the same physical moment as this event of another source


class IssueIn(In):
    title: Annotated[str, Field(min_length=1, max_length=240)]
    severity: Annotated[str, one_of(M.ISSUE_SEVERITY)] = "major"
    affected_subsystem: str | None = None
    problem_description: str | None = None
    reproduction_steps: str | None = None
    expected_behaviour: str | None = None
    actual_behaviour: str | None = None
    hardware_revision: str | None = None
    software_revision: str | None = None
    integration_config_id: int | None = None
    owner: str | None = None
    event_id: int | None = None  # create from a log event
    test_result_id: int | None = None  # create from a failed test result
    connection_id: int | None = None  # create from a failing architecture interface
    requirement_ids: list[int] = []
    site_id: int | None = None  # issue found at a customer site (Phase 7)


class IssuePatch(In):
    title: str | None = None
    severity: Annotated[str, one_of(M.ISSUE_SEVERITY)] | None = None
    affected_subsystem: str | None = None
    problem_description: str | None = None
    reproduction_steps: str | None = None
    expected_behaviour: str | None = None
    actual_behaviour: str | None = None
    hardware_revision: str | None = None
    software_revision: str | None = None
    integration_config_id: int | None = None
    window_start: datetime | None = None
    window_end: datetime | None = None
    confirmed_root_cause: str | None = None
    corrective_action: str | None = None
    corrective_owner: str | None = None
    corrective_due: date | None = None
    retest_run_id: int | None = None
    retest_result: str | None = None
    owner: str | None = None


class StatusIn(In):
    status: Annotated[str, one_of(M.ISSUE_STATUS)]
    note: str | None = None


class HypothesisIn(In):
    text: Annotated[str, Field(min_length=3)]


class DecisionIn(In):
    status: Annotated[str, one_of(["confirmed", "rejected"])]
    verification: Annotated[str, Field(min_length=5)]


class PinIn(In):
    add: list[int] = []
    remove: list[int] = []


# ---------------------------------------------------------------- sources & imports
def _source(db: Session, user: M.User, sid: int) -> M.LogSource:
    s = db.get(M.LogSource, sid)
    if not s:
        raise HTTPException(404, "Log source not found")
    get_project_or_404(db, user, s.project_id)
    return s


@router.get("/projects/{pid}/log-sources")
def list_sources(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    counts = dict(db.query(M.LogEvent.source_id, func.count(M.LogEvent.id)).filter_by(project_id=pid).group_by(M.LogEvent.source_id))
    span = {sid: (a, b) for sid, a, b in db.query(M.LogEvent.source_id, func.min(M.LogEvent.ts), func.max(M.LogEvent.ts))
            .filter_by(project_id=pid).group_by(M.LogEvent.source_id)}
    out = []
    for s in db.query(M.LogSource).filter_by(project_id=pid).order_by(M.LogSource.internal, M.LogSource.name):
        a, b = span.get(s.id, (None, None))
        out.append(to_dict(s) | {"events": counts.get(s.id, 0), "first": a.isoformat() if a else None,
                                 "last": b.isoformat() if b else None,
                                 "imports": [to_dict(i) for i in db.query(M.LogImport).filter_by(source_id=s.id)
                                             .order_by(M.LogImport.id.desc())]})
    return out


@router.post("/projects/{pid}/log-sources", status_code=201)
def create_source(pid: int, body: SourceIn, request: Request, user: M.User = Depends(require("debug.write")),
                  db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    if db.query(M.LogSource.id).filter_by(project_id=pid, name=body.name).first():
        raise HTTPException(409, "A log source with this name exists")
    s = M.LogSource(project_id=pid, created_by=user.username, **body.model_dump())
    db.add(s)
    db.flush()
    audit(db, user, "log_source", "log_source", s.id, project_id=pid, summary=f"Log source '{s.name}' ({s.kind})", request=request)
    db.commit()
    return to_dict(s)


@router.patch("/log-sources/{sid}")
def patch_source(sid: int, body: SourcePatch, request: Request, user: M.User = Depends(require("debug.write")),
                 db: Session = Depends(get_db)):
    s = _source(db, user, sid)
    ch = body.model_dump(exclude_unset=True)
    for k, v in ch.items():
        setattr(s, k, v)
    n = A.resync(db, s) if "clock_offset_ms" in ch else 0
    audit(db, user, "log_source_update", "log_source", s.id, project_id=s.project_id,
          summary=f"Log source '{s.name}' updated" + (f"; offset {s.clock_offset_ms} ms applied to {n} events" if n else ""),
          request=request)
    db.commit()
    return to_dict(s) | {"resynced": n}


@router.post("/log-sources/{sid}/import", status_code=201)
async def import_log(sid: int, request: Request, file: UploadFile = File(...), year: int | None = Form(None),
                     user: M.User = Depends(require("debug.write")), db: Session = Depends(get_db)):
    s = _source(db, user, sid)
    raw = await file.read()
    if len(raw) > MAX_LOG_BYTES:
        raise HTTPException(413, "Log file larger than 50 MB; split it or import the relevant window")
    imp = A.import_text(db, s, Path(file.filename or "log").name, raw, user.username, year)
    if imp.events == 0:
        db.rollback()
        raise HTTPException(422, f"No events recognised ({imp.lines} lines, detected format '{imp.detected_format}'). "
                                 "Choose the format explicitly on the source.")
    audit(db, user, "log_import", "log_source", s.id, project_id=s.project_id,
          summary=f"Imported {imp.filename}: {imp.events} events ({imp.detected_format}, {imp.unparsed} unparsed)", request=request)
    db.commit()
    return to_dict(imp)


@router.delete("/log-imports/{iid}")
def delete_import(iid: int, request: Request, user: M.User = Depends(require("debug.write")), db: Session = Depends(get_db)):
    imp = db.get(M.LogImport, iid)
    if not imp:
        raise HTTPException(404, "Import not found")
    s = _source(db, user, imp.source_id)
    n = db.query(M.LogEvent).filter_by(import_id=iid).delete()
    audit(db, user, "log_import_delete", "log_source", s.id, project_id=s.project_id,
          summary=f"Removed import {imp.filename} ({n} events)", request=request)
    db.delete(imp)
    db.commit()
    return {"ok": True, "events_removed": n}


@router.post("/log-sources/{sid}/align")
def align(sid: int, body: AlignIn, request: Request, user: M.User = Depends(require("debug.write")),
          db: Session = Depends(get_db)):
    """Timestamp synchronisation: shift this source so `event_id` coincides with `reference_event_id`."""
    s = _source(db, user, sid)
    e, ref = db.get(M.LogEvent, body.event_id), db.get(M.LogEvent, body.reference_event_id)
    if not e or e.source_id != s.id:
        raise HTTPException(422, "event_id must belong to this source")
    if not ref or ref.project_id != s.project_id or ref.source_id == s.id:
        raise HTTPException(422, "reference_event_id must be an event of another source in the same project")
    s.clock_offset_ms = round((ref.ts - e.ts_raw).total_seconds() * 1000, 3)
    n = A.resync(db, s)
    audit(db, user, "log_align", "log_source", s.id, project_id=s.project_id,
          summary=f"'{s.name}' aligned to event #{ref.id}: offset {s.clock_offset_ms} ms ({n} events)", request=request)
    db.commit()
    return to_dict(s) | {"resynced": n}


@router.post("/projects/{pid}/logs/collect")
def collect(pid: int, request: Request, user: M.User = Depends(require("debug.write")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    r = A.collect_internal(db, pid)
    audit(db, user, "log_collect", "project", pid, project_id=pid, summary=f"Collected {r['total']} internal event(s)", request=request)
    db.commit()
    return r


@router.post("/projects/{pid}/logs/anomalies")
def anomalies(pid: int, request: Request, outlier_k: float = Query(6.0, ge=2, le=20),
              gap_factor: float = Query(3.0, ge=1.5, le=50), user: M.User = Depends(require("debug.write")),
              db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    r = A.detect_anomalies(db, pid, outlier_k, gap_factor)
    audit(db, user, "log_anomalies", "project", pid, project_id=pid, summary=f"Anomaly detection: {r['anomalies']} finding(s)",
          request=request)
    db.commit()
    return r


# ---------------------------------------------------------------- events
def _filtered(db: Session, pid: int, source_ids: str | None, levels: str | None, categories: str | None,
              component: str | None, q: str | None, start: datetime | None, end: datetime | None, fingerprint: str | None):
    qry = db.query(M.LogEvent).filter(M.LogEvent.project_id == pid)
    if source_ids:
        qry = qry.filter(M.LogEvent.source_id.in_([int(x) for x in source_ids.split(",") if x.strip().isdigit()]))
    if levels:
        qry = qry.filter(M.LogEvent.level.in_(levels.split(",")))
    if categories:
        qry = qry.filter(M.LogEvent.category.in_(categories.split(",")))
    if component:
        qry = qry.filter(M.LogEvent.component.ilike(f"%{component}%"))
    if q:
        qry = qry.filter(M.LogEvent.message.ilike(f"%{q}%"))
    if start:
        qry = qry.filter(M.LogEvent.ts >= start)
    if end:
        qry = qry.filter(M.LogEvent.ts <= end)
    if fingerprint:
        qry = qry.filter(M.LogEvent.fingerprint == fingerprint)
    return qry


def _ev(e: M.LogEvent, names: dict) -> dict:
    return {"id": e.id, "ts": e.ts.isoformat(timespec="milliseconds"), "ts_raw": e.ts_raw.isoformat(timespec="milliseconds"),
            "level": e.level, "category": e.category, "component": e.component, "source_id": e.source_id,
            "source": names.get(e.source_id), "message": e.message, "fields": e.fields, "fingerprint": e.fingerprint,
            "template": e.template, "ref": e.ref}


def _names(db: Session, pid: int) -> dict:
    return {s.id: s.name for s in db.query(M.LogSource).filter_by(project_id=pid)}


@router.get("/projects/{pid}/events")
def events(pid: int, source_ids: str | None = None, levels: str | None = None, categories: str | None = None,
           component: str | None = None, q: str | None = None, start: datetime | None = None, end: datetime | None = None,
           fingerprint: str | None = None, limit: int = Query(200, le=2000), offset: int = 0,
           order: str = Query("desc", pattern="^(asc|desc)$"), user: M.User = Depends(require("internal.view")),
           db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    qry = _filtered(db, pid, source_ids, levels, categories, component, q, start, end, fingerprint)
    total = qry.count()
    col = M.LogEvent.ts.asc() if order == "asc" else M.LogEvent.ts.desc()
    names = _names(db, pid)
    return {"total": total, "events": [_ev(e, names) for e in qry.order_by(col, M.LogEvent.id).offset(offset).limit(limit)]}


@router.get("/projects/{pid}/events/facets")
def facets(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    base = db.query(M.LogEvent).filter(M.LogEvent.project_id == pid)
    g = lambda col: dict(base.with_entities(col, func.count(M.LogEvent.id)).group_by(col).all())  # noqa: E731
    a, b = base.with_entities(func.min(M.LogEvent.ts), func.max(M.LogEvent.ts)).one()
    return {"levels": g(M.LogEvent.level), "categories": g(M.LogEvent.category), "sources": g(M.LogEvent.source_id),
            "total": base.count(), "first": a.isoformat() if a else None, "last": b.isoformat() if b else None}


@router.get("/projects/{pid}/events/timeline")
def timeline(pid: int, start: datetime | None = None, end: datetime | None = None, source_ids: str | None = None,
             levels: str | None = None, categories: str | None = None, q: str | None = None,
             buckets: int = Query(120, ge=10, le=600), max_points: int = Query(4000, le=20000),
             user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    """Histogram by level plus a point set for the cross-component swim-lane chart (warnings and above preferred)."""
    get_project_or_404(db, user, pid)
    qry = _filtered(db, pid, source_ids, levels, categories, None, q, start, end, None)
    rows = qry.with_entities(M.LogEvent.id, M.LogEvent.ts, M.LogEvent.level, M.LogEvent.source_id, M.LogEvent.component,
                             M.LogEvent.message, M.LogEvent.category).order_by(M.LogEvent.ts).all()
    if not rows:
        return {"buckets": [], "points": [], "lanes": []}
    t0, t1 = rows[0][1], rows[-1][1]
    width = max((t1 - t0).total_seconds() / buckets, 0.001)
    hist: dict[int, dict] = {}
    for _, ts, lvl, *_ in rows:
        i = min(int((ts - t0).total_seconds() / width), buckets - 1)
        hist.setdefault(i, {l: 0 for l in M.LEVELS})[lvl] += 1
    out_b = [{"start": (t0 + timedelta(seconds=i * width)).isoformat(timespec="milliseconds"), **hist[i]} for i in sorted(hist)]
    pts = sorted(rows, key=lambda r: -A.LEVEL_ORDER[r[2]])[:max_points]
    names = _names(db, pid)
    lanes = sorted({r[3] for r in rows}, key=lambda s: names.get(s, ""))
    return {"bucket_s": round(width, 3), "buckets": out_b, "lanes": [{"source_id": s, "name": names.get(s)} for s in lanes],
            "points": [{"id": r[0], "ts": r[1].isoformat(timespec="milliseconds"), "level": r[2], "source_id": r[3],
                        "component": r[4], "message": r[5][:160], "category": r[6]} for r in sorted(pts, key=lambda r: r[1])],
            "truncated": len(rows) > max_points}


@router.get("/events/{eid}")
def event_detail(eid: int, context: int = Query(15, le=100), user: M.User = Depends(require("internal.view")),
                 db: Session = Depends(get_db)):
    e = db.get(M.LogEvent, eid)
    if not e:
        raise HTTPException(404, "Event not found")
    get_project_or_404(db, user, e.project_id)
    names = _names(db, e.project_id)
    before = (db.query(M.LogEvent).filter(M.LogEvent.source_id == e.source_id, M.LogEvent.ts <= e.ts, M.LogEvent.id != e.id)
              .order_by(M.LogEvent.ts.desc(), M.LogEvent.id.desc()).limit(context).all())
    after = (db.query(M.LogEvent).filter(M.LogEvent.source_id == e.source_id, M.LogEvent.ts >= e.ts, M.LogEvent.id != e.id)
             .order_by(M.LogEvent.ts, M.LogEvent.id).limit(context).all())
    same = db.query(func.count(M.LogEvent.id)).filter_by(project_id=e.project_id, fingerprint=e.fingerprint).scalar()
    return _ev(e, names) | {"context_before": [_ev(x, names) for x in reversed(before)],
                            "context_after": [_ev(x, names) for x in after], "same_template_count": same}


@router.get("/events/{eid}/correlate")
def correlate(eid: int, before_s: float = Query(30, gt=0, le=3600), after_s: float = Query(5, ge=0, le=3600),
              user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    e = db.get(M.LogEvent, eid)
    if not e:
        raise HTTPException(404, "Event not found")
    get_project_or_404(db, user, e.project_id)
    names = _names(db, e.project_id)
    rows = A.window_events(db, e, before_s, after_s)
    for r in rows:
        r["source"] = names.get(r["source_id"])
    pre = A.precursors(db, e.project_id, e.fingerprint, window_s=before_s)
    for c in pre["candidates"]:
        c["source"] = names.get(c["source_id"])
    return {"anchor": _ev(e, names), "window": rows, "precursors": pre}


@router.get("/projects/{pid}/incidents")
def incidents(pid: int, gap_s: float = Query(2.0, gt=0, le=600), min_level: str = Query("warning", pattern="^(warning|error|critical)$"),
              user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    names = _names(db, pid)
    out = A.clusters(db, pid, gap_s, min_level)
    for c in out:
        c["source_names"] = [names.get(s) for s in c["sources"]]
    return out


# ---------------------------------------------------------------- issues / RCA
def _issue(db: Session, user: M.User, iid: int) -> M.Issue:
    i = db.get(M.Issue, iid)
    if not i:
        raise HTTPException(404, "Issue not found")
    get_project_or_404(db, user, i.project_id)
    return i


def issue_out(db: Session, i: M.Issue, full: bool = False) -> dict:
    d = to_dict(i)
    d["hypotheses_count"] = db.query(func.count(M.IssueHypothesis.id)).filter_by(issue_id=i.id).scalar()
    if full:
        names = _names(db, i.project_id)
        evs = db.query(M.LogEvent).filter(M.LogEvent.id.in_(i.pinned_event_ids or [-1])).order_by(M.LogEvent.ts).all()
        d["pinned_events"] = [_ev(e, names) for e in evs]
        d["hypotheses"] = [to_dict(h) for h in db.query(M.IssueHypothesis).filter_by(issue_id=i.id).order_by(M.IssueHypothesis.id)]
        d["attachments"] = [to_dict(a) for a in db.query(M.IssueAttachment).filter_by(issue_id=i.id)]
        run = db.get(M.TestRun, i.retest_run_id) if i.retest_run_id else None
        d["retest_run"] = {"id": run.id, "status": run.status, "environment": run.environment, "approved_by": run.approved_by,
                           "name": run.name} if run else None
        d["close_check"] = close_check(db, i)
    return d


def close_check(db: Session, i: M.Issue) -> dict:
    reasons = []
    if not i.confirmed_root_cause:
        reasons.append("confirmed root cause missing")
    if not db.query(M.IssueHypothesis.id).filter_by(issue_id=i.id, status="confirmed").first():
        reasons.append("no hypothesis confirmed with verification evidence")
    if not i.corrective_action:
        reasons.append("corrective action missing")
    run = db.get(M.TestRun, i.retest_run_id) if i.retest_run_id else None
    if run is not None:
        if run.status != "passed" or not run.approved_by:
            reasons.append(f"retest run #{run.id} is {run.status}{'' if run.approved_by else ' and not approved'}")
    elif i.severity == "critical":
        reasons.append("critical issues need an approved, passing retest run")
    elif not i.retest_result:
        reasons.append("retest result missing (link an approved retest run or describe the retest)")
    return {"can_close": not reasons, "reasons": reasons}


@router.get("/projects/{pid}/issues")
def list_issues(pid: int, status: str | None = None, user: M.User = Depends(require("internal.view")),
                db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    q = db.query(M.Issue).filter_by(project_id=pid).order_by(M.Issue.id.desc())
    if status:
        q = q.filter(M.Issue.status == status)
    return [issue_out(db, i) for i in q]


@router.post("/projects/{pid}/issues", status_code=201)
def create_issue(pid: int, body: IssueIn, request: Request, user: M.User = Depends(require("issues.write")),
                 db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    data = body.model_dump(exclude={"event_id", "test_result_id", "connection_id", "requirement_ids"})
    links, pins, window = [], [], (None, None)
    if body.event_id:
        e = db.get(M.LogEvent, body.event_id)
        if not e or e.project_id != pid:
            raise HTTPException(422, "event_id: not an event of this project")
        pins.append(e.id)
        window = (e.ts - timedelta(seconds=60), e.ts + timedelta(seconds=10))
        data["actual_behaviour"] = data["actual_behaviour"] or f"[{e.ts.isoformat(timespec='milliseconds')}] {e.component or ''}: {e.message[:500]}"
        data["affected_subsystem"] = data["affected_subsystem"] or e.component
    if body.test_result_id:
        r = db.get(M.TestResult, body.test_result_id)
        run = db.get(M.TestRun, r.run_id) if r else None
        if not r or run.project_id != pid:
            raise HTTPException(422, "test_result_id: not a result of this project")
        tc = db.get(M.TestCase, r.test_case_id)
        links.append({"type": "test_result", "id": r.id, "label": f"Run #{run.id} {tc.ref} {r.status} ({run.environment})"})
        data["expected_behaviour"] = data["expected_behaviour"] or tc.expected_output
        data["actual_behaviour"] = data["actual_behaviour"] or r.actual_output
        data["reproduction_steps"] = data["reproduction_steps"] or tc.procedure
        if run.integration_config_id and not data["integration_config_id"]:
            data["integration_config_id"] = run.integration_config_id
        t = r.executed_at or run.started_at
        window = (t - timedelta(seconds=120), t + timedelta(seconds=10))
    if body.connection_id:
        cn = db.get(M.ArchConnection, body.connection_id)
        am = db.get(M.ArchModel, cn.model_id) if cn else None
        if not cn or am.project_id != pid:
            raise HTTPException(422, "connection_id: not an interface of this project")
        links.append({"type": "interface", "id": cn.id, "label": f"{am.name}: {cn.key} ({cn.interface_type})"})
    if body.site_id:
        st = db.get(M.Site, body.site_id)
        if not st or st.project_id != pid:
            raise HTTPException(422, "site_id: not a site of this project")
        links.append({"type": "site", "id": st.id, "label": f"Site {st.name}"})
        data["affected_subsystem"] = data["affected_subsystem"] or f"Customer site {st.name}"
    for rid in body.requirement_ids:
        rq = db.get(M.Requirement, rid)
        if not rq or rq.project_id != pid:
            raise HTTPException(422, f"Requirement {rid} not in this project")
        links.append({"type": "requirement", "id": rq.id, "label": f"{rq.ref} {rq.title}"})
    cfg = db.get(M.IntegrationConfig, data["integration_config_id"]) if data.get("integration_config_id") else None
    if cfg:
        data["hardware_revision"] = data["hardware_revision"] or "; ".join(
            f"{x['label']} HW {x.get('hardware_revision') or '-'} FW {x.get('firmware_version') or '-'}" for x in cfg.items if x["type"] == "hardware")
        data["software_revision"] = data["software_revision"] or "; ".join(
            f"{x['label']} {x.get('version')}" + (f" ({x['commit_ref']})" if x.get("commit_ref") else "") for x in cfg.items if x["type"] == "software")
    nums = [int(m.group(1)) for (r,) in db.query(M.Issue.ref).filter_by(project_id=pid) if (m := re.fullmatch(r"ISS-(\d+)", r))]
    i = M.Issue(project_id=pid, ref=f"ISS-{(max(nums) + 1 if nums else 1):03d}", created_by=user.username, links=links,
                pinned_event_ids=pins, window_start=window[0], window_end=window[1], **data)
    db.add(i)
    db.flush()
    record_revision(db, "issue", i, user.username, "Created")
    audit(db, user, "issue_create", "issue", i.id, project_id=pid, summary=f"{p.code} {i.ref} [{i.severity}] {i.title}", request=request)
    db.commit()
    return issue_out(db, i, full=True)


@router.get("/issues/{iid}")
def get_issue(iid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return issue_out(db, _issue(db, user, iid), full=True)


@router.patch("/issues/{iid}")
def patch_issue(iid: int, body: IssuePatch, request: Request, user: M.User = Depends(require("issues.write")),
                db: Session = Depends(get_db)):
    i = _issue(db, user, iid)
    if i.status in ("closed", "rejected"):
        raise HTTPException(409, f"Issue is {i.status}; reopen it first")
    ch = body.model_dump(exclude_unset=True)
    if "confirmed_root_cause" in ch and ch["confirmed_root_cause"] != i.confirmed_root_cause:
        if not can(user, "issues.confirm"):
            raise HTTPException(403, "Only engineers can record a confirmed root cause")
        i.root_cause_confirmed_by = user.username
    if ch.get("retest_run_id"):
        run = db.get(M.TestRun, ch["retest_run_id"])
        if not run or run.project_id != i.project_id:
            raise HTTPException(422, "retest_run_id: not a run of this project")
    for k, v in ch.items():
        setattr(i, k, v)
    db.flush()
    rev = record_revision(db, "issue", i, user.username)
    audit(db, user, "issue_update", "issue", i.id, project_id=i.project_id,
          summary=f"{i.ref} updated ({', '.join(rev.changed_fields) if rev else 'no change'})", request=request)
    db.commit()
    return issue_out(db, i, full=True)


ORDER = {s: n for n, s in enumerate(["open", "investigating", "root_cause_identified", "corrective_action", "retest", "closed"])}


@router.post("/issues/{iid}/status")
def set_status(iid: int, body: StatusIn, request: Request, user: M.User = Depends(require("issues.write")),
               db: Session = Depends(get_db)):
    i = _issue(db, user, iid)
    new, old = body.status, i.status
    if new == old:
        raise HTTPException(409, f"Issue is already {old}")
    if new == "rejected":
        if not body.note:
            raise HTTPException(422, "Rejecting needs a note (duplicate, not a defect, cannot reproduce …)")
    elif new == "closed":
        if not can(user, "issues.close"):
            raise HTTPException(403, "Your role may not close issues")
        chk = close_check(db, i)
        if not chk["can_close"]:
            raise HTTPException(409, {"message": f"{i.ref} cannot be closed", "reasons": chk["reasons"]})
        i.closed_by, i.closed_at = user.username, M.utcnow()
    elif old in ("closed", "rejected"):
        if new not in ("open", "investigating") or not body.note:
            raise HTTPException(422, "Reopen to 'open' or 'investigating' with a note")
        i.closed_by = i.closed_at = None
    else:
        if ORDER.get(new, 0) >= ORDER["root_cause_identified"]:
            if not i.confirmed_root_cause or not db.query(M.IssueHypothesis.id).filter_by(issue_id=i.id, status="confirmed").first():
                raise HTTPException(409, "A confirmed root cause and at least one confirmed hypothesis are required")
        if ORDER.get(new, 0) >= ORDER["corrective_action"] and not (i.corrective_action and i.corrective_owner):
            raise HTTPException(409, "Corrective action and its owner are required")
    i.status = new
    db.flush()
    record_revision(db, "issue", i, user.username, f"Status {old} -> {new}: {body.note or ''}")
    audit(db, user, "issue_status", "issue", i.id, project_id=i.project_id, summary=f"{i.ref}: {old} -> {new}",
          detail={"note": body.note}, request=request)
    db.commit()
    return issue_out(db, i, full=True)


@router.put("/issues/{iid}/events")
def pin_events(iid: int, body: PinIn, user: M.User = Depends(require("issues.write")), db: Session = Depends(get_db)):
    i = _issue(db, user, iid)
    ids = set(i.pinned_event_ids or [])
    for eid in body.add:
        e = db.get(M.LogEvent, eid)
        if not e or e.project_id != i.project_id:
            raise HTTPException(422, f"Event {eid} is not in this project")
        ids.add(eid)
    ids -= set(body.remove)
    i.pinned_event_ids = sorted(ids)
    db.commit()
    return issue_out(db, i, full=True)


@router.post("/issues/{iid}/hypotheses", status_code=201)
def add_hypothesis(iid: int, body: HypothesisIn, user: M.User = Depends(require("issues.write")), db: Session = Depends(get_db)):
    i = _issue(db, user, iid)
    h = M.IssueHypothesis(issue_id=i.id, text=body.text, origin="engineer", created_by=user.username)
    db.add(h)
    db.commit()
    return to_dict(h)


@router.post("/issues/{iid}/suggest")
def suggest(iid: int, request: Request, window_s: float = Query(30, gt=0, le=3600),
            user: M.User = Depends(require("issues.write")), db: Session = Depends(get_db)):
    """Add correlation-based candidate causes (status 'proposed', origin 'correlation') from the pinned events."""
    i = _issue(db, user, iid)
    if not i.pinned_event_ids:
        raise HTTPException(409, "Pin at least one failure event to the issue first")
    names = _names(db, i.project_id)
    existing = {h.support.get("fingerprint") for h in db.query(M.IssueHypothesis).filter_by(issue_id=i.id) if h.support}
    added = []
    for eid in i.pinned_event_ids:
        e = db.get(M.LogEvent, eid)
        if not e or e.level not in ("warning", "error", "critical"):
            continue
        pre = A.precursors(db, i.project_id, e.fingerprint, window_s=window_s)
        for c in pre["candidates"][:5]:
            if c["fingerprint"] in existing:
                continue
            existing.add(c["fingerprint"])
            text = (f"'{c['template'][:160]}' ({names.get(c['source_id'])}) precedes '{pre['template'][:120]}' in "
                    f"{c['support'] * 100:.0f} % of {pre['occurrences']} occurrence(s), {c['lift']}x more often than chance, "
                    f"median lead {c['median_lead_s']} s")
            h = M.IssueHypothesis(issue_id=i.id, text=text, origin="correlation", created_by="integra-correlation",
                                  support=c | {"target": e.fingerprint, "window_s": window_s})
            db.add(h)
            added.append(text)
    audit(db, user, "issue_suggest", "issue", i.id, project_id=i.project_id, summary=f"{i.ref}: {len(added)} correlation suggestion(s)")
    db.commit()
    return {"added": len(added), "suggestions": added,
            "note": "Suggestions are statistical; an engineer must confirm or reject each with verification evidence."}


@router.post("/hypotheses/{hid}/decision")
def decide(hid: int, body: DecisionIn, request: Request, user: M.User = Depends(require("issues.confirm")),
           db: Session = Depends(get_db)):
    h = db.get(M.IssueHypothesis, hid)
    if not h:
        raise HTTPException(404, "Hypothesis not found")
    i = _issue(db, user, h.issue_id)
    h.status, h.verification, h.decided_by, h.decided_at = body.status, body.verification, user.username, M.utcnow()
    audit(db, user, f"hypothesis_{body.status}", "issue", i.id, project_id=i.project_id,
          summary=f"{i.ref}: hypothesis #{h.id} {body.status}", detail={"verification": body.verification}, request=request)
    db.commit()
    return to_dict(h)


# ---------------------------------------------------------------- attachments
def _att_dir() -> Path:
    d = config.settings.data_dir / "attachments"
    d.mkdir(parents=True, exist_ok=True)
    return d


@router.post("/issues/{iid}/attachments", status_code=201)
async def upload_attachment(iid: int, request: Request, file: UploadFile = File(...), description: str | None = Form(None),
                            user: M.User = Depends(require("issues.write")), db: Session = Depends(get_db)):
    i = _issue(db, user, iid)
    raw = await file.read()
    if len(raw) > 25_000_000:
        raise HTTPException(413, "Attachment larger than 25 MB")
    a = M.IssueAttachment(issue_id=i.id, filename=Path(file.filename or "attachment").name[:260], content_type=file.content_type,
                          size=len(raw), sha256=hashlib.sha256(raw).hexdigest(), description=description, uploaded_by=user.username)
    db.add(a)
    db.flush()
    (_att_dir() / str(a.id)).write_bytes(raw)
    audit(db, user, "issue_attachment", "issue", i.id, project_id=i.project_id, summary=f"{i.ref}: attached {a.filename}", request=request)
    db.commit()
    return to_dict(a)


@router.get("/attachments/{aid}")
def download_attachment(aid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    a = db.get(M.IssueAttachment, aid)
    if not a:
        raise HTTPException(404, "Attachment not found")
    _issue(db, user, a.issue_id)
    f = _att_dir() / str(a.id)
    if not f.exists():
        raise HTTPException(410, "Attachment file missing from storage")
    return FileResponse(f, filename=a.filename, media_type="application/octet-stream")
