"""Software integration workspace (Phase 3): host diagnostics, Git repositories (read-only), controlled scripts
(review + approval before execution) and integration configurations (hardware + software baselines)."""
from __future__ import annotations

import hashlib
import os
import platform
import shutil
import stat
import subprocess
import sys
import time
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import Field
from sqlalchemy.orm import Session

from .. import config
from .. import models as M
from ..db import get_db
from ..schemas import In, one_of
from ..security import audit, get_project_or_404, require
from ..services.records import diff, to_dict

router = APIRouter(prefix="/api/v1", tags=["software integration workspace"])


# ---------------------------------------------------------------- host diagnostics (read-only)
def _cmd(args: list[str], timeout: float = 20) -> tuple[int, str]:
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, errors="replace")
        return r.returncode, r.stdout
    except (OSError, subprocess.TimeoutExpired) as e:
        return -1, str(e)


@router.get("/diagnostics/system")
def diag_system(_: M.User = Depends(require("diagnostics.view"))):
    import psutil
    vm, sw = psutil.virtual_memory(), psutil.swap_memory()
    disks = []
    for p in psutil.disk_partitions(all=False):
        try:
            u = psutil.disk_usage(p.mountpoint)
            disks.append({"mount": p.mountpoint, "fs": p.fstype, "total_gb": round(u.total / 1e9, 1),
                          "used_pct": u.percent})
        except OSError:
            continue
    temps = {}
    if hasattr(psutil, "sensors_temperatures"):
        try:
            temps = {k: [round(x.current, 1) for x in v] for k, v in (psutil.sensors_temperatures() or {}).items()}
        except Exception:
            temps = {}
    return {"host": platform.node(), "os": f"{platform.system()} {platform.release()}", "version": platform.version(),
            "machine": platform.machine(), "python": sys.version.split()[0],
            "boot_time": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(psutil.boot_time())),
            "cpu": {"logical": psutil.cpu_count(), "physical": psutil.cpu_count(logical=False),
                    "percent": psutil.cpu_percent(interval=0.3), "per_core": psutil.cpu_percent(interval=None, percpu=True),
                    "load_avg": [round(x, 2) for x in psutil.getloadavg()] if hasattr(psutil, "getloadavg") else None},
            "memory": {"total_gb": round(vm.total / 1e9, 2), "used_pct": vm.percent, "swap_used_pct": sw.percent},
            "disks": disks, "temperatures_c": temps,
            "note": "Diagnostics of the machine running the INTEGRA backend. Remote Linux targets (SSH) are planned."}


@router.get("/diagnostics/processes")
def diag_processes(sort: str = Query("cpu", pattern="^(cpu|memory)$"), limit: int = Query(40, le=300),
                   q: str | None = None, _: M.User = Depends(require("diagnostics.view"))):
    import psutil
    procs = []
    for p in psutil.process_iter(["pid", "name", "username", "cpu_percent", "memory_percent", "status", "num_threads"]):
        i = p.info
        if q and q.lower() not in (i["name"] or "").lower():
            continue
        procs.append({k: (round(v, 2) if isinstance(v, float) else v) for k, v in i.items()})
    key = "cpu_percent" if sort == "cpu" else "memory_percent"
    return sorted(procs, key=lambda x: x[key] or 0, reverse=True)[:limit]


@router.get("/diagnostics/services")
def diag_services(q: str | None = None, _: M.User = Depends(require("diagnostics.view"))):
    out = []
    if platform.system() == "Windows":
        import psutil
        for s in psutil.win_service_iter():
            try:
                d = s.as_dict()
            except Exception:
                continue
            out.append({"name": d["name"], "display": d["display_name"], "status": d["status"],
                        "start": d["start_type"]})
    elif shutil.which("systemctl"):
        rc, txt = _cmd(["systemctl", "list-units", "--type=service", "--all", "--no-pager", "--plain", "--no-legend"])
        for line in txt.splitlines():
            parts = line.split(None, 4)
            if len(parts) >= 4:
                out.append({"name": parts[0], "display": parts[4] if len(parts) > 4 else "", "status": parts[3],
                            "start": parts[2]})
    if q:
        out = [s for s in out if q.lower() in f"{s['name']} {s['display']}".lower()]
    return out[:500]


@router.get("/diagnostics/drivers")
def diag_drivers(q: str | None = None, _: M.User = Depends(require("diagnostics.view"))):
    out = []
    if platform.system() == "Windows":
        rc, txt = _cmd(["driverquery", "/fo", "csv", "/nh"], timeout=40)
        import csv
        import io
        for row in csv.reader(io.StringIO(txt)):
            if len(row) >= 4:
                out.append({"name": row[0], "display": row[1], "type": row[2], "date": row[3]})
    elif shutil.which("lsmod"):
        rc, txt = _cmd(["lsmod"])
        for line in txt.splitlines()[1:]:
            p = line.split()
            if len(p) >= 3:
                out.append({"name": p[0], "display": f"size {p[1]}", "type": "kernel module", "date": f"used by {p[2]}"})
    if q:
        out = [d for d in out if q.lower() in f"{d['name']} {d['display']}".lower()]
    return out[:800]


@router.get("/diagnostics/permissions")
def diag_permissions(path: str, _: M.User = Depends(require("diagnostics.view"))):
    p = Path(path)
    if not p.exists():
        raise HTTPException(404, "Path does not exist on the backend host")
    st = p.stat()
    out = {"path": str(p.resolve()), "type": "directory" if p.is_dir() else "file", "mode": stat.filemode(st.st_mode),
           "octal": oct(st.st_mode & 0o7777), "size": st.st_size,
           "modified": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(st.st_mtime)),
           "readable": os.access(p, os.R_OK), "writable": os.access(p, os.W_OK), "executable": os.access(p, os.X_OK)}
    if platform.system() == "Windows":
        rc, txt = _cmd(["icacls", str(p)])
        out["acl"] = txt.strip().splitlines()[:30]
    else:
        import grp
        import pwd
        out["owner"], out["group"] = pwd.getpwuid(st.st_uid).pw_name, grp.getgrgid(st.st_gid).gr_name
    return out


# ---------------------------------------------------------------- Git (read-only)
GIT_READONLY = {"rev-parse", "branch", "log", "tag", "status", "ls-remote", "cat-file", "remote", "show"}


def git(args: list[str], cwd: str | None = None, timeout: float = 20) -> str:
    if args[0] not in GIT_READONLY:
        raise HTTPException(400, f"git {args[0]} is not an allowed read-only command")
    exe = shutil.which("git")
    if not exe:
        raise HTTPException(409, "git is not installed on the backend host")
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0"}
    r = subprocess.run([exe, *(["-C", cwd] if cwd else []), *args], capture_output=True, text=True, timeout=timeout,
                       env=env, errors="replace")
    if r.returncode != 0:
        raise HTTPException(409, f"git {args[0]} failed: {r.stderr.strip()[:300]}")
    return r.stdout


class RepoIn(In):
    name: Annotated[str, Field(min_length=1, max_length=160)]
    path: str | None = None
    remote_url: str | None = None
    project_id: int | None = None


@router.get("/repos")
def list_repos(_: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return [to_dict(r) for r in db.query(M.Repository).order_by(M.Repository.name)]


@router.post("/repos", status_code=201)
def add_repo(body: RepoIn, request: Request, user: M.User = Depends(require("software.write")),
             db: Session = Depends(get_db)):
    if not body.path and not body.remote_url:
        raise HTTPException(422, "Provide a local working-copy path or a remote URL")
    branch = None
    if body.path:
        if not Path(body.path).is_dir():
            raise HTTPException(422, "path: directory does not exist on the backend host")
        top = git(["rev-parse", "--show-toplevel"], body.path).strip()
        branch = git(["rev-parse", "--abbrev-ref", "HEAD"], body.path).strip()
        body.path = top
    elif body.remote_url:
        if not body.remote_url.startswith(("https://", "ssh://", "git@")):
            raise HTTPException(422, "remote_url must be https://, ssh:// or git@")
        out = git(["ls-remote", "--symref", body.remote_url, "HEAD"], timeout=30)
        branch = next((ln.split()[1].removeprefix("refs/heads/") for ln in out.splitlines() if ln.startswith("ref:")), None)
    if body.project_id:
        get_project_or_404(db, user, body.project_id)
    r = M.Repository(name=body.name, path=body.path, remote_url=body.remote_url, project_id=body.project_id,
                     default_branch=branch, registered_by=user.username)
    db.add(r)
    db.flush()
    audit(db, user, "repo_register", "repository", r.id, project_id=body.project_id,
          summary=f"Registered repository {r.name}", request=request)
    db.commit()
    return to_dict(r)


def _repo(db: Session, rid: int) -> M.Repository:
    r = db.get(M.Repository, rid)
    if not r:
        raise HTTPException(404, "Repository not found")
    return r


@router.get("/repos/{rid}/summary")
def repo_summary(rid: int, limit: int = Query(30, le=200), _: M.User = Depends(require("internal.view")),
                 db: Session = Depends(get_db)):
    r = _repo(db, rid)
    if not r.path:
        out = git(["ls-remote", "--heads", "--tags", r.remote_url], timeout=30)
        refs = [ln.split("\t")[1] for ln in out.splitlines() if "\t" in ln]
        return {"repository": to_dict(r), "mode": "remote (ls-remote)",
                "branches": [x.removeprefix("refs/heads/") for x in refs if x.startswith("refs/heads/")],
                "tags": [x.removeprefix("refs/tags/") for x in refs if x.startswith("refs/tags/") and not x.endswith("^{}")],
                "commits": [], "head": None, "dirty": None}
    sep = "\x1f"
    log = git(["log", f"-{limit}", f"--format=%H{sep}%h{sep}%an{sep}%aI{sep}%s{sep}%D"], r.path)
    commits = []
    for ln in log.splitlines():
        p = ln.split(sep)
        if len(p) >= 5:
            commits.append({"sha": p[0], "short": p[1], "author": p[2], "date": p[3], "subject": p[4],
                            "refs": p[5] if len(p) > 5 else ""})
    status = git(["status", "--porcelain"], r.path)
    return {"repository": to_dict(r), "mode": "local working copy",
            "head": git(["rev-parse", "HEAD"], r.path).strip(),
            "branch": git(["rev-parse", "--abbrev-ref", "HEAD"], r.path).strip(),
            "branches": [b.strip() for b in git(["branch", "-a", "--format=%(refname:short)"], r.path).splitlines() if b.strip()],
            "tags": [t for t in git(["tag", "--sort=-creatordate"], r.path).splitlines() if t][:100],
            "commits": commits, "dirty": bool(status.strip()), "changed_files": len(status.splitlines())}


@router.get("/repos/{rid}/verify")
def verify_ref(rid: int, ref: str = Query(..., min_length=1, max_length=100), _: M.User = Depends(require("internal.view")),
               db: Session = Depends(get_db)):
    """Does a commit/tag exist in the repository? (used to check a software item's commit_ref)"""
    r = _repo(db, rid)
    if not r.path:
        raise HTTPException(409, "Commit verification needs a local working copy")
    if ref.startswith("-"):
        raise HTTPException(422, "Invalid ref")
    try:
        sha = git(["rev-parse", "--verify", "--quiet", f"{ref}^{{commit}}"], r.path).strip()
        subj = git(["log", "-1", "--format=%s (%aI)", sha], r.path).strip()
        return {"ref": ref, "exists": True, "sha": sha, "subject": subj}
    except HTTPException:
        return {"ref": ref, "exists": False}


# ---------------------------------------------------------------- controlled scripts
EXT = {"bash": ".sh", "python": ".py", "powershell": ".ps1"}


def interpreter(lang: str) -> list[str] | None:
    if lang == "bash":
        b = shutil.which("bash")
        return [b] if b else None
    if lang == "python":
        if not getattr(sys, "frozen", False):
            return [sys.executable]
        p = shutil.which("python") or shutil.which("python3")
        return [p] if p else None
    if lang == "powershell":
        p = shutil.which("pwsh") or shutil.which("powershell")
        return [p, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File"] if p else None
    return None


def _sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


class ScriptIn(In):
    name: Annotated[str, Field(pattern=r"^[A-Za-z0-9_.-]{1,160}$")]
    language: Annotated[str, one_of(M.SCRIPT_LANGS)]
    description: str | None = None
    content: Annotated[str, Field(min_length=1, max_length=200_000)]
    project_id: int | None = None


class ScriptPatch(In):
    description: str | None = None
    content: Annotated[str, Field(min_length=1, max_length=200_000)] | None = None


class RunIn(In):
    args: list[Annotated[str, Field(max_length=200)]] = Field(default_factory=list, max_length=20)
    timeout_s: Annotated[int, Field(ge=1, le=300)] = 60
    confirm: bool = False


def _script_out(s: M.Script) -> dict:
    d = to_dict(s)
    d["runnable"] = s.status == "approved" and s.approved_sha256 == _sha(s.content)
    d["interpreter_available"] = interpreter(s.language) is not None
    return d


@router.get("/scripts")
def list_scripts(_: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return [_script_out(s) for s in db.query(M.Script).order_by(M.Script.name)]


@router.get("/scripts/interpreters")
def interpreters(_: M.User = Depends(require("internal.view"))):
    return {k: (interpreter(k) or [None])[0] for k in M.SCRIPT_LANGS}


@router.post("/scripts", status_code=201)
def create_script(body: ScriptIn, request: Request, user: M.User = Depends(require("scripts.write")),
                  db: Session = Depends(get_db)):
    if db.query(M.Script.id).filter_by(name=body.name).first():
        raise HTTPException(409, "A script with this name exists")
    s = M.Script(**body.model_dump(), author=user.username)
    db.add(s)
    db.flush()
    audit(db, user, "script_create", "script", s.id, summary=f"Script {s.name} ({s.language}) drafted", request=request)
    db.commit()
    return _script_out(s)


def _script(db: Session, sid: int) -> M.Script:
    s = db.get(M.Script, sid)
    if not s:
        raise HTTPException(404, "Script not found")
    return s


@router.get("/scripts/{sid}")
def get_script(sid: int, _: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    s = _script(db, sid)
    runs = [to_dict(r, exclude={"stdout", "stderr"}) for r in
            db.query(M.ScriptRun).filter_by(script_id=sid).order_by(M.ScriptRun.id.desc()).limit(20)]
    return _script_out(s) | {"runs": runs}


@router.patch("/scripts/{sid}")
def edit_script(sid: int, body: ScriptPatch, request: Request, user: M.User = Depends(require("scripts.write")),
                db: Session = Depends(get_db)):
    s = _script(db, sid)
    ch = body.model_dump(exclude_unset=True)
    if "content" in ch and ch["content"] != s.content:
        s.content, s.version = ch["content"], s.version + 1
        s.status, s.approved_by, s.approved_at, s.approved_sha256 = "draft", None, None, None  # needs a new review
    if "description" in ch:
        s.description = ch["description"]
    audit(db, user, "script_edit", "script", s.id, summary=f"Script {s.name} v{s.version} edited (back to draft)",
          request=request)
    db.commit()
    return _script_out(s)


@router.post("/scripts/{sid}/approve")
def approve_script(sid: int, request: Request, user: M.User = Depends(require("scripts.approve")),
                   db: Session = Depends(get_db)):
    s = _script(db, sid)
    if s.author == user.username:
        raise HTTPException(403, "Four-eyes rule: the author cannot approve their own script")
    if s.status == "approved" and s.approved_sha256 == _sha(s.content):
        raise HTTPException(409, "Already approved")
    s.status, s.approved_by, s.approved_at, s.approved_sha256 = "approved", user.username, M.utcnow(), _sha(s.content)
    audit(db, user, "script_approve", "script", s.id, summary=f"Approved {s.name} v{s.version} sha256 {s.approved_sha256[:12]}",
          request=request)
    db.commit()
    return _script_out(s)


@router.post("/scripts/{sid}/run")
def run_script(sid: int, body: RunIn, request: Request, user: M.User = Depends(require("scripts.run")),
               db: Session = Depends(get_db)):
    s = _script(db, sid)
    if not body.confirm:
        raise HTTPException(400, "Execution must be explicitly confirmed (confirm=true)")
    if s.status != "approved" or s.approved_sha256 != _sha(s.content):
        raise HTTPException(409, "Only an approved, unmodified script can run")
    interp = interpreter(s.language)
    if not interp:
        raise HTTPException(409, f"No {s.language} interpreter on the backend host")
    run = M.ScriptRun(script_id=s.id, version=s.version, sha256=s.approved_sha256, args=body.args,
                      interpreter=" ".join(interp), started_by=user.username)
    db.add(run)
    db.flush()
    wd = config.settings.data_dir / "runs" / str(run.id)
    wd.mkdir(parents=True, exist_ok=True)
    f = wd / f"script{EXT[s.language]}"
    f.write_text(s.content, encoding="utf-8", newline="\n")
    keep = {k: v for k, v in os.environ.items() if k.upper() in
            ("PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "HOME", "USERPROFILE", "LANG", "COMSPEC", "PATHEXT")}
    env = keep | {"INTEGRA_RUN_ID": str(run.id), "PYTHONIOENCODING": "utf-8"}
    t0 = time.time()
    try:
        r = subprocess.run([*interp, str(f), *body.args], cwd=wd, env=env, capture_output=True, text=True,
                           timeout=body.timeout_s, errors="replace")
        run.exit_code, run.stdout, run.stderr = r.returncode, r.stdout[-200_000:], r.stderr[-200_000:]
    except subprocess.TimeoutExpired as e:
        run.timed_out, run.exit_code = True, None
        run.stdout = (e.stdout or b"").decode(errors="replace")[-200_000:] if isinstance(e.stdout, bytes) else (e.stdout or "")
        run.stderr = f"Timed out after {body.timeout_s} s"
    run.duration_s = round(time.time() - t0, 3)
    audit(db, user, "script_run", "script", s.id, summary=f"Ran {s.name} v{s.version} -> exit {run.exit_code}"
                                                        + (" (timeout)" if run.timed_out else ""),
          detail={"run_id": run.id, "args": body.args}, request=request)
    db.commit()
    return to_dict(run)


@router.get("/script-runs/{rid}")
def get_run(rid: int, _: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    r = db.get(M.ScriptRun, rid)
    if not r:
        raise HTTPException(404, "Run not found")
    return to_dict(r)


# ---------------------------------------------------------------- integration configurations
class ConfigIn(In):
    name: Annotated[str, Field(min_length=1, max_length=160)]
    description: str | None = None
    hardware_ids: list[int] = []
    software_ids: list[int] = []


def _snapshot_items(db: Session, project: M.Project, hw_ids: list[int], sw_ids: list[int]) -> list[dict]:
    items = []
    for hid in hw_ids:
        h = db.get(M.HardwareItem, hid)
        if not h or h.project_id not in (None, project.id):
            raise HTTPException(422, f"Hardware {hid} not available for {project.code}")
        items.append({"type": "hardware", "id": h.id, "label": f"{h.asset_tag} {h.name}", "model": h.model,
                      "serial_number": h.serial_number, "hardware_revision": h.hardware_revision,
                      "firmware_version": h.firmware_version})
    for sid in sw_ids:
        s = db.get(M.SoftwareItem, sid)
        if not s or s.project_id not in (None, project.id):
            raise HTTPException(422, f"Software {sid} not available for {project.code}")
        items.append({"type": "software", "id": s.id, "label": s.name, "version": s.version, "commit_ref": s.commit_ref})
    return items


def _drift(db: Session, c: M.IntegrationConfig) -> list[dict]:
    """Differences between the recorded configuration and today's inventory records."""
    out = []
    for it in c.items:
        cur = db.get(M.HardwareItem if it["type"] == "hardware" else M.SoftwareItem, it["id"])
        if cur is None:
            out.append({"item": it["label"], "field": "record", "recorded": "present", "current": "deleted"})
            continue
        fields = ("hardware_revision", "firmware_version", "serial_number") if it["type"] == "hardware" \
            else ("version", "commit_ref")
        for f in fields:
            if it.get(f) != getattr(cur, f):
                out.append({"item": it["label"], "field": f, "recorded": it.get(f), "current": getattr(cur, f)})
    return out


def _cfg_out(db: Session, c: M.IntegrationConfig) -> dict:
    return to_dict(c) | {"drift": _drift(db, c)}


@router.get("/projects/{pid}/configs")
def list_configs(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_cfg_out(db, c) for c in db.query(M.IntegrationConfig).filter_by(project_id=pid)
            .order_by(M.IntegrationConfig.id.desc())]


@router.post("/projects/{pid}/configs", status_code=201)
def create_config(pid: int, body: ConfigIn, request: Request, user: M.User = Depends(require("configs.write")),
                  db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    if not body.hardware_ids and not body.software_ids:
        raise HTTPException(422, "Select at least one hardware or software item")
    if db.query(M.IntegrationConfig.id).filter_by(project_id=pid, name=body.name).first():
        raise HTTPException(409, "A configuration with this name exists")
    c = M.IntegrationConfig(project_id=pid, name=body.name, description=body.description, created_by=user.username,
                            items=_snapshot_items(db, p, body.hardware_ids, body.software_ids))
    db.add(c)
    db.flush()
    audit(db, user, "config_create", "integration_config", c.id, project_id=pid,
          summary=f"{p.code}: configuration '{c.name}' ({len(c.items)} items)", request=request)
    db.commit()
    return _cfg_out(db, c)


@router.post("/configs/{cid}/refresh")
def refresh_config(cid: int, request: Request, user: M.User = Depends(require("configs.write")),
                   db: Session = Depends(get_db)):
    c = db.get(M.IntegrationConfig, cid)
    if not c:
        raise HTTPException(404, "Configuration not found")
    if c.status == "frozen":
        raise HTTPException(409, "Frozen configurations are immutable; create a new one")
    p = get_project_or_404(db, user, c.project_id)
    c.items = _snapshot_items(db, p, [i["id"] for i in c.items if i["type"] == "hardware"],
                              [i["id"] for i in c.items if i["type"] == "software"])
    db.commit()
    return _cfg_out(db, c)


@router.post("/configs/{cid}/freeze")
def freeze_config(cid: int, request: Request, user: M.User = Depends(require("configs.freeze")),
                  db: Session = Depends(get_db)):
    c = db.get(M.IntegrationConfig, cid)
    if not c:
        raise HTTPException(404, "Configuration not found")
    get_project_or_404(db, user, c.project_id)
    if c.status == "frozen":
        raise HTTPException(409, "Already frozen")
    if _drift(db, c):
        raise HTTPException(409, "Recorded items differ from the inventory; refresh the configuration first")
    c.status, c.frozen_by, c.frozen_at = "frozen", user.username, M.utcnow()
    audit(db, user, "config_freeze", "integration_config", c.id, project_id=c.project_id,
          summary=f"Froze configuration '{c.name}'", request=request)
    db.commit()
    return _cfg_out(db, c)


@router.get("/configs/compare")
def compare_configs(a: int, b: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    ca, cb = db.get(M.IntegrationConfig, a), db.get(M.IntegrationConfig, b)
    if not ca or not cb:
        raise HTTPException(404, "Configuration not found")
    get_project_or_404(db, user, ca.project_id)
    get_project_or_404(db, user, cb.project_id)
    A = {(i["type"], i["id"]): i for i in ca.items}
    B = {(i["type"], i["id"]): i for i in cb.items}
    return {"from": ca.name, "to": cb.name,
            "added": [B[k]["label"] for k in B.keys() - A.keys()], "removed": [A[k]["label"] for k in A.keys() - B.keys()],
            "changed": [{"item": B[k]["label"], "changes": diff(A[k], B[k])} for k in A.keys() & B.keys() if A[k] != B[k]]}
