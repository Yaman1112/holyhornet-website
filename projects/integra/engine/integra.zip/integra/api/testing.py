"""Test Automation & Validation (Module I) and SIL/HIL execution (Module H): test cases with reviewed pytest code,
suites, runs per environment, manual results, engineer approval -> requirement evidence, SIL vs HIL comparison and
coverage."""
from __future__ import annotations

import re
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import Field
from sqlalchemy.orm import Session

from .. import config
from .. import models as M
from ..db import get_db
from ..schemas import In, one_of
from ..security import audit, check_project_write, get_project_or_404, require
from ..services import testing as T
from ..services.records import to_dict
from .rigs import hil_readiness

router = APIRouter(prefix="/api/v1", tags=["test automation"])


class CaseIn(In):
    ref: Annotated[str, Field(pattern=r"^[A-Za-z0-9_.-]{1,32}$")] | None = None
    name: Annotated[str, Field(min_length=1, max_length=200)]
    description: str | None = None
    objective: str | None = None
    test_type: Annotated[str, one_of(M.TEST_TYPES)] = "integration"
    environments: list[Annotated[str, one_of(M.TEST_ENVS)]] = ["sil"]
    preconditions: str | None = None
    hardware_configuration: str | None = None
    software_configuration: str | None = None
    input_data: str | None = None
    procedure: str | None = None
    expected_output: str | None = None
    acceptance_criteria: str | None = None
    expected_measurements: dict[str, dict[str, Any]] = {}
    automation: Annotated[str, one_of(["manual", "pytest"])] = "manual"
    code: str | None = None
    dbc_id: int | None = None
    scenario_id: int | None = None
    requirement_ids: list[int] = []


class CasePatch(In):
    name: str | None = None
    description: str | None = None
    objective: str | None = None
    test_type: Annotated[str, one_of(M.TEST_TYPES)] | None = None
    environments: list[Annotated[str, one_of(M.TEST_ENVS)]] | None = None
    preconditions: str | None = None
    hardware_configuration: str | None = None
    software_configuration: str | None = None
    input_data: str | None = None
    procedure: str | None = None
    expected_output: str | None = None
    acceptance_criteria: str | None = None
    expected_measurements: dict[str, dict[str, Any]] | None = None
    automation: Annotated[str, one_of(["manual", "pytest"])] | None = None
    code: str | None = None
    dbc_id: int | None = None
    scenario_id: int | None = None


class SuiteIn(In):
    name: Annotated[str, Field(min_length=1, max_length=160)]
    description: str | None = None
    test_case_ids: list[int]


class RunIn(In):
    name: str | None = None
    environment: Annotated[str, one_of(M.TEST_ENVS)]
    suite_id: int | None = None
    test_case_ids: list[int] = []
    rig_id: int | None = None
    integration_config_id: int | None = None


class ManualResultIn(In):
    status: Annotated[str, one_of(["passed", "failed", "blocked", "skipped"])]
    actual_output: Annotated[str, Field(min_length=1)]
    measurements: list[dict[str, Any]] = []


class ApproveIn(In):
    note: str | None = None


def _validate_measurement_specs(spec: dict) -> None:
    for name, s in spec.items():
        if not isinstance(s, dict) or not ({"min", "max"} & set(s)):
            raise HTTPException(422, f"expected_measurements.{name}: give min and/or max (and optional unit)")


def _case_out(db: Session, tc: M.TestCase, full: bool = False) -> dict:
    d = to_dict(tc, exclude=set() if full else {"code"})
    d["runnable"] = T.code_runnable(tc)
    reqs = (db.query(M.Requirement).join(M.TraceLink, M.TraceLink.requirement_id == M.Requirement.id)
            .filter(M.TraceLink.target_type == "test_case", M.TraceLink.target_ref == str(tc.id)).all())
    d["requirements"] = [{"id": r.id, "ref": r.ref, "title": r.title, "status": r.status} for r in reqs]
    last = (db.query(M.TestResult, M.TestRun).join(M.TestRun, M.TestRun.id == M.TestResult.run_id)
            .filter(M.TestResult.test_case_id == tc.id).order_by(M.TestResult.id.desc()).first())
    d["last_result"] = {"status": last[0].status, "run_id": last[1].id, "environment": last[1].environment,
                        "approved": last[1].approved_by is not None} if last else None
    return d


def _case(db: Session, user: M.User, cid: int) -> tuple[M.TestCase, M.Project]:
    tc = db.get(M.TestCase, cid)
    if not tc:
        raise HTTPException(404, "Test case not found")
    return tc, get_project_or_404(db, user, tc.project_id)


def _link_requirements(db: Session, user: M.User, tc: M.TestCase, req_ids: list[int]) -> None:
    for rid in req_ids:
        r = db.get(M.Requirement, rid)
        if not r or r.project_id != tc.project_id:
            raise HTTPException(422, f"Requirement {rid} is not in this project")
        if not db.query(M.TraceLink.id).filter_by(requirement_id=rid, target_type="test_case", target_ref=str(tc.id),
                                                  relation="verified_by").first():
            db.add(M.TraceLink(requirement_id=rid, target_type="test_case", target_ref=str(tc.id),
                               target_label=f"{tc.ref} {tc.name}", relation="verified_by", created_by=user.username))


# ---------------------------------------------------------------- environment info
@router.get("/testing/environment")
def environment(_: M.User = Depends(require("internal.view"))):
    return T.check_interpreter() | {"case_timeout_s": T.CASE_TIMEOUT_S, "testkit": str(T.testkit_root())}


# ---------------------------------------------------------------- test cases
@router.get("/projects/{pid}/test-cases")
def list_cases(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [_case_out(db, tc) for tc in db.query(M.TestCase).filter_by(project_id=pid).order_by(M.TestCase.ref)]


@router.post("/projects/{pid}/test-cases", status_code=201)
def create_case(pid: int, body: CaseIn, request: Request, user: M.User = Depends(require("tests.write")),
                db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    check_project_write(db, user, p)
    _validate_measurement_specs(body.expected_measurements)
    data = body.model_dump(exclude={"requirement_ids"})
    if not data["ref"]:
        nums = [int(m.group(1)) for (r,) in db.query(M.TestCase.ref).filter_by(project_id=pid)
                if (m := re.fullmatch(r"TC-(\d+)", r))]
        data["ref"] = f"TC-{(max(nums) + 1 if nums else 1):03d}"
    if db.query(M.TestCase.id).filter_by(project_id=pid, ref=data["ref"]).first():
        raise HTTPException(409, f"{data['ref']} already exists")
    if body.automation == "pytest" and not body.code:
        raise HTTPException(422, "Automated test cases need pytest code")
    if body.dbc_id and not db.get(M.DbcFile, body.dbc_id):
        raise HTTPException(422, "dbc_id: DBC not found")
    tc = M.TestCase(project_id=pid, created_by=user.username, code_version=1 if body.code else 0, **data)
    db.add(tc)
    db.flush()
    _link_requirements(db, user, tc, body.requirement_ids)
    audit(db, user, "test_case_create", "test_case", tc.id, project_id=pid, summary=f"{p.code} {tc.ref} {tc.name}",
          request=request)
    db.commit()
    return _case_out(db, tc, full=True)


@router.get("/test-cases/{cid}")
def get_case(cid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    tc, _ = _case(db, user, cid)
    return _case_out(db, tc, full=True)


@router.patch("/test-cases/{cid}")
def patch_case(cid: int, body: CasePatch, request: Request, user: M.User = Depends(require("tests.write")),
               db: Session = Depends(get_db)):
    tc, p = _case(db, user, cid)
    check_project_write(db, user, p)
    ch = body.model_dump(exclude_unset=True)
    if "expected_measurements" in ch:
        _validate_measurement_specs(ch["expected_measurements"])
    if "code" in ch and ch["code"] != tc.code:
        tc.code_version += 1
        tc.code_status, tc.code_approved_by, tc.code_sha256 = "draft", None, None  # changed code needs a new review
    for k, v in ch.items():
        setattr(tc, k, v)
    audit(db, user, "test_case_update", "test_case", tc.id, project_id=p.id,
          summary=f"{p.code} {tc.ref} updated ({', '.join(sorted(ch))})", request=request)
    db.commit()
    return _case_out(db, tc, full=True)


@router.post("/test-cases/{cid}/approve-code")
def approve_code(cid: int, request: Request, user: M.User = Depends(require("tests.approve")),
                 db: Session = Depends(get_db)):
    tc, p = _case(db, user, cid)
    if tc.automation != "pytest" or not tc.code:
        raise HTTPException(409, "No test code to approve")
    if tc.created_by == user.username:
        raise HTTPException(403, "Four-eyes rule: the author cannot approve their own test code")
    if T.code_runnable(tc):
        raise HTTPException(409, "Already approved")
    tc.code_status, tc.code_approved_by, tc.code_sha256 = "approved", user.username, T.sha(tc.code)
    audit(db, user, "test_code_approve", "test_case", tc.id, project_id=p.id,
          summary=f"{p.code} {tc.ref} code v{tc.code_version} approved (sha256 {tc.code_sha256[:12]})", request=request)
    db.commit()
    return _case_out(db, tc, full=True)


@router.post("/test-cases/{cid}/requirements")
def link_reqs(cid: int, body: dict, request: Request, user: M.User = Depends(require("trace.write")),
              db: Session = Depends(get_db)):
    tc, p = _case(db, user, cid)
    _link_requirements(db, user, tc, [int(x) for x in body.get("requirement_ids", [])])
    db.commit()
    return _case_out(db, tc)


# ---------------------------------------------------------------- suites
@router.get("/projects/{pid}/test-suites")
def list_suites(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [to_dict(s) for s in db.query(M.TestSuite).filter_by(project_id=pid).order_by(M.TestSuite.name)]


@router.post("/projects/{pid}/test-suites", status_code=201)
def create_suite(pid: int, body: SuiteIn, request: Request, user: M.User = Depends(require("tests.write")),
                 db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    ids = {tc.id for tc in db.query(M.TestCase).filter(M.TestCase.id.in_(body.test_case_ids), M.TestCase.project_id == pid)}
    if not body.test_case_ids or ids != set(body.test_case_ids):
        raise HTTPException(422, "test_case_ids must be test cases of this project")
    s = M.TestSuite(project_id=pid, name=body.name, description=body.description, test_case_ids=body.test_case_ids,
                    created_by=user.username)
    db.add(s)
    db.flush()
    audit(db, user, "suite_create", "test_suite", s.id, project_id=pid, summary=f"{p.code} suite '{s.name}'", request=request)
    db.commit()
    return to_dict(s)


# ---------------------------------------------------------------- runs
def _run_out(db: Session, run: M.TestRun, full: bool = False) -> dict:
    d = to_dict(run) | {"executing": T.is_running(run.id)}
    if run.rig_id:
        rg = db.get(M.TestRig, run.rig_id)
        d["rig"] = rg.name if rg else None
    if full:
        rows = []
        for r in db.query(M.TestResult).filter_by(run_id=run.id).order_by(M.TestResult.id):
            tc = db.get(M.TestCase, r.test_case_id)
            rows.append(to_dict(r) | {"ref": tc.ref, "name": tc.name, "automation": tc.automation,
                                      "expected_output": tc.expected_output, "acceptance_criteria": tc.acceptance_criteria})
        d["results"] = rows
    return d


@router.get("/projects/{pid}/test-runs")
def list_runs(pid: int, environment: str | None = None, user: M.User = Depends(require("internal.view")),
              db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    q = db.query(M.TestRun).filter_by(project_id=pid).order_by(M.TestRun.id.desc())
    if environment:
        q = q.filter(M.TestRun.environment == environment)
    return [_run_out(db, r) for r in q.limit(200)]


@router.post("/projects/{pid}/test-runs", status_code=201)
def start_run(pid: int, body: RunIn, request: Request, user: M.User = Depends(require("tests.run")),
              db: Session = Depends(get_db)):
    p = get_project_or_404(db, user, pid)
    ids = list(body.test_case_ids)
    suite = None
    if body.suite_id:
        suite = db.get(M.TestSuite, body.suite_id)
        if not suite or suite.project_id != pid:
            raise HTTPException(422, "suite_id: not a suite of this project")
        ids = list(suite.test_case_ids)
    cases = [db.get(M.TestCase, i) for i in dict.fromkeys(ids)]
    if not cases or any(c is None or c.project_id != pid for c in cases):
        raise HTTPException(422, "Select test cases of this project (or a suite)")
    rig = None
    hil_ok = False
    check_id = auth_id = None
    if body.environment in ("virtual_rig", "hil"):
        if not body.rig_id:
            raise HTTPException(422, f"{body.environment} runs need a rig")
        rig = db.get(M.TestRig, body.rig_id)
        if not rig or rig.is_template:
            raise HTTPException(422, "rig_id: rig not found (templates cannot run tests)")
        if body.environment == "virtual_rig" and rig.kind != "virtual":
            raise HTTPException(422, "virtual_rig runs need a virtual rig")
        if body.environment == "hil":
            if rig.kind != "physical":
                raise HTTPException(422, "HIL runs need a physical rig")
            ready = hil_readiness(db, rig)
            if not ready["ready"]:
                raise HTTPException(409, {"message": "Rig is not ready for HIL execution", "reasons": ready["reasons"]})
            hil_ok, check_id, auth_id = True, ready["checklist_id"], ready["authorization_id"]
        if db.query(M.TestRun.id).filter(M.TestRun.rig_id == rig.id, M.TestRun.status.in_(["queued", "running"])).first():
            raise HTTPException(409, f"Rig '{rig.name}' is busy with another run")
    elif body.rig_id:
        raise HTTPException(422, "SIL and manual runs do not use a rig")
    if body.integration_config_id:
        cfg = db.get(M.IntegrationConfig, body.integration_config_id)
        if not cfg or cfg.project_id != pid:
            raise HTTPException(422, "integration_config_id: not a configuration of this project")
    run = M.TestRun(project_id=pid, suite_id=suite.id if suite else None, environment=body.environment,
                    name=body.name or f"{body.environment.upper()} {suite.name if suite else f'{len(cases)} case(s)'}",
                    rig_id=rig.id if rig else None, checklist_id=check_id, authorization_id=auth_id,
                    integration_config_id=body.integration_config_id, started_by=user.username, status="queued")
    db.add(run)
    db.flush()
    automated = 0
    for tc in cases:
        status, log = "queued", None
        if body.environment not in (tc.environments or []):
            status, log = "skipped", f"{tc.ref} is not specified for environment '{body.environment}'"
        elif body.environment == "manual" or tc.automation == "manual":
            status = "pending"
        elif config.browser():
            status, log = "blocked", "Automated execution (pytest in a separate Python process) needs the desktop edition"
        elif not T.code_runnable(tc):
            status, log = "blocked", "Test code is not approved (or changed since approval)"
        else:
            automated += 1
        db.add(M.TestResult(run_id=run.id, test_case_id=tc.id, status=status, log=log))
    db.flush()
    T.recompute(db, run)
    run.status = "queued" if automated else run.status
    audit(db, user, "test_run", "test_run", run.id, project_id=pid,
          summary=f"{p.code} run #{run.id} {run.environment} ({len(cases)} cases, {automated} automated)"
                  + (f" on rig '{rig.name}'" if rig else ""), request=request)
    db.commit()
    if automated:
        T.start(run.id, hil_ok)
    return _run_out(db, run)


def _run(db: Session, user: M.User, rid: int) -> M.TestRun:
    r = db.get(M.TestRun, rid)
    if not r:
        raise HTTPException(404, "Run not found")
    get_project_or_404(db, user, r.project_id)
    return r


@router.get("/test-runs/{rid}")
def get_run(rid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    return _run_out(db, _run(db, user, rid), full=True)


@router.put("/test-results/{resid}")
def manual_result(resid: int, body: ManualResultIn, request: Request, user: M.User = Depends(require("tests.run")),
                  db: Session = Depends(get_db)):
    r = db.get(M.TestResult, resid)
    if not r:
        raise HTTPException(404, "Result not found")
    run = _run(db, user, r.run_id)
    tc = db.get(M.TestCase, r.test_case_id)
    if r.status != "pending":
        raise HTTPException(409, "Only pending (manual) results can be recorded by hand")
    if run.approved_by:
        raise HTTPException(409, "Run is approved and immutable")
    r.status, r.actual_output, r.measurements = body.status, body.actual_output, body.measurements
    r.executed_by, r.executed_at = user.username, M.utcnow()
    T.recompute(db, run)
    if run.status != "open":
        run.finished_at = M.utcnow()
    audit(db, user, "manual_result", "test_run", run.id, project_id=run.project_id,
          summary=f"Run #{run.id} {tc.ref}: {body.status}", request=request)
    db.commit()
    return _run_out(db, run, full=True)


@router.post("/test-runs/{rid}/approve")
def approve_run(rid: int, body: ApproveIn, request: Request, user: M.User = Depends(require("tests.approve")),
                db: Session = Depends(get_db)):
    """Engineer approval: results become verification evidence on every requirement the test cases verify."""
    run = _run(db, user, rid)
    if run.approved_by:
        raise HTTPException(409, "Already approved")
    if T.is_running(run.id) or run.status in ("queued", "running", "open"):
        raise HTTPException(409, f"Run is {run.status}; finish all results first")
    if run.started_by == user.username:
        raise HTTPException(403, "Four-eyes rule: the engineer who started the run cannot approve it")
    rig = db.get(M.TestRig, run.rig_id) if run.rig_id else None
    cfg = db.get(M.IntegrationConfig, run.integration_config_id) if run.integration_config_id else None
    env_label = {"sil": "SIL", "virtual_rig": "Virtual rig", "hil": "HIL", "manual": "Manual"}[run.environment]
    created = 0
    for res in db.query(M.TestResult).filter_by(run_id=run.id):
        if res.status not in ("passed", "failed"):
            continue
        tc = db.get(M.TestCase, res.test_case_id)
        ref = f"TR-{run.id}/{tc.ref}"
        res.evidence_ref = ref
        for link in db.query(M.TraceLink).filter_by(target_type="test_case", target_ref=str(tc.id)):
            req = db.get(M.Requirement, link.requirement_id)
            db.add(M.Evidence(requirement_id=req.id, kind="test_result", result="pass" if res.status == "passed" else "fail",
                              title=f"{env_label} {tc.ref} {tc.name}: {res.status}", reference=ref,
                              hardware_config=(f"{rig.name} ({rig.kind} rig)" if rig else env_label)
                              + (f" / {cfg.name}" if cfg else ""), software_config=cfg.name if cfg else None,
                              notes=(res.actual_output or "")[:2000], recorded_by=user.username))
            created += 1
            if res.status == "failed" and req.status in ("passed", "approved", "tested"):
                old = req.status
                req.status = "failed"
                audit(db, "system", "status", "requirement", req.id, project_id=req.project_id,
                      summary=f"{req.ref}: {old} -> failed (approved failing result {ref})")
    run.approved_by, run.approved_at, run.approval_note = user.username, M.utcnow(), body.note
    audit(db, user, "test_run_approve", "test_run", run.id, project_id=run.project_id,
          summary=f"Run #{run.id} approved: {created} evidence record(s) created", request=request)
    db.commit()
    return _run_out(db, run, full=True) | {"evidence_created": created}


# ---------------------------------------------------------------- comparison & coverage
@router.get("/projects/{pid}/test-comparison")
def comparison(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    """Expected vs SIL vs virtual-rig vs HIL: latest result and measurements per test case and environment."""
    get_project_or_404(db, user, pid)
    out = []
    for tc in db.query(M.TestCase).filter_by(project_id=pid).order_by(M.TestCase.ref):
        row = {"id": tc.id, "ref": tc.ref, "name": tc.name, "expected_output": tc.expected_output,
               "expected_measurements": tc.expected_measurements, "environments": {}}
        for env in M.TEST_ENVS:
            hit = (db.query(M.TestResult, M.TestRun).join(M.TestRun, M.TestRun.id == M.TestResult.run_id)
                   .filter(M.TestResult.test_case_id == tc.id, M.TestRun.environment == env,
                           M.TestResult.status.in_(["passed", "failed", "error"]))
                   .order_by(M.TestResult.id.desc()).first())
            if hit:
                res, run = hit
                row["environments"][env] = {"status": res.status, "run_id": run.id, "approved": run.approved_by is not None,
                                            "at": (res.executed_at or run.started_at).isoformat(timespec="seconds"),
                                            "measurements": {m["name"]: {"value": m.get("value"), "unit": m.get("unit"),
                                                                          "ok": m.get("ok")} for m in res.measurements or []}}
        out.append(row)
    return out


@router.get("/projects/{pid}/test-coverage")
def coverage(pid: int, user: M.User = Depends(require("internal.view")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    reqs = db.query(M.Requirement).filter_by(project_id=pid).order_by(M.Requirement.ref).all()
    rows = []
    for r in reqs:
        tcs = [db.get(M.TestCase, int(l.target_ref)) for l in
               db.query(M.TraceLink).filter_by(requirement_id=r.id, target_type="test_case") if l.target_ref.isdigit()]
        tcs = [t for t in tcs if t]
        latest = []
        for t in tcs:
            hit = (db.query(M.TestResult, M.TestRun).join(M.TestRun, M.TestRun.id == M.TestResult.run_id)
                   .filter(M.TestResult.test_case_id == t.id, M.TestRun.approved_by.isnot(None))
                   .order_by(M.TestResult.id.desc()).first())
            latest.append({"ref": t.ref, "status": hit[0].status if hit else None,
                           "environment": hit[1].environment if hit else None})
        state = "untested" if not tcs else "failing" if any(x["status"] == "failed" for x in latest) else \
            "passing" if all(x["status"] == "passed" for x in latest) else "partial"
        rows.append({"id": r.id, "ref": r.ref, "title": r.title, "mandatory": r.mandatory, "verification": r.verification_method,
                     "test_cases": latest, "state": state})
    tcs = db.query(M.TestCase).filter_by(project_id=pid).all()
    return {"rows": rows,
            "summary": {s: sum(1 for x in rows if x["state"] == s) for s in ("untested", "partial", "passing", "failing")},
            "test_cases": len(tcs), "automated": sum(1 for t in tcs if t.automation == "pytest"),
            "approved_code": sum(1 for t in tcs if T.code_runnable(t)),
            "basis": "latest result from APPROVED runs per test case linked as verified_by"}
