"""Engineering reports (Phase 1 subset): Requirements Traceability, Hardware Integration Register,
Software Integration Register — CSV, Excel and PDF, each with document control metadata."""
from __future__ import annotations

import csv
import hashlib
import io
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import config
from .. import models as M
from ..db import get_db
from ..security import ROLES, audit, get_project_or_404, require
from ..services import engineering as E

router = APIRouter(prefix="/api/v1/reports", tags=["reports"])

REPORTS = {
    "requirements_traceability": "Requirements Traceability Report",
    "hardware_integration": "Hardware Integration Report",
    "software_integration": "Software Integration Report",
    "system_architecture": "System Architecture Report",
    "interface_compatibility": "Interface Compatibility Report",
    "automated_test": "Automated Test Report",
    "sil_test": "SIL Test Report",
    "hil_test": "HIL Test Report",
    "test_rig_configuration": "Test Rig Configuration Report",
    "integration_failure": "Integration Failure Report",
    "root_cause_analysis": "Root Cause Analysis Report",
    "can_communication": "CAN Communication Report",
    "software_release": "Software Release Report",
    "customer_site_integration": "Customer Site Integration Report",
    "final_system_acceptance": "Final System Acceptance Report",
}
PLANNED: list[str] = []
MIME = {"csv": "text/csv", "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "pdf": "application/pdf"}


@router.get("")
def catalogue(_: M.User = Depends(require("reports.export"))):
    return {"available": [{"key": k, "title": t, "formats": list(MIME)} for k, t in REPORTS.items()],
            "planned": PLANNED}


def _build(db: Session, p: M.Project, kind: str) -> tuple[list[str], list[list], dict]:
    """Return (columns, rows, context)."""
    hw = db.query(M.HardwareItem).filter_by(project_id=p.id).order_by(M.HardwareItem.asset_tag).all()
    sw = db.query(M.SoftwareItem).filter_by(project_id=p.id).order_by(M.SoftwareItem.name).all()
    reqs = E.load_requirements(db, p.id)
    ctx = {
        "hardware_revisions": [f"{h.asset_tag} {h.manufacturer} {h.model} HW {h.hardware_revision or '-'} "
                               f"FW {h.firmware_version or '-'}" for h in hw],
        "software_revisions": [f"{s.name} {s.version}" + (f" ({s.commit_ref})" if s.commit_ref else "") for s in sw],
        "gate": E.delivery_gate(db, p.id, reqs),
        "coverage": E.coverage(db, p.id, reqs),
        "approvals": [f"{h.changed_at:%Y-%m-%d %H:%M} {h.changed_by}: stage -> {h.to_stage}"
                      + (f" ({h.note})" if h.note else "")
                      for h in db.query(M.StageHistory).filter_by(project_id=p.id).order_by(M.StageHistory.id)]
                     + [f"{e.recorded_at:%Y-%m-%d %H:%M} {e.recorded_by}: customer sign-off {r.ref} '{e.title}'"
                        for r in reqs for e in r.evidence if e.kind == "customer_signoff"],
    }
    if kind == "requirements_traceability":
        cols = ["Ref", "Title", "Category", "Priority", "Mandatory", "Verification", "Status", "Allocated to",
                "Verified by", "Evidence (pass/fail/info)", "Gaps"]
        rows = []
        for r in reqs:
            alloc = "; ".join(f"{l.target_type}: {l.target_label}" for l in r.links if l.relation != "verified_by")
            ver = "; ".join(f"{l.target_type}: {l.target_label}" for l in r.links if l.relation == "verified_by")
            ev = (f"{sum(e.result == 'pass' for e in r.evidence)}/{sum(e.result == 'fail' for e in r.evidence)}/"
                  f"{sum(e.result == 'info' for e in r.evidence)}")
            row_cov = next(x for x in ctx["coverage"]["rows"] if x["id"] == r.id)
            rows.append([r.ref, r.title, r.category, r.priority, "yes" if r.mandatory else "no", r.verification_method,
                         r.status, alloc, ver, ev, "; ".join(row_cov["gaps"])])
    elif kind == "hardware_integration":
        cols = ["Asset", "Name", "Category", "Manufacturer", "Model", "Serial", "HW rev", "FW", "Supply V",
                "Max A", "Interfaces", "Status", "Config records"]
        rows = [[h.asset_tag, h.name, h.category, h.manufacturer, h.model, h.serial_number, h.hardware_revision or "",
                 h.firmware_version or "",
                 f"{h.supply_voltage_min or ''}-{h.supply_voltage_max or ''}" if h.supply_voltage_min or
                 h.supply_voltage_max else "", h.max_current_a or "", ", ".join(h.interfaces), h.status,
                 len(h.config_records)] for h in hw]
    elif kind == "software_integration":
        cols = ["Name", "Version", "Kind", "Language", "Commit", "Build", "Target platform", "Status", "Dependencies",
                "Hardware compatibility"]
        rows = [[s.name, s.version, s.kind, s.language, s.commit_ref or "", s.build_system or "",
                 s.target_platform or "", s.status,
                 "; ".join(f"{d.name} {d.version_constraint or ''}".strip() for d in s.dependencies),
                 "; ".join(f"{c.hardware.asset_tag}={c.status}" for c in s.compatibility)] for s in sw]
    elif kind == "system_architecture":
        from .architecture import model_payload
        cols = ["Architecture", "Component", "Layer", "Kind", "Hosted on / part of", "Inventory record", "Revision",
                "Connections"]
        rows = []
        for am in db.query(M.ArchModel).filter_by(project_id=p.id).order_by(M.ArchModel.id):
            pl = model_payload(db, am)
            names = {c["id"]: c["name"] for c in pl["components"]}
            for c in sorted(pl["components"], key=lambda c: (c["layer"], c["name"])):
                inv = c.get("inventory") or {}
                ident = (f"{inv.get('asset_tag', '')} {inv.get('manufacturer', '')} {inv.get('model', '')}".strip()
                         if c["layer"] == "hardware" else f"{inv.get('name', '')} {inv.get('version', '')}".strip())
                rev = (f"HW {inv.get('hardware_revision') or '-'} / FW {inv.get('firmware_version') or '-'}"
                       if c["layer"] == "hardware" and inv else "")
                n = sum(1 for x in pl["connections"] if c["id"] in (x["source_id"], x["target_id"]))
                rows.append([am.name, c["name"], c["layer"], c["kind"], names.get(c["parent_id"], ""),
                             ident or "(not linked)", rev, n])
            for f in pl["dependencies"]:
                if f["severity"] != "info":
                    rows.append([am.name, f"[{f['severity'].upper()}] {f['code']}", "finding", "", "", f["message"], "", ""])
    elif kind == "interface_compatibility":
        from ..services.validation import validate_model
        cols = ["Architecture", "Source", "Destination", "Interface", "Protocol", "Data type", "Rate Hz", "Status",
                "Result", "Explanation", "Verification"]
        rows = []
        for am in db.query(M.ArchModel).filter_by(project_id=p.id).order_by(M.ArchModel.id):
            v = validate_model(db, am.id)
            conns = {c.id: c for c in db.query(M.ArchConnection).filter_by(model_id=am.id)}
            for r in v["connections"]:
                cn = conns[r["id"]]
                rows.append([am.name, r["source"], r["target"], cn.interface_type, cn.protocol or "", cn.data_type or "",
                             f"{cn.rate_hz:g}" if cn.rate_hz else "", cn.status, r["result"], r["explanation"],
                             f"{cn.verified_by}: {cn.verification_ref}" if cn.verification_ref else ""])
    elif kind in ("automated_test", "sil_test", "hil_test"):
        env = {"sil_test": ["sil"], "hil_test": ["hil"], "automated_test": ["sil", "virtual_rig", "hil"]}[kind]
        cols = ["Run", "Environment", "Rig", "Approved by", "Test case", "Name", "Status", "Actual output / measurements",
                "Duration s", "Evidence"]
        rows = []
        for run in db.query(M.TestRun).filter(M.TestRun.project_id == p.id, M.TestRun.environment.in_(env)) \
                .order_by(M.TestRun.id):
            rig = db.get(M.TestRig, run.rig_id) if run.rig_id else None
            for r in db.query(M.TestResult).filter_by(run_id=run.id).order_by(M.TestResult.id):
                tc = db.get(M.TestCase, r.test_case_id)
                rows.append([f"#{run.id} {run.started_at:%Y-%m-%d %H:%M}", run.environment,
                             f"{rig.name} ({rig.kind})" if rig else "", run.approved_by or "NOT APPROVED", tc.ref, tc.name,
                             r.status, (r.actual_output or r.log or "")[:600], r.duration_s or "", r.evidence_ref or ""])
            ctx["approvals"].append(f"Run #{run.id} ({run.environment}): " + (
                f"approved by {run.approved_by} {run.approved_at:%Y-%m-%d %H:%M}" if run.approved_by else "not approved"))
    elif kind == "test_rig_configuration":
        cols = ["Rig", "Kind", "Status", "Component", "Role", "Inventory item", "HW rev / FW", "Properties", "Connections",
                "Last checklist"]
        rows = []
        for rig in db.query(M.TestRig).filter(M.TestRig.project_id == p.id, M.TestRig.is_template.is_(False)):
            last = db.query(M.RigChecklist).filter_by(rig_id=rig.id).order_by(M.RigChecklist.id.desc()).first()
            comps = {c.id: c for c in db.query(M.RigComponent).filter_by(rig_id=rig.id)}
            conns = db.query(M.RigConnection).filter_by(rig_id=rig.id).all()
            for c in comps.values():
                h = db.get(M.HardwareItem, c.hardware_id) if c.hardware_id else None
                links = "; ".join(f"{x.kind} {x.interface or ''} -> {comps[x.target_id].name}" for x in conns
                                  if x.source_id == c.id and x.target_id in comps)
                rows.append([rig.name, rig.kind, rig.status, c.name, c.role,
                             f"{h.asset_tag} {h.manufacturer} {h.model} S/N {h.serial_number}" if h else "(not linked)",
                             f"{h.hardware_revision or '-'} / {h.firmware_version or '-'}" if h else "",
                             ", ".join(f"{k}={v}" for k, v in (c.properties or {}).items())[:300], links,
                             f"#{last.id} {last.status} {last.completed_at:%Y-%m-%d %H:%M}" if last and last.completed_at
                             else (f"#{last.id} {last.status}" if last else "none")])
    elif kind == "integration_failure":
        cols = ["Issue", "Severity", "Status", "Title", "Affected subsystem", "Actual behaviour", "Expected behaviour",
                "Hardware revision", "Software revision", "Linked records", "Supporting events", "Owner", "Opened"]
        rows = []
        for i in db.query(M.Issue).filter_by(project_id=p.id).order_by(M.Issue.ref):
            rows.append([i.ref, i.severity, i.status, i.title, i.affected_subsystem or "", (i.actual_behaviour or "")[:500],
                         (i.expected_behaviour or "")[:300], (i.hardware_revision or "")[:300], (i.software_revision or "")[:300],
                         "; ".join(l["label"] for l in i.links or []), len(i.pinned_event_ids or []), i.owner or "",
                         f"{i.created_at:%Y-%m-%d} {i.created_by}"])
        sev = {"critical": 0, "major": 1, "minor": 2}
        rows.sort(key=lambda r: (r[2] in ("closed", "rejected"), sev.get(r[1], 3), r[0]))
    elif kind == "root_cause_analysis":
        cols = ["Issue", "Title", "Status", "Problem description", "Reproduction steps", "Supporting log events",
                "Hypotheses (status: text — verification)", "Confirmed root cause", "Corrective action", "Retest", "Closed"]
        rows = []
        for i in db.query(M.Issue).filter_by(project_id=p.id).order_by(M.Issue.ref):
            evs = db.query(M.LogEvent).filter(M.LogEvent.id.in_(i.pinned_event_ids or [-1])).order_by(M.LogEvent.ts).all()
            hyps = db.query(M.IssueHypothesis).filter_by(issue_id=i.id).order_by(M.IssueHypothesis.id).all()
            run = db.get(M.TestRun, i.retest_run_id) if i.retest_run_id else None
            rows.append([i.ref, i.title, i.status, (i.problem_description or "")[:600], (i.reproduction_steps or "")[:400],
                         " | ".join(f"{e.ts:%H:%M:%S.%f}"[:-3] + f" {e.level} {e.component or ''}: {e.message[:120]}" for e in evs[:12]),
                         " | ".join(f"{h.status} ({h.origin}): {h.text[:200]}" + (f" — {h.verification[:150]} [{h.decided_by}]" if h.verification else "")
                                    for h in hyps),
                         f"{i.confirmed_root_cause or '(not confirmed)'}" + (f" [{i.root_cause_confirmed_by}]" if i.root_cause_confirmed_by else ""),
                         f"{i.corrective_action or ''}" + (f" (owner {i.corrective_owner}, due {i.corrective_due})" if i.corrective_owner else ""),
                         (f"Run #{run.id} {run.environment} {run.status}, approved by {run.approved_by}" if run and run.approved_by
                          else f"Run #{run.id} {run.status} (not approved)" if run else (i.retest_result or "")),
                         f"{i.closed_at:%Y-%m-%d} {i.closed_by}" if i.closed_at else ""])
            if i.root_cause_confirmed_by:
                ctx["approvals"].append(f"{i.ref}: root cause confirmed by {i.root_cause_confirmed_by}"
                                        + (f"; closed by {i.closed_by} {i.closed_at:%Y-%m-%d %H:%M}" if i.closed_at else ""))
    elif kind == "can_communication":
        cols = ["Capture", "Kind", "Environment", "Interface / channel", "DBC", "Started", "Records", "Duration s",
                "Error frames", "Bus load % (estimate)", "Per-ID rates"]
        rows = []
        for c in db.query(M.Capture).filter_by(project_id=p.id).order_by(M.Capture.id):
            st = c.stats or {}
            dbc = db.get(M.DbcFile, c.dbc_id) if c.dbc_id else None
            ids = "; ".join(f"{i.get('hex')} n={i.get('count')} {i.get('rate_hz') or '-'} Hz" for i in (st.get("ids") or [])[:25])
            rows.append([f"#{c.id} {c.name}", c.kind, c.environment,
                         f"{(c.config or {}).get('interface', '')} {(c.config or {}).get('channel', '')}".strip(),
                         dbc.name if dbc else "", f"{c.started_at:%Y-%m-%d %H:%M} {c.started_by}", st.get("records", c.records),
                         st.get("duration_s", ""), st.get("error_frames", ""), st.get("bus_load_pct", ""), ids])
    elif kind == "software_release":
        from ..services import delivery as D
        cols = ["Release", "Status", "Source revision", "Tag", "Build", "Configuration", "Release gate",
                "Failing / warning checks", "Required suites / runs", "Known limitations", "Approvals", "Deployments"]
        rows = []
        for rel in db.query(M.Release).filter_by(project_id=p.id).order_by(M.Release.id):
            chk = D.release_checks(db, rel)
            b = db.get(M.Build, rel.build_id) if rel.build_id else None
            cfg = db.get(M.IntegrationConfig, rel.integration_config_id) if rel.integration_config_id else None
            apps = db.query(M.ReleaseApproval).filter_by(release_id=rel.id).order_by(M.ReleaseApproval.id).all()
            deps = db.query(M.Deployment).filter_by(release_id=rel.id).order_by(M.Deployment.id).all()
            rows.append([rel.version + (f" ({rel.name})" if rel.name else ""), rel.status, (rel.commit_sha or "")[:12], rel.tag or "",
                         f"#{b.id} {b.source} {b.status} @ {(b.commit_sha or '')[:12]}" if b else "",
                         f"{cfg.name} ({cfg.status})" if cfg else "",
                         "PASSED" if chk["passed"] else f"BLOCKED ({chk['counts']['fail']} failing)",
                         " | ".join(f"[{c['result'].upper()}] {c['title']}: {c['detail']}" for c in chk["checks"] if c["result"] != "pass")[:900],
                         f"{len(rel.required_suite_ids)} suite(s), {len(rel.test_run_ids)} run(s)",
                         " | ".join(rel.known_limitations),
                         " | ".join(f"{a.kind} {a.decision} by {a.username}" + (" (superseded)" if a.superseded else "") for a in apps),
                         " | ".join(f"{d.environment} {d.target} {d.status}" for d in deps)])
            for a in apps:
                ctx["approvals"].append(f"{a.at:%Y-%m-%d %H:%M} {a.username} ({ROLES.get(a.role)}): {rel.version} {a.kind} "
                                        f"{a.decision}" + (" [superseded]" if a.superseded else "") + (f" - {a.comment}" if a.comment else ""))
    elif kind == "customer_site_integration":
        cols = ["Site", "Site status", "Record", "Reference", "Detail", "Revision / release", "By", "Date"]
        rows = []
        for s in db.query(M.Site).filter_by(project_id=p.id).order_by(M.Site.name):
            for x in s.infrastructure or []:
                rows.append([s.name, s.status, f"infrastructure: {x.get('category')}", x.get("item"), x.get("detail") or "", "",
                             s.created_by, ""])
            for i in db.query(M.SiteInstallation).filter_by(site_id=s.id).order_by(M.SiteInstallation.id):
                h = db.get(M.HardwareItem, i.hardware_id)
                cfgtxt = ", ".join(f"{k}={v}" for k, v in (i.configuration or {}).items())
                rows.append([s.name, s.status, "installation" + (" (removed)" if i.removed_at else ""),
                             f"{h.asset_tag} {h.manufacturer} {h.model} S/N {i.serial_number}",
                             i.position + (f"; {cfgtxt}" if cfgtxt else ""),
                             f"HW {i.hardware_revision or '-'} / FW {i.firmware_version or '-'}", i.installed_by,
                             f"{i.installed_at:%Y-%m-%d}"])
            for d in db.query(M.Deployment).filter_by(site_id=s.id).order_by(M.Deployment.id):
                rel = db.get(M.Release, d.release_id)
                rows.append([s.name, s.status, f"deployment ({d.status})", d.target,
                             (f"rollback of #{d.rollback_of_id}; " if d.rollback_of_id else "") + (d.notes or ""),
                             f"{rel.version} @ {(rel.commit_sha or '')[:12]}", d.performed_by or d.recorded_by,
                             f"{d.performed_at:%Y-%m-%d}" if d.performed_at else ""])
            for c in db.query(M.SiteCheck).filter_by(site_id=s.id).order_by(M.SiteCheck.id):
                rel = db.get(M.Release, c.release_id) if c.release_id else None
                for it in c.items:
                    rows.append([s.name, s.status, f"check #{c.id} ({c.status})", it["text"],
                                 f"{it['status'].upper()}: {it.get('detail') or ''}", rel.version if rel else "",
                                 it.get("by") or "", (it.get("at") or "")[:10]])
            for g in db.query(M.SiteDiagnostic).filter_by(site_id=s.id).order_by(M.SiteDiagnostic.id):
                rows.append([s.name, s.status, f"diagnostic ({g.kind})", g.filename, f"{g.size} B sha256 {g.sha256[:16]}"
                             + (f"; imported as log import #{g.log_import_id}" if g.log_import_id else ""), "", g.uploaded_by,
                             f"{g.uploaded_at:%Y-%m-%d}"])
            for i in db.query(M.Issue).filter_by(site_id=s.id).order_by(M.Issue.ref):
                rows.append([s.name, s.status, f"issue ({i.severity}, {i.status})", f"{i.ref} {i.title}",
                             f"Corrective action: {i.corrective_action or '(none yet)'}", "", i.owner or i.created_by,
                             f"{i.created_at:%Y-%m-%d}"])
    elif kind == "final_system_acceptance":
        from ..services import delivery as D
        fg = D.final_gate(db, p.id)
        ctx["gate"], ctx["gate_label"] = fg, "Final delivery gate"
        cols = ["Record", "Kind", "Record status", "Release", "Site", "Requirement", "Mandatory", "Result", "Engineer comment",
                "Customer comment", "Requirement status", "Signed"]
        rows = []
        reqs_by_id = {r.id: r for r in reqs}
        for a in db.query(M.AcceptanceRecord).filter_by(project_id=p.id).order_by(M.AcceptanceRecord.id):
            rel = db.get(M.Release, a.release_id) if a.release_id else None
            site = db.get(M.Site, a.site_id) if a.site_id else None
            signed = (f"{a.signed_at:%Y-%m-%d %H:%M} {a.signed_by} ({a.signature_role}: {a.customer_representative}) "
                      f"sha256 {a.sha256[:16]}" if a.signed_at else "not signed")
            for it in a.items:
                r = reqs_by_id.get(it["requirement_id"])
                rows.append([a.ref, a.kind.upper(), a.status, f"{rel.version} ({rel.status})" if rel else "", site.name if site else "",
                             f"{it['ref']} {it['title']}", "yes" if it["mandatory"] else "no", it["result"], it.get("comment") or "",
                             it.get("customer_comment") or "", r.status if r else "(deleted)", signed])
            if a.signed_at:
                ctx["approvals"].append(f"{a.signed_at:%Y-%m-%d %H:%M} {a.ref} {a.status.upper()} signed by {a.signed_by} "
                                        f"({a.signature_role}, representative {a.customer_representative})"
                                        + (f"; conditions: {a.conditions}" if a.conditions else ""))
        for b in fg["blockers"]:
            rows.append(["FINAL GATE", "", "BLOCKER", "", "", f"{b['ref']} {b['title']}", "", "", "; ".join(b["reasons"]),
                         "", "", ""])
    else:
        raise HTTPException(404, f"Unknown report '{kind}'")
    return cols, rows, ctx


def _header(p: M.Project, kind: str, rev: int, user: M.User, lead: str) -> list[tuple[str, str]]:
    return [("Document", REPORTS[kind]), ("Document revision", f"Rev {rev}"),
            ("Date (UTC)", datetime.utcnow().strftime("%Y-%m-%d %H:%M")), ("Project ID", p.code),
            ("Project", p.name), ("Customer", p.customer.name), ("Stage", dict(M.STAGES)[p.stage]),
            ("Responsible engineer", lead), ("Generated by", f"{user.full_name} ({ROLES.get(user.role)})"),
            ("Application", f"{config.APP_NAME} {config.APP_VERSION}")]


def _csv(header, cols, rows, ctx) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    for k, v in header:
        w.writerow([f"# {k}", v])
    w.writerow([f"# {ctx.get('gate_label', 'Delivery gate')}", "PASSED" if ctx["gate"]["passed"] else f"BLOCKED ({len(ctx['gate']['blockers'])})"])
    w.writerow([])
    w.writerow(cols)
    w.writerows(rows)
    w.writerow([])
    w.writerow(["# Applicable hardware revisions"])
    w.writerows([[x] for x in ctx["hardware_revisions"]] or [["(none recorded)"]])
    w.writerow(["# Applicable software revisions"])
    w.writerows([[x] for x in ctx["software_revisions"]] or [["(none recorded)"]])
    w.writerow(["# Approval history"])
    w.writerows([[x] for x in ctx["approvals"]])
    return buf.getvalue().encode("utf-8-sig")


def _xlsx(header, cols, rows, ctx) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    wb = Workbook()
    ws = wb.active
    ws.title = "Report"
    bold = Font(bold=True)
    for k, v in header:
        ws.append([k, v])
        ws.cell(ws.max_row, 1).font = bold
    ws.append([ctx.get("gate_label", "Delivery gate"), "PASSED" if ctx["gate"]["passed"] else f"BLOCKED ({len(ctx['gate']['blockers'])})"])
    ws.append([])
    ws.append(cols)
    fill = PatternFill("solid", fgColor="1F2937")
    for c in ws[ws.max_row]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = fill
    for r in rows:
        ws.append(r)
    for i, col in enumerate(cols, 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = 22 if i > 2 else 30
    for title, items in (("Applicable hardware revisions", ctx["hardware_revisions"]),
                         ("Applicable software revisions", ctx["software_revisions"]),
                         ("Approval history", ctx["approvals"])):
        s = wb.create_sheet(title[:31])
        s.append([title])
        s["A1"].font = bold
        for x in items or ["(none recorded)"]:
            s.append([x])
        s.column_dimensions["A"].width = 100
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def _latin(s) -> str:
    return str(s).encode("latin-1", "replace").decode("latin-1")


def _pdf(header, cols, rows, ctx, title) -> bytes:
    from fpdf import FPDF

    pdf = FPDF(orientation="L", unit="mm", format="A4")
    pdf.set_auto_page_break(True, margin=12)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 15)
    pdf.cell(0, 9, _latin(f"{config.APP_NAME} - {title}"), new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 9)
    for k, v in header:
        pdf.set_font("Helvetica", "B", 9)
        pdf.cell(45, 5, _latin(k))
        pdf.set_font("Helvetica", "", 9)
        pdf.cell(0, 5, _latin(v), new_x="LMARGIN", new_y="NEXT")
    gate = ctx["gate"]
    pdf.set_font("Helvetica", "B", 9)
    pdf.cell(45, 5, ctx.get("gate_label", "Delivery gate"))
    pdf.cell(0, 5, "PASSED" if gate["passed"] else f"BLOCKED - {len(gate['blockers'])} blocker(s)",
             new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)
    pdf.set_font("Helvetica", "", 7)
    with pdf.table(text_align="LEFT", line_height=3.6, first_row_as_headings=True) as t:
        hr = t.row()
        for c in cols:
            hr.cell(_latin(c))
        for r in rows or [["(no records)"] + [""] * (len(cols) - 1)]:
            tr = t.row()
            for v in r:
                tr.cell(_latin(v)[:300])
    for sec, items in (("Applicable hardware revisions", ctx["hardware_revisions"]),
                       ("Applicable software revisions", ctx["software_revisions"]),
                       ("Approval history", ctx["approvals"])):
        pdf.ln(3)
        pdf.set_font("Helvetica", "B", 10)
        pdf.cell(0, 6, sec, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 8)
        for x in items or ["(none recorded)"]:
            pdf.multi_cell(0, 4, _latin(f"- {x}"), new_x="LMARGIN", new_y="NEXT")
    return bytes(pdf.output())


@router.get("/log/{pid}")
def report_log(pid: int, user: M.User = Depends(require("reports.export")), db: Session = Depends(get_db)):
    get_project_or_404(db, user, pid)
    return [{"report_type": r.report_type, "title": REPORTS.get(r.report_type), "revision": r.revision, "fmt": r.fmt,
             "generated_by": r.generated_by, "generated_at": r.generated_at.isoformat(timespec="seconds"),
             "sha256": r.sha256}
            for r in db.query(M.ReportLog).filter_by(project_id=pid).order_by(M.ReportLog.id.desc())]


@router.get("/{kind}/{pid}")
def export(kind: str, pid: int, fmt: str = Query("pdf", pattern="^(csv|xlsx|pdf)$"),
           user: M.User = Depends(require("reports.export")), db: Session = Depends(get_db)):
    if kind not in REPORTS:
        raise HTTPException(404, f"Unknown report '{kind}'")
    p = get_project_or_404(db, user, pid)
    cols, rows, ctx = _build(db, p, kind)
    rev = (db.query(func.max(M.ReportLog.revision)).filter_by(project_id=p.id, report_type=kind).scalar() or 0) + 1
    lead = db.get(M.User, p.lead_engineer_id).full_name if p.lead_engineer_id else "(not assigned)"
    header = _header(p, kind, rev, user, lead)
    data = {"csv": lambda: _csv(header, cols, rows, ctx), "xlsx": lambda: _xlsx(header, cols, rows, ctx),
            "pdf": lambda: _pdf(header, cols, rows, ctx, REPORTS[kind])}[fmt]()
    sha = hashlib.sha256(data).hexdigest()
    db.add(M.ReportLog(project_id=p.id, report_type=kind, revision=rev, fmt=fmt, generated_by=user.username, sha256=sha))
    audit(db, user, "report", "project", p.id, project_id=p.id, summary=f"{REPORTS[kind]} Rev {rev} ({fmt})",
          detail={"sha256": sha})
    db.commit()
    fname = f"{p.code}_{kind}_rev{rev}.{fmt}"
    return Response(data, media_type=MIME[fmt], headers={"Content-Disposition": f'attachment; filename="{fname}"',
                                                         "X-Report-Revision": str(rev), "X-Report-SHA256": sha})
