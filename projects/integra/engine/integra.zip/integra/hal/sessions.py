"""Background capture / generator / replay sessions (CAN, serial, UDP).

Each session runs in its own thread, keeps a ring buffer for live viewing and appends every record to
data/captures/<capture_id>.jsonl. The Capture row is updated when the session stops.
"""
from __future__ import annotations

import json
import math
import socket
import threading
import time
from collections import defaultdict, deque
from pathlib import Path

from .. import config
from .. import models as M
from ..db import session_scope
from .decoders import UbxParser, build_ubx, decode_nmea, nmea_checksum

RING = 5000
_lock = threading.Lock()
SESSIONS: dict[int, "BaseSession"] = {}
TASKS: dict[str, "BaseTask"] = {}


def capture_dir() -> Path:
    d = config.settings.data_dir / "captures"
    d.mkdir(parents=True, exist_ok=True)
    return d


def capture_file(cid: int) -> Path:
    return capture_dir() / f"{cid}.jsonl"


class BaseSession:
    kind = "base"

    def __init__(self, capture_id: int, cfg: dict):
        self.id, self.cfg = capture_id, cfg
        self.ring: deque = deque(maxlen=RING)
        self.seq = 0
        self.stop_evt = threading.Event()
        self.error: str | None = None
        self.started = time.time()
        self.file = open(capture_file(capture_id), "a", encoding="utf-8")
        self.thread = threading.Thread(target=self._wrap, name=f"capture-{capture_id}", daemon=True)

    def start(self):
        with _lock:
            SESSIONS[self.id] = self
        self.thread.start()

    def _wrap(self):
        try:
            self.run()
        except Exception as e:  # recorded on the capture row
            self.error = f"{type(e).__name__}: {e}"
        finally:
            self.file.close()
            self._finish()

    def add(self, rec: dict):
        self.seq += 1
        rec["seq"] = self.seq
        self.ring.append(rec)
        self.file.write(json.dumps(rec, separators=(",", ":")) + "\n")
        if self.seq % 200 == 0:
            self.file.flush()

    def stats(self) -> dict:
        return {"records": self.seq}

    def stop(self, wait: float = 3.0):
        self.stop_evt.set()
        self.thread.join(wait)

    def _finish(self):
        with _lock:
            SESSIONS.pop(self.id, None)
        with session_scope() as db:
            c = db.get(M.Capture, self.id)
            if c:
                c.status = "error" if self.error else "stopped"
                c.error = self.error
                c.records = self.seq
                c.stats = self.stats()
                c.stopped_at = M.utcnow()

    def since(self, after: int, limit: int) -> list[dict]:
        return [r for r in list(self.ring) if r["seq"] > after][:limit]


# ---------------------------------------------------------------- CAN
def open_can_bus(cfg: dict):
    import can
    kw = {"interface": cfg["interface"], "channel": cfg["channel"]}
    if cfg["interface"] != "virtual":
        if cfg.get("bitrate"):
            kw["bitrate"] = int(cfg["bitrate"])
        if cfg.get("fd"):
            kw["fd"] = True
            if cfg.get("data_bitrate"):
                kw["data_bitrate"] = int(cfg["data_bitrate"])
    bus = can.Bus(**kw)
    listen_only = None
    if cfg.get("listen_only") and cfg["interface"] != "virtual":
        try:
            bus.state = can.BusState.PASSIVE
            listen_only = True
        except Exception:
            listen_only = False  # interface cannot enforce it; recorded in the capture stats
    return bus, listen_only


def frame_bits(dlc_bytes: int, extended: bool) -> float:
    """Approximate bits on the wire incl. ~10 % stuffing (classical frame model; FD data phase not separated)."""
    return ((67 if extended else 47) + 8 * dlc_bytes) * 1.1


class CanSession(BaseSession):
    kind = "can"

    def __init__(self, capture_id, cfg):
        super().__init__(capture_id, cfg)
        self.by_id: dict[int, dict] = {}
        self.errors = 0
        self.window: deque = deque()  # (t, bits) over the last second
        self.listen_only = None

    def run(self):
        bus, self.listen_only = open_can_bus(self.cfg)
        try:
            while not self.stop_evt.is_set():
                msg = bus.recv(0.2)
                if msg is None:
                    continue
                t = time.time()
                rec = {"t": round(t, 6), "id": msg.arbitration_id, "ext": msg.is_extended_id, "fd": msg.is_fd,
                       "brs": msg.bitrate_switch, "dlc": msg.dlc, "data": bytes(msg.data).hex(), "err": msg.is_error_frame,
                       "rtr": msg.is_remote_frame}
                self.add(rec)
                if msg.is_error_frame:
                    self.errors += 1
                    continue
                s = self.by_id.setdefault(msg.arbitration_id, {"count": 0, "first": t, "last": t, "dlc": msg.dlc,
                                                               "ext": msg.is_extended_id})
                s["count"] += 1
                s["last"], s["dlc"] = t, msg.dlc
                self.window.append((t, frame_bits(len(msg.data), msg.is_extended_id)))
        finally:
            bus.shutdown()

    def stats(self) -> dict:
        now = time.time()
        while self.window and self.window[0][0] < now - 1.0:
            self.window.popleft()
        bitrate = float(self.cfg.get("bitrate") or 500000)
        ids = []
        for i, s in sorted(self.by_id.items()):
            span = s["last"] - s["first"]
            ids.append({"id": i, "hex": f"0x{i:X}", "count": s["count"], "dlc": s["dlc"], "ext": s["ext"],
                        "rate_hz": round((s["count"] - 1) / span, 2) if span > 0 and s["count"] > 1 else None,
                        "last_t": s["last"]})
        return {"records": self.seq, "error_frames": self.errors, "ids": ids,
                "bus_load_pct": round(100 * sum(b for _, b in self.window) / bitrate, 2),
                "bus_load_basis": f"estimate at {int(bitrate)} bit/s, classical frame model",
                "listen_only": self.listen_only, "duration_s": round(now - self.started, 1)}


def send_can(cfg: dict, arbitration_id: int, data: bytes, extended: bool, fd: bool = False):
    import can
    bus, _ = open_can_bus(cfg | {"listen_only": False})
    try:
        bus.send(can.Message(arbitration_id=arbitration_id, data=data, is_extended_id=extended, is_fd=fd))
    finally:
        bus.shutdown()


class BaseTask:
    """Generator / replay running on a bus until stopped."""

    def __init__(self, key: str, cfg: dict, user: str):
        self.key, self.cfg, self.user = key, cfg, user
        self.stop_evt = threading.Event()
        self.sent = 0
        self.error: str | None = None
        self.started = time.time()
        self.done = False
        self.thread = threading.Thread(target=self._wrap, name=f"task-{key}", daemon=True)

    def start(self):
        with _lock:
            if self.key in TASKS and not TASKS[self.key].done:
                raise RuntimeError(f"Task {self.key} already running")
            TASKS[self.key] = self
        self.thread.start()

    def _wrap(self):
        try:
            self.run()
        except Exception as e:
            self.error = f"{type(e).__name__}: {e}"
        finally:
            self.done = True

    def stop(self):
        self.stop_evt.set()
        self.thread.join(3)

    def info(self) -> dict:
        return {"key": self.key, "kind": type(self).__name__, "config": self.cfg, "sent": self.sent, "error": self.error,
                "running": not self.done, "started_by": self.user, "uptime_s": round(time.time() - self.started, 1)}


class DbcGenerator(BaseTask):
    """Periodic traffic from a DBC (cycle time from the DBC, else 100 ms). Signals follow slow sine waves inside
    their DBC min/max — synthetic data for SIL and decoder testing, never real vehicle behaviour."""

    def __init__(self, key, cfg, user, db_text: str, messages: list[str] | None):
        super().__init__(key, cfg, user)
        import cantools
        self.db = cantools.database.load_string(db_text, database_format="dbc")
        self.msgs = [m for m in self.db.messages if not messages or m.name in messages]
        self.counters: dict = {}

    def _values(self, m, t: float) -> dict:
        vals = {}
        for i, s in enumerate(m.signals):
            if any(k in s.name.lower() for k in ("alive", "counter", "rolling")):  # rolling counters increment by 1
                key = (m.frame_id, s.name)
                self.counters[key] = (self.counters.get(key, -1) + 1) % (2 ** s.length)
                vals[s.name] = self.counters[key]
                continue
            if s.choices:
                keys = sorted(int(k) for k in s.choices)
                vals[s.name] = keys[int(t / 2 + i) % len(keys)]
                continue
            lo = s.minimum if s.minimum is not None else 0
            hi = s.maximum if s.maximum is not None else (lo + (2 ** min(s.length, 16) - 1) * (s.scale or 1))
            mid, amp = (lo + hi) / 2, (hi - lo) / 2 * 0.8
            v = mid + amp * math.sin(t * (0.3 + 0.1 * i))
            scale = s.scale or 1
            vals[s.name] = round(v / scale) * scale
        return vals

    def run(self):
        import can
        bus, _ = open_can_bus(self.cfg | {"listen_only": False})
        try:
            nxt = {m.frame_id: time.time() for m in self.msgs}
            while not self.stop_evt.is_set():
                now = time.time()
                for m in self.msgs:
                    if now >= nxt[m.frame_id]:
                        data = m.encode(self._values(m, now - self.started), strict=False)
                        bus.send(can.Message(arbitration_id=m.frame_id, data=data, is_extended_id=m.is_extended_frame,
                                             is_fd=m.is_fd))
                        self.sent += 1
                        nxt[m.frame_id] += (m.cycle_time or 100) / 1000
                time.sleep(max(0.001, min(nxt.values()) - time.time()))
        finally:
            bus.shutdown()


class CanReplay(BaseTask):
    def __init__(self, key, cfg, user, capture_id: int, speed: float, loop: bool):
        super().__init__(key, cfg, user)
        self.capture_id, self.speed, self.loop = capture_id, speed, loop

    def run(self):
        import can
        frames = [r for r in read_records(self.capture_id) if not r.get("err")]
        if not frames:
            raise RuntimeError("capture has no frames")
        bus, _ = open_can_bus(self.cfg | {"listen_only": False})
        try:
            while not self.stop_evt.is_set():
                t0, w0 = frames[0]["t"], time.time()
                for r in frames:
                    if self.stop_evt.is_set():
                        break
                    delay = (r["t"] - t0) / self.speed - (time.time() - w0)
                    while delay > 0 and not self.stop_evt.is_set():  # time.sleep: precise on Windows
                        time.sleep(min(delay, 0.05))
                        delay = (r["t"] - t0) / self.speed - (time.time() - w0)
                    bus.send(can.Message(arbitration_id=r["id"], data=bytes.fromhex(r["data"]), is_extended_id=r["ext"],
                                         is_fd=r.get("fd", False)))
                    self.sent += 1
                if not self.loop:
                    break
        finally:
            bus.shutdown()


# ---------------------------------------------------------------- serial
def open_serial(cfg: dict):
    import serial
    return serial.serial_for_url(cfg["port"], baudrate=int(cfg.get("baudrate", 115200)),
                                 bytesize=int(cfg.get("bytesize", 8)), parity=cfg.get("parity", "N"),
                                 stopbits=float(cfg.get("stopbits", 1)), timeout=0.2)


def nmea_sentence(body: str) -> bytes:
    return f"${body}*{nmea_checksum(body)}\r\n".encode()


class SerialSession(BaseSession):
    kind = "serial"

    def __init__(self, capture_id, cfg):
        super().__init__(capture_id, cfg)
        self.port = None
        self.counts: dict[str, int] = defaultdict(int)
        self.bad_checksum = 0
        self.bytes = 0
        self.ubx = UbxParser()
        self.tx_queue: deque = deque()

    def _simulate(self, t: float) -> bytes:
        """Synthetic NMEA/UBX source for loop:// ports (decoder and pipeline testing only)."""
        k = self.seq
        hh, mm, ss = time.gmtime(t)[3:6]
        lat = 5221.0 + 0.001 * math.sin(t / 10)
        out = nmea_sentence(f"GPGGA,{hh:02d}{mm:02d}{ss:02d}.00,{lat:.4f},N,00445.0000,E,1,12,0.8,12.0,M,46.0,M,,")
        if self.cfg.get("simulate") == "ubx":
            p = bytearray(92)
            p[20], p[23] = 3, 12
            import struct
            struct.pack_into("<ii", p, 24, int(4.75e7 + k), int(52.36e7))
            out = build_ubx(0x01, 0x07, bytes(p))
        return out

    def run(self):
        self.port = open_serial(self.cfg)
        mode = self.cfg.get("decoder", "ascii")
        sim = self.cfg.get("simulate")
        rate = float(self.cfg.get("simulate_rate_hz", 10))
        nxt = time.time()
        buf = bytearray()
        try:
            while not self.stop_evt.is_set():
                if sim and self.cfg["port"].startswith("loop://") and time.time() >= nxt:
                    self.port.write(self._simulate(time.time()))
                    nxt += 1 / rate
                while self.tx_queue:
                    self.port.write(self.tx_queue.popleft())
                data = self.port.read(self.port.in_waiting or 1)
                if not data:
                    continue
                self.bytes += len(data)
                t = round(time.time(), 6)
                if mode == "ubx":
                    for f in self.ubx.feed(data):
                        self.counts[f["name"]] += 1
                        self.bad_checksum += 0 if f["checksum_ok"] else 1
                        self.add({"t": t, "decoded": f})
                    continue
                if mode == "raw":
                    self.add({"t": t, "hex": data.hex()})
                    continue
                buf += data
                while b"\n" in buf:
                    line, _, rest = bytes(buf).partition(b"\n")
                    buf = bytearray(rest)
                    text = line.decode("ascii", "replace").rstrip("\r")
                    rec = {"t": t, "text": text}
                    if mode == "nmea":
                        d = decode_nmea(text)
                        if d:
                            rec["decoded"] = d
                            self.counts[d["sentence"]] += 1
                            self.bad_checksum += 1 if d["checksum_ok"] is False else 0
                    else:
                        self.counts["line"] += 1
                    self.add(rec)
        finally:
            self.port.close()

    def write(self, data: bytes):
        self.tx_queue.append(data)

    def stats(self) -> dict:
        dur = max(1e-6, time.time() - self.started)
        return {"records": self.seq, "bytes": self.bytes, "by_type": dict(self.counts), "bad_checksum": self.bad_checksum,
                "rates_hz": {k: round(v / dur, 2) for k, v in self.counts.items()}, "duration_s": round(dur, 1)}


# ---------------------------------------------------------------- UDP
class UdpSession(BaseSession):
    kind = "udp"

    def __init__(self, capture_id, cfg):
        super().__init__(capture_id, cfg)
        self.sources: dict[str, int] = defaultdict(int)
        self.bytes = 0

    def run(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((self.cfg.get("host", "127.0.0.1"), int(self.cfg["port"])))
        s.settimeout(0.2)
        try:
            while not self.stop_evt.is_set():
                try:
                    data, addr = s.recvfrom(65535)
                except socket.timeout:
                    continue
                src = f"{addr[0]}:{addr[1]}"
                self.sources[src] += 1
                self.bytes += len(data)
                self.add({"t": round(time.time(), 6), "src": src, "len": len(data), "hex": data[:64].hex()})
        finally:
            s.close()

    def stats(self) -> dict:
        dur = max(1e-6, time.time() - self.started)
        return {"records": self.seq, "bytes": self.bytes, "packets_per_s": round(self.seq / dur, 2),
                "mbit_per_s": round(self.bytes * 8 / dur / 1e6, 4), "sources": dict(self.sources),
                "duration_s": round(dur, 1)}


# ---------------------------------------------------------------- records on disk
def read_records(cid: int, after: int = 0, limit: int | None = None) -> list[dict]:
    f = capture_file(cid)
    if not f.exists():
        return []
    s = SESSIONS.get(cid)
    if s:
        s.file.flush()
    out = []
    with open(f, encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            r = json.loads(line)
            if r["seq"] > after:
                out.append(r)
                if limit and len(out) >= limit:
                    break
    return out


def stop_all():
    for s in list(SESSIONS.values()):
        s.stop(1)
    for t in list(TASKS.values()):
        if not t.done:
            t.stop()
