"""SCPI over raw TCP (port 5025, newline-terminated) and a virtual programmable power supply.

The client is generic (any LXI/SCPI instrument). Physical instruments are `experimental`: the command set used here
(*IDN?, OUTP, VOLT, CURR, MEAS:VOLT?, MEAS:CURR?) is common to bench PSUs, but no physical unit was tested in
this build. The virtual PSU runs inside the backend on 127.0.0.1 and models a resistive load with a current limit.
"""
from __future__ import annotations

import socket
import threading

_LOCK = threading.Lock()
VIRTUAL: dict[str, "VirtualPsu"] = {}


class ScpiClient:
    def __init__(self, host: str, port: int = 5025, timeout: float = 2.0):
        self.host, self.port, self.timeout = host, port, timeout

    def _io(self, cmds: list[str]) -> list[str]:
        out = []
        with socket.create_connection((self.host, self.port), timeout=self.timeout) as s:
            f = s.makefile("rwb")
            for c in cmds:
                f.write((c.strip() + "\n").encode())
                f.flush()
                if c.strip().endswith("?"):
                    line = f.readline()
                    if not line:
                        raise ConnectionError(f"no reply to {c}")
                    out.append(line.decode(errors="replace").strip())
        return out

    def query(self, cmd: str) -> str:
        return self._io([cmd])[0]

    def write(self, cmd: str) -> None:
        self._io([cmd])

    def status(self) -> dict:
        idn, outp, v, i, vset, ilim = self._io(["*IDN?", "OUTP?", "MEAS:VOLT?", "MEAS:CURR?", "VOLT?", "CURR?"])
        return {"idn": idn, "output_on": outp.strip() in ("1", "ON"), "voltage_v": float(v), "current_a": float(i),
                "voltage_set_v": float(vset), "current_limit_a": float(ilim)}


class VirtualPsu:
    """Single-channel PSU model: V_out = setpoint when on; I = V/R, limited by the current limit (then CC mode)."""

    def __init__(self, name: str, load_ohm: float = 12.0, voltage: float = 0.0, current_limit: float = 3.0):
        self.name, self.load, self.vset, self.ilim, self.on = name, load_ohm, voltage, current_limit, False
        self.srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("127.0.0.1", 0))
        self.srv.listen(8)
        self.port = self.srv.getsockname()[1]
        self.stop_evt = threading.Event()
        threading.Thread(target=self._serve, daemon=True, name=f"vpsu-{name}").start()

    def _out(self) -> tuple[float, float]:
        if not self.on:
            return 0.0, 0.0
        i = self.vset / self.load if self.load > 0 else self.ilim
        if i > self.ilim:  # constant-current mode
            return round(self.ilim * self.load, 4), round(self.ilim, 4)
        return round(self.vset, 4), round(i, 4)

    def handle(self, cmd: str) -> str | None:
        c = cmd.strip().upper()
        arg = c.split(" ", 1)[1] if " " in c else ""
        if c == "*IDN?":
            return f"INTEGRA,VirtualPSU,{self.name},1.0"
        if c in ("OUTP?", "OUTPUT?"):
            return "1" if self.on else "0"
        if c.startswith(("OUTP ", "OUTPUT ")):
            self.on = arg in ("1", "ON")
            return None
        if c in ("VOLT?", "SOUR:VOLT?"):
            return f"{self.vset:.4f}"
        if c.startswith(("VOLT ", "SOUR:VOLT ")):
            self.vset = max(0.0, min(60.0, float(arg)))
            return None
        if c in ("CURR?", "SOUR:CURR?"):
            return f"{self.ilim:.4f}"
        if c.startswith(("CURR ", "SOUR:CURR ")):
            self.ilim = max(0.0, min(20.0, float(arg)))
            return None
        if c == "MEAS:VOLT?":
            return f"{self._out()[0]:.4f}"
        if c == "MEAS:CURR?":
            return f"{self._out()[1]:.4f}"
        if c.endswith("?"):
            return "ERR:UNKNOWN"
        return None

    def _client(self, conn: socket.socket):
        with conn, conn.makefile("rwb") as f:
            for line in f:
                try:
                    r = self.handle(line.decode(errors="replace"))
                except ValueError:
                    r = "ERR:VALUE" if line.strip().endswith(b"?") else None
                if r is not None:
                    f.write((r + "\n").encode())
                    f.flush()

    def _serve(self):
        self.srv.settimeout(0.5)
        while not self.stop_evt.is_set():
            try:
                conn, _ = self.srv.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._client, args=(conn,), daemon=True).start()

    def close(self):
        self.stop_evt.set()
        self.srv.close()


def virtual_psu(key: str, **kw) -> VirtualPsu:
    """Get or start the virtual PSU registered under `key` (one per rig component)."""
    with _LOCK:
        if key not in VIRTUAL:
            VIRTUAL[key] = VirtualPsu(key, **kw)
        return VIRTUAL[key]


def endpoint(props: dict, key: str) -> tuple[str, int, bool] | None:
    """(host, port, virtual) for a rig component's `scpi` properties."""
    sc = (props or {}).get("scpi")
    if not sc:
        return None
    if sc.get("virtual"):
        p = virtual_psu(key, load_ohm=float(sc.get("load_ohm", 12)), voltage=float(sc.get("voltage", 0)),
                        current_limit=float(sc.get("current_limit", 3)))
        return "127.0.0.1", p.port, True
    return str(sc["host"]), int(sc.get("port", 5025)), False
