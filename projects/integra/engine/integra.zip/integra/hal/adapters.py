"""Adapter registry: what this build can actually do, and what is available on *this* host.

status:
  available     implemented and covered by automated tests in this build
  experimental  implemented through a vendor-neutral library (python-can / pyserial) but NOT verified against
                physical hardware by the INTEGRA team; use with an authorised, isolated setup
  planned       not implemented
host_available: whether the driver/library needed is present on the machine running the backend right now.
"""
from __future__ import annotations

import importlib.util
import logging
import platform

for _n in ("can", "can.interfaces", "can.pcan", "can.interfaces.vector", "can.interfaces.ixxat", "can.interfaces.kvaser",
           "can.interfaces.ics_neovi", "can.interfaces.socketcan", "can.interfaces.udp_multicast"):
    logging.getLogger(_n).setLevel(logging.ERROR)

CAN_PHYSICAL = {
    "pcan": "PEAK PCAN (PCANBasic driver)",
    "vector": "Vector XL (vxlapi)",
    "kvaser": "Kvaser CANlib",
    "socketcan": "Linux SocketCAN",
    "slcan": "Serial-line CAN (slcan/LAWICEL)",
    "gs_usb": "gs_usb / candleLight",
    "ixxat": "IXXAT VCI",
}


def _has(mod: str) -> bool:
    return importlib.util.find_spec(mod) is not None


def _host_can(name: str) -> tuple[bool, str]:
    sysname = platform.system()
    if name == "socketcan":
        return (sysname == "Linux", "Linux only" if sysname != "Linux" else "kernel SocketCAN")
    if name == "pcan":
        import ctypes.util
        lib = ctypes.util.find_library("PCANBasic") or ctypes.util.find_library("pcanbasic")
        return (bool(lib), "PCANBasic library found" if lib else "PCANBasic driver not installed")
    if name == "vector":
        import ctypes.util
        lib = ctypes.util.find_library("vxlapi64") or ctypes.util.find_library("vxlapi")
        return (bool(lib), "vxlapi found" if lib else "Vector XL driver library not installed")
    if name == "kvaser":
        import ctypes.util
        lib = ctypes.util.find_library("canlib32") or ctypes.util.find_library("canlib")
        return (bool(lib), "canlib found" if lib else "Kvaser CANlib not installed")
    if name == "slcan":
        return (_has("serial"), "pyserial present (needs an slcan device on a serial port)")
    if name == "gs_usb":
        return (_has("usb"), "pyusb present" if _has("usb") else "pyusb/libusb not installed")
    if name == "ixxat":
        return (False, "IXXAT VCI driver not detected")
    return (False, "")


def registry() -> list[dict]:
    out = [
        {"key": "can.virtual", "title": "CAN / CAN FD — virtual bus (python-can)", "phase": 3, "status": "available",
         "host_available": _has("can"), "host_note": "in-process isolated bus; never reaches a physical network"},
    ]
    for k, t in CAN_PHYSICAL.items():
        ok, note = _host_can(k)
        out.append({"key": f"can.{k}", "title": f"CAN / CAN FD — {t}", "phase": 3, "status": "experimental",
                    "host_available": ok, "host_note": note})
    out += [
        {"key": "dbc", "title": "DBC import & decode (cantools)", "phase": 3, "status": "available",
         "host_available": _has("cantools"), "host_note": ""},
        {"key": "serial", "title": "Serial / UART capture (pyserial, incl. loop:// and socket:// URLs)", "phase": 3,
         "status": "available", "host_available": _has("serial"), "host_note": "physical COM/tty ports: experimental"},
        {"key": "nmea_ubx", "title": "NMEA 0183 / UBX decoders", "phase": 3, "status": "available",
         "host_available": True, "host_note": ""},
        {"key": "ethernet", "title": "Ethernet diagnostics (interfaces, TCP probe, UDP capture)", "phase": 3,
         "status": "available", "host_available": _has("psutil"), "host_note": ""},
        {"key": "discovery", "title": "Device discovery (USB/PnP, serial, CAN, network)", "phase": 3,
         "status": "available", "host_available": True, "host_note": platform.system()},
        {"key": "git", "title": "Git repositories (read-only)", "phase": 3, "status": "available",
         "host_available": True, "host_note": ""},
        {"key": "lin", "title": "LIN (LDF) via supported hardware", "phase": 3, "status": "planned",
         "host_available": False, "host_note": "needs a LIN interface and vendor API"},
        {"key": "ssh", "title": "Remote Linux target diagnostics over SSH", "phase": 3, "status": "planned",
         "host_available": False, "host_note": "host diagnostics run on the backend machine only"},
        {"key": "ros2", "title": "ROS 2", "phase": 6, "status": "planned", "host_available": False, "host_note": ""},
        {"key": "gazebo", "title": "Gazebo", "phase": 6, "status": "planned", "host_available": False, "host_note": ""},
        {"key": "carla", "title": "CARLA", "phase": 6, "status": "planned", "host_available": False, "host_note": ""},
        {"key": "simulink", "title": "MATLAB/Simulink", "phase": 6, "status": "planned", "host_available": False,
         "host_note": ""},
        {"key": "github_actions", "title": "GitHub Actions (read-only REST API: workflow runs)", "phase": 7,
         "status": "available", "host_available": True,
         "host_note": "needs network access to the API; optional token from an environment variable"},
        {"key": "gitlab_ci", "title": "GitLab CI", "phase": 7, "status": "planned", "host_available": False, "host_note": ""},
        {"key": "jenkins", "title": "Jenkins", "phase": 7, "status": "planned", "host_available": False, "host_note": ""},
    ]
    return out


def can_interfaces() -> list[dict]:
    return [r | {"interface": r["key"].split(".", 1)[1]} for r in registry() if r["key"].startswith("can.")]
