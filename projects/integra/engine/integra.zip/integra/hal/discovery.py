"""Device discovery on the machine running the backend. Read-only: enumerates, never opens or configures devices.

Sources: pyserial port list; USB/PnP devices (Windows: Get-PnpDevice, Linux: /sys/bus/usb); python-can
detect_available_configs; network interfaces (psutil). Detected devices are matched to inventory hardware by
serial number or by a `usb_vid_pid` / `detect_pattern` entry in the hardware item's specifications.
"""
from __future__ import annotations

import json
import platform
import re
import subprocess
from pathlib import Path

from sqlalchemy.orm import Session

from .. import models as M

VIDPID = re.compile(r"VID_([0-9A-F]{4})&PID_([0-9A-F]{4})", re.I)


def _serial_ports() -> list[dict]:
    from serial.tools import list_ports
    out = []
    for p in list_ports.comports():
        out.append({"bus": "serial", "identifier": p.device, "description": p.description or p.device,
                    "manufacturer": p.manufacturer, "serial_number": p.serial_number,
                    "vid_pid": f"{p.vid:04X}:{p.pid:04X}" if p.vid is not None and p.pid is not None else None,
                    "driver": None, "driver_status": "OK",
                    "details": {"hwid": p.hwid, "location": p.location, "interface": p.interface}})
    return out


def _usb_windows() -> list[dict]:
    cmd = ["powershell", "-NoProfile", "-NonInteractive", "-Command",
           "Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB*' } | "
           "Select-Object FriendlyName, InstanceId, Status, Class, Manufacturer, Service | ConvertTo-Json -Compress"]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if r.returncode != 0 or not r.stdout.strip():
        return []
    data = json.loads(r.stdout)
    data = data if isinstance(data, list) else [data]
    out = []
    for d in data:
        iid = d.get("InstanceId") or ""
        m = VIDPID.search(iid)
        tail = iid.split("\\")[-1]
        out.append({"bus": "usb", "identifier": iid, "description": d.get("FriendlyName"),
                    "manufacturer": d.get("Manufacturer"),
                    "serial_number": tail if tail and "&" not in tail else None,
                    "vid_pid": f"{m.group(1).upper()}:{m.group(2).upper()}" if m else None,
                    "driver": d.get("Service"), "driver_status": d.get("Status"),
                    "details": {"class": d.get("Class")}})
    return out


def _usb_linux() -> list[dict]:
    base = Path("/sys/bus/usb/devices")
    out = []
    if not base.exists():
        return out

    def rd(p: Path, f: str):
        try:
            return (p / f).read_text().strip()
        except OSError:
            return None
    for dev in base.iterdir():
        vid, pid = rd(dev, "idVendor"), rd(dev, "idProduct")
        if not vid:
            continue
        drivers = sorted({(i / "driver").resolve().name for i in dev.glob(f"{dev.name}:*") if (i / "driver").exists()})
        out.append({"bus": "usb", "identifier": dev.name, "description": rd(dev, "product"),
                    "manufacturer": rd(dev, "manufacturer"), "serial_number": rd(dev, "serial"),
                    "vid_pid": f"{vid.upper()}:{pid.upper()}", "driver": ", ".join(drivers) or None,
                    "driver_status": "OK" if drivers else "no driver bound", "details": {}})
    return out


def _can_configs() -> list[dict]:
    import can
    from .adapters import CAN_PHYSICAL
    out = []
    try:
        cfgs = can.detect_available_configs(interfaces=list(CAN_PHYSICAL))
    except Exception:  # pragma: no cover - vendor library errors
        cfgs = []
    for c in cfgs:
        ident = f"{c.get('interface')}:{c.get('channel')}"
        out.append({"bus": "can", "identifier": ident, "description": f"{c.get('interface')} channel {c.get('channel')}",
                    "manufacturer": None, "serial_number": str(c.get("serial_number") or "") or None, "vid_pid": None,
                    "driver": c.get("interface"), "driver_status": "OK",
                    "details": {k: v for k, v in c.items() if isinstance(v, (str, int, float, bool))}})
    return out


def _network() -> list[dict]:
    import psutil
    stats = psutil.net_if_stats()
    out = []
    for name, addrs in psutil.net_if_addrs().items():
        st = stats.get(name)
        mac = next((a.address for a in addrs if getattr(a.family, "name", "") in ("AF_LINK", "AF_PACKET")), None)
        out.append({"bus": "network", "identifier": name, "description": name, "manufacturer": None,
                    "serial_number": mac, "vid_pid": None, "driver": None,
                    "driver_status": "up" if st and st.isup else "down",
                    "details": {"addresses": [a.address for a in addrs if a.family.name in ("AF_INET", "AF_INET6")],
                                "speed_mbps": st.speed if st else None, "mtu": st.mtu if st else None}})
    return out


def scan_host() -> tuple[list[dict], list[str]]:
    """Return (detections, warnings)."""
    found, warnings = [], []
    sources = [("serial", _serial_ports), ("can", _can_configs), ("network", _network),
               ("usb", _usb_windows if platform.system() == "Windows" else _usb_linux)]
    for name, fn in sources:
        try:
            found += fn()
        except Exception as e:  # keep scanning other buses
            warnings.append(f"{name}: {e}")
    return found, warnings


def _match(d: dict, items: list[M.HardwareItem]) -> tuple[int | None, str | None]:
    for h in items:
        spec = h.specifications or {}
        sn = (h.serial_number or "").strip()
        if sn and d.get("serial_number") and sn.lower() == str(d["serial_number"]).lower():
            return h.id, "serial number"
        vp = str(spec.get("usb_vid_pid", "")).upper()
        if vp and d.get("vid_pid") and vp == d["vid_pid"].upper():
            return h.id, "USB VID:PID"
        pat = spec.get("detect_pattern")
        if pat:
            try:
                if re.search(pat, f"{d.get('identifier')} {d.get('description')}", re.I):
                    return h.id, f"pattern {pat}"
            except re.error:
                pass
    return None, None


def persist(db: Session, detections: list[dict], buses: set[str]) -> list[M.DetectedDevice]:
    items = db.query(M.HardwareItem).filter(M.HardwareItem.status != "retired").all()
    now = M.utcnow()
    seen = set()
    rows = []
    for d in detections:
        row = db.query(M.DetectedDevice).filter_by(bus=d["bus"], identifier=d["identifier"][:300]).first()
        if row is None:
            row = M.DetectedDevice(bus=d["bus"], identifier=d["identifier"][:300], first_seen=now)
            db.add(row)
        for k in ("description", "manufacturer", "serial_number", "vid_pid", "driver", "driver_status", "details"):
            setattr(row, k, d.get(k))
        if row.match_rule != "manual":
            row.hardware_id, row.match_rule = _match(d, items)
        row.present, row.last_seen = True, now
        seen.add((row.bus, row.identifier))
        rows.append(row)
    for row in db.query(M.DetectedDevice).filter(M.DetectedDevice.bus.in_(buses)):
        if (row.bus, row.identifier) not in seen:
            row.present = False
    return rows
