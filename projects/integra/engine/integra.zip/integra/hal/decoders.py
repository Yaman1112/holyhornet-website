"""Protocol decoders for serial data. Pluggable: register a function in DECODERS(name) -> callable."""
from __future__ import annotations

import struct
from functools import reduce


def nmea_checksum(body: str) -> str:
    return f"{reduce(lambda a, c: a ^ ord(c), body, 0):02X}"


def decode_nmea(line: str) -> dict | None:
    line = line.strip()
    if not line.startswith(("$", "!")):
        return None
    body, _, cs = line[1:].partition("*")
    fields = body.split(",")
    out = {"protocol": "NMEA 0183", "talker": fields[0][:2], "sentence": fields[0][2:], "fields": fields[1:],
           "checksum_ok": (cs[:2].upper() == nmea_checksum(body)) if cs else None}
    if out["sentence"] == "GGA" and len(fields) >= 10:
        out["values"] = {"utc": fields[1], "lat": _nmea_deg(fields[2], fields[3]), "lon": _nmea_deg(fields[4], fields[5]),
                         "fix_quality": fields[6], "satellites": fields[7], "hdop": fields[8], "alt_m": fields[9]}
    elif out["sentence"] == "RMC" and len(fields) >= 9:
        out["values"] = {"utc": fields[1], "status": fields[2], "lat": _nmea_deg(fields[3], fields[4]),
                         "lon": _nmea_deg(fields[5], fields[6]), "speed_kn": fields[7], "course": fields[8]}
    return out


def _nmea_deg(v: str, hemi: str) -> float | None:
    try:
        dot = v.index(".")
        deg = float(v[:dot - 2]) + float(v[dot - 2:]) / 60
        return round(-deg if hemi in ("S", "W") else deg, 7)
    except (ValueError, IndexError):
        return None


def ubx_checksum(payload: bytes) -> bytes:
    a = b = 0
    for x in payload:
        a = (a + x) & 0xFF
        b = (b + a) & 0xFF
    return bytes([a, b])


UBX_NAMES = {(0x01, 0x07): "NAV-PVT", (0x01, 0x03): "NAV-STATUS", (0x05, 0x01): "ACK-ACK", (0x05, 0x00): "ACK-NAK",
             (0x0A, 0x04): "MON-VER"}


class UbxParser:
    """Incremental UBX frame parser (sync 0xB5 0x62, class, id, little-endian length, payload, 2-byte Fletcher)."""

    def __init__(self):
        self.buf = bytearray()

    def feed(self, data: bytes) -> list[dict]:
        self.buf += data
        out = []
        while True:
            i = self.buf.find(b"\xb5\x62")
            if i < 0:
                self.buf = self.buf[-1:]
                return out
            del self.buf[:i]
            if len(self.buf) < 6:
                return out
            cls, mid = self.buf[2], self.buf[3]
            (ln,) = struct.unpack_from("<H", self.buf, 4)
            if ln > 4096:
                del self.buf[:2]
                continue
            if len(self.buf) < 8 + ln:
                return out
            frame = bytes(self.buf[:8 + ln])
            del self.buf[:8 + ln]
            ok = ubx_checksum(frame[2:6 + ln]) == frame[6 + ln:8 + ln]
            d = {"protocol": "UBX", "class": cls, "id": mid, "name": UBX_NAMES.get((cls, mid), f"0x{cls:02X}-0x{mid:02X}"),
                 "length": ln, "checksum_ok": ok}
            if ok and (cls, mid) == (0x01, 0x07) and ln >= 92:
                p = frame[6:6 + ln]
                lon, lat = struct.unpack_from("<ii", p, 24)
                d["values"] = {"fix_type": p[20], "num_sv": p[23], "lon": lon * 1e-7, "lat": lat * 1e-7,
                               "h_msl_m": struct.unpack_from("<i", p, 36)[0] / 1000}
            out.append(d)


def build_ubx(cls: int, mid: int, payload: bytes) -> bytes:
    head = bytes([cls, mid]) + struct.pack("<H", len(payload)) + payload
    return b"\xb5\x62" + head + ubx_checksum(head)


DECODERS = {"none": None, "ascii": "ascii", "nmea": decode_nmea, "ubx": "ubx"}
