"""Authorisation gate for potentially disruptive physical operations (transmit, replay, traffic generation).

Virtual interfaces (python-can 'virtual', pyserial 'loop://') are isolated and never need authorisation.
A physical operation needs an APPROVED, unexpired authorisation for the same interface + channel that lists the
action, was approved by someone other than the requester, and confirms isolation from vehicle networks.
"""
from __future__ import annotations

from fastapi import HTTPException
from sqlalchemy.orm import Session

from .. import models as M


def is_virtual(interface: str, channel: str = "") -> bool:
    if interface == "virtual":
        return True
    if interface == "serial" and channel.startswith("loop://"):
        return True
    return False


def find_authorization(db: Session, interface: str, channel: str, action: str) -> M.DeviceAuthorization | None:
    now = M.utcnow()
    for a in db.query(M.DeviceAuthorization).filter_by(interface=interface, channel=channel, status="approved"):
        if action in (a.actions or []) and a.isolation_confirmed and a.valid_until and a.valid_until > now:
            return a
    return None


def require(db: Session, interface: str, channel: str, action: str) -> M.DeviceAuthorization | None:
    """Return the authorisation used (None for virtual interfaces) or raise 403."""
    if is_virtual(interface, channel):
        return None
    a = find_authorization(db, interface, channel, action)
    if a is None:
        raise HTTPException(403, {"message": f"'{action}' on physical interface {interface}:{channel} requires an "
                                             "approved, unexpired authorisation with confirmed isolation",
                                  "interface": interface, "channel": channel, "action": action})
    return a
