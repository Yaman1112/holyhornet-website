"""Schema creation and the demonstration dataset.

The demo dataset is clearly labelled (`data_source = demo_seed`, fictional customers, fictional serial numbers).
Product names of commercially available components are used only as inventory records — they do NOT imply that
INTEGRA has a tested adapter for that device. Electrical values are left blank unless stated in `notes`.
"""
from __future__ import annotations

import hashlib
import logging
from datetime import date, datetime, timedelta
from pathlib import Path

from sqlalchemy import inspect
from sqlalchemy.orm import Session

from . import models as M
from .db import get_engine, session_scope
from .security import hash_password
from .services.records import record_revision

log = logging.getLogger("integra")
SCHEMA_VERSION = 1

DEMO_USERS = [
    ("admin", "Avery Admin", "ADMIN", "Admin#2026!"),
    ("swint", "Sam Integration", "SW_INTEGRATION", "Swint#2026!"),
    ("embedded", "Emery Embedded", "EMBEDDED_SW", "Embedded#2026!"),
    ("hardware", "Harper Hardware", "HARDWARE", "Hardware#2026!"),
    ("electrical", "Eli Electrical", "ELECTRICAL", "Electric#2026!"),
    ("mechanical", "Morgan Mechanical", "MECHANICAL", "Mechanic#2026!"),
    ("systems", "Sky Systems", "SYSTEMS", "Systems#2026!"),
    ("test", "Taylor Test", "TEST", "Tester#2026!"),
    ("pm", "Parker Manager", "PROJECT_MANAGER", "Manager#2026!"),
    ("customer", "Casey Customer", "CUSTOMER_VIEWER", "Customer#2026!"),
]


MIGRATIONS = Path(__file__).resolve().parent / "migrations"


def migrate() -> None:
    """Bring the database to the latest Alembic revision. Databases created by the pre-Alembic Phase 1 build
    (tables present, no alembic_version) are stamped at the baseline 0001 first."""
    from alembic import command
    from alembic.config import Config
    engine = get_engine()
    cfg = Config()
    cfg.set_main_option("script_location", str(MIGRATIONS))
    tables = set(inspect(engine).get_table_names())
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        if "users" in tables and "alembic_version" not in tables:
            command.stamp(cfg, "0001")
        command.upgrade(cfg, "head")


def init_db() -> None:
    from . import config
    if not config.browser():  # the browser edition ships a database already at the head revision
        migrate()
    with session_scope() as db:
        sv = db.query(M.SchemaVersion).first()
        if not sv:
            db.add(M.SchemaVersion(version=SCHEMA_VERSION))
        elif sv.version != SCHEMA_VERSION:
            sv.version, sv.applied_at = SCHEMA_VERSION, M.utcnow()


def seed_demo() -> bool:
    with session_scope() as db:
        if db.query(M.User).first():
            return False
        users = {}
        for un, name, role, pw in DEMO_USERS:
            u = M.User(username=un, full_name=name, role=role, password_hash=hash_password(pw),
                       email=f"{un}@integra.example")
            db.add(u)
            users[un] = u
        db.flush()
        _demo_projects(db, users)
        log.info("Demo dataset created")
        return True


def _demo_projects(db: Session, U: dict[str, M.User]) -> None:
    today = date.today()
    d = lambda n: today + timedelta(days=n)  # noqa: E731

    northline = M.Customer(name="Northline Freight Robotics (fictional)", industry="Autonomous trucking",
                           contact_name="J. Varga", contact_email="integration@northline.example",
                           address="Demo data - fictional customer", notes="Demo customer")
    helix = M.Customer(name="Helix Intralogistics (fictional)", industry="Warehouse robotics",
                       contact_name="R. Okafor", contact_email="eng@helix.example", notes="Demo customer")
    db.add_all([northline, helix])
    db.flush()

    p1 = M.Project(
        code=f"INT-{today.year}-001", name="Hub-to-hub truck autonomy compute integration", customer_id=northline.id,
        domain="autonomous_trucking", stage="requirements_pending", priority="high",
        description="Integrate an autonomy compute unit, long-range sensor suite and vehicle gateway into the "
                    "customer's Class 8 tractor platform. Lab integration and HIL first; no vehicle actuation "
                    "without operator authorisation.",
        objectives=["Deliver a validated sensing + compute stack on the customer bench",
                    "Demonstrate perception data path end-to-end on HIL",
                    "Hand over a configuration baseline with full requirements traceability"],
        use_cases=["Highway hub-to-hub driving (operator supervised)", "Depot yard manoeuvring at low speed"],
        validation_criteria=["All mandatory requirements passed with evidence", "Customer FAT signed"],
        lead_engineer_id=U["swint"].id, start_date=d(-75), target_date=d(110),
        internal_notes="Customer gateway ECU firmware drop expected late; keep CAN DBC under change control.")
    p2 = M.Project(
        code=f"INT-{today.year}-002", name="AMR sensor suite retrofit", customer_id=helix.id, domain="robotics",
        stage="requirements_pending", priority="medium",
        description="Retrofit 2D safety LiDAR, depth cameras and an embedded computer onto an existing AMR fleet.",
        objectives=["Replace end-of-life sensors without changing the navigation stack interface"],
        use_cases=["Pallet transport in mixed human/robot aisles"], lead_engineer_id=U["systems"].id,
        start_date=d(-10), target_date=d(150))
    db.add_all([p1, p2])
    db.flush()
    for p in (p1, p2):
        db.add(M.StageHistory(project_id=p.id, to_stage="requirements_pending", changed_by="pm", note="Project created"))
    for stage in ("architecture_in_progress", "hardware_preparation", "software_preparation", "component_integration"):
        db.add(M.StageHistory(project_id=p1.id, from_stage=p1.stage, to_stage=stage, changed_by="pm"))
        p1.stage = stage
    db.add(M.StageHistory(project_id=p2.id, from_stage=p2.stage, to_stage="architecture_in_progress",
                          changed_by="systems"))
    p2.stage = "architecture_in_progress"

    for un, role in (("swint", "Lead integration engineer"), ("embedded", "Embedded software"),
                     ("hardware", "Sensor & compute hardware"), ("electrical", "Power & harness"),
                     ("test", "Test lead"), ("pm", "Project manager"), ("systems", "Systems engineer"),
                     ("customer", "Customer representative")):
        db.add(M.ProjectMember(project_id=p1.id, user_id=U[un].id, project_role=role))
    for un, role in (("systems", "Lead systems engineer"), ("mechanical", "Mounting & brackets"), ("pm", "PM")):
        db.add(M.ProjectMember(project_id=p2.id, user_id=U[un].id, project_role=role))

    for name, due, status, deliv in (
            ("Requirements baseline", -60, "done", "Signed requirements specification v1.0"),
            ("Architecture freeze", -35, "done", "System architecture & ICD v1.0"),
            ("Bench integration complete", 20, "in_progress", "All sensors streaming on the lab bench"),
            ("HIL campaign", 60, "planned", "HIL test report"),
            ("Customer FAT", 100, "planned", "Factory acceptance test protocol signed")):
        db.add(M.Milestone(project_id=p1.id, name=name, due_date=d(due), status=status, deliverable=deliv,
                           completed_at=M.utcnow() if status == "done" else None))
    db.add(M.Milestone(project_id=p2.id, name="Sensor selection review", due_date=d(14), status="in_progress"))

    # ---------------- hardware (demo records; serials fictional)
    def hw(tag, name, cat, man, model, sn, rev, fw, ifaces, status="in_integration", pid=p1.id, **kw):
        h = M.HardwareItem(asset_tag=tag, name=name, category=cat, manufacturer=man, model=model, serial_number=sn,
                           hardware_revision=rev, firmware_version=fw, interfaces=ifaces, status=status,
                           project_id=pid, data_source="demo_seed", location=kw.pop("location", "Lab bench B2"), **kw)
        db.add(h)
        return h

    H = {
        "orin": hw("HW-0001", "Autonomy compute unit", "nvidia_jetson", "NVIDIA", "Jetson AGX Orin 64GB Developer Kit",
                   "DEMO-ORIN-0193", "A", "Jetson Linux 36.4", ["Ethernet", "USB", "CAN", "GPIO", "MIPI CSI-2", "PCIe"],
                   specifications={"cpu": "12-core Arm Cortex-A78AE", "memory": "64 GB LPDDR5"},
                   driver_requirements="JetPack 6.x BSP; mttcan kernel module for CAN"),
        "cam_f": hw("HW-0002", "Front long-range camera", "camera", "Leopard Imaging", "LI-IMX490-GMSL2",
                    "DEMO-CAM-4471", "B", "1.2.0", ["GMSL"], specifications={"sensor": "Sony IMX490"},
                    driver_requirements="Vendor GMSL2 deserializer driver for Jetson Linux 36.x"),
        "cam_r": hw("HW-0003", "Rear camera", "camera", "Leopard Imaging", "LI-IMX490-GMSL2", "DEMO-CAM-4472", "B",
                    "1.2.0", ["GMSL"], status="faulty", notes="Intermittent link loss on GMSL2 channel; RMA opened"),
        "lidar": hw("HW-0004", "Roof LiDAR", "lidar", "Ouster", "OS1-128", "DEMO-OS1-88812", "Rev 7", "2.5.3",
                    ["Ethernet", "PPS"], specifications={"channels": 128},
                    driver_requirements="ouster-ros driver; PTP/PPS time sync"),
        "radar": hw("HW-0005", "Front long-range radar", "radar", "Continental", "ARS 548 RDI", "DEMO-ARS-20391",
                    "C1", "05.02", ["Automotive Ethernet"], driver_requirements="Vendor UDP interface spec"),
        "gnss": hw("HW-0006", "GNSS receiver", "gnss", "u-blox", "ZED-F9P", "DEMO-F9P-5521", "B", "HPG 1.32",
                   ["UART", "USB", "PPS"], status="available"),
        "imu": hw("HW-0007", "IMU", "imu", "Xsens", "MTi-630", "DEMO-MTI-1180", "1", "1.10.0", ["UART", "USB", "CAN"]),
        "pcan": hw("HW-0008", "CAN FD interface", "can_adapter", "PEAK-System", "PCAN-USB FD", "DEMO-PCAN-30021", "1",
                   "3.2", ["USB", "CAN FD"], status="available", driver_requirements="peak_usb (SocketCAN) kernel driver"),
        "gw": hw("HW-0009", "Vehicle gateway ECU", "automotive_ecu", "Northline (customer supplied)", "VGW-2",
                 "DEMO-VGW-0007", "P3", "0.9.4-rc2", ["CAN FD", "Automotive Ethernet"],
                 notes="Customer prototype. Do not flash firmware without customer authorisation."),
        "psu": hw("HW-0010", "Bench power supply", "power_supply", "Rohde & Schwarz", "NGE103B", "DEMO-NGE-77120",
                  "1", "2.10", ["Ethernet", "USB", "Power"], status="available", pid=None, location="Lab pool"),
        "amr_pc": hw("HW-0011", "AMR embedded computer", "industrial_computer", "OnLogic", "Karbon 410",
                     "DEMO-K410-3310", "A", "BIOS 1.08", ["Ethernet", "USB", "Serial", "CAN"], status="reserved",
                     pid=p2.id, location="Lab bench C1"),
    }
    db.flush()
    db.add(M.HardwareConfigRecord(hardware_id=H["lidar"].id, title="Bench network configuration",
                                  parameters={"ip": "192.168.10.20/24", "lidar_mode": "1024x10",
                                              "timestamp_mode": "TIME_FROM_PTP_1588", "udp_dest": "192.168.10.2"},
                                  recorded_by="hardware"))
    db.add(M.HardwareConfigRecord(hardware_id=H["orin"].id, title="CAN interface bring-up",
                                  parameters={"can0": {"bitrate": 500000, "dbitrate": 2000000, "fd": True}},
                                  notes="ip link set can0 type can bitrate 500000 dbitrate 2000000 fd on",
                                  recorded_by="embedded"))

    # ---------------- software
    def sw(name, kind, lang, ver, status, pid=p1.id, **kw):
        s = M.SoftwareItem(name=name, kind=kind, language=lang, version=ver, status=status, project_id=pid,
                           data_source="demo_seed", **kw)
        db.add(s)
        return s

    S = {
        "l4t": sw("NVIDIA Jetson Linux", "operating_system", "Other", "36.4", "released", pid=None,
                  target_platform="Jetson AGX Orin"),
        "ros": sw("ROS 2 Humble Hawksbill", "middleware", "C++", "humble", "released", pid=None,
                  target_platform="Ubuntu 22.04 aarch64"),
        "cam": sw("gmsl_camera_driver", "device_driver", "C++", "0.9.2", "in_development", build_system="CMake",
                  repository_url="https://git.example/northline/gmsl_camera_driver", commit_ref="a41c9e2",
                  target_platform="Jetson Linux 36.4"),
        "lidar": sw("lidar_ingest", "sensor_processing", "C++", "1.3.0", "integrated", build_system="colcon",
                    commit_ref="7f02d1b", target_platform="ROS 2 Humble / aarch64"),
        "radar": sw("radar_bridge", "communication_service", "C++", "0.4.1", "in_development", build_system="colcon"),
        "fusion": sw("sensor_fusion_node", "sensor_processing", "C++", "2.1.0", "in_development", build_system="colcon"),
        "gw": sw("vehicle_gateway_service", "communication_service", "Python", "0.7.0", "integrated",
                 build_system="pip", description="CAN FD bridge to the customer gateway ECU (read-only in bench mode)"),
        "health": sw("health_monitor", "monitoring_service", "Python", "1.0.0", "released", build_system="pip"),
        "logger": sw("data_logger", "logging", "Python", "0.3.0", "planned"),
    }
    db.flush()
    for src, dst, cons in (("cam", "l4t", ">=36.3"), ("lidar", "ros", "humble"), ("radar", "ros", "humble"),
                           ("fusion", "ros", "humble"), ("fusion", "lidar", ">=1.3"), ("fusion", "radar", ">=0.4"),
                           ("fusion", "cam", ">=0.9"), ("gw", "ros", "humble")):
        db.add(M.SoftwareDependency(software_id=S[src].id, name=S[dst].name, version_constraint=cons,
                                    depends_on_id=S[dst].id))
    db.add(M.SoftwareDependency(software_id=S["gw"].id, name="python-can", version_constraint=">=4.3"))
    db.add(M.SoftwareDependency(software_id=S["gw"].id, name="cantools", version_constraint=">=39"))
    for s, h, st, note in (("cam", "cam_f", "limited", "30 fps only at reduced resolution with driver 0.9.2"),
                           ("cam", "cam_r", "untested", None), ("lidar", "lidar", "compatible", None),
                           ("gw", "gw", "compatible", "Read-only bench mode verified"),
                           ("radar", "radar", "untested", None), ("l4t", "orin", "compatible", None)):
        db.add(M.HardwareCompatibility(software_id=S[s].id, hardware_id=H[h].id, status=st, notes=note,
                                       recorded_by="swint"))

    # ---------------- requirements
    reqs = [
        ("REQ-001", "Front camera stream available to perception at >= 30 fps", "performance", True, "test",
         ">= 30 fps at 2880x1860", "passed", [("hardware", "cam_f"), ("software", "cam")],
         [("test_result", "Bench stream test BT-014", "pass")]),
        ("REQ-002", "LiDAR point clouds time-stamped against PTP with < 1 ms offset", "interface", True, "test",
         "< 1 ms", "passed", [("hardware", "lidar"), ("software", "lidar")],
         [("test_result", "PTP offset capture 2h run", "pass")]),
        ("REQ-003", "Radar object list received on autonomy computer", "interface", True, "test", "20 Hz",
         "in_development", [("hardware", "radar"), ("software", "radar")], []),
        ("REQ-004", "End-to-end sensor-to-fusion latency", "performance", True, "test", "<= 100 ms (p99)", "failed",
         [("software", "fusion")], [("test_result", "Latency run LT-003 (p99 = 142 ms)", "fail")]),
        ("REQ-005", "Vehicle gateway messages decoded from customer DBC", "interface", True, "test", "100 % of DBC signals",
         "tested", [("hardware", "gw"), ("software", "gw")], [("test_result", "DBC decode regression", "info")]),
        ("REQ-006", "No CAN transmission to vehicle network in bench mode", "safety", True, "inspection",
         "0 TX frames", "passed", [("software", "gw")], [("inspection_record", "Code + config inspection IR-002", "pass")]),
        ("REQ-007", "Compute unit operates from 24 V vehicle supply via DC/DC", "hardware", True, "test",
         "18-32 V input range", "not_addressed", [], []),
        ("REQ-008", "Health monitor reports sensor dropouts within 500 ms", "functional", True, "test", "<= 500 ms",
         "integrated", [("software", "health")], []),
        ("REQ-009", "GNSS position available with RTK fix status", "functional", False, "demonstration", None,
         "in_development", [("hardware", "gnss")], []),
        ("REQ-010", "Data logger records all sensor topics for 8 h", "operational", False, "test", "8 h", "not_addressed",
         [], []),
        ("REQ-011", "Operating temperature range of compute enclosure", "environmental", True, "analysis",
         "-20 to +60 degC", "not_addressed", [], []),
        ("REQ-012", "Configuration baseline handed over with traceability report", "operational", True, "inspection",
         None, "in_development", [("document", "ICD-001 Interface Control Document v1.0")], []),
    ]
    for ref, title, cat, mand, ver, target, status, links, evid in reqs:
        r = M.Requirement(project_id=p1.id, ref=ref, title=title, category=cat, mandatory=mand,
                          priority="must" if mand else "should", verification_method=ver, target_value=target,
                          acceptance_criteria=f"Meets {target}" if target else None, status=status,
                          source="Customer spec NFR-SPEC-01 (demo)", created_by="systems", owner_id=U["systems"].id)
        db.add(r)
        db.flush()
        for ttype, key in links:
            if ttype == "hardware":
                h = H[key]
                db.add(M.TraceLink(requirement_id=r.id, target_type="hardware", target_ref=str(h.id),
                                   target_label=f"{h.asset_tag} {h.name} ({h.model}, rev {h.hardware_revision})",
                                   relation="allocated_to", created_by="systems"))
            elif ttype == "software":
                s = S[key]
                db.add(M.TraceLink(requirement_id=r.id, target_type="software", target_ref=str(s.id),
                                   target_label=f"{s.name} {s.version}", relation="implemented_by", created_by="systems"))
            else:
                db.add(M.TraceLink(requirement_id=r.id, target_type="document", target_ref="ICD-001", target_label=key,
                                   relation="documented_in", created_by="systems"))
        for kind, title_e, result in evid:
            db.add(M.Evidence(requirement_id=r.id, kind=kind, title=title_e, result=result, recorded_by="test",
                              reference="Demo record", hardware_config="Bench B2 baseline",
                              software_config="Demo baseline"))
        db.flush()
        record_revision(db, "requirement", r, "systems", "Demo seed")

    for title, ver_ in (("Safety LiDAR outputs protective field status to AMR controller", "test"),
                        ("Depth cameras provide obstacle data at >= 15 Hz", "test"),
                        ("Retrofit keeps existing navigation stack interface unchanged", "inspection")):
        n = db.query(M.Requirement).filter_by(project_id=p2.id).count() + 1
        db.add(M.Requirement(project_id=p2.id, ref=f"REQ-{n:03d}", title=title, verification_method=ver_,
                             created_by="systems"))
        db.flush()

    db.add(M.CustomerFeedback(project_id=p1.id, author="customer", category="change_request",
                              text="Please add a second rear-facing radar to the scope for yard manoeuvring.",
                              response="Captured for change board review; impact assessment in progress.",
                              responded_by="pm"))
    db.flush()
    _demo_architecture(db, p1, H, S)
    _demo_phase3(db, p1)
    _demo_phase4(db, p1, H)
    _demo_phase5(db, p1)
    _demo_phase6(db, p1)
    _demo_phase7(db, p1, H, S, U)
    for p in (p1, p2):
        record_revision(db, "project", p, "pm", "Demo seed")
    for h in H.values():
        record_revision(db, "hardware", h, "hardware", "Demo seed")
    for s in S.values():
        record_revision(db, "software", s, "swint", "Demo seed")


def _demo_architecture(db: Session, p1: M.Project, H: dict, S: dict) -> None:
    m = M.ArchModel(project_id=p1.id, name="Vehicle autonomy stack (bench)", created_by="systems",
                    description="Sensing, compute and vehicle-interface architecture for the lab bench integration.")
    db.add(m)
    db.flush()
    C: dict[str, M.ArchComponent] = {}

    def comp(key, name, layer, kind, x, y, hw=None, sw=None, parent=None, **props):
        c = M.ArchComponent(model_id=m.id, key=key, name=name, layer=layer, kind=kind, x=x, y=y,
                            hardware_id=H[hw].id if hw else None, software_id=S[sw].id if sw else None,
                            parent_id=C[parent].id if parent else None, properties=props)
        db.add(c)
        db.flush()
        C[key] = c

    comp("orin", "Autonomy compute unit", "hardware", "main_computer", 520, 260, hw="orin")
    comp("cam_front", "Front camera", "hardware", "camera", 0, 0, hw="cam_f", max_output_rate_hz=30)
    comp("cam_rear", "Rear camera", "hardware", "camera", 0, 130, hw="cam_r", max_output_rate_hz=30)
    comp("deser", "GMSL2 deserializer board", "hardware", "electronic_module", 260, 60,
         interfaces=["GMSL", "MIPI CSI-2"])
    comp("lidar", "Roof LiDAR", "hardware", "lidar", 0, 260, hw="lidar", max_output_rate_hz=20)
    comp("radar", "Front radar", "hardware", "radar", 0, 390, hw="radar", max_output_rate_hz=20)
    comp("gnss", "GNSS receiver", "hardware", "gnss", 0, 520, hw="gnss", max_output_rate_hz=20)
    comp("imu", "IMU", "hardware", "imu", 260, 560, hw="imu", max_output_rate_hz=400)
    comp("gateway", "Vehicle gateway ECU", "hardware", "ecu", 1020, 520, hw="gw")
    comp("pcan", "CAN FD interface", "hardware", "can_interface", 780, 520, hw="pcan")
    for key, name, kind, sw, x, y in (("os", "Jetson Linux", "operating_system", "l4t", 520, 420),
                                      ("ros", "ROS 2 Humble", "middleware", "ros", 700, 420),
                                      ("cam_drv", "GMSL camera driver", "device_driver", "cam", 760, 0),
                                      ("lidar_ingest", "LiDAR ingest", "sensor_processing", "lidar", 760, 110),
                                      ("radar_bridge", "Radar bridge", "communication_service", "radar", 760, 220),
                                      ("fusion", "Sensor fusion", "sensor_processing", "fusion", 1020, 160),
                                      ("gw_svc", "Vehicle gateway service", "communication_service", "gw", 1020, 330),
                                      ("health", "Health monitor", "monitoring_service", "health", 1260, 160)):
        comp(key, name, "software", kind, x, y, sw=sw, parent="orin")

    def conn(src, dst, iface, proto, dtype, rate, bw=None, kind="data", **kw):
        cn = M.ArchConnection(model_id=m.id, key=f"{src}__{dst}", source_id=C[src].id, target_id=C[dst].id,
                              kind=kind, interface_type=iface, protocol=proto, data_type=dtype, rate_hz=rate,
                              bandwidth_mbps=bw, status=kw.pop("status", "configured"), **kw)
        db.add(cn)
        return cn

    conn("cam_front", "deser", "GMSL", "Video RAW", "RAW12 2880x1860", 30, 2000,
         error_conditions="Link lock lost; frame CRC errors", config_requirements="Deserializer link mode GMSL2 6 Gbps")
    conn("cam_rear", "deser", "GMSL", "Video RAW", "RAW12 2880x1860", 30, 2000)
    conn("deser", "orin", "MIPI CSI-2", "Video RAW", "RAW12 2880x1860 x2", 30, 4000)
    conn("lidar", "orin", "Ethernet", "UDP", "Ouster lidar packets (1024x10)", 10, 130, status="verified",
         verification_ref="BT-021 PTP bench run, 2 h, 0 dropped packets", verified_by="test", verified_at=M.utcnow(),
         config_requirements="Static IP 192.168.10.20; PTP grandmaster on compute unit",
         error_conditions="UDP packet loss; PTP offset > 1 ms")
    conn("radar", "orin", "Automotive Ethernet", "UDP", "ARS 548 object & detection lists", 20, 10,
         error_conditions="Missing cycle > 100 ms")
    conn("gnss", "orin", "USB", "UBX", "UBX-NAV-PVT", 10, 0.1)
    conn("imu", "orin", "USB", "Xbus", "Orientation + rate (MTData2)", 400, 0.5)
    conn("gateway", "pcan", "CAN FD", "CAN FD", "Customer DBC VGW-2 v0.9", 100, 1.2, status="verified",
         verification_ref="BC-007 listen-only CAN capture, all DBC frames decoded", verified_by="embedded",
         verified_at=M.utcnow(), config_requirements="500 kbit/s nominal, 2 Mbit/s data; listen-only on bench",
         error_conditions="Bus-off; error passive; missing heartbeat 0x100")
    conn("pcan", "orin", "USB", "CAN (adapter)", "SocketCAN can0", 100, 1.2)
    conn("cam_drv", "fusion", "ROS 2 topic", "DDS", "sensor_msgs/Image", 30)
    conn("lidar_ingest", "fusion", "ROS 2 topic", "DDS", "sensor_msgs/PointCloud2", 10, latency_budget_ms=30)
    conn("radar_bridge", "fusion", "ROS 2 topic", "DDS", "radar_msgs/RadarTracks", 20)
    conn("gw_svc", "fusion", "ROS 2 topic", "DDS", "vehicle state (custom msg)", 50)
    conn("fusion", "health", "ROS 2 topic", "DDS", "diagnostic_msgs/DiagnosticArray", 1)
    db.flush()

    # baseline Rev 1 = architecture freeze; the working copy then adds the media converter under study
    from .api.architecture import _snapshot
    from .services.validation import validate_model
    db.add(M.ArchBaseline(model_id=m.id, revision=1, label="Architecture freeze", created_by="systems",
                          comment="ICD v1.0", snapshot=_snapshot(db, m.id),
                          validation_summary=validate_model(db, m.id)["summary"]))
    comp("media_conv", "100BASE-T1 media converter", "hardware", "media_converter", 260, 390,
         interfaces=["Automotive Ethernet", "Ethernet"])
    C["fusion"].description = "Latency budget under review (REQ-004)"

    for ref, key in (("REQ-001", "deser__orin"), ("REQ-003", "radar__orin"), ("REQ-005", "gateway__pcan")):
        r = db.query(M.Requirement).filter_by(project_id=p1.id, ref=ref).first()
        cn = db.query(M.ArchConnection).filter_by(model_id=m.id, key=key).first()
        s, t = db.get(M.ArchComponent, cn.source_id), db.get(M.ArchComponent, cn.target_id)
        db.add(M.TraceLink(requirement_id=r.id, target_type="interface", target_ref=str(cn.id),
                           target_label=f"{m.name}: {s.name} -> {t.name} ({cn.interface_type}/{cn.protocol})",
                           relation="allocated_to", created_by="systems"))


DEMO_DBC = """VERSION "VGW-2 demo 0.9 (fictional)"

NS_ :

BS_:

BU_: VGW ADU

BO_ 256 VehicleState: 8 VGW
 SG_ VehicleSpeed : 0|16@1+ (0.01,0) [0|250] "km/h" ADU
 SG_ GearPosition : 16|4@1+ (1,0) [0|8] "" ADU
 SG_ AliveCounter : 24|8@1+ (1,0) [0|255] "" ADU
 SG_ BrakePressure : 32|12@1+ (0.1,0) [0|250] "bar" ADU

BO_ 512 SteeringState: 8 VGW
 SG_ SteeringAngle : 0|16@1- (0.1,0) [-780|780] "deg" ADU
 SG_ SteeringRate : 16|16@1- (0.1,0) [-1000|1000] "deg/s" ADU

BO_ 768 PowertrainState: 8 VGW
 SG_ EngineSpeed : 0|16@1+ (0.25,0) [0|3000] "rpm" ADU
 SG_ AxleTorque : 16|16@1- (1,0) [-20000|30000] "Nm" ADU

BO_ 1024 GatewayHeartbeat: 2 VGW
 SG_ GatewayState : 0|4@1+ (1,0) [0|3] "" ADU

BA_DEF_ BO_ "GenMsgCycleTime" INT 0 10000;
BA_DEF_DEF_ "GenMsgCycleTime" 100;
BA_ "GenMsgCycleTime" BO_ 256 20;
BA_ "GenMsgCycleTime" BO_ 512 10;
BA_ "GenMsgCycleTime" BO_ 768 50;
BA_ "GenMsgCycleTime" BO_ 1024 100;
VAL_ 256 GearPosition 0 "P" 1 "R" 2 "N" 3 "D" ;
VAL_ 1024 GatewayState 0 "INIT" 1 "RUN" 2 "DEGRADED" 3 "FAULT" ;
"""


def _demo_phase3(db: Session, p1: M.Project) -> None:
    import hashlib
    db.add(M.DbcFile(project_id=p1.id, name="VGW-2_demo_v0.9.dbc", content=DEMO_DBC,
                     sha256=hashlib.sha256(DEMO_DBC.encode()).hexdigest(), messages=4, signals=9, uploaded_by="embedded"))
    db.add(M.Script(project_id=p1.id, name="bench_can_up.sh", language="bash", author="embedded", status="draft",
                    description="Bring up can0 for the bench (Linux target). Draft: needs review before it can run.",
                    content="#!/usr/bin/env bash\nset -euo pipefail\nIFACE=${1:-can0}\n"
                            "sudo ip link set \"$IFACE\" down || true\n"
                            "sudo ip link set \"$IFACE\" type can bitrate 500000 dbitrate 2000000 fd on\n"
                            "sudo ip link set \"$IFACE\" up\nip -details link show \"$IFACE\"\n"))
    db.add(M.Script(project_id=p1.id, name="env_report.py", language="python", author="swint", status="draft",
                    description="Print interpreter, platform and installed CAN tooling versions.",
                    content="import platform, sys\nprint('python', sys.version.split()[0])\nprint('platform', platform.platform())\n"
                            "for m in ('can', 'cantools', 'serial'):\n    try:\n        mod = __import__(m)\n"
                            "        print(m, getattr(mod, '__version__', '?'))\n    except ImportError:\n        print(m, 'not installed')\n"))


TC001 = '''"""TC-001 - gateway frames decode with the DBC cycle times.

sil:          synthetic VGW-2 traffic from the attached DBC on an isolated virtual bus
virtual_rig:  the same traffic on the rig's virtual CAN channel (simulated gateway ECU)
hil:          listens (no TX) to the real gateway through the rig CAN interface
"""
from integra_testkit import ENVIRONMENT, component, hil, record, sil


def test_cycle_times_and_decode():
    db = sil.dbc()
    gen = None
    if ENVIRONMENT == "hil":
        bus = hil.can_bus()
    else:
        ch = component(role="can_interface")["can"]["channel"] if ENVIRONMENT == "virtual_rig" else sil.channel()
        bus, gen = sil.can_bus(ch), sil.Generator(db, ch)
        gen.__enter__()
    try:
        rates = sil.measure_rates(bus, seconds=2.0)
        vs = db.get_message_by_name("VehicleState")
        frame = None
        while frame is None:
            m = bus.recv(1.0)
            assert m is not None, "no traffic"
            if m.arbitration_id == vs.frame_id:
                frame = m
        decoded = vs.decode(frame.data)
    finally:
        if gen:
            gen.__exit__(None, None, None)
        bus.shutdown()
    st = db.get_message_by_name("SteeringState").frame_id
    record("vehicle_state_rate_hz", round(rates.get(vs.frame_id, 0), 2), unit="Hz", expected="50 Hz (20 ms)")
    record("steering_state_rate_hz", round(rates.get(st, 0), 2), unit="Hz", expected="100 Hz (10 ms)")
    record("vehicle_speed_kmh", round(float(decoded["VehicleSpeed"]), 2), unit="km/h")
    assert 0 <= decoded["VehicleSpeed"] <= 250
'''

TC002 = '''"""TC-002 - heartbeat loss is detected within 500 ms (SIL).

The DUT here is a stub that mirrors the health_monitor heartbeat rule (300 ms timeout); point this test at the
real health_monitor package once its repository is attached to the run environment.
"""
import time

from integra_testkit import record, sil


class HeartbeatMonitor:  # DUT stub
    def __init__(self, timeout_s=0.3):
        self.timeout_s, self.last, self.lost_at = timeout_s, None, None

    def on_frame(self, t):
        self.last = t

    def poll(self, now):
        if self.last is not None and now - self.last > self.timeout_s and self.lost_at is None:
            self.lost_at = now
        return self.lost_at is not None


def test_heartbeat_loss_detected_within_500ms():
    db = sil.dbc()
    hb = db.get_message_by_name("GatewayHeartbeat").frame_id
    ch = sil.channel()
    bus, mon = sil.can_bus(ch), HeartbeatMonitor()
    gen = sil.Generator(db, ch, messages=["GatewayHeartbeat"])
    gen.__enter__()
    end = time.time() + 1.0
    while time.time() < end:
        m = bus.recv(0.05)
        if m is not None and m.arbitration_id == hb:
            mon.on_frame(time.time())
        mon.poll(time.time())
    assert mon.last is not None and mon.lost_at is None, "heartbeat not received while gateway alive"
    gen.__exit__(None, None, None)  # inject the fault: gateway stops sending
    stopped = time.time()
    while not mon.poll(time.time()) and time.time() - stopped < 2:
        bus.recv(0.01)
    bus.shutdown()
    latency = (mon.lost_at - stopped) * 1000 if mon.lost_at else None
    record("detection_latency_ms", round(latency, 1) if latency is not None else None, unit="ms", expected="<= 500")
    assert latency is not None and latency <= 500
'''

TC003 = '''"""TC-003 - bench supply delivers the compute input voltage under load (virtual rig / HIL)."""
import time

from integra_testkit import instrument, record


def test_supply_within_compute_input_range():
    psu = instrument(role="programmable_power")
    psu.write("CURR 5")
    psu.write("VOLT 24")
    psu.write("OUTP ON")
    time.sleep(0.2)
    v = float(psu.query("MEAS:VOLT?"))
    i = float(psu.query("MEAS:CURR?"))
    psu.write("OUTP OFF")
    record("supply_voltage_v", v, unit="V")
    record("supply_current_a", i, unit="A")
    assert v > 0
'''


def _demo_phase4(db: Session, p1: M.Project, H: dict) -> None:
    import hashlib

    def rig(name, kind, comps, links, **kw):
        r = M.TestRig(project_id=kw.pop("project_id", p1.id), name=name, kind=kind, created_by="test", **kw)
        db.add(r)
        db.flush()
        ids = {}
        for key, cname, role, x, y, hw, props in comps:
            c = M.RigComponent(rig_id=r.id, key=key, name=cname, role=role, x=x, y=y, properties=props,
                               hardware_id=H[hw].id if hw else None)
            db.add(c)
            db.flush()
            ids[key] = c.id
        for a, b, kind_, iface, label in links:
            db.add(M.RigConnection(rig_id=r.id, source_id=ids[a], target_id=ids[b], kind=kind_, interface=iface,
                                   label=label))
        return r

    comps_v = [("psu", "Programmable PSU (virtual)", "programmable_power", 0, 120, None,
                {"scpi": {"virtual": True, "load_ohm": 8, "current_limit": 5, "voltage": 24}}),
               ("compute", "Autonomy compute unit (twin)", "computer", 320, 120, "orin", {}),
               ("gw_sim", "Gateway ECU simulator", "sensor_simulator", 0, 300, None, {"can": {"interface": "virtual", "channel": "rig-b2-can"}}),
               ("can_if", "CAN FD interface (virtual)", "can_interface", 320, 300, None,
                {"can": {"interface": "virtual", "channel": "rig-b2-can"}})]
    links = [("psu", "compute", "power", "24 V DC", "Main supply"), ("gw_sim", "can_if", "communication", "CAN FD", "Vehicle CAN"),
             ("can_if", "compute", "communication", "USB", "SocketCAN can0")]
    rig("Bench B2 - virtual twin", "virtual", comps_v, links, status="ready",
        description="Virtual twin of lab bench B2: simulated PSU (SCPI) and gateway traffic on an isolated virtual CAN bus.")
    comps_p = [("psu", "Bench PSU", "programmable_power", 0, 120, "psu",
                {"scpi": {"host": "192.168.10.50", "port": 5025}, "calibration_due": "2027-03-31"}),
               ("compute", "Autonomy compute unit", "computer", 320, 120, "orin", {}),
               ("gateway", "Vehicle gateway ECU", "dut", 0, 300, "gw", {}),
               ("can_if", "CAN FD interface", "can_interface", 320, 300, "pcan",
                {"can": {"interface": "pcan", "channel": "PCAN_USBBUS1", "bitrate": 500000}})]
    links_p = [("psu", "compute", "power", "24 V DC", "Main supply"), ("psu", "gateway", "power", "12 V DC", "ECU supply"),
               ("gateway", "can_if", "communication", "CAN FD", "Vehicle CAN (bench harness)"),
               ("can_if", "compute", "communication", "USB", "SocketCAN can0")]
    rig("Bench B2 - HIL", "physical", comps_p, links_p, location="Lab bench B2",
        description="Physical HIL bench. Not ready until the setup checklist is complete and a HIL authorisation is approved.")
    rig("CAN gateway HIL bench (template)", "physical", comps_p, links_p, is_template=True, project_id=None,
        description="Reusable layout: PSU, compute unit, gateway ECU, CAN FD interface.")

    dbc = db.query(M.DbcFile).filter_by(project_id=p1.id).first()
    reqs = {r.ref: r for r in db.query(M.Requirement).filter_by(project_id=p1.id)}

    def tc(ref, name, ttype, envs, code, req_refs, approved, **kw):
        t = M.TestCase(project_id=p1.id, ref=ref, name=name, test_type=ttype, environments=envs,
                       automation="pytest" if code else "manual", code=code, code_version=1 if code else 0,
                       dbc_id=dbc.id if code and "dbc" in code else None, created_by="embedded", **kw)
        if code and approved:
            t.code_status, t.code_approved_by, t.code_sha256 = "approved", "test", hashlib.sha256(code.encode()).hexdigest()
        db.add(t)
        db.flush()
        for rr in req_refs:
            db.add(M.TraceLink(requirement_id=reqs[rr].id, target_type="test_case", target_ref=str(t.id),
                               target_label=f"{t.ref} {t.name}", relation="verified_by", created_by="systems"))
        return t

    t1 = tc("TC-001", "Gateway frames decode with DBC cycle times", "communication", ["sil", "virtual_rig", "hil"], TC001,
            ["REQ-005"], True, objective="Verify VGW-2 frames are received at their DBC cycle times and decode",
            preconditions="DBC VGW-2 v0.9 attached; HIL: gateway powered, CAN listen-only",
            input_data="VGW-2 traffic (synthetic in SIL)", procedure="Capture 2 s of traffic, measure per-ID rates, decode VehicleState",
            expected_output="VehicleState ~50 Hz, SteeringState ~100 Hz, signals within DBC ranges",
            acceptance_criteria="Rates within ±10 % of the DBC cycle time",
            expected_measurements={"vehicle_state_rate_hz": {"min": 45, "max": 55, "unit": "Hz"},
                                   "steering_state_rate_hz": {"min": 90, "max": 110, "unit": "Hz"}})
    t2 = tc("TC-002", "Heartbeat loss detected within 500 ms", "error_handling", ["sil"], TC002, ["REQ-008"], True,
            objective="Health monitor detects a silent gateway", procedure="Run heartbeat 1 s, stop it, measure detection latency",
            expected_output="Loss reported 300-500 ms after the last heartbeat", acceptance_criteria="latency <= 500 ms",
            expected_measurements={"detection_latency_ms": {"max": 500, "unit": "ms"}})
    t3 = tc("TC-003", "Bench supply within compute input range", "system", ["virtual_rig", "hil"], TC003, ["REQ-007"], True,
            objective="Supply delivers 24 V under load", procedure="Set 24 V / 5 A limit, output on, measure V and I, output off",
            expected_output="24 V ± 0.5 V, current below 4 A",
            expected_measurements={"supply_voltage_v": {"min": 23.5, "max": 24.5, "unit": "V"},
                                   "supply_current_a": {"max": 4, "unit": "A"}})
    t4 = tc("TC-004", "CAN bus termination", "interface", ["manual", "hil"], None, ["REQ-005"], False,
            objective="Bus correctly terminated", procedure="Power off. Measure resistance CAN_H-CAN_L at the PCAN connector",
            expected_output="60 Ω ± 3 Ω", acceptance_criteria="57-63 Ω")
    db.add(M.TestSuite(project_id=p1.id, name="Gateway regression", test_case_ids=[t1.id, t2.id], created_by="test",
                       description="SIL regression for the vehicle gateway integration"))
    db.add(M.TestSuite(project_id=p1.id, name="Bench bring-up", test_case_ids=[t3.id, t4.id, t1.id], created_by="test",
                       description="Rig bring-up checks"))


def _demo_logs(t0: datetime) -> dict[str, str]:
    """Synthetic bench logs (deterministic, labelled demo) in four real formats.

    Story: from +300 s the compute unit heats up; at ~+352 s the CPU is throttled (frequency capped) until ~+610 s and
    the fusion node misses its 100 ms deadline. At +718 s the gateway CAN link goes bus-off for ~7 s; the gateway
    service (whose clock runs 2.35 s behind) reports a heartbeat timeout and fusion stalls on stale vehicle state.
    """
    import math
    import random
    rng = random.Random(42)
    epoch = lambda s: (t0 + timedelta(seconds=s) - datetime(1970, 1, 1)).total_seconds()  # noqa: E731
    fusion, tegra, kern, gw = [], [], [], []
    throttled = lambda s: 352 <= s <= 610  # noqa: E731
    for s in range(0, 900):
        lat = 62 + rng.gauss(0, 5) + (48 + 25 * math.sin(s / 7) + rng.gauss(0, 8) if throttled(s) else 0)
        if not 722 <= s <= 725:  # fusion stalls while vehicle state is stale
            fusion.append(f"[INFO] [{epoch(s + 0.25):.9f}] [sensor_fusion]: fused frame latency_ms={lat:.1f} objects={12 + rng.randint(-3, 3)}")
        if lat > 100:
            fusion.append(f"[WARN] [{epoch(s + 0.26):.9f}] [sensor_fusion]: deadline miss latency_ms={lat:.1f} budget_ms=100")
        if s in (540, 541):
            fusion.append(f"[ERROR] [{epoch(s + 0.4):.9f}] [sensor_fusion]: planning input late (age_ms={150 + rng.randint(20, 40)})")
        temp = 68 + rng.gauss(0, 0.6) + (min(27, (s - 300) * 0.34) if 300 <= s <= 640 else 0) - (max(0, s - 640) * 0.3 if 640 < s < 730 else 0)
        freq = 1190 if throttled(s) else 2201
        load = 45 + rng.gauss(0, 4) + (40 if throttled(s) else 0)
        ts = (t0 + timedelta(seconds=s)).strftime("%m-%d-%Y %H:%M:%S")
        tegra.append(f"{ts} RAM 9{rng.randint(100, 400)}/30536MB (lfb 4200x4MB) SWAP 0/15268MB CPU "
                     f"[{','.join(f'{max(0, min(100, int(load + rng.gauss(0, 6))))}%@{freq}' for _ in range(8))}] "
                     f"EMC_FREQ 21% GR3D_FREQ {35 + rng.randint(0, 20)}% cpu@{temp:.1f}C soc0@{temp - 6:.1f}C "
                     f"gpu@{temp - 4:.1f}C VDD_GPU_SOC {3100 + rng.randint(0, 400)}mW/3200mW VDD_CPU_CV {2400 + rng.randint(0, 900)}mW/2500mW")
        if throttled(s) and (s - 352) % 10 == 0:
            kern.append(f"{(t0 + timedelta(seconds=s)):%b} {(t0 + timedelta(seconds=s)).day:2d} {(t0 + timedelta(seconds=s)):%H:%M:%S} "
                        f"orin-bench kernel: [{40000 + s:.6f}] cpu-thermal: throttling active, cpu@{temp * 1000:.0f} mC, "
                        f"max freq capped at 1190400 kHz")
    k = lambda s, msg: kern.append(f"{(t0 + timedelta(seconds=s)):%b} {(t0 + timedelta(seconds=s)).day:2d} "  # noqa: E731
                                   f"{(t0 + timedelta(seconds=s)):%H:%M:%S} orin-bench kernel: [{40000 + s:.6f}] {msg}")
    k(612, "cpu-thermal: throttling released, cpu freq cap removed")
    k(718, "peak_usb 1-2:1.0 can0: bus-off")
    k(718, "can: controller area network core")
    k(725, "peak_usb 1-2:1.0 can0: restarted (restart-ms 100)")
    kern.sort(key=lambda l: l.split(" orin-bench")[0])
    skew = timedelta(seconds=-2.35)  # gateway host clock runs 2.35 s behind (measured at bench bring-up)
    gwt = lambda s: (t0 + timedelta(seconds=s) + skew).strftime("%Y-%m-%d %H:%M:%S,") + f"{int((s % 1) * 1000):03d}"  # noqa: E731
    seq = 0
    for s in range(0, 900, 5):
        if 718 <= s <= 725:
            continue
        seq += 1
        gw.append(f"{gwt(s + 0.1)} - vehicle_gateway - INFO - heartbeat ok seq={seq} frames_per_s=275")
    gw += [f"{gwt(718.2)} - vehicle_gateway - ERROR - CAN bus-off detected on can0 (tx_errors=256)",
           f"{gwt(718.6)} - vehicle_gateway - WARNING - heartbeat timeout after 300 ms",
           f"{gwt(720.6)} - vehicle_gateway - WARNING - heartbeat timeout after 2300 ms",
           f"{gwt(725.3)} - vehicle_gateway - INFO - CAN restarted on can0, resuming listen-only bridge"]
    for s in (726, 727):
        fusion.append(f"[ERROR] [{epoch(s + 0.1):.9f}] [sensor_fusion]: vehicle state stale (age_ms={(s - 718) * 1000 + 120})")
    gw.sort()
    fusion.sort(key=lambda l: float(l.split("] [")[1]))
    return {"fusion": "\n".join(fusion), "tegra": "\n".join(tegra), "kernel": "\n".join(kern), "gateway": "\n".join(gw)}


def _demo_phase5(db: Session, p1: M.Project) -> None:
    from .services import analysis as A
    day = date.today() - timedelta(days=1)
    t0 = datetime(day.year, day.month, day.day, 9, 0, 0)
    logs = _demo_logs(t0)
    defs = [("fusion", "sensor_fusion_node (ROS 2)", "Autonomy compute unit / sensor_fusion", "application", "ros2", 0.0),
            ("tegra", "tegrastats (compute unit)", "Autonomy compute unit", "resource", "tegrastats", 0.0),
            ("kernel", "kernel log (compute unit)", "Autonomy compute unit / kernel", "system", "syslog", 0.0),
            ("gateway", "vehicle_gateway_service", "Vehicle gateway service", "communication", "python_logging", 2350.0)]
    for key, name, comp, kind, fmt, off in defs:
        s = M.LogSource(project_id=p1.id, name=name, component=comp, kind=kind, format=fmt, clock_offset_ms=off,
                        created_by="embedded")
        db.add(s)
        db.flush()
        A.import_text(db, s, f"bench_b2_{key}_{day:%Y%m%d}.log", logs[key].encode(), "embedded", year=day.year)
    db.flush()
    A.detect_anomalies(db, p1.id)
    db.flush()
    miss = (db.query(M.LogEvent).filter(M.LogEvent.project_id == p1.id, M.LogEvent.message.like("deadline miss%"))
            .order_by(M.LogEvent.ts).first())
    busoff = (db.query(M.LogEvent).filter(M.LogEvent.project_id == p1.id, M.LogEvent.message.like("%can0: bus-off%"))
              .order_by(M.LogEvent.ts).first())
    req4 = db.query(M.Requirement).filter_by(project_id=p1.id, ref="REQ-004").first()
    i1 = M.Issue(project_id=p1.id, ref="ISS-001", title="Sensor fusion latency exceeds the 100 ms budget", severity="major",
                 status="investigating", affected_subsystem="Autonomy compute unit / sensor_fusion",
                 problem_description="During the 15 min bench soak the fusion node intermittently exceeds its 100 ms "
                                     "deadline (REQ-004 latency run LT-003 measured p99 = 142 ms).",
                 reproduction_steps="Run the bench soak profile on Bench B2 with all sensors streaming for 15 min.",
                 expected_behaviour="Sensor-to-fusion latency <= 100 ms (p99)", actual_behaviour="Deadline misses up to ~160 ms",
                 hardware_revision="HW-0001 Jetson AGX Orin dev kit rev A, Jetson Linux 36.4",
                 software_revision="sensor_fusion_node 2.1.0", owner="swint", created_by="test",
                 window_start=miss.ts - timedelta(seconds=60), window_end=miss.ts + timedelta(seconds=300),
                 pinned_event_ids=[miss.id], links=[{"type": "requirement", "id": req4.id, "label": f"REQ-004 {req4.title}"}])
    i2 = M.Issue(project_id=p1.id, ref="ISS-002", title="CAN bus-off on the vehicle gateway link", severity="critical",
                 status="open", affected_subsystem="CAN FD interface / vehicle gateway", owner="embedded", created_by="embedded",
                 problem_description="can0 went bus-off for ~7 s; gateway heartbeat timed out and fusion used stale vehicle state.",
                 actual_behaviour=busoff.message if busoff else None, expected_behaviour="No bus errors in listen-only bench mode",
                 window_start=busoff.ts - timedelta(seconds=30), window_end=busoff.ts + timedelta(seconds=30),
                 pinned_event_ids=[busoff.id] if busoff else [])
    db.add_all([i1, i2])
    db.flush()
    db.add(M.IssueHypothesis(issue_id=i1.id, text="Fusion is CPU-bound: latency rises when the CPU clock is reduced.",
                             created_by="swint"))
    for i in (i1, i2):
        record_revision(db, "issue", i, i.created_by, "Demo seed")


def make_demo_bag(dest: Path, t0: float) -> None:
    """Synthetic rosbag2 (sqlite3) for the demo — NOT a vehicle recording. Contains deliberate defects:
    a 600 ms lidar gap, two lidar stamp reversals and a camera clock lagging ~120 ms behind the other sensors."""
    import numpy as np
    from rosbags.rosbag2 import Writer
    from rosbags.typesys import Stores, get_typestore
    ts = get_typestore(Stores.ROS2_HUMBLE)
    T = ts.types
    Header, Time = T["std_msgs/msg/Header"], T["builtin_interfaces/msg/Time"]
    stamp = lambda s: Time(sec=int(s), nanosec=int(round((s % 1) * 1e9)) % 1_000_000_000)  # noqa: E731
    msgs = []
    for k in range(2000):  # IMU 100 Hz, 20 s
        t = t0 + k * 0.01
        m = T["sensor_msgs/msg/Imu"](header=Header(stamp=stamp(t), frame_id="imu_link"), orientation=T["geometry_msgs/msg/Quaternion"](x=0., y=0., z=0., w=1.),
                                     orientation_covariance=np.zeros(9), angular_velocity=T["geometry_msgs/msg/Vector3"](x=0., y=0., z=0.01),
                                     angular_velocity_covariance=np.zeros(9), linear_acceleration=T["geometry_msgs/msg/Vector3"](x=0.1, y=0., z=9.81),
                                     linear_acceleration_covariance=np.zeros(9))
        msgs.append(("/imu/data", "sensor_msgs/msg/Imu", t + 0.002, m))
    for k in range(200):  # GNSS 10 Hz
        t = t0 + k * 0.1
        m = T["sensor_msgs/msg/NavSatFix"](header=Header(stamp=stamp(t), frame_id="gnss_link"),
                                           status=T["sensor_msgs/msg/NavSatStatus"](status=2, service=1),
                                           latitude=52.3 + k * 1e-6, longitude=4.76 + k * 2e-6, altitude=12.0,
                                           position_covariance=np.array([0.0009, 0, 0, 0, 0.0009, 0, 0, 0, 0.004]), position_covariance_type=2)
        msgs.append(("/gnss/fix", "sensor_msgs/msg/NavSatFix", t + 0.04, m))
    for k in range(200):  # lidar 10 Hz with a gap at 8.0-8.6 s and two stamp reversals
        if 80 < k < 86:
            continue
        t = t0 + k * 0.1 - (0.15 if k in (120, 150) else 0)
        m = T["sensor_msgs/msg/PointCloud2"](header=Header(stamp=stamp(t), frame_id="lidar_roof"), height=1, width=1024, fields=[],
                                             is_bigendian=False, point_step=16, row_step=16384, data=np.zeros(0, dtype=np.uint8), is_dense=True)
        msgs.append(("/lidar/points", "sensor_msgs/msg/PointCloud2", t0 + k * 0.1 + 0.02, m))
    for k in range(600):  # camera 30 Hz, its clock lags ~120 ms
        t = t0 + k / 30
        m = T["sensor_msgs/msg/Image"](header=Header(stamp=stamp(t - 0.12), frame_id="camera_front"), height=1860, width=2880,
                                       encoding="rgb8", is_bigendian=0, step=8640, data=np.zeros(0, dtype=np.uint8))
        msgs.append(("/camera/front/image_raw", "sensor_msgs/msg/Image", t + 0.035, m))
    msgs.sort(key=lambda x: x[2])
    with Writer(dest, version=8) as w:
        conns = {}
        for topic, mt, lt, m in msgs:
            if topic not in conns:
                conns[topic] = w.add_connection(topic, mt, typestore=ts)
            w.write(conns[topic], int(lt * 1e9), ts.serialize_cdr(m, mt))


def _demo_phase6(db: Session, p1: M.Project) -> None:
    import io
    import tempfile
    import zipfile

    from .api.autonomy import TEMPLATES
    from .services import autonomy as AU
    for cat, (name, faults, exps) in TEMPLATES.items():
        n = db.query(M.Scenario).filter_by(project_id=p1.id).count() + 1
        db.add(M.Scenario(project_id=p1.id, ref=f"SC-{n:03d}", name=name, category=cat, duration_s=30, seed=n,
                          faults=faults, expectations=exps, created_by="systems",
                          description="Demo scenario against the INTEGRA reference supervisor (a demo SUT, not production software)."))
        db.flush()
    try:
        with tempfile.TemporaryDirectory() as td:
            bag_dir = Path(td) / "bench_b2_sensors_demo"
            day = date.today() - timedelta(days=1)
            make_demo_bag(bag_dir, (datetime(day.year, day.month, day.day, 10, 0, 0) - datetime(1970, 1, 1)).total_seconds())
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w") as z:
                for f in bag_dir.iterdir():
                    z.write(f, f"bench_b2_sensors_demo/{f.name}")
            raw = buf.getvalue()
        b = M.BagFile(project_id=p1.id, name="bench_b2_sensors_demo", sha256=hashlib.sha256(raw).hexdigest(), storage="sqlite3",
                      environment="simulated", imported_by="embedded")
        db.add(b)
        db.flush()
        path = AU.store_bag(raw, "bench_b2_sensors_demo.zip", b.id)
        a = AU.analyse_bag(path)
        b.messages, b.topics, b.findings, b.sync = a["messages"], a["topics"], a["findings"], a["sync"]
        b.start, b.end, b.duration_s = AU.fmt_ts(a["start"]), AU.fmt_ts(a["end"]), a["duration_s"]
        db.add(M.Scenario(project_id=p1.id, ref=f"SC-{db.query(M.Scenario).filter_by(project_id=p1.id).count() + 1:03d}",
                          name="Replay bench bag with IMU dropout", category="sensor_availability", adapter="rosbag2_replay",
                          bag_id=b.id, duration_s=20, seed=11, created_by="systems",
                          description="Recorded (synthetic demo) bag replayed into the supervisor with an injected IMU dropout.",
                          faults=[{"type": "sensor_dropout", "sensor": "imu_data", "start_s": 6, "end_s": 7}],
                          expectations=[{"type": "detect", "fault": 0, "within_ms": 300, "match": "imu"},
                                        {"type": "recover", "fault": 0, "within_s": 2}]))
    except ImportError:  # rosbags not installed: skip the bag part of the demo
        pass
    db.flush()
    for sc in db.query(M.Scenario).filter_by(project_id=p1.id).order_by(M.Scenario.id):
        AU.run_scenario(db, sc, "systems")
    sc1 = db.query(M.Scenario).filter_by(project_id=p1.id, ref="SC-001").first()
    code = TC005
    t = M.TestCase(project_id=p1.id, ref="TC-005", name="Lidar loss handled safely (SIL scenario SC-001)", test_type="error_handling",
                   environments=["sil"], automation="pytest", code=code, code_version=1, code_status="approved", code_approved_by="test",
                   code_sha256=hashlib.sha256(code.encode()).hexdigest(), scenario_id=sc1.id, created_by="embedded",
                   objective="Supervisor detects a lidar loss, enters MINIMAL_RISK and recovers", expected_output="Detection < 500 ms, MINIMAL_RISK < 600 ms, NOMINAL < 3 s after recovery",
                   expected_measurements={"detect_latency_ms": {"max": 500, "unit": "ms"}})
    db.add(t)
    db.flush()
    req = db.query(M.Requirement).filter_by(project_id=p1.id, ref="REQ-008").first()
    db.add(M.TraceLink(requirement_id=req.id, target_type="test_case", target_ref=str(t.id), target_label=f"{t.ref} {t.name}",
                       relation="verified_by", created_by="systems"))


TC005 = '''"""TC-005 - fault handling against the attached scenario (SIL).

The system under test here is the INTEGRA reference supervisor (demo); replace it with your own package exposing
reset / on_message / step.
"""
from integra_testkit import record, sim


def test_scenario_expectations():
    scn = sim.scenario_from_env()
    res = sim.run(scn, sut=sim.ReferenceSupervisor)
    for e in res["expectations"]:
        if e["measured"] is not None and e["type"] in ("detect", "state"):
            record(f"{e['type']}_latency_ms", e["measured"], unit="ms")
    sim.assert_expectations(res)
'''


DEMO_BUILD_SCRIPT = """# Build vehicle_gateway_service: byte-compile, self-test the decoder, package dist/vgw_bridge-<commit>.zip.
# Runs inside the registered working copy (cwd). INTEGRA_COMMIT is set by INTEGRA to the commit being built.
import compileall
import os
import pathlib
import sys
import zipfile

root = pathlib.Path.cwd()
if not compileall.compile_dir(root / "vgw_bridge", quiet=1):
    sys.exit("byte-compilation failed")
sys.path.insert(0, str(root))
from vgw_bridge.decode import decode_vehicle_state  # noqa: E402

v = decode_vehicle_state(bytes([0x10, 0x27, 3, 0, 0, 0, 0, 0]))
assert v == {"speed_kph": 100.0, "gear": 3}, v
print("self-test ok:", v)
dist = root / "dist"
dist.mkdir(exist_ok=True)
out = dist / f"vgw_bridge-{os.environ.get('INTEGRA_COMMIT', 'unknown')[:12]}.zip"
with zipfile.ZipFile(out, "w") as z:
    for f in sorted((root / "vgw_bridge").rglob("*.py")):
        z.write(f, f.relative_to(root).as_posix())
print("packaged", out.name)
"""

DEMO_REPO_FILES = [
    ("Initial gateway bridge skeleton", {
        ".gitignore": "dist/\n__pycache__/\n*.pyc\n",
        "README.md": "# vehicle_gateway_service (INTEGRA demo repository)\n\nSynthetic demo code created by INTEGRA's demo seed.\n",
        "vgw_bridge/__init__.py": '__version__ = "0.7.0"\n',
        "vgw_bridge/decode.py": "def decode_vehicle_state(data: bytes) -> dict:\n    raise NotImplementedError\n",
    }),
    ("Decode VehicleState speed and gear from the VGW-2 DBC layout", {
        "vgw_bridge/decode.py": "def decode_vehicle_state(data: bytes) -> dict:\n"
                                "    \"\"\"VehicleState (0x120): speed = uint16 LE * 0.01 km/h, gear = byte 2.\"\"\"\n"
                                "    if len(data) < 3:\n        raise ValueError('VehicleState needs 3 bytes')\n"
                                "    return {'speed_kph': int.from_bytes(data[0:2], 'little') * 0.01, 'gear': data[2]}\n",
    }),
    ("Report heartbeat loss after 400 ms instead of 1 s", {
        "vgw_bridge/heartbeat.py": "TIMEOUT_S = 0.4\n\n\ndef lost(last_seen: float, now: float) -> bool:\n    return now - last_seen > TIMEOUT_S\n",
    }),
]


def make_demo_repo(dest: Path) -> str | None:
    """Create a small Git repository for the CI/CD demo (in INTEGRA's own data folder). Returns HEAD or None."""
    import os
    import shutil
    import subprocess
    exe = shutil.which("git")
    if not exe:
        return None
    env = {**os.environ, "GIT_AUTHOR_NAME": "INTEGRA demo", "GIT_AUTHOR_EMAIL": "demo@integra.example",
           "GIT_COMMITTER_NAME": "INTEGRA demo", "GIT_COMMITTER_EMAIL": "demo@integra.example", "GIT_TERMINAL_PROMPT": "0"}

    def git(*a):
        subprocess.run([exe, "-C", str(dest), *a], check=True, capture_output=True, env=env, timeout=30)

    try:
        if dest.exists():
            def _writable(func, path, _exc):  # git marks object files read-only (Windows)
                os.chmod(path, 0o700)
                func(path)
            shutil.rmtree(dest, onexc=_writable)
        dest.mkdir(parents=True)
        git("init", "-q", "-b", "main")
        # demo repository only: no signing, no inherited hooks
        git("config", "commit.gpgsign", "false")
        git("config", "tag.gpgsign", "false")
        git("config", "core.hooksPath", ".git/no-hooks")
        for i, (msg, files) in enumerate(DEMO_REPO_FILES):
            for rel, text in files.items():
                f = dest / rel
                f.parent.mkdir(parents=True, exist_ok=True)
                f.write_text(text, encoding="utf-8", newline="\n")
            git("add", "-A")
            env["GIT_AUTHOR_DATE"] = env["GIT_COMMITTER_DATE"] = f"2026-0{8 + i}-15T10:00:00Z"
            git("commit", "-q", "-m", msg)
        git("tag", "-a", "v0.9.0", "-m", "Bench integration drop 0.9.0 (demo)")
        r = subprocess.run([exe, "-C", str(dest), "rev-parse", "HEAD"], capture_output=True, text=True, env=env, timeout=30)
        return r.stdout.strip() or None
    except (OSError, subprocess.SubprocessError):
        return None


def _demo_phase7(db: Session, p1: M.Project, H: dict, S: dict, U: dict) -> None:
    import hashlib

    from . import config as C
    from .api.workspace import _snapshot_items
    from .services import delivery as D
    head = make_demo_repo(C.settings.data_dir / "demo_repos" / "vehicle_gateway_service")
    repo = build = None
    if head:
        repo = M.Repository(project_id=p1.id, name="vehicle_gateway_service (demo)", default_branch="main",
                            path=str(C.settings.data_dir / "demo_repos" / "vehicle_gateway_service"), registered_by="swint")
        db.add(repo)
        S["gw"].commit_ref = head
        script = M.Script(project_id=p1.id, name="build_vgw_bridge.py", language="python", author="embedded",
                          description="Build + self-test + package for vehicle_gateway_service (reviewed by Test).",
                          content=DEMO_BUILD_SCRIPT, status="approved", approved_by="test", approved_at=M.utcnow(),
                          approved_sha256=hashlib.sha256(DEMO_BUILD_SCRIPT.encode()).hexdigest())
        db.add(script)
        db.flush()
        try:
            build = D.run_local_build(db, p1, repo, script, [], 120, ["dist/*.zip"], U["embedded"])
        except Exception as e:  # no Python interpreter on a frozen install: keep the demo without a build
            log.info("Demo build skipped: %s", getattr(e, "detail", e))
            build = None
    cfg = M.IntegrationConfig(project_id=p1.id, name="Bench B2 baseline v0.9", created_by="swint",
                              description="Compute unit, gateway ECU and CAN interface with the gateway service and health monitor",
                              items=_snapshot_items(db, p1, [H["orin"].id, H["gw"].id, H["pcan"].id], [S["gw"].id, S["health"].id]),
                              status="frozen", frozen_by="test", frozen_at=M.utcnow())
    db.add(cfg)
    db.flush()
    suite = db.query(M.TestSuite).filter_by(project_id=p1.id, name="Gateway regression").first()
    rel = M.Release(project_id=p1.id, version="0.9.0", name="Bench integration drop", created_by="swint",
                    repository_id=repo.id if repo else None, commit_sha=head, tag="v0.9.0" if head else None,
                    build_id=build.id if build else None, integration_config_id=cfg.id,
                    required_suite_ids=[suite.id] if suite else [],
                    known_limitations=["REQ-004 sensor-to-fusion latency p99 142 ms exceeds the 100 ms target (open)",
                                       "Gateway ECU firmware is the customer's pre-release drop; HIL listen-only"],
                    rollback_plan="Stop vehicle_gateway_service, reinstall the previous accepted bench image, restore the "
                                  "service configuration from its configuration record, re-run TC-001 listen-only.")
    db.add(rel)
    db.flush()
    rel.release_notes = D.release_notes_draft(db, rel)
    rel.manifest, rel.status, rel.candidate_at = D.manifest(db, rel), "candidate", M.utcnow()
    site = M.Site(project_id=p1.id, name="Northline depot - Bay 3 (fictional)", location="Demo location", created_by="pm",
                  contact_name="J. Varga (fictional)", access_notes="Escort required in the yard; hi-vis and safety shoes.",
                  infrastructure=[
                      {"category": "network", "item": "Depot LAN VLAN 40 for telemetry", "detail": "DHCP reservation for the compute unit; outbound NTP blocked (see issue)"},
                      {"category": "power", "item": "24 V tractor supply via DC/DC; 230 V in bay", "detail": "DC/DC 18-32 V input, 15 A fuse"},
                      {"category": "mounting", "item": "Cab compute bracket and roof rack", "detail": "Bracket drawing MNT-014 rev B (demo)"}])
    db.add(site)
    db.flush()
    for key, pos, conf in (("orin", "Tractor T-12 cab, compute bracket", {"ip": "10.40.0.10", "hostname": "t12-compute"}),
                           ("lidar", "Tractor T-12 roof rack, centre", {"ip": "10.40.0.20", "mode": "1024x10"})):
        h = H[key]
        db.add(M.SiteInstallation(site_id=site.id, hardware_id=h.id, position=pos, configuration=conf, installed_by="hardware",
                                  serial_number=h.serial_number, hardware_revision=h.hardware_revision,
                                  firmware_version=h.firmware_version))
    db.flush()
    nums = [int(r[4:]) for (r,) in db.query(M.Issue.ref).filter_by(project_id=p1.id) if r.startswith("ISS-") and r[4:].isdigit()]
    db.add(M.Issue(project_id=p1.id, ref=f"ISS-{(max(nums) + 1 if nums else 1):03d}", site_id=site.id, severity="major",
                   status="corrective_action", title="Depot LAN blocks NTP: compute clock drifts at the site",
                   affected_subsystem=f"Customer site {site.name}",
                   actual_behaviour="Compute unit clock 2.3 s off after 6 h; log timestamps disagree with the gateway.",
                   expected_behaviour="Compute clock within 10 ms of GNSS time", created_by="hardware",
                   corrective_action="Use GNSS PPS + gpsd as the time source on site; customer IT to allow NTP to depot server as backup",
                   corrective_owner="hardware", links=[{"type": "site", "id": site.id, "label": f"Site {site.name}"}]))
    db.flush()
    db.add(M.SiteCheck(site_id=site.id, release_id=rel.id, started_by="hardware", items=D.new_site_check_items(db, site, rel, "hardware")))
    fat = M.AcceptanceRecord(project_id=p1.id, ref="FAT-001", kind="fat", title="Factory acceptance test - bench B2",
                             release_id=rel.id, created_by="test", items=D.acceptance_items(db, p1.id))
    for it in fat.items:
        if it["ref"] == "REQ-006":
            it.update(result="pass", comment="Inspection IR-002 walked through with the customer", by="test",
                      at=M.utcnow().isoformat(timespec="seconds"))
    db.add(fat)
    db.flush()
