"""Runtime configuration. Every value can be overridden with INTEGRA_* environment variables."""
from __future__ import annotations

import os
import secrets
import sys
from dataclasses import dataclass, field
from pathlib import Path

APP_NAME = "INTEGRA SYSTEMS PRO"
APP_VERSION = "0.8.0"
PHASE = 8


def browser() -> bool:
    """Browser edition: the backend runs on Pyodide inside the visitor's tab (no host access, no threads, no network)."""
    return os.environ.get("INTEGRA_BROWSER") == "1"


def _default_data_dir() -> Path:
    if os.environ.get("INTEGRA_DATA_DIR"):
        return Path(os.environ["INTEGRA_DATA_DIR"])
    if getattr(sys, "frozen", False):
        return Path(os.environ.get("APPDATA", Path.home())) / "Integra Systems Pro"
    return Path(__file__).resolve().parents[2] / "data"


def _static_dir() -> Path | None:
    if os.environ.get("INTEGRA_STATIC_DIR"):
        p = Path(os.environ["INTEGRA_STATIC_DIR"])
    elif getattr(sys, "frozen", False):  # PyInstaller bundle: UI is shipped next to the code
        p = Path(getattr(sys, "_MEIPASS", ".")) / "web"
    else:
        p = Path(__file__).resolve().parents[2] / "frontend" / "dist"
    return p if (p / "index.html").exists() else None


@dataclass
class Settings:
    data_dir: Path = field(default_factory=_default_data_dir)
    database_url: str | None = os.environ.get("INTEGRA_DATABASE_URL")  # e.g. postgresql+psycopg://...
    host: str = os.environ.get("INTEGRA_HOST", "127.0.0.1")
    port: int = int(os.environ.get("INTEGRA_PORT", "8980"))
    demo_data: bool = os.environ.get("INTEGRA_DEMO", "1") == "1"
    token_ttl_min: int = int(os.environ.get("INTEGRA_TOKEN_TTL_MIN", "720"))
    static_dir: Path | None = field(default_factory=_static_dir)

    @property
    def db_url(self) -> str:
        return self.database_url or f"sqlite:///{(self.data_dir / 'integra.db').as_posix()}"

    @property
    def is_sqlite(self) -> bool:
        return self.db_url.startswith("sqlite")

    @property
    def backup_dir(self) -> Path:
        return self.data_dir / "backups"

    def ensure_dirs(self) -> None:
        for d in (self.data_dir, self.backup_dir):
            d.mkdir(parents=True, exist_ok=True)

    @property
    def secret_key(self) -> str:
        env = os.environ.get("INTEGRA_SECRET_KEY")
        if env:
            return env
        self.ensure_dirs()
        f = self.data_dir / ".secret_key"
        if not f.exists():
            f.write_text(secrets.token_urlsafe(48), encoding="utf-8")
        return f.read_text(encoding="utf-8").strip()


settings = Settings()


def reload_settings() -> Settings:
    global settings
    settings = Settings()
    return settings
