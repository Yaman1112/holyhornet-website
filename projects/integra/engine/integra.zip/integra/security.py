"""Authentication (PBKDF2-SHA256 + JWT), role permissions, project-level access and the audit log."""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import re
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from . import config
from .db import get_db
from .models import AuditLog, Project, ProjectMember, User

ROLES = {
    "ADMIN": "Administrator",
    "SW_INTEGRATION": "Software Integration Engineer",
    "EMBEDDED_SW": "Embedded Software Engineer",
    "HARDWARE": "Hardware Engineer",
    "ELECTRICAL": "Electrical Engineer",
    "MECHANICAL": "Mechanical Engineer",
    "SYSTEMS": "Systems Engineer",
    "TEST": "Test Engineer",
    "PROJECT_MANAGER": "Project Manager",
    "CUSTOMER_VIEWER": "Customer Viewer",
}
ALL = set(ROLES)
ENGINEERS = {"SW_INTEGRATION", "EMBEDDED_SW", "HARDWARE", "ELECTRICAL", "MECHANICAL", "SYSTEMS", "TEST"}
INTERNAL = ALL - {"CUSTOMER_VIEWER"}

PERMISSIONS: dict[str, set[str]] = {
    "read": ALL,
    "projects.create": {"ADMIN", "PROJECT_MANAGER", "SYSTEMS"},
    "projects.write": {"ADMIN", "PROJECT_MANAGER", "SYSTEMS"},
    "projects.stage": {"ADMIN", "PROJECT_MANAGER", "SYSTEMS"},
    "projects.acceptance": {"ADMIN", "PROJECT_MANAGER"},
    "projects.members": {"ADMIN", "PROJECT_MANAGER"},
    "milestones.write": {"ADMIN", "PROJECT_MANAGER", "SYSTEMS"},
    "feedback.write": {"ADMIN", "PROJECT_MANAGER", "CUSTOMER_VIEWER"},
    "feedback.respond": {"ADMIN", "PROJECT_MANAGER", "SYSTEMS"},
    "customers.write": {"ADMIN", "PROJECT_MANAGER"},
    "requirements.write": {"ADMIN", "PROJECT_MANAGER", "SYSTEMS", "SW_INTEGRATION"},
    "requirements.status": INTERNAL - {"PROJECT_MANAGER"} | {"ADMIN"},
    "requirements.approve": {"ADMIN", "PROJECT_MANAGER"},
    "trace.write": ENGINEERS | {"ADMIN"},
    "evidence.write": ENGINEERS | {"ADMIN"},
    "hardware.write": ENGINEERS | {"ADMIN"},
    "software.write": {"ADMIN", "SW_INTEGRATION", "EMBEDDED_SW", "SYSTEMS", "TEST"},
    "architecture.write": {"ADMIN", "SYSTEMS", "SW_INTEGRATION", "EMBEDDED_SW", "HARDWARE", "ELECTRICAL"},
    "architecture.baseline": {"ADMIN", "SYSTEMS", "PROJECT_MANAGER"},
    "connections.verify": ENGINEERS | {"ADMIN"},
    "devices.scan": ENGINEERS | {"ADMIN"},
    "devices.authorize.request": ENGINEERS | {"ADMIN"},
    "devices.authorize.approve": {"ADMIN", "PROJECT_MANAGER", "TEST"},
    "comms.capture": ENGINEERS | {"ADMIN"},
    "comms.transmit": ENGINEERS - {"MECHANICAL"} | {"ADMIN"},
    "diagnostics.view": ENGINEERS | {"ADMIN"},
    "scripts.write": ENGINEERS | {"ADMIN"},
    "scripts.approve": {"ADMIN", "SYSTEMS", "TEST", "SW_INTEGRATION"},
    "scripts.run": ENGINEERS - {"MECHANICAL"} | {"ADMIN"},
    "configs.write": ENGINEERS | {"ADMIN", "PROJECT_MANAGER"},
    "configs.freeze": {"ADMIN", "SYSTEMS", "TEST", "PROJECT_MANAGER"},
    "probes.run": ENGINEERS | {"ADMIN"},
    "rigs.write": ENGINEERS | {"ADMIN"},
    "rigs.checklist": ENGINEERS | {"ADMIN"},
    "rigs.power": {"ADMIN", "TEST", "ELECTRICAL", "HARDWARE", "EMBEDDED_SW"},
    "tests.write": ENGINEERS | {"ADMIN"},
    "tests.approve": {"ADMIN", "TEST", "SYSTEMS"},
    "tests.run": ENGINEERS - {"MECHANICAL"} | {"ADMIN"},
    "debug.write": ENGINEERS | {"ADMIN"},
    "autonomy.write": ENGINEERS | {"ADMIN"},
    "simulation.run": ENGINEERS | {"ADMIN"},
    "issues.write": INTERNAL,
    "issues.confirm": ENGINEERS | {"ADMIN"},
    "issues.close": {"ADMIN", "TEST", "SYSTEMS", "PROJECT_MANAGER"},
    "builds.run": ENGINEERS - {"MECHANICAL"} | {"ADMIN"},
    "ci.write": {"ADMIN", "SW_INTEGRATION", "EMBEDDED_SW", "SYSTEMS", "TEST"},
    "releases.write": {"ADMIN", "SW_INTEGRATION", "EMBEDDED_SW", "SYSTEMS", "TEST", "PROJECT_MANAGER"},
    "releases.approve.engineering": {"ADMIN", "TEST", "SYSTEMS"},
    "releases.approve.project": {"ADMIN", "PROJECT_MANAGER"},
    "deployments.write": ENGINEERS | {"ADMIN"},
    "sites.write": ENGINEERS | {"ADMIN", "PROJECT_MANAGER"},
    "acceptance.write": {"ADMIN", "PROJECT_MANAGER", "SYSTEMS", "TEST"},
    "acceptance.sign": {"ADMIN", "PROJECT_MANAGER", "CUSTOMER_VIEWER"},
    "assistant.use": INTERNAL,
    "assistant.admin": {"ADMIN"},
    "reports.export": ALL,
    "internal.view": INTERNAL,
    "admin.users": {"ADMIN"},
    "admin.audit": {"ADMIN", "PROJECT_MANAGER"},
    "admin.backup": {"ADMIN"},
}

_ITER = int(os.environ.get("INTEGRA_PBKDF2_ITER", "210000"))


def hash_password(pw: str, iterations: int | None = None) -> str:
    it = iterations or _ITER
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, it)
    return f"pbkdf2_sha256${it}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(pw: str, stored: str) -> bool:
    try:
        algo, it, salt_b64, dk_b64 = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), base64.b64decode(salt_b64), int(it))
        return hmac.compare_digest(dk, base64.b64decode(dk_b64))
    except Exception:
        return False


def password_problems(pw: str) -> list[str]:
    p = []
    if len(pw) < 10:
        p.append("at least 10 characters")
    if not re.search(r"[A-Z]", pw):
        p.append("an upper-case letter")
    if not re.search(r"[a-z]", pw):
        p.append("a lower-case letter")
    if not re.search(r"[0-9]", pw):
        p.append("a digit")
    return p


def _pwv(user: User) -> str:
    return hashlib.sha256(user.password_hash.encode()).hexdigest()[:12]


def create_token(user: User) -> str:
    now = datetime.now(timezone.utc)
    payload = {"sub": user.username, "role": user.role, "iat": now,
               "exp": now + timedelta(minutes=config.settings.token_ttl_min), "pwv": _pwv(user)}
    return jwt.encode(payload, config.settings.secret_key, algorithm="HS256")


_bearer = HTTPBearer(auto_error=False)


def current_user(creds: HTTPAuthorizationCredentials | None = Depends(_bearer), db: Session = Depends(get_db)) -> User:
    if creds is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = jwt.decode(creds.credentials, config.settings.secret_key, algorithms=["HS256"])
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired session")
    user = db.query(User).filter(User.username == payload.get("sub")).first()
    if not user or not user.active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not active")
    if payload.get("pwv") != _pwv(user):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session revoked")
    return user


def can(user: User, permission: str) -> bool:
    return user.role in PERMISSIONS[permission]


def require(permission: str):
    def dep(user: User = Depends(current_user)) -> User:
        if not can(user, permission):
            raise HTTPException(status.HTTP_403_FORBIDDEN,
                                f"Role '{ROLES.get(user.role, user.role)}' may not perform '{permission}'")
        return user
    return dep


def permissions_for(role: str) -> list[str]:
    return sorted(p for p, roles in PERMISSIONS.items() if role in roles)


# ---------------------------------------------------------------- project-level access
def is_member(db: Session, user: User, project_id: int) -> bool:
    return db.query(ProjectMember.id).filter_by(project_id=project_id, user_id=user.id).first() is not None


def can_see_project(db: Session, user: User, project: Project) -> bool:
    if user.role == "ADMIN":
        return True
    if user.role == "CUSTOMER_VIEWER" or project.restricted:
        return is_member(db, user, project.id)
    return True


def visible_project_ids(db: Session, user: User) -> set[int] | None:
    """None = all projects visible."""
    if user.role == "ADMIN":
        return None
    member_of = {pid for (pid,) in db.query(ProjectMember.project_id).filter_by(user_id=user.id)}
    if user.role == "CUSTOMER_VIEWER":
        return member_of
    restricted = {pid for (pid,) in db.query(Project.id).filter(Project.restricted.is_(True))}
    if not restricted:
        return None
    return {pid for (pid,) in db.query(Project.id)} - (restricted - member_of)


def get_project_or_404(db: Session, user: User, project_id: int) -> Project:
    p = db.get(Project, project_id)
    if p is None or not can_see_project(db, user, p):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found")
    return p


def check_project_write(db: Session, user: User, project: Project) -> None:
    """Restricted projects may only be changed by their members (and administrators)."""
    if project.restricted and user.role != "ADMIN" and not is_member(db, user, project.id):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Restricted project: only project members may change it")


# ---------------------------------------------------------------- audit
def audit(db: Session, user: User | str, action: str, entity: str, entity_id=None, *, project_id: int | None = None,
          summary: str | None = None, detail: dict | None = None, request: Request | None = None) -> None:
    db.add(AuditLog(username=user if isinstance(user, str) else user.username, action=action, entity=entity,
                    entity_id=None if entity_id is None else str(entity_id), project_id=project_id,
                    summary=(summary or "")[:300] or None, detail=detail,
                    ip=request.client.host if request and request.client else None))
