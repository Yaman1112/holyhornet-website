"""Browser edition: endpoints that need the host machine answer 501 with the reason, instead of failing obscurely.

The browser edition runs the same FastAPI application on Pyodide inside the visitor's tab: there is no access to USB,
serial, CAN or network interfaces, no subprocesses (Git, scripts, pytest, builds), no threads and no outbound network
(GitHub, Anthropic). Everything that works on stored records works unchanged.
"""
from __future__ import annotations

import re

HOST_ONLY: list[tuple[str, str, str]] = [
    ("POST", r"/devices/scan", "device discovery on the host (USB/PnP, serial, CAN, network)"),
    ("GET", r"/diagnostics/.*", "host diagnostics (processes, services, drivers, file permissions)"),
    ("GET", r"/net/interfaces", "the host's network interfaces"),
    ("POST", r"/net/tcp-probe", "network access from the host"),
    ("GET", r"/serial/ports", "the host's serial ports"),
    ("POST", r"/captures/(can|serial|udp)", "live capture on CAN / serial / UDP interfaces"),
    ("POST", r"/captures/\d+/(stop|serial-write)", "live capture on host interfaces"),
    ("POST", r"/captures/import", "the python-can log readers"),
    ("POST", r"/can/(generator|replay|transmit|tasks/stop)", "a CAN bus (virtual or physical) with background threads"),
    ("POST", r"/dbc", "DBC parsing with cantools"),
    ("POST", r"/connections/\d+/probe", "runtime probes against host interfaces"),
    ("POST", r"/rig-components/\d+/power", "SCPI instrument control"),
    ("GET", r"/rigs/\d+/monitor", "live instrument and device monitoring"),
    ("POST", r"/repos", "Git on the host"),
    ("GET", r"/repos/\d+/(summary|verify)", "Git on the host"),
    ("POST", r"/scripts/\d+/run", "script execution on the host"),
    ("GET", r"/scripts/interpreters", "interpreters on the host"),
    ("POST", r"/projects/\d+/builds/run", "build execution in a Git working copy"),
    ("POST", r"/ci/\d+/sync", "network access to the GitHub API"),
    ("POST", r"/bags/import", "the rosbags reader (ROS 2 bag import)"),
    ("POST", r"/simulation/plugins.*", "loading plugin files on the host"),
    ("POST", r"/assistant/conversations/\d+/ask", "the Anthropic API (the browser edition never sends project data out); "
                                                  "the built-in record analyses work here"),
]
_COMPILED = [(m, re.compile(rf"^/api/v1{p}$"), why) for m, p, why in HOST_ONLY]


def blocked(method: str, path: str) -> str | None:
    for m, rx, why in _COMPILED:
        if m == method and rx.match(path):
            return (f"Not available in the browser edition: this needs {why}. Everything here runs inside your browser "
                    "tab; install the INTEGRA desktop edition for hardware, Git, test execution and AI features.")
    return None
