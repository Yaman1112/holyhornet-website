"""FastAPI application factory."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.exc import IntegrityError

from . import config, seed
from .api import (admin, architecture, assistant, autonomy, comms, debug, delivery, inventory, projects, releases, reports, requirements,
                  rigs, testing, workspace)
from .modules import MODULES
from .security import current_user

log = logging.getLogger("integra")

DESCRIPTION = """REST API of INTEGRA SYSTEMS PRO — Software & Hardware Integration Engineering Workbench.

Authenticate with `POST /api/v1/auth/login` and send `Authorization: Bearer <token>`.
All indicators (readiness, coverage, delivery gate) are computed from stored records.
`GET /api/v1/modules` lists which modules and adapters are implemented and which are planned."""


def create_app() -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        seed.init_db()
        if config.settings.demo_data and seed.seed_demo():
            log.info("Demo dataset seeded")
        yield
        from .hal.sessions import stop_all
        stop_all()

    app = FastAPI(title=f"{config.APP_NAME} API", version=config.APP_VERSION, description=DESCRIPTION,
                  lifespan=lifespan, docs_url="/api/docs", openapi_url="/api/openapi.json", redoc_url=None)
    app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3880", "http://127.0.0.1:3880"],
                       allow_methods=["*"], allow_headers=["*"],
                       expose_headers=["Content-Disposition", "X-Report-Revision", "X-Report-SHA256"])

    @app.middleware("http")
    async def headers(request: Request, call_next):
        if config.browser():
            from .browser_guard import blocked
            why = blocked(request.method, request.url.path)
            if why:
                return JSONResponse({"detail": why, "browser_edition": True}, 501)
        resp = await call_next(request)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        if request.url.path.startswith("/api/"):
            resp.headers.setdefault("Cache-Control", "no-store")
        return resp

    @app.exception_handler(IntegrityError)
    async def integrity(_: Request, exc: IntegrityError):
        return JSONResponse({"detail": "Database constraint violated (duplicate or invalid reference)"}, 409)

    @app.exception_handler(RequestValidationError)
    async def validation(_: Request, exc: RequestValidationError):
        msgs = []
        for e in exc.errors():
            loc = ".".join(str(x) for x in e.get("loc", []) if x not in ("body", "query", "path"))
            msg = str(e.get("msg", "")).removeprefix("Value error, ")
            msgs.append(f"{loc}: {msg}" if loc else msg)
        return JSONResponse({"detail": "; ".join(msgs)}, 422)

    for r in (admin.router, projects.router, requirements.router, inventory.router, architecture.router,
              comms.router, workspace.router, rigs.router, testing.router, debug.router, autonomy.router, releases.router,
              delivery.router, assistant.router, reports.router):
        app.include_router(r)

    @app.get("/api/v1/modules", tags=["platform"])
    def modules(_=Depends(current_user)):
        from .hal.adapters import registry
        return {"phase": config.PHASE, "modules": MODULES, "adapters": registry()}

    static = config.settings.static_dir
    if static:
        app.mount("/assets", StaticFiles(directory=static / "assets"), name="assets")

        @app.get("/{path:path}", include_in_schema=False)
        def spa(path: str):
            f = static / path
            if path and f.is_file() and static in f.resolve().parents:
                return FileResponse(f)
            return FileResponse(static / "index.html")

    return app


app = create_app()
