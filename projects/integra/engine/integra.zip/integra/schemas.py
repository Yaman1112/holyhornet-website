"""Pydantic request schemas (input validation). Responses are plain dicts built in the routers."""
from __future__ import annotations

from datetime import date
from typing import Annotated, Any

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, field_validator

from . import models as M


def one_of(values: list[str]):
    def check(v: str) -> str:
        if v not in values:
            raise ValueError(f"must be one of: {', '.join(values)}")
        return v
    return AfterValidator(check)


Stage = Annotated[str, one_of(M.STAGE_KEYS)]
Domain = Annotated[str, one_of(M.DOMAINS)]
Priority = Annotated[str, one_of(M.PRIORITIES)]
Acceptance = Annotated[str, one_of(M.ACCEPTANCE)]
MsStatus = Annotated[str, one_of(M.MILESTONE_STATUS)]
ReqCat = Annotated[str, one_of(M.REQ_CATEGORIES)]
ReqPrio = Annotated[str, one_of(M.REQ_PRIORITY)]
Verif = Annotated[str, one_of(M.VERIFICATION)]
ReqStatus = Annotated[str, one_of(M.REQ_STATUS)]
TraceTarget = Annotated[str, one_of(M.TRACE_TARGETS)]
TraceRel = Annotated[str, one_of(M.TRACE_RELATIONS)]
EvKind = Annotated[str, one_of(M.EVIDENCE_KINDS)]
EvResult = Annotated[str, one_of(M.EVIDENCE_RESULTS)]
HwCat = Annotated[str, one_of(M.HW_CATEGORIES)]
HwStatus = Annotated[str, one_of(M.HW_STATUS)]
SwKind = Annotated[str, one_of(M.SW_KINDS)]
SwLang = Annotated[str, one_of(M.SW_LANGUAGES)]
SwStatus = Annotated[str, one_of(M.SW_STATUS)]
DepKind = Annotated[str, one_of(M.DEP_KINDS)]
Compat = Annotated[str, one_of(M.COMPAT_STATUS)]
Name = Annotated[str, Field(min_length=1, max_length=200)]


class In(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class LoginIn(In):
    username: str
    password: str


class PasswordChangeIn(In):
    current_password: str
    new_password: str


class UserIn(In):
    username: Annotated[str, Field(pattern=r"^[a-z0-9_.-]{3,64}$")]
    full_name: Name
    email: str | None = None
    role: str
    password: str


class UserPatch(In):
    full_name: str | None = None
    email: str | None = None
    role: str | None = None
    active: bool | None = None
    password: str | None = None


class CustomerIn(In):
    name: Name
    industry: str | None = None
    contact_name: str | None = None
    contact_email: str | None = None
    contact_phone: str | None = None
    address: str | None = None
    notes: str | None = None


class ProjectIn(In):
    name: Name
    customer_id: int
    domain: Domain
    description: str | None = None
    objectives: list[str] = []
    use_cases: list[str] = []
    validation_criteria: list[str] = []
    priority: Priority = "medium"
    restricted: bool = False
    lead_engineer_id: int | None = None
    start_date: date | None = None
    target_date: date | None = None
    internal_notes: str | None = None


class ProjectPatch(In):
    name: str | None = None
    customer_id: int | None = None
    domain: Domain | None = None
    description: str | None = None
    objectives: list[str] | None = None
    use_cases: list[str] | None = None
    validation_criteria: list[str] | None = None
    priority: Priority | None = None
    restricted: bool | None = None
    lead_engineer_id: int | None = None
    start_date: date | None = None
    target_date: date | None = None
    internal_notes: str | None = None
    comment: str | None = None


class StageIn(In):
    stage: Stage
    note: str | None = None


class AcceptanceIn(In):
    acceptance_status: Acceptance
    note: str | None = None


class MemberIn(In):
    user_id: int
    project_role: Annotated[str, Field(min_length=1, max_length=60)]


class MilestoneIn(In):
    name: Name
    deliverable: str | None = None
    due_date: date | None = None
    status: MsStatus = "planned"
    owner_id: int | None = None


class MilestonePatch(In):
    name: str | None = None
    deliverable: str | None = None
    due_date: date | None = None
    status: MsStatus | None = None
    owner_id: int | None = None


class FeedbackIn(In):
    category: Annotated[str, one_of(["comment", "change_request", "issue", "approval"])] = "comment"
    text: Annotated[str, Field(min_length=1, max_length=5000)]


class FeedbackResponseIn(In):
    response: Annotated[str, Field(min_length=1, max_length=5000)]


class RequirementIn(In):
    ref: Annotated[str, Field(pattern=r"^[A-Za-z0-9_.-]{1,32}$")] | None = None
    title: Annotated[str, Field(min_length=1, max_length=240)]
    description: str | None = None
    category: ReqCat = "functional"
    priority: ReqPrio = "must"
    mandatory: bool = True
    verification_method: Verif = "test"
    acceptance_criteria: str | None = None
    target_value: str | None = None
    source: str | None = None
    parent_id: int | None = None
    owner_id: int | None = None


class RequirementPatch(In):
    title: str | None = None
    description: str | None = None
    category: ReqCat | None = None
    priority: ReqPrio | None = None
    mandatory: bool | None = None
    verification_method: Verif | None = None
    acceptance_criteria: str | None = None
    target_value: str | None = None
    source: str | None = None
    parent_id: int | None = None
    owner_id: int | None = None
    comment: str | None = None


class ReqStatusIn(In):
    status: ReqStatus
    comment: str | None = None


class TraceIn(In):
    target_type: TraceTarget
    target_ref: Annotated[str, Field(min_length=1, max_length=64)]
    target_label: str | None = None
    relation: TraceRel = "allocated_to"


class EvidenceIn(In):
    kind: EvKind
    title: Annotated[str, Field(min_length=1, max_length=240)]
    reference: str | None = None
    result: EvResult = "info"
    hardware_config: str | None = None
    software_config: str | None = None
    notes: str | None = None


class HardwareIn(In):
    name: Name
    category: HwCat
    manufacturer: Name
    model: Name
    serial_number: Annotated[str, Field(min_length=1, max_length=120)]
    project_id: int | None = None
    asset_tag: str | None = None
    hardware_revision: str | None = None
    firmware_version: str | None = None
    specifications: dict[str, Any] = {}
    supply_voltage_min: float | None = Field(default=None, ge=0, le=1000)
    supply_voltage_max: float | None = Field(default=None, ge=0, le=1000)
    max_current_a: float | None = Field(default=None, ge=0, le=1000)
    max_power_w: float | None = Field(default=None, ge=0, le=100000)
    interfaces: list[str] = []
    driver_requirements: str | None = None
    installation_doc: str | None = None
    location: str | None = None
    status: HwStatus = "available"
    notes: str | None = None

    @field_validator("interfaces")
    @classmethod
    def _ifaces(cls, v: list[str]) -> list[str]:
        bad = [i for i in v if i not in M.HW_INTERFACES]
        if bad:
            raise ValueError(f"unknown interface(s) {bad}; allowed: {', '.join(M.HW_INTERFACES)}")
        return v


class HardwarePatch(In):
    name: str | None = None
    category: HwCat | None = None
    project_id: int | None = None
    hardware_revision: str | None = None
    firmware_version: str | None = None
    specifications: dict[str, Any] | None = None
    supply_voltage_min: float | None = None
    supply_voltage_max: float | None = None
    max_current_a: float | None = None
    max_power_w: float | None = None
    interfaces: list[str] | None = None
    driver_requirements: str | None = None
    installation_doc: str | None = None
    location: str | None = None
    status: HwStatus | None = None
    notes: str | None = None
    comment: str | None = None
    unassign_project: bool = False

    @field_validator("interfaces")
    @classmethod
    def _ifaces(cls, v):
        if v is not None:
            bad = [i for i in v if i not in M.HW_INTERFACES]
            if bad:
                raise ValueError(f"unknown interface(s) {bad}")
        return v


class ConfigRecordIn(In):
    title: Name
    parameters: dict[str, Any] = {}
    notes: str | None = None


class SoftwareIn(In):
    name: Name
    kind: SwKind
    language: SwLang
    version: Annotated[str, Field(min_length=1, max_length=60)]
    project_id: int | None = None
    repository_url: str | None = None
    commit_ref: str | None = None
    build_system: str | None = None
    target_platform: str | None = None
    license: str | None = None
    maintainer_id: int | None = None
    status: SwStatus = "planned"
    description: str | None = None
    config_files: list[str] = []


class SoftwarePatch(In):
    kind: SwKind | None = None
    language: SwLang | None = None
    project_id: int | None = None
    repository_url: str | None = None
    commit_ref: str | None = None
    build_system: str | None = None
    target_platform: str | None = None
    license: str | None = None
    maintainer_id: int | None = None
    status: SwStatus | None = None
    description: str | None = None
    config_files: list[str] | None = None
    comment: str | None = None
    unassign_project: bool = False


class DependencyIn(In):
    name: Name
    version_constraint: str | None = None
    kind: DepKind = "runtime"
    depends_on_id: int | None = None


class CompatIn(In):
    hardware_id: int
    status: Compat
    notes: str | None = None


# ---------------------------------------------------------------- Phase 2: architecture
ArchLayer = Annotated[str, one_of(M.ARCH_LAYERS)]
ConnKind = Annotated[str, one_of(M.CONN_KINDS)]
IfaceType = Annotated[str, one_of(M.HW_INTERFACES + M.LOGICAL_INTERFACES)]
Key = Annotated[str, Field(pattern=r"^[A-Za-z0-9_.-]{1,48}$")]


class ArchModelIn(In):
    name: Name
    description: str | None = None


class ComponentIn(In):
    key: Key | None = None
    name: Name
    layer: ArchLayer
    kind: str
    hardware_id: int | None = None
    software_id: int | None = None
    parent_id: int | None = None
    properties: dict[str, Any] = {}
    description: str | None = None
    x: float = 0
    y: float = 0


class ComponentPatch(In):
    name: str | None = None
    kind: str | None = None
    hardware_id: int | None = None
    software_id: int | None = None
    parent_id: int | None = None
    properties: dict[str, Any] | None = None
    description: str | None = None
    x: float | None = None
    y: float | None = None


class ConnectionIn(In):
    key: Key | None = None
    source_id: int
    target_id: int
    kind: ConnKind = "data"
    interface_type: IfaceType
    protocol: str | None = None
    data_type: str | None = None
    rate_hz: float | None = Field(default=None, gt=0, le=1e7)
    bandwidth_mbps: float | None = Field(default=None, ge=0, le=1e6)
    latency_budget_ms: float | None = Field(default=None, ge=0)
    config_requirements: str | None = None
    error_conditions: str | None = None
    notes: str | None = None


class ConnectionPatch(In):
    kind: ConnKind | None = None
    interface_type: IfaceType | None = None
    protocol: str | None = None
    data_type: str | None = None
    rate_hz: float | None = Field(default=None, gt=0, le=1e7)
    bandwidth_mbps: float | None = Field(default=None, ge=0, le=1e6)
    latency_budget_ms: float | None = Field(default=None, ge=0)
    config_requirements: str | None = None
    error_conditions: str | None = None
    notes: str | None = None
    status: Annotated[str, one_of(["planned", "configured"])] | None = None


class VerifyIn(In):
    result: Annotated[str, one_of(["verified", "failed"])]
    reference: Annotated[str, Field(min_length=3, max_length=300)]


class LayoutIn(In):
    positions: dict[int, tuple[float, float]]


class BaselineIn(In):
    label: Annotated[str, Field(min_length=1, max_length=120)]
    comment: str | None = None
