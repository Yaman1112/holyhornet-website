"""Database engine/session management. SQLite (WAL) locally, any SQLAlchemy URL (PostgreSQL) in production."""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from . import config


class Base(DeclarativeBase):
    pass


_engine: Engine | None = None
_Session: sessionmaker | None = None


def _sqlite_pragmas(dbapi_conn, _):  # pragma: no cover - trivial
    dbapi_conn.isolation_level = None  # SQLAlchemy controls transactions (reliable SAVEPOINTs on pysqlite)
    cur = dbapi_conn.cursor()
    cur.execute("PRAGMA foreign_keys=ON")
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA synchronous=NORMAL")
    cur.close()


def get_engine() -> Engine:
    global _engine, _Session
    if _engine is None:
        s = config.settings
        s.ensure_dirs()
        if s.is_sqlite:
            _engine = create_engine(s.db_url, connect_args={"check_same_thread": False, "timeout": 30})
            event.listen(_engine, "connect", _sqlite_pragmas)
            event.listen(_engine, "begin", lambda conn: conn.exec_driver_sql("BEGIN"))
        else:
            _engine = create_engine(s.db_url, pool_pre_ping=True)
        _Session = sessionmaker(bind=_engine, expire_on_commit=False)
    return _engine


def reset_engine() -> None:
    global _engine, _Session
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _Session = None


def SessionLocal() -> Session:
    get_engine()
    assert _Session is not None
    return _Session()


@contextmanager
def session_scope() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
