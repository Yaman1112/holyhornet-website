"""Log analysis for debugging (Phase 5): ingestion, internal event collection, anomaly detection, window
correlation, statistical precursors, incident clusters and CAN log protocol analysis.

Everything here is computed from stored records. Correlation results are SUGGESTIONS: they show what tends to happen
before a failure, not why it happens. Engineers confirm or reject them with evidence in the RCA workflow.
"""
from __future__ import annotations

import bisect
import hashlib
import math
import statistics
from collections import Counter, defaultdict
from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from .. import models as M
from .logparse import Parsed, categorize, parse_lines, template_of

LEVEL_W = {"debug": 0.5, "info": 1.0, "warning": 2.0, "error": 3.0, "critical": 4.0}
LEVEL_ORDER = {k: i for i, k in enumerate(M.LEVELS)}


# ---------------------------------------------------------------- ingestion
def store_events(db: Session, src: M.LogSource, parsed: list[Parsed], import_id: int | None = None,
                 refs: list[str | None] | None = None) -> int:
    off = timedelta(milliseconds=src.clock_offset_ms or 0)
    rows = []
    for i, p in enumerate(parsed):
        tpl, fp = template_of(p.component or src.component, p.message)
        rows.append(M.LogEvent(project_id=src.project_id, source_id=src.id, import_id=import_id, ts_raw=p.ts, ts=p.ts + off,
                               level=p.level, category=categorize(p.message, p.component, src.kind),
                               component=p.component or src.component, message=p.message[:20000], fields=p.fields,
                               fingerprint=fp, template=tpl, ref=refs[i] if refs else None))
    db.add_all(rows)
    return len(rows)


def import_text(db: Session, src: M.LogSource, filename: str, raw: bytes, user: str, year: int | None = None) -> M.LogImport:
    text = raw.decode("utf-8", errors="replace")
    lines = text.splitlines()
    fmt, parsed, unparsed = parse_lines(lines, src.format, src.timezone_offset_min, year)
    imp = M.LogImport(source_id=src.id, filename=filename, sha256=hashlib.sha256(raw).hexdigest(), detected_format=fmt,
                      lines=len(lines), unparsed=unparsed, imported_by=user,
                      first_ts=min((p.ts for p in parsed), default=None), last_ts=max((p.ts for p in parsed), default=None))
    db.add(imp)
    db.flush()
    imp.events = store_events(db, src, parsed, imp.id)
    return imp


def resync(db: Session, src: M.LogSource) -> int:
    """Re-apply the source clock offset to all its events (timestamp synchronisation)."""
    off = timedelta(milliseconds=src.clock_offset_ms or 0)
    n = 0
    for e in db.query(M.LogEvent).filter_by(source_id=src.id):
        e.ts = e.ts_raw + off
        n += 1
    return n


def _internal_source(db: Session, project_id: int, name: str, kind: str, component: str) -> M.LogSource:
    s = db.query(M.LogSource).filter_by(project_id=project_id, name=name).first()
    if s is None:
        s = M.LogSource(project_id=project_id, name=name, kind=kind, component=component, internal=True, format="auto",
                        created_by="integra")
        db.add(s)
        db.flush()
    return s


def collect_internal(db: Session, project_id: int) -> dict:
    """Turn INTEGRA's own engineering records into timeline events (idempotent by ref)."""
    existing = {r for (r,) in db.query(M.LogEvent.ref).filter(M.LogEvent.project_id == project_id, M.LogEvent.ref.isnot(None))}
    added = Counter()

    def emit(src_name, kind, comp, ref, ts, level, msg, fields=None):
        if ref in existing or ts is None:
            return
        s = _internal_source(db, project_id, src_name, kind, comp)
        store_events(db, s, [Parsed(ts, level, msg, comp, fields or {})], refs=[ref])
        existing.add(ref)
        added[src_name] += 1

    for res, run in (db.query(M.TestResult, M.TestRun).join(M.TestRun, M.TestRun.id == M.TestResult.run_id)
                     .filter(M.TestRun.project_id == project_id, M.TestResult.status.in_(["failed", "error"]))):
        tc = db.get(M.TestCase, res.test_case_id)
        meas = {m["name"]: m["value"] for m in res.measurements or [] if isinstance(m.get("value"), (int, float))}
        emit("INTEGRA test results", "test", "test runner", f"test_result:{res.id}", res.executed_at or run.started_at,
             "error", f"{run.environment.upper()} run #{run.id} {tc.ref} {tc.name}: {res.status}",
             {"run_id": run.id, "test_case": tc.ref, **meas})
    arch_ids = [i for (i,) in db.query(M.ArchModel.id).filter_by(project_id=project_id)]
    if arch_ids:
        for p, cn in (db.query(M.ConnectionProbe, M.ArchConnection).join(M.ArchConnection, M.ArchConnection.id == M.ConnectionProbe.connection_id)
                      .filter(M.ArchConnection.model_id.in_(arch_ids), M.ConnectionProbe.result == "fail")):
            emit("INTEGRA runtime probes", "communication", cn.key, f"probe:{p.id}", p.ran_at, "error",
                 f"Probe {p.kind} failed on {cn.key} ({p.environment}): {p.detail}", {"connection_id": cn.id})
    for c in db.query(M.Capture).filter(M.Capture.project_id == project_id):
        st = c.stats or {}
        if c.status == "error":
            emit("INTEGRA captures", "communication", f"{c.kind} capture", f"capture_err:{c.id}", c.stopped_at or c.started_at,
                 "error", f"Capture #{c.id} '{c.name}' stopped with error: {c.error}")
        if st.get("error_frames"):
            emit("INTEGRA captures", "communication", f"{c.kind} capture", f"capture_ef:{c.id}", c.stopped_at or c.started_at,
                 "warning", f"Capture #{c.id} '{c.name}': {st['error_frames']} CAN error frame(s)", {"error_frames": st["error_frames"]})
        if st.get("bad_checksum"):
            emit("INTEGRA captures", "communication", f"{c.kind} capture", f"capture_cs:{c.id}", c.stopped_at or c.started_at,
                 "warning", f"Capture #{c.id} '{c.name}': {st['bad_checksum']} bad checksum(s)", {"bad_checksum": st["bad_checksum"]})
    for run, s in (db.query(M.ScriptRun, M.Script).join(M.Script, M.Script.id == M.ScriptRun.script_id)
                   .filter(M.Script.project_id == project_id)):
        if run.timed_out or (run.exit_code not in (0, None)):
            emit("INTEGRA scripts", "build", s.name, f"script_run:{run.id}", run.started_at, "error",
                 f"Script {s.name} v{run.version} " + ("timed out" if run.timed_out else f"exited with {run.exit_code}"),
                 {"exit_code": run.exit_code} if run.exit_code is not None else {})
    hw_ids = {h.id: h for h in db.query(M.HardwareItem).filter_by(project_id=project_id)}
    for rv in db.query(M.EntityRevision).filter(M.EntityRevision.entity_type == "hardware",
                                                M.EntityRevision.entity_id.in_(list(hw_ids) or [-1])):
        if "status" in (rv.changed_fields or []) and rv.snapshot.get("status") == "faulty" and rv.revision > 1:
            h = hw_ids[rv.entity_id]
            emit("INTEGRA hardware records", "hardware", h.asset_tag, f"hw_faulty:{rv.id}", rv.changed_at, "error",
                 f"{h.asset_tag} {h.name} marked faulty: {rv.comment or ''}".strip())
    return {"added": dict(added), "total": sum(added.values())}


# ---------------------------------------------------------------- anomalies
def _mad(vals: list[float]) -> tuple[float, float]:
    med = statistics.median(vals)
    return med, statistics.median([abs(v - med) for v in vals])


def detect_anomalies(db: Session, project_id: int, outlier_k: float = 6.0, gap_factor: float = 3.0) -> dict:
    """Gaps in periodic messages, timestamps running backwards, numeric outlier episodes. Re-running replaces the
    previous analysis events."""
    src = _internal_source(db, project_id, "INTEGRA analysis", "analysis", "anomaly detector")
    db.query(M.LogEvent).filter(M.LogEvent.source_id == src.id).delete()
    events = (db.query(M.LogEvent).filter(M.LogEvent.project_id == project_id, M.LogEvent.source_id != src.id)
              .order_by(M.LogEvent.source_id, M.LogEvent.id).all())
    found: list[tuple[Parsed, str]] = []
    by_fp: dict[tuple, list[M.LogEvent]] = defaultdict(list)
    by_src: dict[int, list[M.LogEvent]] = defaultdict(list)
    for e in events:
        by_fp[(e.source_id, e.fingerprint)].append(e)
        by_src[e.source_id].append(e)
    names = {s.id: s.name for s in db.query(M.LogSource).filter_by(project_id=project_id)}

    # 1. gaps in periodic message streams
    for (sid, fp), evs in by_fp.items():
        if len(evs) < 20 or evs[0].level not in ("debug", "info"):  # periodic status streams, not warning bursts
            continue
        ts = sorted(e.ts for e in evs)
        d = [(b - a).total_seconds() for a, b in zip(ts, ts[1:])]
        med = statistics.median(d)
        if med <= 0:
            continue
        # only streams that are actually periodic (heartbeats, status lines): >= 80 % of intervals within ±50 % of median
        if sum(1 for x in d if 0.5 * med <= x <= 1.5 * med) < 0.8 * len(d):
            continue
        for i, gap in enumerate(d):
            if gap > gap_factor * med and gap > med + 0.05:
                found.append((Parsed(ts[i + 1], "warning",
                                     f"Gap of {gap:.3f} s in '{evs[0].template[:80]}' from {names.get(sid)} (median period {med:.3f} s)",
                                     evs[0].component, {"gap_s": round(gap, 4), "median_period_s": round(med, 4),
                                                        "gap_start": ts[i].isoformat(), "fingerprint": fp}), "timing"))
    # 2. timestamps running backwards (file order)
    for sid, evs in by_src.items():
        for a, b in zip(evs, evs[1:]):
            back = (a.ts_raw - b.ts_raw).total_seconds()
            if back > 1.0:
                found.append((Parsed(b.ts, "warning", f"Timestamp went backwards by {back:.3f} s in {names.get(sid)} "
                                     f"(clock jump or unsynchronised source)", b.component, {"jump_s": round(-back, 3)}), "timing"))
    # 3. numeric outlier episodes per (source, field)
    series: dict[tuple, list[tuple[datetime, float, M.LogEvent]]] = defaultdict(list)
    for e in events:
        for k, v in (e.fields or {}).items():
            if isinstance(v, (int, float)) and not isinstance(v, bool) and k not in ("run_id", "exit_code", "kernel_time_s"):
                series[(e.source_id, k)].append((e.ts, float(v), e))
    for (sid, k), pts in series.items():
        if len(pts) < 20:
            continue
        vals = [v for _, v, _ in pts]
        med, mad = _mad(vals)
        if mad == 0:
            continue
        thr = med + outlier_k * 1.4826 * mad
        pts.sort(key=lambda x: x[0])
        period = statistics.median([(b[0] - a[0]).total_seconds() for a, b in zip(pts, pts[1:])] or [1]) or 1
        # group outlying samples into episodes separated by more than max(5 periods, 2 s)
        outl = [p for p in pts if p[1] > thr]
        episodes: list[list] = []
        for p in outl:
            if episodes and (p[0] - episodes[-1][-1][0]).total_seconds() <= max(5 * period, 2.0):
                episodes[-1].append(p)
            else:
                episodes.append([p])
        cat = "timing" if any(s in k for s in ("latency", "delay", "period", "age", "jitter", "_ms")) else \
            "resource" if any(s in k for s in ("temp", "cpu", "ram", "mem", "gpu", "power", "freq")) else "application"
        for ep in episodes:
            if len(ep) < 3:  # isolated spikes are noise, not an episode
                continue
            peak = max(ep, key=lambda x: x[1])
            found.append((Parsed(ep[0][0], "warning",
                                 f"{k} above normal in {names.get(sid)}: peak {peak[1]:g} vs median {med:g} "
                                 f"({len(ep)} sample(s) over {(ep[-1][0] - ep[0][0]).total_seconds():.1f} s)",
                                 peak[2].component, {"field": k, "peak": peak[1], "median": med, "threshold": round(thr, 3),
                                                     "samples": len(ep), "episode_end": ep[-1][0].isoformat()}), cat))
        # low-side outliers matter for frequencies (e.g. CPU clock throttled down)
        if "freq" in k:
            lthr = med - outlier_k * 1.4826 * mad
            low = [(t, v, e) for t, v, e in pts if v < lthr]
            if low:
                found.append((Parsed(low[0][0], "warning", f"{k} below normal in {names.get(sid)}: min {min(v for _, v, _ in low):g} "
                                     f"vs median {med:g} ({len(low)} sample(s))", low[0][2].component,
                                     {"field": k, "min": min(v for _, v, _ in low), "median": med, "samples": len(low)}), "resource"))
    n = store_events(db, src, [p for p, _ in found])
    db.flush()
    # categories from the detector (store_events categorises by text; enforce detector categories)
    for ev, (_, cat) in zip(db.query(M.LogEvent).filter_by(source_id=src.id).order_by(M.LogEvent.id), found):
        ev.category = cat
    kinds = Counter("gap" if p.message.startswith("Gap") else "clock" if "backwards" in p.message else "outlier" for p, _ in found)
    return {"anomalies": n, "by_kind": dict(kinds)}


# ---------------------------------------------------------------- correlation
def window_events(db: Session, anchor: M.LogEvent, before_s: float, after_s: float, limit: int = 60) -> list[dict]:
    lo, hi = anchor.ts - timedelta(seconds=before_s), anchor.ts + timedelta(seconds=after_s)
    evs = (db.query(M.LogEvent).filter(M.LogEvent.project_id == anchor.project_id, M.LogEvent.ts >= lo,
                                       M.LogEvent.ts <= hi, M.LogEvent.id != anchor.id).all())
    freq = Counter(fp for (fp,) in db.query(M.LogEvent.fingerprint).filter(M.LogEvent.project_id == anchor.project_id))
    out = []
    for e in evs:
        dt = (e.ts - anchor.ts).total_seconds()
        score = LEVEL_W[e.level] / (1 + abs(dt) / 5) / math.log2(2 + freq[e.fingerprint]) * (1.5 if dt <= 0 else 0.7) * \
            (1.3 if e.source_id != anchor.source_id else 1.0)
        out.append({"id": e.id, "dt_s": round(dt, 3), "score": round(score, 4), "level": e.level, "category": e.category,
                    "source_id": e.source_id, "component": e.component, "message": e.message[:300],
                    "fingerprint": e.fingerprint, "occurrences": freq[e.fingerprint]})
    out.sort(key=lambda x: -x["score"])
    return out[:limit]


def precursors(db: Session, project_id: int, fingerprint: str, window_s: float = 30.0, min_support: float = 0.3,
               limit: int = 15) -> dict:
    """Which message types tend to occur in the `window_s` before occurrences of `fingerprint` (support), and how much
    more often than chance (lift vs. a Poisson baseline over the project's log span)."""
    rows = (db.query(M.LogEvent.ts, M.LogEvent.fingerprint, M.LogEvent.template, M.LogEvent.component, M.LogEvent.level,
                     M.LogEvent.source_id).filter(M.LogEvent.project_id == project_id).all())
    if not rows:
        return {"target": fingerprint, "occurrences": 0, "candidates": []}
    times: dict[str, list[datetime]] = defaultdict(list)
    meta: dict[str, tuple] = {}
    for ts, fp, tpl, comp, lvl, sid in rows:
        times[fp].append(ts)
        meta.setdefault(fp, (tpl, comp, lvl, sid))
    for v in times.values():
        v.sort()
    target = times.get(fingerprint, [])
    # anomalies derived from the target's own component are restatements of the symptom, not candidate causes
    analysis_src = {s.id for s in db.query(M.LogSource).filter_by(project_id=project_id, kind="analysis")}
    tcomp = meta.get(fingerprint, (None, None))[1]
    span =max((max(r[0] for r in rows) - min(r[0] for r in rows)).total_seconds(), window_s)
    W = timedelta(seconds=window_s)
    cands = []
    for fp, ts in times.items():
        if fp == fingerprint or len(ts) > 20000:
            continue
        if meta[fp][3] in analysis_src and tcomp and meta[fp][1] == tcomp:
            continue
        hit, leads = 0, []
        for t in target:
            i = bisect.bisect_left(ts, t)  # events strictly before t
            j = bisect.bisect_left(ts, t - W)
            if i > j:
                hit += 1
                leads.append((t - ts[i - 1]).total_seconds())
        if not target or hit == 0:
            continue
        support = hit / len(target)
        baseline = 1 - math.exp(-len(ts) / span * window_s)
        lift = support / baseline if baseline > 0 else float("inf")
        if support >= min_support and lift > 1.5:
            tpl, comp, lvl, sid = meta[fp]
            cands.append({"fingerprint": fp, "template": tpl, "component": comp, "level": lvl, "source_id": sid,
                          "support": round(support, 3), "baseline": round(baseline, 4), "lift": round(lift, 2),
                          "median_lead_s": round(statistics.median(leads), 3), "occurrences": len(ts)})
    cands.sort(key=lambda c: (-c["lift"] * c["support"], -c["support"]))
    tpl = meta.get(fingerprint, ("?",))[0]
    return {"target": fingerprint, "template": tpl, "occurrences": len(target), "window_s": window_s,
            "span_s": round(span, 1), "candidates": cands[:limit],
            "note": "Statistical co-occurrence, not causation. Confirm with evidence before recording a root cause."}


def clusters(db: Session, project_id: int, gap_s: float = 2.0, min_level: str = "warning", limit: int = 100) -> list[dict]:
    lv = [l for l in M.LEVELS if LEVEL_ORDER[l] >= LEVEL_ORDER[min_level]]
    evs = (db.query(M.LogEvent).filter(M.LogEvent.project_id == project_id, M.LogEvent.level.in_(lv))
           .order_by(M.LogEvent.ts).all())
    out, cur = [], []

    def flush():
        if not cur:
            return
        srcs = {e.source_id for e in cur}
        out.append({"start": cur[0].ts.isoformat(timespec="milliseconds"), "end": cur[-1].ts.isoformat(timespec="milliseconds"),
                    "events": len(cur), "sources": sorted(srcs), "cross_component": len(srcs) > 1,
                    "levels": dict(Counter(e.level for e in cur)), "categories": dict(Counter(e.category for e in cur)),
                    "first": {"id": cur[0].id, "message": cur[0].message[:200], "component": cur[0].component},
                    "worst": max(cur, key=lambda e: (LEVEL_ORDER[e.level], -e.id)).id, "event_ids": [e.id for e in cur][:200]})
    for e in evs:
        if cur and (e.ts - cur[-1].ts).total_seconds() > gap_s:
            flush()
            cur = []
        cur.append(e)
    flush()
    out.sort(key=lambda c: (-int(c["cross_component"]), -c["events"]))
    return out[:limit]


# ---------------------------------------------------------------- CAN log protocol analysis
def can_analysis(records: list[dict], dbc=None, cycle_tolerance: float = 0.10) -> dict:
    frames = [r for r in records if not r.get("err")]
    errs = [r for r in records if r.get("err")]
    by_id: dict[int, list[dict]] = defaultdict(list)
    for r in frames:
        by_id[r["id"]].append(r)
    msgs = {m.frame_id: m for m in dbc.messages} if dbc else {}
    findings, ids = [], []
    for fid, fr in sorted(by_id.items()):
        ts = [r["t"] for r in fr]
        d = [b - a for a, b in zip(ts, ts[1:])]
        row = {"id": fid, "hex": f"0x{fid:X}", "count": len(fr), "dlc": sorted({r["dlc"] for r in fr})}
        if d:
            row |= {"period_ms": round(statistics.mean(d) * 1000, 3), "jitter_ms": round(statistics.pstdev(d) * 1000, 3),
                    "max_gap_ms": round(max(d) * 1000, 3)}
        m = msgs.get(fid)
        if dbc is not None:
            if m is None:
                findings.append({"severity": "warning", "id": row["hex"], "check": "unknown_id",
                                 "detail": f"{row['hex']} ({len(fr)} frames) is not defined in the DBC"})
            else:
                row["message"] = m.name
                bad_dlc = [x for x in row["dlc"] if x != m.length]
                if bad_dlc and not m.is_fd:
                    findings.append({"severity": "error", "id": row["hex"], "check": "dlc",
                                     "detail": f"{m.name}: DLC {bad_dlc} differs from DBC length {m.length}"})
                if m.cycle_time and d:
                    dev = (row["period_ms"] - m.cycle_time) / m.cycle_time
                    row["cycle_deviation_pct"] = round(dev * 100, 1)
                    if abs(dev) > cycle_tolerance:
                        findings.append({"severity": "warning", "id": row["hex"], "check": "cycle_time",
                                         "detail": f"{m.name}: mean period {row['period_ms']} ms vs DBC {m.cycle_time} ms "
                                                   f"({dev * 100:+.1f} %)"})
                    if row["max_gap_ms"] > 3 * m.cycle_time:
                        findings.append({"severity": "warning", "id": row["hex"], "check": "gap",
                                         "detail": f"{m.name}: max gap {row['max_gap_ms']} ms (> 3x cycle {m.cycle_time} ms)"})
                out_of_range: Counter = Counter()
                counter_skips = 0
                last_cnt: dict[str, int] = {}
                for r in fr:
                    try:
                        vals = m.decode(bytes.fromhex(r["data"]), decode_choices=False)
                    except Exception:
                        out_of_range["<decode error>"] += 1
                        continue
                    for s in m.signals:
                        v = vals.get(s.name)
                        if v is None:
                            continue
                        if (s.minimum is not None and v < s.minimum - 1e-9) or (s.maximum is not None and v > s.maximum + 1e-9):
                            out_of_range[s.name] += 1
                        if any(k in s.name.lower() for k in ("alive", "counter", "rolling")):
                            mod = 2 ** s.length
                            if s.name in last_cnt and (int(v) - last_cnt[s.name]) % mod != 1:
                                counter_skips += 1
                            last_cnt[s.name] = int(v)
                for sname, n in out_of_range.items():
                    findings.append({"severity": "error", "id": row["hex"], "check": "signal_range",
                                     "detail": f"{m.name}.{sname}: {n} value(s) outside the DBC range"})
                if counter_skips:
                    findings.append({"severity": "warning", "id": row["hex"], "check": "alive_counter",
                                     "detail": f"{m.name}: alive counter not incrementing by 1 in {counter_skips} frame(s)"})
        ids.append(row)
    if errs:
        findings.append({"severity": "error", "id": "-", "check": "error_frames",
                         "detail": f"{len(errs)} error frame(s); first at {datetime.utcfromtimestamp(errs[0]['t']).isoformat()}Z"})
    if dbc is not None:
        missing = [m for fid, m in msgs.items() if fid not in by_id]
        for m in missing:
            findings.append({"severity": "info", "id": f"0x{m.frame_id:X}", "check": "missing",
                             "detail": f"{m.name} defined in the DBC but not present in the log"})
    dur = (frames[-1]["t"] - frames[0]["t"]) if len(frames) > 1 else 0
    order = {"error": 0, "warning": 1, "info": 2}
    return {"frames": len(frames), "error_frames": len(errs), "duration_s": round(dur, 3), "ids": ids,
            "findings": sorted(findings, key=lambda f: (order[f["severity"]], f["id"])),
            "dbc_used": dbc is not None}
