"""Interface & dependency validation engine (Module F, static part).

Each connection is checked against the stored engineering records — hardware interface lists, inventory status,
power ranges, protocol/interface pairing, bandwidth vs interface capacity, rates vs declared source capability,
drivers on the receiving host, software/hardware compatibility records and software dependencies.

Runtime checks (device detected, driver loaded, data received at the expected rate) need the Phase 3 hardware
adapters. They are reported as `untested` and are only satisfied by a recorded verification (engineer + reference).

Result per connection: verified | verified_with_limitations | failed | not_tested | missing_information.
"""
from __future__ import annotations

import re
from collections import defaultdict

from sqlalchemy.orm import Session

from .. import models as M

# interface -> protocols commonly carried (a protocol outside this set is a warning, not a failure)
PROTOCOLS: dict[str, set[str]] = {
    "CAN": {"CAN 2.0", "J1939", "CANopen", "UDS", "ISO-TP", "Custom CAN"},
    "CAN FD": {"CAN FD", "CAN 2.0", "J1939", "UDS", "ISO-TP", "Custom CAN"},
    "LIN": {"LIN 2.x", "LIN 1.3"},
    "Ethernet": {"UDP", "TCP", "SOME/IP", "DDS", "PTP", "HTTP", "gRPC", "MQTT", "RTSP", "DoIP"},
    "Automotive Ethernet": {"UDP", "TCP", "SOME/IP", "DDS", "PTP", "DoIP", "AVB"},
    "UART": {"NMEA 0183", "UBX", "Xbus", "Modbus RTU", "Custom binary", "ASCII"},
    "Serial": {"NMEA 0183", "UBX", "Xbus", "Modbus RTU", "Custom binary", "ASCII"},
    "RS-485": {"Modbus RTU", "Custom binary"},
    "USB": {"USB CDC", "UVC", "USB bulk", "Vendor protocol", "NMEA 0183", "UBX", "Xbus", "CAN (adapter)"},
    "SPI": {"Register map", "Custom"},
    "I2C": {"Register map", "SMBus", "Custom"},
    "GPIO": {"Digital I/O", "Trigger"},
    "PPS": {"PPS"},
    "GMSL": {"Video RAW", "Video YUV"},
    "MIPI CSI-2": {"Video RAW", "Video YUV"},
    "PCIe": {"PCIe"},
    "Power": {"DC"},
    "ROS 2 topic": {"DDS"},
    "IPC": {"Shared memory", "Unix socket", "Pipe"},
    "Network API": {"REST", "gRPC", "MQTT", "WebSocket"},
    "Function call": {"In-process"},
}
# nominal usable capacity in Mbit/s (bus load check); UART depends on baud (connection property not modelled)
CAPACITY_MBPS = {"CAN": 1.0, "CAN FD": 5.0, "LIN": 0.02, "Ethernet": 1000.0, "Automotive Ethernet": 100.0,
                 "USB": 480.0, "RS-485": 10.0, "SPI": 50.0, "I2C": 0.4, "GMSL": 6000.0, "MIPI CSI-2": 10000.0,
                 "PCIe": 16000.0}
LOGICAL = set(M.LOGICAL_INTERFACES)
EQUIVALENT = {"CAN": {"CAN", "CAN FD"}, "Serial": {"Serial", "UART", "RS-485"}, "UART": {"UART", "Serial"}}
RUNTIME_CHECKS = ["Device detected on host", "Driver loaded", "Data received at expected rate"]
RESULT_ORDER = ["failed", "missing_information", "not_tested", "verified_with_limitations", "verified"]


class Ctx:
    """Preloaded model graph + linked inventory records."""

    def __init__(self, db: Session, model_id: int):
        self.db = db
        self.comps = {c.id: c for c in db.query(M.ArchComponent).filter_by(model_id=model_id)}
        self.conns = db.query(M.ArchConnection).filter_by(model_id=model_id).order_by(M.ArchConnection.id).all()
        hw_ids = {c.hardware_id for c in self.comps.values() if c.hardware_id}
        sw_ids = {c.software_id for c in self.comps.values() if c.software_id}
        self.hw = {h.id: h for h in db.query(M.HardwareItem).filter(M.HardwareItem.id.in_(hw_ids))} if hw_ids else {}
        self.sw = {s.id: s for s in db.query(M.SoftwareItem).filter(M.SoftwareItem.id.in_(sw_ids))} if sw_ids else {}
        self.compat = {(c.software_id, c.hardware_id): c for c in db.query(M.HardwareCompatibility)
                       .filter(M.HardwareCompatibility.software_id.in_(sw_ids))} if sw_ids else {}
        # latest probe per (connection, kind)
        self.probes: dict[int, dict[str, M.ConnectionProbe]] = {}
        conn_ids = [c.id for c in self.conns]
        if conn_ids:
            for p in db.query(M.ConnectionProbe).filter(M.ConnectionProbe.connection_id.in_(conn_ids)) \
                    .order_by(M.ConnectionProbe.id):
                self.probes.setdefault(p.connection_id, {})[p.kind] = p

    def host(self, c: M.ArchComponent) -> M.ArchComponent | None:
        """Hardware component that hosts `c` (itself for hardware)."""
        seen = set()
        while c is not None and c.layer != "hardware":
            if c.id in seen:
                return None
            seen.add(c.id)
            c = self.comps.get(c.parent_id) if c.parent_id else None
        return c

    def interfaces_of(self, hwc: M.ArchComponent) -> tuple[list[str] | None, str]:
        if hwc.hardware_id and hwc.hardware_id in self.hw:
            return list(self.hw[hwc.hardware_id].interfaces or []), f"inventory {self.hw[hwc.hardware_id].asset_tag}"
        declared = (hwc.properties or {}).get("interfaces")
        if declared:
            return list(declared), "declared in architecture"
        return None, ""

    def hosted_on(self, host_id: int) -> list[M.ArchComponent]:
        return [c for c in self.comps.values() if c.layer == "software" and self.host(c) and self.host(c).id == host_id]


def _chk(name: str, result: str, detail: str) -> dict:
    return {"check": name, "result": result, "detail": detail}


def _supports(ifaces: list[str], wanted: str) -> bool:
    return any(i in ifaces for i in EQUIVALENT.get(wanted, {wanted}))


def validate_connection(ctx: Ctx, cn: M.ArchConnection) -> dict:
    src, dst = ctx.comps.get(cn.source_id), ctx.comps.get(cn.target_id)
    checks: list[dict] = []
    if src is None or dst is None:
        return {"id": cn.id, "result": "failed", "checks": [_chk("Endpoints", "fail", "Endpoint component missing")]}
    logical = cn.interface_type in LOGICAL
    hs, hd = ctx.host(src), ctx.host(dst)

    # 1. hosts resolvable
    for role, c, h in (("Source", src, hs), ("Destination", dst, hd)):
        if h is None:
            checks.append(_chk(f"{role} host", "missing", f"Software '{c.name}' is not deployed on a hardware component "
                                                          "(set 'Hosted on')"))
    # 2. inventory status of hardware involved
    for h in {x.id: x for x in (hs, hd) if x}.values():
        item = ctx.hw.get(h.hardware_id) if h.hardware_id else None
        if item is None:
            checks.append(_chk(f"Inventory: {h.name}", "missing",
                               "Not linked to a registered hardware item (identity, revision and interfaces unknown)"))
        elif item.status in ("faulty", "retired"):
            checks.append(_chk(f"Inventory: {h.name}", "fail", f"{item.asset_tag} S/N {item.serial_number} is {item.status}"))
        else:
            checks.append(_chk(f"Inventory: {h.name}", "pass",
                               f"{item.asset_tag} {item.model} HW {item.hardware_revision or '-'} FW "
                               f"{item.firmware_version or '-'} ({item.status})"))

    # 3. physical interface availability on both ends
    if not logical and hs and hd:
        if hs.id == hd.id and cn.interface_type not in ("Power",):
            checks.append(_chk("Interface availability", "warn", "Both ends resolve to the same hardware host"))
        for role, h in (("source", hs), ("destination", hd)):
            ifaces, origin = ctx.interfaces_of(h)
            if ifaces is None:
                checks.append(_chk(f"Interface on {role}", "missing", f"No interface list for '{h.name}'"))
            elif _supports(ifaces, cn.interface_type):
                checks.append(_chk(f"Interface on {role}", "pass", f"'{h.name}' provides {cn.interface_type} ({origin})"))
            else:
                checks.append(_chk(f"Interface on {role}", "fail",
                                   f"'{h.name}' has no {cn.interface_type} interface ({origin}: {', '.join(ifaces) or 'none'})"
                                   + _hint(cn.interface_type, ifaces)))
    elif logical:
        if hs and hd and hs.id != hd.id and cn.interface_type in ("IPC", "Function call"):
            checks.append(_chk("Interface availability", "fail",
                               f"{cn.interface_type} requires both components on the same host "
                               f"('{hs.name}' vs '{hd.name}')"))
        elif hs and hd and hs.id != hd.id:
            path = _network_path(ctx, hs, hd)
            checks.append(_chk("Network path between hosts", "pass" if path else "warn",
                               f"Hosts '{hs.name}' and '{hd.name}' are linked by {path}" if path else
                               f"No Ethernet connection modelled between '{hs.name}' and '{hd.name}'"))
        if cn.interface_type == "ROS 2 topic":
            ros = [c for c in ctx.comps.values() if c.kind == "middleware" and "ros" in c.name.lower()]
            for role, h in (("source", hs), ("destination", hd)):
                if h and not any(ctx.host(r) and ctx.host(r).id == h.id for r in ros):
                    checks.append(_chk(f"ROS 2 middleware on {role} host", "warn",
                                       f"No ROS 2 middleware component deployed on '{h.name}'"))

    # 4. protocol / interface pairing
    if not cn.protocol:
        checks.append(_chk("Protocol", "missing", "Communication protocol not specified"))
    elif cn.interface_type in PROTOCOLS and cn.protocol not in PROTOCOLS[cn.interface_type]:
        checks.append(_chk("Protocol", "warn", f"'{cn.protocol}' is not a known protocol for {cn.interface_type} "
                                               f"(known: {', '.join(sorted(PROTOCOLS[cn.interface_type]))})"))
    else:
        checks.append(_chk("Protocol", "pass", f"{cn.protocol} over {cn.interface_type}"))

    # 5. data definition, rate and bandwidth
    if cn.kind == "data":
        if not cn.data_type:
            checks.append(_chk("Data type", "missing", "Data type / message schema not specified"))
        else:
            checks.append(_chk("Data type", "pass", cn.data_type))
        if not cn.rate_hz:
            checks.append(_chk("Update frequency", "missing", "Expected update frequency not specified"))
        else:
            max_rate = (src.properties or {}).get("max_output_rate_hz")
            if max_rate is not None and float(cn.rate_hz) > float(max_rate):
                checks.append(_chk("Update frequency", "fail", f"Expected {cn.rate_hz:g} Hz exceeds '{src.name}' "
                                                               f"maximum output rate {float(max_rate):g} Hz"))
            else:
                checks.append(_chk("Update frequency", "pass", f"{cn.rate_hz:g} Hz" +
                                   (f" (source max {float(max_rate):g} Hz)" if max_rate is not None else "")))
    cap = CAPACITY_MBPS.get(cn.interface_type)
    if cn.bandwidth_mbps and cap:
        load = _bus_load(ctx, cn)
        if load > cap:
            checks.append(_chk("Bandwidth", "fail", f"{load:g} Mbit/s on this {cn.interface_type} link exceeds "
                                                    f"nominal capacity {cap:g} Mbit/s"))
        elif load > 0.7 * cap:
            checks.append(_chk("Bandwidth", "warn", f"{load:g} Mbit/s is {load / cap:.0%} of {cap:g} Mbit/s "
                                                    "(above 70 % bus load guideline)"))
        else:
            checks.append(_chk("Bandwidth", "pass", f"{load:g} of {cap:g} Mbit/s ({load / cap:.0%})"))

    # 6. power
    if cn.kind == "power" or cn.interface_type == "Power":
        vout = (src.properties or {}).get("output_voltage_v")
        item = ctx.hw.get(dst.hardware_id) if dst.hardware_id else None
        vmin, vmax = (item.supply_voltage_min, item.supply_voltage_max) if item else (None, None)
        if vout is None or vmin is None or vmax is None:
            checks.append(_chk("Supply voltage", "missing", "Source output voltage or destination supply range "
                                                            "not recorded"))
        elif vmin <= float(vout) <= vmax:
            checks.append(_chk("Supply voltage", "pass", f"{float(vout):g} V within {vmin:g}-{vmax:g} V"))
        else:
            checks.append(_chk("Supply voltage", "fail", f"{float(vout):g} V outside {dst.name} supply range "
                                                         f"{vmin:g}-{vmax:g} V"))

    # 7. driver on receiving host for a peripheral that needs one
    if not logical and hs and hd and cn.kind == "data":
        periph = ctx.hw.get(hs.hardware_id) if hs.hardware_id else None
        if periph is not None and periph.driver_requirements:
            drivers = [c for c in ctx.hosted_on(hd.id) if c.kind == "device_driver"]
            # a driver counts for this peripheral when its compatibility with the peripheral is recorded
            drivers = [d for d in drivers if d.software_id and ctx.compat.get((d.software_id, periph.id)) is not None
                       and ctx.compat[(d.software_id, periph.id)].status != "incompatible"]
            ready = [d for d in drivers if ctx.sw.get(d.software_id)
                     and ctx.sw[d.software_id].status in ("integrated", "released")]
            if ready:
                checks.append(_chk("Driver", "pass", f"{', '.join(d.name for d in ready)} on '{hd.name}'"))
            elif drivers:
                checks.append(_chk("Driver", "warn", f"Driver {', '.join(d.name for d in drivers)} on '{hd.name}' "
                                                     "is not integrated/released yet"))
            else:
                checks.append(_chk("Driver", "warn", f"'{periph.model}' requires: {periph.driver_requirements} — "
                                                     f"no device driver component deployed on '{hd.name}'"))

    # 8. software/hardware compatibility records for software endpoints
    for c in {x.id: x for x in (src, dst)}.values():
        if c.layer != "software":
            continue
        h = ctx.host(c)
        if not (c.software_id and h and h.hardware_id):
            if c.software_id is None:
                checks.append(_chk(f"Software record: {c.name}", "missing", "Not linked to a registered software item"))
            continue
        s = ctx.sw.get(c.software_id)
        rec = ctx.compat.get((c.software_id, h.hardware_id))
        label = f"{s.name} {s.version} on {ctx.hw[h.hardware_id].asset_tag}" if s and h.hardware_id in ctx.hw else c.name
        if rec is None or rec.status == "untested":
            checks.append(_chk(f"SW/HW compatibility: {c.name}", "untested", f"{label}: no compatibility finding"))
        else:
            res = {"compatible": "pass", "limited": "warn", "incompatible": "fail"}[rec.status]
            checks.append(_chk(f"SW/HW compatibility: {c.name}", res,
                               f"{label}: {rec.status}" + (f" — {rec.notes}" if rec.notes else "")))

    # 9. runtime checks: latest runtime probe, else a recorded engineering verification
    manual = cn.status == "verified" and cn.verification_ref
    probes = ctx.probes.get(cn.id, {})
    traffic = max((probes[k] for k in ("can_traffic", "serial_traffic", "tcp_reachable", "ros2_topic") if k in probes),
                  key=lambda p: p.id, default=None)
    dev = probes.get("device_present")
    sources = {"Device detected on host": dev, "Data received at expected rate": traffic,
               "Driver loaded": dev}
    runtime = []
    for name in RUNTIME_CHECKS if not logical else ["Data received at expected rate"]:
        p = sources.get(name)
        if cn.status == "failed":
            c = _chk(name, "fail", f"Recorded as failed: {cn.verification_ref or 'no reference'}")
        elif p is not None and name == "Driver loaded":
            ok = (p.measured or {}).get("driver_ok")
            c = _chk(name, "pass" if ok else ("fail" if p.result == "pass" else "untested"),
                     f"Probe #{p.id}: driver {(p.measured or {}).get('driver') or '-'} "
                     f"status {(p.measured or {}).get('driver_status') or 'unknown'}")
        elif p is not None:
            if p.result == "fail":
                c = _chk(name, "fail", f"Probe #{p.id} ({p.environment}, {p.ran_at:%Y-%m-%d %H:%M}): {p.detail}")
            elif p.environment == "virtual":
                c = _chk(name, "warn", f"Probe #{p.id} passed on an isolated virtual interface — not a hardware "
                                       f"result: {p.detail}")
            else:
                c = _chk(name, "pass", f"Probe #{p.id} ({p.ran_at:%Y-%m-%d %H:%M}): {p.detail}")
        elif manual:
            c = _chk(name, "pass", f"Recorded verification by {cn.verified_by}: {cn.verification_ref}")
        else:
            c = _chk(name, "untested", "No runtime probe or recorded verification yet")
        runtime.append(c)
    checks += runtime
    verified = bool(manual) or (bool(runtime) and all(c["result"] in ("pass", "warn") for c in runtime))

    return {"id": cn.id, "key": cn.key, "result": _overall(checks, verified),
            "source": src.name, "target": dst.name, "interface_type": cn.interface_type, "protocol": cn.protocol,
            "checks": checks, "explanation": _explain(checks)}


def _hint(wanted: str, ifaces: list[str]) -> str:
    if wanted == "Automotive Ethernet" and "Ethernet" in ifaces:
        return ". A 100/1000BASE-T1 media converter is required between Automotive Ethernet and standard Ethernet"
    if wanted == "GMSL" and "MIPI CSI-2" in ifaces:
        return ". A GMSL deserializer (to MIPI CSI-2) is required"
    if wanted in ("CAN", "CAN FD") and "USB" in ifaces:
        return ". Route through a USB-CAN adapter component"
    return ""


def _bus_load(ctx: Ctx, cn: M.ArchConnection) -> float:
    """Sum of declared bandwidth on all connections sharing this physical segment (same unordered host pair)."""
    hs, hd = ctx.host(ctx.comps[cn.source_id]), ctx.host(ctx.comps[cn.target_id])
    pair = frozenset(x.id for x in (hs, hd) if x)
    total = 0.0
    for o in ctx.conns:
        if o.interface_type != cn.interface_type or not o.bandwidth_mbps:
            continue
        a, b = ctx.comps.get(o.source_id), ctx.comps.get(o.target_id)
        if a and b and frozenset(x.id for x in (ctx.host(a), ctx.host(b)) if x) == pair:
            total += o.bandwidth_mbps
    return round(total, 3)


def _network_path(ctx: Ctx, a: M.ArchComponent, b: M.ArchComponent) -> str | None:
    adj = defaultdict(set)
    for o in ctx.conns:
        if o.interface_type in ("Ethernet", "Automotive Ethernet"):
            x, y = ctx.comps.get(o.source_id), ctx.comps.get(o.target_id)
            hx, hy = (ctx.host(x) if x else None), (ctx.host(y) if y else None)
            if hx and hy:
                adj[hx.id].add(hy.id)
                adj[hy.id].add(hx.id)
    seen, stack = {a.id}, [a.id]
    while stack:
        n = stack.pop()
        if n == b.id:
            return "a modelled Ethernet path"
        for m in adj[n] - seen:
            seen.add(m)
            stack.append(m)
    return None


def _overall(checks: list[dict], verified: bool) -> str:
    rs = {c["result"] for c in checks}
    if "fail" in rs:
        return "failed"
    if "missing" in rs:
        return "missing_information"
    if verified:
        return "verified_with_limitations" if "warn" in rs or "untested" in rs else "verified"
    return "not_tested"


def _explain(checks: list[dict]) -> str:
    bad = [c for c in checks if c["result"] in ("fail", "missing")]
    if bad:
        return "; ".join(f"{c['check']}: {c['detail']}" for c in bad)
    warn = [c for c in checks if c["result"] == "warn"]
    if warn:
        return "Limitations — " + "; ".join(f"{c['check']}: {c['detail']}" for c in warn)
    if any(c["result"] == "untested" for c in checks):
        return "Static checks pass; runtime behaviour not yet verified"
    return "All checks pass"


# ---------------------------------------------------------------- dependency analysis
_VER = re.compile(r"\d+(?:\.\d+)*")


def _vtuple(v: str):
    m = _VER.search(v or "")
    return tuple(int(x) for x in m.group(0).split(".")) if m else None


def constraint_ok(version: str, constraint: str | None) -> bool | None:
    """None when it cannot be evaluated (non-numeric versions such as 'humble')."""
    if not constraint:
        return True
    c = constraint.strip()
    m = re.match(r"^(>=|<=|==|>|<|~=)?\s*(.+)$", c)
    op, want = (m.group(1) or "=="), m.group(2)
    a, b = _vtuple(version), _vtuple(want)
    if a is None or b is None:
        return (version.strip().lower() == want.strip().lower()) if op == "==" else None
    n = max(len(a), len(b))
    a, b = a + (0,) * (n - len(a)), b + (0,) * (n - len(b))
    return {">=": a >= b, "<=": a <= b, "==": a == b, ">": a > b, "<": a < b,
            "~=": a >= b and a[0] == b[0]}[op]  # simplified compatible-release: same major, not older


def dependency_analysis(ctx: Ctx) -> list[dict]:
    out: list[dict] = []
    in_model = {c.software_id: c for c in ctx.comps.values() if c.software_id}
    db = ctx.db
    for c in ctx.comps.values():
        if c.layer == "software" and ctx.host(c) is None:
            out.append({"severity": "warning", "code": "NOT_DEPLOYED", "component": c.name,
                        "message": f"'{c.name}' is not deployed on any hardware component"})
        if c.layer == "hardware" and not c.hardware_id:
            out.append({"severity": "info", "code": "HW_UNLINKED", "component": c.name,
                        "message": f"'{c.name}' is not linked to a registered hardware item"})
        if not c.software_id:
            continue
        for d in db.query(M.SoftwareDependency).filter_by(software_id=c.software_id):
            if d.depends_on_id is None:
                continue
            target = db.get(M.SoftwareItem, d.depends_on_id)
            present = in_model.get(d.depends_on_id)
            if present is None:
                # same software name, other version in the model?
                alt = [x for x in in_model.values() if x.software_id and ctx.sw.get(x.software_id)
                       and ctx.sw[x.software_id].name == d.name]
                if alt:
                    v = ctx.sw[alt[0].software_id].version
                    ok = constraint_ok(v, d.version_constraint)
                    out.append({"severity": "critical" if ok is False else "warning", "code": "VERSION_MISMATCH",
                                "component": c.name, "message": f"'{c.name}' requires {d.name} "
                                f"{d.version_constraint or ''}; model has {v}" + (" (constraint not evaluable)" if ok is None else "")})
                else:
                    out.append({"severity": "critical", "code": "MISSING_DEPENDENCY", "component": c.name,
                                "message": f"'{c.name}' depends on {target.name if target else d.name} "
                                           f"{d.version_constraint or ''} which is not in this architecture"})
                continue
            host_c, host_d = ctx.host(c), ctx.host(present)
            if d.kind == "runtime" and host_c and host_d and host_c.id != host_d.id \
                    and present.kind in ("operating_system", "middleware", "device_driver"):
                out.append({"severity": "warning", "code": "DEPENDENCY_OTHER_HOST", "component": c.name,
                            "message": f"'{c.name}' needs {present.name} at runtime but it is deployed on "
                                       f"'{host_d.name}', not '{host_c.name}'"})
            ver = ctx.sw[present.software_id].version if present.software_id in ctx.sw else ""
            if constraint_ok(ver, d.version_constraint) is False:
                out.append({"severity": "critical", "code": "VERSION_MISMATCH", "component": c.name,
                            "message": f"'{c.name}' requires {d.name} {d.version_constraint}; model has {ver}"})
    connected = {cn.source_id for cn in ctx.conns} | {cn.target_id for cn in ctx.conns}
    for c in ctx.comps.values():
        if c.id not in connected and c.layer == "hardware":
            out.append({"severity": "info", "code": "UNCONNECTED", "component": c.name,
                        "message": f"Hardware '{c.name}' has no connections"})
    for name in _articulation_points(ctx):
        out.append({"severity": "info", "code": "SINGLE_POINT", "component": name,
                    "message": f"'{name}' is a single point of failure: removing it disconnects the hardware network"})
    rank = {"critical": 0, "warning": 1, "info": 2}
    return sorted(out, key=lambda f: (rank[f["severity"]], f["component"]))


def _articulation_points(ctx: Ctx) -> list[str]:
    adj = defaultdict(set)
    for cn in ctx.conns:
        a, b = ctx.comps.get(cn.source_id), ctx.comps.get(cn.target_id)
        ha, hb = (ctx.host(a) if a else None), (ctx.host(b) if b else None)
        if ha and hb and ha.id != hb.id and cn.interface_type not in LOGICAL:
            adj[ha.id].add(hb.id)
            adj[hb.id].add(ha.id)
    disc, low, aps, t = {}, {}, set(), [0]

    def dfs(u, parent):
        disc[u] = low[u] = t[0]
        t[0] += 1
        kids = 0
        for v in adj[u]:
            if v not in disc:
                kids += 1
                dfs(v, u)
                low[u] = min(low[u], low[v])
                if parent is not None and low[v] >= disc[u]:
                    aps.add(u)
            elif v != parent:
                low[u] = min(low[u], disc[v])
        if parent is None and kids > 1:
            aps.add(u)

    for n in list(adj):
        if n not in disc:
            dfs(n, None)
    return sorted(ctx.comps[i].name for i in aps)


def validate_model(db: Session, model_id: int) -> dict:
    ctx = Ctx(db, model_id)
    results = [validate_connection(ctx, cn) for cn in ctx.conns]
    summary = {r: 0 for r in RESULT_ORDER}
    for r in results:
        summary[r["result"]] += 1
    return {"connections": results, "summary": summary, "dependencies": dependency_analysis(ctx)}
