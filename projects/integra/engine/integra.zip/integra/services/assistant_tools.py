"""Phase 8: read-only record tools for the engineering assistant.

Every tool reads stored engineering records of ONE project (the conversation's project — the model cannot choose
another) and returns a JSON-serialisable dict whose `refs` list names the records the result was computed from
("requirement:12", "interface:7", ...). These refs are what the assistant may cite; citations are verified against them.

The same functions back the built-in analyses, which answer the common questions without any AI provider.
"""
from __future__ import annotations

import re
from collections import Counter
from sqlalchemy import or_
from sqlalchemy.orm import Session

from .. import models as M
from . import delivery as D
from . import engineering as E

REF_RE = re.compile(r"^([a-z_]+):(\d+)$")
LIMIT = 40


def _r(kind: str, id_: int) -> str:
    return f"{kind}:{id_}"


# ---------------------------------------------------------------- reference resolution
def _arch_models(db: Session, pid: int) -> list[M.ArchModel]:
    return db.query(M.ArchModel).filter_by(project_id=pid).order_by(M.ArchModel.id).all()


def ref_label(db: Session, pid: int, ref: str) -> str | None:
    """Label of a record of this project, or None if it does not exist / belongs to another project."""
    m = REF_RE.match(ref or "")
    if not m:
        return None
    kind, i = m.group(1), int(m.group(2))
    o = None
    if kind == "requirement":
        o = db.get(M.Requirement, i)
        return f"{o.ref} {o.title}" if o and o.project_id == pid else None
    if kind == "hardware":
        o = db.get(M.HardwareItem, i)
        return f"{o.asset_tag} {o.name}" if o and o.project_id == pid else None
    if kind == "software":
        o = db.get(M.SoftwareItem, i)
        return f"{o.name} {o.version}" if o and o.project_id in (pid, None) else None
    if kind in ("component", "interface"):
        o = db.get(M.ArchComponent if kind == "component" else M.ArchConnection, i)
        am = db.get(M.ArchModel, o.model_id) if o else None
        if not am or am.project_id != pid:
            return None
        if kind == "component":
            return f"{o.name} ({o.layer})"
        s, t = db.get(M.ArchComponent, o.source_id), db.get(M.ArchComponent, o.target_id)
        return f"{s.name} -> {t.name} ({o.interface_type})"
    simple = {"issue": (M.Issue, lambda o: f"{o.ref} {o.title}"), "test_case": (M.TestCase, lambda o: f"{o.ref} {o.name}"),
              "test_run": (M.TestRun, lambda o: f"run #{o.id} {o.name}"), "release": (M.Release, lambda o: f"release {o.version}"),
              "build": (M.Build, lambda o: f"build #{o.id} {o.name}"), "site": (M.Site, lambda o: f"site {o.name}"),
              "log_event": (M.LogEvent, lambda o: f"{o.ts:%Y-%m-%d %H:%M:%S} {o.level} {o.message[:80]}"),
              "acceptance": (M.AcceptanceRecord, lambda o: f"{o.ref} {o.title}"),
              "config": (M.IntegrationConfig, lambda o: f"configuration {o.name}"),
              "scenario": (M.Scenario, lambda o: f"{o.ref} {o.name}"), "test_rig": (M.TestRig, lambda o: f"rig {o.name}")}
    if kind in simple:
        cls, lab = simple[kind]
        o = db.get(cls, i)
        return lab(o) if o and getattr(o, "project_id", None) == pid else None
    if kind == "capture":
        o = db.get(M.Capture, i)
        return f"capture #{o.id} {o.name}" if o and o.project_id == pid else None
    return None


# ---------------------------------------------------------------- tools
def project_overview(db: Session, pid: int) -> dict:
    p = db.get(M.Project, pid)
    reqs = E.load_requirements(db, pid)
    rd = E.readiness(db, p, reqs)
    gate = D.final_gate(db, pid)
    issues = db.query(M.Issue).filter(M.Issue.project_id == pid, M.Issue.status.notin_(["closed", "rejected"])).all()
    rels = db.query(M.Release).filter_by(project_id=pid).order_by(M.Release.id.desc()).limit(3).all()
    return {"project": {"code": p.code, "name": p.name, "customer": p.customer.name, "stage": p.stage,
                        "acceptance_status": p.acceptance_status, "domain": p.domain},
            "readiness_score": rd["score"], "readiness_parts": {k: {x: v[x] for x in ("ready", "total", "rule")} for k, v in rd["parts"].items()},
            "requirements_by_status": dict(Counter(r.status for r in reqs)),
            "open_issues": [{"ref": _r("issue", i.id), "id": i.ref, "severity": i.severity, "status": i.status, "title": i.title} for i in issues],
            "final_gate": {"passed": gate["passed"], "blockers": [f"{b['ref']}: {b['title']}" for b in gate["blockers"]]},
            "latest_releases": [{"ref": _r("release", r.id), "version": r.version, "status": r.status} for r in rels],
            "refs": [_r("issue", i.id) for i in issues] + [_r("release", r.id) for r in rels]}


def search_records(db: Session, pid: int, query: str, limit: int = 25) -> dict:
    q = f"%{query.strip()[:80]}%"
    out = []
    for r in db.query(M.Requirement).filter(M.Requirement.project_id == pid, or_(M.Requirement.ref.ilike(q), M.Requirement.title.ilike(q), M.Requirement.description.ilike(q))).limit(limit):
        out.append({"ref": _r("requirement", r.id), "label": f"{r.ref} {r.title}", "status": r.status})
    for h in db.query(M.HardwareItem).filter(M.HardwareItem.project_id == pid, or_(M.HardwareItem.name.ilike(q), M.HardwareItem.model.ilike(q), M.HardwareItem.asset_tag.ilike(q), M.HardwareItem.manufacturer.ilike(q))).limit(limit):
        out.append({"ref": _r("hardware", h.id), "label": f"{h.asset_tag} {h.name} ({h.manufacturer} {h.model})", "status": h.status})
    for s in db.query(M.SoftwareItem).filter(or_(M.SoftwareItem.project_id == pid, M.SoftwareItem.project_id.is_(None)), M.SoftwareItem.name.ilike(q)).limit(limit):
        out.append({"ref": _r("software", s.id), "label": f"{s.name} {s.version}", "status": s.status})
    for am in _arch_models(db, pid):
        for c in db.query(M.ArchComponent).filter(M.ArchComponent.model_id == am.id, M.ArchComponent.name.ilike(q)).limit(limit):
            out.append({"ref": _r("component", c.id), "label": f"{am.name}: {c.name} ({c.layer}/{c.kind})"})
    for i in db.query(M.Issue).filter(M.Issue.project_id == pid, or_(M.Issue.title.ilike(q), M.Issue.ref.ilike(q), M.Issue.affected_subsystem.ilike(q))).limit(limit):
        out.append({"ref": _r("issue", i.id), "label": f"{i.ref} {i.title}", "status": i.status})
    for t in db.query(M.TestCase).filter(M.TestCase.project_id == pid, or_(M.TestCase.name.ilike(q), M.TestCase.ref.ilike(q))).limit(limit):
        out.append({"ref": _r("test_case", t.id), "label": f"{t.ref} {t.name}"})
    return {"query": query, "results": out[:60], "refs": [x["ref"] for x in out[:60]]}


def get_record(db: Session, pid: int, ref: str) -> dict:
    from .records import to_dict
    if ref_label(db, pid, ref) is None:
        return {"error": f"{ref} is not a record of this project", "refs": []}
    kind, i = REF_RE.match(ref).group(1), int(REF_RE.match(ref).group(2))
    cls = {"requirement": M.Requirement, "hardware": M.HardwareItem, "software": M.SoftwareItem, "component": M.ArchComponent,
           "interface": M.ArchConnection, "issue": M.Issue, "test_case": M.TestCase, "test_run": M.TestRun, "release": M.Release,
           "build": M.Build, "site": M.Site, "log_event": M.LogEvent, "acceptance": M.AcceptanceRecord, "config": M.IntegrationConfig,
           "scenario": M.Scenario, "capture": M.Capture, "test_rig": M.TestRig}[kind]
    o = db.get(cls, i)
    d = to_dict(o, exclude={"internal_notes", "content", "code", "log", "manifest", "timeline", "trajectory"})
    refs = [ref]
    if kind == "requirement":
        d["links"] = [f"{l.relation} {l.target_type}:{l.target_ref} {l.target_label}" for l in o.links]
        d["evidence"] = [f"{e.kind} {e.result}: {e.title} ({e.recorded_at:%Y-%m-%d})" for e in o.evidence]
    if kind == "test_case":
        d["code_present"] = bool(o.code)
    if kind == "build" and o.log:
        d["log_tail"] = o.log[-1500:]
    if kind == "interface":
        am = db.get(M.ArchModel, o.model_id)
        from .validation import validate_model
        v = next((c for c in validate_model(db, am.id)["connections"] if c["id"] == o.id), None)
        d["validation"] = v
        d["probes"] = [f"{p.ran_at:%Y-%m-%d %H:%M} {p.kind} {p.environment} {p.result}: {p.detail[:200]}"
                       for p in db.query(M.ConnectionProbe).filter_by(connection_id=o.id).order_by(M.ConnectionProbe.id.desc()).limit(5)]
    return {"record": d, "refs": refs}


def unvalidated_interfaces(db: Session, pid: int) -> dict:
    from .validation import validate_model
    rows = []
    for am in _arch_models(db, pid):
        for c in validate_model(db, am.id)["connections"]:
            if c["result"] in ("verified",):
                continue
            rows.append({"ref": _r("interface", c["id"]), "architecture": am.name, "connection": f"{c.get('source')} -> {c.get('target')}",
                         "interface": c.get("interface_type"), "result": c["result"], "explanation": c.get("explanation", "")[:400],
                         "failing_checks": [f"{k['check']}: {k['detail']}" for k in c.get("checks", []) if k["result"] in ("fail", "missing", "warn")][:6]})
    order = {"failed": 0, "missing_information": 1, "not_tested": 2, "verified_with_limitations": 3}
    rows.sort(key=lambda r: order.get(r["result"], 9))
    return {"count": len(rows), "by_result": dict(Counter(r["result"] for r in rows)), "interfaces": rows[:LIMIT],
            "refs": [r["ref"] for r in rows[:LIMIT]]}


def untested_requirements(db: Session, pid: int) -> dict:
    m = D.verification_matrix(db, pid)
    rows = []
    for r in m["rows"]:
        passed = [t for t in r["test_cases"] if t["result"] == "passed"]
        if r["status"] in ("passed", "approved") and r["validation_evidence"]:
            continue
        rows.append({"ref": _r("requirement", r["id"]), "id": r["ref"], "title": r["title"], "mandatory": r["mandatory"],
                     "status": r["status"], "method": r["verification_method"],
                     "linked_tests": [f"{t['ref']}: {t['result'] or 'no approved result'}" for t in r["test_cases"]],
                     "passing_tests": len(passed), "reason": r["reason"]})
    rows.sort(key=lambda r: (not r["mandatory"], r["id"]))
    return {"count": len(rows), "mandatory": sum(1 for r in rows if r["mandatory"]), "requirements": rows,
            "refs": [r["ref"] for r in rows]}


def missing_dependencies(db: Session, pid: int) -> dict:
    from .validation import validate_model
    findings, refs = [], []
    for am in _arch_models(db, pid):
        for f in validate_model(db, am.id)["dependencies"]:
            if f["severity"] == "info":
                continue
            findings.append({"architecture": am.name, "severity": f["severity"], "code": f["code"], "message": f["message"]})
    for s in db.query(M.SoftwareItem).filter_by(project_id=pid):
        for d in s.dependencies:
            if d.depends_on_id is None:
                findings.append({"software": f"{s.name} {s.version}", "severity": "info", "code": "DEP_NOT_IN_INVENTORY",
                                 "message": f"{d.name} {d.version_constraint or ''} is not a registered software item".strip(),
                                 "ref": _r("software", s.id)})
                refs.append(_r("software", s.id))
    return {"count": len(findings), "findings": findings[:LIMIT], "refs": sorted(set(refs))}


def compare_releases(db: Session, pid: int, a_version: str | None, b_version: str | None) -> dict:
    rels = db.query(M.Release).filter_by(project_id=pid).order_by(M.Release.id.desc()).all()
    if len(rels) < 2 and not (a_version and b_version):
        return {"error": f"The project has {len(rels)} release(s); two are needed to compare", "refs": [_r("release", r.id) for r in rels]}
    by_v = {r.version: r for r in rels}
    a = by_v.get(a_version) if a_version else rels[1]
    b = by_v.get(b_version) if b_version else rels[0]
    if not a or not b:
        return {"error": f"Unknown release version; existing: {', '.join(by_v)}", "refs": []}
    return D.compare_releases(db, a, b) | {"refs": [_r("release", a.id), _r("release", b.id)]}


def connection_diagnosis(db: Session, pid: int, component: str) -> dict:
    """Everything recorded about the interfaces of a component (by name): validation checks, probes, matching log
    errors, open issues, device presence. Used for 'why is X not communicating with Y'."""
    from .validation import validate_model
    q = component.strip().lower()
    out, refs = [], []
    for am in _arch_models(db, pid):
        comps = {c.id: c for c in db.query(M.ArchComponent).filter_by(model_id=am.id)}
        hits = {i for i, c in comps.items() if q in c.name.lower() or q in (c.kind or "").lower()}
        if not hits:
            continue
        val = {c["id"]: c for c in validate_model(db, am.id)["connections"]}
        for cn in db.query(M.ArchConnection).filter_by(model_id=am.id):
            if cn.source_id not in hits and cn.target_id not in hits:
                continue
            v = val.get(cn.id, {})
            probes = db.query(M.ConnectionProbe).filter_by(connection_id=cn.id).order_by(M.ConnectionProbe.id.desc()).limit(3).all()
            out.append({"ref": _r("interface", cn.id), "connection": f"{comps[cn.source_id].name} -> {comps[cn.target_id].name}",
                        "interface": cn.interface_type, "protocol": cn.protocol, "status": cn.status, "validation": v.get("result"),
                        "checks": [f"{k['result']}: {k['check']} - {k['detail']}" for k in v.get("checks", []) if k["result"] != "pass"][:8],
                        "probes": [f"{p.ran_at:%Y-%m-%d %H:%M} {p.kind} ({p.environment}) {p.result}: {p.detail[:160]}" for p in probes]})
            refs.append(_r("interface", cn.id))
        for i in hits:
            refs.append(_r("component", i))
    evs = (db.query(M.LogEvent).filter(M.LogEvent.project_id == pid, M.LogEvent.level.in_(["error", "critical", "warning"]),
                                       or_(M.LogEvent.component.ilike(f"%{q}%"), M.LogEvent.message.ilike(f"%{q}%")))
           .order_by(M.LogEvent.ts.desc()).limit(15).all())
    iss = db.query(M.Issue).filter(M.Issue.project_id == pid, M.Issue.status.notin_(["closed", "rejected"]),
                                   or_(M.Issue.title.ilike(f"%{q}%"), M.Issue.affected_subsystem.ilike(f"%{q}%"))).all()
    hw = db.query(M.HardwareItem).filter(M.HardwareItem.project_id == pid, or_(M.HardwareItem.name.ilike(f"%{q}%"), M.HardwareItem.model.ilike(f"%{q}%"))).all()
    devices = []
    for h in hw:
        d = db.query(M.DetectedDevice).filter_by(hardware_id=h.id).order_by(M.DetectedDevice.last_seen.desc()).first()
        devices.append({"ref": _r("hardware", h.id), "unit": f"{h.asset_tag} {h.name}", "inventory_status": h.status,
                        "interfaces": h.interfaces, "driver_requirements": h.driver_requirements,
                        "last_detected": (f"{d.last_seen:%Y-%m-%d %H:%M} ({'present' if d.present else 'absent'}, driver {d.driver_status or 'unknown'})"
                                          if d else "never matched by device discovery on the backend host")})
        refs.append(_r("hardware", h.id))
    refs += [_r("log_event", e.id) for e in evs] + [_r("issue", i.id) for i in iss]
    return {"component": component, "connections": out, "hardware": devices,
            "recent_log_errors": [{"ref": _r("log_event", e.id), "ts": e.ts.isoformat(timespec="milliseconds"), "level": e.level,
                                   "component": e.component, "message": e.message[:300]} for e in evs],
            "open_issues": [{"ref": _r("issue", i.id), "id": i.ref, "title": i.title, "status": i.status} for i in iss],
            "note": None if out or hw else f"No component, interface or hardware matching '{component}' in this project",
            "refs": sorted(set(refs))}


def can_capture_analysis(db: Session, pid: int, capture_id: int | None) -> dict:
    from ..hal import sessions as S
    from .analysis import can_analysis
    q = db.query(M.Capture).filter_by(project_id=pid, kind="can").order_by(M.Capture.id.desc())
    c = q.filter(M.Capture.id == capture_id).first() if capture_id else q.first()
    if not c:
        return {"error": "No CAN capture recorded for this project", "refs": []}
    cdb = None
    if c.dbc_id:
        from ..api.comms import load_dbc
        try:
            cdb = load_dbc(db, c.dbc_id)[1]
        except Exception:
            cdb = None
    res = can_analysis(S.read_records(c.id), cdb)
    if len(res.get("ids", [])) > 60:
        res["ids"] = res["ids"][:60]
    return {"capture": {"ref": _r("capture", c.id), "name": c.name, "environment": c.environment, "records": c.records,
                        "dbc": bool(cdb)}, "analysis": res, "refs": [_r("capture", c.id)]}


def log_search(db: Session, pid: int, query: str | None, min_level: str | None, limit: int = 30) -> dict:
    qry = db.query(M.LogEvent).filter(M.LogEvent.project_id == pid)
    if query:
        qry = qry.filter(or_(M.LogEvent.message.ilike(f"%{query[:80]}%"), M.LogEvent.component.ilike(f"%{query[:80]}%")))
    levels = M.LEVELS[M.LEVELS.index(min_level):] if min_level in M.LEVELS else M.LEVELS
    evs = qry.filter(M.LogEvent.level.in_(levels)).order_by(M.LogEvent.ts.desc()).limit(min(limit, 60)).all()
    return {"events": [{"ref": _r("log_event", e.id), "ts": e.ts.isoformat(timespec="milliseconds"), "level": e.level,
                        "category": e.category, "component": e.component, "message": e.message[:300]} for e in evs],
            "refs": [_r("log_event", e.id) for e in evs]}


def issues_summary(db: Session, pid: int, include_closed: bool = False) -> dict:
    qry = db.query(M.Issue).filter(M.Issue.project_id == pid)
    if not include_closed:
        qry = qry.filter(M.Issue.status.notin_(["closed", "rejected"]))
    rows = []
    for i in qry.order_by(M.Issue.ref):
        hyps = db.query(M.IssueHypothesis).filter_by(issue_id=i.id).all()
        rows.append({"ref": _r("issue", i.id), "id": i.ref, "title": i.title, "severity": i.severity, "status": i.status,
                     "subsystem": i.affected_subsystem, "actual": (i.actual_behaviour or "")[:300],
                     "confirmed_root_cause": i.confirmed_root_cause, "corrective_action": i.corrective_action,
                     "hypotheses": [f"{h.status} ({h.origin}): {h.text[:160]}" for h in hyps], "site_id": i.site_id})
    return {"count": len(rows), "issues": rows, "refs": [r["ref"] for r in rows]}


def delivery_readiness(db: Session, pid: int) -> dict:
    fg = D.final_gate(db, pid)
    refs = []
    rel = db.query(M.Release).filter_by(project_id=pid).order_by(M.Release.id.desc()).first()
    rel_checks = []
    if rel:
        rel_checks = [f"[{c['result']}] {c['title']}: {c['detail']}" for c in D.release_checks(db, rel)["checks"] if c["result"] != "pass"]
        refs.append(_r("release", rel.id))
    sites = []
    for s in db.query(M.Site).filter_by(project_id=pid):
        chk = D.latest_site_check(db, s.id)
        sites.append({"ref": _r("site", s.id), "name": s.name, "status": s.status,
                      "check": chk.status if chk else "none",
                      "failing_items": [f"{i['text']}: {i.get('detail')}" for i in (chk.items if chk else []) if i["status"] in ("fail", "pending")]})
        refs.append(_r("site", s.id))
    for b in fg["blockers"]:
        if b.get("id"):
            refs.append(_r("requirement", b["id"]))
    iss = issues_summary(db, pid)
    return {"final_gate_passed": fg["passed"], "blockers": [{"ref": _r("requirement", b["id"]) if b.get("id") else None,
                                                            "item": f"{b['ref']} {b['title']}", "reasons": b["reasons"]} for b in fg["blockers"]],
            "latest_release": {"ref": _r("release", rel.id), "version": rel.version, "status": rel.status, "open_checks": rel_checks} if rel else None,
            "sites": sites, "open_issues": iss["issues"], "refs": sorted(set(refs + iss["refs"]))}


def regression_plan(db: Session, pid: int, since_version: str | None) -> dict:
    """Test cases affected by changes since a release: software/hardware whose version or revision changed, and the
    requirements and test cases traced to them, plus test cases linked to issues closed since then."""
    rels = db.query(M.Release).filter_by(project_id=pid).order_by(M.Release.id.desc()).all()
    base = next((r for r in rels if r.version == since_version), None) if since_version else next(
        (r for r in rels if r.status in ("approved", "released")), None)
    changed_sw, changed_hw, refs = [], [], []
    if base and base.manifest:
        for s in base.manifest.get("software", []):
            cur = db.get(M.SoftwareItem, s["id"])
            if cur and (cur.version != s.get("version") or cur.commit_ref != s.get("commit_ref")):
                changed_sw.append(cur)
        for h in base.manifest.get("hardware", []):
            cur = db.get(M.HardwareItem, h["id"])
            if cur and (cur.hardware_revision != h.get("hardware_revision") or cur.firmware_version != h.get("firmware_version")):
                changed_hw.append(cur)
    else:
        changed_sw = db.query(M.SoftwareItem).filter_by(project_id=pid).filter(M.SoftwareItem.status.in_(["in_development", "integrated"])).all()
    targets = {("software", str(s.id)) for s in changed_sw} | {("hardware", str(h.id)) for h in changed_hw}
    reqs = [r for r in E.load_requirements(db, pid) if any((l.target_type, l.target_ref) in targets for l in r.links)]
    tcs: dict[int, dict] = {}
    for r in reqs:
        for l in r.links:
            if l.target_type == "test_case" and l.target_ref.isdigit():
                tc = db.get(M.TestCase, int(l.target_ref))
                if tc:
                    tcs.setdefault(tc.id, {"ref": _r("test_case", tc.id), "id": tc.ref, "name": tc.name, "environments": tc.environments,
                                           "automated": tc.automation == "pytest" and tc.code_status == "approved", "because": []})["because"].append(f"verifies {r.ref}")
    since = base.approved_at if base else None
    q = db.query(M.Issue).filter(M.Issue.project_id == pid, M.Issue.status == "closed")
    if since:
        q = q.filter(M.Issue.closed_at >= since)
    for i in q:
        for l in i.links or []:
            if l.get("type") == "test_result":
                res = db.get(M.TestResult, l["id"])
                tc = db.get(M.TestCase, res.test_case_id) if res else None
                if tc:
                    tcs.setdefault(tc.id, {"ref": _r("test_case", tc.id), "id": tc.ref, "name": tc.name, "environments": tc.environments,
                                           "automated": tc.automation == "pytest" and tc.code_status == "approved", "because": []})["because"].append(f"retest for {i.ref}")
    suites = db.query(M.TestSuite).filter_by(project_id=pid).all()
    refs += [_r("software", s.id) for s in changed_sw] + [_r("hardware", h.id) for h in changed_hw] + [_r("requirement", r.id) for r in reqs]
    refs += [t["ref"] for t in tcs.values()] + ([_r("release", base.id)] if base else [])
    return {"baseline": base.version if base else None,
            "basis": "changes since the baseline release manifest" if base and base.manifest else "no approved baseline release: software still in development/integration",
            "changed_software": [f"{s.name} {s.version}" for s in changed_sw], "changed_hardware": [f"{h.asset_tag} HW {h.hardware_revision} FW {h.firmware_version}" for h in changed_hw],
            "affected_requirements": [f"{r.ref} {r.title}" for r in reqs], "test_cases": list(tcs.values()),
            "existing_suites": [f"{s.name}: {len(s.test_case_ids)} case(s)" for s in suites], "refs": sorted(set(refs))}


def hardware_checklist(db: Session, pid: int, hardware_query: str | None) -> dict:
    """Integration checklist derived from hardware records (interfaces, power, drivers, documents, config records)."""
    qry = db.query(M.HardwareItem).filter(M.HardwareItem.project_id == pid)
    if hardware_query:
        qry = qry.filter(or_(M.HardwareItem.name.ilike(f"%{hardware_query}%"), M.HardwareItem.model.ilike(f"%{hardware_query}%"),
                             M.HardwareItem.asset_tag.ilike(f"%{hardware_query}%")))
    units = []
    for h in qry.order_by(M.HardwareItem.asset_tag):
        steps = [f"Identify unit: {h.manufacturer} {h.model} S/N {h.serial_number}, HW rev {h.hardware_revision or '(not recorded)'}, FW {h.firmware_version or '(not recorded)'}"]
        if h.supply_voltage_min or h.supply_voltage_max:
            steps.append(f"Verify supply within {h.supply_voltage_min or '?'}-{h.supply_voltage_max or '?'} V"
                         + (f", current limit <= {h.max_current_a} A" if h.max_current_a else "") + " before power-on")
        else:
            steps.append("Power requirements not recorded - obtain the datasheet value before power-on")
        for i in h.interfaces or []:
            steps.append(f"Connect and verify {i} interface (cabling, termination/pinout, link up)")
        steps.append(f"Driver: {h.driver_requirements}" if h.driver_requirements else "Driver requirements not recorded - confirm with the supplier")
        steps.append(f"Follow installation document {h.installation_doc}" if h.installation_doc else "No installation document linked")
        steps.append(f"Record configuration ({len(h.config_records)} configuration record(s) exist)")
        if h.status == "faulty":
            steps.insert(0, "UNIT IS MARKED FAULTY - do not integrate until the fault is cleared")
        units.append({"ref": _r("hardware", h.id), "unit": f"{h.asset_tag} {h.name}", "status": h.status, "steps": steps})
    return {"units": units, "refs": [u["ref"] for u in units]}


# ---------------------------------------------------------------- registry used by the agent and the built-in analyses
def _s(desc: str, props: dict, required: list[str]) -> dict:
    return {"type": "object", "properties": props, "required": required, "additionalProperties": False}


TOOLS: list[dict] = [
    {"name": "project_overview", "description": "Stage, readiness components, requirement status counts, open issues, final delivery gate and latest releases of the current project.",
     "input_schema": _s("", {}, [])},
    {"name": "search_records", "description": "Find requirements, hardware, software, architecture components, issues and test cases whose name/ID contains the text.",
     "input_schema": _s("", {"query": {"type": "string", "description": "Text to search for"}}, ["query"])},
    {"name": "get_record", "description": "Full details of one record by reference 'kind:id' (kinds: requirement, hardware, software, component, interface, issue, test_case, test_run, release, build, site, log_event, acceptance, config, scenario, capture, test_rig). Interfaces include validation checks and probes.",
     "input_schema": _s("", {"ref": {"type": "string"}}, ["ref"])},
    {"name": "unvalidated_interfaces", "description": "Architecture interfaces that are not fully verified, with validation result and failing checks.",
     "input_schema": _s("", {}, [])},
    {"name": "untested_requirements", "description": "Requirements not yet passed with validation evidence, with linked test cases and their latest approved results.",
     "input_schema": _s("", {}, [])},
    {"name": "missing_dependencies", "description": "Dependency findings of the architecture validation and software dependencies not registered in the inventory.",
     "input_schema": _s("", {}, [])},
    {"name": "compare_releases", "description": "Compare two releases (software/hardware changes, limitations, gate checks, commits). Omit versions to compare the two latest.",
     "input_schema": _s("", {"a_version": {"type": ["string", "null"]}, "b_version": {"type": ["string", "null"]}}, ["a_version", "b_version"])},
    {"name": "connection_diagnosis", "description": "Everything recorded about a component's interfaces: validation checks, probes, hardware records, recent warning/error log events and open issues. Use for 'why is X not communicating'.",
     "input_schema": _s("", {"component": {"type": "string", "description": "Component, sensor or hardware name"}}, ["component"])},
    {"name": "can_capture_analysis", "description": "Protocol analysis of a recorded CAN capture (per-ID rates vs DBC cycle times, DLC, errors). Omit capture_id for the latest.",
     "input_schema": _s("", {"capture_id": {"type": ["integer", "null"]}}, ["capture_id"])},
    {"name": "log_search", "description": "Search synchronised log events by text, optionally from a minimum level (debug, info, warning, error, critical).",
     "input_schema": _s("", {"query": {"type": ["string", "null"]}, "min_level": {"type": ["string", "null"]}}, ["query", "min_level"])},
    {"name": "issues_summary", "description": "Engineering issues with severity, status, root-cause hypotheses and corrective actions.",
     "input_schema": _s("", {"include_closed": {"type": "boolean"}}, ["include_closed"])},
    {"name": "delivery_readiness", "description": "Final delivery gate blockers, open release-gate checks, site check status and open issues.",
     "input_schema": _s("", {}, [])},
    {"name": "regression_plan", "description": "Test cases affected by software/hardware changes since a baseline release (default: latest approved) and by issues closed since then.",
     "input_schema": _s("", {"since_version": {"type": ["string", "null"]}}, ["since_version"])},
    {"name": "hardware_checklist", "description": "Integration checklist steps derived from hardware records (identity, power, interfaces, drivers, documents). Optional filter by name/model/asset tag.",
     "input_schema": _s("", {"hardware_query": {"type": ["string", "null"]}}, ["hardware_query"])},
]


def run_tool(db: Session, pid: int, name: str, args: dict) -> dict:
    a = args or {}
    f = {
        "project_overview": lambda: project_overview(db, pid),
        "search_records": lambda: search_records(db, pid, str(a.get("query") or "")),
        "get_record": lambda: get_record(db, pid, str(a.get("ref") or "")),
        "unvalidated_interfaces": lambda: unvalidated_interfaces(db, pid),
        "untested_requirements": lambda: untested_requirements(db, pid),
        "missing_dependencies": lambda: missing_dependencies(db, pid),
        "compare_releases": lambda: compare_releases(db, pid, a.get("a_version"), a.get("b_version")),
        "connection_diagnosis": lambda: connection_diagnosis(db, pid, str(a.get("component") or "")),
        "can_capture_analysis": lambda: can_capture_analysis(db, pid, a.get("capture_id")),
        "log_search": lambda: log_search(db, pid, a.get("query"), a.get("min_level")),
        "issues_summary": lambda: issues_summary(db, pid, bool(a.get("include_closed"))),
        "delivery_readiness": lambda: delivery_readiness(db, pid),
        "regression_plan": lambda: regression_plan(db, pid, a.get("since_version")),
        "hardware_checklist": lambda: hardware_checklist(db, pid, a.get("hardware_query")),
    }.get(name)
    if f is None:
        raise KeyError(f"Unknown tool {name}")
    return f()


# Built-in analyses (no AI): question -> tool
ANALYSES = {
    "overview": ("Project overview", "project_overview", {}),
    "unvalidated_interfaces": ("Which hardware interfaces have not been validated?", "unvalidated_interfaces", {}),
    "untested_requirements": ("Which customer requirements remain untested?", "untested_requirements", {}),
    "missing_dependencies": ("Identify missing system dependencies", "missing_dependencies", {}),
    "compare_releases": ("Compare the two latest software releases", "compare_releases", {"a_version": None, "b_version": None}),
    "delivery_readiness": ("Summarize integration issues before customer delivery", "delivery_readiness", {}),
    "regression_plan": ("Create a regression test plan", "regression_plan", {"since_version": None}),
    "hardware_checklist": ("Prepare a hardware integration checklist", "hardware_checklist", {"hardware_query": None}),
    "can_analysis": ("Analyse the latest CAN log", "can_capture_analysis", {"capture_id": None}),
    "connection_diagnosis": ("Why is this component not communicating?", "connection_diagnosis", {"component": ""}),
    "issues": ("Open integration issues", "issues_summary", {"include_closed": False}),
}
