"""Phase 7 services: CI/CD (local build runner, GitHub Actions adapter), release gate and manifest, release notes and
comparison, customer site checks, requirements verification matrix, acceptance and the final delivery gate.

Principles carried over from earlier phases:
* every check result is computed from stored records and carries the evidence it was computed from;
* nothing is deployed or tagged automatically — INTEGRA records what engineers did and verifies it against Git;
* CI access is read-only and secrets are never stored in the database.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy.orm import Session

from .. import config
from .. import models as M
from . import engineering as E

SHA_RE = re.compile(r"^[0-9a-fA-F]{7,64}$")
OWNER_REPO_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
INTEGRATION_TYPES = {"integration", "interface", "communication", "system"}


def _git(args: list[str], cwd: str | None, timeout: float = 20) -> str:
    from ..api.workspace import git
    return git(args, cwd, timeout)


def resolve_commit(repo: M.Repository | None, ref: str | None) -> str | None:
    """Full SHA of a commit/tag in a local working copy, or None if it cannot be resolved."""
    if not ref or not repo or not repo.path or ref.startswith("-"):
        return None
    try:
        return _git(["rev-parse", "--verify", "--quiet", f"{ref}^{{commit}}"], repo.path).strip() or None
    except HTTPException:
        return None


def same_commit(a: str | None, b: str | None) -> bool:
    if not a or not b:
        return False
    a, b = a.lower(), b.lower()
    n = min(len(a), len(b))
    return n >= 7 and a[:n] == b[:n]


# ---------------------------------------------------------------- local build runner
def run_local_build(db: Session, project: M.Project, repo: M.Repository, script: M.Script, args: list[str],
                    timeout_s: int, artifact_globs: list[str], user: M.User) -> M.Build:
    """Run an approved, unmodified build script inside the repository's working copy and record the result."""
    from ..api.workspace import EXT, _sha, interpreter
    if not repo.path or not Path(repo.path).is_dir():
        raise HTTPException(409, "Local builds need a registered local working copy")
    if script.status != "approved" or script.approved_sha256 != _sha(script.content):
        raise HTTPException(409, f"Build script '{script.name}' is not approved or changed since approval")
    interp = interpreter(script.language)
    if not interp:
        raise HTTPException(409, f"No {script.language} interpreter on the backend host")
    head = _git(["rev-parse", "HEAD"], repo.path).strip()
    branch = _git(["rev-parse", "--abbrev-ref", "HEAD"], repo.path).strip()
    dirty = bool(_git(["status", "--porcelain"], repo.path).strip())
    b = M.Build(project_id=project.id, repository_id=repo.id, source="local_script", name=f"{repo.name}: {script.name}",
                branch=branch, commit_sha=head, dirty=dirty, status="running", script_id=script.id,
                script_sha256=script.approved_sha256, started_by=user.username,
                config={"script": script.name, "script_version": script.version, "args": args, "interpreter": " ".join(interp),
                        "artifact_globs": artifact_globs, "timeout_s": timeout_s, "working_copy": repo.path})
    db.add(b)
    db.flush()
    wd = config.settings.data_dir / "builds" / str(b.id)
    wd.mkdir(parents=True, exist_ok=True)
    f = wd / f"build{EXT[script.language]}"
    f.write_text(script.content, encoding="utf-8", newline="\n")
    keep = {k: v for k, v in os.environ.items() if k.upper() in
            ("PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "HOME", "USERPROFILE", "LANG", "COMSPEC", "PATHEXT")}
    env = keep | {"INTEGRA_BUILD_ID": str(b.id), "INTEGRA_COMMIT": head, "INTEGRA_BRANCH": branch,
                  "INTEGRA_PROJECT": project.code, "PYTHONIOENCODING": "utf-8"}
    t0 = time.time()
    try:
        r = subprocess.run([*interp, str(f), *args], cwd=repo.path, env=env, capture_output=True, text=True,
                           timeout=timeout_s, errors="replace")
        b.status = "success" if r.returncode == 0 else "failure"
        b.log = (f"$ {script.name} {' '.join(args)}\n{r.stdout}" + (f"\n[stderr]\n{r.stderr}" if r.stderr else "")
                 + f"\n[exit {r.returncode}]")[-200_000:]
    except subprocess.TimeoutExpired:
        b.status, b.log = "error", f"Timed out after {timeout_s} s"
    b.duration_s = round(time.time() - t0, 3)
    b.finished_at = M.utcnow()
    b.artifacts = collect_artifacts(repo.path, artifact_globs) if b.status == "success" else []
    return b


def collect_artifacts(root: str, globs: list[str], limit: int = 200) -> list[dict]:
    base = Path(root).resolve()
    out, seen = [], set()
    for g in globs:
        if not g or g.startswith(("/", "\\")) or ".." in Path(g).parts or ":" in g:
            continue
        for p in sorted(base.glob(g)):
            rp = p.resolve()
            if not rp.is_file() or base not in rp.parents or rp in seen:
                continue
            seen.add(rp)
            h = hashlib.sha256()
            with rp.open("rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 20), b""):
                    h.update(chunk)
            out.append({"path": rp.relative_to(base).as_posix(), "size": rp.stat().st_size, "sha256": h.hexdigest()})
            if len(out) >= limit:
                return out
    return out


# ---------------------------------------------------------------- GitHub Actions adapter (read-only REST)
GH_STATUS = {"queued": "queued", "waiting": "queued", "requested": "queued", "pending": "queued",
             "in_progress": "running"}
GH_CONCLUSION = {"success": "success", "failure": "failure", "timed_out": "failure", "startup_failure": "failure",
                 "cancelled": "cancelled", "skipped": "cancelled", "neutral": "cancelled", "stale": "cancelled",
                 "action_required": "error"}


def check_api_base(url: str) -> str:
    u = urllib.parse.urlparse(url)
    if u.scheme == "https" and u.hostname:
        return url.rstrip("/")
    if u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost"):
        return url.rstrip("/")  # local test servers / emulators only
    raise HTTPException(422, "api_base must be an https:// URL (http:// only for localhost)")


def github_runs(conn: M.CiConnection, per_page: int = 50) -> list[dict]:
    q = {"per_page": str(per_page)}
    if conn.branch:
        q["branch"] = conn.branch
    url = f"{check_api_base(conn.api_base)}/repos/{conn.owner_repo}/actions/runs?{urllib.parse.urlencode(q)}"
    headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28",
               "User-Agent": "INTEGRA-Systems-Pro"}
    token = os.environ.get(conn.token_env) if conn.token_env else None
    if conn.token_env and not token:
        raise HTTPException(409, f"Environment variable {conn.token_env} is not set on the backend host")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=20) as r:
            data = json.loads(r.read())
    except urllib.error.HTTPError as e:
        body = e.read()[:300].decode(errors="replace")
        raise HTTPException(502, f"GitHub API {e.code}: {body}")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise HTTPException(502, f"GitHub API unreachable: {e}")
    runs = data.get("workflow_runs")
    if not isinstance(runs, list):
        raise HTTPException(502, "Unexpected GitHub API response (no workflow_runs)")
    if conn.workflow:
        runs = [r for r in runs if conn.workflow.lower() in f"{r.get('name', '')} {r.get('path', '')}".lower()]
    return runs


def _gh_time(s: str | None) -> datetime | None:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return None


def sync_ci(db: Session, conn: M.CiConnection, username: str) -> dict:
    created = updated = 0
    try:
        runs = github_runs(conn)
    except HTTPException as e:
        conn.last_error, conn.last_sync_at = str(e.detail), M.utcnow()
        raise
    for r in runs:
        ext = str(r.get("id"))
        status = GH_CONCLUSION.get(r.get("conclusion") or "", "error") if r.get("status") == "completed" \
            else GH_STATUS.get(r.get("status") or "", "queued")
        started, finished = _gh_time(r.get("run_started_at") or r.get("created_at")), _gh_time(r.get("updated_at"))
        b = db.query(M.Build).filter_by(project_id=conn.project_id, source="github_actions", external_id=ext).first()
        fields = dict(name=f"{r.get('name') or 'workflow'} #{r.get('run_number', '')}".strip(), branch=r.get("head_branch"),
                      commit_sha=r.get("head_sha"), status=status, url=r.get("html_url"),
                      config={"event": r.get("event"), "workflow_path": r.get("path"), "status": r.get("status"),
                              "conclusion": r.get("conclusion"), "run_attempt": r.get("run_attempt"),
                              "actor": (r.get("actor") or {}).get("login")},
                      finished_at=finished if r.get("status") == "completed" else None,
                      duration_s=round((finished - started).total_seconds(), 1) if started and finished and r.get("status") == "completed" else None)
        if b is None:
            db.add(M.Build(project_id=conn.project_id, repository_id=conn.repository_id, ci_connection_id=conn.id,
                           source="github_actions", external_id=ext, started_by=f"ci:{username}",
                           started_at=started or M.utcnow(), **fields))
            created += 1
        else:
            for k, v in fields.items():
                setattr(b, k, v)
            updated += 1
    conn.last_sync_at, conn.last_error = M.utcnow(), None
    return {"runs": len(runs), "created": created, "updated": updated}


# ---------------------------------------------------------------- release manifest & gate
def manifest(db: Session, rel: M.Release) -> dict:
    cfg = db.get(M.IntegrationConfig, rel.integration_config_id) if rel.integration_config_id else None
    items = cfg.items if cfg else []
    sw, hw, compat = [], [], []
    for it in items:
        if it["type"] == "software":
            s = db.get(M.SoftwareItem, it["id"])
            sw.append({"id": it["id"], "name": it["label"], "version": it.get("version"), "commit_ref": it.get("commit_ref"),
                       "kind": s.kind if s else None,
                       "dependencies": [f"{d.name} {d.version_constraint or ''}".strip() for d in (s.dependencies if s else [])]})
        else:
            hw.append({"id": it["id"], "label": it["label"], "model": it.get("model"), "serial_number": it.get("serial_number"),
                       "hardware_revision": it.get("hardware_revision"), "firmware_version": it.get("firmware_version")})
    for s in sw:
        for h in hw:
            c = db.query(M.HardwareCompatibility).filter_by(software_id=s["id"], hardware_id=h["id"]).first()
            compat.append({"software": f"{s['name']} {s['version']}", "hardware": h["label"],
                           "status": c.status if c else "no record", "notes": c.notes if c else None})
    b = db.get(M.Build, rel.build_id) if rel.build_id else None
    repo = db.get(M.Repository, rel.repository_id) if rel.repository_id else None
    return {"config": {"id": cfg.id, "name": cfg.name, "status": cfg.status} if cfg else None,
            "repository": repo.name if repo else None, "commit_sha": rel.commit_sha, "tag": rel.tag,
            "build": {"id": b.id, "name": b.name, "source": b.source, "status": b.status, "commit_sha": b.commit_sha,
                      "artifacts": b.artifacts} if b else None,
            "software": sw, "hardware": hw, "compatibility": compat}


def _latest_approved_suite_run(db: Session, project_id: int, suite_id: int) -> M.TestRun | None:
    return (db.query(M.TestRun).filter(M.TestRun.project_id == project_id, M.TestRun.suite_id == suite_id,
                                       M.TestRun.approved_by.isnot(None)).order_by(M.TestRun.id.desc()).first())


def release_checks(db: Session, rel: M.Release) -> dict:
    checks: list[dict] = []

    def add(key, title, result, detail):
        checks.append({"key": key, "title": title, "result": result, "detail": detail})

    repo = db.get(M.Repository, rel.repository_id) if rel.repository_id else None
    # 1 source revision
    if not rel.commit_sha:
        add("source", "Source revision", "fail", "No commit recorded for this release")
    elif repo and repo.path and not config.browser():
        full = resolve_commit(repo, rel.commit_sha)
        add("source", "Source revision", "pass" if full else "fail",
            f"{full[:12]} exists in {repo.name}" if full else f"Commit {rel.commit_sha[:12]} not found in {repo.name}")
    else:
        add("source", "Source revision", "warn", f"Commit {rel.commit_sha[:12]} recorded but not verifiable "
            + ("(browser edition: Git verification needs the desktop edition)" if config.browser() and repo else
               "(remote-only repository: register a local working copy)" if repo else "(no repository linked)"))
    # 2 version tag
    if not rel.tag:
        add("tag", "Version tag", "warn", "No version tag recorded")
    elif repo and repo.path and not config.browser():
        t = resolve_commit(repo, rel.tag)
        if not t:
            add("tag", "Version tag", "warn", f"Tag '{rel.tag}' does not exist yet. INTEGRA does not write to Git; an engineer "
                f"creates it after approval: git tag -a {rel.tag} {(rel.commit_sha or '<commit>')[:12]} -m \"{rel.version}\"")
        elif same_commit(t, rel.commit_sha):
            add("tag", "Version tag", "pass", f"Tag '{rel.tag}' points to the release commit {t[:12]}")
        else:
            add("tag", "Version tag", "fail", f"Tag '{rel.tag}' points to {t[:12]}, not the release commit {(rel.commit_sha or '-')[:12]}")
    else:
        add("tag", "Version tag", "warn", f"Tag '{rel.tag}' recorded but not verifiable "
            + ("in the browser edition" if config.browser() else "without a local working copy"))
    # 3 build
    b = db.get(M.Build, rel.build_id) if rel.build_id else None
    if not b:
        add("build", "Build", "fail", "No build linked")
    elif b.status != "success":
        add("build", "Build", "fail", f"Build #{b.id} ({b.source}) status is '{b.status}'")
    elif not same_commit(b.commit_sha, rel.commit_sha):
        add("build", "Build", "fail", f"Build #{b.id} built {(b.commit_sha or 'unknown')[:12]}, release commit is {(rel.commit_sha or '-')[:12]}")
    elif b.dirty:
        add("build", "Build", "warn", f"Build #{b.id} ran on a working copy with uncommitted changes — artefacts may not match the commit")
    else:
        add("build", "Build", "pass", f"Build #{b.id} ({b.source}) succeeded on {b.commit_sha[:12]}"
            + (f", {len(b.artifacts)} artefact(s) hashed" if b.artifacts else ""))
    # 4 integration configuration
    cfg = db.get(M.IntegrationConfig, rel.integration_config_id) if rel.integration_config_id else None
    if not cfg:
        add("config", "Hardware + software configuration", "fail", "No integration configuration linked")
    else:
        from ..api.workspace import _drift
        drift = _drift(db, cfg)
        if cfg.status != "frozen":
            add("config", "Hardware + software configuration", "fail", f"'{cfg.name}' is not frozen")
        elif drift:
            add("config", "Hardware + software configuration", "fail",
                f"'{cfg.name}' differs from inventory: " + "; ".join(f"{d['item']} {d['field']} {d['recorded']} -> {d['current']}" for d in drift[:4]))
        else:
            add("config", "Hardware + software configuration", "pass",
                f"'{cfg.name}' frozen by {cfg.frozen_by}, {len(cfg.items)} item(s), no drift")
        refs = [i.get("commit_ref") for i in cfg.items if i["type"] == "software"]
        if rel.commit_sha:
            hit = [i["label"] for i in cfg.items if i["type"] == "software" and same_commit(i.get("commit_ref"), rel.commit_sha)]
            add("config_source", "Release commit in configuration", "pass" if hit else "warn",
                f"Recorded for {', '.join(hit)}" if hit else
                f"No software item in '{cfg.name}' records commit {rel.commit_sha[:12]} (recorded: {', '.join(r[:12] for r in refs if r) or 'none'})")
        man = manifest(db, rel)
        bad = [f"{c['software']} × {c['hardware']}" for c in man["compatibility"] if c["status"] == "incompatible"]
        weak = [f"{c['software']} × {c['hardware']} ({c['status']})" for c in man["compatibility"]
                if c["status"] in ("untested", "limited", "no record")]
        if bad:
            add("compatibility", "Hardware compatibility", "fail", "Incompatible: " + "; ".join(bad[:5]))
        elif weak:
            add("compatibility", "Hardware compatibility", "warn", f"{len(weak)} pair(s) without a 'compatible' record: " + "; ".join(weak[:4]))
        elif man["compatibility"]:
            add("compatibility", "Hardware compatibility", "pass", f"{len(man['compatibility'])} software × hardware pair(s) compatible")
        else:
            add("compatibility", "Hardware compatibility", "warn", "Configuration has no software × hardware pairs to assess")
    # 5 tests
    considered: list[M.TestRun] = []
    if not rel.required_suite_ids and not rel.test_run_ids:
        add("tests", "Regression & integration tests", "fail", "No required regression suite and no test runs linked")
    for sid in rel.required_suite_ids:
        s = db.get(M.TestSuite, sid)
        if not s:
            add(f"suite:{sid}", f"Required suite #{sid}", "fail", "Suite no longer exists")
            continue
        run = _latest_approved_suite_run(db, rel.project_id, sid)
        if not run:
            add(f"suite:{sid}", f"Required suite '{s.name}'", "fail", "No approved run of this suite")
            continue
        considered.append(run)
        if run.status != "passed":
            add(f"suite:{sid}", f"Required suite '{s.name}'", "fail", f"Latest approved run #{run.id} ({run.environment}) is '{run.status}'")
        elif cfg and run.integration_config_id != cfg.id:
            add(f"suite:{sid}", f"Required suite '{s.name}'", "warn",
                f"Run #{run.id} passed but on " + (f"configuration #{run.integration_config_id}" if run.integration_config_id
                                                   else "no recorded configuration") + f", release ships '{cfg.name}'")
        else:
            add(f"suite:{sid}", f"Required suite '{s.name}'", "pass",
                f"Run #{run.id} ({run.environment}) passed, approved by {run.approved_by}")
    for rid in rel.test_run_ids:
        run = db.get(M.TestRun, rid)
        if not run or run.project_id != rel.project_id:
            add(f"run:{rid}", f"Test run #{rid}", "fail", "Run not found in this project")
            continue
        considered.append(run)
        ok = run.status == "passed" and run.approved_by
        add(f"run:{rid}", f"Test run #{rid} {run.name}", "pass" if ok else "fail",
            f"{run.environment}, {run.status}, " + (f"approved by {run.approved_by}" if run.approved_by else "NOT approved"))
    if considered:
        types = set()
        for run in considered:
            for (tt,) in (db.query(M.TestCase.test_type).join(M.TestResult, M.TestResult.test_case_id == M.TestCase.id)
                          .filter(M.TestResult.run_id == run.id)):
                types.add(tt)
        add("test_types", "Integration-level tests executed", "pass" if types & INTEGRATION_TYPES else "warn",
            f"Executed test types: {', '.join(sorted(types)) or 'none'}")
    # 6 issues
    open_iss = db.query(M.Issue).filter(M.Issue.project_id == rel.project_id, M.Issue.status.notin_(["closed", "rejected"])).all()
    crit = [i.ref for i in open_iss if i.severity == "critical"]
    major = [i.ref for i in open_iss if i.severity == "major"]
    add("issues", "Open engineering issues", "fail" if crit else "warn" if major else "pass",
        f"Critical: {', '.join(crit)}" if crit else f"Open major: {', '.join(major)}" if major else "No open critical or major issues")
    # 7 requirements (informational for lab releases; customer delivery has its own gate)
    gate = E.delivery_gate(db, rel.project_id)
    add("requirements", "Mandatory requirements verified", "pass" if gate["passed"] else "warn",
        "Delivery gate passed" if gate["passed"] else
        f"{len(gate['blockers'])} blocker(s): " + ", ".join(b_["ref"] for b_ in gate["blockers"][:8])
        + " — a release can be approved for lab use; customer delivery is gated separately")
    # 8 rollback documentation
    add("rollback", "Rollback plan", "pass" if (rel.rollback_plan or "").strip() else "fail",
        "Documented" if (rel.rollback_plan or "").strip() else "No rollback plan documented")
    # 9 known limitations must cover the warnings
    warns = [c for c in checks if c["result"] == "warn"]
    if warns and not rel.known_limitations:
        add("limitations", "Known limitations documented", "fail",
            f"{len(warns)} warning(s) above but no known limitations recorded")
    else:
        add("limitations", "Known limitations documented", "pass",
            f"{len(rel.known_limitations)} limitation(s) recorded" if rel.known_limitations else "No warnings to document")
    counts = {k: sum(1 for c in checks if c["result"] == k) for k in ("pass", "warn", "fail")}
    return {"passed": counts["fail"] == 0, "counts": counts, "checks": checks}


def release_notes_draft(db: Session, rel: M.Release) -> str:
    p = db.get(M.Project, rel.project_id)
    repo = db.get(M.Repository, rel.repository_id) if rel.repository_id else None
    prev = (db.query(M.Release).filter(M.Release.project_id == rel.project_id, M.Release.id != rel.id,
                                       M.Release.status.in_(["approved", "released"]), M.Release.created_at <= rel.created_at)
            .order_by(M.Release.id.desc()).first())
    out = [f"{p.code} {rel.version}" + (f" — {rel.name}" if rel.name else ""), ""]
    out.append(f"Source: {repo.name if repo else '(no repository)'} @ {(rel.commit_sha or '-')[:12]}" + (f", tag {rel.tag}" if rel.tag else ""))
    out.append("")
    if repo and repo.path and rel.commit_sha and SHA_RE.match(rel.commit_sha):
        rng = f"{prev.commit_sha}..{rel.commit_sha}" if prev and prev.commit_sha and SHA_RE.match(prev.commit_sha) else rel.commit_sha
        try:
            log = _git(["log", "--no-merges", "-200", "--format=%h %s (%an)", rng], repo.path)
            out.append(f"Changes since {prev.version}:" if prev else "Changes (latest commits):")
            out += [f"  - {ln}" for ln in log.splitlines()[: 60 if prev else 20]] or ["  (no commits)"]
        except HTTPException as e:
            out.append(f"Changes: could not read Git history ({e.detail})")
        out.append("")
    since = prev.approved_at if prev and prev.approved_at else None
    q = db.query(M.Issue).filter(M.Issue.project_id == rel.project_id, M.Issue.status == "closed")
    if since:
        q = q.filter(M.Issue.closed_at >= since)
    fixed = q.order_by(M.Issue.ref).all()
    if fixed:
        out.append("Resolved issues:")
        out += [f"  - {i.ref} {i.title}" + (f" — {i.corrective_action[:160]}" if i.corrective_action else "") for i in fixed]
        out.append("")
    chk = release_checks(db, rel)
    out.append("Verification:")
    out += [f"  - [{c['result'].upper()}] {c['title']}: {c['detail']}" for c in chk["checks"] if c["key"].startswith(("suite:", "run:", "test_types"))] \
        or ["  - no test evidence linked"]
    out.append("")
    out.append("Known limitations:")
    out += [f"  - {x}" for x in rel.known_limitations] or ["  - none recorded"]
    out.append("")
    out.append("DRAFT generated by INTEGRA from project records — review and edit before saving.")
    return "\n".join(out)


def compare_releases(db: Session, a: M.Release, b: M.Release) -> dict:
    ma = a.manifest if a.manifest else manifest(db, a)
    mb = b.manifest if b.manifest else manifest(db, b)
    sa = {s["name"]: s for s in ma.get("software", [])}
    sb = {s["name"]: s for s in mb.get("software", [])}
    ha = {h["label"]: h for h in ma.get("hardware", [])}
    hb = {h["label"]: h for h in mb.get("hardware", [])}

    def changed(x, y, fields):
        return [{"field": f, "from": x.get(f), "to": y.get(f)} for f in fields if x.get(f) != y.get(f)]

    commits: list[str] | str = []
    repo = db.get(M.Repository, b.repository_id) if b.repository_id else None
    if repo and repo.path and a.commit_sha and b.commit_sha and SHA_RE.match(a.commit_sha) and SHA_RE.match(b.commit_sha):
        try:
            commits = _git(["log", "--no-merges", "-200", "--format=%h %s", f"{a.commit_sha}..{b.commit_sha}"], repo.path).splitlines()
        except HTTPException as e:
            commits = f"unavailable: {e.detail}"
    ca, cb = release_checks(db, a), release_checks(db, b)
    return {
        "a": {"id": a.id, "version": a.version, "status": a.status, "commit": a.commit_sha, "gate": ca["counts"]},
        "b": {"id": b.id, "version": b.version, "status": b.status, "commit": b.commit_sha, "gate": cb["counts"]},
        "software": {"added": sorted(sb.keys() - sa.keys()), "removed": sorted(sa.keys() - sb.keys()),
                     "changed": [{"item": k, "changes": changed(sa[k], sb[k], ("version", "commit_ref"))}
                                 for k in sorted(sa.keys() & sb.keys()) if changed(sa[k], sb[k], ("version", "commit_ref"))]},
        "hardware": {"added": sorted(hb.keys() - ha.keys()), "removed": sorted(ha.keys() - hb.keys()),
                     "changed": [{"item": k, "changes": changed(ha[k], hb[k], ("hardware_revision", "firmware_version", "serial_number"))}
                                 for k in sorted(ha.keys() & hb.keys())
                                 if changed(ha[k], hb[k], ("hardware_revision", "firmware_version", "serial_number"))]},
        "limitations": {"added": [x for x in b.known_limitations if x not in a.known_limitations],
                        "removed": [x for x in a.known_limitations if x not in b.known_limitations]},
        "checks": [{"title": x["title"], "a": next((y["result"] for y in ca["checks"] if y["key"] == x["key"]), "-"), "b": x["result"]}
                   for x in cb["checks"]],
        "commits": commits,
    }


# ---------------------------------------------------------------- customer site
SITE_ITEMS = [
    ("installed", "Installed hardware registered at the site", True),
    ("identity", "Installed units match inventory (serial, hardware revision, firmware)", True),
    ("hw_health", "No installed unit marked faulty or retired", True),
    ("release", "Release to install is approved", True),
    ("release_hw", "Installed hardware matches the release configuration", True),
    ("deployment", "Installation of the release at this site recorded", True),
    ("infrastructure", "Site infrastructure documented (network, power, mounting)", True),
    ("site_issues", "No open critical or major issue at this site", True),
    ("power", "Supply voltage at the compute input measured within specification", False),
    ("network", "Network connectivity to customer systems verified", False),
    ("vehicle_network", "Connection to the vehicle network authorised and isolation confirmed by the customer", False),
    ("handover", "Customer operators briefed; operating limits and rollback procedure handed over", False),
]


def active_installations(db: Session, site_id: int) -> list[M.SiteInstallation]:
    return db.query(M.SiteInstallation).filter_by(site_id=site_id, removed_at=None).order_by(M.SiteInstallation.id).all()


def site_auto(db: Session, site: M.Site, release: M.Release | None) -> dict[str, tuple[str, str]]:
    inst = active_installations(db, site.id)
    r: dict[str, tuple[str, str]] = {}
    r["installed"] = ("pass", f"{len(inst)} unit(s) installed") if inst else ("fail", "No hardware registered at this site")
    mism, unhealthy = [], []
    for i in inst:
        h = db.get(M.HardwareItem, i.hardware_id)
        for f in ("serial_number", "hardware_revision", "firmware_version"):
            if getattr(h, f) != getattr(i, f):
                mism.append(f"{h.asset_tag} {f}: installed {getattr(i, f)} / inventory {getattr(h, f)}")
        if h.status in ("faulty", "retired"):
            unhealthy.append(f"{h.asset_tag} is {h.status}")
    r["identity"] = ("fail", "; ".join(mism[:5])) if mism else (("pass", "Installed units match inventory") if inst else ("na", "No units"))
    r["hw_health"] = ("fail", "; ".join(unhealthy)) if unhealthy else (("pass", "All installed units usable") if inst else ("na", "No units"))
    if not release:
        r["release"] = ("fail", "No release selected for this check")
        r["release_hw"] = ("na", "No release selected")
        r["deployment"] = ("na", "No release selected")
    else:
        r["release"] = ("pass", f"{release.version} is {release.status}") if release.status in ("approved", "released") \
            else ("fail", f"{release.version} is '{release.status}' (needs approved)")
        man = release.manifest or manifest(db, release)
        cfg_hw = {h["id"]: h for h in man.get("hardware", [])}
        diffs, extra = [], []
        for i in inst:
            h = cfg_hw.get(i.hardware_id)
            if not h:
                extra.append(db.get(M.HardwareItem, i.hardware_id).asset_tag)
                continue
            for f in ("hardware_revision", "firmware_version"):
                if h.get(f) != getattr(i, f):
                    diffs.append(f"{h['label']} {f}: release {h.get(f)} / installed {getattr(i, f)}")
        if diffs:
            r["release_hw"] = ("fail", "; ".join(diffs[:5]))
        elif not inst:
            r["release_hw"] = ("na", "No units")
        else:
            r["release_hw"] = ("pass", "Installed revisions match the release configuration"
                               + (f" (not in configuration: {', '.join(extra)})" if extra else ""))
        dep = db.query(M.Deployment).filter_by(release_id=release.id, site_id=site.id, status="performed").first()
        r["deployment"] = ("pass", f"Recorded by {dep.recorded_by}, performed by {dep.performed_by or dep.recorded_by}") if dep \
            else ("fail", f"No performed deployment of {release.version} recorded for this site")
    cats = {x.get("category") for x in site.infrastructure or []}
    need = {"network", "power", "mounting"}
    r["infrastructure"] = ("pass", "Network, power and mounting documented") if need <= cats else \
        ("fail", f"Missing: {', '.join(sorted(need - cats))}")
    iss = db.query(M.Issue).filter(M.Issue.site_id == site.id, M.Issue.status.notin_(["closed", "rejected"]),
                                   M.Issue.severity.in_(["critical", "major"])).all()
    r["site_issues"] = ("fail", ", ".join(f"{i.ref} ({i.severity})" for i in iss)) if iss else ("pass", "None open")
    return r


def new_site_check_items(db: Session, site: M.Site, release: M.Release | None, user: str) -> list[dict]:
    auto = site_auto(db, site, release)
    items = []
    for key, text, is_auto in SITE_ITEMS:
        st, detail = auto.get(key, ("pending", "")) if is_auto else ("pending", "")
        items.append({"key": key, "text": text, "auto": is_auto, "status": st, "detail": detail,
                      "by": "INTEGRA" if is_auto else None, "at": M.utcnow().isoformat(timespec="seconds") if is_auto else None})
    return items


# ---------------------------------------------------------------- requirements verification matrix
def verification_matrix(db: Session, project_id: int) -> dict:
    reqs = E.load_requirements(db, project_id)
    rows = []
    accepted = db.query(M.AcceptanceRecord).filter_by(project_id=project_id).all()
    for r in reqs:
        tcs = []
        for l in r.links:
            if l.target_type != "test_case" or not l.target_ref.isdigit():
                continue
            tc = db.get(M.TestCase, int(l.target_ref))
            if not tc:
                continue
            res = (db.query(M.TestResult, M.TestRun).join(M.TestRun, M.TestRun.id == M.TestResult.run_id)
                   .filter(M.TestResult.test_case_id == tc.id, M.TestRun.approved_by.isnot(None))
                   .order_by(M.TestRun.id.desc()).first())
            tcs.append({"id": tc.id, "ref": tc.ref, "name": tc.name,
                        "result": res[0].status if res else None, "run_id": res[1].id if res else None,
                        "environment": res[1].environment if res else None,
                        "approved_by": res[1].approved_by if res else None})
        latest = [t["result"] for t in tcs]
        suggestion, reason = None, None
        if r.verification_method == "test":
            if not tcs:
                reason = "No test case linked (verified_by)"
            elif any(x == "failed" or x == "error" for x in latest):
                suggestion, reason = "failed", "A linked test case's latest approved result failed"
            elif all(x == "passed" for x in latest):
                suggestion, reason = "passed", f"All {len(tcs)} linked test case(s) passed in approved runs"
            else:
                reason = f"{sum(1 for x in latest if x is None)} linked test case(s) without an approved result"
        else:
            reason = f"Verified by {r.verification_method}: record evidence"
        if suggestion == r.status or (suggestion == "passed" and r.status == "approved"):
            suggestion = None
        acc = []
        for a in accepted:
            for it in a.items:
                if it.get("requirement_id") == r.id:
                    acc.append({"record": a.ref, "kind": a.kind, "status": a.status, "result": it.get("result")})
        rows.append({"id": r.id, "ref": r.ref, "title": r.title, "mandatory": r.mandatory,
                     "verification_method": r.verification_method, "status": r.status,
                     "validation_evidence": E.has_validation_evidence(r),
                     "evidence": {k: sum(1 for e in r.evidence if e.result == k) for k in ("pass", "fail", "info")},
                     "customer_signoff": any(e.kind == "customer_signoff" for e in r.evidence),
                     "test_cases": tcs, "suggested_status": suggestion, "reason": reason, "acceptance": acc})
    summary = {"total": len(rows), "with_tests": sum(1 for x in rows if x["test_cases"]),
               "suggestions": sum(1 for x in rows if x["suggested_status"]),
               "customer_approved": sum(1 for x in rows if x["status"] == "approved")}
    return {"summary": summary, "rows": rows}


# ---------------------------------------------------------------- acceptance
def acceptance_items(db: Session, project_id: int) -> list[dict]:
    out = []
    for r in E.load_requirements(db, project_id):
        out.append({"requirement_id": r.id, "ref": r.ref, "title": r.title, "mandatory": r.mandatory,
                    "verification_method": r.verification_method, "result": "pending", "comment": None,
                    "customer_comment": None, "by": None, "at": None})
    return out


def latest_site_check(db: Session, site_id: int) -> M.SiteCheck | None:
    return db.query(M.SiteCheck).filter_by(site_id=site_id).order_by(M.SiteCheck.id.desc()).first()


def acceptance_blockers(db: Session, rec: M.AcceptanceRecord) -> list[str]:
    """Why this record cannot be signed as ACCEPTED (empty = it can)."""
    b = []
    if rec.status != "in_review":
        b.append(f"Record is '{rec.status}' (submit it for review first)")
    reqs = {r.id: r for r in E.load_requirements(db, rec.project_id)}
    for it in rec.items:
        r = reqs.get(it["requirement_id"])
        if r is None:
            b.append(f"{it['ref']}: requirement deleted")
            continue
        if it["result"] == "pending":
            b.append(f"{it['ref']}: no result recorded")
        elif it["result"] == "fail":
            b.append(f"{it['ref']}: failed (reject the record or correct and re-test)")
        elif it["result"] == "waived" and r.mandatory:
            b.append(f"{it['ref']}: mandatory requirements cannot be waived")
        elif it["result"] == "pass":
            if r.status not in E.READY_REQ:
                b.append(f"{it['ref']}: requirement status is '{r.status}' (needs passed)")
            if not any(e.result == "pass" for e in r.evidence):
                b.append(f"{it['ref']}: no passing validation evidence")
    missing = [r.ref for r in reqs.values() if r.mandatory and r.id not in {i["requirement_id"] for i in rec.items}]
    if missing:
        b.append(f"Mandatory requirement(s) not in this record: {', '.join(missing)}")
    rel = db.get(M.Release, rec.release_id) if rec.release_id else None
    if rec.kind in ("sat", "final") and not rel:
        b.append(f"A {rec.kind.upper()} must reference the release being accepted")
    if rel and rel.status not in ("approved", "released"):
        b.append(f"Release {rel.version} is '{rel.status}' (needs approved)")
    if rec.kind == "sat" and not rec.site_id:
        b.append("A SAT must reference the customer site")
    if rec.site_id:
        chk = latest_site_check(db, rec.site_id)
        if not chk or chk.status != "complete":
            b.append("Site integration check is not complete" + (f" (latest #{chk.id} is {chk.status})" if chk else ""))
    if rec.kind == "final":
        crit = [i.ref for i in db.query(M.Issue).filter(M.Issue.project_id == rec.project_id, M.Issue.severity == "critical",
                                                         M.Issue.status.notin_(["closed", "rejected"]))]
        if crit:
            b.append(f"Open critical issue(s): {', '.join(crit)}")
    return b


def acceptance_hash(rec: M.AcceptanceRecord, rel: M.Release | None, site: M.Site | None, decision: str) -> str:
    doc = {"ref": rec.ref, "kind": rec.kind, "title": rec.title, "project_id": rec.project_id, "decision": decision,
           "release": {"version": rel.version, "commit": rel.commit_sha} if rel else None,
           "site": site.name if site else None,
           "items": [[i["ref"], i["result"], i.get("comment"), i.get("customer_comment")] for i in rec.items],
           "representative": rec.customer_representative, "conditions": rec.conditions,
           "signed_by": rec.signed_by, "signed_at": rec.signed_at.isoformat() if rec.signed_at else None}
    return hashlib.sha256(json.dumps(doc, sort_keys=True, ensure_ascii=True).encode()).hexdigest()


# ---------------------------------------------------------------- final delivery gate
def final_gate(db: Session, project_id: int) -> dict:
    g = E.delivery_gate(db, project_id)
    blockers = list(g["blockers"])
    rels = (db.query(M.Release).filter(M.Release.project_id == project_id, M.Release.status.in_(["approved", "released"]))
            .order_by(M.Release.id.desc()).all())
    if not rels:
        blockers.append({"id": None, "ref": "RELEASE", "title": "No approved release",
                         "reasons": ["approve a release in CI/CD & Releases"]})
    fin = (db.query(M.AcceptanceRecord).filter_by(project_id=project_id, kind="final", status="accepted")
           .order_by(M.AcceptanceRecord.id.desc()).first())
    if not fin:
        blockers.append({"id": None, "ref": "ACCEPTANCE", "title": "No signed final acceptance",
                         "reasons": ["complete and sign a final acceptance record in Customer Delivery"]})
    return {"passed": not blockers, "mandatory": g["mandatory"], "blockers": blockers,
            "requirements_gate": g["passed"],
            "release": {"id": rels[0].id, "version": rels[0].version, "status": rels[0].status} if rels else None,
            "final_acceptance": {"id": fin.id, "ref": fin.ref, "signed_at": fin.signed_at.isoformat(timespec="seconds"),
                                 "signed_by": fin.signed_by} if fin else None}
