"""Record-derived engineering indicators: requirement coverage, delivery gate, readiness, alerts.

Nothing here is typed in by a user: every number is computed from stored records and returned together with the
counts it was computed from, so the UI can explain it.
"""
from __future__ import annotations

from collections import Counter
from datetime import date

from sqlalchemy.orm import Session, selectinload

from ..models import (REQ_STATUS, ArchModel, STAGE_KEYS, HardwareCompatibility, HardwareItem, Milestone, Project, Requirement,
                      SoftwareItem)

READY_REQ = {"passed", "approved"}
READY_SW = {"integrated", "released"}
UNUSABLE_HW = {"faulty", "retired"}
WEIGHTS = {"requirements": 0.40, "interfaces": 0.20, "hardware": 0.15, "software": 0.15, "milestones": 0.10}
VERIFIED_IF = {"verified", "verified_with_limitations"}


def load_requirements(db: Session, project_id: int) -> list[Requirement]:
    return (db.query(Requirement).options(selectinload(Requirement.links), selectinload(Requirement.evidence))
            .filter(Requirement.project_id == project_id).order_by(Requirement.ref).all())


def has_validation_evidence(r: Requirement) -> bool:
    """Evidence that validates (pass result, or a customer sign-off) — informational documents do not count."""
    return any(e.result == "pass" or e.kind == "customer_signoff" for e in r.evidence)


def coverage(db: Session, project_id: int, reqs: list[Requirement] | None = None) -> dict:
    reqs = reqs if reqs is not None else load_requirements(db, project_id)
    rows = []
    for r in reqs:
        by_type = Counter(l.target_type for l in r.links)
        rows.append({
            "id": r.id, "ref": r.ref, "title": r.title, "category": r.category, "priority": r.priority,
            "mandatory": r.mandatory, "verification_method": r.verification_method, "status": r.status,
            "links": dict(by_type), "link_count": len(r.links),
            "evidence_count": len(r.evidence),
            "validation_evidence": has_validation_evidence(r),
            "failed_evidence": sum(1 for e in r.evidence if e.result == "fail"),
            "gaps": _gaps(r, by_type),
        })
    status_counts = {s: 0 for s in REQ_STATUS}
    for r in reqs:
        status_counts[r.status] = status_counts.get(r.status, 0) + 1
    mandatory = [r for r in reqs if r.mandatory]
    return {
        "total": len(reqs),
        "mandatory": len(mandatory),
        "by_status": status_counts,
        "allocated": sum(1 for r in reqs if r.links),
        "with_validation_evidence": sum(1 for r in reqs if has_validation_evidence(r)),
        "rows": rows,
    }


def _gaps(r: Requirement, by_type: Counter) -> list[str]:
    g = []
    if not r.links:
        g.append("Not allocated to any hardware, software or architecture element")
    if r.status in READY_REQ and not has_validation_evidence(r):
        g.append(f"Status '{r.status}' without validation evidence")
    if r.status == "failed":
        g.append("Verification failed")
    if r.verification_method == "test" and r.status in {"tested", "passed", "approved"} \
            and not (by_type.get("test_case") or by_type.get("test_result")) and not r.evidence:
        g.append("Verified by test but no test case/result linked")
    return g


def delivery_gate(db: Session, project_id: int, reqs: list[Requirement] | None = None) -> dict:
    """Mandatory requirements must be passed/approved AND carry validation evidence."""
    reqs = reqs if reqs is not None else load_requirements(db, project_id)
    blockers = []
    for r in reqs:
        if not r.mandatory:
            continue
        reasons = []
        if r.status not in READY_REQ:
            reasons.append(f"status is '{r.status}' (needs passed or approved)")
        if not has_validation_evidence(r):
            reasons.append("no validation evidence (pass result or customer sign-off)")
        if reasons:
            blockers.append({"id": r.id, "ref": r.ref, "title": r.title, "reasons": reasons})
    from ..models import Issue
    for iss in db.query(Issue).filter(Issue.project_id == project_id, Issue.severity == "critical",
                                      Issue.status.notin_(["closed", "rejected"])):
        blockers.append({"id": None, "ref": iss.ref, "title": iss.title,
                         "reasons": [f"open critical issue ({iss.status})"]})
    mandatory = sum(1 for r in reqs if r.mandatory)
    if mandatory == 0:
        blockers.insert(0, {"id": None, "ref": "-", "title": "Project has no mandatory requirements",
                            "reasons": ["register and verify at least one mandatory requirement"]})
    return {"passed": not blockers, "mandatory": mandatory, "blockers": blockers}


def _share(n: int, d: int) -> float | None:
    return None if d == 0 else round(n / d, 4)


def _interface_counts(db: Session, project_id: int) -> dict:
    from .validation import validate_model  # local import: validation imports models only
    ready = total = 0
    for (mid,) in db.query(ArchModel.id).filter_by(project_id=project_id):
        for r in validate_model(db, mid)["connections"]:
            total += 1
            ready += r["result"] in VERIFIED_IF
    return {"ready": ready, "total": total, "rule": "architecture interfaces verified (static checks + recorded verification)"}


def readiness(db: Session, project: Project, reqs: list[Requirement] | None = None) -> dict:
    reqs = reqs if reqs is not None else load_requirements(db, project.id)
    hw = db.query(HardwareItem).filter_by(project_id=project.id).all()
    sw = db.query(SoftwareItem).filter_by(project_id=project.id).all()
    ms = db.query(Milestone).filter_by(project_id=project.id).all()
    parts = {
        "requirements": {"ready": sum(1 for r in reqs if r.status in READY_REQ and has_validation_evidence(r)),
                         "total": len(reqs), "rule": "passed/approved with validation evidence"},
        "hardware": {"ready": sum(1 for h in hw if h.status not in UNUSABLE_HW), "total": len(hw),
                     "rule": "assigned hardware not faulty/retired"},
        "software": {"ready": sum(1 for s in sw if s.status in READY_SW), "total": len(sw),
                     "rule": "software integrated or released"},
        "milestones": {"ready": sum(1 for m in ms if m.status == "done"), "total": len(ms),
                       "rule": "milestones done"},
        "interfaces": _interface_counts(db, project.id),
    }
    score = 0.0
    missing = []
    for k, p in parts.items():
        p["share"] = _share(p["ready"], p["total"])
        p["weight"] = WEIGHTS[k]
        if p["share"] is None:
            missing.append(k)
        else:
            score += WEIGHTS[k] * p["share"]
    return {"score": round(score * 100, 1), "parts": parts, "missing_records": missing,
            "stage_index": STAGE_KEYS.index(project.stage), "stage_count": len(STAGE_KEYS)}


def alerts(db: Session, project: Project, reqs: list[Requirement] | None = None) -> list[dict]:
    reqs = reqs if reqs is not None else load_requirements(db, project.id)
    out: list[dict] = []
    stage_i = STAGE_KEYS.index(project.stage)

    def add(sev, code, msg, ref=None):
        out.append({"severity": sev, "code": code, "message": msg, "project_id": project.id,
                    "project_code": project.code, "ref": ref})

    failed = [r.ref for r in reqs if r.status == "failed"]
    if failed:
        add("critical", "REQ_FAILED", f"{len(failed)} requirement(s) failed verification: {', '.join(failed[:6])}", failed)
    unaddressed = [r.ref for r in reqs if r.mandatory and r.status == "not_addressed"]
    if unaddressed and stage_i >= STAGE_KEYS.index("component_integration"):
        add("warning", "REQ_UNADDRESSED",
            f"{len(unaddressed)} mandatory requirement(s) still not addressed at stage '{project.stage}'", unaddressed)
    unalloc = [r.ref for r in reqs if r.mandatory and not r.links]
    if unalloc and stage_i >= STAGE_KEYS.index("hardware_preparation"):
        add("warning", "REQ_UNALLOCATED", f"{len(unalloc)} mandatory requirement(s) not allocated", unalloc)
    no_ev = [r.ref for r in reqs if r.status in READY_REQ and not has_validation_evidence(r)]
    if no_ev:
        add("warning", "EVIDENCE_MISSING", f"{len(no_ev)} requirement(s) marked passed/approved without evidence", no_ev)
    faulty = db.query(HardwareItem).filter_by(project_id=project.id, status="faulty").all()
    for h in faulty:
        add("critical", "HW_FAULTY", f"{h.asset_tag} {h.name} ({h.serial_number}) is marked faulty", h.asset_tag)
    incompatible = (db.query(HardwareCompatibility, SoftwareItem, HardwareItem)
                    .join(SoftwareItem, SoftwareItem.id == HardwareCompatibility.software_id)
                    .join(HardwareItem, HardwareItem.id == HardwareCompatibility.hardware_id)
                    .filter(SoftwareItem.project_id == project.id, HardwareCompatibility.status == "incompatible").all())
    for c, s, h in incompatible:
        add("warning", "SW_HW_INCOMPATIBLE", f"{s.name} {s.version} recorded incompatible with {h.asset_tag} {h.model}")
    from .validation import validate_model
    for am in db.query(ArchModel).filter_by(project_id=project.id):
        v = validate_model(db, am.id)
        failed_if = [f"{c['source']} -> {c['target']}" for c in v["connections"] if c["result"] == "failed"]
        if failed_if:
            add("critical" if stage_i >= STAGE_KEYS.index("interface_validation") else "warning", "INTERFACE_FAILED",
                f"{am.name}: {len(failed_if)} interface(s) fail validation: {', '.join(failed_if[:4])}", failed_if)
        crit = [f["message"] for f in v["dependencies"] if f["severity"] == "critical"]
        if crit:
            add("warning", "DEPENDENCY", f"{am.name}: {len(crit)} dependency problem(s) — {crit[0]}", crit)
    from ..models import Issue
    open_issues = db.query(Issue).filter(Issue.project_id == project.id, Issue.status.notin_(["closed", "rejected"])).all()
    crit = [i.ref for i in open_issues if i.severity == "critical"]
    if crit:
        add("critical", "ISSUE_CRITICAL", f"{len(crit)} open critical issue(s): {', '.join(crit[:5])}", crit)
    today = date.today()
    for m in db.query(Milestone).filter_by(project_id=project.id).all():
        if m.status in ("planned", "in_progress") and m.due_date and m.due_date < today:
            add("warning", "MILESTONE_OVERDUE", f"Milestone '{m.name}' overdue since {m.due_date.isoformat()}")
    if project.target_date and project.target_date < today and project.stage != "approved_for_delivery":
        add("critical", "PROJECT_OVERDUE", f"Target delivery date {project.target_date.isoformat()} has passed")
    return out
