"""Autonomous systems integration & simulation services (Phase 6).

- data-flow staging: architecture components classified into sensing -> interfaces -> perception / localisation ->
  fusion -> planning -> control -> vehicle interface (+ platform, monitoring), with the real connections between them
- ROS 2 bag analysis without a ROS installation (rosbags): per-topic rates, gaps, header-stamp latency, stamp order,
  clock-offset outliers; publishing to the debugging timeline and as runtime probes on ROS 2 topic interfaces
- simulator adapter registry: built-in kinematic simulator, rosbag2 replay, administrator-approved plugins;
  ROS 2 live / Gazebo / CARLA / Simulink listed as planned (not implemented)
"""
from __future__ import annotations

import hashlib
import importlib.util
import math
import re
import shutil
import statistics
import time
import zipfile
from datetime import datetime
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy.orm import Session

from .. import config
from .. import models as M

# ---------------------------------------------------------------- data-flow staging
STAGES = [("sensing", "Sensing"), ("interfaces", "Interfaces & drivers"), ("perception", "Perception"),
          ("localization", "Localisation"), ("fusion", "Sensor fusion"), ("planning", "Planning"), ("control", "Control"),
          ("vehicle", "Vehicle interface"), ("compute", "Compute platform"), ("monitoring", "Monitoring & logging")]
_NAME_RULES = [("planning", r"plan|behavio|route|trajector"), ("control", r"control|actuat|steer|brake|throttle"),
               ("fusion", r"fusion|tracker|tracking|world ?model"), ("localization", r"locali|odom|ins\b|slam|gnss|gps"),
               ("perception", r"percep|detect|segment|ingest|camera|lidar|radar|vision|object"),
               ("vehicle", r"gateway|vehicle|can bridge|dbw|drive.?by.?wire"), ("monitoring", r"health|monitor|diagnos|log")]
_KIND_STAGE = {"camera": "sensing", "lidar": "sensing", "radar": "sensing", "gnss": "sensing", "imu": "sensing", "sensor": "sensing",
               "can_interface": "interfaces", "media_converter": "interfaces", "ethernet_switch": "interfaces",
               "electronic_module": "interfaces", "device_driver": "interfaces", "ecu": "vehicle", "actuator": "vehicle",
               "communication_gateway": "vehicle", "main_computer": "compute", "embedded_computer": "compute",
               "microcontroller": "compute", "operating_system": "compute", "middleware": "compute",
               "monitoring_service": "monitoring", "logging": "monitoring", "diagnostic": "monitoring",
               "control_application": "control", "power_supply": "compute", "power_management": "compute"}


def stage_of(c: dict) -> str:
    if c["layer"] == "hardware" and c["kind"] in _KIND_STAGE:
        return _KIND_STAGE[c["kind"]]
    name = f"{c['name']} {(c.get('inventory') or {}).get('name', '')}".lower()
    for st, rx in _NAME_RULES:
        if re.search(rx, name):
            return st
    return _KIND_STAGE.get(c["kind"], "perception" if c["kind"] in ("sensor_processing", "data_acquisition") else "compute")


def dataflow(payload: dict) -> dict:
    comps = payload["components"]
    staged = {c["id"]: stage_of(c) for c in comps}
    for c in comps:  # a component's own 'stage' property overrides the classification
        if (c.get("properties") or {}).get("stage") in dict(STAGES):
            staged[c["id"]] = c["properties"]["stage"]
    cols = []
    for key, title in STAGES:
        members = [c for c in comps if staged[c["id"]] == key]
        cols.append({"stage": key, "title": title, "components": [
            {"id": c["id"], "name": c["name"], "layer": c["layer"], "kind": c["kind"], "inventory": c.get("inventory"),
             "host_id": c.get("host_id")} for c in members]})
    flows = []
    for cn in payload["connections"]:
        if cn["kind"] not in ("data", "control"):
            continue
        flows.append({"id": cn["id"], "source_id": cn["source_id"], "target_id": cn["target_id"],
                      "from_stage": staged[cn["source_id"]], "to_stage": staged[cn["target_id"]],
                      "interface": cn["interface_type"], "protocol": cn["protocol"], "data_type": cn["data_type"],
                      "rate_hz": cn["rate_hz"], "result": cn["validation"]["result"]})
    order = {k: i for i, (k, _) in enumerate(STAGES)}
    back = [f for f in flows if order[f["from_stage"]] > order[f["to_stage"]] and f["to_stage"] not in ("compute", "monitoring")
            and f["from_stage"] not in ("compute", "monitoring")]
    present = {s for s in staged.values()}
    gaps = [title for key, title in STAGES if key not in present and key not in ("monitoring", "compute")]
    return {"stages": cols, "flows": flows,
            "checks": {"missing_stages": gaps, "feedback_flows": len(back),
                       "unverified_flows": sum(1 for f in flows if f["result"] not in ("verified", "verified_with_limitations")),
                       "failed_flows": sum(1 for f in flows if f["result"] == "failed")}}


# ---------------------------------------------------------------- ROS 2 bags
def bag_root() -> Path:
    d = config.settings.data_dir / "bags"
    d.mkdir(parents=True, exist_ok=True)
    return d


def store_bag(raw: bytes, filename: str, bag_id: int) -> Path:
    """Bags are uploaded as a zip of the rosbag2 directory (metadata.yaml + .db3 / .mcap)."""
    dest = bag_root() / str(bag_id)
    shutil.rmtree(dest, ignore_errors=True)
    dest.mkdir(parents=True)
    zp = dest / "upload.zip"
    zp.write_bytes(raw)
    try:
        with zipfile.ZipFile(zp) as z:
            for n in z.namelist():
                if n.endswith("/"):
                    continue
                target = (dest / "bag" / Path(n).name)
                if ".." in Path(n).parts:
                    raise HTTPException(422, "Invalid path in zip")
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(n))
    except zipfile.BadZipFile:
        raise HTTPException(422, "Upload a .zip of the rosbag2 directory (metadata.yaml plus .db3 or .mcap)")
    finally:
        zp.unlink(missing_ok=True)
    if not (dest / "bag" / "metadata.yaml").exists():
        raise HTTPException(422, "The zip must contain the bag's metadata.yaml")
    return dest / "bag"


def _stamp(msg) -> float | None:
    h = getattr(msg, "header", None)
    st = getattr(h, "stamp", None) if h is not None else None
    if st is None:
        return None
    return st.sec + st.nanosec * 1e-9


def read_bag(path: Path, max_msgs: int = 2_000_000):
    """Yield (topic, msgtype, log_time_s, msg) using the pure-Python rosbags reader."""
    from rosbags.highlevel import AnyReader
    with AnyReader([path]) as r:
        n = 0
        for conn, ts, raw in r.messages():
            n += 1
            if n > max_msgs:
                break
            try:
                msg = r.deserialize(raw, conn.msgtype)
            except Exception:
                msg = None
            yield conn.topic, conn.msgtype, ts * 1e-9, msg


def analyse_bag(path: Path) -> dict:
    per: dict[str, dict] = {}
    t_min, t_max, total = math.inf, -math.inf, 0
    for topic, mt, lt, msg in read_bag(path):
        total += 1
        t_min, t_max = min(t_min, lt), max(t_max, lt)
        d = per.setdefault(topic, {"topic": topic, "msgtype": mt, "log": [], "lat": [], "back": 0, "last_stamp": None,
                                   "frames": set(), "no_header": 0})
        d["log"].append(lt)
        st = _stamp(msg) if msg is not None else None
        if st is None:
            d["no_header"] += 1
            continue
        d["lat"].append(lt - st)
        if d["last_stamp"] is not None and st < d["last_stamp"]:
            d["back"] += 1
        d["last_stamp"] = st
        fid = getattr(getattr(msg, "header", None), "frame_id", None)
        if fid:
            d["frames"].add(fid)
    topics, findings = [], []
    for topic, d in sorted(per.items()):
        lg = d["log"]
        dts = [b - a for a, b in zip(lg, lg[1:])]
        row = {"topic": topic, "msgtype": d["msgtype"], "count": len(lg), "frame_ids": sorted(d["frames"])[:5],
               "has_header": d["no_header"] == 0, "stamp_backwards": d["back"]}
        if dts:
            med = statistics.median(dts)
            row |= {"rate_hz": round((len(lg) - 1) / (lg[-1] - lg[0]), 3) if lg[-1] > lg[0] else None,
                    "period_ms": round(med * 1000, 3), "jitter_ms": round(statistics.pstdev(dts) * 1000, 3),
                    "max_gap_ms": round(max(dts) * 1000, 3)}
            gaps = [(lg[i], dts[i]) for i in range(len(dts)) if med > 0 and dts[i] > 3 * med and dts[i] > med + 0.02]
            row["gaps"] = len(gaps)
            for g0, g in gaps[:10]:
                findings.append({"severity": "warning", "topic": topic, "check": "gap", "t": g0,
                                 "detail": f"{topic}: {g * 1000:.0f} ms without messages (median period {med * 1000:.1f} ms)"})
        if d["lat"]:
            lat = sorted(d["lat"])
            row |= {"latency_ms_median": round(statistics.median(lat) * 1000, 3),
                    "latency_ms_p95": round(lat[int(0.95 * (len(lat) - 1))] * 1000, 3), "latency_ms_max": round(lat[-1] * 1000, 3)}
            neg = sum(1 for x in lat if x < -0.001)
            if neg:
                findings.append({"severity": "error", "topic": topic, "check": "stamp_in_future",
                                 "detail": f"{topic}: {neg} message(s) stamped after they were recorded (unsynchronised clock)"})
        if d["back"]:
            findings.append({"severity": "error", "topic": topic, "check": "stamp_order",
                             "detail": f"{topic}: header stamp went backwards {d['back']} time(s)"})
        if d["no_header"] and d["no_header"] < len(lg):
            findings.append({"severity": "info", "topic": topic, "check": "header", "detail": f"{topic}: {d['no_header']} message(s) without header"})
        topics.append(row)
    med_lat = [t["latency_ms_median"] for t in topics if t.get("latency_ms_median") is not None]
    sync = []
    if len(med_lat) >= 2:
        ref = statistics.median(med_lat)
        for t in topics:
            if t.get("latency_ms_median") is None:
                continue
            off = round(t["latency_ms_median"] - ref, 3)
            sync.append({"topic": t["topic"], "median_latency_ms": t["latency_ms_median"], "offset_vs_group_ms": off})
            if abs(off) > 50:
                findings.append({"severity": "warning", "topic": t["topic"], "check": "clock_offset",
                                 "detail": f"{t['topic']}: median stamp-to-record latency deviates {off:+.0f} ms from the other "
                                           f"sensors (clock offset or pipeline delay)"})
    order = {"error": 0, "warning": 1, "info": 2}
    findings.sort(key=lambda f: (order[f["severity"]], f["topic"]))
    return {"messages": total, "start": t_min if total else None, "end": t_max if total else None,
            "duration_s": round(t_max - t_min, 3) if total else 0, "topics": topics, "findings": findings, "sync": sync}


_KIND_BY_TYPE = {"sensor_msgs/msg/Imu": "imu", "sensor_msgs/msg/NavSatFix": "gnss", "sensor_msgs/msg/PointCloud2": "lidar",
                 "sensor_msgs/msg/Image": "camera", "sensor_msgs/msg/CompressedImage": "camera"}


def bag_to_messages(path: Path, topics_meta: list[dict]) -> tuple[list[dict], dict]:
    """Convert supported bag topics into simulation messages (times relative to bag start) + sensor configuration."""
    rates = {t["topic"]: t.get("rate_hz") for t in topics_meta}
    msgs, sensors, t0, lat0, lon0 = [], {}, None, None, None
    for topic, mt, lt, msg in read_bag(path):
        kind = _KIND_BY_TYPE.get(mt)
        if kind is None or msg is None:
            continue
        t0 = lt if t0 is None else t0
        name = re.sub(r"[^a-z0-9]+", "_", topic.lower()).strip("_")
        if name not in sensors:
            sensors[name] = {"type": kind, "topic": topic, "rate_hz": rates.get(topic) or 10.0,
                             "critical": kind in ("imu", "lidar", "camera")}
        st = _stamp(msg)
        stamp = (st if st is not None else lt) - t0
        if kind == "imu":
            data = {"ax": msg.linear_acceleration.x, "ay": msg.linear_acceleration.y, "az": msg.linear_acceleration.z,
                    "gz": msg.angular_velocity.z}
        elif kind == "gnss":
            lat0, lon0 = (msg.latitude, msg.longitude) if lat0 is None else (lat0, lon0)
            data = {"x": (msg.longitude - lon0) * 111320 * math.cos(math.radians(lat0)), "y": (msg.latitude - lat0) * 110540,
                    "covariance_m2": float(msg.position_covariance[0]),
                    "fix": {2: "RTK_FIXED", 1: "RTK_FLOAT"}.get(int(msg.status.status), "SINGLE")}
        elif kind == "lidar":
            data = {"points": int(msg.width) * int(msg.height)}
        else:
            data = {"width": int(getattr(msg, "width", 0)), "height": int(getattr(msg, "height", 0))}
        msgs.append({"topic": topic, "sensor": name, "kind": kind, "seq": len(msgs) + 1, "stamp": round(stamp, 6),
                     "t_recv": round(lt - t0, 6), "data": data})
    return msgs, sensors


# ---------------------------------------------------------------- simulator adapters & plugins
def plugins_dir() -> Path:
    d = config.settings.data_dir / "plugins"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def list_plugins(db: Session) -> list[dict]:
    approved = {a.filename: a for a in db.query(M.PluginApproval)}
    out = []
    for f in sorted(plugins_dir().glob("*.py")):
        sha = _sha(f)
        a = approved.get(f.name)
        out.append({"filename": f.name, "sha256": sha, "size": f.stat().st_size, "approved": bool(a and a.sha256 == sha),
                    "approved_by": a.approved_by if a else None, "changed_since_approval": bool(a and a.sha256 != sha)})
    return out


def load_plugins(db: Session) -> tuple[dict, dict, list[str]]:
    """Import approved, unchanged plugin files. A plugin module may define ADAPTERS (classes with key, title,
    run(scenario, sut_factory) -> result) and SUTS ({name: factory})."""
    adapters, suts, errors = {}, {}, []
    for p in list_plugins(db):
        if not p["approved"]:
            continue
        path = plugins_dir() / p["filename"]
        try:
            spec = importlib.util.spec_from_file_location(f"integra_plugin_{path.stem}", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            for cls in getattr(mod, "ADAPTERS", []):
                adapters[cls.key] = cls
            for k, v in getattr(mod, "SUTS", {}).items():
                suts[k] = v
        except Exception as e:  # a broken plugin must not take the backend down
            errors.append(f"{p['filename']}: {type(e).__name__}: {e}")
    return adapters, suts, errors


BUILTIN_ADAPTERS = [
    {"key": "integra_kinematic", "title": "INTEGRA kinematic simulator (built-in)", "status": "available",
     "detail": "Deterministic kinematic world, 7 sensor models, 9 fault types; isolated, no external tools."},
    {"key": "rosbag2_replay", "title": "rosbag2 replay (recorded data as SUT input)", "status": "available",
     "detail": "Replays Imu / NavSatFix / PointCloud2 / Image topics of an imported bag, with fault injection."},
    {"key": "ros2_live", "title": "ROS 2 live (rclpy)", "status": "planned",
     "detail": "Not implemented: needs a ROS 2 installation; use bag import/replay meanwhile."},
    {"key": "gazebo", "title": "Gazebo", "status": "planned", "detail": "Not implemented (adapter interface documented)."},
    {"key": "carla", "title": "CARLA", "status": "planned", "detail": "Not implemented (adapter interface documented)."},
    {"key": "simulink", "title": "MATLAB/Simulink", "status": "planned", "detail": "Not implemented (adapter interface documented)."},
]


def adapter_list(db: Session) -> dict:
    out = []
    for a in BUILTIN_ADAPTERS:
        host = True
        note = ""
        if a["key"] == "rosbag2_replay":
            host = importlib.util.find_spec("rosbags") is not None
            note = "rosbags present" if host else "rosbags not installed"
        elif a["status"] == "planned":
            host = False
            if a["key"] == "ros2_live":
                note = "rclpy found on host (adapter still not implemented)" if importlib.util.find_spec("rclpy") else "rclpy not on host"
        out.append(a | {"host_available": host, "host_note": note})
    adapters, suts, errors = load_plugins(db)
    for k, cls in adapters.items():
        out.append({"key": k, "title": getattr(cls, "title", k), "status": "plugin", "detail": getattr(cls, "detail", ""),
                    "host_available": True, "host_note": "approved plugin"})
    from integra_testkit.sim import SUTS as BUILTIN_SUTS
    return {"adapters": out, "suts": [{"key": k, "title": "INTEGRA reference supervisor (demo SUT)" if k == "reference_supervisor" else k,
                                       "origin": "built-in"} for k in BUILTIN_SUTS] +
            [{"key": k, "title": k, "origin": "plugin"} for k in suts], "plugin_errors": errors}


def run_scenario(db: Session, sc: M.Scenario, user: str) -> M.ScenarioRun:
    from integra_testkit import sim
    snap = {"duration_s": sc.duration_s, "seed": sc.seed, "world": sc.world or {}, "sensors": sc.sensors or {},
            "faults": sc.faults or [], "expectations": sc.expectations or []}
    errs = sim.validate_scenario(snap)
    if sc.adapter != "integra_kinematic":  # sensors come from the replayed bag / plugin; checked later
        errs = [e for e in errs if "unknown sensor" not in e]
    if errs:
        raise HTTPException(422, "; ".join(errs))
    adapters, suts, _ = load_plugins(db)
    if sc.sut in sim.SUTS:
        sut = None if sc.sut == "reference_supervisor" else sim.SUTS[sc.sut]
    elif sc.sut in suts:
        sut = suts[sc.sut]
    else:
        raise HTTPException(422, f"Unknown system under test '{sc.sut}'")
    t0 = time.time()
    run = M.ScenarioRun(scenario_id=sc.id, project_id=sc.project_id, adapter=sc.adapter, sut=sc.sut, status="error",
                        scenario_snapshot=snap, started_by=user)
    try:
        if sc.adapter == "integra_kinematic":
            res = sim.run(snap, sut=sut)
        elif sc.adapter == "rosbag2_replay":
            bag = db.get(M.BagFile, sc.bag_id) if sc.bag_id else None
            if bag is None:
                raise HTTPException(422, "rosbag2_replay needs a bag (bag_id)")
            msgs, sensors = bag_to_messages(bag_root() / str(bag.id) / "bag", bag.topics)
            if not msgs:
                raise HTTPException(422, "The bag has no replayable topics (Imu, NavSatFix, PointCloud2, Image)")
            snap = snap | {"sensors": sensors, "duration_s": min(sc.duration_s, max(m["t_recv"] for m in msgs))}
            for f in snap["faults"]:
                if f.get("sensor") and f["sensor"] not in sensors:
                    raise HTTPException(422, f"Fault sensor '{f['sensor']}' is not a replayed topic ({', '.join(sensors)})")
            res = sim.run(snap, sut=sut or (lambda: sim.ReferenceSupervisor(sensors)),
                          messages=sim.apply_faults(msgs, snap["faults"], sc.seed))
        elif sc.adapter in adapters:
            res = adapters[sc.adapter]().run(snap, sut)
        else:
            raise HTTPException(422, f"Simulator adapter '{sc.adapter}' is not available (planned or not installed)")
        run.status, run.expectations, run.summary = res["status"], res["expectations"], res["summary"]
        run.timeline, run.trajectory = res["timeline"], res.get("trajectory", {})
    except HTTPException:
        raise
    except Exception as e:
        run.error = f"{type(e).__name__}: {e}"
    run.scenario_snapshot = snap
    run.wall_time_s = round(time.time() - t0, 3)
    db.add(run)
    db.flush()
    return run


def run_to_timeline(db: Session, run: M.ScenarioRun) -> int:
    """Publish a scenario run (faults, diagnostics, state changes) to the debugging timeline in wall-clock time."""
    from datetime import timedelta

    from .analysis import _internal_source, store_events
    from .logparse import Parsed
    sc = db.get(M.Scenario, run.scenario_id)
    src = _internal_source(db, run.project_id, f"Scenario run #{run.id} ({sc.ref}, simulated)", "test", f"SUT {run.sut}")
    db.query(M.LogEvent).filter_by(source_id=src.id).delete()
    base = run.started_at
    lvl = {"OK": "info", "INFO": "info", "WARN": "warning", "ERROR": "error"}
    parsed = [Parsed(base + timedelta(seconds=f["start_s"]), "warning", f"[fault injected] {f['type']} on {f['target']} "
                     f"({f['start_s']}-{f['end_s']} s)", "simulator", {}) for f in run.timeline.get("faults", [])]
    parsed += [Parsed(base + timedelta(seconds=d["t"]), lvl.get(d["level"], "info"), f"{d['name']}: {d['message']}", f"SUT {run.sut}", {})
               for d in run.timeline.get("diagnostics", [])]
    parsed += [Parsed(base + timedelta(seconds=t), "error" if s == "MINIMAL_RISK" else "warning" if s in ("DEGRADED", "OFFLINE") else "info",
                      f"system state -> {s}", f"SUT {run.sut}", {}) for t, s in run.timeline.get("states", [])]
    return store_events(db, src, parsed)


def fmt_ts(x: float | None):
    return datetime.utcfromtimestamp(x) if x is not None else None
