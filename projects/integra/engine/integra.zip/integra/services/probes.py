"""Runtime probes on architecture connections (Phase 3). Results feed the runtime checks of interface validation.

All probes are non-disruptive: CAN probes listen only, serial probes read only (a simulated source is allowed on
loop:// ports), TCP probes open and close connections. Probes on virtual interfaces are recorded as
environment='virtual' and never count as hardware verification.
"""
from __future__ import annotations

import time

from fastapi import HTTPException
from sqlalchemy.orm import Session

from .. import models as M
from ..hal import sessions as S


def _ids(raw) -> set[int] | None:
    if not raw:
        return None
    out = set()
    for x in raw:
        out.add(int(x, 16) if isinstance(x, str) and x.lower().startswith("0x") else int(x))
    return out


def probe_device(db: Session, cn: M.ArchConnection, params: dict) -> dict:
    from .validation import Ctx
    ctx = Ctx(db, cn.model_id)
    hid = params.get("hardware_id")
    if hid is None:
        src = ctx.host(ctx.comps[cn.source_id])
        hid = src.hardware_id if src else None
    if hid is None:
        raise HTTPException(422, "Source is not linked to an inventory hardware item; pass params.hardware_id")
    h = db.get(M.HardwareItem, int(hid))
    devs = db.query(M.DetectedDevice).filter_by(hardware_id=h.id, present=True).all()
    if not devs:
        return {"result": "fail", "environment": "physical", "measured": {"hardware": h.asset_tag, "detected": []},
                "detail": f"{h.asset_tag} {h.model} not among devices present at the last scan (run a device scan, "
                          "or link the detected device to the inventory item)"}
    d = devs[0]
    driver_ok = (d.driver_status or "").upper() in ("OK", "UP")
    return {"result": "pass", "environment": "physical",
            "measured": {"hardware": h.asset_tag, "bus": d.bus, "identifier": d.identifier, "driver": d.driver,
                         "driver_status": d.driver_status, "driver_ok": driver_ok, "last_seen": d.last_seen.isoformat()},
            "detail": f"{h.asset_tag} detected as {d.bus}:{d.identifier} (driver {d.driver or '-'}: {d.driver_status})"}


def probe_can(cn: M.ArchConnection, p: dict) -> dict:
    cfg = {"interface": p.get("interface", "virtual"), "channel": p.get("channel", "vbus0"),
           "bitrate": p.get("bitrate", 500000), "fd": bool(p.get("fd")), "data_bitrate": p.get("data_bitrate"),
           "listen_only": True}
    dur = min(float(p.get("duration_s", 3)), 10.0)
    ids = _ids(p.get("ids"))
    bus, lo = S.open_can_bus(cfg)
    counts: dict[int, int] = {}
    errors = 0
    t_end = time.time() + dur
    try:
        while time.time() < t_end:
            m = bus.recv(0.1)
            if m is None:
                continue
            if m.is_error_frame:
                errors += 1
                continue
            if ids is None or m.arbitration_id in ids:
                counts[m.arbitration_id] = counts.get(m.arbitration_id, 0) + 1
    finally:
        bus.shutdown()
    rates = {f"0x{k:X}": round(v / dur, 2) for k, v in sorted(counts.items())}
    expected = cn.rate_hz
    if ids:
        missing = [f"0x{i:X}" for i in ids if i not in counts]
        worst = min((counts.get(i, 0) / dur for i in ids), default=0)
    else:
        missing, worst = [], sum(counts.values()) / dur
    ok = not missing and worst > 0 and (expected is None or worst >= 0.9 * expected)
    env = "virtual" if cfg["interface"] == "virtual" else "physical"
    detail = (f"{sum(counts.values())} frame(s) in {dur:g} s on {cfg['interface']}:{cfg['channel']}; "
              f"lowest rate {worst:.2f} Hz" + (f" vs expected {expected:g} Hz" if expected else "")
              + (f"; missing IDs {', '.join(missing)}" if missing else "") + (f"; {errors} error frame(s)" if errors else ""))
    return {"result": "pass" if ok else "fail", "environment": env,
            "measured": {"rates_hz": rates, "lowest_rate_hz": round(worst, 2), "error_frames": errors,
                         "duration_s": dur, "listen_only": lo}, "detail": detail}


def probe_serial(cn: M.ArchConnection, p: dict) -> dict:
    port = p.get("port")
    if not port:
        raise HTTPException(422, "params.port is required")
    sim = p.get("simulate")
    if sim and not port.startswith("loop://"):
        raise HTTPException(422, "simulate is only allowed on loop:// ports")
    dur = min(float(p.get("duration_s", 3)), 10.0)
    ser = S.open_serial({"port": port, "baudrate": p.get("baudrate", 115200)})
    lines, valid = 0, 0
    buf = b""
    rate_sim = float(p.get("simulate_rate_hz", cn.rate_hz or 10))
    nxt = time.time()
    t_end = time.time() + dur
    from ..hal.decoders import decode_nmea
    try:
        while time.time() < t_end:
            if sim and time.time() >= nxt:
                ser.write(S.nmea_sentence("GPGGA,120000.00,5221.0000,N,00445.0000,E,1,12,0.8,12.0,M,46.0,M,,"))
                nxt += 1 / rate_sim
            buf += ser.read(ser.in_waiting or 1)
            while b"\n" in buf:
                line, _, buf = buf.partition(b"\n")
                lines += 1
                d = decode_nmea(line.decode("ascii", "replace"))
                if d and d["checksum_ok"]:
                    valid += 1
    finally:
        ser.close()
    count = valid if p.get("decoder", "nmea") == "nmea" else lines
    rate = count / dur
    ok = count > 0 and (cn.rate_hz is None or rate >= 0.9 * cn.rate_hz)
    return {"result": "pass" if ok else "fail", "environment": "virtual" if port.startswith("loop://") else "physical",
            "measured": {"lines": lines, "valid_nmea": valid, "rate_hz": round(rate, 2), "duration_s": dur},
            "detail": f"{count} message(s) in {dur:g} s on {port} ({rate:.2f} Hz)"
                      + (f" vs expected {cn.rate_hz:g} Hz" if cn.rate_hz else "")}


def probe_tcp(cn: M.ArchConnection, p: dict) -> dict:
    from ..api.comms import tcp_probe
    if not p.get("host") or not p.get("port"):
        raise HTTPException(422, "params.host and params.port are required")
    r = tcp_probe(str(p["host"]), int(p["port"]), min(int(p.get("count", 5)), 20), float(p.get("timeout_s", 1)))
    budget = cn.latency_budget_ms
    avg = r["latency_ms"]["avg"] if r["latency_ms"] else None
    ok = r["loss_pct"] <= 20 and avg is not None and (budget is None or avg <= budget)
    host = str(p["host"])
    env = "virtual" if host in ("127.0.0.1", "localhost", "::1") else "physical"
    return {"result": "pass" if ok else "fail", "environment": env, "measured": r,
            "detail": f"{r['succeeded']}/{r['attempts']} connections to {host}:{p['port']}"
                      + (f", avg {avg} ms" if avg is not None else "") + (f" (budget {budget:g} ms)" if budget else "")
                      + (" — loopback, not a network path" if env == "virtual" else "")}


RUNNERS = {"can_traffic": probe_can, "serial_traffic": probe_serial, "tcp_reachable": probe_tcp}


def run_probe(db: Session, cn: M.ArchConnection, kind: str, params: dict) -> dict:
    if kind == "device_present":
        return probe_device(db, cn, params)
    if kind == "ros2_topic":
        raise HTTPException(422, "ros2_topic probes are created from an imported ROS 2 bag (Simulation → bags)")
    try:
        return RUNNERS[kind](cn, params)
    except HTTPException:
        raise
    except Exception as e:
        return {"result": "fail", "environment": "virtual" if params.get("interface") == "virtual" else "physical",
                "measured": {}, "detail": f"Probe could not run: {type(e).__name__}: {e}"}
