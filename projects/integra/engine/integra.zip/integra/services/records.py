"""Serialization and configuration versioning (entity revisions)."""
from __future__ import annotations

from datetime import date, datetime
from typing import Any

from sqlalchemy import func
from sqlalchemy.orm import Session

from ..models import EntityRevision, utcnow

_SKIP = {"updated_at", "created_at"}


def _plain(v: Any) -> Any:
    if isinstance(v, datetime):
        return v.isoformat(timespec="seconds")
    if isinstance(v, date):
        return v.isoformat()
    return v


def to_dict(obj, exclude: set[str] | None = None) -> dict:
    ex = exclude or set()
    return {c.key: _plain(getattr(obj, c.key)) for c in obj.__table__.columns if c.key not in ex}


def snapshot(obj) -> dict:
    return {k: v for k, v in to_dict(obj).items() if k not in _SKIP}


def record_revision(db: Session, entity_type: str, obj, user: str, comment: str | None = None) -> EntityRevision | None:
    """Store a snapshot if anything changed since the last revision. Call after flush()."""
    snap = snapshot(obj)
    last = (db.query(EntityRevision).filter_by(entity_type=entity_type, entity_id=obj.id)
            .order_by(EntityRevision.revision.desc()).first())
    if last is not None:
        changed = sorted(k for k in set(snap) | set(last.snapshot) if snap.get(k) != last.snapshot.get(k))
        if not changed:
            return None
    else:
        changed = sorted(snap)
    rev = EntityRevision(entity_type=entity_type, entity_id=obj.id, revision=(last.revision + 1) if last else 1,
                         snapshot=snap, changed_fields=changed, changed_by=user, changed_at=utcnow(), comment=comment)
    db.add(rev)
    return rev


def revision_count(db: Session, entity_type: str, entity_id: int) -> int:
    return db.query(func.count(EntityRevision.id)).filter_by(entity_type=entity_type, entity_id=entity_id).scalar() or 0


def diff(a: dict, b: dict) -> list[dict]:
    keys = sorted(set(a) | set(b))
    return [{"field": k, "from": a.get(k), "to": b.get(k)} for k in keys if a.get(k) != b.get(k)]
