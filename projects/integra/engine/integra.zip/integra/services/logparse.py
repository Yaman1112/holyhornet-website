"""Log parsing, normalisation and categorisation (Phase 5).

Supported formats (auto-detected per file from the first lines):
  jsonl           one JSON object per line (ts/time/timestamp/@timestamp, level/severity, msg/message, component/logger/node)
  journald_json   `journalctl -o json` (__REALTIME_TIMESTAMP, PRIORITY, MESSAGE, SYSLOG_IDENTIFIER)
  syslog          RFC 5424 and RFC 3164 (kernel / daemon logs)
  ros2            `[LEVEL] [epoch.ns] [node]: message`
  python_logging  `YYYY-MM-DD HH:MM:SS,mmm - name - LEVEL - msg` and common variants
  tegrastats      NVIDIA Jetson `tegrastats` lines (RAM, CPU load/freq, GPU, temperatures, power rails)
  text            any line starting with an ISO-like timestamp; other lines are continuation lines (tracebacks)
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

LEVEL_WORDS = {
    "trace": "debug", "debug": "debug", "d": "debug", "verbose": "debug", "v": "debug",
    "info": "info", "i": "info", "notice": "info", "information": "info",
    "warn": "warning", "warning": "warning", "w": "warning",
    "err": "error", "error": "error", "e": "error",
    "fatal": "critical", "crit": "critical", "critical": "critical", "f": "critical", "emerg": "critical",
    "alert": "critical", "panic": "critical",
}
SYSLOG_SEV = {0: "critical", 1: "critical", 2: "critical", 3: "error", 4: "warning", 5: "info", 6: "info", 7: "debug"}

CATEGORY_RULES: list[tuple[str, re.Pattern]] = [
    ("crash", re.compile(r"segfault|sigsegv|sigabrt|core dumped|traceback \(most recent|unhandled exception|panic|"
                         r"terminate called|stack trace|aborted \(core", re.I)),
    ("build", re.compile(r"cmake error|undefined reference|compilation terminated|build failed|ninja: build stopped|"
                         r"colcon .*failed|error: .*\.(c|cpp|h|hpp):\d+|make(\[\d+\])?: \*\*\*", re.I)),
    ("test", re.compile(r"\bFAILED\b|assertionerror|test(s)? failed|pytest", re.I)),
    ("communication", re.compile(r"bus-?off|error[ -]passive|error[ -]warning|can(fd)?\d?:|arbitration lost|"
                                 r"no ack|crc error|frame error|packet loss|udp|tcp|socket|heartbeat|link (down|up)|"
                                 r"timeout waiting for|dbc|someip|dds", re.I)),
    ("driver", re.compile(r"driver|probe (failed|of)|usb \d|usb disconnect|firmware|kernel module|insmod|modprobe|"
                          r"peak_usb|mttcan|nvgpu|deserializer|gmsl|i2c|spi|xhci", re.I)),
    ("resource", re.compile(r"tegrastats|out of memory|oom|no space left|enospc|throttl|thermal|overheat|cpu (load|usage)|"
                            r"memory (usage|pressure)|disk full|swap", re.I)),
    ("timing", re.compile(r"latency|deadline|overrun|jitter|late by|too slow|period exceeded|stale|clock|ptp|sync", re.I)),
    ("sensor", re.compile(r"sensor|camera|lidar|radar|gnss|imu|frame drop|dropped frame|no data|point ?cloud|exposure", re.I)),
    ("api", re.compile(r"http [45]\d\d|status[ =:]+[45]\d\d|connection refused|grpc|rest api|endpoint|503|502", re.I)),
    ("hardware", re.compile(r"voltage|current|power (fail|loss)|brown-?out|fan|temperature|ecu|hardware", re.I)),
]

TS_ISO = re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d{1,9})?(?:Z|[+-]\d{2}:?\d{2})?)\s*")
MONTHS = {m: i for i, m in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}
RFC3164 = re.compile(r"^(?:<(?P<pri>\d{1,3})>)?(?P<mon>[A-Z][a-z]{2}) {1,2}(?P<day>\d{1,2}) (?P<time>\d{2}:\d{2}:\d{2}) "
                     r"(?P<host>\S+) (?P<tag>[^:\[\s]+)(?:\[(?P<pid>\d+)\])?: ?(?P<msg>.*)$")
RFC5424 = re.compile(r"^<(?P<pri>\d{1,3})>1 (?P<ts>\S+) (?P<host>\S+) (?P<app>\S+) (?P<pid>\S+) (?P<msgid>\S+) "
                     r"(?P<sd>-|\[.*?\]) ?(?P<msg>.*)$")
ROS2 = re.compile(r"^\[(?P<level>[A-Z]+)\] \[(?P<ts>\d+(?:\.\d+)?)\] \[(?P<node>[^\]]+)\]: (?P<msg>.*)$")
PYLOG = re.compile(r"^(?P<ts>\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[.,]\d{1,6})?)\s*(?:-\s*)?"
                   r"(?:(?P<a_name>[\w.\-/]+) - (?P<a_level>[A-Za-z]+) - |(?P<b_level>[A-Z]{4,8})\s+(?P<b_name>[\w.\-/]+)[:\]]?\s+|"
                   r"\[(?P<c_level>[A-Za-z]+)\]\s+(?:\[(?P<c_name>[^\]]+)\]\s+)?)(?P<msg>.*)$")
TEGRA_TS = re.compile(r"^(?P<ts>\d{2}-\d{2}-\d{4} \d{2}:\d{2}:\d{2}) (?P<rest>RAM .*)$")
KV_NUM = re.compile(r"(?<![\w.])(?P<k>[A-Za-z_][\w.]{0,40})[=:](?P<v>-?\d+(?:\.\d+)?)(?:\s?(?P<u>ms|s|us|hz|%|c|v|a|w|mb|kb))?\b", re.I)

NORM = [(re.compile(r"0x[0-9a-fA-F]+"), "<HEX>"), (re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f-]{27}\b", re.I), "<UUID>"),
        (re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b"), "<IP>"), (re.compile(r"'[^']*'|\"[^\"]*\""), "<STR>"),
        (re.compile(r"-?\d+(?:\.\d+)?"), "<N>")]


@dataclass
class Parsed:
    ts: datetime  # naive UTC
    level: str
    message: str
    component: str | None = None
    fields: dict = field(default_factory=dict)


def norm_level(v) -> str | None:
    if v is None:
        return None
    if isinstance(v, int):
        return SYSLOG_SEV.get(v)
    s = str(v).strip().lower()
    if s.isdigit():
        return SYSLOG_SEV.get(int(s))
    return LEVEL_WORDS.get(s)


def infer_level(msg: str) -> str:
    m = msg.lower()
    if re.search(r"\b(fatal|panic|segfault|core dumped)\b", m):
        return "critical"
    if re.search(r"\b(error|failed|failure|exception|traceback|bus-off|refused)\b", m):
        return "error"
    if re.search(r"\b(warn|warning|deprecated|retry|retrying|timeout|throttl)", m):
        return "warning"
    return "info"


def _to_utc(dt: datetime, tz_offset_min: int) -> datetime:
    if dt.tzinfo is not None:
        return dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt - timedelta(minutes=tz_offset_min)


def parse_ts(v, tz_offset_min: int = 0) -> datetime | None:
    if v is None:
        return None
    if isinstance(v, (int, float)) or (isinstance(v, str) and re.fullmatch(r"\d{9,19}(\.\d+)?", v.strip())):
        x = float(v)
        while x > 1e11:  # ms / us / ns epochs
            x /= 1000
        return datetime.fromtimestamp(x, timezone.utc).replace(tzinfo=None)
    s = str(v).strip().replace(",", ".")
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    s = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", s)
    m = re.match(r"^(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2})(\.\d+)?(.*)$", s)
    if m and m.group(2) and len(m.group(2)) > 7:
        s = m.group(1) + m.group(2)[:7] + m.group(3)
    try:
        return _to_utc(datetime.fromisoformat(s.replace(" ", "T", 1)), tz_offset_min)
    except ValueError:
        return None


def extract_numbers(msg: str) -> dict:
    out = {}
    for m in KV_NUM.finditer(msg):
        k = m.group("k").lower()
        if m.group("u") and not k.endswith(m.group("u").lower()):
            k = f"{k}_{m.group('u').lower()}"
        out[k] = float(m.group("v"))
    return out


def template_of(component: str | None, msg: str) -> tuple[str, str]:
    t = msg.strip().splitlines()[0] if msg.strip() else ""
    for rx, rep in NORM:
        t = rx.sub(rep, t)
    t = t[:300]
    fp = hashlib.sha1(f"{component or ''}|{t}".encode()).hexdigest()[:16]
    return t, fp


def categorize(msg: str, component: str | None, source_kind: str) -> str:
    text = f"{component or ''} {msg}"
    for cat, rx in CATEGORY_RULES:
        if rx.search(text):
            return cat
    return {"application": "application", "system": "system", "hardware": "hardware", "communication": "communication",
            "driver": "driver", "sensor": "sensor", "api": "api", "build": "build", "test": "test",
            "resource": "resource", "analysis": "timing"}.get(source_kind, "application")


# ---------------------------------------------------------------- per-format line parsers
def p_jsonl(line: str, tz: int, _year: int) -> Parsed | None:
    try:
        o = json.loads(line)
    except ValueError:
        return None
    if not isinstance(o, dict):
        return None
    if "__REALTIME_TIMESTAMP" in o:
        return p_journald(o, tz)
    ts = None
    for k in ("ts", "time", "timestamp", "@timestamp", "t", "datetime", "date"):
        if k in o:
            ts = parse_ts(o.pop(k), tz)
            break
    if ts is None:
        return None
    level = None
    for k in ("level", "severity", "lvl", "levelname", "log_level"):
        if k in o:
            level = norm_level(o.pop(k))
            break
    msg = ""
    for k in ("msg", "message", "text", "event"):
        if k in o:
            msg = str(o.pop(k))
            break
    comp = None
    for k in ("component", "logger", "name", "node", "module", "service", "source"):
        if k in o and isinstance(o[k], str):
            comp = o.pop(k)
            break
    fields = {k: v for k, v in o.items() if isinstance(v, (int, float, str, bool)) and len(str(v)) < 200}
    return Parsed(ts, level or infer_level(msg), msg, comp, fields)


def p_journald(o: dict, tz: int) -> Parsed | None:
    ts = parse_ts(int(o["__REALTIME_TIMESTAMP"]), tz)
    msg = o.get("MESSAGE")
    if isinstance(msg, list):  # journald encodes binary messages as byte arrays
        msg = bytes(msg).decode(errors="replace")
    level = SYSLOG_SEV.get(int(o.get("PRIORITY", 6)), "info")
    comp = o.get("SYSLOG_IDENTIFIER") or o.get("_COMM") or o.get("_SYSTEMD_UNIT")
    fields = {k: o[k] for k in ("_PID", "_SYSTEMD_UNIT", "_HOSTNAME", "_TRANSPORT") if k in o}
    return Parsed(ts, level, str(msg or ""), comp, fields)


def p_syslog(line: str, tz: int, year: int) -> Parsed | None:
    m = RFC5424.match(line)
    if m:
        ts = parse_ts(m.group("ts"), tz)
        if ts is None:
            return None
        pri = int(m.group("pri"))
        return Parsed(ts, SYSLOG_SEV[pri % 8], m.group("msg"), m.group("app"), {"host": m.group("host")})
    m = RFC3164.match(line)
    if m:
        try:
            dt = datetime(year, MONTHS[m.group("mon")], int(m.group("day")), *map(int, m.group("time").split(":")))
        except (KeyError, ValueError):
            return None
        ts = _to_utc(dt, tz)
        msg = m.group("msg")
        level = SYSLOG_SEV[int(m.group("pri")) % 8] if m.group("pri") else infer_level(msg)
        kt = re.match(r"^\[\s*(\d+\.\d+)\]\s*(.*)$", msg)  # kernel monotonic stamp
        fields = {"host": m.group("host")}
        if kt:
            fields["kernel_time_s"] = float(kt.group(1))
            msg = kt.group(2)
        return Parsed(ts, level, msg, m.group("tag"), fields)
    return None


def p_ros2(line: str, tz: int, _year: int) -> Parsed | None:
    m = ROS2.match(line)
    if not m:
        return None
    return Parsed(parse_ts(m.group("ts"), tz), norm_level(m.group("level")) or "info", m.group("msg"), m.group("node"))


def p_pylog(line: str, tz: int, _year: int) -> Parsed | None:
    m = PYLOG.match(line)
    if not m:
        return None
    lvl = m.group("a_level") or m.group("b_level") or m.group("c_level")
    name = m.group("a_name") or m.group("b_name") or m.group("c_name")
    level = norm_level(lvl)
    if level is None:
        return None
    ts = parse_ts(m.group("ts"), tz)
    return Parsed(ts, level, m.group("msg"), name) if ts else None


def p_tegrastats(line: str, tz: int, _year: int) -> Parsed | None:
    m = TEGRA_TS.match(line.strip())
    if not m:
        return None
    try:
        ts = _to_utc(datetime.strptime(m.group("ts"), "%m-%d-%Y %H:%M:%S"), tz)
    except ValueError:
        return None
    rest = m.group("rest")
    f: dict = {}
    r = re.search(r"RAM (\d+)/(\d+)MB", rest)
    if r:
        f["ram_used_mb"], f["ram_total_mb"] = float(r.group(1)), float(r.group(2))
        f["ram_pct"] = round(100 * f["ram_used_mb"] / f["ram_total_mb"], 1)
    c = re.search(r"CPU \[([^\]]+)\]", rest)
    if c:
        loads, freqs = [], []
        for core in c.group(1).split(","):
            mm = re.match(r"(\d+)%@(\d+)", core.strip())
            if mm:
                loads.append(int(mm.group(1)))
                freqs.append(int(mm.group(2)))
        if loads:
            f["cpu_load_pct"] = round(sum(loads) / len(loads), 1)
            f["cpu_freq_mhz"] = round(sum(freqs) / len(freqs))
    g = re.search(r"GR3D_FREQ (\d+)%", rest)
    if g:
        f["gpu_load_pct"] = float(g.group(1))
    for name, val in re.findall(r"(\w+)@(-?\d+(?:\.\d+)?)C", rest):
        f[f"temp_{name.lower()}_c"] = float(val)
    for name, val in re.findall(r"(VDD_\w+|VIN_\w+) (\d+)mW", rest):
        f[f"power_{name.lower()}_mw"] = float(val)
    temps = [v for k, v in f.items() if k.startswith("temp_")]
    summary = f"RAM {f.get('ram_pct', '?')}% · CPU {f.get('cpu_load_pct', '?')}% @ {f.get('cpu_freq_mhz', '?')} MHz · " \
              f"GPU {f.get('gpu_load_pct', '?')}% · max temp {max(temps) if temps else '?'} °C"
    return Parsed(ts, "info", summary, "tegrastats", f)


def p_text(line: str, tz: int, _year: int) -> Parsed | None:
    m = TS_ISO.match(line)
    if not m:
        return None
    ts = parse_ts(m.group("ts"), tz)
    if ts is None:
        return None
    rest = line[m.end():]
    lm = re.match(r"^\[?(?P<lvl>[A-Za-z]{1,8})\]?[:\s]\s*(?P<rest>.*)$", rest)
    level = norm_level(lm.group("lvl")) if lm else None
    if level:
        rest = lm.group("rest")
    comp = None
    cm = re.match(r"^\[?(?P<c>[\w.\-/]{2,60})\]?: (?P<m>.*)$", rest)
    if cm:
        comp, rest = cm.group("c"), cm.group("m")
    return Parsed(ts, level or infer_level(rest), rest, comp)


PARSERS = {"jsonl": p_jsonl, "journald_json": p_jsonl, "syslog": p_syslog, "ros2": p_ros2, "python_logging": p_pylog,
           "tegrastats": p_tegrastats, "text": p_text}


def detect_format(lines: list[str], year: int) -> str:
    sample = [l for l in lines if l.strip()][:40]
    best, score = "text", -1
    for name in ("journald_json", "jsonl", "tegrastats", "ros2", "syslog", "python_logging", "text"):
        fn = PARSERS[name]
        ok = 0
        for l in sample:
            try:
                p = fn(l.rstrip("\n"), 0, year)
            except Exception:
                p = None
            if p is not None:
                if name == "journald_json" and "__REALTIME_TIMESTAMP" not in l:
                    continue
                ok += 1
        if ok > score:
            best, score = name, ok
    return best


def parse_lines(lines: list[str], fmt: str, tz_offset_min: int = 0, year: int | None = None) -> tuple[str, list[Parsed], int]:
    """Return (format used, events, unparsed line count). Unparseable lines continue the previous event."""
    year = year or datetime.utcnow().year
    if fmt == "auto":
        fmt = detect_format(lines, year)
    fn = PARSERS[fmt]
    out: list[Parsed] = []
    unparsed = 0
    for raw in lines:
        line = raw.rstrip("\r\n")
        if not line.strip():
            continue
        try:
            p = fn(line, tz_offset_min, year)
        except Exception:
            p = None
        if p is None:
            if out and fmt in ("text", "python_logging", "syslog", "ros2"):
                out[-1].message += "\n" + line  # multi-line message (traceback, wrapped line)
                if re.search(r"traceback|exception|error", line, re.I) and out[-1].level in ("info", "debug"):
                    out[-1].level = "error"
            else:
                unparsed += 1
            continue
        p.fields = {**extract_numbers(p.message), **p.fields}
        out.append(p)
    return fmt, out, unparsed
