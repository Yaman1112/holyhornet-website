"""Test execution engine (Phase 4).

Each automated test case is a reviewed pytest file. A run executes every case of a suite in its own working directory
(data/test-runs/<run>/<ref>/) with the environment variables documented in integra_testkit, collects the JUnit XML
and the recorded measurements, evaluates expected measurement ranges and stores one TestResult per case.

Environments are kept distinct: sil (software only, virtual devices), virtual_rig (rig made of virtual instruments and
buses), hil (physical rig: needs a completed checklist and an approved HIL authorisation), manual.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from .. import config
from .. import models as M
from ..db import session_scope

TESTKIT_DIR = Path(__file__).resolve().parents[2]  # directory containing the integra_testkit package
CASE_TIMEOUT_S = int(os.environ.get("INTEGRA_TEST_TIMEOUT_S", "180"))
_running: dict[int, threading.Thread] = {}


def sha(s: str | None) -> str:
    return hashlib.sha256((s or "").encode()).hexdigest()


def code_runnable(tc: M.TestCase) -> bool:
    return tc.automation == "pytest" and tc.code_status == "approved" and tc.code_sha256 == sha(tc.code)


def python_for_tests() -> list[str] | None:
    """Interpreter used for pytest: INTEGRA_TEST_PYTHON, the backend's own Python in development, or python on PATH."""
    if os.environ.get("INTEGRA_TEST_PYTHON"):
        return [os.environ["INTEGRA_TEST_PYTHON"]]
    if not getattr(sys, "frozen", False):
        return [sys.executable]
    p = shutil.which("python") or shutil.which("python3")
    return [p] if p else None


def testkit_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", ".")) / "testkit"
    return TESTKIT_DIR


def check_interpreter() -> dict:
    from .. import config
    if config.browser():
        return {"python": None, "pytest": False, "can": False, "browser": True,
                "detail": "Browser edition: automated tests run in a separate Python process, which only the desktop edition has"}
    py = python_for_tests()
    if not py:
        return {"python": None, "pytest": False, "can": False, "detail": "No Python interpreter found"}
    probe = "import importlib.util as u;print(bool(u.find_spec('pytest')), bool(u.find_spec('can')), bool(u.find_spec('cantools')))"
    try:
        r = subprocess.run([*py, "-c", probe], capture_output=True, text=True, timeout=20)
        pt, cn, ct = (r.stdout.strip().split() + ["False"] * 3)[:3]
        return {"python": py[0], "pytest": pt == "True", "can": cn == "True" and ct == "True", "detail": r.stderr.strip()[:200]}
    except (OSError, subprocess.TimeoutExpired) as e:
        return {"python": py[0], "pytest": False, "can": False, "detail": str(e)}


def _in_range(value, spec: dict) -> bool | None:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    if spec.get("min") is not None and v < float(spec["min"]):
        return False
    if spec.get("max") is not None and v > float(spec["max"]):
        return False
    return True


def _parse_junit(path: Path) -> list[dict]:
    if not path.exists():
        return []
    out = []
    for tc in ET.parse(path).getroot().iter("testcase"):
        st, msg = "passed", ""
        for tag in ("failure", "error", "skipped"):
            el = tc.find(tag)
            if el is not None:
                st = {"failure": "failed", "error": "error", "skipped": "skipped"}[tag]
                msg = (el.get("message") or "") + ("\n" + el.text if el.text else "")
                break
        out.append({"name": tc.get("name"), "classname": tc.get("classname"), "time_s": float(tc.get("time") or 0),
                    "status": st, "message": msg[:4000]})
    return out


def run_case(tc: M.TestCase, run: M.TestRun, rig_json: dict | None, dbc_text: str | None, hil_ok: bool,
             scenario_json: dict | None = None) -> dict:
    wd = config.settings.data_dir / "test-runs" / str(run.id) / tc.ref
    shutil.rmtree(wd, ignore_errors=True)
    (wd / "results").mkdir(parents=True)
    f = wd / f"test_{tc.ref.replace('-', '_').lower()}.py"
    f.write_text(tc.code or "", encoding="utf-8", newline="\n")
    # isolate pytest from any configuration in parent folders (pyproject.toml / setup.cfg / conftest.py)
    (wd / "pytest.ini").write_text("[pytest]\n", encoding="utf-8")
    env = {k: v for k, v in os.environ.items() if k.upper() in
           ("PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "HOME", "USERPROFILE", "LANG", "COMSPEC", "PATHEXT")}
    env |= {"PYTHONPATH": str(testkit_root()), "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1",
            "INTEGRA_ENVIRONMENT": run.environment, "INTEGRA_RUN_ID": str(run.id), "INTEGRA_TEST_REF": tc.ref,
            "INTEGRA_RESULTS_DIR": str(wd / "results"), "INTEGRA_HIL_AUTHORIZED": "1" if hil_ok else "0"}
    if rig_json:
        env["INTEGRA_RIG_JSON"] = json.dumps(rig_json)
    if scenario_json:
        (wd / "scenario.json").write_text(json.dumps(scenario_json), encoding="utf-8")
        env["INTEGRA_SCENARIO_PATH"] = str(wd / "scenario.json")
    if dbc_text:
        (wd / "attached.dbc").write_text(dbc_text, encoding="utf-8")
        env["INTEGRA_DBC_PATH"] = str(wd / "attached.dbc")
    py = python_for_tests()
    t0 = time.time()
    if not py:
        return {"status": "error", "log": "No Python interpreter available for pytest", "checks": [], "measurements": [],
                "duration_s": 0.0}
    cmd = [*py, "-m", "pytest", f.name, "-q", "-c", "pytest.ini", "--rootdir", ".", "--confcutdir", ".",
           "-p", "no:cacheprovider", "--junitxml", "junit.xml", "-o", "junit_family=xunit2", "--color=no"]
    try:
        r = subprocess.run(cmd, cwd=wd, env=env, capture_output=True, text=True, timeout=CASE_TIMEOUT_S, errors="replace")
        log = (r.stdout + ("\n" + r.stderr if r.stderr else ""))[-60_000:]
        timed_out = False
    except subprocess.TimeoutExpired as e:
        log = f"Timed out after {CASE_TIMEOUT_S} s\n" + ((e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or ""))
        timed_out = True
    checks = _parse_junit(wd / "junit.xml")
    meas = []
    mf = wd / "results" / "measurements.jsonl"
    if mf.exists():
        for line in mf.read_text(encoding="utf-8").splitlines():
            if line.strip():
                m = json.loads(line)
                spec = (tc.expected_measurements or {}).get(m["name"])
                m["limits"] = spec
                m["ok"] = _in_range(m["value"], spec) if spec else None
                meas.append(m)
    statuses = {c["status"] for c in checks}
    if timed_out:
        status = "error"
    elif not checks:
        status = "error"
        log = "No tests were collected or pytest could not start.\n" + log
    elif "error" in statuses:
        status = "error"
    elif "failed" in statuses:
        status = "failed"
    elif statuses == {"skipped"}:
        status = "skipped"
    else:
        status = "passed"
    out_of_range = [m for m in meas if m["ok"] is False]
    if status == "passed" and out_of_range:
        status = "failed"
    missing = [n for n in (tc.expected_measurements or {}) if n not in {m["name"] for m in meas}]
    if status == "passed" and missing:
        status = "failed"
    summary = [f"{m['name']} = {m['value']}{(' ' + m['unit']) if m.get('unit') else ''}"
               + (f" (limits {m['limits'].get('min', '-')}..{m['limits'].get('max', '-')}: {'OK' if m['ok'] else 'OUT OF RANGE'})"
                  if m.get('limits') else (f" (expected {m['expected']})" if m.get('expected') else "")) for m in meas]
    if missing:
        summary.append(f"Expected measurement(s) not recorded: {', '.join(missing)}")
    summary.append(f"pytest: {sum(c['status'] == 'passed' for c in checks)} passed, "
                   f"{sum(c['status'] in ('failed', 'error') for c in checks)} failed/error, "
                   f"{sum(c['status'] == 'skipped' for c in checks)} skipped")
    return {"status": status, "log": log, "checks": checks, "measurements": meas, "actual_output": "\n".join(summary),
            "duration_s": round(time.time() - t0, 3)}


def rig_payload(db, rig: M.TestRig | None) -> dict | None:
    if rig is None:
        return None
    from ..hal import scpi
    comps = []
    for c in db.query(M.RigComponent).filter_by(rig_id=rig.id):
        d = {"key": c.key, "name": c.name, "role": c.role, "properties": c.properties or {},
             "can": (c.properties or {}).get("can")}
        ep = scpi.endpoint(c.properties, f"rig{rig.id}:{c.key}")
        if ep:
            d["scpi_endpoint"] = {"host": ep[0], "port": ep[1], "virtual": ep[2]}
        if c.hardware_id:
            h = db.get(M.HardwareItem, c.hardware_id)
            d["hardware"] = {"asset_tag": h.asset_tag, "model": h.model, "serial_number": h.serial_number,
                             "hardware_revision": h.hardware_revision, "firmware_version": h.firmware_version}
        comps.append(d)
    return {"id": rig.id, "name": rig.name, "kind": rig.kind, "components": comps}


def recompute(db, run: M.TestRun) -> None:
    res = db.query(M.TestResult).filter_by(run_id=run.id).all()
    counts = {s: 0 for s in M.RESULT_STATUS + ["pending"]}
    for r in res:
        counts[r.status] = counts.get(r.status, 0) + 1
    run.summary = {"total": len(res), **counts}
    if counts["pending"]:
        run.status = "open"
    elif counts["failed"] or counts["error"] or counts["blocked"]:
        run.status = "failed"
    elif counts["passed"]:
        run.status = "passed"
    else:
        run.status = "error"


def _execute(run_id: int, hil_ok: bool) -> None:
    with session_scope() as db:
        run = db.get(M.TestRun, run_id)
        run.status = "running"
    try:
        with session_scope() as db:
            run = db.get(M.TestRun, run_id)
            rig = db.get(M.TestRig, run.rig_id) if run.rig_id else None
            rig_json = rig_payload(db, rig)
            results = db.query(M.TestResult).filter_by(run_id=run_id).order_by(M.TestResult.id).all()
            jobs = []
            for r in results:
                tc = db.get(M.TestCase, r.test_case_id)
                dbc = db.get(M.DbcFile, tc.dbc_id).content if tc.dbc_id else None
                sc = db.get(M.Scenario, tc.scenario_id) if tc.scenario_id else None
                scj = {"ref": sc.ref, "name": sc.name, "duration_s": sc.duration_s, "seed": sc.seed, "world": sc.world,
                       "sensors": sc.sensors, "faults": sc.faults, "expectations": sc.expectations} if sc else None
                jobs.append((r.id, tc, dbc, scj))
            db.expunge_all()
        for rid, tc, dbc, scj in jobs:
            with session_scope() as db:
                r = db.get(M.TestResult, rid)
                if r.status != "queued":
                    continue
                run = db.get(M.TestRun, run_id)
                db.expunge(run)
            out = run_case(tc, run, rig_json, dbc, hil_ok, scj)
            with session_scope() as db:
                r = db.get(M.TestResult, rid)
                r.status, r.log, r.checks, r.measurements = out["status"], out["log"], out["checks"], out["measurements"]
                r.actual_output, r.duration_s = out.get("actual_output"), out["duration_s"]
                r.code_sha256, r.executed_by, r.executed_at = tc.code_sha256, "integra-runner", M.utcnow()
    except Exception as e:  # pragma: no cover - defensive
        with session_scope() as db:
            run = db.get(M.TestRun, run_id)
            run.summary = (run.summary or {}) | {"runner_error": f"{type(e).__name__}: {e}"}
    finally:
        with session_scope() as db:
            run = db.get(M.TestRun, run_id)
            for r in db.query(M.TestResult).filter_by(run_id=run_id, status="queued"):
                r.status, r.log = "error", "Runner stopped before this case executed"
            recompute(db, run)
            run.finished_at = M.utcnow() if run.status != "open" else None
        _running.pop(run_id, None)


def start(run_id: int, hil_ok: bool, wait: bool = False) -> None:
    t = threading.Thread(target=_execute, args=(run_id, hil_ok), daemon=True, name=f"testrun-{run_id}")
    _running[run_id] = t
    t.start()
    if wait:
        t.join()


def is_running(run_id: int) -> bool:
    return run_id in _running
