"""Run the API: python -m integra [--port 8980]"""
import argparse

import uvicorn

from . import config

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default=config.settings.host)
    ap.add_argument("--port", type=int, default=config.settings.port)
    a = ap.parse_args()
    uvicorn.run("integra.main:app", host=a.host, port=a.port, log_level="info")
