"""ORM models (Phase 1 schema). Dialect-neutral: runs on SQLite and PostgreSQL.

Controlled vocabularies are declared here and validated in the API layer, so the database stays portable
(plain strings instead of native ENUM types).
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from sqlalchemy import (JSON, Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ---------------------------------------------------------------- vocabularies
STAGES = [
    ("requirements_pending", "Requirements pending"),
    ("architecture_in_progress", "Architecture in progress"),
    ("hardware_preparation", "Hardware preparation"),
    ("software_preparation", "Software preparation"),
    ("component_integration", "Component integration"),
    ("interface_validation", "Interface validation"),
    ("system_testing", "System testing"),
    ("hil_testing", "Hardware-in-the-loop testing"),
    ("sil_testing", "Software-in-the-loop testing"),
    ("customer_validation", "Customer validation"),
    ("release_candidate", "Release candidate"),
    ("approved_for_delivery", "Approved for delivery"),
]
STAGE_KEYS = [k for k, _ in STAGES]
GATED_STAGES = {"release_candidate", "approved_for_delivery"}

DOMAINS = ["autonomous_vehicles", "autonomous_trucking", "robotics", "embedded_systems", "automotive_electronics",
           "sensor_integration", "industrial_automation", "computer_controlled_hardware", "autonomous_mobile_platforms"]
ACCEPTANCE = ["not_started", "in_review", "accepted", "rejected"]
PRIORITIES = ["low", "medium", "high", "critical"]
MILESTONE_STATUS = ["planned", "in_progress", "done", "missed"]

REQ_CATEGORIES = ["functional", "performance", "interface", "safety", "environmental", "regulatory", "hardware",
                  "software", "operational"]
REQ_PRIORITY = ["must", "should", "could"]
VERIFICATION = ["test", "analysis", "inspection", "demonstration"]
REQ_STATUS = ["not_addressed", "in_development", "integrated", "tested", "passed", "failed", "approved"]
TRACE_TARGETS = ["hardware", "software", "architecture_component", "interface", "task", "test_case", "test_result",
                 "document"]
TRACE_RELATIONS = ["allocated_to", "implemented_by", "verified_by", "satisfied_by", "documented_in"]
EVIDENCE_KINDS = ["test_result", "inspection_record", "analysis", "demonstration", "customer_signoff", "document"]
EVIDENCE_RESULTS = ["pass", "fail", "info"]

HW_CATEGORIES = ["embedded_computer", "nvidia_jetson", "raspberry_pi", "industrial_computer", "microcontroller",
                 "automotive_ecu", "camera", "lidar", "radar", "gnss", "imu", "can_adapter", "ethernet_adapter",
                 "ethernet_switch", "usb_device", "serial_device", "power_supply", "power_management", "actuator",
                 "custom_pcb", "communication_gateway", "measurement_instrument", "other"]
HW_INTERFACES = ["USB", "Serial", "UART", "SPI", "I2C", "CAN", "CAN FD", "LIN", "Ethernet", "Automotive Ethernet",
                 "GPIO", "GMSL", "MIPI CSI-2", "PCIe", "RS-485", "PPS", "Power"]
HW_STATUS = ["available", "reserved", "in_integration", "in_test", "faulty", "retired"]

SW_KINDS = ["operating_system", "middleware", "device_driver", "embedded_application", "api", "communication_service",
            "sensor_processing", "data_acquisition", "control_application", "monitoring_service", "logging",
            "diagnostic", "library", "tooling"]
SW_LANGUAGES = ["Python", "C", "C++", "Bash", "Rust", "Other"]
SW_STATUS = ["planned", "in_development", "integrated", "released", "deprecated"]
DEP_KINDS = ["runtime", "build", "test"]
COMPAT_STATUS = ["compatible", "limited", "incompatible", "untested"]


# ---------------------------------------------------------------- users & access
class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(128))
    email: Mapped[str | None] = mapped_column(String(160))
    role: Mapped[str] = mapped_column(String(40))
    password_hash: Mapped[str] = mapped_column(String(256))
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_login: Mapped[datetime | None] = mapped_column(DateTime)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    username: Mapped[str] = mapped_column(String(64), index=True)
    action: Mapped[str] = mapped_column(String(64))
    entity: Mapped[str] = mapped_column(String(64))
    entity_id: Mapped[str | None] = mapped_column(String(64))
    project_id: Mapped[int | None] = mapped_column(Integer, index=True)
    summary: Mapped[str | None] = mapped_column(String(300))
    detail: Mapped[dict | None] = mapped_column(JSON)
    ip: Mapped[str | None] = mapped_column(String(64))


class EntityRevision(Base):
    """Configuration versioning: a JSON snapshot per change of a versioned entity."""
    __tablename__ = "entity_revisions"
    __table_args__ = (UniqueConstraint("entity_type", "entity_id", "revision"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(40), index=True)
    entity_id: Mapped[int] = mapped_column(Integer, index=True)
    revision: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    changed_fields: Mapped[list] = mapped_column(JSON, default=list)
    changed_by: Mapped[str] = mapped_column(String(64))
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    comment: Mapped[str | None] = mapped_column(String(300))


# ---------------------------------------------------------------- customers & projects
class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), unique=True)
    industry: Mapped[str | None] = mapped_column(String(80))
    contact_name: Mapped[str | None] = mapped_column(String(120))
    contact_email: Mapped[str | None] = mapped_column(String(160))
    contact_phone: Mapped[str | None] = mapped_column(String(60))
    address: Mapped[str | None] = mapped_column(Text)
    notes: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Project(Base):
    __tablename__ = "projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"))
    domain: Mapped[str] = mapped_column(String(40))
    description: Mapped[str | None] = mapped_column(Text)
    objectives: Mapped[list] = mapped_column(JSON, default=list)
    use_cases: Mapped[list] = mapped_column(JSON, default=list)
    validation_criteria: Mapped[list] = mapped_column(JSON, default=list)
    stage: Mapped[str] = mapped_column(String(40), default="requirements_pending")
    priority: Mapped[str] = mapped_column(String(16), default="medium")
    acceptance_status: Mapped[str] = mapped_column(String(16), default="not_started")
    restricted: Mapped[bool] = mapped_column(Boolean, default=False)
    lead_engineer_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    start_date: Mapped[date | None] = mapped_column(Date)
    target_date: Mapped[date | None] = mapped_column(Date)
    internal_notes: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    customer: Mapped[Customer] = relationship()


class ProjectMember(Base):
    __tablename__ = "project_members"
    __table_args__ = (UniqueConstraint("project_id", "user_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    project_role: Mapped[str] = mapped_column(String(60))  # free text: "Lead integration engineer", ...
    added_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    user: Mapped[User] = relationship()


class StageHistory(Base):
    __tablename__ = "stage_history"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    from_stage: Mapped[str | None] = mapped_column(String(40))
    to_stage: Mapped[str] = mapped_column(String(40))
    changed_by: Mapped[str] = mapped_column(String(64))
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    note: Mapped[str | None] = mapped_column(Text)


class Milestone(Base):
    __tablename__ = "milestones"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    deliverable: Mapped[str | None] = mapped_column(Text)
    due_date: Mapped[date | None] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(16), default="planned")
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime)


class CustomerFeedback(Base):
    __tablename__ = "customer_feedback"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    author: Mapped[str] = mapped_column(String(64))
    received_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    category: Mapped[str] = mapped_column(String(32), default="comment")  # comment | change_request | issue | approval
    text: Mapped[str] = mapped_column(Text)
    response: Mapped[str | None] = mapped_column(Text)
    responded_by: Mapped[str | None] = mapped_column(String(64))


# ---------------------------------------------------------------- requirements & traceability
class Requirement(Base):
    __tablename__ = "requirements"
    __table_args__ = (UniqueConstraint("project_id", "ref"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    ref: Mapped[str] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(240))
    description: Mapped[str | None] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(24), default="functional")
    priority: Mapped[str] = mapped_column(String(8), default="must")
    mandatory: Mapped[bool] = mapped_column(Boolean, default=True)
    verification_method: Mapped[str] = mapped_column(String(16), default="test")
    acceptance_criteria: Mapped[str | None] = mapped_column(Text)
    target_value: Mapped[str | None] = mapped_column(String(120))  # e.g. "<= 100 ms", ">= 30 fps"
    source: Mapped[str | None] = mapped_column(String(200))  # customer document / clause
    status: Mapped[str] = mapped_column(String(16), default="not_addressed")
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("requirements.id", ondelete="SET NULL"))
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    links: Mapped[list["TraceLink"]] = relationship(cascade="all, delete-orphan", back_populates="requirement")
    evidence: Mapped[list["Evidence"]] = relationship(cascade="all, delete-orphan", back_populates="requirement")


class TraceLink(Base):
    __tablename__ = "trace_links"
    __table_args__ = (UniqueConstraint("requirement_id", "target_type", "target_ref", "relation"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    requirement_id: Mapped[int] = mapped_column(ForeignKey("requirements.id", ondelete="CASCADE"), index=True)
    target_type: Mapped[str] = mapped_column(String(32))
    target_ref: Mapped[str] = mapped_column(String(64))  # id of the target record (string: future targets vary)
    target_label: Mapped[str] = mapped_column(String(240))
    relation: Mapped[str] = mapped_column(String(24), default="allocated_to")
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    requirement: Mapped[Requirement] = relationship(back_populates="links")


class Evidence(Base):
    __tablename__ = "evidence"
    id: Mapped[int] = mapped_column(primary_key=True)
    requirement_id: Mapped[int] = mapped_column(ForeignKey("requirements.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(24))
    title: Mapped[str] = mapped_column(String(240))
    reference: Mapped[str | None] = mapped_column(String(400))  # document id, report path, URL, test run id
    result: Mapped[str] = mapped_column(String(8), default="info")
    hardware_config: Mapped[str | None] = mapped_column(String(240))
    software_config: Mapped[str | None] = mapped_column(String(240))
    notes: Mapped[str | None] = mapped_column(Text)
    recorded_by: Mapped[str] = mapped_column(String(64))
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    requirement: Mapped[Requirement] = relationship(back_populates="evidence")


# ---------------------------------------------------------------- hardware inventory
class HardwareItem(Base):
    __tablename__ = "hardware_items"
    __table_args__ = (UniqueConstraint("manufacturer", "model", "serial_number"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"), index=True)
    asset_tag: Mapped[str] = mapped_column(String(32), unique=True)
    name: Mapped[str] = mapped_column(String(160))
    category: Mapped[str] = mapped_column(String(32))
    manufacturer: Mapped[str] = mapped_column(String(120))
    model: Mapped[str] = mapped_column(String(120))
    serial_number: Mapped[str] = mapped_column(String(120))
    hardware_revision: Mapped[str | None] = mapped_column(String(40))
    firmware_version: Mapped[str | None] = mapped_column(String(60))
    specifications: Mapped[dict] = mapped_column(JSON, default=dict)
    supply_voltage_min: Mapped[float | None] = mapped_column(Float)
    supply_voltage_max: Mapped[float | None] = mapped_column(Float)
    max_current_a: Mapped[float | None] = mapped_column(Float)
    max_power_w: Mapped[float | None] = mapped_column(Float)
    interfaces: Mapped[list] = mapped_column(JSON, default=list)
    driver_requirements: Mapped[str | None] = mapped_column(Text)
    installation_doc: Mapped[str | None] = mapped_column(String(400))
    location: Mapped[str | None] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(16), default="available")
    notes: Mapped[str | None] = mapped_column(Text)
    data_source: Mapped[str] = mapped_column(String(24), default="manual")  # manual | demo_seed | imported | detected
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    config_records: Mapped[list["HardwareConfigRecord"]] = relationship(cascade="all, delete-orphan")


class HardwareConfigRecord(Base):
    __tablename__ = "hardware_config_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    hardware_id: Mapped[int] = mapped_column(ForeignKey("hardware_items.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    parameters: Mapped[dict] = mapped_column(JSON, default=dict)
    notes: Mapped[str | None] = mapped_column(Text)
    recorded_by: Mapped[str] = mapped_column(String(64))
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- software inventory
class SoftwareItem(Base):
    __tablename__ = "software_items"
    __table_args__ = (UniqueConstraint("name", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    kind: Mapped[str] = mapped_column(String(32))
    language: Mapped[str] = mapped_column(String(16))
    version: Mapped[str] = mapped_column(String(60))
    repository_url: Mapped[str | None] = mapped_column(String(400))
    commit_ref: Mapped[str | None] = mapped_column(String(80))
    build_system: Mapped[str | None] = mapped_column(String(60))  # CMake, colcon, pip, make, ...
    target_platform: Mapped[str | None] = mapped_column(String(120))  # e.g. "aarch64 Ubuntu 22.04 / ROS 2 Humble"
    license: Mapped[str | None] = mapped_column(String(60))
    maintainer_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    status: Mapped[str] = mapped_column(String(16), default="planned")
    description: Mapped[str | None] = mapped_column(Text)
    config_files: Mapped[list] = mapped_column(JSON, default=list)
    data_source: Mapped[str] = mapped_column(String(24), default="manual")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)

    dependencies: Mapped[list["SoftwareDependency"]] = relationship(
        cascade="all, delete-orphan", foreign_keys="SoftwareDependency.software_id")
    compatibility: Mapped[list["HardwareCompatibility"]] = relationship(cascade="all, delete-orphan")


class SoftwareDependency(Base):
    __tablename__ = "software_dependencies"
    id: Mapped[int] = mapped_column(primary_key=True)
    software_id: Mapped[int] = mapped_column(ForeignKey("software_items.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    version_constraint: Mapped[str | None] = mapped_column(String(60))
    kind: Mapped[str] = mapped_column(String(8), default="runtime")
    depends_on_id: Mapped[int | None] = mapped_column(ForeignKey("software_items.id", ondelete="SET NULL"))


class HardwareCompatibility(Base):
    __tablename__ = "hardware_compatibility"
    __table_args__ = (UniqueConstraint("software_id", "hardware_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    software_id: Mapped[int] = mapped_column(ForeignKey("software_items.id", ondelete="CASCADE"), index=True)
    hardware_id: Mapped[int] = mapped_column(ForeignKey("hardware_items.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(16), default="untested")
    notes: Mapped[str | None] = mapped_column(Text)
    recorded_by: Mapped[str] = mapped_column(String(64))
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    hardware: Mapped[HardwareItem] = relationship()


# ---------------------------------------------------------------- reports
class ReportLog(Base):
    """Every generated report gets a document revision number per (project, report type)."""
    __tablename__ = "report_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(Integer, index=True)
    report_type: Mapped[str] = mapped_column(String(48))
    revision: Mapped[int] = mapped_column(Integer)
    fmt: Mapped[str] = mapped_column(String(8))
    generated_by: Mapped[str] = mapped_column(String(64))
    generated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    sha256: Mapped[str] = mapped_column(String(64))


class SchemaVersion(Base):
    __tablename__ = "schema_version"
    id: Mapped[int] = mapped_column(primary_key=True)
    version: Mapped[int] = mapped_column(Integer)
    applied_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- Phase 2: system architecture
ARCH_LAYERS = ["hardware", "software"]
ARCH_HW_KINDS = ["main_computer", "embedded_computer", "microcontroller", "ecu", "sensor", "camera", "lidar", "radar",
                 "gnss", "imu", "can_interface", "ethernet_switch", "media_converter", "power_management",
                 "power_supply", "actuator", "electronic_module", "pcb_assembly", "communication_gateway",
                 "test_instrument", "other_hardware"]
ARCH_SW_KINDS = ["operating_system", "middleware", "device_driver", "embedded_application", "api",
                 "communication_service", "sensor_processing", "data_acquisition", "control_application",
                 "monitoring_service", "logging", "diagnostic", "other_software"]
LOGICAL_INTERFACES = ["ROS 2 topic", "IPC", "Network API", "Function call"]
CONN_KINDS = ["data", "power", "control", "time_sync"]
CONN_STATUS = ["planned", "configured", "verified", "failed"]


class ArchModel(Base):
    """One architecture per scope (e.g. 'Vehicle system', 'Lab bench') within a project."""
    __tablename__ = "arch_models"
    __table_args__ = (UniqueConstraint("project_id", "name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    description: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class ArchComponent(Base):
    __tablename__ = "arch_components"
    __table_args__ = (UniqueConstraint("model_id", "key"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    model_id: Mapped[int] = mapped_column(ForeignKey("arch_models.id", ondelete="CASCADE"), index=True)
    key: Mapped[str] = mapped_column(String(48))  # stable identifier used for revision comparison
    name: Mapped[str] = mapped_column(String(160))
    layer: Mapped[str] = mapped_column(String(16))
    kind: Mapped[str] = mapped_column(String(32))
    hardware_id: Mapped[int | None] = mapped_column(ForeignKey("hardware_items.id", ondelete="SET NULL"))
    software_id: Mapped[int | None] = mapped_column(ForeignKey("software_items.id", ondelete="SET NULL"))
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("arch_components.id", ondelete="SET NULL"))  # hosted on
    properties: Mapped[dict] = mapped_column(JSON, default=dict)  # declared interfaces, rates, voltages, ...
    description: Mapped[str | None] = mapped_column(Text)
    x: Mapped[float] = mapped_column(Float, default=0)
    y: Mapped[float] = mapped_column(Float, default=0)


class ArchConnection(Base):
    __tablename__ = "arch_connections"
    __table_args__ = (UniqueConstraint("model_id", "key"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    model_id: Mapped[int] = mapped_column(ForeignKey("arch_models.id", ondelete="CASCADE"), index=True)
    key: Mapped[str] = mapped_column(String(48))
    source_id: Mapped[int] = mapped_column(ForeignKey("arch_components.id", ondelete="CASCADE"), index=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("arch_components.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(16), default="data")
    interface_type: Mapped[str] = mapped_column(String(32))
    protocol: Mapped[str | None] = mapped_column(String(60))
    data_type: Mapped[str | None] = mapped_column(String(160))
    rate_hz: Mapped[float | None] = mapped_column(Float)
    bandwidth_mbps: Mapped[float | None] = mapped_column(Float)
    latency_budget_ms: Mapped[float | None] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(16), default="planned")
    config_requirements: Mapped[str | None] = mapped_column(Text)
    error_conditions: Mapped[str | None] = mapped_column(Text)
    notes: Mapped[str | None] = mapped_column(Text)
    verification_ref: Mapped[str | None] = mapped_column(String(300))
    verified_by: Mapped[str | None] = mapped_column(String(64))
    verified_at: Mapped[datetime | None] = mapped_column(DateTime)


class ArchBaseline(Base):
    """Frozen architecture revision (snapshot of components and connections) for history and comparison."""
    __tablename__ = "arch_baselines"
    __table_args__ = (UniqueConstraint("model_id", "revision"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    model_id: Mapped[int] = mapped_column(ForeignKey("arch_models.id", ondelete="CASCADE"), index=True)
    revision: Mapped[int] = mapped_column(Integer)
    label: Mapped[str] = mapped_column(String(120))
    comment: Mapped[str | None] = mapped_column(Text)
    snapshot: Mapped[dict] = mapped_column(JSON)
    validation_summary: Mapped[dict] = mapped_column(JSON, default=dict)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- Phase 3: hardware & software integration
AUTH_ACTIONS = ["transmit", "replay", "generate", "power_control", "hil_execution"]
AUTH_STATUS = ["requested", "approved", "rejected", "revoked"]
CAPTURE_KINDS = ["can", "serial", "udp"]
SCRIPT_LANGS = ["bash", "python", "powershell"]
PROBE_KINDS = ["device_present", "can_traffic", "serial_traffic", "tcp_reachable", "ros2_topic"]


class DetectedDevice(Base):
    """Result of device discovery on the host running the backend (USB/PnP, serial, CAN, network)."""
    __tablename__ = "detected_devices"
    __table_args__ = (UniqueConstraint("bus", "identifier"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    bus: Mapped[str] = mapped_column(String(16))  # usb | serial | can | network
    identifier: Mapped[str] = mapped_column(String(300))  # port / instance id / interface name
    description: Mapped[str | None] = mapped_column(String(300))
    manufacturer: Mapped[str | None] = mapped_column(String(160))
    serial_number: Mapped[str | None] = mapped_column(String(160))
    vid_pid: Mapped[str | None] = mapped_column(String(16))
    driver: Mapped[str | None] = mapped_column(String(160))
    driver_status: Mapped[str | None] = mapped_column(String(40))
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    hardware_id: Mapped[int | None] = mapped_column(ForeignKey("hardware_items.id", ondelete="SET NULL"))
    match_rule: Mapped[str | None] = mapped_column(String(120))
    present: Mapped[bool] = mapped_column(Boolean, default=True)
    first_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class DeviceAuthorization(Base):
    """Explicit, time-limited authorisation for a potentially disruptive operation on a physical interface."""
    __tablename__ = "device_authorizations"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"))
    interface: Mapped[str] = mapped_column(String(32))  # python-can interface name / 'serial'
    channel: Mapped[str] = mapped_column(String(120))
    actions: Mapped[list] = mapped_column(JSON, default=list)
    purpose: Mapped[str] = mapped_column(Text)
    isolation: Mapped[str] = mapped_column(Text)  # how the network is isolated from the vehicle
    isolation_confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    requested_by: Mapped[str] = mapped_column(String(64))
    requested_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    status: Mapped[str] = mapped_column(String(16), default="requested")
    decided_by: Mapped[str | None] = mapped_column(String(64))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime)
    decision_note: Mapped[str | None] = mapped_column(Text)
    valid_until: Mapped[datetime | None] = mapped_column(DateTime)


class DbcFile(Base):
    __tablename__ = "dbc_files"
    __table_args__ = (UniqueConstraint("name", "sha256"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"))
    name: Mapped[str] = mapped_column(String(200))
    content: Mapped[str] = mapped_column(Text)
    sha256: Mapped[str] = mapped_column(String(64))
    messages: Mapped[int] = mapped_column(Integer, default=0)
    signals: Mapped[int] = mapped_column(Integer, default=0)
    uploaded_by: Mapped[str] = mapped_column(String(64))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Capture(Base):
    """A recorded communication session (CAN / serial / UDP). Records live in data/captures/<id>.jsonl."""
    __tablename__ = "captures"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"))
    kind: Mapped[str] = mapped_column(String(8))
    name: Mapped[str] = mapped_column(String(200))
    config: Mapped[dict] = mapped_column(JSON, default=dict)
    environment: Mapped[str] = mapped_column(String(10))  # virtual | physical
    dbc_id: Mapped[int | None] = mapped_column(ForeignKey("dbc_files.id", ondelete="SET NULL"))
    status: Mapped[str] = mapped_column(String(12), default="running")  # running | stopped | error
    error: Mapped[str | None] = mapped_column(Text)
    records: Mapped[int] = mapped_column(Integer, default=0)
    stats: Mapped[dict] = mapped_column(JSON, default=dict)
    started_by: Mapped[str] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    stopped_at: Mapped[datetime | None] = mapped_column(DateTime)


class Repository(Base):
    __tablename__ = "repositories"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"))
    name: Mapped[str] = mapped_column(String(160), unique=True)
    path: Mapped[str | None] = mapped_column(String(500))  # local working copy (read-only access)
    remote_url: Mapped[str | None] = mapped_column(String(500))
    default_branch: Mapped[str | None] = mapped_column(String(120))
    registered_by: Mapped[str] = mapped_column(String(64))
    registered_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class IntegrationConfig(Base):
    """Named hardware + software configuration (which unit, revision, firmware, software version/commit)."""
    __tablename__ = "integration_configs"
    __table_args__ = (UniqueConstraint("project_id", "name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    description: Mapped[str | None] = mapped_column(Text)
    items: Mapped[list] = mapped_column(JSON, default=list)  # [{type, id, label, revision fields...}]
    status: Mapped[str] = mapped_column(String(10), default="draft")  # draft | frozen
    frozen_by: Mapped[str | None] = mapped_column(String(64))
    frozen_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Script(Base):
    """Bash/Python/PowerShell script under review control. Only an approved, unchanged script can run."""
    __tablename__ = "scripts"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"))
    name: Mapped[str] = mapped_column(String(160), unique=True)
    language: Mapped[str] = mapped_column(String(12))
    description: Mapped[str | None] = mapped_column(Text)
    content: Mapped[str] = mapped_column(Text)
    version: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(12), default="draft")  # draft | approved
    author: Mapped[str] = mapped_column(String(64))
    approved_by: Mapped[str | None] = mapped_column(String(64))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime)
    approved_sha256: Mapped[str | None] = mapped_column(String(64))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class ScriptRun(Base):
    __tablename__ = "script_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    script_id: Mapped[int] = mapped_column(ForeignKey("scripts.id", ondelete="CASCADE"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    args: Mapped[list] = mapped_column(JSON, default=list)
    interpreter: Mapped[str] = mapped_column(String(300))
    started_by: Mapped[str] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    duration_s: Mapped[float | None] = mapped_column(Float)
    exit_code: Mapped[int | None] = mapped_column(Integer)
    timed_out: Mapped[bool] = mapped_column(Boolean, default=False)
    stdout: Mapped[str | None] = mapped_column(Text)
    stderr: Mapped[str | None] = mapped_column(Text)


class ConnectionProbe(Base):
    """Runtime measurement on an architecture connection (feeds the runtime checks of interface validation)."""
    __tablename__ = "connection_probes"
    id: Mapped[int] = mapped_column(primary_key=True)
    connection_id: Mapped[int] = mapped_column(ForeignKey("arch_connections.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(20))
    params: Mapped[dict] = mapped_column(JSON, default=dict)
    environment: Mapped[str] = mapped_column(String(10))  # virtual | physical
    result: Mapped[str] = mapped_column(String(8))  # pass | fail
    measured: Mapped[dict] = mapped_column(JSON, default=dict)
    detail: Mapped[str] = mapped_column(Text)
    ran_by: Mapped[str] = mapped_column(String(64))
    ran_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- Phase 4: test rigs & test automation
RIG_KINDS = ["physical", "virtual"]
RIG_STATUS = ["draft", "ready", "in_use", "maintenance"]
RIG_ROLES = ["dut", "computer", "ecu", "power_supply", "programmable_power", "can_interface", "ethernet_interface",
             "sensor_simulator", "camera_input", "lidar_input", "signal_generator", "measurement_instrument",
             "oscilloscope", "logic_analyzer", "usb_device", "serial_device", "network_switch", "other"]
RIG_LINKS = ["power", "communication", "data_in", "data_out", "measurement", "trigger"]
TEST_TYPES = ["unit", "integration", "regression", "system", "performance", "stress", "reliability", "interface",
              "communication", "error_handling"]
TEST_ENVS = ["sil", "virtual_rig", "hil", "manual"]
RESULT_STATUS = ["passed", "failed", "error", "skipped", "blocked"]


class TestRig(Base):
    __tablename__ = "test_rigs"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    description: Mapped[str | None] = mapped_column(Text)
    kind: Mapped[str] = mapped_column(String(10), default="physical")
    status: Mapped[str] = mapped_column(String(12), default="draft")
    is_template: Mapped[bool] = mapped_column(Boolean, default=False)
    template_id: Mapped[int | None] = mapped_column(ForeignKey("test_rigs.id", ondelete="SET NULL"))
    location: Mapped[str | None] = mapped_column(String(120))
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class RigComponent(Base):
    __tablename__ = "rig_components"
    __table_args__ = (UniqueConstraint("rig_id", "key"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    rig_id: Mapped[int] = mapped_column(ForeignKey("test_rigs.id", ondelete="CASCADE"), index=True)
    key: Mapped[str] = mapped_column(String(48))
    name: Mapped[str] = mapped_column(String(160))
    role: Mapped[str] = mapped_column(String(32))
    hardware_id: Mapped[int | None] = mapped_column(ForeignKey("hardware_items.id", ondelete="SET NULL"))
    properties: Mapped[dict] = mapped_column(JSON, default=dict)  # scpi {host,port,virtual}, can {interface,channel}, calibration_due, ...
    x: Mapped[float] = mapped_column(Float, default=0)
    y: Mapped[float] = mapped_column(Float, default=0)


class RigConnection(Base):
    __tablename__ = "rig_connections"
    id: Mapped[int] = mapped_column(primary_key=True)
    rig_id: Mapped[int] = mapped_column(ForeignKey("test_rigs.id", ondelete="CASCADE"), index=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("rig_components.id", ondelete="CASCADE"))
    target_id: Mapped[int] = mapped_column(ForeignKey("rig_components.id", ondelete="CASCADE"))
    kind: Mapped[str] = mapped_column(String(16))
    interface: Mapped[str | None] = mapped_column(String(40))
    label: Mapped[str | None] = mapped_column(String(160))
    notes: Mapped[str | None] = mapped_column(Text)


class RigChecklist(Base):
    __tablename__ = "rig_checklists"
    id: Mapped[int] = mapped_column(primary_key=True)
    rig_id: Mapped[int] = mapped_column(ForeignKey("test_rigs.id", ondelete="CASCADE"), index=True)
    items: Mapped[list] = mapped_column(JSON, default=list)  # [{key, text, auto, status, detail, by}]
    status: Mapped[str] = mapped_column(String(10), default="open")  # open | complete | failed
    started_by: Mapped[str] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    completed_by: Mapped[str | None] = mapped_column(String(64))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime)


class TestCase(Base):
    __tablename__ = "test_cases"
    __table_args__ = (UniqueConstraint("project_id", "ref"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    ref: Mapped[str] = mapped_column(String(32))
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text)
    objective: Mapped[str | None] = mapped_column(Text)
    test_type: Mapped[str] = mapped_column(String(20), default="integration")
    environments: Mapped[list] = mapped_column(JSON, default=list)  # allowed: sil / virtual_rig / hil / manual
    preconditions: Mapped[str | None] = mapped_column(Text)
    hardware_configuration: Mapped[str | None] = mapped_column(Text)
    software_configuration: Mapped[str | None] = mapped_column(Text)
    input_data: Mapped[str | None] = mapped_column(Text)
    procedure: Mapped[str | None] = mapped_column(Text)
    expected_output: Mapped[str | None] = mapped_column(Text)
    acceptance_criteria: Mapped[str | None] = mapped_column(Text)
    expected_measurements: Mapped[dict] = mapped_column(JSON, default=dict)  # name -> {min,max,unit}
    automation: Mapped[str] = mapped_column(String(10), default="manual")  # manual | pytest
    code: Mapped[str | None] = mapped_column(Text)
    code_version: Mapped[int] = mapped_column(Integer, default=0)
    code_status: Mapped[str] = mapped_column(String(10), default="draft")
    code_approved_by: Mapped[str | None] = mapped_column(String(64))
    code_sha256: Mapped[str | None] = mapped_column(String(64))
    dbc_id: Mapped[int | None] = mapped_column(ForeignKey("dbc_files.id", ondelete="SET NULL"))
    scenario_id: Mapped[int | None] = mapped_column(ForeignKey("scenarios.id", ondelete="SET NULL"))
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class TestSuite(Base):
    __tablename__ = "test_suites"
    __table_args__ = (UniqueConstraint("project_id", "name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    description: Mapped[str | None] = mapped_column(Text)
    test_case_ids: Mapped[list] = mapped_column(JSON, default=list)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class TestRun(Base):
    __tablename__ = "test_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    suite_id: Mapped[int | None] = mapped_column(ForeignKey("test_suites.id", ondelete="SET NULL"))
    name: Mapped[str] = mapped_column(String(200))
    environment: Mapped[str] = mapped_column(String(12))
    rig_id: Mapped[int | None] = mapped_column(ForeignKey("test_rigs.id", ondelete="SET NULL"))
    checklist_id: Mapped[int | None] = mapped_column(ForeignKey("rig_checklists.id", ondelete="SET NULL"))
    authorization_id: Mapped[int | None] = mapped_column(ForeignKey("device_authorizations.id", ondelete="SET NULL"))
    integration_config_id: Mapped[int | None] = mapped_column(ForeignKey("integration_configs.id", ondelete="SET NULL"))
    status: Mapped[str] = mapped_column(String(10), default="queued")  # queued | running | passed | failed | error | open
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    started_by: Mapped[str] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime)
    approved_by: Mapped[str | None] = mapped_column(String(64))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime)
    approval_note: Mapped[str | None] = mapped_column(Text)


class TestResult(Base):
    __tablename__ = "test_results"
    __table_args__ = (UniqueConstraint("run_id", "test_case_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("test_runs.id", ondelete="CASCADE"), index=True)
    test_case_id: Mapped[int] = mapped_column(ForeignKey("test_cases.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(10), default="blocked")
    code_sha256: Mapped[str | None] = mapped_column(String(64))
    actual_output: Mapped[str | None] = mapped_column(Text)
    measurements: Mapped[list] = mapped_column(JSON, default=list)  # [{name, value, unit, expected, ok}]
    checks: Mapped[list] = mapped_column(JSON, default=list)  # pytest node results
    log: Mapped[str | None] = mapped_column(Text)
    duration_s: Mapped[float | None] = mapped_column(Float)
    executed_by: Mapped[str | None] = mapped_column(String(64))
    executed_at: Mapped[datetime | None] = mapped_column(DateTime)
    evidence_ref: Mapped[str | None] = mapped_column(String(300))


# ---------------------------------------------------------------- Phase 5: debugging & root cause analysis
LOG_KINDS = ["application", "system", "hardware", "communication", "driver", "sensor", "api", "build", "test", "resource",
             "analysis"]
LOG_FORMATS = ["auto", "jsonl", "syslog", "journald_json", "ros2", "python_logging", "tegrastats", "text"]
LEVELS = ["debug", "info", "warning", "error", "critical"]
EVENT_CATEGORIES = ["application", "system", "hardware", "communication", "driver", "sensor", "api", "build", "test",
                    "timing", "resource", "crash"]
ISSUE_STATUS = ["open", "investigating", "root_cause_identified", "corrective_action", "retest", "closed", "rejected"]
ISSUE_SEVERITY = ["critical", "major", "minor"]


class LogSource(Base):
    __tablename__ = "log_sources"
    __table_args__ = (UniqueConstraint("project_id", "name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    component: Mapped[str | None] = mapped_column(String(160))  # e.g. "Autonomy compute unit / sensor_fusion_node"
    kind: Mapped[str] = mapped_column(String(16), default="application")
    format: Mapped[str] = mapped_column(String(16), default="auto")
    clock_offset_ms: Mapped[float] = mapped_column(Float, default=0.0)  # added to raw timestamps (synchronisation)
    timezone_offset_min: Mapped[int] = mapped_column(Integer, default=0)  # for naive local timestamps
    internal: Mapped[bool] = mapped_column(Boolean, default=False)  # events synthesised from INTEGRA records
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class LogImport(Base):
    __tablename__ = "log_imports"
    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("log_sources.id", ondelete="CASCADE"), index=True)
    filename: Mapped[str] = mapped_column(String(260))
    sha256: Mapped[str] = mapped_column(String(64))
    detected_format: Mapped[str] = mapped_column(String(16))
    lines: Mapped[int] = mapped_column(Integer, default=0)
    events: Mapped[int] = mapped_column(Integer, default=0)
    unparsed: Mapped[int] = mapped_column(Integer, default=0)
    first_ts: Mapped[datetime | None] = mapped_column(DateTime)
    last_ts: Mapped[datetime | None] = mapped_column(DateTime)
    imported_by: Mapped[str] = mapped_column(String(64))
    imported_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class LogEvent(Base):
    __tablename__ = "log_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("log_sources.id", ondelete="CASCADE"), index=True)
    import_id: Mapped[int | None] = mapped_column(ForeignKey("log_imports.id", ondelete="CASCADE"), index=True)
    ts_raw: Mapped[datetime] = mapped_column(DateTime)  # as found in the log (UTC after timezone conversion)
    ts: Mapped[datetime] = mapped_column(DateTime, index=True)  # synchronised: ts_raw + source clock offset
    level: Mapped[str] = mapped_column(String(10), index=True)
    category: Mapped[str] = mapped_column(String(16), index=True)
    component: Mapped[str | None] = mapped_column(String(160))
    message: Mapped[str] = mapped_column(Text)
    fields: Mapped[dict] = mapped_column(JSON, default=dict)
    fingerprint: Mapped[str] = mapped_column(String(16), index=True)  # normalised message template hash
    template: Mapped[str] = mapped_column(String(300))
    ref: Mapped[str | None] = mapped_column(String(120), index=True)  # internal origin, e.g. "test_result:12"


class Issue(Base):
    __tablename__ = "issues"
    __table_args__ = (UniqueConstraint("project_id", "ref"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    ref: Mapped[str] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(240))
    severity: Mapped[str] = mapped_column(String(10), default="major")
    status: Mapped[str] = mapped_column(String(24), default="open")
    affected_subsystem: Mapped[str | None] = mapped_column(String(160))
    problem_description: Mapped[str | None] = mapped_column(Text)
    reproduction_steps: Mapped[str | None] = mapped_column(Text)
    expected_behaviour: Mapped[str | None] = mapped_column(Text)
    actual_behaviour: Mapped[str | None] = mapped_column(Text)
    hardware_revision: Mapped[str | None] = mapped_column(Text)
    software_revision: Mapped[str | None] = mapped_column(Text)
    integration_config_id: Mapped[int | None] = mapped_column(ForeignKey("integration_configs.id", ondelete="SET NULL"))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id", ondelete="SET NULL"), index=True)
    window_start: Mapped[datetime | None] = mapped_column(DateTime)  # failure window for log correlation
    window_end: Mapped[datetime | None] = mapped_column(DateTime)
    pinned_event_ids: Mapped[list] = mapped_column(JSON, default=list)  # supporting log events
    links: Mapped[list] = mapped_column(JSON, default=list)  # [{type, id, label}] test results, connections, requirements
    confirmed_root_cause: Mapped[str | None] = mapped_column(Text)
    root_cause_confirmed_by: Mapped[str | None] = mapped_column(String(64))
    corrective_action: Mapped[str | None] = mapped_column(Text)
    corrective_owner: Mapped[str | None] = mapped_column(String(64))
    corrective_due: Mapped[date | None] = mapped_column(Date)
    retest_run_id: Mapped[int | None] = mapped_column(ForeignKey("test_runs.id", ondelete="SET NULL"))
    retest_result: Mapped[str | None] = mapped_column(Text)
    owner: Mapped[str | None] = mapped_column(String(64))
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
    closed_by: Mapped[str | None] = mapped_column(String(64))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime)


class IssueHypothesis(Base):
    __tablename__ = "issue_hypotheses"
    id: Mapped[int] = mapped_column(primary_key=True)
    issue_id: Mapped[int] = mapped_column(ForeignKey("issues.id", ondelete="CASCADE"), index=True)
    text: Mapped[str] = mapped_column(Text)
    origin: Mapped[str] = mapped_column(String(16), default="engineer")  # engineer | correlation
    status: Mapped[str] = mapped_column(String(10), default="proposed")  # proposed | confirmed | rejected
    support: Mapped[dict] = mapped_column(JSON, default=dict)  # statistics behind a correlation suggestion
    verification: Mapped[str | None] = mapped_column(Text)  # how the engineer confirmed / rejected it
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    decided_by: Mapped[str | None] = mapped_column(String(64))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime)


class IssueAttachment(Base):
    __tablename__ = "issue_attachments"
    id: Mapped[int] = mapped_column(primary_key=True)
    issue_id: Mapped[int] = mapped_column(ForeignKey("issues.id", ondelete="CASCADE"), index=True)
    filename: Mapped[str] = mapped_column(String(260))
    content_type: Mapped[str | None] = mapped_column(String(120))
    size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    description: Mapped[str | None] = mapped_column(Text)
    uploaded_by: Mapped[str] = mapped_column(String(64))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- Phase 6: autonomous systems & simulation
SCENARIO_CATEGORIES = ["sensor_availability", "missing_data", "timestamp", "comm_interruption", "latency",
                       "invalid_input", "localization", "restart_recovery", "compute_limits", "custom"]


class Scenario(Base):
    """Controlled fault-injection scenario for software validation in an isolated simulation."""
    __tablename__ = "scenarios"
    __table_args__ = (UniqueConstraint("project_id", "ref"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    ref: Mapped[str] = mapped_column(String(32))
    name: Mapped[str] = mapped_column(String(200))
    category: Mapped[str] = mapped_column(String(24), default="custom")
    description: Mapped[str | None] = mapped_column(Text)
    adapter: Mapped[str] = mapped_column(String(48), default="integra_kinematic")
    bag_id: Mapped[int | None] = mapped_column(ForeignKey("bag_files.id", ondelete="SET NULL"))  # rosbag2_replay input
    duration_s: Mapped[float] = mapped_column(Float, default=30.0)
    seed: Mapped[int] = mapped_column(Integer, default=1)
    world: Mapped[dict] = mapped_column(JSON, default=dict)
    sensors: Mapped[dict] = mapped_column(JSON, default=dict)
    faults: Mapped[list] = mapped_column(JSON, default=list)
    expectations: Mapped[list] = mapped_column(JSON, default=list)
    sut: Mapped[str] = mapped_column(String(48), default="reference_supervisor")
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class ScenarioRun(Base):
    __tablename__ = "scenario_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    scenario_id: Mapped[int] = mapped_column(ForeignKey("scenarios.id", ondelete="CASCADE"), index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    adapter: Mapped[str] = mapped_column(String(48))
    sut: Mapped[str] = mapped_column(String(48))
    status: Mapped[str] = mapped_column(String(10))  # passed | failed | error
    scenario_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    expectations: Mapped[list] = mapped_column(JSON, default=list)  # evaluated
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    timeline: Mapped[dict] = mapped_column(JSON, default=dict)  # states, diagnostics, faults (sim time)
    trajectory: Mapped[dict] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text)
    wall_time_s: Mapped[float | None] = mapped_column(Float)
    started_by: Mapped[str] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class BagFile(Base):
    """Recorded ROS 2 bag (rosbag2 sqlite3 / mcap) analysed offline without a ROS installation."""
    __tablename__ = "bag_files"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int | None] = mapped_column(ForeignKey("projects.id", ondelete="SET NULL"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    sha256: Mapped[str] = mapped_column(String(64))
    storage: Mapped[str] = mapped_column(String(10))
    environment: Mapped[str] = mapped_column(String(10), default="unknown")  # physical | simulated | unknown
    start: Mapped[datetime | None] = mapped_column(DateTime)
    end: Mapped[datetime | None] = mapped_column(DateTime)
    duration_s: Mapped[float | None] = mapped_column(Float)
    messages: Mapped[int] = mapped_column(Integer, default=0)
    topics: Mapped[list] = mapped_column(JSON, default=list)
    findings: Mapped[list] = mapped_column(JSON, default=list)
    sync: Mapped[list] = mapped_column(JSON, default=list)
    imported_by: Mapped[str] = mapped_column(String(64))
    imported_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class PluginApproval(Base):
    """Administrator approval of a simulation adapter plugin file (bound to its SHA-256)."""
    __tablename__ = "plugin_approvals"
    id: Mapped[int] = mapped_column(primary_key=True)
    filename: Mapped[str] = mapped_column(String(200), unique=True)
    sha256: Mapped[str] = mapped_column(String(64))
    approved_by: Mapped[str] = mapped_column(String(64))
    approved_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ---------------------------------------------------------------- Phase 7: CI/CD, releases, customer delivery
BUILD_STATUS = ["queued", "running", "success", "failure", "cancelled", "error"]
RELEASE_STATUS = ["draft", "candidate", "approved", "released", "withdrawn"]
DEPLOY_ENVS = ["lab", "virtual", "customer_site"]
DEPLOY_STATUS = ["planned", "performed", "failed", "rolled_back"]
SITE_STATUS = ["planned", "installing", "commissioned", "accepted", "decommissioned"]
INFRA_CATEGORIES = ["network", "power", "mounting", "environment", "vehicle", "it_security", "access", "other"]
ACCEPT_KINDS = ["fat", "sat", "final"]
ACCEPT_STATUS = ["draft", "in_review", "accepted", "rejected"]
ACCEPT_RESULTS = ["pending", "pass", "fail", "waived"]


class CiConnection(Base):
    """Read-only connection to a CI service (GitHub Actions REST API). Secrets are never stored: an optional token is
    read from an environment variable on the backend host whose *name* is recorded here."""
    __tablename__ = "ci_connections"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    repository_id: Mapped[int | None] = mapped_column(ForeignKey("repositories.id", ondelete="SET NULL"))
    provider: Mapped[str] = mapped_column(String(24), default="github_actions")
    owner_repo: Mapped[str] = mapped_column(String(200))
    api_base: Mapped[str] = mapped_column(String(300), default="https://api.github.com")
    workflow: Mapped[str | None] = mapped_column(String(200))
    branch: Mapped[str | None] = mapped_column(String(120))
    token_env: Mapped[str | None] = mapped_column(String(80))
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime)
    last_error: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Build(Base):
    __tablename__ = "builds"
    __table_args__ = (UniqueConstraint("project_id", "source", "external_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    repository_id: Mapped[int | None] = mapped_column(ForeignKey("repositories.id", ondelete="SET NULL"))
    ci_connection_id: Mapped[int | None] = mapped_column(ForeignKey("ci_connections.id", ondelete="SET NULL"))
    source: Mapped[str] = mapped_column(String(20))  # local_script | github_actions
    external_id: Mapped[str | None] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(200))
    branch: Mapped[str | None] = mapped_column(String(160))
    commit_sha: Mapped[str | None] = mapped_column(String(64))
    dirty: Mapped[bool | None] = mapped_column(Boolean)
    status: Mapped[str] = mapped_column(String(12), default="queued")
    script_id: Mapped[int | None] = mapped_column(ForeignKey("scripts.id", ondelete="SET NULL"))
    script_sha256: Mapped[str | None] = mapped_column(String(64))
    config: Mapped[dict] = mapped_column(JSON, default=dict)
    log: Mapped[str | None] = mapped_column(Text)
    artifacts: Mapped[list] = mapped_column(JSON, default=list)
    url: Mapped[str | None] = mapped_column(String(500))
    started_by: Mapped[str] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime)
    duration_s: Mapped[float | None] = mapped_column(Float)


class Release(Base):
    __tablename__ = "releases"
    __table_args__ = (UniqueConstraint("project_id", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    version: Mapped[str] = mapped_column(String(64))
    name: Mapped[str | None] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(12), default="draft")
    repository_id: Mapped[int | None] = mapped_column(ForeignKey("repositories.id", ondelete="SET NULL"))
    commit_sha: Mapped[str | None] = mapped_column(String(64))
    tag: Mapped[str | None] = mapped_column(String(120))
    build_id: Mapped[int | None] = mapped_column(ForeignKey("builds.id", ondelete="SET NULL"))
    integration_config_id: Mapped[int | None] = mapped_column(ForeignKey("integration_configs.id", ondelete="SET NULL"))
    required_suite_ids: Mapped[list] = mapped_column(JSON, default=list)
    test_run_ids: Mapped[list] = mapped_column(JSON, default=list)
    known_limitations: Mapped[list] = mapped_column(JSON, default=list)
    release_notes: Mapped[str | None] = mapped_column(Text)
    rollback_plan: Mapped[str | None] = mapped_column(Text)
    manifest: Mapped[dict] = mapped_column(JSON, default=dict)  # frozen at candidate: software, hardware, compatibility
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
    candidate_at: Mapped[datetime | None] = mapped_column(DateTime)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime)
    released_at: Mapped[datetime | None] = mapped_column(DateTime)
    withdrawn_reason: Mapped[str | None] = mapped_column(Text)


class ReleaseApproval(Base):
    __tablename__ = "release_approvals"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(12))  # engineering | project
    decision: Mapped[str] = mapped_column(String(8))  # approve | reject
    username: Mapped[str] = mapped_column(String(64))
    role: Mapped[str] = mapped_column(String(40))
    comment: Mapped[str | None] = mapped_column(Text)
    gate_summary: Mapped[dict] = mapped_column(JSON, default=dict)
    superseded: Mapped[bool] = mapped_column(Boolean, default=False)
    at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class Site(Base):
    __tablename__ = "sites"
    __table_args__ = (UniqueConstraint("project_id", "name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(160))
    location: Mapped[str | None] = mapped_column(String(200))
    address: Mapped[str | None] = mapped_column(Text)
    contact_name: Mapped[str | None] = mapped_column(String(120))
    contact_phone: Mapped[str | None] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(16), default="planned")
    infrastructure: Mapped[list] = mapped_column(JSON, default=list)  # [{category, item, detail}]
    access_notes: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class Deployment(Base):
    """Record of an installation performed by an engineer. INTEGRA never deploys software itself."""
    __tablename__ = "deployments"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id", ondelete="CASCADE"), index=True)
    environment: Mapped[str] = mapped_column(String(16))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id", ondelete="SET NULL"))
    target: Mapped[str] = mapped_column(String(240))
    status: Mapped[str] = mapped_column(String(12), default="planned")
    rollback_of_id: Mapped[int | None] = mapped_column(ForeignKey("deployments.id", ondelete="SET NULL"))
    procedure_ref: Mapped[str | None] = mapped_column(String(300))
    notes: Mapped[str | None] = mapped_column(Text)
    recorded_by: Mapped[str] = mapped_column(String(64))
    performed_by: Mapped[str | None] = mapped_column(String(120))
    performed_at: Mapped[datetime | None] = mapped_column(DateTime)
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class SiteInstallation(Base):
    __tablename__ = "site_installations"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id", ondelete="CASCADE"), index=True)
    hardware_id: Mapped[int] = mapped_column(ForeignKey("hardware_items.id", ondelete="CASCADE"))
    position: Mapped[str] = mapped_column(String(200))
    serial_number: Mapped[str] = mapped_column(String(120))
    hardware_revision: Mapped[str | None] = mapped_column(String(40))
    firmware_version: Mapped[str | None] = mapped_column(String(60))
    configuration: Mapped[dict] = mapped_column(JSON, default=dict)
    notes: Mapped[str | None] = mapped_column(Text)
    installed_by: Mapped[str] = mapped_column(String(64))
    installed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    removed_by: Mapped[str | None] = mapped_column(String(64))
    removed_at: Mapped[datetime | None] = mapped_column(DateTime)


class SiteCheck(Base):
    __tablename__ = "site_checks"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id", ondelete="CASCADE"), index=True)
    release_id: Mapped[int | None] = mapped_column(ForeignKey("releases.id", ondelete="SET NULL"))
    items: Mapped[list] = mapped_column(JSON, default=list)  # [{key, text, auto, status, detail, by, at}]
    status: Mapped[str] = mapped_column(String(10), default="open")  # open | complete | failed
    started_by: Mapped[str] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    completed_by: Mapped[str | None] = mapped_column(String(64))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime)


class SiteDiagnostic(Base):
    __tablename__ = "site_diagnostics"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id", ondelete="CASCADE"), index=True)
    filename: Mapped[str] = mapped_column(String(260))
    kind: Mapped[str] = mapped_column(String(16), default="log")  # log | config | measurement | other
    description: Mapped[str | None] = mapped_column(Text)
    size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    log_import_id: Mapped[int | None] = mapped_column(ForeignKey("log_imports.id", ondelete="SET NULL"))
    uploaded_by: Mapped[str] = mapped_column(String(64))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AcceptanceRecord(Base):
    """Factory / site / final acceptance with per-requirement results and a customer signature."""
    __tablename__ = "acceptance_records"
    __table_args__ = (UniqueConstraint("project_id", "ref"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    ref: Mapped[str] = mapped_column(String(32))
    kind: Mapped[str] = mapped_column(String(8))
    title: Mapped[str] = mapped_column(String(240))
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id", ondelete="SET NULL"))
    release_id: Mapped[int | None] = mapped_column(ForeignKey("releases.id", ondelete="SET NULL"))
    status: Mapped[str] = mapped_column(String(10), default="draft")
    items: Mapped[list] = mapped_column(JSON, default=list)
    customer_representative: Mapped[str | None] = mapped_column(String(160))
    conditions: Mapped[str | None] = mapped_column(Text)
    signed_by: Mapped[str | None] = mapped_column(String(64))
    signature_role: Mapped[str | None] = mapped_column(String(12))  # customer | on_behalf
    signed_at: Mapped[datetime | None] = mapped_column(DateTime)
    sha256: Mapped[str | None] = mapped_column(String(64))
    created_by: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


# ---------------------------------------------------------------- Phase 8: AI engineering assistant
class AppSetting(Base):
    """Administrator-controlled settings (key -> JSON value)."""
    __tablename__ = "app_settings"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_by: Mapped[str] = mapped_column(String(64))
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AssistantConversation(Base):
    __tablename__ = "assistant_conversations"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    username: Mapped[str] = mapped_column(String(64), index=True)
    title: Mapped[str] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AssistantMessage(Base):
    """A question or an answer. Answers keep the structured findings, the record tools called and the token usage."""
    __tablename__ = "assistant_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    conversation_id: Mapped[int] = mapped_column(ForeignKey("assistant_conversations.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(10))  # user | assistant
    mode: Mapped[str] = mapped_column(String(10), default="ai")  # ai | analysis
    content: Mapped[str] = mapped_column(Text)
    answer: Mapped[dict] = mapped_column(JSON, default=dict)  # {summary, findings[{statement, basis, refs, note}], next_steps}
    tool_calls: Mapped[list] = mapped_column(JSON, default=list)  # [{name, input, refs, error, ms}]
    model: Mapped[str | None] = mapped_column(String(64))
    usage: Mapped[dict] = mapped_column(JSON, default=dict)
    stop_reason: Mapped[str | None] = mapped_column(String(24))
    error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class AssistantProposal(Base):
    """Something the assistant drafted (test case with code, test rig). Nothing is created until an engineer accepts;
    created records start as drafts that still need the normal review / four-eyes approval."""
    __tablename__ = "assistant_proposals"
    id: Mapped[int] = mapped_column(primary_key=True)
    conversation_id: Mapped[int] = mapped_column(ForeignKey("assistant_conversations.id", ondelete="CASCADE"), index=True)
    message_id: Mapped[int | None] = mapped_column(ForeignKey("assistant_messages.id", ondelete="SET NULL"))
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(16))  # test_case | test_rig
    title: Mapped[str] = mapped_column(String(240))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(10), default="proposed")  # proposed | created | dismissed
    record_ref: Mapped[str | None] = mapped_column(String(64))
    decided_by: Mapped[str | None] = mapped_column(String(64))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
