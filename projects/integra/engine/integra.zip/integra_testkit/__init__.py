"""integra_testkit — helpers for INTEGRA automated tests (pytest).

INTEGRA runs each automated test case in its own working directory with these environment variables:

  INTEGRA_ENVIRONMENT   sil | virtual_rig | hil
  INTEGRA_RESULTS_DIR   where record() writes measurements
  INTEGRA_RUN_ID / INTEGRA_TEST_REF
  INTEGRA_DBC_PATH      DBC file attached to the test case (optional)
  INTEGRA_RIG_JSON      rig description: components with roles, SCPI endpoints, CAN interfaces (virtual_rig / hil)
  INTEGRA_HIL_AUTHORIZED  "1" only when the backend verified an approved HIL authorisation for this run

Typical SIL test::

    from integra_testkit import record, sil

    def test_gateway_rate():
        db = sil.dbc()
        with sil.can_bus() as bus, sil.Generator(db, bus.channel_info):
            rates = sil.measure_rates(bus, seconds=1.0)
        record("vehicle_state_rate_hz", rates.get(0x100, 0), unit="Hz", expected=">= 45")
        assert rates.get(0x100, 0) >= 45
"""
from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path

ENVIRONMENT = os.environ.get("INTEGRA_ENVIRONMENT", "sil")


def _results_dir() -> Path:
    d = Path(os.environ.get("INTEGRA_RESULTS_DIR", "."))
    d.mkdir(parents=True, exist_ok=True)
    return d


def _current_test() -> str:
    cur = os.environ.get("PYTEST_CURRENT_TEST", "")
    return cur.rsplit(" ", 1)[0] if cur else ""


def record(name: str, value, unit: str | None = None, expected: str | None = None) -> None:
    """Record a measurement; INTEGRA shows it next to the expected value and compares SIL vs HIL results."""
    rec = {"name": name, "value": value, "unit": unit, "expected": expected, "test": _current_test(), "t": time.time()}
    with open(_results_dir() / "measurements.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


def rig() -> dict:
    raw = os.environ.get("INTEGRA_RIG_JSON")
    return json.loads(raw) if raw else {}


def component(role: str | None = None, key: str | None = None) -> dict:
    for c in rig().get("components", []):
        if (key and c["key"] == key) or (role and c["role"] == role):
            return c
    raise LookupError(f"rig has no component with role={role} key={key}")


class _Scpi:
    """Minimal SCPI-over-TCP client (same protocol as integra.hal.scpi)."""

    def __init__(self, host: str, port: int, timeout: float = 2.0):
        self.host, self.port, self.timeout = host, port, timeout

    def _io(self, cmd: str):
        import socket
        with socket.create_connection((self.host, self.port), timeout=self.timeout) as s:
            f = s.makefile("rwb")
            f.write((cmd + "\n").encode())
            f.flush()
            return f.readline().decode().strip() if cmd.strip().endswith("?") else None

    def query(self, cmd: str) -> str:
        return self._io(cmd)

    def write(self, cmd: str) -> None:
        self._io(cmd)


def instrument(key: str | None = None, role: str = "programmable_power") -> _Scpi:
    c = component(role=None if key else role, key=key)
    sc = c.get("scpi_endpoint")
    if not sc:
        raise LookupError(f"component {c['key']} has no SCPI endpoint")
    if not sc.get("virtual") and os.environ.get("INTEGRA_HIL_AUTHORIZED") != "1":
        raise PermissionError("Physical instrument access requires an authorised HIL run")
    return _Scpi(sc["host"], int(sc["port"]))


class sil:  # noqa: N801  (namespace)
    """Software-in-the-loop helpers: isolated, in-process virtual devices only."""

    @staticmethod
    def channel() -> str:
        return os.environ.get("INTEGRA_SIL_CHANNEL") or f"sil-{os.environ.get('INTEGRA_RUN_ID', 'local')}-{uuid.uuid4().hex[:6]}"

    @staticmethod
    def can_bus(channel: str | None = None, receive_own_messages: bool = False):
        import can
        return can.Bus(interface="virtual", channel=channel or sil.channel(), receive_own_messages=receive_own_messages)

    @staticmethod
    def dbc(path: str | None = None):
        import cantools
        p = path or os.environ.get("INTEGRA_DBC_PATH")
        if not p:
            raise LookupError("No DBC attached to this test case")
        return cantools.database.load_file(p)

    class Generator:
        """Periodic DBC traffic on a virtual channel (cycle times from the DBC). `values` maps signal -> value or
        callable(t) -> value; unspecified signals use the middle of their DBC range."""

        def __init__(self, db, channel, messages=None, values=None, skip=None):
            self.db, self.channel = db, channel
            self.msgs = [m for m in db.messages if not messages or m.name in messages]
            self.values, self.skip = values or {}, set(skip or [])
            self._stop = None
            self._counters: dict = {}

        def _val(self, s, t, frame_id=None):
            if s.name not in self.values and any(k in s.name.lower() for k in ("alive", "counter", "rolling")):
                key = (frame_id, s.name)
                self._counters[key] = (self._counters.get(key, -1) + 1) % (2 ** s.length)
                return self._counters[key]
            v = self.values.get(s.name)
            if callable(v):
                return v(t)
            if v is not None:
                return v
            if s.choices:
                return sorted(int(k) for k in s.choices)[0]
            lo = s.minimum if s.minimum is not None else 0
            hi = s.maximum if s.maximum is not None else lo
            return (lo + hi) / 2

        def __enter__(self):
            import threading

            import can
            ch = self.channel if isinstance(self.channel, str) else getattr(self.channel, "channel_info", self.channel)
            ch = str(ch).replace("Virtual bus channel ", "")
            self._bus = can.Bus(interface="virtual", channel=ch)
            self._stop = threading.Event()
            t0 = time.time()

            def loop():
                nxt = {m.frame_id: time.time() for m in self.msgs}
                while not self._stop.is_set():
                    now = time.time()
                    for m in self.msgs:
                        if m.name in self.skip or now < nxt[m.frame_id]:
                            continue
                        data = m.encode({s.name: self._val(s, now - t0, m.frame_id) for s in m.signals}, strict=False)
                        self._bus.send(can.Message(arbitration_id=m.frame_id, data=data,
                                                   is_extended_id=m.is_extended_frame))
                        nxt[m.frame_id] += (m.cycle_time or 100) / 1000  # fixed schedule, no drift
                    # time.sleep is high-resolution on Windows; Event.wait has ~15 ms granularity there
                    time.sleep(min(0.01, max(0.0002, min(nxt.values()) - time.time())))
            self._thread = threading.Thread(target=loop, daemon=True)
            self._thread.start()
            return self

        def __exit__(self, *exc):
            self._stop.set()
            self._thread.join(2)
            self._bus.shutdown()

    @staticmethod
    def measure_rates(bus, seconds: float = 1.0) -> dict[int, float]:
        counts: dict[int, int] = {}
        end = time.time() + seconds
        while time.time() < end:
            m = bus.recv(0.05)
            if m is not None and not m.is_error_frame:
                counts[m.arbitration_id] = counts.get(m.arbitration_id, 0) + 1
        return {k: v / seconds for k, v in counts.items()}

    class MockHttpServer:
        """Mock REST API: routes = {("GET", "/status"): (200, {"ok": True})}. Use .url inside the with-block."""

        def __init__(self, routes: dict):
            self.routes, self.calls = routes, []

        def __enter__(self):
            import threading
            from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
            outer = self

            class H(BaseHTTPRequestHandler):
                def _do(self):
                    n = int(self.headers.get("Content-Length") or 0)
                    body = self.rfile.read(n) if n else b""
                    outer.calls.append((self.command, self.path, body))
                    code, payload = outer.routes.get((self.command, self.path), (404, {"error": "no route"}))
                    data = json.dumps(payload).encode()
                    self.send_response(code)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                do_GET = do_POST = do_PUT = do_DELETE = _do

                def log_message(self, *a):
                    pass
            self.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
            self.url = f"http://127.0.0.1:{self.srv.server_address[1]}"
            threading.Thread(target=self.srv.serve_forever, daemon=True).start()
            return self

        def __exit__(self, *exc):
            self.srv.shutdown()
            self.srv.server_close()


class hil:  # noqa: N801
    """Hardware-in-the-loop helpers: open rig interfaces only when the backend authorised this run."""

    @staticmethod
    def require_authorized():
        if os.environ.get("INTEGRA_HIL_AUTHORIZED") != "1":
            raise PermissionError("This test needs an authorised HIL run (approved rig authorisation + checklist)")

    @staticmethod
    def can_bus(key: str | None = None):
        import can
        c = component(role=None if key else "can_interface", key=key)
        cfg = c.get("can") or {}
        if cfg.get("interface", "virtual") != "virtual":
            hil.require_authorized()
        kw = {"interface": cfg.get("interface", "virtual"), "channel": cfg.get("channel", "vbus0")}
        if cfg.get("bitrate") and kw["interface"] != "virtual":
            kw["bitrate"] = int(cfg["bitrate"])
        return can.Bus(**kw)
