"""integra_testkit.sim — deterministic fault-injection simulation for autonomous-system software (SIL).

The engine generates timestamped sensor messages from a kinematic vehicle world, applies the scenario's faults
(dropouts, stale or jittered timestamps, communication interruptions, added latency, invalid values, localisation
degradation, process restarts, compute limits), delivers them in receive-time order to a System Under Test (SUT) and
evaluates the SUT's diagnostics and system states against the scenario's expectations.

Everything is synthetic and isolated: no vehicle, no actuation, no network. The physics is deliberately simple
(kinematic point vehicle on a polyline route, linearly moving objects); it exercises timing, availability and
data-validity handling, not perception accuracy.

SUT interface (duck-typed)::

    class MySystem:
        def reset(self, t: float) -> None: ...          # (re)start at sim time t
        def on_message(self, msg: dict) -> None: ...    # msg: topic, sensor, seq, stamp, t_recv, data
        def step(self, t: float) -> list[dict]: ...     # outputs: {"type": "state", "state": ...}
                                                        #          {"type": "diagnostic", "level": "OK|WARN|ERROR", "name": ..., "message": ...}
"""
from __future__ import annotations

import copy
import math
import random
from dataclasses import dataclass, field

STATES = ["INIT", "NOMINAL", "DEGRADED", "MINIMAL_RISK", "OFFLINE"]
LEVEL_RANK = {"OK": 0, "WARN": 1, "ERROR": 2}

DEFAULT_SENSORS: dict[str, dict] = {
    "camera_front": {"type": "camera", "topic": "/camera/front/image_raw", "rate_hz": 30, "latency_ms": 35, "jitter_ms": 3, "critical": True},
    "lidar_roof": {"type": "lidar", "topic": "/lidar/points", "rate_hz": 10, "latency_ms": 20, "jitter_ms": 2, "critical": True},
    "radar_front": {"type": "radar", "topic": "/radar/tracks", "rate_hz": 20, "latency_ms": 15, "jitter_ms": 2, "critical": False},
    "gnss": {"type": "gnss", "topic": "/gnss/fix", "rate_hz": 10, "latency_ms": 40, "jitter_ms": 5, "noise_m": 0.03, "critical": False},
    "imu": {"type": "imu", "topic": "/imu/data", "rate_hz": 100, "latency_ms": 2, "jitter_ms": 0.5, "critical": True},
    "vehicle_state": {"type": "vehicle_state", "topic": "/vehicle/state", "rate_hz": 50, "latency_ms": 8, "jitter_ms": 1, "critical": True},
    "resources": {"type": "resources", "topic": "/system/resources", "rate_hz": 2, "latency_ms": 1, "jitter_ms": 0, "critical": False},
}
DEFAULT_WORLD = {"route": [[0, 0], [250, 0], [400, 60], [400, 300], [100, 330], [0, 150]], "speed_mps": 15.0,
                 "objects": [{"id": 1, "x": 80, "y": 1.5, "vx": 10.0, "vy": 0.0}, {"id": 2, "x": 260, "y": 20, "vx": 0.0, "vy": 2.0}]}
FAULT_TYPES = ["sensor_dropout", "stale_timestamps", "timestamp_jitter", "comm_interruption", "latency_increase",
               "invalid_messages", "localization_degradation", "process_restart", "compute_limit"]
EXPECTATION_TYPES = ["detect", "state", "recover", "no_false_alarm", "never_state"]


# ---------------------------------------------------------------- world
class World:
    def __init__(self, cfg: dict):
        self.route = [tuple(map(float, p)) for p in cfg.get("route", DEFAULT_WORLD["route"])]
        self.speed = float(cfg.get("speed_mps", DEFAULT_WORLD["speed_mps"]))
        self.objects = [dict(o) for o in cfg.get("objects", DEFAULT_WORLD["objects"])]
        self.seg = []
        total = 0.0
        for a, b in zip(self.route, self.route[1:]):
            d = math.dist(a, b)
            self.seg.append((total, d, a, b))
            total += d
        self.length = total

    def pose(self, t: float) -> tuple[float, float, float, float]:
        """(x, y, heading, speed): accelerate at 2 m/s² to cruise speed, then follow the route (looping)."""
        ta = self.speed / 2.0
        s = 0.5 * 2.0 * t * t if t < ta else 0.5 * 2.0 * ta * ta + self.speed * (t - ta)
        v = min(self.speed, 2.0 * t)
        s = s % self.length if self.length else 0
        for start, d, a, b in self.seg:
            if s <= start + d:
                k = (s - start) / d if d else 0
                return a[0] + k * (b[0] - a[0]), a[1] + k * (b[1] - a[1]), math.atan2(b[1] - a[1], b[0] - a[0]), v
        a, b = self.route[-2], self.route[-1]
        return b[0], b[1], math.atan2(b[1] - a[1], b[0] - a[0]), v

    def objects_at(self, t: float) -> list[dict]:
        return [{"id": o["id"], "x": o["x"] + o.get("vx", 0) * t, "y": o["y"] + o.get("vy", 0) * t} for o in self.objects]


# ---------------------------------------------------------------- faults
@dataclass
class Fault:
    type: str
    start_s: float
    end_s: float
    sensor: str | None = None
    sensors: list[str] = field(default_factory=list)
    params: dict = field(default_factory=dict)

    def active(self, t: float) -> bool:
        return self.start_s <= t < self.end_s

    def hits(self, sensor: str) -> bool:
        return sensor == self.sensor or sensor in self.sensors

    @staticmethod
    def from_dict(d: dict) -> "Fault":
        if d.get("type") not in FAULT_TYPES:
            raise ValueError(f"unknown fault type {d.get('type')}")
        p = {k: v for k, v in d.items() if k not in ("type", "start_s", "end_s", "sensor", "sensors")}
        return Fault(d["type"], float(d["start_s"]), float(d["end_s"]), d.get("sensor"), list(d.get("sensors") or []), p)


# ---------------------------------------------------------------- sensor message generation
def _payload(kind: str, cfg: dict, world: World, t: float, rng: random.Random, gnss_factor: float) -> dict:
    x, y, h, v = world.pose(t)
    if kind == "camera":
        return {"width": 2880, "height": 1860, "exposure_ms": 8.0, "frame_id": "camera_front"}
    if kind == "lidar":
        return {"points": 131072 - rng.randint(0, 2000), "frame_id": "lidar_roof", "ego_x": x, "ego_y": y}
    if kind == "radar":
        tracks = []
        for o in world.objects_at(t):
            dx, dy = o["x"] - x, o["y"] - y
            rng_m = math.hypot(dx, dy)
            az = math.atan2(dy, dx) - h
            az = (az + math.pi) % (2 * math.pi) - math.pi
            if rng_m < 150 and abs(az) < math.radians(60):
                tracks.append({"id": o["id"], "range_m": round(rng_m + rng.gauss(0, 0.2), 2), "azimuth_deg": round(math.degrees(az), 2)})
        return {"tracks": tracks}
    if kind == "gnss":
        sigma = float(cfg.get("noise_m", 0.03)) * gnss_factor
        return {"x": round(x + rng.gauss(0, sigma), 3), "y": round(y + rng.gauss(0, sigma), 3), "covariance_m2": round(sigma ** 2, 6),
                "fix": "RTK_FIXED" if gnss_factor <= 1.5 else ("RTK_FLOAT" if gnss_factor <= 10 else "SINGLE")}
    if kind == "imu":
        return {"ax": round(rng.gauss(0, 0.05), 4), "ay": round(rng.gauss(0, 0.05), 4), "az": round(9.81 + rng.gauss(0, 0.05), 4),
                "gz": round(rng.gauss(0, 0.002), 5)}
    if kind == "vehicle_state":
        return {"speed_mps": round(v, 3), "heading_rad": round(h, 4), "gear": "D"}
    if kind == "resources":
        return {"cpu_load_pct": round(45 + rng.gauss(0, 3), 1), "mem_pct": 38.0}
    return {}


def _corrupt(kind: str, data: dict, mode: str) -> dict:
    d = copy.deepcopy(data)
    keys = [k for k, v in d.items() if isinstance(v, (int, float)) and not isinstance(v, bool)]
    if kind == "radar" and d.get("tracks"):
        d["tracks"][0]["range_m"] = float("nan") if mode == "nan" else -50.0
        return d
    if keys:
        d[keys[0]] = float("nan") if mode == "nan" else (-1e6 if mode == "out_of_range" else d[keys[0]])
    return d


def generate_messages(scn: dict, rng: random.Random) -> tuple[list[dict], dict]:
    sensors = {**DEFAULT_SENSORS, **(scn.get("sensors") or {})}
    sensors = {k: v for k, v in sensors.items() if v is not None and v.get("enabled", True)}
    world = World(scn.get("world") or DEFAULT_WORLD)
    faults = [Fault.from_dict(f) for f in scn.get("faults", [])]
    dur = float(scn.get("duration_s", 30))
    msgs: list[dict] = []
    counts = {k: {"generated": 0, "dropped": 0, "corrupted": 0} for k in sensors}
    for name, cfg in sensors.items():
        period = 1.0 / float(cfg["rate_hz"])
        phase = rng.uniform(0, period)
        seq = 0
        t = phase
        while t < dur:
            seq += 1
            capture = t
            active = [f for f in faults if f.active(capture)]
            counts[name]["generated"] += 1
            if any(f.type in ("sensor_dropout", "comm_interruption") and f.hits(name) for f in active):
                counts[name]["dropped"] += 1
                t += period
                continue
            gnss_factor = 1.0
            for f in active:
                if f.type == "localization_degradation" and cfg["type"] == "gnss":
                    gnss_factor = float(f.params.get("noise_factor", 50))
            data = _payload(cfg["type"], cfg, world, capture, rng, gnss_factor)
            stamp = capture
            latency = float(cfg.get("latency_ms", 10)) / 1000 + abs(rng.gauss(0, float(cfg.get("jitter_ms", 1)) / 1000))
            for f in active:
                if not f.hits(name) and f.type not in ("compute_limit",):
                    continue
                if f.type == "stale_timestamps":
                    stamp -= float(f.params.get("delay_ms", 300)) / 1000
                elif f.type == "timestamp_jitter":
                    stamp += rng.gauss(0, float(f.params.get("jitter_ms", 40)) / 1000)
                elif f.type == "latency_increase":
                    latency += float(f.params.get("add_ms", 200)) / 1000
                elif f.type == "invalid_messages" and rng.random() < float(f.params.get("probability", 1.0)):
                    data = _corrupt(cfg["type"], data, f.params.get("mode", "nan"))
                    counts[name]["corrupted"] += 1
                elif f.type == "compute_limit" and cfg["type"] == "resources":
                    data["cpu_load_pct"] = float(f.params.get("cpu_load_pct", 98))
            msgs.append({"topic": cfg["topic"], "sensor": name, "seq": seq, "stamp": round(stamp, 6),
                         "t_recv": round(capture + latency, 6), "data": data})
            t += period
    msgs.sort(key=lambda m: m["t_recv"])
    return msgs, counts


# ---------------------------------------------------------------- reference system under test (demo)
class ReferenceSupervisor:
    """INTEGRA reference supervisor — a DEMO system under test, not production software.

    Checks per sensor: receive timeout (3x nominal period), data age at receipt (> max_age_ms), invalid values (NaN,
    negative ranges, implausible magnitudes); GNSS covariance / fix quality for localisation; CPU load from
    /system/resources. State machine: critical sensor ERROR -> MINIMAL_RISK; other errors or warnings -> DEGRADED;
    1 s without findings -> NOMINAL; after a restart -> INIT for 0.5 s.

    Known limitation (deliberate, to show how failures are reported): it does NOT check timestamp monotonicity, so
    jittered stamps that run backwards are not detected.
    """

    def __init__(self, sensors: dict | None = None, max_age_ms: float = 150.0):
        self.sensors = {k: v for k, v in {**DEFAULT_SENSORS, **(sensors or {})}.items() if v is not None and v.get("enabled", True)}
        self.max_age = max_age_ms / 1000
        self.reset(0.0)

    def reset(self, t: float) -> None:
        self.t0 = t
        self.last_recv: dict[str, float] = {}
        self.findings: dict[str, tuple[str, str, float]] = {}  # key -> (level, message, since)
        self.state = "INIT"
        self.clear_since = t
        self.emitted: dict[str, str] = {}
        self.cpu_high_since: float | None = None
        self.loc_bad_since: float | None = None

    def _set(self, key: str, level: str, msg: str, t: float):
        if level == "OK":
            self.findings.pop(key, None)
        elif key not in self.findings or self.findings[key][0] != level:
            self.findings[key] = (level, msg, t)

    def on_message(self, m: dict) -> None:
        s, t, d = m["sensor"], m["t_recv"], m["data"]
        self.last_recv[s] = t
        age = t - m["stamp"]
        self._set(f"{s}.age", "WARN" if age > self.max_age else "OK", f"{s} stale data (age {age * 1000:.0f} ms)", t)
        bad = any(isinstance(v, float) and (math.isnan(v) or abs(v) > 1e5) for v in d.values()) or \
            any(isinstance(tr.get("range_m"), float) and (math.isnan(tr["range_m"]) or tr["range_m"] < 0) for tr in d.get("tracks", []))
        self._set(f"{s}.invalid", "WARN" if bad else "OK", f"{s} invalid data", t)
        if self.sensors.get(s, {}).get("type") == "gnss":
            poor = d.get("covariance_m2", 0) > 1.0 or d.get("fix") == "SINGLE"
            if poor and self.loc_bad_since is None:
                self.loc_bad_since = t
            if not poor:
                self.loc_bad_since = None
            self._set("localization", "WARN" if poor else "OK", f"localization degraded (cov {d.get('covariance_m2')} m², fix {d.get('fix')})", t)
        if self.sensors.get(s, {}).get("type") == "resources":
            high = d.get("cpu_load_pct", 0) > 90
            self.cpu_high_since = (self.cpu_high_since or t) if high else None
            self._set("compute", "WARN" if high and t - self.cpu_high_since >= 1.0 else "OK", f"compute overload (CPU {d.get('cpu_load_pct')} %)", t)

    def step(self, t: float) -> list[dict]:
        out = []
        for s, cfg in self.sensors.items():
            if t - self.t0 < 0.5:
                break
            last = self.last_recv.get(s, self.t0)
            timeout = 3.0 / float(cfg["rate_hz"]) + 0.05
            self._set(f"{s}.timeout", "ERROR" if t - last > timeout else "OK", f"{s} timeout ({(t - last) * 1000:.0f} ms without data)", t)
        for key, (lvl, msg, _) in list(self.findings.items()):
            if self.emitted.get(key) != lvl:
                out.append({"type": "diagnostic", "level": lvl, "name": key, "message": msg})
                self.emitted[key] = lvl
        for key in [k for k in self.emitted if k not in self.findings]:
            out.append({"type": "diagnostic", "level": "OK", "name": key, "message": f"{key} cleared"})
            del self.emitted[key]
        if t - self.t0 < 0.5:
            new = "INIT"
        else:
            crit = any(lvl == "ERROR" and self.sensors.get(k.split(".")[0], {}).get("critical") for k, (lvl, _, _) in self.findings.items())
            loc_lost = self.loc_bad_since is not None and t - self.loc_bad_since > 5.0
            if crit:
                new = "MINIMAL_RISK"
            elif self.findings or loc_lost:
                new = "DEGRADED"
            else:
                new = "NOMINAL" if (self.state in ("INIT", "NOMINAL") or t - self.clear_since >= 1.0) else self.state
            if self.findings:
                self.clear_since = t
        if new != self.state:
            self.state = new
            out.append({"type": "state", "state": new})
        return out


SUTS = {"reference_supervisor": ReferenceSupervisor}


# ---------------------------------------------------------------- run & evaluate
def run(scenario: dict, sut=None, messages: list[dict] | None = None, step_hz: float = 50.0) -> dict:
    """Execute a scenario. `sut` is an instance or a zero-argument factory; `messages` replaces the generated stream
    (used by the rosbag2 replay adapter). Returns timeline, evaluated expectations and summary."""
    rng = random.Random(int(scenario.get("seed", 1)))
    dur = float(scenario.get("duration_s", 30))
    counts: dict = {}
    if messages is None:
        msgs, counts = generate_messages(scenario, rng)
    else:
        msgs = sorted(messages, key=lambda m: m["t_recv"])
    if sut is None:
        factory = lambda: ReferenceSupervisor(scenario.get("sensors"))  # noqa: E731
    elif isinstance(sut, type) or (callable(sut) and not hasattr(sut, "on_message")):
        factory = sut  # class or factory: a restart creates a fresh instance
    else:
        factory = lambda: sut  # noqa: E731  (instance: a restart calls reset() on the same object)
    inst = factory()
    faults = [Fault.from_dict(f) for f in scenario.get("faults", [])]
    restarts = [f for f in faults if f.type == "process_restart"]
    compute = [f for f in faults if f.type == "compute_limit"]
    inst.reset(0.0)
    states, diags = [(0.0, "INIT")], []
    pending: list[tuple[float, dict]] = []  # outputs delayed by compute limits
    i, t, dt = 0, 0.0, 1.0 / step_hz
    down_until = -1.0
    restarted = set()
    delivered = 0
    while t <= dur + 1e-9:
        for f in restarts:
            if f.start_s <= t and id(f) not in restarted:
                restarted.add(id(f))
                down_until = f.end_s
                states.append((round(t, 3), "OFFLINE"))
                diags.append({"t": round(t, 3), "level": "INFO", "name": "sim.process_restart",
                              "message": f"SUT process stopped by fault injection until {f.end_s} s"})
        while i < len(msgs) and msgs[i]["t_recv"] <= t:
            if t >= down_until:
                inst.on_message(msgs[i])
                delivered += 1
            i += 1
        if t < down_until:
            t = round(t + dt, 9)
            if t >= down_until > 0:
                inst = factory()
                inst.reset(t)
                states.append((round(t, 3), "INIT"))
            continue
        delay = sum(float(f.params.get("output_delay_ms", 150)) / 1000 for f in compute if f.active(t))
        for o in inst.step(t):
            pending.append((t + delay, o))
        due = [p for p in pending if p[0] <= t + 1e-9]
        pending = [p for p in pending if p[0] > t + 1e-9]
        for tt, o in due:
            if o.get("type") == "state" and o.get("state") != states[-1][1]:
                states.append((round(tt, 3), o["state"]))
            elif o.get("type") == "diagnostic":
                diags.append({"t": round(tt, 3), "level": o.get("level", "WARN"), "name": o.get("name", ""), "message": o.get("message", "")})
        t = round(t + dt, 9)
    exps = evaluate(scenario, faults, states, diags)
    world = World(scenario.get("world") or DEFAULT_WORLD)
    traj = [world.pose(k * 0.5)[:2] for k in range(int(dur * 2) + 1)]
    gnss = [(m["t_recv"], m["data"].get("x"), m["data"].get("y")) for m in msgs if m["data"].get("covariance_m2") is not None][::5]
    time_in = {s: 0.0 for s in STATES}
    for (a, s), (b, _) in zip(states, states[1:] + [(dur, None)]):
        time_in[s] = time_in.get(s, 0) + max(0.0, min(b, dur) - a)
    return {
        "status": "passed" if exps and all(e["passed"] for e in exps) else ("failed" if exps else "passed"),
        "expectations": exps,
        "timeline": {"states": states, "diagnostics": diags,
                     "faults": [{"type": f.type, "start_s": f.start_s, "end_s": f.end_s, "target": f.sensor or ",".join(f.sensors) or "sut",
                                 **f.params} for f in faults]},
        "trajectory": {"route": world.route, "ego": [[round(x, 2), round(y, 2)] for x, y in traj],
                       "gnss": [[round(t, 2), x, y] for t, x, y in gnss if x is not None],
                       "objects": world.objects},
        "summary": {"messages_delivered": delivered, "messages_total": len(msgs), "per_sensor": counts,
                    "diagnostics": len(diags), "time_in_state_s": {k: round(v, 2) for k, v in time_in.items()},
                    "final_state": states[-1][1]},
    }


def _state_at(states: list, t: float) -> str:
    cur = states[0][1]
    for tt, s in states:
        if tt <= t:
            cur = s
        else:
            break
    return cur


def evaluate(scn: dict, faults: list[Fault], states: list, diags: list) -> list[dict]:
    out = []
    for e in scn.get("expectations", []):
        typ = e.get("type")
        f = faults[int(e["fault"])] if e.get("fault") is not None and int(e["fault"]) < len(faults) else None
        r = {**e, "passed": False, "measured": None, "detail": ""}
        if typ == "detect" and f:
            lim = float(e.get("within_ms", 500)) / 1000
            minr = LEVEL_RANK.get(e.get("min_level", "WARN"), 1)
            hit = next((d for d in diags if f.start_s <= d["t"] <= f.start_s + lim and LEVEL_RANK.get(d["level"], -1) >= minr
                        and (not e.get("match") or e["match"].lower() in f"{d['name']} {d['message']}".lower())), None)
            if hit:
                r.update(passed=True, measured=round((hit["t"] - f.start_s) * 1000, 1),
                         detail=f"'{hit['message']}' after {(hit['t'] - f.start_s) * 1000:.0f} ms")
            else:
                r["detail"] = f"no {e.get('min_level', 'WARN')}+ diagnostic" + (f" matching '{e['match']}'" if e.get("match") else "") + \
                    f" within {lim * 1000:.0f} ms of the {f.type} at {f.start_s} s"
        elif typ == "state" and f:
            lim = float(e.get("within_ms", 1000)) / 1000
            allowed = e.get("allowed", ["DEGRADED", "MINIMAL_RISK"])
            hit = next(((tt, s) for tt, s in states if f.start_s <= tt <= f.start_s + lim and s in allowed), None)
            if not hit and _state_at(states, f.start_s) in allowed:
                hit = (f.start_s, _state_at(states, f.start_s))
            if hit:
                r.update(passed=True, measured=round((hit[0] - f.start_s) * 1000, 1), detail=f"entered {hit[1]} after {(hit[0] - f.start_s) * 1000:.0f} ms")
            else:
                r["detail"] = f"did not enter {'/'.join(allowed)} within {lim * 1000:.0f} ms (state: {_state_at(states, f.start_s + lim)})"
        elif typ == "recover" and f:
            lim = float(e.get("within_s", 3))
            hit = next(((tt, s) for tt, s in states if f.end_s <= tt <= f.end_s + lim and s == "NOMINAL"), None)
            if not hit and _state_at(states, f.end_s) == "NOMINAL":
                hit = (f.end_s, "NOMINAL")
            if hit:
                r.update(passed=True, measured=round(hit[0] - f.end_s, 3), detail=f"NOMINAL {hit[0] - f.end_s:.2f} s after the fault ended")
            else:
                r["detail"] = f"not NOMINAL within {lim} s after the fault ended (state: {_state_at(states, f.end_s + lim)})"
        elif typ == "no_false_alarm":
            until = float(e.get("until_s", min((x.start_s for x in faults), default=float(scn.get("duration_s", 30)))))
            bad = [d for d in diags if d["t"] < until and d["level"] in ("WARN", "ERROR")]
            r.update(passed=not bad, measured=len(bad),
                     detail="no warnings before the first fault" if not bad else f"{len(bad)} warning(s) before {until} s, first: {bad[0]['message']}")
        elif typ == "never_state":
            st = e.get("state", "MINIMAL_RISK")
            hit = next(((tt, s) for tt, s in states if s == st), None)
            r.update(passed=hit is None, measured=hit[0] if hit else None,
                     detail=f"never entered {st}" if hit is None else f"entered {st} at {hit[0]} s")
        else:
            r["detail"] = "invalid expectation (unknown type or fault index)"
        out.append(r)
    return out


def validate_scenario(scn: dict) -> list[str]:
    errs = []
    dur = float(scn.get("duration_s", 0) or 0)
    if not 1 <= dur <= 600:
        errs.append("duration_s must be between 1 and 600")
    sensors = {**DEFAULT_SENSORS, **(scn.get("sensors") or {})}
    for i, f in enumerate(scn.get("faults", [])):
        if f.get("type") not in FAULT_TYPES:
            errs.append(f"faults[{i}].type must be one of {', '.join(FAULT_TYPES)}")
            continue
        try:
            s, e = float(f["start_s"]), float(f["end_s"])
        except (KeyError, TypeError, ValueError):
            errs.append(f"faults[{i}] needs numeric start_s and end_s")
            continue
        if not 0 <= s < e <= dur:
            errs.append(f"faults[{i}] window must satisfy 0 <= start_s < end_s <= duration_s")
        for name in [f.get("sensor")] + list(f.get("sensors") or []):
            if name and name not in sensors:
                errs.append(f"faults[{i}] references unknown sensor '{name}'")
    for i, e in enumerate(scn.get("expectations", [])):
        if e.get("type") not in EXPECTATION_TYPES:
            errs.append(f"expectations[{i}].type must be one of {', '.join(EXPECTATION_TYPES)}")
        if e.get("type") in ("detect", "state", "recover") and not (isinstance(e.get("fault"), int) and 0 <= e["fault"] < len(scn.get("faults", []))):
            errs.append(f"expectations[{i}].fault must index a fault")
    return errs


def assert_expectations(result: dict) -> None:
    """For pytest: fail with a readable message listing unmet expectations."""
    bad = [e for e in result["expectations"] if not e["passed"]]
    assert not bad, "; ".join(f"{e['type']}: {e['detail']}" for e in bad)


def apply_faults(messages: list[dict], faults_cfg: list[dict], seed: int = 1) -> list[dict]:
    """Apply sensor-level faults to an existing (e.g. replayed) message stream. Times are seconds from stream start;
    a message's capture time is its stamp."""
    rng = random.Random(seed)
    faults = [Fault.from_dict(f) for f in faults_cfg]
    out = []
    for m in messages:
        m = copy.deepcopy(m)
        active = [f for f in faults if f.active(m["stamp"]) and (f.hits(m["sensor"]) or f.type == "comm_interruption" and not (f.sensor or f.sensors))]
        if any(f.type in ("sensor_dropout", "comm_interruption") for f in active):
            continue
        for f in active:
            if f.type == "stale_timestamps":
                m["stamp"] -= float(f.params.get("delay_ms", 300)) / 1000
            elif f.type == "timestamp_jitter":
                m["stamp"] += rng.gauss(0, float(f.params.get("jitter_ms", 40)) / 1000)
            elif f.type == "latency_increase":
                m["t_recv"] += float(f.params.get("add_ms", 200)) / 1000
            elif f.type == "invalid_messages" and rng.random() < float(f.params.get("probability", 1.0)):
                m["data"] = _corrupt(m.get("kind", ""), m["data"], f.params.get("mode", "nan"))
        out.append(m)
    return sorted(out, key=lambda x: x["t_recv"])


def scenario_from_env() -> dict:
    """The scenario attached to the running INTEGRA test case (INTEGRA_SCENARIO_PATH)."""
    import json
    import os
    p = os.environ.get("INTEGRA_SCENARIO_PATH")
    if not p:
        raise LookupError("No scenario attached to this test case")
    with open(p, encoding="utf-8") as f:
        return json.load(f)
