"""
Utilities to parse SVG graphics into fpdf.drawing objects.

The contents of this module are internal to fpdf2, and not part of the public API.
They may change at any time without prior warning or any deprecation period,
in non-backward-compatible ways.

Usage documentation at: <https://py-pdf.github.io/fpdf2/SVG.html>
"""

# pyright: reportUnknownLambdaType=false, reportUnknownArgumentType=false, reportUnknownMemberType=false

import logging
import math
import re
from copy import copy, deepcopy
from dataclasses import dataclass
from os import PathLike
from typing import TYPE_CHECKING, Any, Callable, NamedTuple, Optional

# nosemgrep: python.lang.security.use-defused-xml.use-defused-xml
from xml.etree.ElementTree import fromstring as parse_xml_str  # nosec B405

from fontTools.svgLib.path import (
    parse_path,  # pyright: ignore[reportUnknownVariableType]
)

from . import html
from .drawing import (
    BoundingBox,
    ClippingPath,
    GradientPaint,
    GraphicsContext,
    GraphicsStyle,
    InheritType,
    PaintedPath,
    PathPen,
    PatternPaint,
    Text,
    TextRun,
)
from .drawing_primitives import (
    Color,
    DeviceGray,
    DeviceRGB,
    Point,
    Transform,
    color_from_hex_string,
    color_from_rgb_string,
    force_nodocument,
)
from .enums import (
    GradientSpreadMethod,
    GradientUnits,
    PathPaintRule,
    ResourceAccessPolicy,
    StrokeCapStyle,
)
from .errors import FPDFSvgLimitExceeded
from .image_datastructures import ImageCache, VectorImageInfo
from .output import stream_content_for_raster_image
from .pattern import shape_linear_gradient, shape_radial_gradient

# pylint: disable=unused-import
from .util import absolute_length_units  # pyright: ignore[reportUnusedImport]
from .util import relative_length_units  # pyright: ignore[reportUnusedImport]
from .util import (
    resolve_length,
    unit_splitter,
)

# pylint: enable=unused-import

if TYPE_CHECKING:
    from xml.etree.ElementTree import Element  # nosec

    from .drawing import Renderable
    from .fpdf import FPDF
    from .output import ResourceCatalog


LOGGER = logging.getLogger(__name__)


# https://www.w3.org/TR/SVG/Overview.html

_HANDY_NAMESPACES = {
    "svg": "http://www.w3.org/2000/svg",
    "xlink": "http://www.w3.org/1999/xlink",
}

NUMBER_SPLIT = re.compile(r"(?:\s+,\s+|\s+,|,\s+|\s+|,)")
TRANSFORM_GETTER = re.compile(
    r"(matrix|rotate|scale|scaleX|scaleY|skew|skewX|skewY|translate|translateX|translateY)\(([\d\.,\s+eE-]+)\)"
)

# One coordinate of a points attribute, with the whitespace and comma that may follow it
COORDINATE_RE = re.compile(r"\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s*,?")
CSS_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
CSS_BLOCK_RE = re.compile(r"(?s)([^{}]+)\{([^{}]*)\}")

SVG_SWITCH_CONDITIONAL_ATTRIBUTES = (
    "requiredFeatures",
    "requiredExtensions",
    "systemLanguage",
)


def _normalize_css_value(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        return stripped
    return value


def _has_switch_conditional_attrs(tag: "Element") -> bool:
    return any(
        attribute in tag.attrib for attribute in SVG_SWITCH_CONDITIONAL_ATTRIBUTES
    )


@force_nodocument
class Percent(float):
    """class to represent percentage values"""


@dataclass(frozen=True)
class SVGLimits:
    """
    Configurable limits for SVG processing.

    A limit set to None disables that specific check. Disabling or raising limits
    should only be done for SVG input from trusted sources.
    """

    max_use_depth: int | None = 32
    "Maximum depth allowed while resolving nested SVG <use> references."

    max_resolved_elements: int | None = 100_000
    "Maximum number of elements allowed after resolving SVG control flow."

    def __post_init__(self) -> None:
        self._validate_limit("max_use_depth", self.max_use_depth)
        self._validate_limit("max_resolved_elements", self.max_resolved_elements)

    @staticmethod
    def _validate_limit(name: str, value: int | None) -> None:
        if value is not None and value <= 0:
            raise ValueError(f"{name} must be a positive integer or None")


def _resolved_element_cost(item: Any) -> int:
    if isinstance(item, GraphicsContext):
        return 1 + sum(_resolved_element_cost(child) for child in item.path_items)
    return 1


angle_units = {
    "deg": math.tau / 360,
    "grad": math.tau / 400,
    "rad": 1,  # pdf canonical unit
    "turn": math.tau,
}


class SymbolInfo(NamedTuple):
    """Reusable SVG <symbol> sizing metadata."""

    viewbox: tuple[float, float, float, float]
    width: Optional[float]
    height: Optional[float]


@force_nodocument
def resolve_optional_length(length_str: Optional[str]) -> Optional[float]:
    """Resolve an optional absolute SVG length, ignoring unsupported percentages."""
    if not length_str or "%" in length_str:
        return None
    return resolve_length(length_str)


@force_nodocument
def parse_viewbox(viewbox: str) -> tuple[float, float, float, float]:
    """Parse an SVG viewBox into min-x, min-y, width, and height values."""
    parts = [float(num) for num in NUMBER_SPLIT.split(viewbox.strip()) if num]
    if len(parts) != 4:
        raise ValueError(f"invalid viewBox {viewbox}")
    vx, vy, vw, vh = parts
    if (vw < 0) or (vh < 0):
        raise ValueError(f"invalid negative width/height in viewBox {viewbox}")
    return vx, vy, vw, vh


@force_nodocument
def resolve_angle(angle_str: str, default_unit: str = "deg") -> float:
    """Convert an angle value to our canonical angle unit, radians"""
    m = unit_splitter.match(angle_str)
    value: str | float
    if m is not None:
        value, unit = m.groups()
    else:
        value = angle_str
    if not unit:  # pyright: ignore[reportPossiblyUnboundVariable]
        unit = default_unit

    try:
        return float(value) * angle_units[unit]
    except KeyError:
        raise ValueError(f"angle {angle_str} has unknown unit {unit}") from None


@force_nodocument
def xmlns(space: str, name: str) -> str:
    """Create an XML namespace string representation for the given tag name."""
    try:
        space = f"{{{_HANDY_NAMESPACES[space]}}}"
    except KeyError:
        space = ""

    return f"{space}{name}"


@force_nodocument
def xmlns_lookup(space: str, *names: str) -> dict[str, str]:
    """Create a lookup for the given name in the given XML namespace."""

    result = {}
    for name in names:
        result[xmlns(space, name)] = name
        result[name] = name

    return result  # pyright: ignore[reportUnknownVariableType]


@force_nodocument
def without_ns(qualified_tag: str) -> str:
    """Remove the xmlns namespace from a qualified XML tag name"""
    i = qualified_tag.index("}")
    if i >= 0:
        return qualified_tag[i + 1 :]
    return qualified_tag


shape_tags = xmlns_lookup(
    "svg", "rect", "circle", "ellipse", "line", "polyline", "polygon"
)


@force_nodocument
def svgcolor(colorstr: str) -> DeviceRGB | DeviceGray:
    # color keywords are ASCII case-insensitive in SVG/CSS: "Red" is "red"
    colorstr = html.COLOR_DICT.get(colorstr.strip().lower(), colorstr.strip())

    if colorstr.startswith("#"):
        return color_from_hex_string(colorstr)

    if colorstr.lower().startswith("rgb"):
        return color_from_rgb_string(colorstr.lower())

    raise ValueError(f"unsupported color specification {colorstr}")


@force_nodocument
def convert_stroke_width(incoming: str) -> Optional[float]:
    val = resolve_length(incoming)
    if val < 0:
        raise ValueError(f"stroke width {incoming} cannot be negative")
    if val == 0:
        return None
    return val


@force_nodocument
def convert_miterlimit(incoming: str) -> float:
    val = float(incoming)
    if val < 1.0:
        raise ValueError(f"miter limit {incoming} cannot be less than 1")
    return val


@force_nodocument
def clamp_float(min_val: float, max_val: float) -> Callable[[str], float]:
    def converter(value: str) -> float:
        value = value.strip()
        # SVG 2 / CSS also allow opacities as a percentage: "50%" is 0.5
        val = float(value[:-1]) / 100 if value.endswith("%") else float(value)
        if val < min_val:
            return min_val
        if val > max_val:
            return max_val
        return val

    return converter


@force_nodocument
def inheritable(
    value: str, converter: Callable[[str], Any] = lambda value: value
) -> Any:
    if value in ("inherit", "currentColor"):
        return GraphicsStyle.INHERIT
    return converter(value)


@force_nodocument
def optional(
    value: Optional[str], converter: Callable[[str], Any] = lambda noop: noop
) -> Any:
    # Treat missing/empty/whitespace exactly like "not set"
    if value is None:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    if value == "none":
        return None
    return inheritable(value, converter)


@force_nodocument
def svg_paint(colorstr: Optional[str]) -> Any:
    """A fill or stroke paint: "transparent" paints nothing, like "none"."""
    if colorstr and colorstr.startswith("url("):
        return None
    if colorstr and colorstr.strip().lower() == "transparent":
        return None
    return optional(colorstr, svgcolor)


# this is mostly SVG 1.1 stuff. SVG 2 changed some of this and the documentation is much
# harder to assemble into something coherently understandable
svg_attr_map: dict[str, Any] = {
    # https://www.w3.org/TR/SVG11/painting.html#FillProperty
    "fill": lambda colorstr: ("fill_color", svg_paint(colorstr)),
    # https://www.w3.org/TR/SVG11/painting.html#FillRuleProperty
    "fill-rule": lambda fillrulestr: ("intersection_rule", inheritable(fillrulestr)),
    # https://www.w3.org/TR/SVG11/painting.html#FillOpacityProperty
    "fill-opacity": lambda filopstr: (
        "fill_opacity",
        inheritable(filopstr, clamp_float(0.0, 1.0)),
    ),
    # https://www.w3.org/TR/SVG11/painting.html#StrokeProperty
    "stroke": lambda colorstr: ("stroke_color", svg_paint(colorstr)),
    # https://www.w3.org/TR/SVG11/painting.html#StrokeWidthProperty
    "stroke-width": lambda valuestr: (
        "stroke_width",
        inheritable(valuestr, convert_stroke_width),
    ),
    # https://www.w3.org/TR/SVG11/painting.html#StrokeDasharrayProperty
    "stroke-dasharray": lambda dasharray: (
        "stroke_dash_pattern",
        optional(
            dasharray,
            lambda da: [float(item) for item in NUMBER_SPLIT.split(da) if item],
        ),
    ),
    # stroke-dashoffset may be a percentage, which we don't support currently
    # https://www.w3.org/TR/SVG11/painting.html#StrokeDashoffsetProperty
    "stroke-dashoffset": lambda dashoff: (
        "stroke_dash_phase",
        inheritable(dashoff, float),
    ),
    # https://www.w3.org/TR/SVG11/painting.html#StrokeLinecapProperty
    "stroke-linecap": lambda capstr: ("stroke_cap_style", inheritable(capstr)),
    # https://www.w3.org/TR/SVG11/painting.html#StrokeLinejoinProperty
    "stroke-linejoin": lambda joinstr: ("stroke_join_style", inheritable(joinstr)),
    # https://www.w3.org/TR/SVG11/painting.html#StrokeMiterlimitProperty
    "stroke-miterlimit": lambda limstr: (
        "stroke_miter_limit",
        inheritable(limstr, convert_miterlimit),
    ),
    # https://www.w3.org/TR/SVG11/painting.html#StrokeOpacityProperty
    "stroke-opacity": lambda stropstr: (
        "stroke_opacity",
        inheritable(stropstr, clamp_float(0.0, 1.0)),
    ),
}


@force_nodocument
def apply_styles(
    stylable: PaintedPath | GraphicsContext,
    svg_element: "Element",
    computed_style: Optional[dict[str, Any]] = None,
    allow_fill_and_stroke: bool = True,
) -> None:
    """Apply the known styles from `svg_element` to the pdf path/group `stylable`."""
    if computed_style is not None:
        style = computed_style
    else:
        style = {}
        for key, value in html.parse_css_style(
            svg_element.attrib.get("style", "")
        ).items():
            norm_value = _normalize_css_value(value)
            if norm_value is not None:
                style[key] = norm_value
    stylable.style.auto_close = False

    if allow_fill_and_stroke:
        for attr_name, converter in svg_attr_map.items():
            attr_value = _normalize_css_value(style.get(attr_name))
            if attr_value is None:
                attr_value = _normalize_css_value(svg_element.attrib.get(attr_name))
            if attr_value is not None:
                setattr(stylable.style, *converter(attr_value))

    # handle this separately for now
    opacity_str = _normalize_css_value(style.get("opacity"))
    if opacity_str is None:
        opacity_str = _normalize_css_value(svg_element.attrib.get("opacity"))
    if opacity_str is not None:
        # out-of-range values are clamped, as for fill-opacity and stroke-opacity
        opacity = clamp_float(0.0, 1.0)(opacity_str)
        stylable.style.fill_opacity = opacity
        stylable.style.stroke_opacity = opacity

    tfstr = svg_element.attrib.get("transform")
    if tfstr:
        stylable.transform = convert_transforms(tfstr)


@force_nodocument
def _clone_gradient_paint(paint: GradientPaint) -> GradientPaint:
    cloned = GradientPaint(
        gradient=paint.gradient,
        units=paint.units,
        gradient_transform=paint.gradient_transform,
        apply_page_ctm=paint.apply_page_ctm,
        spread_method=paint.spread_method,
    )
    cloned.skip_alpha = paint.skip_alpha
    cloned.coordinate_transform = paint.coordinate_transform
    cloned.local_bbox = paint.local_bbox
    return cloned


class SVGPatternPaint(PatternPaint):
    """Deferred SVG tile definition resolved in the referencing object's space."""

    local_bbox = True

    def __init__(  # pylint: disable=super-init-not-called
        self, group: GraphicsContext, attributes: dict[str, str], svg: "SVGObject"
    ) -> None:
        # SVG definitions bind to a document only when _tile_for() creates a tile.
        self._colored = True
        self.group = group
        self.attributes = attributes
        self.svg = svg
        self.units = GradientUnits.coerce(
            attributes.get("patternUnits", "objectBoundingBox")
        )
        self.content_units = GradientUnits.coerce(
            attributes.get("patternContentUnits", "userSpaceOnUse")
        )
        self.pattern_transform = (
            convert_transforms(attributes.get("patternTransform", ""))
            if attributes.get("patternTransform")
            else Transform.identity()
        )
        self.svg_transform = Transform.identity()
        self._tiles: dict[
            tuple[
                "ResourceCatalog", Optional[BoundingBox], Transform, tuple[float, float]
            ],
            PatternPaint,
        ] = {}

    def __deepcopy__(self, memo: dict[int, Any]) -> "SVGPatternPaint":
        # Each usage gets its own placement transform, while sharing tile contents.
        return copy(self)

    def _coordinate(self, name: str, axis: int) -> float:
        value = self.attributes.get(name, "0")
        if value.endswith("%"):
            fraction = float(value[:-1]) / 100
            if self.units == GradientUnits.OBJECT_BOUNDING_BOX:
                return fraction
            return fraction * self.svg.pattern_viewport[axis]
        return resolve_length(value)

    def _tile_for(
        self, catalog: "ResourceCatalog", bbox: Optional[BoundingBox]
    ) -> Optional[PatternPaint]:
        width, height = self._coordinate("width", 0), self._coordinate("height", 1)
        if not all(math.isfinite(v) and v > 0 for v in (width, height)):
            return None
        needs_bbox = self.units == GradientUnits.OBJECT_BOUNDING_BOX or (
            self.content_units == GradientUnits.OBJECT_BOUNDING_BOX
            and not self.attributes.get("viewBox")
        )
        if needs_bbox and (bbox is None or bbox.width <= 0 or bbox.height <= 0):
            return None
        key = (catalog, bbox, self.svg_transform, self.svg.pattern_viewport)
        if key in self._tiles:
            return self._tiles[key]
        unit_matrix = Transform.identity()
        sx = sy = 1.0
        if self.units == GradientUnits.OBJECT_BOUNDING_BOX:
            assert bbox is not None
            sx, sy = bbox.width, bbox.height
            unit_matrix = Transform(sx, 0, 0, sy, bbox.x0, bbox.y0)
        content_matrix = Transform.identity()
        viewbox = self.attributes.get("viewBox")
        if viewbox:
            vx, vy, vw, vh = parse_viewbox(viewbox)
            if vw <= 0 or vh <= 0:
                return None
            # Aspect-ratio fitting is measured in the physical tile viewport.
            rx, ry = width * sx / vw, height * sy / vh
            preserve = self.attributes.get(
                "preserveAspectRatio", "xMidYMid meet"
            ).split()
            if preserve and preserve[0] == "defer":
                preserve = preserve[1:]
            alignment = preserve[0] if preserve else "xMidYMid"
            dx = dy = 0.0
            if alignment != "none":
                ratio = max(rx, ry) if "slice" in preserve else min(rx, ry)
                rx = ry = ratio
                extra_x, extra_y = width * sx - vw * ratio, height * sy - vh * ratio
                dx = extra_x * (
                    0 if "xMin" in alignment else 1 if "xMax" in alignment else 0.5
                )
                dy = extra_y * (
                    0 if "YMin" in alignment else 1 if "YMax" in alignment else 0.5
                )
            content_matrix = (
                Transform.translation(-vx, -vy)
                @ Transform.scaling(rx, ry)
                @ Transform.translation(dx, dy)
                @ Transform.scaling(1 / sx, 1 / sy)
            )
        elif self.content_units != self.units:
            if self.content_units == GradientUnits.OBJECT_BOUNDING_BOX:
                assert bbox is not None
                content_matrix = Transform.scaling(bbox.width, bbox.height)
            else:
                content_matrix = Transform.scaling(1 / sx, 1 / sy)
        matrix = (
            Transform.translation(self._coordinate("x", 0), self._coordinate("y", 1))
            @ self.pattern_transform
            @ unit_matrix
            @ self.svg_transform
        )
        tile = PatternPaint(catalog, width, height, width, height, matrix)
        wrapper = GraphicsContext()
        wrapper.transform = content_matrix
        wrapper.add_item(self.group)
        # Nested paint servers see the cell's content transform, not the page's.
        apply_svg_transform_to_user_space_gradients(wrapper, pattern_cell=True)
        tile.add_item(wrapper)
        style = GraphicsStyle()
        style.stroke_width = None
        tile.finalize(style)
        self._tiles[key] = tile
        return tile

    def _emit_svg(
        self,
        catalog: "ResourceCatalog",
        bbox: Optional[BoundingBox],
        stroke: bool = False,
    ) -> str:
        tile = self._tile_for(catalog, bbox)
        if tile is None:
            style = GraphicsStyle()
            if stroke:
                style.stroke_opacity = 0
            else:
                style.fill_opacity = 0
            name = catalog.register_graphics_style(style)
            assert name is not None
            return f"{name.serialize()} gs"
        return (
            tile.emit_stroke(catalog, bbox) if stroke else tile.emit_fill(catalog, bbox)
        )

    def emit_fill(
        self, catalog: "ResourceCatalog", bbox: Optional[BoundingBox] = None
    ) -> str:
        return self._emit_svg(catalog, bbox)

    def emit_stroke(
        self, catalog: "ResourceCatalog", bbox: Optional[BoundingBox] = None
    ) -> str:
        return self._emit_svg(catalog, bbox, stroke=True)


@force_nodocument
def apply_svg_transform_to_user_space_gradients(
    node: GraphicsContext | PaintedPath,
    inherited_transform: Optional[Transform] = None,
    pattern_inherited_transform: Optional[Transform] = None,
    pattern_cell: bool = False,
) -> None:
    current_transform = inherited_transform or Transform.identity()
    pattern_transform = pattern_inherited_transform or current_transform

    if isinstance(node, PaintedPath):
        apply_svg_transform_to_user_space_gradients(
            node.get_graphics_context(),
            current_transform,
            pattern_transform,
            pattern_cell,
        )
        return

    if node.transform is not None:
        current_transform = current_transform @ node.transform
        pattern_transform = node.transform @ pattern_transform

    def transform_paint(
        paint: Color | GradientPaint | PatternPaint | InheritType | str | None,
    ) -> None:
        if isinstance(paint, SVGPatternPaint):
            paint.svg_transform = pattern_transform
        elif isinstance(paint, GradientPaint):
            if pattern_cell:
                # Pattern /Matrix is relative to the cell's initial space, not
                # the CTM at the path's painting operator. Map the local bbox
                # first, then apply the cell-content transforms.
                paint.coordinate_transform = pattern_transform
                paint.local_bbox = True
                paint.apply_page_ctm = False
            elif paint.units == GradientUnits.USER_SPACE_ON_USE:
                paint.gradient_transform = paint.gradient_transform @ current_transform

    for paint_attr in ("fill_color", "stroke_color"):
        transform_paint(getattr(node.style, paint_attr))

    for item in node.path_items:
        if isinstance(item, (GraphicsContext, PaintedPath)):
            apply_svg_transform_to_user_space_gradients(
                item, current_transform, pattern_transform, pattern_cell
            )
        elif isinstance(item, Text):
            for run in item.text_runs:
                if run.run_style is not None:
                    for attr in ("fill_color", "stroke_color"):
                        paint = getattr(run.run_style, attr)
                        if pattern_cell or isinstance(paint, SVGPatternPaint):
                            transform_paint(paint)


def _preserve_ws(style_map: dict[str, Any], tag: "Element") -> bool:
    # CSS ‘white-space’ wins; otherwise XML’s xml:space
    ws = (style_map.get("white-space") or "").strip()
    if ws in ("pre", "pre-wrap", "break-spaces"):
        return True
    xml_space = tag.attrib.get("{http://www.w3.org/XML/1998/namespace}space")
    return bool(xml_space == "preserve")


def _collapse_ws(s: Optional[str], preserve: bool = False) -> str:
    """
    Collapse sequences of whitespace characters (spaces, tabs, etc.) to a single space
    In some cases, like with `pre` tags, whitespace should be preserved.
    """
    if s is None:
        return ""
    if preserve:
        return s  # keep all spaces/newlines
    return re.sub(r"\s+", " ", s)


def _svg_font_style_to_emphasis(font_style: Optional[str], font_weight: str) -> str:
    # Map CSS-like values to fpdf "B", "I", "BI", ""
    b = False
    i = False
    if font_weight:
        fw = font_weight.strip().lower()
        # numeric 600+ considered bold in CSS, also "bold", "bolder"
        b = fw in ("bold", "bolder") or (fw.isdigit() and int(fw) >= 600)
    if font_style:
        fs = font_style.strip().lower()
        i = fs in ("italic", "oblique")
    if b and i:
        return "BI"
    if b:
        return "B"
    if i:
        return "I"
    return ""


def _get_attr_or_style(
    tag: "Element", name: str, style_map: Optional[dict[str, Any]] = None
) -> Optional[str]:
    """Return the value for a given attribute, honoring computed style overrides."""
    if style_map is not None:
        value = _normalize_css_value(style_map.get(name))
        if value is not None:
            return value
    if style_map is None:
        inline = html.parse_css_style(tag.attrib.get("style", ""))
        value = _normalize_css_value(inline.get(name))
        if value is not None:
            return value
    return _normalize_css_value(tag.attrib.get(name))


def _parse_font_attrs(
    tag: "Element", style_map: Optional[dict[str, Any]] = None
) -> tuple[Optional[str], str, Optional[float], str]:
    """Returns (font_family or None, font_style_emphasis, font_size_pt or None, text_anchor)"""
    family_value = _get_attr_or_style(tag, "font-family", style_map)
    if family_value:
        cleaned = []
        for item in family_value.split(","):
            stripped = item.strip().replace('"', "").replace("'", "")
            if stripped:
                cleaned.append(stripped)
        family = ",".join(cleaned) if cleaned else None
    else:
        family = None

    # style/weight -> B/I/BI/""
    font_style = _get_attr_or_style(tag, "font-style", style_map) or ""
    font_weight = _get_attr_or_style(tag, "font-weight", style_map) or ""
    emphasis = _svg_font_style_to_emphasis(font_style, font_weight)

    # font-size: default 16px (SVG/CSS); resolve_length defaults to pt; px=0.75pt defined above.
    fs = _get_attr_or_style(tag, "font-size", style_map)
    size_pt = (
        resolve_length(fs) if fs is not None else None
    )  # px handled in absolute_length_units

    # text-anchor: start|middle|end (default start)
    ta = (_get_attr_or_style(tag, "text-anchor", style_map) or "start").strip().lower()
    if ta not in ("start", "middle", "end"):
        ta = "start"

    return family, emphasis, float(size_pt) if size_pt is not None else None, ta


def _parse_xy_delta(
    tag: "Element",
    style_map: Optional[dict[str, Any]] = None,
    font_size: Optional[float] = None,
) -> tuple[float, float, float, float]:
    """x,y (default 0,0) and optional dx,dy (default 0)"""

    # pylint: disable=too-many-return-statements
    def first_number(
        name: str,
        default: float = 0.0,
        resolver: Callable[[str], float] = resolve_length,
    ) -> float:
        attr = None
        if style_map is not None and name in style_map:
            attr = style_map[name]
        elif name in tag.attrib:
            attr = tag.attrib[name]
        if not attr:
            return default
        parts = NUMBER_SPLIT.split(attr.strip())
        if not parts or not parts[0]:
            return default
        token = parts[0]
        match = unit_splitter.fullmatch(token)
        if match:
            value_str = match.group("value")
            unit = (match.group("unit") or "").strip()
            if unit.lower() in {"em", "rem"}:
                if font_size is None:
                    LOGGER.warning(
                        "Ignoring relative %s length on <%s %s> because font size is unknown",
                        unit,
                        tag.tag,
                        name,
                    )
                    return default
                try:
                    return float(value_str) * font_size
                except (TypeError, ValueError):
                    return default
            if unit.lower() == "ex":
                if font_size is None:
                    LOGGER.warning(
                        "Ignoring relative ex length on <%s %s> because font size is unknown",
                        tag.tag,
                        name,
                    )
                    return default
                try:
                    return float(value_str) * font_size * 0.5
                except (TypeError, ValueError):
                    return default
        try:
            return float(resolver(token))
        except ValueError:
            LOGGER.warning(
                "Ignoring unsupported length '%s' on <%s %s>",
                token,
                tag.tag,
                name,
            )
            return default

    x = first_number("x", 0.0)
    y = first_number("y", 0.0)
    dx = first_number("dx", 0.0)
    dy = first_number("dy", 0.0)
    return x, y, dx, dy


def _extract_css_class_styles(css_text: str) -> list[tuple[str, dict[str, Any]]]:
    styles: list[tuple[str, dict[str, Any]]] = []
    if not css_text:
        return styles

    cleaned = CSS_COMMENT_RE.sub("", css_text)
    for selector_block, body in CSS_BLOCK_RE.findall(cleaned):
        declarations = html.parse_css_style(body)
        if not declarations:
            continue
        normalized = {}
        for key, value in declarations.items():
            norm_value = _normalize_css_value(value)
            if norm_value is not None:
                normalized[key] = norm_value
        if not normalized:
            continue
        selectors = [selector.strip() for selector in selector_block.split(",")]
        for selector in selectors:
            if not selector.startswith("."):
                continue
            class_name = selector[1:].split(":", 1)[0].strip()
            if not class_name:
                continue
            styles.append((class_name, dict(normalized)))
    return styles


@force_nodocument
class ShapeBuilder:
    """A namespace within which methods for converting basic shapes can be looked up."""

    @staticmethod
    def new_path(tag: "Element", clipping_path: bool = False) -> PaintedPath:
        """Create a new path with the appropriate styles."""
        path = PaintedPath()
        if clipping_path:
            path = ClippingPath()
        apply_styles(path, tag)
        return path

    @classmethod
    def rect(cls, tag: "Element", clipping_path: bool = False) -> PaintedPath:
        """Convert an SVG <rect> into a PDF path."""
        # svg rect is wound clockwise
        x = resolve_length(tag.attrib.get("x", "0"))
        y = resolve_length(tag.attrib.get("y", "0"))
        width_str = tag.attrib.get("width") or "0"
        if width_str.endswith("%"):
            width: Percent | float = Percent(width_str[:-1])
        else:
            width = resolve_length(width_str)
        height_str = tag.attrib.get("height") or "0"
        if height_str.endswith("%"):
            height: Percent | float = Percent(height_str[:-1])
        else:
            height = resolve_length(height_str)
        rx_str = tag.attrib.get("rx") or "auto"
        ry_str = tag.attrib.get("ry") or "auto"

        if rx_str == "none":
            rx_str = "0"
        if ry_str == "none":
            ry_str = "0"

        rx: float
        ry: float

        if rx_str == ry_str == "auto":
            rx = ry = 0
        elif rx_str == "auto":
            rx = ry = resolve_length(ry_str)
        elif ry_str == "auto":
            ry = rx = resolve_length(rx_str)
        else:
            rx = resolve_length(rx_str)
            ry = resolve_length(ry_str)

        if (width < 0) or (height < 0) or (rx < 0) or (ry < 0):
            raise ValueError(f"bad rect {tag}")

        if (width == 0) or (height == 0):
            return PaintedPath()

        if rx > (width / 2):
            rx = width / 2
        if ry > (height / 2):
            ry = height / 2

        path = cls.new_path(tag, clipping_path)
        path.rectangle(x, y, width, height, rx, ry)
        return path

    @classmethod
    def circle(cls, tag: "Element", clipping_path: bool = False) -> PaintedPath:
        """Convert an SVG <circle> into a PDF path."""
        cx = resolve_length(tag.attrib.get("cx", "0"))
        cy = resolve_length(tag.attrib.get("cy", "0"))
        r = resolve_length(tag.attrib["r"])

        path = cls.new_path(tag, clipping_path)
        path.circle(cx, cy, r)
        return path

    @classmethod
    def ellipse(cls, tag: "Element", clipping_path: bool = False) -> PaintedPath:
        """Convert an SVG <ellipse> into a PDF path."""
        cx = resolve_length(tag.attrib.get("cx", "0"))
        cy = resolve_length(tag.attrib.get("cy", "0"))

        rx_str = tag.attrib.get("rx") or "auto"
        ry_str = tag.attrib.get("ry") or "auto"

        path = cls.new_path(tag, clipping_path)

        if (rx_str == ry_str == "auto") or (rx_str == "0") or (ry_str == "0"):
            return path

        if rx_str == "auto":
            rx = ry = resolve_length(ry_str)
        elif ry_str == "auto":
            rx = ry = resolve_length(rx_str)
        else:
            rx = resolve_length(rx_str)
            ry = resolve_length(ry_str)

        path.ellipse(cx, cy, rx, ry)
        return path

    @classmethod
    def line(cls, tag: "Element") -> PaintedPath:
        """Convert an SVG <line> into a PDF path."""
        x1 = resolve_length(tag.attrib["x1"])
        y1 = resolve_length(tag.attrib["y1"])
        x2 = resolve_length(tag.attrib["x2"])
        y2 = resolve_length(tag.attrib["y2"])

        path = cls.new_path(tag)
        path.move_to(x1, y1)
        path.line_to(x2, y2)
        return path

    @staticmethod
    def _complete_points(points: str) -> str:
        """The coordinate pairs of a points attribute, up to the first error.

        Like an incorrect <path>, an error (an invalid coordinate or an odd number
        of them) is rendered up to and including the last complete pair before it,
        and nothing after it; no points renders nothing.
        https://www.w3.org/TR/SVG11/shapes.html#PolylineElement
        https://www.w3.org/TR/SVG11/implnote.html#PathElementImplementationNotes
        """
        coordinates = []
        position = 0
        while match := COORDINATE_RE.match(points, position):
            coordinates.append(match.group(1))
            position = match.end()
        if len(coordinates) % 2:
            coordinates.pop()
        return " ".join(coordinates)

    @classmethod
    def polyline(cls, tag: "Element") -> PaintedPath:
        """Convert an SVG <polyline> into a PDF path."""
        path = cls.new_path(tag)
        points = cls._complete_points(tag.attrib["points"])
        if points:
            svg_path_converter(path, "M" + points)
        return path

    @classmethod
    def polygon(cls, tag: "Element", clipping_path: bool = False) -> PaintedPath:
        """Convert an SVG <polygon> into a PDF path."""
        path = cls.new_path(tag, clipping_path)
        points = cls._complete_points(tag.attrib["points"])
        if points:
            svg_path_converter(path, "M" + points + "Z")
        return path


@force_nodocument
def convert_transforms(tfstr: str) -> Transform:
    """Convert SVG/CSS transform functions into PDF transforms."""

    # SVG 2 uses CSS transforms. SVG 1.1 transforms are slightly different. I'm really
    # not sure if it is worth it to try to support SVG 2 because it is significantly
    # more entangled with The HTML Disaster than SVG 1.1, which makes it astronomically
    # harder to support.
    # https://drafts.csswg.org/css-transforms/#two-d-transform-functions
    parsed = TRANSFORM_GETTER.findall(tfstr)
    # pylint: disable=redefined-loop-name
    transform = Transform.identity()
    for tf_type, args in parsed:
        args = args.strip()
        if tf_type == "matrix":
            a, b, c, d, e, f = tuple(float(n) for n in NUMBER_SPLIT.split(args))
            transform = Transform(a, b, c, d, e, f) @ transform

        elif tf_type == "rotate":
            theta, *about = NUMBER_SPLIT.split(args)
            theta = resolve_angle(theta)
            rotation = Transform.rotation(theta=theta)
            if about:
                # this is an SVG 1.1 feature. SVG 2 uses the transform-origin property.
                # see: https://www.w3.org/TR/SVG11/coords.html#TransformAttribute
                if len(about) == 2:
                    rotation = rotation.about(float(about[0]), float(about[1]))
                else:
                    raise ValueError(
                        f"rotation transform {tf_type}({args}) is malformed"
                    )

            transform = rotation @ transform

        elif tf_type == "scale":
            # if sy is not provided, it takes a value equal to sx
            args = NUMBER_SPLIT.split(args)
            if len(args) == 2:
                sx = float(args[0])
                sy = float(args[1])
            elif len(args) == 1:
                sx = sy = float(args[0])
            else:
                raise ValueError(f"bad scale transform {tfstr}")

            transform = Transform.scaling(x=sx, y=sy) @ transform

        elif tf_type == "scaleX":  # SVG 2
            transform = Transform.scaling(x=float(args), y=1) @ transform

        elif tf_type == "scaleY":  # SVG 2
            transform = Transform.scaling(x=1, y=float(args)) @ transform

        elif tf_type == "skew":  # SVG 2, not the same as skewX@skewY
            # if sy is not provided, it takes a value equal to 0
            args = NUMBER_SPLIT.split(args)
            if len(args) == 2:
                sx = resolve_angle(args[0])
                sy = resolve_angle(args[1])
            elif len(args) == 1:
                sx = resolve_angle(args[0])
                sy = 0
            else:
                raise ValueError(f"bad skew transform {tfstr}")

            transform = Transform.shearing(x=math.tan(sx), y=math.tan(sy)) @ transform

        elif tf_type == "skewX":
            transform = (
                Transform.shearing(x=math.tan(resolve_angle(args)), y=0) @ transform
            )

        elif tf_type == "skewY":
            transform = (
                Transform.shearing(x=0, y=math.tan(resolve_angle(args))) @ transform
            )

        elif tf_type == "translate":
            # if y is not provided, it takes a value equal to 0
            args = NUMBER_SPLIT.split(args)
            if len(args) == 2:
                x = resolve_length(args[0])
                y = resolve_length(args[1])
            elif len(args) == 1:
                x = resolve_length(args[0])
                y = 0
            else:
                raise ValueError(f"bad translation transform {tfstr}")

            transform = Transform.translation(x=x, y=y) @ transform

        elif tf_type == "translateX":  # SVG 2
            transform = Transform.translation(x=resolve_length(args), y=0) @ transform

        elif tf_type == "translateY":  # SVG 2
            transform = Transform.translation(x=0, y=resolve_length(args)) @ transform

    return transform


@force_nodocument
def svg_path_converter(pdf_path: PaintedPath, svg_path: str) -> None:
    pen = PathPen(pdf_path)
    parse_path(svg_path, pen)
    if not pen.first_is_move:
        raise ValueError("Path does not start with move item")


class SVGObject:
    """
    A representation of an SVG that has been converted to a PDF representation.
    """

    @classmethod
    def from_file(
        cls,
        filename: str | PathLike[str],
        *args: Any,
        encoding: str = "utf-8",
        **kwargs: Any,
    ) -> "SVGObject":
        """
        Create an `SVGObject` from the contents of the file at `filename`.

        Args:
            filename (path-like): the path to a file containing SVG data.
            *args: forwarded directly to the SVGObject initializer. For subclass use.
            encoding (str): optional charset encoding to use when reading the file.
            **kwargs: forwarded directly to the SVGObject initializer. For subclass use.

        Returns:
            A converted `SVGObject`.
        """
        with open(filename, "r", encoding=encoding) as svgfile:
            return cls(svgfile.read(), *args, **kwargs)

    def __init__(
        self,
        svg_text: str | bytes,
        image_cache: Optional[ImageCache] = None,
        resource_access_policy: ResourceAccessPolicy = ResourceAccessPolicy.DEFAULT,
        svg_limits: Optional[SVGLimits] = None,
    ) -> None:
        self.image_cache = image_cache  # Needed to render images
        self.resource_access_policy = resource_access_policy
        self.svg_limits = svg_limits or SVGLimits()
        self._resolved_element_count = 0
        self.cross_references: dict[str, Any] = {}
        self._cross_reference_costs: dict[str, int] = {}
        self.symbol_info: dict[str, SymbolInfo] = {}
        self.css_class_styles: dict[str, dict[str, Any]] = {}
        self.gradient_definitions: dict[str, GradientPaint] = (
            {}
        )  # Store parsed gradients by ID
        self.pattern_definitions: dict[str, SVGPatternPaint] = {}
        self._patterns_in_progress: set[str] = set()
        self.width: Optional[Percent | float] = None
        self.height: Optional[Percent | float] = None
        # Modern CPython Expat mitigates entity expansion / billion laughs natively:
        svg_tree: "Element" = parse_xml_str(svg_text)  # nosec B314

        if svg_tree.tag not in xmlns_lookup("svg", "svg"):
            raise ValueError(f"root tag must be svg, not {svg_tree.tag}")

        self._pattern_elements = {
            "#" + element.attrib["id"]: element
            for element in svg_tree.iter()
            if element.tag in xmlns_lookup("svg", "pattern")
            and element.attrib.get("id")
        }
        self._pattern_parents = {
            child: parent for parent in svg_tree.iter() for child in parent
        }
        self._collect_css_styles(svg_tree)
        self.extract_shape_info(svg_tree)
        self.pattern_viewport = (
            (self.viewbox[2], self.viewbox[3])
            if self.viewbox
            else (float(self.width or 300), float(self.height or 150))
        )
        self._check_svg_limits(svg_tree)
        self.convert_graphics(svg_tree)

    @force_nodocument
    def update_xref(self, key: Optional[str], referenced: Any) -> None:
        if key:
            key = "#" + key if not key.startswith("#") else key
            self.cross_references[key] = referenced
            self._cross_reference_costs[key] = _resolved_element_cost(referenced)

    def _record_resolved_elements(self, count: int) -> None:
        max_resolved_elements = self.svg_limits.max_resolved_elements
        if max_resolved_elements is None:
            return
        if self._resolved_element_count + count > max_resolved_elements:
            raise FPDFSvgLimitExceeded(
                "SVG complexity exceeds the configured "
                f"max_resolved_elements limit ({max_resolved_elements})"
            )
        self._resolved_element_count += count

    def _check_svg_limits(self, root_tag: "Element") -> None:
        elements_by_id = {
            f"#{element_id}": element
            for element in root_tag.iter()
            if (element_id := element.attrib.get("id"))
        }

        def use_ref(use_tag: "Element") -> Optional[str]:
            for candidate in xmlns_lookup("xlink", "href", "id"):
                if candidate in use_tag.attrib:
                    return use_tag.attrib[candidate]
            return None

        max_use_depth = self.svg_limits.max_use_depth
        memo: dict[int, int] = {}
        active_refs: set[str] = set()

        def check_use_depth(depth: int) -> None:
            if max_use_depth is not None and depth > max_use_depth:
                raise FPDFSvgLimitExceeded(
                    "SVG complexity exceeds the configured "
                    f"max_use_depth limit ({max_use_depth})"
                )

        def max_nested_use_depth(element: "Element", current_depth: int = 0) -> int:
            check_use_depth(current_depth)
            element_id = id(element)
            if element_id in memo:
                check_use_depth(current_depth + memo[element_id])
                return memo[element_id]
            depth = 0
            for child in element.iter():
                if child.tag not in xmlns_lookup("svg", "use"):
                    continue
                ref = use_ref(child)
                if not ref:
                    continue
                referenced = elements_by_id.get(ref)
                if referenced is None:
                    continue
                if ref in active_refs:
                    raise FPDFSvgLimitExceeded(
                        f"SVG <use> reference cycle detected for {ref!r}"
                    )
                active_refs.add(ref)
                try:
                    depth = max(
                        depth,
                        1 + max_nested_use_depth(referenced, current_depth + 1),
                    )
                finally:
                    active_refs.remove(ref)
                check_use_depth(current_depth + depth)
            memo[element_id] = depth
            return depth

        for referenced_element in elements_by_id.values():
            max_nested_use_depth(referenced_element)
        max_nested_use_depth(root_tag)

        max_resolved_elements = self.svg_limits.max_resolved_elements
        if max_resolved_elements is None:
            return

        graphic_container_tags = xmlns_lookup("svg", "svg", "symbol", "g", "a")
        graphic_leaf_tags = xmlns_lookup("svg", "path", "image", "text") | shape_tags
        defs_tags = xmlns_lookup("svg", "defs")
        clip_path_tags = xmlns_lookup("svg", "clipPath")
        style_tags = xmlns_lookup("svg", "style")
        gradient_tags = xmlns_lookup("svg", "linearGradient", "radialGradient")
        use_tags = xmlns_lookup("svg", "use")
        switch_tags = xmlns_lookup("svg", "switch")
        projected_cost_memo: dict[int, int] = {}
        active_projected_refs: set[str] = set()

        def check_projected_limit(cost: int) -> int:
            if cost > max_resolved_elements:
                raise FPDFSvgLimitExceeded(
                    "SVG complexity exceeds the configured "
                    f"max_resolved_elements limit ({max_resolved_elements})"
                )
            return cost

        def projected_cost(element: "Element") -> int:
            element_id = id(element)
            if element_id in projected_cost_memo:
                return projected_cost_memo[element_id]

            if element.tag in use_tags:
                ref = use_ref(element)
                if ref is None:
                    return 1
                referenced = elements_by_id.get(ref)
                if referenced is None:
                    return 1
                if ref in active_projected_refs:
                    raise FPDFSvgLimitExceeded(
                        f"SVG <use> reference cycle detected for {ref!r}"
                    )
                active_projected_refs.add(ref)
                cost = 1 + projected_cost(referenced)
                active_projected_refs.remove(ref)
            elif element.tag in switch_tags:
                cost = 1
                for child in element:
                    if _has_switch_conditional_attrs(child):
                        continue
                    cost += projected_cost(child)
                    break
            elif element.tag in graphic_container_tags:
                cost = 1
                defs_cost = sum(
                    projected_cost(child) for child in element if child.tag in defs_tags
                )
                # build_group() currently handles <defs> before normal children, then
                # encounters the same <defs> again while iterating over children.
                cost += defs_cost
                for child in element:
                    cost += projected_cost(child)
                    check_projected_limit(cost)
            elif element.tag in defs_tags:
                cost = sum(projected_cost(child) for child in element)
            elif element.tag in clip_path_tags:
                cost = sum(projected_cost(child) for child in element)
            elif element.tag in graphic_leaf_tags:
                cost = 1
            elif element.tag in style_tags or element.tag in gradient_tags:
                cost = 0
            else:
                cost = 0

            projected_cost_memo[element_id] = check_projected_limit(cost)
            return cost

        projected_cost(root_tag)

    def _collect_css_styles(self, root_tag: "Element") -> None:
        for node in root_tag.iter():
            if node.tag in xmlns_lookup("svg", "style"):
                css_text = "".join(node.itertext() or [])
                for class_name, declarations in _extract_css_class_styles(css_text):
                    existing = self.css_class_styles.setdefault(class_name, {})
                    existing.update(declarations)

    def _style_map_for(self, tag: "Element") -> dict[str, Any]:
        style_map: dict[str, Any] = {}
        if self.css_class_styles:
            class_attr = tag.attrib.get("class")
            if class_attr:
                for class_name in class_attr.split():
                    class_styles = self.css_class_styles.get(class_name)
                    if class_styles:
                        style_map.update(class_styles)
        inline = html.parse_css_style(tag.attrib.get("style", ""))
        for key, value in inline.items():
            norm_value = _normalize_css_value(value)
            if norm_value is not None:
                style_map[key] = norm_value
            elif key in style_map:
                style_map.pop(key, None)
        inheritable_attrs = (
            "font-family",
            "font-size",
            "font-style",
            "font-weight",
            "text-anchor",
            "white-space",
        )
        for attr in inheritable_attrs:
            if attr in tag.attrib:
                norm_value = _normalize_css_value(tag.attrib.get(attr))
                if norm_value is not None:
                    style_map.setdefault(attr, norm_value)
        return style_map

    @force_nodocument
    @staticmethod
    def _convert_gradient_coordinate(value: str, default: str = "0") -> float:
        """Convert SVG gradient coordinate (percentage or number) to float."""
        if value is None or value == "":
            value = default

        value = value.strip()

        if value.endswith("%"):
            return float(value[:-1]) / 100.0

        try:
            return float(value)
        except ValueError:
            try:
                return resolve_length(value)
            except ValueError:
                LOGGER.warning(
                    "Could not parse gradient coordinate '%s', using 0", value
                )
                return 0.0

    @force_nodocument
    @staticmethod
    def _parse_gradient_stops(
        gradient_element: "Element",
    ) -> list[tuple[float, DeviceRGB | DeviceGray]]:
        """Parse <stop> children of a gradient element."""
        stops: list[tuple[float, DeviceRGB | DeviceGray]] = []
        opacity_converter = clamp_float(0.0, 1.0)

        for stop_element in gradient_element:
            tag_name = without_ns(stop_element.tag)
            if tag_name != "stop":
                continue

            offset_str = stop_element.attrib.get("offset")
            if offset_str is None:
                LOGGER.warning("Found <stop> without offset, skipping")
                continue

            offset_str = offset_str.strip()
            if offset_str.endswith("%"):
                offset = float(offset_str[:-1]) / 100.0
            else:
                offset = float(offset_str)

            offset = max(0.0, min(1.0, offset))

            stop_color = None
            stop_opacity = 1.0

            if "stop-opacity" in stop_element.attrib:
                try:
                    stop_opacity = opacity_converter(
                        stop_element.attrib.get("stop-opacity") or "1"
                    )
                except ValueError:
                    pass

            style = stop_element.attrib.get("style", "")
            if style:
                style_dict = html.parse_css_style(style)
                stop_color = style_dict.get("stop-color")
                stop_opacity_str = style_dict.get("stop-opacity")
                if stop_opacity_str:
                    try:
                        stop_opacity = opacity_converter(stop_opacity_str)
                    except ValueError:
                        LOGGER.warning(
                            "Invalid stop-opacity value: %s", stop_opacity_str
                        )

            if stop_color is None:
                stop_color = stop_element.attrib.get("stop-color", "black")

            try:
                color_obj = svgcolor(stop_color)

                color_alpha = color_obj.a if color_obj.a is not None else 1.0
                effective_opacity = color_alpha * stop_opacity
                if effective_opacity < 1.0:
                    if isinstance(color_obj, DeviceRGB):
                        color_obj = DeviceRGB(
                            color_obj.r, color_obj.g, color_obj.b, effective_opacity
                        )
                    if isinstance(color_obj, DeviceGray):
                        color_obj = DeviceGray(color_obj.g, effective_opacity)
                stops.append((offset, color_obj))

            except (ValueError, KeyError) as e:
                LOGGER.warning("Could not parse stop color '%s': %s", stop_color, e)
                continue

        return stops

    @force_nodocument
    @staticmethod
    def _extract_gradient_id(url_value: Optional[str]) -> Optional[str]:
        """Extract gradient ID from url(#id) format."""
        if not url_value or not isinstance(url_value, str):
            return None
        match = re.search(r'url\(\s*["\']?\s*#([^)"\'\s]+)', url_value)
        if match:
            return "#" + match.group(1)
        return None

    @force_nodocument
    def _parse_linear_gradient(self, grad_element: "Element") -> None:
        """Parse a <linearGradient> element and store it in gradient_definitions."""
        grad_id: Optional[str] = grad_element.attrib.get("id")
        if not grad_id:
            LOGGER.warning("Found <linearGradient> without id attribute, skipping")
            return

        if not grad_id.startswith("#"):
            grad_id = "#" + grad_id

        x1 = grad_element.attrib.get("x1", "0%")
        y1 = grad_element.attrib.get("y1", "0%")
        x2 = grad_element.attrib.get("x2", "100%")
        y2 = grad_element.attrib.get("y2", "0%")

        x1_val = self._convert_gradient_coordinate(x1, "0")
        y1_val = self._convert_gradient_coordinate(y1, "0")
        x2_val = self._convert_gradient_coordinate(x2, "1")
        y2_val = self._convert_gradient_coordinate(y2, "0")

        units_str = grad_element.attrib.get("gradientUnits", "objectBoundingBox")
        if units_str == "userSpaceOnUse":
            units = GradientUnits.USER_SPACE_ON_USE
        else:
            units = GradientUnits.OBJECT_BOUNDING_BOX

        spread_str = grad_element.attrib.get("spreadMethod", "pad")
        try:
            spread_method = GradientSpreadMethod.coerce(spread_str)
        except (ValueError, AttributeError):
            spread_method = GradientSpreadMethod.PAD
            LOGGER.warning("Invalid spreadMethod '%s', using PAD", spread_str)

        transform = None
        transform_str = grad_element.attrib.get("gradientTransform")
        if transform_str:
            try:
                transform = convert_transforms(transform_str)
            except (ValueError, AttributeError, TypeError) as e:
                LOGGER.warning("Could not parse gradientTransform: %s", e)

        stops = self._parse_gradient_stops(grad_element)

        if not stops:
            LOGGER.warning("Linear gradient '%s' has no valid stops, skipping", grad_id)
            return

        gradient = shape_linear_gradient(
            x1=x1_val,
            y1=y1_val,
            x2=x2_val,
            y2=y2_val,
            stops=stops,
            spread_method=spread_method,
        )

        gradient_paint = GradientPaint(
            gradient=gradient,
            units=units,
            gradient_transform=transform or Transform.identity(),
            spread_method=spread_method,
        )

        self.gradient_definitions[grad_id] = gradient_paint

        LOGGER.debug("Parsed linear gradient '%s' with %d stops", grad_id, len(stops))

    @force_nodocument
    def _parse_radial_gradient(self, grad_element: "Element") -> None:
        """Parse a <radialGradient> element and store it in gradient_definitions."""
        grad_id = grad_element.attrib.get("id")
        if not grad_id:
            LOGGER.warning("Found <radialGradient> without id attribute, skipping")
            return

        if not grad_id.startswith("#"):
            grad_id = "#" + grad_id

        cx = grad_element.attrib.get("cx", "50%")
        cy = grad_element.attrib.get("cy", "50%")
        r = grad_element.attrib.get("r", "50%")
        fx = grad_element.attrib.get("fx", cx)
        fy = grad_element.attrib.get("fy", cy)
        fr = grad_element.attrib.get("fr", "0%")

        cx_val = self._convert_gradient_coordinate(cx, "0.5")
        cy_val = self._convert_gradient_coordinate(cy, "0.5")
        r_val = self._convert_gradient_coordinate(r, "0.5")
        fx_val = self._convert_gradient_coordinate(fx, str(cx_val))
        fy_val = self._convert_gradient_coordinate(fy, str(cy_val))
        fr_val = self._convert_gradient_coordinate(fr, "0")

        if r_val <= 0:
            LOGGER.warning(
                "Radial gradient '%s' has invalid radius %s, skipping", grad_id, r_val
            )
            return

        units_str = grad_element.attrib.get("gradientUnits", "objectBoundingBox")
        units = (
            GradientUnits.USER_SPACE_ON_USE
            if units_str == "userSpaceOnUse"
            else GradientUnits.OBJECT_BOUNDING_BOX
        )

        spread_str = grad_element.attrib.get("spreadMethod", "pad")
        try:
            spread_method = GradientSpreadMethod.coerce(spread_str)
        except (ValueError, AttributeError):
            spread_method = GradientSpreadMethod.PAD

        transform = None
        transform_str = grad_element.attrib.get("gradientTransform")
        if transform_str:
            try:
                transform = convert_transforms(transform_str)
            except (ValueError, AttributeError, TypeError) as e:
                LOGGER.warning("Could not parse gradientTransform: %s", e)

        stops = self._parse_gradient_stops(grad_element)
        if not stops:
            LOGGER.warning("Radial gradient '%s' has no valid stops, skipping", grad_id)
            return

        gradient = shape_radial_gradient(
            cx=cx_val,
            cy=cy_val,
            r=r_val,
            stops=stops,
            fx=fx_val,
            fy=fy_val,
            fr=fr_val,
            spread_method=spread_method,
        )

        gradient_paint = GradientPaint(
            gradient=gradient,
            units=units,
            gradient_transform=transform or Transform.identity(),
            spread_method=spread_method,
        )

        self.gradient_definitions[grad_id] = gradient_paint
        LOGGER.debug("Parsed radial gradient '%s' with %d stops", grad_id, len(stops))

    def _resolve_pattern_element(
        self, pattern_id: str, visited: tuple[str, ...] = ()
    ) -> Optional["Element"]:
        if pattern_id in visited:
            raise ValueError("Cyclic SVG pattern reference")
        max_depth = self.svg_limits.max_use_depth
        if max_depth is not None and len(visited) >= max_depth:
            raise FPDFSvgLimitExceeded("SVG pattern reference exceeds max_use_depth")
        element = self._pattern_elements.get(pattern_id)
        if element is None:
            return None
        resolved = deepcopy(element)
        href = element.attrib.get(
            "href", element.attrib.get("{http://www.w3.org/1999/xlink}href")
        )
        if href:
            if not href.startswith("#"):
                LOGGER.warning("Ignoring external SVG pattern reference: %s", href)
                return None
            template = self._resolve_pattern_element(href, visited + (pattern_id,))
            if template is None:
                return None
            for attr in (
                "x",
                "y",
                "width",
                "height",
                "patternUnits",
                "patternContentUnits",
                "patternTransform",
                "viewBox",
                "preserveAspectRatio",
            ):
                if attr not in resolved.attrib and attr in template.attrib:
                    resolved.attrib[attr] = template.attrib[attr]
            graphics = [
                child
                for child in resolved
                if child.tag not in xmlns_lookup("svg", "title", "desc", "metadata")
            ]
            if not graphics:
                for child in list(resolved):
                    resolved.remove(child)
                resolved.extend(deepcopy(list(template)))
        return resolved

    def _get_pattern_paint(self, pattern_id: str) -> Optional[SVGPatternPaint]:
        if pattern_id in self.pattern_definitions:
            return deepcopy(self.pattern_definitions[pattern_id])
        if pattern_id in self._patterns_in_progress:
            raise ValueError("Cyclic SVG pattern paint reference")
        element = self._resolve_pattern_element(pattern_id)
        if element is None:
            return None
        self._patterns_in_progress.add(pattern_id)
        try:
            group = GraphicsContext()
            # SVG paint-server contents inherit from their own ancestors, never
            # from the referencing shape's fill or stroke.
            group.style.fill_color = DeviceRGB(0, 0, 0)
            group.style.stroke_color = None
            group.style.stroke_width = None
            group.style.auto_close = False
            # Inherit paint/font properties from the definition's real ancestors.
            # Ancestor transforms and opacity do not belong to the tile contents.
            ancestors: list["Element"] = []
            parent = self._pattern_parents.get(self._pattern_elements[pattern_id])
            while parent is not None:
                ancestors.append(parent)
                parent = self._pattern_parents.get(parent)
            inherited: dict[str, Any] = {}
            font_keys = (
                "font-family",
                "font-size",
                "font-style",
                "font-weight",
                "text-anchor",
                "white-space",
            )
            for ancestor in reversed(ancestors):
                styles = self._style_map_for(ancestor)
                for attr in (*svg_attr_map, *font_keys):
                    value = _get_attr_or_style(ancestor, attr, styles)
                    if value is not None:
                        inherited[attr] = value
            empty = copy(element)
            empty.attrib = {}
            apply_styles(group, empty, inherited)
            self._apply_gradient_paint(group, empty, inherited)
            self.build_group(
                element,
                group,
                {
                    key: value
                    for key, value in inherited.items()
                    if key in font_keys
                    or (
                        key in ("fill", "stroke")
                        and self._extract_gradient_id(value) in self._pattern_elements
                    )
                },
            )
            paint = SVGPatternPaint(group, dict(element.attrib), self)
            self.pattern_definitions[pattern_id] = paint
            return deepcopy(paint)
        finally:
            self._patterns_in_progress.remove(pattern_id)

    @force_nodocument
    def _apply_gradient_paint(
        self,
        stylable: PaintedPath | GraphicsContext,
        svg_element: "Element",
        style_map: Optional[dict[str, Any]] = None,
    ) -> None:
        """Apply gradient paint to fill or stroke if a url(#gradientId) reference is found."""
        fill_value = _get_attr_or_style(svg_element, "fill", style_map)
        if fill_value:
            grad_id = self._extract_gradient_id(fill_value)
            if grad_id and grad_id in self.gradient_definitions:
                stylable.style.fill_color = _clone_gradient_paint(
                    self.gradient_definitions[grad_id]
                )
                LOGGER.debug("Applied gradient %s to fill", grad_id)

        stroke_value = _get_attr_or_style(svg_element, "stroke", style_map)
        if stroke_value:
            grad_id = self._extract_gradient_id(stroke_value)
            if grad_id and grad_id in self.gradient_definitions:
                stylable.style.stroke_color = _clone_gradient_paint(
                    self.gradient_definitions[grad_id]
                )
                LOGGER.debug("Applied gradient %s to stroke", grad_id)

        for attr in ("fill", "stroke"):
            value = _get_attr_or_style(svg_element, attr, style_map)
            pattern_id = self._extract_gradient_id(value) if value else None
            if pattern_id is not None and pattern_id in self._pattern_elements:
                if isinstance(stylable, GraphicsContext):
                    # A group's bounding box must never size an inherited tile.
                    # The referring shapes resolve the paint individually.
                    setattr(stylable.style, attr + "_color", GraphicsStyle.INHERIT)
                else:
                    paint = self._get_pattern_paint(pattern_id)
                    setattr(stylable.style, attr + "_color", paint)

    def _apply_inherited_pattern(
        self, path: PaintedPath, element: "Element", inherited: dict[str, Any]
    ) -> None:
        """Bind inherited pattern URLs at the actual painted shape, not its group."""
        local_style = self._style_map_for(element)
        for attr in ("fill", "stroke"):
            local_value = _get_attr_or_style(element, attr, local_style)
            if local_value not in (None, "inherit"):
                continue
            value = inherited.get(attr)
            pattern_id = self._extract_gradient_id(value) if value else None
            if pattern_id in self._pattern_elements and pattern_id is not None:
                setattr(
                    path.style, attr + "_color", self._get_pattern_paint(pattern_id)
                )

    @force_nodocument
    def extract_shape_info(self, root_tag: "Element") -> None:
        """Collect shape info from the given SVG."""

        width_str = root_tag.get("width")
        height_str = root_tag.get("height")
        viewbox = root_tag.get("viewBox")
        # we don't fully support this, just check for its existence
        preserve_ar = root_tag.get("preserveAspectRatio", True)
        if preserve_ar == "none":
            self.preserve_ar = None
        else:
            self.preserve_ar = True

        self.width = None
        if width_str is not None:
            width_str = width_str.strip()
            if width_str.endswith("%"):
                self.width = Percent(width_str[:-1])
            else:
                self.width = resolve_length(width_str)

        self.height = None
        if height_str is not None:
            height_str = height_str.strip()
            if height_str.endswith("%"):
                self.height = Percent(height_str[:-1])
            else:
                self.height = resolve_length(height_str)

        if viewbox is None:
            self.viewbox = None
        else:
            viewbox = viewbox.strip()
            vx, vy, vw, vh = [float(num) for num in NUMBER_SPLIT.split(viewbox)]
            if (vw < 0) or (vh < 0):
                raise ValueError(f"invalid negative width/height in viewbox {viewbox}")

            self.viewbox = [vx, vy, vw, vh]

    @force_nodocument
    def convert_graphics(self, root_tag: "Element") -> None:
        """Convert the graphics contained in the SVG into the PDF representation."""
        base_group = GraphicsContext()
        base_group.style.stroke_width = None
        base_group.style.auto_close = False
        base_group.style.stroke_cap_style = StrokeCapStyle.BUTT

        self.build_group(root_tag, base_group)

        self.base_group = base_group

    def transform_to_page_viewport(
        self, pdf: "FPDF", align_viewbox: bool = True
    ) -> tuple[float, float, GraphicsContext]:
        """
        Size the converted SVG paths to the page viewport.

        The SVG document size can be specified relative to the rendering viewport
        (e.g. width=50%). If the converted SVG sizes are relative units, then this
        computes the appropriate scale transform to size the SVG to the correct
        dimensions for a page in the current PDF document.

        If the SVG document size is specified in absolute units, then it is not scaled.

        Args:
            pdf (fpdf.fpdf.FPDF): the pdf to use the page size of.
            align_viewbox (bool): if True, mimic some of the SVG alignment rules if the
                viewbox aspect ratio does not match that of the viewport.

        Returns:
            The same thing as `SVGObject.transform_to_rect_viewport`.
        """

        return self.transform_to_rect_viewport(pdf.k, pdf.epw, pdf.eph, align_viewbox)

    def transform_to_rect_viewport(
        self,
        scale: float,
        width: float | Percent,
        height: float | Percent,
        align_viewbox: bool = True,
        ignore_svg_top_attrs: bool = False,
    ) -> tuple[float, float, GraphicsContext]:
        """
        Size the converted SVG paths to an arbitrarily sized viewport.

        The SVG document size can be specified relative to the rendering viewport
        (e.g. width=50%). If the converted SVG sizes are relative units, then this
        computes the appropriate scale transform to size the SVG to the correct
        dimensions for a page in the current PDF document.

        Args:
            scale (Number): the scale factor from document units to PDF points.
            width (Number): the width of the viewport to scale to in document units.
            height (Number): the height of the viewport to scale to in document units.
            align_viewbox (bool): if True, mimic some of the SVG alignment rules if the
                viewbox aspect ratio does not match that of the viewport.
            ignore_svg_top_attrs (bool): ignore <svg> top attributes like "width", "height"
                or "preserveAspectRatio" when figuring the image dimensions.
                Require width & height to be provided as parameters.

        Returns:
            A tuple of (width, height, `fpdf.drawing.GraphicsContext`), where width and
            height are the resolved width and height (they may be 0. If 0, the returned
            `fpdf.drawing.GraphicsContext` will be empty). The
            `fpdf.drawing.GraphicsContext` contains all of the paths that were
            converted from the SVG, scaled to the given viewport size.
        """
        vp_width: float
        vp_height: float

        if ignore_svg_top_attrs:
            # width/height may be Percent when passed from FPDF.image; resolve to float
            if isinstance(width, Percent):
                vp_width = float(width)
            else:
                vp_width = float(width)
        elif isinstance(self.width, Percent):
            if not width:
                raise ValueError(
                    'SVG "width" is a percentage, hence a viewport width is required'
                )
            vp_width = self.width * width / 100
        else:
            vp_width = self.width if self.width is not None else width

        if ignore_svg_top_attrs:
            if isinstance(height, Percent):
                vp_height = float(height)
            else:
                vp_height = float(height)
        elif isinstance(self.height, Percent):
            if not height:
                raise ValueError(
                    'SVG "height" is a percentage, hence a viewport height is required'
                )
            vp_height = self.height * height / 100
        else:
            vp_height = self.height if self.height is not None else height

        if vp_width == 0 or vp_height == 0:
            context = GraphicsContext()
            context.transform = Transform.identity()
            return 0, 0, context

        if scale == 1:
            transform = Transform.identity()
        else:
            transform = Transform.scaling(1 / scale)

        if self.viewbox:
            vx, vy, vw, vh = self.viewbox

            if (vw == 0) or (vh == 0):
                context = GraphicsContext()
                context.transform = Transform.identity()
                return 0, 0, context

            w_ratio = vp_width / vw
            h_ratio = vp_height / vh

            if not ignore_svg_top_attrs and self.preserve_ar and (w_ratio != h_ratio):
                w_ratio = h_ratio = min(w_ratio, h_ratio)

            transform = (
                transform
                @ Transform.translation(x=-vx, y=-vy)
                @ Transform.scaling(x=w_ratio, y=h_ratio)
            )

            if align_viewbox:
                transform = transform @ Transform.translation(
                    x=vp_width / 2 - (vw / 2) * w_ratio,
                    y=vp_height / 2 - (vh / 2) * h_ratio,
                )

        self.pattern_viewport = (
            (self.viewbox[2], self.viewbox[3])
            if self.viewbox
            else (float(vp_width), float(vp_height))
        )
        self.base_group.transform = transform

        return vp_width / scale, vp_height / scale, self.base_group

    def draw_to_page(
        self,
        pdf: "FPDF",
        x: Optional[float] = None,
        y: Optional[float] = None,
        debug_stream: Optional[bool] = None,
    ) -> None:
        """
        Directly draw the converted SVG to the given PDF's current page.

        The page viewport is used for sizing the SVG.

        Args:
            pdf (fpdf.fpdf.FPDF): the document to which the converted SVG is rendered.
            x (Number): abscissa of the converted SVG's top-left corner.
            y (Number): ordinate of the converted SVG's top-left corner.
            debug_stream (io.TextIO): *DEPRECATED* the stream to which rendering debug info will be
                written.
        """
        previous_image_cache = self.image_cache
        previous_resource_access_policy = self.resource_access_policy
        self.image_cache = pdf.image_cache  # Needed to render images
        self.resource_access_policy = pdf.resource_access_policy
        try:
            _, _, path = self.transform_to_page_viewport(pdf)

            old_x, old_y = pdf.x, pdf.y
            try:
                if x is not None and y is not None:
                    pdf.set_xy(0, 0)
                    assert path.transform is not None
                    path.transform = path.transform @ Transform.translation(x, y)

                apply_svg_transform_to_user_space_gradients(path)
                pdf.draw_path(path, debug_stream)

            finally:
                pdf.set_xy(old_x, old_y)
        finally:
            self.image_cache = previous_image_cache
            self.resource_access_policy = previous_resource_access_policy

    # defs paths are not drawn immediately but are added to xrefs and can be referenced
    # later to be drawn.
    @force_nodocument
    def handle_defs(self, defs: "Element") -> None:
        """Produce lookups for groups and paths inside the <defs> tag"""
        for child in defs:
            if child.tag in xmlns_lookup("svg", "g"):
                self.build_group(child)
            elif child.tag in xmlns_lookup("svg", "switch"):
                self.build_switch(child)
            elif child.tag in xmlns_lookup("svg", "symbol"):
                self.build_symbol(child)
            elif child.tag in xmlns_lookup("svg", "a"):
                # <a> tags aren't supported but we need to recurse into them to
                # render nested elements.
                LOGGER.warning(
                    "Ignoring unsupported SVG tag: <a> (contributions are welcome to add support for it)",
                )
                self.build_group(child)
            elif child.tag in xmlns_lookup("svg", "path"):
                self.build_path(child)
            elif child.tag in xmlns_lookup("svg", "image"):
                self.build_image(child)
            elif child.tag in shape_tags:
                self.build_shape(child)
            elif child.tag in xmlns_lookup("svg", "linearGradient"):
                self._parse_linear_gradient(child)
            elif child.tag in xmlns_lookup("svg", "radialGradient"):
                self._parse_radial_gradient(child)
            elif child.tag in xmlns_lookup("svg", "pattern"):
                # Definitions are resolved lazily, including forward references.
                continue
            elif child.tag in xmlns_lookup("svg", "clipPath"):
                try:
                    clip_id = child.attrib["id"]
                except KeyError:
                    clip_id = None
                for child_ in child:
                    self.build_clipping_path(child_, clip_id)
            elif child.tag in xmlns_lookup("svg", "style"):
                # Styles handled globally during parsing
                continue
            else:
                LOGGER.warning(
                    "Ignoring unsupported SVG tag: <%s> (contributions are welcome to add support for it)",
                    without_ns(child.tag),
                )

    @force_nodocument
    def build_symbol(self, symbol: "Element") -> GraphicsContext:
        """Parse <symbol> as reusable content, not rendered directly."""
        group = self.build_group(symbol)
        viewbox = symbol.attrib.get("viewBox")
        if viewbox:
            vx, vy, vw, vh = parse_viewbox(viewbox)
            if vw == 0 or vh == 0:
                group = GraphicsContext()
            else:
                group.transform = Transform.translation(
                    x=-vx, y=-vy
                ) @ Transform.scaling(x=1 / vw, y=1 / vh)
            symbol_id = symbol.attrib.get("id")
            if symbol_id:
                symbol_key = (
                    "#" + symbol_id if not symbol_id.startswith("#") else symbol_id
                )
                self.symbol_info[symbol_key] = SymbolInfo(
                    viewbox=(vx, vy, vw, vh),
                    width=resolve_optional_length(symbol.attrib.get("width")),
                    height=resolve_optional_length(symbol.attrib.get("height")),
                )
        return group

    # this assumes xrefs only reference already-defined ids.
    # I don't know if this is required by the SVG spec.
    @force_nodocument
    def build_xref(
        self, xref: "Element", inherited_style: Optional[dict[str, Any]] = None
    ) -> GraphicsContext:
        """Resolve a cross-reference to an already-seen SVG element by ID."""
        style_map = self._style_map_for(xref)
        pdf_group = GraphicsContext()
        apply_styles(pdf_group, xref, style_map)

        for candidate in xmlns_lookup("xlink", "href", "id"):
            try:
                ref = xref.attrib[candidate]
                break
            except KeyError:
                pass
        else:
            raise ValueError(f"use {xref} doesn't contain known xref attribute")

        try:
            referenced = self.cross_references[ref]
            referenced_cost = self._cross_reference_costs[ref]
        except KeyError:
            raise ValueError(
                f"use {xref} references nonexistent ref id {ref}"
            ) from None
        self._record_resolved_elements(1 + referenced_cost)
        referenced = deepcopy(referenced)
        pattern_paints: dict[str, Optional[SVGPatternPaint]] = {}
        for attr in ("fill", "stroke"):
            value = _get_attr_or_style(xref, attr, style_map)
            if value in (None, "inherit"):
                value = (inherited_style or {}).get(attr)
            pattern_id = self._extract_gradient_id(value) if value else None
            if pattern_id in self._pattern_elements:
                pattern_paints[attr + "_color"] = self._get_pattern_paint(pattern_id)
        if pattern_paints and isinstance(referenced, (GraphicsContext, PaintedPath)):
            self._bind_reference_patterns(referenced, pattern_paints)
        pdf_group.add_item(referenced, False)

        placement_transform = None
        if "x" in xref.attrib or "y" in xref.attrib:
            # Quoting the SVG spec - 5.6.2. Layout of re-used graphics:
            # > The x and y properties define an additional transformation translate(x,y)
            x, y = float(xref.attrib.get("x", 0)), float(xref.attrib.get("y", 0))
            placement_transform = Transform.translation(x=x, y=y)
        # Note that we currently do not support "width" & "height" with % in <use>
        symbol_info = self.symbol_info.get(ref)
        if symbol_info:
            _, _, vw, vh = symbol_info.viewbox
            width = (
                resolve_optional_length(xref.attrib.get("width"))
                or symbol_info.width
                or vw
            )
            height = (
                resolve_optional_length(xref.attrib.get("height"))
                or symbol_info.height
                or vh
            )
            symbol_transform = Transform.scaling(x=width, y=height)
            if placement_transform is None:
                placement_transform = symbol_transform
            else:
                placement_transform = symbol_transform @ placement_transform
        if placement_transform:
            if pdf_group.transform:
                pdf_group.transform = placement_transform @ pdf_group.transform
            else:
                pdf_group.transform = placement_transform

        return pdf_group

    def _bind_reference_patterns(
        self,
        node: GraphicsContext | PaintedPath,
        paints: dict[str, Optional[SVGPatternPaint]],
    ) -> None:
        """Resolve inherited reference paints at each leaf's own bounds."""
        inherited = {
            attr: paint
            for attr, paint in paints.items()
            if getattr(node.style, attr) is GraphicsStyle.INHERIT
        }
        if isinstance(node, PaintedPath):
            for attr, paint in inherited.items():
                setattr(node.style, attr, deepcopy(paint))
            return
        for item in node.path_items:
            if isinstance(item, (GraphicsContext, PaintedPath)):
                self._bind_reference_patterns(item, inherited)

    @force_nodocument
    def build_group(
        self,
        group: "Element",
        pdf_group: Optional[GraphicsContext] = None,
        inherited_style: Optional[dict[str, Any]] = None,
    ) -> GraphicsContext:
        """Handle nested items within a group <g> tag."""
        local_style = self._style_map_for(group)
        merged_style = dict(inherited_style or {})
        merged_style.update(local_style)
        if pdf_group is None:
            pdf_group = GraphicsContext()
        self._record_resolved_elements(1)
        for attr in ("fill", "stroke"):
            local_value = _get_attr_or_style(group, attr, local_style)
            inherited_value = (inherited_style or {}).get(attr)
            if (
                local_value == "inherit"
                and self._extract_gradient_id(inherited_value) in self._pattern_elements
            ):
                merged_style[attr] = inherited_value
            elif local_value is not None and (
                attr in merged_style
                or self._extract_gradient_id(local_value) in self._pattern_elements
            ):
                merged_style[attr] = local_value
        apply_styles(pdf_group, group, merged_style)

        # handle defs before anything else
        for child in [
            child for child in group if child.tag in xmlns_lookup("svg", "defs")
        ]:
            self.handle_defs(child)
        self._apply_gradient_paint(pdf_group, group, merged_style)

        for child in group:
            self._build_group_child(pdf_group, child, merged_style)

        self.update_xref(group.attrib.get("id"), pdf_group)

        return pdf_group

    @force_nodocument
    def _build_group_child(
        self,
        pdf_group: GraphicsContext,
        child: "Element",
        inherited_style: dict[str, Any],
    ) -> None:
        """Convert one graphics child while preserving its parent's style."""
        if child.tag in xmlns_lookup("svg", "defs"):
            self.handle_defs(child)
        elif child.tag in xmlns_lookup(
            "svg", "pattern", "linearGradient", "radialGradient"
        ):
            return
        elif child.tag in xmlns_lookup("svg", "style"):
            # Stylesheets already parsed globally.
            return
        elif child.tag in xmlns_lookup("svg", "symbol"):
            self.build_symbol(child)
        elif child.tag in xmlns_lookup("svg", "g"):
            pdf_group.add_item(self.build_group(child, None, inherited_style), False)
        elif child.tag in xmlns_lookup("svg", "switch"):
            pdf_group.add_item(self.build_switch(child, inherited_style), False)
        elif child.tag in xmlns_lookup("svg", "a"):
            # <a> tags aren't supported but we need to recurse into them to
            # render nested elements.
            LOGGER.warning(
                "Ignoring unsupported SVG tag: <a> (contributions are welcome to add support for it)",
            )
            pdf_group.add_item(self.build_group(child, None, inherited_style), False)
        elif child.tag in xmlns_lookup("svg", "path"):
            path = self.build_path(child)
            self._apply_inherited_pattern(path, child, inherited_style)
            pdf_group.add_item(path, False)
        elif child.tag in shape_tags:
            path = self.build_shape(child)
            self._apply_inherited_pattern(path, child, inherited_style)
            pdf_group.add_item(path, False)
        elif child.tag in xmlns_lookup("svg", "use"):
            pdf_group.add_item(self.build_xref(child, inherited_style), False)
        elif child.tag in xmlns_lookup("svg", "image"):
            pdf_group.add_item(self.build_image(child), False)
        elif child.tag in xmlns_lookup("svg", "text"):
            text_path = self.build_text(child, inherited_style)
            if text_path:
                pdf_group.add_item(text_path, False)
        else:
            LOGGER.warning(
                "Ignoring unsupported SVG tag: <%s> (contributions are welcome to add support for it)",
                without_ns(child.tag),
            )

    @force_nodocument
    def build_switch(
        self, switch: "Element", inherited_style: Optional[dict[str, Any]] = None
    ) -> GraphicsContext:
        """Render the first ``<switch>`` child that needs no environment support.

        Conditional SVG processing attributes need browser capabilities or user locale
        preferences that fpdf2 does not expose. Children that use them are therefore
        skipped, which allows a following unconditional fallback to be rendered.
        """
        local_style = self._style_map_for(switch)
        merged_style = dict(inherited_style or {})
        merged_style.update(local_style)
        pdf_group = GraphicsContext()
        self._record_resolved_elements(1)
        apply_styles(pdf_group, switch, merged_style)

        for child in switch:
            if _has_switch_conditional_attrs(child):
                LOGGER.debug(
                    "Skipping conditional <switch> child <%s>", without_ns(child.tag)
                )
                continue
            self._build_group_child(pdf_group, child, merged_style)
            break

        self.update_xref(switch.attrib.get("id"), pdf_group)
        return pdf_group

    @force_nodocument
    def build_path(self, path: "Element") -> PaintedPath:
        """Convert an SVG <path> tag into a PDF path object."""
        self._record_resolved_elements(1)
        style_map = self._style_map_for(path)
        pdf_path = PaintedPath()
        apply_styles(pdf_path, path, style_map)
        self._apply_gradient_paint(pdf_path, path, style_map)
        self.apply_clipping_path(pdf_path, path, style_map)
        svg_path = path.attrib.get("d")
        if svg_path is not None:
            svg_path_converter(pdf_path, svg_path)
        self.update_xref(path.attrib.get("id"), pdf_path)
        return pdf_path

    @force_nodocument
    def build_shape(self, shape: "Element") -> PaintedPath:
        """Convert an SVG shape tag into a PDF path object. Necessary to make xref (because ShapeBuilder doesn't have access to this object.)"""
        self._record_resolved_elements(1)
        style_map = self._style_map_for(shape)
        shape_builder = getattr(ShapeBuilder, shape_tags[shape.tag])
        shape_path = shape_builder(shape)
        assert isinstance(shape_path, PaintedPath)
        apply_styles(shape_path, shape, style_map)
        self._apply_gradient_paint(shape_path, shape, style_map)
        self.apply_clipping_path(shape_path, shape, style_map)
        self.update_xref(shape.attrib.get("id"), shape_path)
        return shape_path

    @force_nodocument
    def build_clipping_path(self, shape: "Element", clip_id: Optional[str]) -> None:
        if shape.tag in shape_tags:
            self._record_resolved_elements(1)
            style_map = self._style_map_for(shape)
            shape_builder = getattr(ShapeBuilder, shape_tags[shape.tag])
            clipping_path_shape = shape_builder(shape, True)
            apply_styles(clipping_path_shape, shape, style_map)
        elif shape.tag in xmlns_lookup("svg", "path"):
            self._record_resolved_elements(1)
            style_map = self._style_map_for(shape)
            clipping_path_shape = PaintedPath()
            apply_styles(clipping_path_shape, shape, style_map)
            clipping_path_shape.paint_rule = PathPaintRule.DONT_PAINT
            svg_path = shape.attrib.get("d")
            if svg_path is not None:
                svg_path_converter(clipping_path_shape, svg_path)
        else:
            LOGGER.warning(
                "Ignoring unsupported <clipPath> child tag: <%s> (contributions are welcome to add support for it)",
                without_ns(shape.tag),
            )
            return
        self.update_xref(clip_id, clipping_path_shape)

    @force_nodocument
    def apply_clipping_path(
        self,
        stylable: PaintedPath | GraphicsContext,
        svg_element: "Element",
        style_map: Optional[dict[str, Any]] = None,
    ) -> None:
        clip_value = None
        if style_map and "clip-path" in style_map:
            clip_value = style_map["clip-path"]
        if clip_value is None:
            clip_value = svg_element.attrib.get("clip-path")
        if clip_value:
            clipping_path_id = re.search(r"url\((\#\w+)\)", clip_value)
            assert clipping_path_id is not None
            stylable.clipping_path = self.cross_references[clipping_path_id[1]]

    @force_nodocument
    def build_image(self, image: "Element") -> "SVGImage | GraphicsContext":
        self._record_resolved_elements(1)
        href = None
        for key in xmlns_lookup("xlink", "href"):
            if key in image.attrib:
                href = image.attrib[key]
                break
        if not href:
            raise ValueError("<image> is missing a href attribute")
        width = float(image.attrib.get("width", 0))
        height = float(image.attrib.get("height", 0))

        keep_aspect_ratio = True
        preserve_aspect_ratio = image.attrib.get("preserveAspectRatio")
        if preserve_aspect_ratio is not None:
            parts = preserve_aspect_ratio.strip().split()
            align = (
                parts[1]
                if parts and parts[0] == "defer" and len(parts) > 1
                else (parts[0] if parts else "")
            )
            if align == "none":
                keep_aspect_ratio = False
            elif align.startswith("x") and (
                "meet" in parts or "slice" in parts or len(parts) <= 2
            ):
                keep_aspect_ratio = True
                if align != "xMidYMid" or "slice" in parts:
                    LOGGER.warning(
                        'Ignoring preserveAspectRatio alignment/slice mode "%s" on <image> (only "xMidYMid meet" and "none" are supported)',
                        preserve_aspect_ratio,
                    )
            else:
                LOGGER.warning(
                    '"preserveAspectRatio" value "%s" defined on <image> is currently not supported (contributions are welcome to add support for it)',
                    preserve_aspect_ratio,
                )

        # Note: at this moment, self.image_cache is not set yet:
        svg_image = SVGImage(
            href=href,
            x=float(image.attrib.get("x", "0")),
            y=float(image.attrib.get("y", "0")),
            width=width,
            height=height,
            svg_obj=self,
            keep_aspect_ratio=keep_aspect_ratio,
        )

        style_map = self._style_map_for(image)
        has_transform = "transform" in image.attrib
        has_opacity = "opacity" in image.attrib or "opacity" in style_map
        has_clip = "clip-path" in image.attrib or "clip-path" in style_map

        if has_transform or has_opacity or has_clip:
            wrapper = GraphicsContext()
            apply_styles(wrapper, image, style_map, allow_fill_and_stroke=False)
            self.apply_clipping_path(wrapper, image, style_map)
            wrapper.add_item(svg_image, clone=False)
            result: SVGImage | GraphicsContext = wrapper
        else:
            result = svg_image

        self.update_xref(image.attrib.get("id"), result)
        return result

    @force_nodocument
    def build_text(
        self, text_tag: "Element", inherited_style: Optional[dict[str, Any]] = None
    ) -> Optional[PaintedPath]:
        """
        Convert <text> (and simple <tspan>) into a PaintedPath with Text runs.
        - Uses Text baseline at (x,y)
        - Honors x/y and dx/dy on <text> and direct child <tspan>
        - Flattens nested tspans; advanced per-character positioning is not implemented
        """
        self._record_resolved_elements(1)
        local_style = self._style_map_for(text_tag)
        effective_style = dict(inherited_style or {})
        effective_style.update(local_style)
        for attr in ("fill", "stroke"):
            value = _get_attr_or_style(text_tag, attr, local_style)
            inherited_value = (inherited_style or {}).get(attr)
            if (
                value == "inherit"
                and self._extract_gradient_id(inherited_value) in self._pattern_elements
            ):
                effective_style[attr] = inherited_value
            elif value is not None:
                effective_style[attr] = value
        path = PaintedPath()
        apply_styles(path, text_tag, local_style)
        self._apply_gradient_paint(path, text_tag, effective_style)
        self.apply_clipping_path(path, text_tag, effective_style)

        preserve_parent = _preserve_ws(effective_style, text_tag)

        base_family, base_emph, base_size, base_anchor = _parse_font_attrs(
            text_tag, effective_style
        )
        if base_family is None:
            base_family = "sans-serif"
        default_font_size = (
            base_size if base_size is not None else resolve_length("16px")
        )
        base_x, base_y, base_dx, base_dy = _parse_xy_delta(
            text_tag, effective_style, font_size=default_font_size
        )
        anchor_x = base_x + base_dx
        anchor_y = base_y + base_dy

        text_runs: list[TextRun] = []
        pending_dx = 0.0
        pending_dy = 0.0

        def _style_for_run(
            tag: Optional["Element"], style_map_for_tag: Optional[dict[str, Any]]
        ) -> Optional[GraphicsStyle]:
            if tag is None or style_map_for_tag is None:
                return None
            context = GraphicsContext()
            apply_styles(context, tag, style_map_for_tag)
            self._apply_gradient_paint(context, tag, style_map_for_tag)
            context.style.auto_close = GraphicsStyle.INHERIT
            overrides = any(
                getattr(context.style, prop) is not GraphicsStyle.INHERIT
                for prop in GraphicsStyle.MERGE_PROPERTIES
            )
            if not overrides:
                return None
            return deepcopy(context.style)

        def _add_run(
            raw_text: str,
            family: Optional[str],
            emphasis: Optional[str],
            size: Optional[float],
            preserve: bool,
            dx_extra: float = 0.0,
            dy_extra: float = 0.0,
            abs_x: Optional[float] = None,
            abs_y: Optional[float] = None,
            style_tag: Optional["Element"] = None,
            style_map_for_tag: Optional[dict[str, Any]] = None,
        ) -> None:
            nonlocal pending_dx, pending_dy
            raw = raw_text or ""
            collapsed = _collapse_ws(raw, preserve=preserve)
            if preserve:
                content = collapsed
            else:
                trimmed = collapsed.strip()
                if trimmed:
                    content = trimmed
                    if raw[:1].isspace():
                        content = " " + content
                    if raw[-1:].isspace():
                        content = content + " "
                else:
                    if (raw[:1].isspace() or raw[-1:].isspace()) and text_runs:
                        content = " "
                    else:
                        content = ""
            if not content:
                pending_dx += dx_extra
                pending_dy += dy_extra
                return

            run_size = size if size is not None else default_font_size
            run_family = family or base_family or "sans-serif"
            run_emphasis = (emphasis if emphasis is not None else base_emph) or ""
            run_dx = pending_dx + dx_extra
            run_dy = pending_dy + dy_extra
            pending_dx = 0.0
            pending_dy = 0.0
            run_style = _style_for_run(style_tag, style_map_for_tag)

            text_runs.append(
                TextRun(
                    text=content,
                    family=run_family,
                    emphasis=run_emphasis,
                    size=run_size,
                    dx=run_dx,
                    dy=run_dy,
                    abs_x=abs_x,
                    abs_y=abs_y,
                    run_style=run_style,
                )
            )

        # Leading text (before child <tspan>)
        _add_run(
            text_tag.text or "",
            base_family,
            base_emph,
            base_size,
            preserve=preserve_parent,
            style_tag=None,
            style_map_for_tag=None,
        )

        for child in text_tag:
            if child.tag in xmlns_lookup("svg", "tspan"):
                child_local_style = self._style_map_for(child)
                child_effective_style = dict(effective_style)
                child_effective_style.update(child_local_style)
                fam, emph, size, _anchor = _parse_font_attrs(
                    child, child_effective_style
                )
                run_font_size = size if size is not None else default_font_size
                x, y, dx, dy = _parse_xy_delta(
                    child, child_effective_style, font_size=run_font_size
                )

                child_preserve = _preserve_ws(child_effective_style, child)
                raw_itertext = "".join(child.itertext())
                tail_text = child.tail or ""
                if tail_text and raw_itertext.endswith(tail_text):
                    run_text = raw_itertext[: -len(tail_text)]
                else:
                    run_text = raw_itertext
                abs_x = None
                abs_y = None
                if "x" in child.attrib or (
                    child_local_style is not None and "x" in child_local_style
                ):
                    abs_x = x
                if "y" in child.attrib or (
                    child_local_style is not None and "y" in child_local_style
                ):
                    abs_y = y

                _add_run(
                    run_text,
                    fam,
                    emph,
                    size,
                    preserve=child_preserve,
                    dx_extra=dx,
                    dy_extra=dy,
                    abs_x=abs_x,
                    abs_y=abs_y,
                    style_tag=child,
                    style_map_for_tag=child_local_style,
                )

                # Text between tspans inherits parent style
                _add_run(
                    child.tail or "",
                    base_family,
                    base_emph,
                    base_size,
                    preserve=preserve_parent,
                    style_tag=None,
                    style_map_for_tag=None,
                )
            else:
                # other child tags are ignored (already logged elsewhere)
                pass

        if text_runs:
            path.add_path_element(
                Text(
                    x=anchor_x,
                    y=anchor_y,
                    text_runs=tuple(text_runs),
                    text_anchor=base_anchor,
                ),
                clone=False,
            )

        self.update_xref(text_tag.attrib.get("id"), path)
        return path


class SVGImage(NamedTuple):
    href: str
    x: float
    y: float
    width: float
    height: float
    svg_obj: SVGObject
    keep_aspect_ratio: bool = True

    @property
    def is_image_mask(self) -> bool:
        """SVG image elements carry colors rather than a colorless stencil."""
        return False

    def __deepcopy__(self: "SVGImage", _memo: dict[int, Any]) -> "SVGImage":
        # Defining this method is required to avoid the .svg_obj reference to be cloned:
        return SVGImage(
            href=self.href,
            x=self.x,
            y=self.y,
            width=self.width,
            height=self.height,
            svg_obj=self.svg_obj,
            keep_aspect_ratio=self.keep_aspect_ratio,
        )

    # pylint: disable=unused-argument
    @force_nodocument
    def render(
        self,
        resource_registry: "ResourceCatalog",
        style: GraphicsStyle,
        last_item: "Renderable",
        initial_point: Point,
    ) -> tuple[str, "Renderable", Point]:
        image_cache = self.svg_obj and self.svg_obj.image_cache
        if not image_cache:
            raise AssertionError(
                "fpdf2 bug - Cannot render a raster image without a SVGObject.image_cache"
            )

        # We lazy-import this function to circumvent a circular import problem:
        # pylint: disable=cyclic-import,import-outside-toplevel
        from .image_parsing import preload_image

        _, _, info = preload_image(
            image_cache,
            self.href,
            resource_access_policy=self.svg_obj.resource_access_policy,
            svg_limits=self.svg_obj.svg_limits,
        )
        if isinstance(info, VectorImageInfo):
            LOGGER.warning(
                "Inserting .svg vector graphics in <image> tags is currently not supported (contributions are welcome to add support for it)"
            )
            return "", last_item, initial_point
        w, h = info.size_in_document_units(self.width, self.height)
        stream_content = stream_content_for_raster_image(
            info=info,
            x=self.x,
            y=self.y,
            w=w,
            h=h,
            keep_aspect_ratio=self.keep_aspect_ratio,
        )
        return stream_content, last_item, initial_point

    @property
    def end_point(self) -> Point:
        return Point(self.x, self.y)

    # pylint: disable=unused-argument
    def bounding_box(self, start: Point) -> tuple[BoundingBox, Point]:
        x0 = self.x
        y0 = self.y
        x1 = self.x + self.width
        y1 = self.y + self.height

        bbox = BoundingBox.from_points(
            [
                Point(x0, y0),
                Point(x1, y0),
                Point(x0, y1),
                Point(x1, y1),
            ]
        )
        return bbox, Point(self.x, self.y)
