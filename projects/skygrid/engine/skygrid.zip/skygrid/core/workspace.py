"""Workspace: the stateful SkyGrid service for one organisation.

Holds entities in memory, enforces permissions, records audit entries and a change journal, and runs
one live simulation session. The FastAPI service persists the journal to SQL; the browser edition runs
this class unchanged inside Pyodide.
"""

from __future__ import annotations

import copy
import datetime as dt
import math
import time

import numpy as np

from . import analytics, assistant, catalog, report
from .allocation import DEFAULT_RULES, allocate, pad_position
from .catalog import DOCKS, EMERGENCY_SITES, GCS, MODELS
from .conflict import DEFAULT_SEPARATION, strategic_check
from .contract import COMMANDS
from .coordinator import Coordinator
from .geo import LocalFrame, polygon_area
from .planning import build_route, partition_polygon, time_parameterize
from .rbac import PermissionDenied, require, role_table
from .scenarios import builtin_scenarios, validate_scenario
from .sim import AIRBORNE, MODES, Agent, Simulation

VERSION = "0.1.0"


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    if isinstance(o, (np.floating,)):
        o = float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, float):
        return o if math.isfinite(o) else None
    return o


class CommandError(Exception):
    pass


class LiveSession:
    def __init__(self, ws: "Workspace", mission: dict, scenario: dict | None):
        self.ws = ws
        self.mission = mission
        self.scenario = scenario
        plan = mission["plan"]
        w = mission.get("weather") or {"wind_ms": 3.0, "wind_dir_deg": 300.0, "gust_ms": 1.0}
        seed = (scenario or {}).get("seed", 7)
        agents = []
        for a in plan["assignments"]:
            u = copy.deepcopy(ws.uavs[a["uav_id"]])
            d = next(x for x in DOCKS if x["id"] == u["home_dock"])
            home = tuple(a.get("home") or (d["e"], d["n"]))
            agents.append(Agent(u, home, copy.deepcopy(a["route"]), a["launch_delay_s"], None))
        zones = copy.deepcopy([z for z in ws.zones.values() if z.get("active", True) or z.get("t_from") is not None])
        for zid, rep in ((scenario or {}).get("zones_replace") or {}).items():
            zones = [copy.deepcopy(rep) if z["id"] == zid else z for z in zones]
        self.sim = Simulation(ws.frame, agents, zones, GCS[0], seed=seed, wind_ms=w["wind_ms"], wind_dir_deg=w["wind_dir_deg"],
                              gust_ms=w.get("gust_ms", 1.0),
                              events=[e for e in (scenario or {}).get("events", []) if e["type"] != "abort_request"])
        for ag in agents:
            ag.rng = self.sim.rng
        self.sim.task_sensors = {t["id"]: t["sensors"] for t in mission["tasks"]}
        self.ws_events = sorted([e for e in (scenario or {}).get("events", []) if e["type"] == "abort_request"], key=lambda e: e["t"])
        self.coord = Coordinator(DOCKS, EMERGENCY_SITES, {**ws.settings["separation"], **((scenario or {}).get("separation") or {})},
                                 ws.settings["rules"]["reserve_fraction"], mission["id"])
        self.sim.speed = float((scenario or {}).get("speed", 8.0))
        self.start_soc = {a.id: a.soc for a in agents}
        self.started_wall = None
        self.finished = False
        self.run_id = None
        self.paused_mission = False

    def tick(self, wall_dt: float, budget_s: float = 0.08):
        sim = self.sim
        if sim.status != "running":
            return
        target = min(wall_dt, 0.5) * sim.speed
        t_end = sim.t + target
        t0 = time.perf_counter()
        while sim.t < t_end - 1e-6 and sim.status == "running":
            sim.advance(min(1.0, t_end - sim.t), self.coord)
            while self.ws_events and self.ws_events[0]["t"] <= sim.t:
                ev = self.ws_events.pop(0)
                self.coord.propose_abort(sim, ev.get("params", {}).get("reason", "abort requested"))
            if self.ws.settings.get("presenter_auto_approve"):
                for p in self.coord.proposals:
                    if p["state"] == "proposed" and sim.t - p["t"] >= 20.0:
                        self.coord.apply_option(sim, p["id"], p["recommended"], "presenter mode (simulation auto-approval)")
                        self.ws._audit({"id": "presenter", "name": "Presenter mode", "role": "system", "org_id": self.ws.org_id},
                                       "proposals.approve", {"proposal_id": p["id"], "option_id": p["recommended"]}, "ok",
                                       "auto-approved in simulation presenter mode")
            if time.perf_counter() - t0 > budget_s:
                break
        if sim.status == "completed" and not self.finished:
            self.finished = True
            self.ws._finish_session(self)

    def frame(self) -> dict:
        sim, c = self.sim, self.coord
        est = sim.ground_estimates()
        aircraft = []
        for a in sim.agents.values():
            tel = sim.telemetry.get(a.id)
            e = est.get(a.id)
            aircraft.append({
                "id": a.id, "name": a.uav["name"], "model": a.uav["model"], "category": a.uav["category"],
                "payload": a.uav["payload"]["items"], "sensors": a.uav["sensors"],
                "mode": a.mode, "failsafe": a.failsafe, "telemetry": tel,
                "estimate": None if e is None else {"e": float(e["pos"][0]), "n": float(e["pos"][1]), "u": float(e["pos"][2]),
                                                    "ve": float(e["vel"][0]), "vn": float(e["vel"][1]), "sigma": round(e["sigma"], 2),
                                                    "age": round(e["age"], 1)},
                "truth": {"e": round(float(a.pos[0]), 2), "n": round(float(a.pos[1]), 2), "u": round(float(a.pos[2]), 2),
                          "hdg": round(a.heading, 1), "roll": round(a.roll, 1), "pitch": round(a.pitch, 1), "soc": round(a.soc, 4)},
                "route": [[round(w["e"], 1), round(w["n"], 1), round(w["u"], 1), w["kind"][0]] for w in a.route],
                "wp": a.idx, "task_id": a.current_task(),
                "stats": {"flight_time_s": round(a.flight_time), "distance_m": round(a.distance), "energy_wh": round(a.energy_used, 1)},
                "remaining_work": len(a.remaining_work),
            })
        alerts = sorted([x for x in c.alerts.values() if x["active"]], key=lambda x: (-["informational", "advisory", "warning", "critical"].index(x["level"]), x["t_first"]))
        return jsonable({
            "simulated": True, "label": "SIMULATION — synthetic aircraft and telemetry", "t": round(sim.t, 2),
            "status": sim.status, "speed": sim.speed, "mission_id": self.mission["id"], "mission_name": self.mission["name"],
            "mission_state": "paused" if self.paused_mission else c.mission_state,
            "scenario_id": (self.scenario or {}).get("id"), "scenario_name": (self.scenario or {}).get("name"),
            "aircraft": aircraft, "alerts": alerts, "proposals": c.proposals[-6:], "progress": getattr(c, "progress", {}),
            "events": sim.event_log[-40:], "decisions": c.decisions[-10:],
            "min_separation_m": None if c.min_sep_seen == math.inf else round(c.min_sep_seen, 1),
            "wind": {"speed_ms": sim.wind_ms, "dir_deg": sim.wind_dir, "gust_ms": sim.gust},
            "zones": [{"id": z["id"], "active": z.get("active", True), "t_from": z.get("t_from"), "t_to": z.get("t_to")} for z in sim.zones],
            "run_id": self.run_id, "presenter_auto_approve": bool(self.ws.settings.get("presenter_auto_approve")),
            "link_stats": {k: {"sent": v[0], "received": v[1]} for k, v in sim.tel_count.items()},
        })


class Workspace:
    def __init__(self, org_id: str = "org-demo", seed_demo: bool = True):
        self.org_id = org_id
        o = catalog.SITE_ORIGIN
        self.frame = LocalFrame(o["lat"], o["lon"], o["alt"])
        self.journal: list[dict] = []
        self.audit: list[dict] = []
        self.uavs: dict[str, dict] = {}
        self.zones: dict[str, dict] = {}
        self.missions: dict[str, dict] = {}
        self.scenarios: dict[str, dict] = {}
        self.runs: dict[str, dict] = {}
        self.reports: dict[str, dict] = {}
        self.maintenance: dict[str, dict] = {}
        self.incidents: dict[str, dict] = {}
        self.history: list[dict] = []
        self.operators = {o["id"]: dict(o) for o in catalog.OPERATORS}
        self.session: LiveSession | None = None
        self.counter = 0
        self.settings = {
            "operating_mode": "simulation", "separation": dict(DEFAULT_SEPARATION), "rules": dict(DEFAULT_RULES),
            "presenter_auto_approve": False, "regulatory_profile": {"country": "AE", "status": "unverified",
                                                                     "note": "Operational mode is disabled until a verified regulatory profile and operation authorisation are configured. See docs/REGULATORY.md."},
            "data_sources": [{"name": catalog.DATA_SOURCE, "kind": "synthetic", "timestamp": catalog.DATA_TIMESTAMP,
                              "covers": "fleet, facility, zones"},
                             {"name": "Live airspace feed", "kind": "not connected", "timestamp": None,
                              "covers": "none — SkyGrid shows only aircraft it knows about"}],
            "contingency_defaults": {"link_loss": "hold_then_rth", "link_loss_timeout_s": 5.0, "hold_s": 20.0, "low_battery_rtl_soc": 0.12},
        }
        if seed_demo:
            self._seed()

    # ------------------------------------------------------------ infrastructure
    def _seed(self):
        for u in catalog.make_fleet():
            self.uavs[u["id"]] = u
        for z in catalog.ZONES:
            self.zones[z["id"]] = {**copy.deepcopy(z), "source": "operator-defined (synthetic demo)",
                                   "source_timestamp": catalog.DATA_TIMESTAMP, "org_id": self.org_id}
        for s in builtin_scenarios():
            self.scenarios[s["id"]] = s
        for m in catalog.make_maintenance():
            self.maintenance[m["id"]] = m
        self.history = catalog.make_history()
        self.incidents["INC-001"] = {"id": "INC-001", "date": "2026-10-28", "uav_id": "HH-009", "severity": "minor",
                                     "kind": "hard landing", "summary": "Hard landing in gusts on recovery; propeller replaced (synthetic)",
                                     "status": "closed", "synthetic": True}

    def _id(self, prefix: str) -> str:
        self.counter += 1
        return f"{prefix}-{int(time.time()) % 100000:05d}{self.counter:03d}"

    def _change(self, entity: str, op: str, obj_id: str, data=None):
        self.journal.append({"entity": entity, "op": op, "id": obj_id, "data": jsonable(data), "org_id": self.org_id})

    def drain_journal(self) -> list[dict]:
        j, self.journal = self.journal, []
        return j

    def _audit(self, actor, command, args, result, detail=""):
        entry = {"id": len(self.audit) + 1, "time": now_iso(), "actor_id": actor.get("id"), "actor": actor.get("name"),
                 "role": actor.get("role"), "org_id": self.org_id, "command": command,
                 "args": {k: v for k, v in (args or {}).items() if k not in ("password",) and not isinstance(v, (list, dict))},
                 "result": result, "detail": detail[:300]}
        self.audit.append(entry)
        self._change("audit", "insert", str(entry["id"]), entry)

    def call(self, command: str, args: dict | None, actor: dict):
        args = args or {}
        if command not in COMMANDS:
            raise CommandError(f"unknown command {command}")
        perm, mutating = COMMANDS[command]
        if actor.get("org_id") not in (self.org_id, None) and actor.get("role") != "super_admin":
            raise PermissionDenied("actor belongs to another organisation")
        try:
            require(actor, perm)
        except PermissionDenied as e:
            self._audit(actor, command, args, "denied", str(e))
            raise
        fn = getattr(self, "cmd_" + command.replace(".", "_"))
        try:
            out = fn(actor=actor, **args)
        except (CommandError, ValueError, KeyError) as e:
            if mutating:
                self._audit(actor, command, args, "error", str(e))
            raise CommandError(str(e)) from e
        if mutating:
            self._audit(actor, command, args, "ok")
        return jsonable(out)

    # ------------------------------------------------------------ read models
    def cmd_me(self, actor):
        return {"actor": actor, "roles": role_table(), "version": VERSION, "org_id": self.org_id,
                "operating_mode": self.settings["operating_mode"]}

    def cmd_site_get(self, actor):
        s = catalog.site_payload(self.frame)
        s["zones"] = [self._zone_out(z) for z in self.zones.values()]
        s["models"] = MODELS
        s["sensor_labels"] = catalog.SENSOR_LABELS
        return s

    def _zone_out(self, z):
        return {**z, "ring_geo": self.frame.ring_to_geo(z["ring"]), "area_m2": round(polygon_area(z["ring"]))}

    def cmd_dashboard_summary(self, actor):
        return analytics.dashboard(self)

    def cmd_fleet_list(self, actor, q: str = "", category: str = "", status: str = ""):
        out = []
        live = {}
        if self.session:
            for a in self.session.sim.agents.values():
                live[a.id] = a.mode
        for u in self.uavs.values():
            if q and q.lower() not in (u["id"] + u["name"] + u["model"] + " ".join(u["sensors"])).lower():
                continue
            if category and u["category"] != category:
                continue
            if status and u["status"] != status:
                continue
            out.append({**u, "live_mode": live.get(u["id"])})
        return out

    def cmd_fleet_get(self, actor, uav_id: str):
        u = self.uavs.get(uav_id)
        if not u:
            raise CommandError(f"UAV {uav_id} not found")
        mx = [m for m in self.maintenance.values() if m["uav_id"] == uav_id]
        flights = [h for h in self.history if uav_id in h["uavs"]][-10:]
        return {**u, "spec": MODELS[u["model_code"]], "maintenance_records": mx, "recent_flights": flights,
                "operator": self.operators.get(u.get("operator_id"))}

    def cmd_fleet_compare(self, actor, uav_ids: list[str]):
        rows = []
        for i in uav_ids:
            u = self.uavs[i]
            m = MODELS[u["model_code"]]
            rows.append({"id": i, "name": u["name"], "model": u["model"], "category": u["category"], "cruise_ms": m["cruise_ms"],
                         "endurance_min": u["endurance_min"], "range_km": u["range_km"], "battery_wh": u["battery"]["capacity_wh"],
                         "battery_health": u["battery"]["health"], "soc": u["battery"]["soc"], "mtom_kg": u["mtom_kg"],
                         "payload_max_kg": m["payload_max_kg"], "sensors": u["sensors"], "flight_hours": u["maintenance"]["flight_hours"],
                         "max_wind_ms": m["max_wind_ms"], "status": u["status"]})
        return rows

    def _validate_uav(self, u: dict):
        if u.get("model_code") not in MODELS:
            raise CommandError(f"unknown model {u.get('model_code')}; available: {', '.join(MODELS)}")
        if not u.get("id") or not u.get("name"):
            raise CommandError("id and name are required")
        bad = [s for s in u.get("sensors", []) if s not in catalog.SENSOR_LABELS]
        if bad:
            raise CommandError(f"unknown sensors {bad}")
        b = u.get("battery", {})
        if not (0 <= b.get("soc", 1) <= 1 and 0 < b.get("health", 1) <= 1):
            raise CommandError("battery soc and health must be fractions 0..1")
        if u.get("home_dock") not in [d["id"] for d in DOCKS]:
            raise CommandError("home_dock must be one of " + ", ".join(d["id"] for d in DOCKS))

    def cmd_fleet_create(self, actor, uav: dict):
        uid = uav.get("id") or f"HH-{100 + len(self.uavs) + 1:03d}"
        if uid in self.uavs:
            raise CommandError(f"UAV {uid} already exists")
        m = MODELS.get(uav.get("model_code", ""))
        if not m:
            raise CommandError("model_code required")
        base = {
            "id": uid, "name": uav.get("name") or uid, "model_code": uav["model_code"], "model": m["model"], "manufacturer": m["manufacturer"],
            "category": m["category"], "roles": list(m["roles"]), "serial": uav.get("serial") or f"SYN-{uid}",
            "flight_controller": uav.get("flight_controller") or m["flight_controller"], "firmware": uav.get("firmware") or "sim",
            "navigation": m["navigation"], "gnss": m["gnss"], "comms": m["comms"],
            "battery": {"chemistry": "LiPo", "cells": m["cells"], "capacity_wh": m["battery_wh"], "health": 1.0, "soc": 1.0, "cycles": 0,
                        **(uav.get("battery") or {})},
            "payload": {"mass_kg": 0.35 * len(uav.get("sensors", [])), "items": [catalog.SENSOR_LABELS.get(s, s) for s in uav.get("sensors", [])]},
            "sensors": uav.get("sensors", ["rgb"]), "mtom_kg": m["mtom_kg"], "endurance_min": m["endurance_min"], "range_km": m["range_km"],
            "maintenance": {"status": "ok", "flight_hours": 0.0, "next_service_hours": 50.0},
            "registration": {"reference": uav.get("registration_ref") or f"SYNTHETIC-REG-{uid}", "authority": uav.get("authority") or "(not registered — synthetic)",
                             "documents_valid_until": uav.get("documents_valid_until")},
            "operator_id": uav.get("operator_id") or "OP-1", "status": uav.get("status", "available"),
            "home_dock": uav.get("home_dock", "D1"), "contingency": dict(self.settings["contingency_defaults"]),
            "synthetic": True,
        }
        self._validate_uav(base)
        self.uavs[uid] = base
        self._change("uav", "upsert", uid, base)
        return base

    def cmd_fleet_update(self, actor, uav_id: str, patch: dict):
        u = self.uavs.get(uav_id)
        if not u:
            raise CommandError(f"UAV {uav_id} not found")
        locked = {"id", "model", "manufacturer", "category"}
        new = copy.deepcopy(u)
        for k, v in patch.items():
            if k in locked:
                continue
            if isinstance(v, dict) and isinstance(new.get(k), dict):
                new[k].update(v)
            else:
                new[k] = v
        if "sensors" in patch:
            new["payload"]["items"] = [catalog.SENSOR_LABELS.get(s, s) for s in new["sensors"]]
            new["payload"]["mass_kg"] = round(0.35 * len(new["sensors"]), 2)
        self._validate_uav(new)
        self.uavs[uav_id] = new
        self._change("uav", "upsert", uav_id, new)
        return new

    def cmd_fleet_set_status(self, actor, uav_id: str, status: str, note: str = ""):
        if status not in ("available", "standby", "maintenance", "disabled"):
            raise CommandError("status must be available | standby | maintenance | disabled")
        if actor["role"] == "maintenance_engineer" and status not in ("maintenance", "available"):
            raise PermissionDenied("maintenance engineers can only move aircraft into or out of maintenance")
        u = self.uavs[uav_id]
        u["status"] = status
        if status == "maintenance":
            u["maintenance"]["status"] = "in_maintenance"
        elif u["maintenance"]["status"] == "in_maintenance":
            u["maintenance"]["status"] = "ok"
        self._change("uav", "upsert", uav_id, u)
        return u

    def cmd_operators_list(self, actor):
        return list(self.operators.values())

    # ------------------------------------------------------------ zones
    def cmd_zones_list(self, actor):
        return [self._zone_out(z) for z in self.zones.values()]

    def _check_zone(self, z):
        if z.get("rule") not in ("no_fly", "keep_in", "caution"):
            raise CommandError("rule must be no_fly, keep_in or caution")
        if len(z.get("ring", [])) < 3:
            raise CommandError("zone polygon needs at least 3 points")
        if not (z.get("alt_min", 0) < z.get("alt_max", 120)):
            raise CommandError("alt_min must be below alt_max")

    def cmd_zones_create(self, actor, zone: dict):
        z = {"id": zone.get("id") or self._id("Z"), "name": zone.get("name", "Operator zone"), "kind": zone.get("kind", "restricted"),
             "ring": zone.get("ring") or [], "alt_min": float(zone.get("alt_min", 0)), "alt_max": float(zone.get("alt_max", 120)),
             "rule": zone.get("rule", "no_fly"), "active": bool(zone.get("active", True)),
             "source": zone.get("source") or f"operator-defined by {actor.get('name')}", "source_timestamp": now_iso(), "org_id": self.org_id}
        if zone.get("ring_geo"):
            z["ring"] = [list(self.frame.to_enu(p[1], p[0])[:2]) for p in zone["ring_geo"]]
            if z["ring"][0] == z["ring"][-1]:
                z["ring"] = z["ring"][:-1]
        self._check_zone(z)
        self.zones[z["id"]] = z
        self._change("zone", "upsert", z["id"], z)
        return self._zone_out(z)

    def cmd_zones_update(self, actor, zone_id: str, patch: dict):
        z = self.zones[zone_id]
        z.update({k: v for k, v in patch.items() if k in ("name", "active", "alt_min", "alt_max", "rule", "ring")})
        z["source_timestamp"] = now_iso()
        self._check_zone(z)
        self._change("zone", "upsert", zone_id, z)
        return self._zone_out(z)

    def cmd_zones_delete(self, actor, zone_id: str):
        if zone_id == "Z-OPS":
            raise CommandError("the operational area boundary cannot be deleted")
        self.zones.pop(zone_id)
        self._change("zone", "delete", zone_id)
        return {"deleted": zone_id}

    # ------------------------------------------------------------ missions
    def cmd_missions_list(self, actor):
        return [self._mission_summary(m) for m in sorted(self.missions.values(), key=lambda m: m["created_at"], reverse=True)]

    def _mission_summary(self, m):
        return {k: m.get(k) for k in ("id", "name", "type", "objective", "status", "mode", "uav_ids", "created_at", "created_by",
                                      "scenario_id", "run_id", "report_id")} | {
            "task_count": len(m["tasks"]), "assigned": len(m["plan"]["assignments"]) if m.get("plan") else 0}

    def cmd_missions_get(self, actor, mission_id: str):
        m = self.missions.get(mission_id)
        if not m:
            raise CommandError(f"mission {mission_id} not found")
        return m

    def _tasks_from(self, spec: dict) -> list[dict]:
        tasks = []
        areas = {a["id"]: a for a in catalog.INSPECTION_AREAS}
        for aid in spec.get("area_ids", []):
            a = copy.deepcopy(areas[aid])
            tasks.append(a)
        for i, a in enumerate(spec.get("areas", [])):
            t = {"id": a.get("id") or f"C{i + 1}", "name": a.get("name", f"Custom area {i + 1}"), "ring": a["ring"],
                 "pattern": a.get("pattern", "lawnmower"), "params": a.get("params") or {"spacing": 40.0, "alt": 45.0},
                 "sensors": a.get("sensors", ["rgb"]), "priority": a.get("priority", 2), "objective": a.get("objective", "")}
            tasks.append(t)
        cov = spec.get("coverage")
        if cov:
            parts = partition_polygon(cov["ring"], int(cov.get("k", 4)))
            for i, r in enumerate(parts):
                tasks.append({"id": f"S{i + 1}", "name": f"Survey strip {i + 1}", "ring": r, "pattern": "lawnmower",
                              # adjacent strips alternate altitude by 15 m so neighbours stay vertically separated
                              "params": {"spacing": cov.get("spacing", 60.0), "alt": cov.get("alt", 60.0) + 15.0 * (i % 2), "axis": cov.get("axis", "x")},
                              "sensors": cov.get("sensors", ["rgb"]), "priority": 2, "objective": "Coverage strip",
                              "area_m2": round(polygon_area(r))})
        for t in tasks:
            t["ring_geo"] = self.frame.ring_to_geo(t["ring"])
        return tasks

    def cmd_missions_create(self, actor, mission: dict):
        if mission.get("mode", "simulation") != "simulation":
            raise CommandError("only simulation and planning missions are available: operational mode requires a verified "
                               "regulatory profile, an operation authorisation and a connected, authorised hardware adapter")
        mid = self._id("M")
        tasks = self._tasks_from(mission)
        if not tasks and not mission.get("assignments"):
            raise CommandError("mission needs at least one area, coverage polygon or explicit assignment")
        uav_ids = mission.get("uav_ids") or [u["id"] for u in self.uavs.values() if u["status"] == "available"]
        m = {"id": mid, "name": mission.get("name") or "Untitled mission", "type": mission.get("type", "industrial_inspection"),
             "objective": mission.get("objective", ""), "status": "draft", "mode": "simulation", "tasks": tasks, "uav_ids": uav_ids,
             "constraints": mission.get("constraints", {}), "rules": mission.get("rules", {}), "weather": mission.get("weather"),
             "assignments_explicit": mission.get("assignments"), "plan": None, "approvals": [], "created_at": now_iso(),
             "created_by": actor.get("name"), "scenario_id": mission.get("scenario_id"), "run_id": None, "report_id": None,
             "timeline": [{"time": now_iso(), "event": "created", "by": actor.get("name")}]}
        self.missions[mid] = m
        self._change("mission", "upsert", mid, m)
        return m

    def cmd_missions_plan(self, actor, mission_id: str):
        m = self.missions[mission_id]
        if m["status"] not in ("draft", "proposed", "approved"):
            raise CommandError(f"mission is {m['status']}; only draft/proposed missions can be re-planned")
        uavs = [self.uavs[i] for i in m["uav_ids"] if i in self.uavs]
        wind = (m.get("weather") or {}).get("wind_ms", 3.0)
        rules = {**self.settings["rules"], **(m.get("rules") or {})}
        zones = list(self.zones.values())
        if m.get("scenario_id") and self.scenarios.get(m["scenario_id"], {}).get("zones_replace"):
            rep = self.scenarios[m["scenario_id"]]["zones_replace"]
            zones = [rep.get(z["id"], z) for z in zones]
        if m.get("assignments_explicit"):
            plan = self._explicit_plan(m, rules, zones)
        else:
            plan = allocate(uavs, m["tasks"], DOCKS, rules, wind, zones=zones)
        routes = {}
        for a in plan["assignments"]:
            spec = MODELS[self.uavs[a["uav_id"]]["model_code"]]
            d = next(x for x in DOCKS if x["id"] == self.uavs[a["uav_id"]]["home_dock"])
            h = a.get("home") or (d["e"], d["n"])
            routes[a["uav_id"]] = time_parameterize(spec, a["route"], a["launch_delay_s"], start=(h[0], h[1], 0.0))
        plan["strategic"] = strategic_check(routes, zones, self.settings["separation"])
        plan["compatibility"] = self._compatibility(m, uavs)
        plan["generated_at"] = now_iso()
        plan["generated_by"] = actor.get("name")
        m["plan"] = plan
        m["status"] = "proposed"
        m["timeline"].append({"time": now_iso(), "event": "plan proposed", "by": actor.get("name"),
                              "detail": f"{len(plan['assignments'])} aircraft, {len(plan['unassigned'])} unassigned task(s), "
                                        f"strategic check {'clear' if plan['strategic']['ok'] else 'has conflicts'}"})
        self._change("mission", "upsert", mission_id, m)
        return m

    def _compatibility(self, m, uavs):
        need = sorted({s for t in m["tasks"] for s in t["sensors"]})
        rows = []
        for u in uavs:
            rows.append({"uav_id": u["id"], "status": u["status"], "maintenance": u["maintenance"]["status"],
                         "soc": u["battery"]["soc"], "health": u["battery"]["health"],
                         "sensors": {s: s in u["sensors"] for s in need}})
        return {"required_sensors": need, "rows": rows}

    def _explicit_plan(self, m, rules, zones=None):
        assignments = []
        k = 0
        for a in m["assignments_explicit"]:
            u = self.uavs[a["uav_id"]]
            spec = MODELS[u["model_code"]]
            d0 = next(x for x in DOCKS if x["id"] == u["home_dock"])
            hx, hy = pad_position(d0, k)
            d = {"id": d0["id"], "e": hx, "n": hy}
            alt = a["waypoints"][0][2]
            tid = f"R-{u['id']}"
            if not any(t["id"] == tid for t in m["tasks"]):
                m["tasks"].append({"id": tid, "name": f"Route {u['id']}", "ring": [[p[0], p[1]] for p in a["waypoints"]],
                                   "pattern": "waypoints", "params": {"points": a["waypoints"]}, "sensors": [], "priority": 1,
                                   "objective": "operator-defined route", "ring_geo": self.frame.ring_to_geo([[p[0], p[1]] for p in a["waypoints"]])})
            wps = [{"e": d["e"], "n": d["n"], "u": alt, "kind": "takeoff", "task_id": None, "speed": spec["climb_ms"]}]
            wps += [{"e": p[0], "n": p[1], "u": p[2], "kind": "inspect", "task_id": tid, "speed": spec["cruise_ms"], "idx": i}
                    for i, p in enumerate(a["waypoints"])]
            wps += [{"e": d["e"], "n": d["n"], "u": alt, "kind": "transit", "task_id": None, "speed": spec["cruise_ms"]},
                    {"e": d["e"], "n": d["n"], "u": 0.0, "kind": "land", "task_id": None, "speed": spec["descent_ms"]}]
            from .planning import apply_detours, estimate
            wps = apply_detours(wps, zones, start=(d["e"], d["n"], alt))
            est = estimate(spec, wps, payload_kg=u["payload"]["mass_kg"])
            assignments.append({"uav_id": u["id"], "task_ids": [tid], "transit_alt": alt, "launch_delay_s": a.get("launch_t", 0.0),
                                "dock": d["id"], "home": [hx, hy], "route": wps, "estimate": {kk: round(v, 1) for kk, v in est.items()},
                                "energy_margin": round((u["battery"]["soc"] * u["battery"]["capacity_wh"] * u["battery"]["health"] - est["energy_wh"]) /
                                                       (u["battery"]["capacity_wh"] * u["battery"]["health"]), 3),
                                "reasons": ["operator-defined route (no optimisation)"], "alternatives": []})
            k += 1
        return {"method": "explicit operator-defined routes", "rules": rules, "wind_ms": 0, "rounds": 0, "assignments": assignments,
                "unassigned": [], "matrix": None, "runtime_ms": 0, "total_energy_wh": round(sum(a["estimate"]["energy_wh"] for a in assignments), 1),
                "makespan_s": round(max(a["estimate"]["time_s"] + a["launch_delay_s"] for a in assignments))}

    def cmd_missions_approve(self, actor, mission_id: str, note: str = ""):
        m = self.missions[mission_id]
        if m["status"] != "proposed" or not m.get("plan"):
            raise CommandError("only a proposed plan can be approved")
        if not m["plan"]["assignments"]:
            raise CommandError("the plan assigns no aircraft")
        m["status"] = "approved"
        m["approvals"].append({"by": actor.get("name"), "role": actor.get("role"), "time": now_iso(), "note": note,
                               "mode": m["mode"], "strategic_ok": m["plan"]["strategic"]["ok"]})
        m["timeline"].append({"time": now_iso(), "event": "plan approved", "by": actor.get("name"), "detail": note})
        self._change("mission", "upsert", mission_id, m)
        return m

    def cmd_missions_execute(self, actor, mission_id: str, start: bool = True):
        m = self.missions[mission_id]
        if m["status"] != "approved":
            raise CommandError("a mission must be approved by an authorised operator before execution")
        if m["mode"] != "simulation":
            raise CommandError("only simulated execution is available in this release")
        if self.session and self.session.sim.status == "running":
            raise CommandError(f"simulation of {self.session.mission['name']} is running; stop or reset it first")
        sc = self.scenarios.get(m.get("scenario_id")) if m.get("scenario_id") else None
        self.session = LiveSession(self, m, sc)
        m["status"] = "executing"
        m["timeline"].append({"time": now_iso(), "event": "simulated execution started", "by": actor.get("name")})
        self._change("mission", "upsert", mission_id, m)
        if start:
            self.session.sim.status = "running"
            self.session.sim.paused = False
        return {"mission_id": mission_id, "frame": self.session.frame()}

    def cmd_missions_cancel(self, actor, mission_id: str):
        m = self.missions[mission_id]
        if m["status"] in ("executing",):
            raise CommandError("abort a running mission from Mission Control instead")
        m["status"] = "cancelled"
        self._change("mission", "upsert", mission_id, m)
        return m

    # ------------------------------------------------------------ scenarios & simulation
    def cmd_scenarios_list(self, actor):
        return list(self.scenarios.values())

    def cmd_scenarios_save(self, actor, scenario: dict):
        s = copy.deepcopy(scenario)
        s["id"] = s.get("id") or self._id("SCN")
        if s["id"] in self.scenarios and self.scenarios[s["id"]].get("builtin"):
            s["id"] = self._id("SCN")
        s["builtin"] = False
        s.setdefault("events", [])
        s.setdefault("weather", {"wind_ms": 3.0, "wind_dir_deg": 300.0, "gust_ms": 1.0})
        s.setdefault("rules", {})
        s.setdefault("separation", {})
        s.setdefault("seed", 100)
        s.setdefault("speed", 8.0)
        errs = validate_scenario(s, set(self.uavs))
        if errs:
            raise CommandError("; ".join(errs))
        s["saved_by"] = actor.get("name")
        s["saved_at"] = now_iso()
        self.scenarios[s["id"]] = s
        self._change("scenario", "upsert", s["id"], s)
        return s

    def cmd_scenarios_delete(self, actor, scenario_id: str):
        s = self.scenarios.get(scenario_id)
        if not s or s.get("builtin"):
            raise CommandError("built-in scenarios cannot be deleted")
        self.scenarios.pop(scenario_id)
        self._change("scenario", "delete", scenario_id)
        return {"deleted": scenario_id}

    def cmd_sim_load_scenario(self, actor, scenario_id: str, auto_execute: bool = False):
        s = self.scenarios.get(scenario_id)
        if not s:
            raise CommandError(f"scenario {scenario_id} not found")
        if self.session and self.session.sim.status == "running":
            self.session.sim.status = "stopped"
        mspec = {**s["mission"], "uav_ids": s["uav_ids"], "scenario_id": s["id"], "weather": s.get("weather"),
                 "rules": s.get("rules"), "assignments": s.get("assignments")}
        m = self.cmd_missions_create(actor, mspec)
        m = self.cmd_missions_plan(actor, m["id"])
        if auto_execute:
            self.cmd_missions_approve(actor, m["id"], note=f"scenario quick-run: {s['name']}")
            self.cmd_missions_execute(actor, m["id"])
        return {"mission": self.missions[m["id"]], "scenario": s}

    def _need_session(self):
        if not self.session:
            raise CommandError("no simulation loaded")
        return self.session

    def cmd_sim_state(self, actor):
        return self.session.frame() if self.session else None

    def cmd_sim_control(self, actor, action: str, speed: float | None = None):
        s = self._need_session()
        sim = s.sim
        if action == "start" or action == "resume":
            if sim.status in ("ready", "paused"):
                sim.status = "running"
        elif action == "pause":
            if sim.status == "running":
                sim.status = "paused"
        elif action == "speed":
            sim.speed = float(min(max(speed or 1.0, 0.25), 30.0))
        elif action == "reset":
            m = s.mission
            m["status"] = "approved"
            self.session = LiveSession(self, m, s.scenario)
            m["status"] = "executing"
            m["timeline"].append({"time": now_iso(), "event": "simulation reset", "by": actor.get("name")})
        elif action == "stop":
            sim.status = "stopped"
            s.mission["status"] = "approved"
        else:
            raise CommandError("action must be start | pause | resume | speed | reset | stop")
        return self.session.frame()

    def cmd_sim_inject(self, actor, type: str, uav_id: str | None = None, params: dict | None = None):
        s = self._need_session()
        if type == "abort_request":
            s.coord.propose_abort(s.sim, (params or {}).get("reason", "operator request"))
        else:
            if uav_id and uav_id not in s.sim.agents:
                raise CommandError(f"{uav_id} is not part of this simulation")
            s.sim.inject({"t": s.sim.t, "type": type, "uav_id": uav_id, "params": params or {}})
        return s.frame()

    def cmd_sim_recording(self, actor, run_id: str | None = None):
        if run_id:
            r = self.runs.get(run_id)
            if not r:
                raise CommandError("run not found")
            return {"run_id": run_id, "recording": r["recording"], "events": r["events"], "routes": r["routes"], "origin": catalog.SITE_ORIGIN}
        s = self._need_session()
        return {"run_id": s.run_id, "recording": s.sim.recording, "events": s.sim.event_log,
                "routes": {a.id: [[w["e"], w["n"], w["u"]] for w in a.route] for a in s.sim.agents.values()}, "origin": catalog.SITE_ORIGIN}

    def cmd_sim_pause_mission(self, actor):
        s = self._need_session()
        for a in s.sim.agents.values():
            if a.mode in ("transit", "mission", "takeoff"):
                a.pre_pause = a.mode
                a.mode = "paused"
                a.log(s.sim.t, "hold", "mission paused by operator: holding position")
            elif a.mode == "parked" and a.route:
                a.launch_t = math.inf
                a.pre_pause = "parked"
        s.paused_mission = True
        s.sim.log("decision", f"mission paused by {actor.get('name')}", None, "advisory")
        return s.frame()

    def cmd_sim_resume_mission(self, actor):
        s = self._need_session()
        for a in s.sim.agents.values():
            if getattr(a, "pre_pause", None):
                if a.pre_pause == "parked":
                    a.launch_t = s.sim.t + 2.0
                elif a.mode == "paused":
                    a.mode = a.pre_pause
                a.pre_pause = None
        s.paused_mission = False
        s.sim.log("decision", f"mission resumed by {actor.get('name')}", None, "info")
        return s.frame()

    def cmd_sim_abort_mission(self, actor, reason: str = "operator abort"):
        s = self._need_session()
        s.coord.propose_abort(s.sim, reason)
        return s.frame()

    def cmd_proposals_approve(self, actor, proposal_id: str, option_id: str):
        s = self._need_session()
        p = s.coord.apply_option(s.sim, proposal_id, option_id, actor.get("name"))
        if p["type"] == "abort":
            s.paused_mission = False
            s.mission["timeline"].append({"time": now_iso(), "event": "abort approved", "by": actor.get("name")})
        s.mission["timeline"].append({"time": now_iso(), "event": f"proposal {proposal_id} approved ({option_id})", "by": actor.get("name")})
        return s.frame()

    def cmd_proposals_reject(self, actor, proposal_id: str, note: str = ""):
        s = self._need_session()
        s.coord.reject(s.sim, proposal_id, actor.get("name"), note)
        return s.frame()

    def cmd_alerts_ack(self, actor, alert_id: str):
        s = self._need_session()
        a = s.coord.alerts.get(alert_id)
        if not a:
            raise CommandError("alert not found")
        a["acknowledged_by"] = actor.get("name")
        a["acknowledged_at"] = round(s.sim.t, 1)
        return a

    def tick(self, wall_dt: float):
        if self.session:
            self.session.tick(wall_dt)

    def _finish_session(self, s: LiveSession):
        rid = self._id("RUN")
        s.run_id = rid
        rep = report.build(self, s)
        rep["id"] = self._id("RPT")
        rep["run_id"] = rid
        self.reports[rep["id"]] = rep
        sim = s.sim
        run = {"id": rid, "mission_id": s.mission["id"], "scenario_id": (s.scenario or {}).get("id"), "ended_at": now_iso(),
               "duration_s": round(sim.t, 1), "outcome": rep["summary"]["outcome"], "report_id": rep["id"],
               "metrics": rep["summary"], "recording": sim.recording, "events": sim.event_log,
               "routes": {a.id: [[w["e"], w["n"], w["u"]] for w in a.route] for a in sim.agents.values()}, "simulated": True}
        self.runs[rid] = run
        m = s.mission
        m["status"] = "completed" if rep["summary"]["outcome"].startswith("completed") else rep["summary"]["outcome"]
        m["run_id"] = rid
        m["report_id"] = rep["id"]
        m["timeline"].append({"time": now_iso(), "event": f"simulation finished: {rep['summary']['outcome']}", "by": "system"})
        for a in sim.agents.values():
            u = self.uavs.get(a.id)
            if u:
                u["maintenance"]["flight_hours"] = round(u["maintenance"]["flight_hours"] + a.flight_time / 3600.0, 2)
                self._change("uav", "upsert", a.id, u)
        self._change("mission", "upsert", m["id"], m)
        self._change("run", "upsert", rid, {k: v for k, v in run.items() if k != "recording"})
        self._change("report", "upsert", rep["id"], rep)

    # ------------------------------------------------------------ runs, reports, maintenance, analytics
    def cmd_runs_list(self, actor):
        return [{k: v for k, v in r.items() if k not in ("recording", "events", "routes")} for r in self.runs.values()]

    def cmd_runs_get(self, actor, run_id: str):
        r = self.runs[run_id]
        return {k: v for k, v in r.items() if k != "recording"}

    def cmd_reports_list(self, actor):
        return [{"id": r["id"], "title": r["title"], "generated_at": r["generated_at"], "mission_id": r["mission"]["id"],
                 "outcome": r["summary"]["outcome"], "run_id": r.get("run_id")} for r in self.reports.values()]

    def cmd_reports_get(self, actor, report_id: str, fmt: str = "json"):
        r = self.reports[report_id]
        if fmt == "markdown":
            return {"content": report.to_markdown(r), "mime": "text/markdown"}
        if fmt == "html":
            return {"content": report.to_html(r), "mime": "text/html"}
        if fmt == "csv_events":
            return {"content": report.events_csv(r), "mime": "text/csv"}
        if fmt == "csv_aircraft":
            return {"content": report.aircraft_csv(r), "mime": "text/csv"}
        return r

    def cmd_reports_generate(self, actor, kind: str = "fleet_utilization"):
        if kind == "current" and self.session:
            rep = report.build(self, self.session)
        elif kind == "fleet_utilization":
            rep = report.fleet_report(self)
        else:
            raise CommandError("kind must be current | fleet_utilization")
        rep["id"] = self._id("RPT")
        self.reports[rep["id"]] = rep
        self._change("report", "upsert", rep["id"], rep)
        return rep

    def cmd_maintenance_list(self, actor, uav_id: str = ""):
        return [m for m in self.maintenance.values() if not uav_id or m["uav_id"] == uav_id]

    def cmd_maintenance_create(self, actor, record: dict):
        if record.get("uav_id") not in self.uavs:
            raise CommandError("unknown UAV")
        rid = self._id("MX")
        r = {"id": rid, "uav_id": record["uav_id"], "kind": record.get("kind", "Inspection"), "status": record.get("status", "scheduled"),
             "date": record.get("date") or now_iso()[:10], "notes": record.get("notes", ""), "engineer": actor.get("name"),
             "hours_at_service": self.uavs[record["uav_id"]]["maintenance"]["flight_hours"]}
        self.maintenance[rid] = r
        self._change("maintenance", "upsert", rid, r)
        return r

    def cmd_maintenance_update(self, actor, record_id: str, patch: dict):
        r = self.maintenance[record_id]
        r.update({k: v for k, v in patch.items() if k in ("status", "notes", "date", "kind")})
        if r["status"] == "completed":
            u = self.uavs[r["uav_id"]]
            if u["maintenance"]["status"] in ("due_soon", "in_maintenance") and not any(
                    m["status"] in ("open", "scheduled") and m["uav_id"] == u["id"] for m in self.maintenance.values()):
                u["maintenance"]["status"] = "ok"
                u["maintenance"]["next_service_hours"] = round(u["maintenance"]["flight_hours"] + 50.0, 1)
                if u["status"] == "maintenance":
                    u["status"] = "available"
                self._change("uav", "upsert", u["id"], u)
        self._change("maintenance", "upsert", record_id, r)
        return r

    def cmd_incidents_list(self, actor):
        return list(self.incidents.values())

    def cmd_analytics_summary(self, actor):
        return analytics.summary(self)

    def cmd_assistant_ask(self, actor, question: str):
        return assistant.answer(self, question)

    def cmd_settings_get(self, actor):
        return {**self.settings, "roles": role_table()}

    def cmd_settings_update(self, actor, patch: dict):
        if "operating_mode" in patch and patch["operating_mode"] != "simulation":
            raise CommandError("operational mode cannot be enabled from settings in this release")
        for k in ("separation", "rules", "contingency_defaults"):
            if k in patch:
                self.settings[k].update(patch[k])
        if "presenter_auto_approve" in patch:
            self.settings["presenter_auto_approve"] = bool(patch["presenter_auto_approve"])
        s = self.settings["separation"]
        if s["horizontal_m"] < 5 or s["vertical_m"] < 3:
            raise CommandError("separation minima too small")
        self._change("settings", "upsert", self.org_id, self.settings)
        return self.settings

    def cmd_audit_list(self, actor, limit: int = 200):
        return list(reversed(self.audit[-limit:]))

    def cmd_hardware_list(self, actor):
        return {"adapters": [
            {"id": "sim", "name": "Simulated telemetry source", "status": "active", "kind": "simulation"},
            {"id": "mavlink-udp", "name": "MAVLink v2 over UDP (PX4 / ArduPilot)", "status": "disabled", "kind": "hardware",
             "note": "Read-only telemetry ingestion. Server edition only; requires SKYGRID_HARDWARE_ENABLED=1 and operator authorisation. Not tested with real hardware."},
            {"id": "mavsdk", "name": "MAVSDK gRPC bridge", "status": "not implemented", "kind": "hardware",
             "note": "Integration boundary documented in docs/HARDWARE.md"},
        ], "uplink": "none — SkyGrid does not send commands to aircraft in this release"}
