"""Role-based access control: roles -> permissions. Checked on every command (core and API)."""

from __future__ import annotations

ALL = {"read", "fleet.write", "fleet.status", "zone.write", "mission.plan", "mission.approve", "mission.execute",
       "scenario.write", "sim.control", "proposal.approve", "report.generate", "maintenance.write", "settings.write",
       "audit.read", "users.manage", "hardware.connect", "org.manage"}

ROLES: dict[str, dict] = {
    "super_admin": {"label": "Super Administrator", "perms": ALL},
    "org_admin": {"label": "Organization Administrator", "perms": ALL - {"org.manage"}},
    "fleet_manager": {"label": "Fleet Manager", "perms": {"read", "fleet.write", "fleet.status", "mission.plan", "report.generate",
                                                          "maintenance.write", "audit.read", "scenario.write", "sim.control"}},
    "mission_planner": {"label": "Mission Planner", "perms": {"read", "mission.plan", "zone.write", "scenario.write", "sim.control",
                                                             "report.generate"}},
    "uav_operator": {"label": "UAV Operator", "perms": {"read", "mission.approve", "mission.execute", "proposal.approve", "sim.control",
                                                       "report.generate", "hardware.connect"}},
    "observer": {"label": "Observer", "perms": {"read"}},
    "maintenance_engineer": {"label": "Maintenance Engineer", "perms": {"read", "fleet.status", "maintenance.write"}},
}


class PermissionDenied(Exception):
    pass


def can(role: str, perm: str) -> bool:
    r = ROLES.get(role)
    return bool(r) and perm in r["perms"]


def require(actor: dict, perm: str):
    if not can(actor.get("role", ""), perm):
        raise PermissionDenied(f"role '{actor.get('role')}' lacks permission '{perm}'")


def role_table() -> list[dict]:
    return [{"role": k, "label": v["label"], "perms": sorted(v["perms"])} for k, v in ROLES.items()]
