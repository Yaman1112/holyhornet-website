"""Conflict prediction: tactical (closest point of approach with uncertainty), intent-based route
prediction, zone intrusion, and strategic (pre-flight) 4-D route checks.

ADVISORY ONLY. These alerts describe aircraft known to SkyGrid; they are not a complete traffic picture
and are not a certified detect-and-avoid function.

Tactical CPA (constant-velocity extrapolation of the ground-station Kalman estimate):
    r = p2 - p1, v = v2 - v1 (horizontal),  t* = clamp(-r·v / |v|², 0, horizon),  d* = |r + v t*|
Uncertainty of the miss distance along the miss direction û:
    Σ(t) = Σ_rr + t (Σ_rv + Σ_vr) + t² Σ_vv   (sum of both aircraft, assumed independent)
    σ_d = sqrt(ûᵀ Σ(t*) û ⊕ (k_m t*²)²)        k_m: manoeuvre allowance, CV ignores turns
    P(infringe) ≈ Φ((S_h − d*) / σ_d)          one-dimensional approximation along û
"""

from __future__ import annotations

import math

import numpy as np

from .catalog import DOCKS
from .geo import distance_to_polygon, point_in_polygon

DEFAULT_SEPARATION = {
    "horizontal_m": 30.0, "vertical_m": 15.0, "horizon_s": 60.0, "manoeuvre_k": 0.02,
    "critical": {"d_frac": 0.5, "t_s": 15.0},
    "warning": {"p": 0.5, "t_s": 30.0},
    "advisory": {"p": 0.2, "t_s": 60.0},
    "info_factor": 2.0,
    "stale_s": 3.0, "lost_s": 8.0,
    "terminal_alt_m": 10.0,
    # dock terminal areas (e, n, radius): inside these, take-off/landing sequencing on the pads separates aircraft
    "terminal_areas": [(d["e"], d["n"], 75.0) for d in DOCKS],  # below this at a dock, pad sequencing (not SkyGrid) separates aircraft
}
LEVELS = ["informational", "advisory", "warning", "critical"]


def in_terminal(pos, cfg) -> bool:
    return any(math.hypot(pos[0] - e, pos[1] - n) < r for e, n, r in cfg.get("terminal_areas", []))


def phi(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def cpa(p1, v1, p2, v2, horizon: float):
    r = np.asarray(p2[:2], float) - np.asarray(p1[:2], float)
    v = np.asarray(v2[:2], float) - np.asarray(v1[:2], float)
    vv = float(v @ v)
    t = 0.0 if vv < 1e-9 else min(max(-float(r @ v) / vv, 0.0), horizon)
    miss = r + v * t
    return t, float(np.linalg.norm(miss)), miss


def tactical_pair(a: dict, b: dict, cfg: dict) -> dict:
    """a, b: {'id','pos','vel','P'} ground-station estimates. Returns metrics + explanation."""
    H = cfg["horizon_s"]
    t, d, miss = cpa(a["pos"], a["vel"], b["pos"], b["vel"], H)
    dz = (b["pos"][2] + b["vel"][2] * t) - (a["pos"][2] + a["vel"][2] * t)
    Pa, Pb = a["P"], b["P"]
    S = (Pa[:2, :2] + Pb[:2, :2]) + t * (Pa[:2, 3:5] + Pa[3:5, :2] + Pb[:2, 3:5] + Pb[3:5, :2]) + t * t * (Pa[3:5, 3:5] + Pb[3:5, 3:5])
    if d > 1e-6:
        u = miss / d
    else:
        w, V = np.linalg.eigh(S)
        u = V[:, -1]
    sig = math.sqrt(max(float(u @ S @ u), 0.0) + (cfg["manoeuvre_k"] * t * t) ** 2)
    sig = max(sig, 0.5)
    p = phi((cfg["horizontal_m"] - d) / sig) if abs(dz) < cfg["vertical_m"] else 0.0
    now_d = float(np.linalg.norm(np.asarray(b["pos"][:2]) - np.asarray(a["pos"][:2])))
    return {"t_cpa": t, "d_cpa": d, "dz_cpa": dz, "sigma": sig, "p_infringe": p, "d_now": now_d,
            "cpa_a": [float(a["pos"][k] + a["vel"][k] * t) for k in range(3)],
            "cpa_b": [float(b["pos"][k] + b["vel"][k] * t) for k in range(3)],
            "rel_pos": [float(x) for x in (np.asarray(b["pos"]) - np.asarray(a["pos"]))],
            "rel_vel": [float(x) for x in (np.asarray(b["vel"]) - np.asarray(a["vel"]))]}


def classify(m: dict, cfg: dict) -> str | None:
    Hs = cfg["horizontal_m"]
    if abs(m["dz_cpa"]) >= cfg["vertical_m"]:
        return None
    if m["d_cpa"] < cfg["critical"]["d_frac"] * Hs and m["t_cpa"] <= cfg["critical"]["t_s"]:
        return "critical"
    if m["d_now"] < cfg["critical"]["d_frac"] * Hs:
        return "critical"
    if (m["p_infringe"] >= cfg["warning"]["p"] or m["d_cpa"] < Hs) and m["t_cpa"] <= cfg["warning"]["t_s"]:
        return "warning"
    if m["p_infringe"] >= cfg["advisory"]["p"] and m["t_cpa"] <= cfg["advisory"]["t_s"]:
        return "advisory"
    if m["d_cpa"] < cfg["info_factor"] * Hs and m["t_cpa"] <= cfg["horizon_s"]:
        return "informational"
    return None


def intent_min_separation(path_a, path_b, cfg: dict):
    """path_*: [(t, e, n, u)] predicted along each aircraft's uploaded route, same time grid."""
    best = (math.inf, 0.0, 0.0)
    for (t, ea, na, ua), (_, eb, nb, ub) in zip(path_a, path_b):
        if abs(ub - ua) >= cfg["vertical_m"] or ua < cfg["terminal_alt_m"] or ub < cfg["terminal_alt_m"]:
            continue
        if in_terminal((ea, na), cfg) and in_terminal((eb, nb), cfg):
            continue
        d = math.hypot(eb - ea, nb - na)
        if d < best[0]:
            best = (d, t - path_a[0][0], ub - ua)
    return best  # (d_min, t_rel, dz)


def zone_active(z: dict, t: float) -> bool:
    if not z.get("active", True):
        return False
    return z.get("t_from", -math.inf) <= t <= z.get("t_to", math.inf)


def zone_status(pos, path, zone: dict, t: float):
    """Returns (level, detail) for one aircraft and one zone, or None."""
    if not zone_active(zone, t):
        return None
    inside_alt = zone["alt_min"] <= pos[2] <= zone["alt_max"]
    inside = point_in_polygon(pos[0], pos[1], zone["ring"]) and inside_alt
    if zone["rule"] == "no_fly":
        if inside:
            return "critical", f"inside {zone['name']}"
        for (tt, e, n, u) in path:
            if zone["alt_min"] <= u <= zone["alt_max"] and point_in_polygon(e, n, zone["ring"]):
                return "warning", f"predicted to enter {zone['name']} in {tt - path[0][0]:.0f} s"
        dist = distance_to_polygon(pos[0], pos[1], zone["ring"])
        if dist < 20.0 and inside_alt:
            return "advisory", f"{dist:.0f} m from {zone['name']}"
    elif zone["rule"] == "keep_in" and pos[2] > 1.0:
        if not point_in_polygon(pos[0], pos[1], zone["ring"]) or pos[2] > zone["alt_max"]:
            return "warning", f"outside {zone['name']}"
        for (tt, e, n, u) in path:
            if not point_in_polygon(e, n, zone["ring"]) or u > zone["alt_max"]:
                return "advisory", f"predicted to leave {zone['name']} in {tt - path[0][0]:.0f} s"
    return None


def sample_path(tp, t0: float, t1: float, dt: float = 1.0):
    """Sample a time-parameterised route [(t,e,n,u)] on [t0, t1]; holds the end points."""
    out = []
    k = 0
    t = t0
    while t <= t1 + 1e-9:
        while k + 1 < len(tp) and tp[k + 1][0] < t:
            k += 1
        if t <= tp[0][0]:
            p = tp[0][1:]
        elif k + 1 >= len(tp):
            p = tp[-1][1:]
        else:
            ta, *pa = tp[k]
            tb, *pb = tp[k + 1]
            s = (t - ta) / (tb - ta) if tb > ta else 0.0
            p = tuple(pa[i] + s * (pb[i] - pa[i]) for i in range(3))
        out.append((t, *p))
        t += dt
    return out


def strategic_check(routes: dict[str, list], zones: list[dict], cfg: dict | None = None, dt: float = 1.0) -> dict:
    """routes: uav_id -> time-parameterised route [(t,e,n,u)] (absolute plan time). Ground segments
    (u < 3 m, on the dock) are ignored. Returns pair conflicts and zone intrusions with time windows."""
    cfg = {**DEFAULT_SEPARATION, **(cfg or {})}
    ids = list(routes)
    t_end = max((r[-1][0] for r in routes.values()), default=0.0)
    samples = {i: sample_path(routes[i], 0.0, t_end, dt) for i in ids}
    conflicts = []
    for x in range(len(ids)):
        for y in range(x + 1, len(ids)):
            a, b = samples[ids[x]], samples[ids[y]]
            win = None
            dmin = math.inf
            for (t, ea, na, ua), (_, eb, nb, ub) in zip(a, b):
                if ua < cfg["terminal_alt_m"] or ub < cfg["terminal_alt_m"]:
                    continue
                if in_terminal((ea, na), cfg) and in_terminal((eb, nb), cfg):
                    continue
                d = math.hypot(eb - ea, nb - na)
                bad = d < cfg["horizontal_m"] and abs(ub - ua) < cfg["vertical_m"]
                if bad:
                    dmin = min(dmin, d)
                    win = [t, t] if win is None else [win[0], t]
                elif win is not None:
                    conflicts.append({"uavs": [ids[x], ids[y]], "t_from": win[0], "t_to": win[1], "d_min": round(dmin, 1)})
                    win, dmin = None, math.inf
            if win is not None:
                conflicts.append({"uavs": [ids[x], ids[y]], "t_from": win[0], "t_to": win[1], "d_min": round(dmin, 1)})
    intrusions = []
    for i in ids:
        for z in zones:
            if z["rule"] != "no_fly":
                continue
            hit = [t for (t, e, n, u) in samples[i] if u > 3.0 and zone_active(z, t)
                   and z["alt_min"] <= u <= z["alt_max"] and point_in_polygon(e, n, z["ring"])]
            if hit:
                intrusions.append({"uav_id": i, "zone_id": z["id"], "zone": z["name"], "t_from": hit[0], "t_to": hit[-1]})
    min_sep = math.inf
    for x in range(len(ids)):
        for y in range(x + 1, len(ids)):
            for (t, ea, na, ua), (_, eb, nb, ub) in zip(samples[ids[x]], samples[ids[y]]):
                if ua > cfg["terminal_alt_m"] and ub > cfg["terminal_alt_m"]:
                    d3 = math.sqrt((eb - ea) ** 2 + (nb - na) ** 2 + ((ub - ua) * cfg["horizontal_m"] / cfg["vertical_m"]) ** 2)
                    min_sep = min(min_sep, d3)
    return {"conflicts": conflicts, "intrusions": intrusions, "ok": not conflicts and not intrusions,
            "min_scaled_separation_m": None if min_sep == math.inf else round(min_sep, 1),
            "method": f"4-D sampling at {dt:.0f} s; conflict = horizontal < {cfg['horizontal_m']:.0f} m and vertical < {cfg['vertical_m']:.0f} m"}
