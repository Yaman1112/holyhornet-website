"""Ground-station track per aircraft: constant-velocity Kalman filter in 3-D (ENU).

State x = [e, n, u, ve, vn, vu]. Measurements are telemetry position (GNSS, noise from reported
quality) and velocity. With no telemetry (link loss) only the prediction runs, so the covariance grows
and the UI shows the growing uncertainty instead of a frozen icon.
"""

from __future__ import annotations

import numpy as np


class CVTrack:
    def __init__(self, pos, vel=(0.0, 0.0, 0.0), t: float = 0.0, q: float = 0.8):
        self.x = np.array([*pos, *vel], dtype=float)
        self.P = np.diag([4.0, 4.0, 4.0, 1.0, 1.0, 1.0])
        self.t = t
        self.last_update = t
        self.q = q  # white-acceleration spectral density [m^2/s^3]

    def predict_to(self, t: float):
        dt = t - self.t
        if dt <= 0:
            return
        F = np.eye(6)
        F[0, 3] = F[1, 4] = F[2, 5] = dt
        q = self.q
        Q1 = np.array([[dt**3 / 3, dt**2 / 2], [dt**2 / 2, dt]]) * q
        Q = np.zeros((6, 6))
        for k in range(3):
            Q[np.ix_([k, k + 3], [k, k + 3])] = Q1
        self.x = F @ self.x
        self.P = F @ self.P @ F.T + Q
        self.t = t

    def update(self, t: float, pos, vel, sigma_pos: float, sigma_vel: float = 0.3):
        self.predict_to(t)
        z = np.array([*pos, *vel], dtype=float)
        R = np.diag([sigma_pos**2, sigma_pos**2, (1.5 * sigma_pos) ** 2, sigma_vel**2, sigma_vel**2, sigma_vel**2])
        S = self.P + R
        K = self.P @ np.linalg.inv(S)
        self.x = self.x + K @ (z - self.x)
        self.P = (np.eye(6) - K) @ self.P
        self.P = 0.5 * (self.P + self.P.T)
        self.last_update = t

    def state_at(self, t: float):
        """Extrapolated (pos, vel, P) at time t without changing the filter."""
        dt = max(0.0, t - self.t)
        F = np.eye(6)
        F[0, 3] = F[1, 4] = F[2, 5] = dt
        x = F @ self.x
        P = F @ self.P @ F.T
        return x[:3], x[3:], P

    def sigma_h(self) -> float:
        """1-σ horizontal position uncertainty (root of the larger eigenvalue)."""
        return float(np.sqrt(max(np.linalg.eigvalsh(self.P[:2, :2]).max(), 0.0)))
