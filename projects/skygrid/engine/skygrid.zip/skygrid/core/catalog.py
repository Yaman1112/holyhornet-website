"""Synthetic demonstration data: aircraft models, fleet, the industrial facility, zones and history.

EVERYTHING IN THIS FILE IS SYNTHETIC. Model names, serial numbers, registrations, operators and the
facility are invented for demonstration. The site origin is an empty inland location chosen only to give
the map real coordinates; there is no real facility there and no airspace data is implied.
"""

from __future__ import annotations

import copy
import math
import random

SITE_ORIGIN = {"lat": 24.1830, "lon": 55.3120, "alt": 95.0}  # synthetic, open desert
DATA_SOURCE = "SkyGrid synthetic dataset v0.1"
DATA_TIMESTAMP = "2026-11-13T00:00:00Z"

# ---------------------------------------------------------------- aircraft models (synthetic)
MODELS: dict[str, dict] = {
    "HH-Q4": {
        "model": "HH-Q4 Hornet", "manufacturer": "HolyHornet (synthetic model)", "category": "multirotor",
        "roles": ["inspection"], "mass_kg": 6.2, "mtom_kg": 7.6, "payload_max_kg": 1.4,
        "cruise_ms": 10.0, "vmax_ms": 17.0, "climb_ms": 4.0, "descent_ms": 2.5, "accel_ms2": 3.0,
        "hover_w": 620.0, "battery_wh": 488.0, "cells": 6, "endurance_min": 38, "range_km": 7.0,
        "max_wind_ms": 12.0, "flight_controller": "PX4 v1.15 (simulated)",
        "navigation": "GNSS + IMU + barometer + magnetometer", "gnss": "GPS/GLONASS/Galileo/BeiDou, RTK-ready",
        "comms": "2.4 GHz C2 link + LTE backup (simulated)",
    },
    "HH-Q6L": {
        "model": "HH-Q6L Atlas LiDAR", "manufacturer": "HolyHornet (synthetic model)", "category": "multirotor",
        "roles": ["mapping", "inspection"], "mass_kg": 9.8, "mtom_kg": 13.5, "payload_max_kg": 3.0,
        "cruise_ms": 9.0, "vmax_ms": 15.0, "climb_ms": 3.5, "descent_ms": 2.5, "accel_ms2": 2.5,
        "hover_w": 980.0, "battery_wh": 710.0, "cells": 12, "endurance_min": 34, "range_km": 7.0,
        "max_wind_ms": 12.0, "flight_controller": "ArduCopter 4.5 (simulated)",
        "navigation": "RTK GNSS + IMU + barometer", "gnss": "Dual-antenna RTK GNSS",
        "comms": "2.4/5.8 GHz C2 link (simulated)",
    },
    "HH-F2": {
        "model": "HH-F2 Swift", "manufacturer": "HolyHornet (synthetic model)", "category": "fixed_wing",
        "roles": ["mapping", "survey"], "mass_kg": 4.1, "mtom_kg": 4.8, "payload_max_kg": 0.7,
        "cruise_ms": 18.0, "vmax_ms": 26.0, "vmin_ms": 13.0, "climb_ms": 3.0, "descent_ms": 3.0, "accel_ms2": 1.5,
        "cruise_w": 175.0, "battery_wh": 355.0, "cells": 6, "endurance_min": 100, "range_km": 15.0,
        "min_turn_radius_m": 60.0, "max_wind_ms": 14.0, "flight_controller": "ArduPlane 4.5 (simulated)",
        "navigation": "GNSS + IMU + airspeed + barometer", "gnss": "GPS/Galileo, PPK",
        "comms": "900 MHz long-range C2 link (simulated)",
    },
    "HH-V3": {
        "model": "HH-V3 Kestrel VTOL", "manufacturer": "HolyHornet (synthetic model)", "category": "hybrid_vtol",
        "roles": ["inspection", "mapping", "survey"], "mass_kg": 11.5, "mtom_kg": 14.0, "payload_max_kg": 2.0,
        "cruise_ms": 20.0, "vmax_ms": 30.0, "vmin_ms": 15.0, "climb_ms": 3.0, "descent_ms": 2.0, "accel_ms2": 2.0,
        "hover_w": 1450.0, "cruise_w": 270.0, "battery_wh": 920.0, "cells": 12, "endurance_min": 120,
        "range_km": 25.0, "min_turn_radius_m": 80.0, "max_wind_ms": 15.0,
        "flight_controller": "PX4 v1.15 VTOL (simulated)", "navigation": "RTK GNSS + IMU + airspeed",
        "gnss": "Dual-antenna RTK GNSS", "comms": "900 MHz C2 + LTE (simulated)",
    },
    "HH-AG12": {
        "model": "HH-AG12 Agri", "manufacturer": "HolyHornet (synthetic model)", "category": "agricultural",
        "roles": ["agriculture", "survey"], "mass_kg": 24.0, "mtom_kg": 38.0, "payload_max_kg": 12.0,
        "cruise_ms": 7.0, "vmax_ms": 12.0, "climb_ms": 3.0, "descent_ms": 2.0, "accel_ms2": 2.0,
        "hover_w": 3600.0, "battery_wh": 1350.0, "cells": 14, "endurance_min": 18, "range_km": 3.0,
        "max_wind_ms": 8.0, "flight_controller": "ArduCopter 4.5 (simulated)",
        "navigation": "RTK GNSS + IMU + radar altimeter", "gnss": "RTK GNSS", "comms": "2.4 GHz (simulated)",
    },
    "HH-D5": {
        "model": "HH-D5 Courier", "manufacturer": "HolyHornet (synthetic model)", "category": "delivery",
        "roles": ["logistics"], "mass_kg": 9.0, "mtom_kg": 14.0, "payload_max_kg": 5.0,
        "cruise_ms": 14.0, "vmax_ms": 20.0, "climb_ms": 4.0, "descent_ms": 2.5, "accel_ms2": 2.5,
        "hover_w": 1150.0, "battery_wh": 640.0, "cells": 12, "endurance_min": 30, "range_km": 10.0,
        "max_wind_ms": 11.0, "flight_controller": "PX4 v1.15 (simulated)",
        "navigation": "GNSS + IMU + barometer", "gnss": "GPS/Galileo", "comms": "LTE + 2.4 GHz (simulated)",
    },
}

SENSOR_LABELS = {
    "rgb": "RGB camera 45 MP", "thermal": "Radiometric thermal 640×512", "gas": "Methane laser detector",
    "lidar": "LiDAR 240k pts/s", "zoom": "30× EO zoom", "multispectral": "5-band multispectral",
    "sprayer": "Spray system 10 L", "winch": "Payload winch 5 kg",
}

# ---------------------------------------------------------------- facility (ENU metres, synthetic)
DOCKS = [
    {"id": "D1", "name": "Dock D1", "e": -390.0, "n": -250.0, "capacity": 4},
    {"id": "D2", "name": "Dock D2", "e": -330.0, "n": -250.0, "capacity": 4},
    {"id": "D3", "name": "Dock D3 (east)", "e": 420.0, "n": -235.0, "capacity": 4},
]
GCS = [{"id": "GCS-1", "name": "Ground control station (control room)", "e": -360.0, "n": -310.0, "range_m": 6000.0}]
EMERGENCY_SITES = [
    {"id": "E1", "name": "Emergency landing E1 (laydown yard)", "e": -420.0, "n": 300.0},
    {"id": "E2", "name": "Emergency landing E2 (east gravel)", "e": 440.0, "n": -160.0},
    {"id": "E3", "name": "Emergency landing E3 (south lot)", "e": 40.0, "n": -320.0},
]


def _circle(cx, cy, r, k=24):
    return [[cx + r * math.cos(2 * math.pi * i / k), cy + r * math.sin(2 * math.pi * i / k)] for i in range(k)]


TANKS = [(-240.0, 170.0), (-120.0, 170.0), (-240.0, 270.0), (-120.0, 270.0)]
STACK = (330.0, 180.0)
FLARE = (410.0, 320.0)
PIPE_RACK = [[-300.0, 40.0], [-20.0, -40.0], [300.0, -60.0], [380.0, -200.0]]

INSPECTION_AREAS = [
    {"id": "A1", "name": "Tank Farm North", "ring": [[-310, 110], [-50, 110], [-50, 330], [-310, 330]],
     "pattern": "multi_orbit", "params": {"centers": [list(t) for t in TANKS], "radius": 55.0, "alt": 32.0},
     "sensors": ["thermal"], "priority": 3, "objective": "Thermal survey of tank shells and roofs"},
    {"id": "A2", "name": "Process Unit", "ring": [[0, 40], [250, 40], [250, 250], [0, 250]],
     "pattern": "lawnmower", "params": {"spacing": 42.0, "alt": 46.0},
     "sensors": ["gas", "rgb"], "priority": 3, "objective": "Methane leak survey and visual check"},
    {"id": "A3", "name": "Stack & Flare Area", "ring": [[270, 120], [390, 120], [390, 240], [270, 240]],
     "pattern": "orbit", "params": {"center": list(STACK), "radius": 48.0, "alts": [38.0, 58.0, 78.0]},
     "sensors": ["thermal", "rgb"], "priority": 2, "objective": "Stack shell thermal and visual inspection"},
    {"id": "A4", "name": "Pipe Rack Corridor", "ring": [[-310, 60], [-310, 20], [300, -40], [400, -200], [360, -210], [290, -80], [-20, -60]],
     "pattern": "corridor", "params": {"line": PIPE_RACK, "offset": 14.0, "alt": 24.0},
     "sensors": ["rgb"], "priority": 2, "objective": "Visual inspection of pipe supports and insulation"},
    {"id": "A5", "name": "Substation & Solar Field", "ring": [[-250, -215], [-70, -215], [-70, -85], [-250, -85]],
     "pattern": "lawnmower", "params": {"spacing": 32.0, "alt": 40.0},
     "sensors": ["thermal"], "priority": 1, "objective": "Thermal hotspot scan of transformers and panels"},
]

SITE_BOUNDARY = [[-470, -350], [470, -350], [470, 370], [-470, 370]]

ZONES = [
    {"id": "Z-OPS", "name": "Facility operational area", "kind": "operational_area", "ring": SITE_BOUNDARY,
     "alt_min": 0.0, "alt_max": 120.0, "rule": "keep_in", "active": True},
    {"id": "Z-FLARE", "name": "Active flare exclusion", "kind": "restricted", "ring": _circle(*FLARE, 65.0),
     "alt_min": 0.0, "alt_max": 250.0, "rule": "no_fly", "active": True},
    {"id": "Z-CR", "name": "Control room no-overflight", "kind": "restricted",
     "ring": [[-420, -335], [-300, -335], [-300, -285], [-420, -285]], "alt_min": 0.0, "alt_max": 60.0,
     "rule": "no_fly", "active": True},
    {"id": "Z-CRANE", "name": "Temporary restriction: crane lift", "kind": "temporary", "ring": _circle(140.0, -160.0, 45.0),
     "alt_min": 0.0, "alt_max": 90.0, "rule": "no_fly", "active": True, "t_from": 0.0, "t_to": 5400.0},
]

BUILDINGS = (
    [{"kind": "tank", "e": t[0], "n": t[1], "r": 34.0, "h": 18.0} for t in TANKS]
    + [{"kind": "stack", "e": STACK[0], "n": STACK[1], "r": 5.0, "h": 62.0},
       {"kind": "flare", "e": FLARE[0], "n": FLARE[1], "r": 2.5, "h": 46.0}]
    + [{"kind": "box", "e": e, "n": n, "w": w, "d": d, "h": h} for e, n, w, d, h in [
        (60, 90, 40, 26, 22), (130, 110, 30, 50, 28), (200, 80, 36, 30, 16), (70, 190, 50, 30, 18),
        (180, 200, 44, 40, 25), (-360, -310, 110, 40, 9), (-360, -200, 90, 30, 7), (385, -270, 40, 26, 6),
        (-200, -110, 30, 20, 7), (-150, -110, 20, 20, 6)]]
    + [{"kind": "panel", "e": -230 + i * 26.0, "n": -175.0, "w": 16.0, "d": 70.0, "h": 2.5} for i in range(6)]
)

# ---------------------------------------------------------------- fleet (synthetic)
_FLEET_SPEC = [
    # id, name, model, sensors, soc, health, hours, maintenance, dock, operator, status
    ("HH-001", "Hornet 1", "HH-Q4", ["rgb", "thermal"], 0.98, 0.97, 212.4, "ok", "D1", "OP-1", "available"),
    ("HH-002", "Hornet 2", "HH-Q4", ["rgb", "thermal", "gas"], 1.00, 0.95, 188.0, "ok", "D1", "OP-1", "available"),
    ("HH-003", "Hornet 3", "HH-Q4", ["rgb", "thermal"], 0.95, 0.91, 301.7, "ok", "D1", "OP-2", "available"),
    ("HH-004", "Hornet 4", "HH-Q4", ["rgb", "thermal", "gas"], 0.90, 0.93, 260.2, "ok", "D2", "OP-2", "available"),
    ("HH-005", "Hornet 5", "HH-Q4", ["rgb", "thermal", "zoom"], 1.00, 0.99, 64.9, "ok", "D2", "OP-3", "available"),
    ("HH-006", "Hornet 6", "HH-Q4", ["rgb", "thermal"], 0.88, 0.89, 344.1, "due_soon", "D2", "OP-3", "standby"),
    ("HH-007", "Atlas 1", "HH-Q6L", ["lidar", "rgb"], 1.00, 0.96, 120.5, "ok", "D2", "OP-1", "available"),
    ("HH-008", "Swift 1", "HH-F2", ["rgb", "multispectral"], 1.00, 0.97, 410.0, "ok", "D3", "OP-2", "available"),
    ("HH-009", "Swift 2", "HH-F2", ["rgb", "multispectral"], 0.97, 0.94, 455.3, "ok", "D3", "OP-2", "available"),
    ("HH-010", "Kestrel 1", "HH-V3", ["rgb", "thermal", "zoom"], 1.00, 0.98, 96.0, "ok", "D3", "OP-3", "available"),
    ("HH-011", "Agri 1", "HH-AG12", ["multispectral", "sprayer"], 0.60, 0.90, 150.0, "in_maintenance", "D3", "OP-3", "maintenance"),
    ("HH-012", "Courier 1", "HH-D5", ["rgb", "winch"], 0.95, 0.95, 77.0, "ok", "D3", "OP-1", "available"),
]


def make_fleet() -> list[dict]:
    fleet = []
    for i, (uid, name, model, sensors, soc, health, hours, maint, dock, op, status) in enumerate(_FLEET_SPEC):
        m = MODELS[model]
        fleet.append({
            "id": uid, "name": name, "model_code": model, "model": m["model"], "manufacturer": m["manufacturer"],
            "category": m["category"], "roles": list(m["roles"]),
            "serial": f"SYN-{model.replace('-', '')}-{2026_0000 + 137 * (i + 1)}",
            "flight_controller": m["flight_controller"], "firmware": "1.15.4-sim" if "PX4" in m["flight_controller"] else "4.5.7-sim",
            "navigation": m["navigation"], "gnss": m["gnss"], "comms": m["comms"],
            "battery": {"chemistry": "Li-ion 21700" if m["battery_wh"] > 600 else "LiPo", "cells": m["cells"],
                        "capacity_wh": m["battery_wh"], "health": health, "soc": soc,
                        "cycles": int(hours * 1.6)},
            "payload": {"mass_kg": round(min(m["payload_max_kg"], 0.35 * len(sensors)), 2),
                        "items": [SENSOR_LABELS[s] for s in sensors]},
            "sensors": list(sensors), "mtom_kg": m["mtom_kg"], "endurance_min": m["endurance_min"],
            "range_km": m["range_km"],
            "maintenance": {"status": maint, "flight_hours": hours,
                            "next_service_hours": round(math.ceil((hours + 1) / 50.0) * 50.0, 1)},
            "registration": {"reference": f"SYNTHETIC-REG-{uid}", "authority": "(not registered — synthetic)",
                             "documents_valid_until": None},
            "operator_id": op, "status": status, "home_dock": dock,
            "contingency": {"link_loss": "hold_then_rth", "link_loss_timeout_s": 5.0, "hold_s": 20.0,
                            "low_battery_rtl_soc": 0.12},
            "synthetic": True,
        })
    return fleet


OPERATORS = [
    {"id": "OP-1", "name": "Operator Alpha (synthetic)", "certificate": "SYNTHETIC-RPC-001", "current": True},
    {"id": "OP-2", "name": "Operator Bravo (synthetic)", "certificate": "SYNTHETIC-RPC-002", "current": True},
    {"id": "OP-3", "name": "Operator Charlie (synthetic)", "certificate": "SYNTHETIC-RPC-003", "current": True},
]

ORGANIZATIONS = [
    {"id": "org-demo", "name": "HolyHornet Demo Industrial Operator", "country": "AE", "regulatory_profile": "unverified"},
    {"id": "org-partner", "name": "Partner Survey Co. (demo)", "country": "DE", "regulatory_profile": "unverified"},
]

DEMO_USERS = [
    {"id": "u-super", "email": "super@demo.skygrid", "name": "Super Admin (demo)", "role": "super_admin", "org_id": "org-demo"},
    {"id": "u-admin", "email": "admin@demo.skygrid", "name": "Org Admin (demo)", "role": "org_admin", "org_id": "org-demo"},
    {"id": "u-fleet", "email": "fleet@demo.skygrid", "name": "Fleet Manager (demo)", "role": "fleet_manager", "org_id": "org-demo"},
    {"id": "u-plan", "email": "planner@demo.skygrid", "name": "Mission Planner (demo)", "role": "mission_planner", "org_id": "org-demo"},
    {"id": "u-op", "email": "operator@demo.skygrid", "name": "UAV Operator (demo)", "role": "uav_operator", "org_id": "org-demo"},
    {"id": "u-obs", "email": "observer@demo.skygrid", "name": "Observer (demo)", "role": "observer", "org_id": "org-demo"},
    {"id": "u-mx", "email": "maint@demo.skygrid", "name": "Maintenance Engineer (demo)", "role": "maintenance_engineer", "org_id": "org-demo"},
    {"id": "u-partner", "email": "admin@partner.skygrid", "name": "Partner Admin (demo)", "role": "org_admin", "org_id": "org-partner"},
]


def make_maintenance() -> list[dict]:
    recs = []
    rng = random.Random(7)
    kinds = ["Propeller replacement", "Motor bearing check", "Firmware update", "Battery capacity test",
             "Airframe inspection", "Compass calibration", "Gimbal calibration"]
    for uid, *_ in _FLEET_SPEC:
        for k in range(rng.randint(1, 3)):
            day = rng.randint(3, 80)
            recs.append({"id": f"MX-{uid[-3:]}-{k + 1}", "uav_id": uid, "kind": rng.choice(kinds),
                         "status": "completed", "date": f"2026-{8 + day // 30:02d}-{1 + day % 28:02d}",
                         "hours_at_service": None, "notes": "Synthetic record", "engineer": "Maintenance (demo)"})
    recs.append({"id": "MX-011-OPEN", "uav_id": "HH-011", "kind": "Pump seal replacement", "status": "open",
                 "date": "2026-11-12", "hours_at_service": 150.0, "notes": "Spray pump leak found on post-flight check (synthetic)",
                 "engineer": "Maintenance (demo)"})
    recs.append({"id": "MX-006-DUE", "uav_id": "HH-006", "kind": "350 h service", "status": "scheduled",
                 "date": "2026-11-16", "hours_at_service": 350.0, "notes": "Due in 5.9 flight hours (synthetic)",
                 "engineer": "Maintenance (demo)"})
    return recs


def make_history(days: int = 30, seed: int = 11) -> list[dict]:
    """Synthetic completed-mission history for analytics (clearly labelled synthetic)."""
    rng = random.Random(seed)
    kinds = ["infrastructure_inspection", "aerial_mapping", "industrial_inspection", "environmental_monitoring",
             "construction_monitoring", "surveying"]
    uavs = [s[0] for s in _FLEET_SPEC if s[0] != "HH-011"]
    out = []
    for d in range(days, 0, -1):
        for k in range(rng.choice([1, 2, 2, 3])):
            n = rng.choice([1, 2, 3, 5])
            ids = rng.sample(uavs, n)
            planned = rng.uniform(12, 45)
            actual = planned * rng.uniform(0.92, 1.25)
            outcome = rng.choices(["completed", "completed_with_reassignment", "aborted"], [0.85, 0.11, 0.04])[0]
            out.append({
                "id": f"HIST-{d:02d}-{k}", "day_offset": -d, "kind": rng.choice(kinds), "uavs": ids,
                "planned_min": round(planned, 1), "actual_min": round(actual, 1),
                "distance_km": round(actual * 60 * 9.0 * n / 1000.0 * rng.uniform(0.8, 1.0), 2),
                "energy_wh": round(actual * 60 * 560 / 3600.0 * n * rng.uniform(0.9, 1.15), 1),
                "outcome": outcome, "interruptions": 0 if outcome == "completed" else 1,
                "link_availability": round(rng.uniform(0.95, 1.0), 4), "synthetic": True,
            })
    return out


def site_payload(frame) -> dict:
    """Everything the map/3D views need about the static site, in both ENU and WGS-84."""

    def geo_pt(p):
        lat, lon, _ = frame.to_geo(p["e"], p["n"])
        return {**p, "lat": lat, "lon": lon}

    return {
        "origin": SITE_ORIGIN, "name": "Synthetic Industrial Facility (demo)", "synthetic": True,
        "source": DATA_SOURCE, "source_timestamp": DATA_TIMESTAMP,
        "boundary": SITE_BOUNDARY, "boundary_geo": frame.ring_to_geo(SITE_BOUNDARY),
        "docks": [geo_pt(d) for d in DOCKS], "gcs": [geo_pt(g) for g in GCS],
        "emergency_sites": [geo_pt(e) for e in EMERGENCY_SITES],
        "buildings": copy.deepcopy(BUILDINGS), "pipe_rack": PIPE_RACK,
        "areas": [{**a, "ring_geo": frame.ring_to_geo(a["ring"])} for a in copy.deepcopy(INSPECTION_AREAS)],
    }
