"""Simplified power and battery models (configurable, not identified from real aircraft data).

Multirotor:  P = P_hover * (m/m0)^1.5 * (1 - 0.12 s + 0.45 s^2) + climb + wind term,   s = airspeed / vmax
             The dip at moderate speed reproduces translational lift; the s^2 term is parasite drag.
Fixed-wing:  P = P_cruise * (0.5 (v/vc)^3 + 0.5 (vc/v)) + climb    (parasite ~v^3 + induced ~1/v)
Hybrid VTOL: multirotor model while hovering/transitioning, fixed-wing model in forward flight.
Battery:     open-circuit voltage from SoC, internal resistance, I = P / V.
"""

from __future__ import annotations

import math

G = 9.81


def power_w(spec: dict, airspeed: float, vz: float, wind: float = 0.0, payload_kg: float = 0.0,
            hovering: bool | None = None) -> float:
    cat = spec["category"]
    m0 = spec["mass_kg"]
    m = m0 + payload_kg
    climb = m * G * vz / 0.65 if vz > 0 else 0.15 * m * G * vz  # descent recovers a little (negative)
    fixed = cat == "fixed_wing" or (cat == "hybrid_vtol" and not hovering and airspeed >= spec.get("vmin_ms", 0) * 0.9)
    if fixed:
        vc = spec["cruise_ms"]
        v = max(airspeed, spec.get("vmin_ms", vc * 0.7))
        p = spec["cruise_w"] * (0.5 * (v / vc) ** 3 + 0.5 * (vc / v)) * (m / m0)
        return max(30.0, p + climb + 0.6 * wind * wind)
    s = min(airspeed / spec["vmax_ms"], 1.3)
    p = spec["hover_w"] * (m / m0) ** 1.5 * (1 - 0.12 * s + 0.45 * s * s)
    return max(50.0, p + climb + 0.004 * spec["hover_w"] * wind * wind)


def ocv(cells: int, soc: float) -> float:
    soc = min(max(soc, 0.0), 1.0)
    return cells * (3.30 + 0.62 * soc + 0.28 * soc ** 3 - 0.25 * math.exp(-25 * soc))


def battery_vi(cells: int, soc: float, power: float) -> tuple[float, float]:
    r = 0.0035 * cells
    v0 = ocv(cells, soc)
    # P = V*I = (v0 - I r) I  ->  r I^2 - v0 I + P = 0
    disc = v0 * v0 - 4 * r * power
    i = (v0 - math.sqrt(max(disc, 0.0))) / (2 * r)
    return v0 - i * r, i


def usable_wh(uav: dict) -> float:
    b = uav["battery"]
    return b["capacity_wh"] * b["health"]
