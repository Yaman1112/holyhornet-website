"""Built-in simulation scenarios and the scenario schema used by the scenario editor.

Scenario (JSON):
  id, name, description, builtin, uav_ids[], mission{name, type, objective, area_ids[] | areas[] | coverage{}},
  assignments[] (optional explicit routes: {uav_id, waypoints[[e,n,u]], launch_t}; bypasses allocation),
  events[] {t, type, uav_id?, params{}}, weather{wind_ms, wind_dir_deg, gust_ms}, rules{}, separation{},
  seed, speed, zones_extra[]
Event types: battery_fault, link_loss, link_degraded, gps_degraded, motor_fault, wind, zone_activate,
             abort_request (workspace-level: coordinator proposes abort recovery options).
"""

from __future__ import annotations

import copy

FIVE = ["HH-001", "HH-002", "HH-003", "HH-004", "HH-005"]
ALL_AREAS = ["A1", "A2", "A3", "A4", "A5"]
SURVEY_PARCEL = [[520, -330], [1720, -330], [1720, 680], [520, 680]]
SURVEY_OPS = {"id": "Z-OPS", "name": "Operational area (facility + survey parcel)", "kind": "operational_area",
              "ring": [[-470, -350], [1760, -350], [1760, 720], [-470, 720]], "alt_min": 0.0, "alt_max": 140.0,
              "rule": "keep_in", "active": True}

BUILTIN = [
    {
        "id": "skygrid-demo", "name": "SKYGRID DEMO — Multi-UAV Industrial Inspection",
        "description": "Five simulated UAVs inspect five areas of an industrial facility. Mid-mission, HH-003 suffers a "
                       "simulated battery fault; SkyGrid detects it, proposes a recovery and reassignment plan for operator "
                       "approval, and the remaining fleet completes the inspection.",
        "uav_ids": FIVE, "mission": {"name": "Facility inspection — 5 areas", "type": "industrial_inspection",
                                     "objective": "Complete thermal, gas and visual inspection of all five facility areas",
                                     "area_ids": ALL_AREAS},
        "events": [{"t": 150.0, "type": "battery_fault", "uav_id": "HH-003", "params": {"soc_drop": 0.62, "drain_mult": 1.6}}],
        "weather": {"wind_ms": 4.0, "wind_dir_deg": 310.0, "gust_ms": 1.5}, "seed": 2026, "speed": 8.0, "featured": True,
    },
    {
        "id": "single-uav", "name": "1 · Single-UAV mission",
        "description": "HH-005 performs a three-altitude orbit inspection of the stack.",
        "uav_ids": ["HH-005"], "mission": {"name": "Stack inspection", "type": "industrial_inspection",
                                           "objective": "Thermal and visual inspection of the stack shell", "area_ids": ["A3"]},
        "events": [], "weather": {"wind_ms": 3.0, "wind_dir_deg": 300.0, "gust_ms": 1.0}, "seed": 11, "speed": 6.0,
    },
    {
        "id": "five-uav-inspection", "name": "2 · Five-UAV coordinated inspection",
        "description": "Nominal coordinated inspection of the five facility areas; no injected faults.",
        "uav_ids": FIVE, "mission": {"name": "Coordinated inspection", "type": "industrial_inspection",
                                     "objective": "Inspect all facility areas", "area_ids": ALL_AREAS},
        "events": [], "weather": {"wind_ms": 3.0, "wind_dir_deg": 300.0, "gust_ms": 1.0}, "seed": 12, "speed": 8.0,
    },
    {
        "id": "ten-uav-survey", "name": "3 · Ten-UAV area survey",
        "description": "A 1.2 km × 1.0 km parcel east of the facility is partitioned into ten non-overlapping, equal-area "
                       "strips, each surveyed with a boustrophedon pattern. Mixed multirotor, fixed-wing and VTOL fleet.",
        "uav_ids": ["HH-001", "HH-002", "HH-003", "HH-004", "HH-005", "HH-006", "HH-007", "HH-008", "HH-009", "HH-010"],
        "mission": {"name": "Parcel survey", "type": "aerial_mapping", "objective": "RGB survey of the east parcel",
                    "coverage": {"ring": SURVEY_PARCEL, "k": 10, "spacing": 70.0, "alt": 70.0, "sensors": ["rgb"], "axis": "y"}},
        "rules": {"allow_standby": True}, "zones_replace": {"Z-OPS": SURVEY_OPS},
        "events": [], "weather": {"wind_ms": 5.0, "wind_dir_deg": 290.0, "gust_ms": 1.5}, "seed": 13, "speed": 12.0,
    },
    {
        "id": "route-conflict", "name": "4 · Multi-UAV route conflict",
        "description": "Three aircraft fly operator-defined routes. HH-001 and HH-002 cross at the same altitude; HH-004 crosses "
                       "20 m higher. The strategic check flags the first pair before launch and the tactical monitor escalates "
                       "alerts with CPA, uncertainty and explanation. SkyGrid advises only; it does not manoeuvre aircraft.",
        "uav_ids": ["HH-001", "HH-002", "HH-004"],
        "mission": {"name": "Crossing routes (conflict demonstration)", "type": "logistics_demonstration",
                    "objective": "Demonstrate conflict prediction"},
        "assignments": [
            {"uav_id": "HH-001", "launch_t": 4.0, "waypoints": [[-380, -100, 40], [-200, 0, 40], [300, 0, 40]]},
            {"uav_id": "HH-002", "launch_t": 0.0, "waypoints": [[-60, -230, 40], [40, -200, 40], [40, 300, 40]]},
            {"uav_id": "HH-004", "launch_t": 10.0, "waypoints": [[-300, -150, 60], [-150, 100, 60], [200, 120, 60]]},
        ],
        "events": [], "weather": {"wind_ms": 2.0, "wind_dir_deg": 300.0, "gust_ms": 0.5}, "seed": 14, "speed": 4.0,
    },
    {
        "id": "low-battery-reassign", "name": "5 · Low-battery mission reassignment",
        "description": "HH-001 develops abnormal battery drain while inspecting the tank farm; SkyGrid proposes returning it "
                       "and redistributing its remaining orbits.",
        "uav_ids": FIVE, "mission": {"name": "Inspection with battery fault", "type": "industrial_inspection",
                                     "objective": "Inspect all facility areas", "area_ids": ALL_AREAS},
        "events": [{"t": 140.0, "type": "battery_fault", "uav_id": "HH-001", "params": {"soc_drop": 0.6, "drain_mult": 1.7}}],
        "weather": {"wind_ms": 4.0, "wind_dir_deg": 300.0, "gust_ms": 1.0}, "seed": 15, "speed": 8.0,
    },
    {
        "id": "comms-loss", "name": "6 · Communication-loss scenario",
        "description": "HH-005 loses its C2 link for 45 s (onboard: hold 20 s, then RTH); HH-002 has a degraded link and "
                       "HH-003 degraded GNSS. The ground track's uncertainty grows while no telemetry arrives.",
        "uav_ids": FIVE, "mission": {"name": "Inspection with link and GNSS faults", "type": "industrial_inspection",
                                     "objective": "Inspect all facility areas", "area_ids": ALL_AREAS},
        "events": [{"t": 110.0, "type": "link_loss", "uav_id": "HH-005", "params": {"duration_s": 45.0}},
                   {"t": 60.0, "type": "link_degraded", "uav_id": "HH-002", "params": {"factor": 0.35, "duration_s": 90.0}},
                   {"t": 90.0, "type": "gps_degraded", "uav_id": "HH-003", "params": {"duration_s": 70.0}}],
        "weather": {"wind_ms": 3.0, "wind_dir_deg": 300.0, "gust_ms": 1.0}, "seed": 16, "speed": 6.0,
    },
    {
        "id": "aircraft-unavailable", "name": "7 · Aircraft unavailable during a mission",
        "description": "HH-002 (the gas-sensor aircraft on the process unit) reports a motor fault and lands; only aircraft "
                       "with a gas sensor are proposed to take over its work.",
        "uav_ids": FIVE, "mission": {"name": "Inspection with aircraft loss", "type": "industrial_inspection",
                                     "objective": "Inspect all facility areas", "area_ids": ALL_AREAS},
        "events": [{"t": 120.0, "type": "motor_fault", "uav_id": "HH-002", "params": {}}],
        "weather": {"wind_ms": 3.0, "wind_dir_deg": 300.0, "gust_ms": 1.0}, "seed": 17, "speed": 8.0,
    },
    {
        "id": "independent-ops", "name": "Independent operations (3 missions)",
        "description": "Three aircraft fly unrelated operator-defined tasks in different areas: LiDAR pass of the process unit, "
                       "a VTOL survey leg over the east parcel, and a logistics demonstration to the laydown yard.",
        "uav_ids": ["HH-007", "HH-010", "HH-012"],
        "mission": {"name": "Independent operations", "type": "logistics_demonstration", "objective": "Separate tasks"},
        "assignments": [
            {"uav_id": "HH-007", "launch_t": 0.0, "waypoints": [[20, 60, 50], [230, 60, 50], [230, 130, 50], [20, 130, 50], [20, 200, 50], [230, 200, 50]]},
            {"uav_id": "HH-010", "launch_t": 5.0, "waypoints": [[600, -250, 90], [1600, -250, 90], [1600, 500, 90], [600, 500, 90]]},
            {"uav_id": "HH-012", "launch_t": 10.0, "waypoints": [[300, -80, 35], [-400, 0, 35], [-420, 300, 35], [-420, 300, 5]]},
        ],
        "zones_replace": {"Z-OPS": SURVEY_OPS},
        "events": [], "weather": {"wind_ms": 3.0, "wind_dir_deg": 300.0, "gust_ms": 1.0}, "seed": 18, "speed": 8.0,
    },
    {
        "id": "mission-interruption", "name": "Mission interruption & recovery",
        "description": "At t = 160 s a site emergency is declared and an abort is requested. SkyGrid presents safe recovery "
                       "options (return to docks, land at nearest safe site, hold) for operator approval.",
        "uav_ids": FIVE, "mission": {"name": "Inspection interrupted", "type": "industrial_inspection",
                                     "objective": "Inspect all facility areas", "area_ids": ALL_AREAS},
        "events": [{"t": 160.0, "type": "abort_request", "params": {"reason": "site emergency declared (simulated)"}}],
        "weather": {"wind_ms": 3.0, "wind_dir_deg": 300.0, "gust_ms": 1.0}, "seed": 19, "speed": 8.0,
    },
]


def builtin_scenarios() -> list[dict]:
    out = copy.deepcopy(BUILTIN)
    for s in out:
        s["builtin"] = True
        s.setdefault("rules", {})
        s.setdefault("separation", {})
    return out


def validate_scenario(s: dict, known_uavs: set[str]) -> list[str]:
    errs = []
    if not s.get("name"):
        errs.append("name is required")
    ids = s.get("uav_ids") or []
    if not ids:
        errs.append("select at least one UAV")
    bad = [u for u in ids if u not in known_uavs]
    if bad:
        errs.append(f"unknown UAVs: {', '.join(bad)}")
    m = s.get("mission") or {}
    if not (m.get("area_ids") or m.get("areas") or m.get("coverage") or s.get("assignments")):
        errs.append("mission needs areas, a coverage polygon or explicit assignments")
    for e in s.get("events", []):
        if e.get("type") not in ("battery_fault", "link_loss", "link_degraded", "gps_degraded", "motor_fault", "wind",
                                 "zone_activate", "abort_request"):
            errs.append(f"unknown event type {e.get('type')}")
        if not isinstance(e.get("t"), (int, float)) or e["t"] < 0:
            errs.append("event time must be >= 0")
        if e.get("type") in ("battery_fault", "link_loss", "link_degraded", "gps_degraded", "motor_fault") and e.get("uav_id") not in ids:
            errs.append(f"event {e.get('type')} targets {e.get('uav_id')}, which is not in the scenario")
    w = s.get("weather", {})
    if w and not (0 <= float(w.get("wind_ms", 0)) <= 25):
        errs.append("wind must be between 0 and 25 m/s")
    return errs
