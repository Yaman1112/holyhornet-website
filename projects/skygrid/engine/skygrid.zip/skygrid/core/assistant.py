"""SkyGrid decision-support analyst (rule-based, deterministic).

Maps an operator question to an analysis over workspace data and returns an answer, the data used and
any recommendation. It cannot approve missions, change routes or command aircraft. The server edition can
optionally put an LLM in front of these same tools (api/ai.py); the browser edition uses this only.
"""

from __future__ import annotations

import re

from . import analytics
from .allocation import allocate
from .catalog import DOCKS
from .scenarios import SURVEY_PARCEL

LIMITS = "Decision support only: recommendations need operator approval. Based on simulated and synthetic data."

INTENTS = [
    ("available", r"\bavailable\b|\bfree\b|\bready\b|new (inspection|mission)"),
    ("low_battery", r"low batt|battery low|batter(y|ies).*(low|below)|\bsoc\b"),
    ("risk", r"risk|danger|riskiest|highest.*(risk|concern)"),
    ("longer", r"longer than|took longer|delay|overran|over-ran|late"),
    ("recommend", r"recommend|suggest|allocat|survey area|assign"),
    ("summary_today", r"summar|today|completed missions|what happened"),
    ("utilization", r"utili[sz]|compare|busiest|least used"),
    ("abnormal", r"abnormal|anomal|unusual|strange|telemetry pattern"),
    ("conflict", r"conflict|separation|close|near miss|cpa"),
    ("maintenance", r"maint|service|due"),
    ("status", r"status|overview|where is|fleet|what is every"),
]


def _intent(q: str) -> str:
    q = q.lower()
    for name, rx in INTENTS:
        if re.search(rx, q):
            return name
    return "help"


def _live(ws):
    out = {}
    if ws.session:
        for a in ws.session.sim.agents.values():
            out[a.id] = {"mode": a.mode, "tel": ws.session.sim.telemetry.get(a.id, {})}
    return out


def answer(ws, question: str) -> dict:
    intent = _intent(question or "")
    fn = globals().get("_a_" + intent, _a_help)
    res = fn(ws, question)
    res.update(intent=intent, engine="SkyGrid rule-based analyst v0.1", limits=LIMITS, question=question)
    return res


def _a_available(ws, q):
    live = _live(ws)
    rows = []
    for u in ws.uavs.values():
        busy = live.get(u["id"], {}).get("mode") not in (None, "parked", "landed")
        ok = u["status"] == "available" and u["maintenance"]["status"] in ("ok", "due_soon") and not busy
        if ok:
            score = u["battery"]["soc"] * u["battery"]["health"] - (0.1 if u["maintenance"]["status"] == "due_soon" else 0)
            rows.append((score, u))
    rows.sort(key=lambda r: -r[0])
    insp = [u for _, u in rows if "inspection" in u["roles"] or u["category"] in ("multirotor", "hybrid_vtol")]
    lines = [f"{u['id']} {u['name']} ({u['model']}) — SoC {u['battery']['soc'] * 100:.0f}%, health {u['battery']['health'] * 100:.0f}%, "
             f"sensors {', '.join(u['sensors'])}, dock {u['home_dock']}" for u in insp]
    excluded = [f"{u['id']}: {u['status']}/{u['maintenance']['status']}" for u in ws.uavs.values() if u not in [x for _, x in rows]]
    return {"answer": f"{len(insp)} aircraft are available and suitable for inspection work." if insp else "No inspection-capable aircraft are available.",
            "items": lines, "data_used": ["fleet registry (status, maintenance, battery, sensors)", "live simulation modes" if live else "no live session"],
            "recommendations": ["Prefer aircraft with thermal sensors for tank and stack work; gas sensor only on " +
                                ", ".join(u["id"] for u in insp if "gas" in u["sensors"])] if insp else [],
            "notes": ["Not available: " + "; ".join(excluded)] if excluded else []}


def _a_low_battery(ws, q):
    live = _live(ws)
    rows = []
    for u in ws.uavs.values():
        tel = live.get(u["id"], {}).get("tel") or {}
        soc = tel.get("soc", u["battery"]["soc"])
        src = "telemetry" if tel else "registry"
        if soc < 0.4 or u["battery"]["health"] < 0.9:
            rows.append(f"{u['id']}: SoC {soc * 100:.0f}% ({src}), battery health {u['battery']['health'] * 100:.0f}%, mode {live.get(u['id'], {}).get('mode', u['status'])}")
    return {"answer": f"{len(rows)} aircraft have SoC below 40% or battery health below 90%." if rows else "No aircraft below 40% SoC or 90% health.",
            "items": rows, "data_used": ["live telemetry SoC" if live else "registry SoC", "battery health from registry"],
            "recommendations": ["Schedule a capacity test for batteries under 90% health"] if rows else []}


def _a_risk(ws, q):
    items, recs = [], []
    if ws.session:
        c = ws.session.coord
        act = [a for a in c.alerts.values() if a["active"]]
        order = ["informational", "advisory", "warning", "critical"]
        act.sort(key=lambda a: -order.index(a["level"]))
        for a in act[:6]:
            items.append(f"[{a['level']}] {a['title']} — {a['detail']}")
        margins = []
        for ag in ws.session.sim.agents.values():
            tel = ws.session.sim.telemetry.get(ag.id)
            if tel and ag.remaining_inspect():
                margins.append((tel["soc"], ag.id))
        margins.sort()
        if margins:
            items.append(f"Lowest battery among aircraft with work remaining: {margins[0][1]} at {margins[0][0] * 100:.0f}%")
        pend = [p for p in c.proposals if p["state"] == "proposed"]
        if pend:
            recs.append(f"Decide on {pend[0]['id']} ({pend[0]['reason']}); recommended {pend[0]['recommended']}")
        head = f"Live mission '{ws.session.mission['name']}' has {len(act)} active alert(s)."
    else:
        head = "No live mission. Ranking planned missions by energy margin and strategic conflicts."
    planned = []
    for m in ws.missions.values():
        if m.get("plan") and m["status"] in ("proposed", "approved"):
            mm = min((a["energy_margin"] for a in m["plan"]["assignments"]), default=1)
            planned.append((len(m["plan"]["strategic"]["conflicts"]) * 0.5 - mm, m, mm))
    planned.sort(key=lambda r: -r[0])
    for _, m, mm in planned[:3]:
        items.append(f"Planned {m['name']}: lowest energy margin {mm * 100:.0f}%, {len(m['plan']['strategic']['conflicts'])} strategic conflict(s), "
                     f"{len(m['plan']['unassigned'])} unassigned task(s)")
    return {"answer": head, "items": items or ["Nothing currently elevated."], "recommendations": recs,
            "data_used": ["active coordinator alerts", "ground-station telemetry", "mission plans (energy margins, strategic check)"]}


def _a_longer(ws, q):
    reps = [r for r in ws.reports.values() if r["summary"].get("planned_makespan_s")]
    if reps:
        r = reps[-1]
        s = r["summary"]
        over = s["duration_s"] - s["planned_makespan_s"]
        causes = []
        for d in r["decisions"]:
            causes.append(f"operator decision at t={d['t']} s: {d['title']}")
        holds = [e for e in r["events"] if e.get("kind") in ("failsafe", "hold", "fault")]
        for e in holds[:5]:
            causes.append(f"t={e['t']} s {e['text']}")
        causes.append(f"wind {s['wind_ms']:.0f} m/s (power model adds drag, ground-speed control holds route timing)")
        return {"answer": f"'{r['mission']['name']}' took {s['duration_s'] / 60:.1f} min against a planned makespan of "
                          f"{s['planned_makespan_s'] / 60:.1f} min ({'+' if over >= 0 else ''}{over / 60:.1f} min).",
                "items": causes, "data_used": ["mission report", "event log", "operator decisions"],
                "recommendations": ["Re-plan with a higher reserve or a standby aircraft if faults recur"] if over > 60 else []}
    hist = sorted(ws.history, key=lambda h: h["actual_min"] - h["planned_min"], reverse=True)[:3]
    return {"answer": "No simulation report yet; largest overruns in the synthetic history:",
            "items": [f"{h['id']} ({h['kind']}): planned {h['planned_min']} min, actual {h['actual_min']} min, outcome {h['outcome']}" for h in hist],
            "data_used": ["synthetic mission history"], "recommendations": ["Run a simulation to get an explained timeline"]}


def _a_recommend(ws, q):
    avail = [u for u in ws.uavs.values() if u["status"] == "available" and "rgb" in u["sensors"]]
    k = max(1, min(len(avail), 6))
    tasks = ws._tasks_from({"coverage": {"ring": SURVEY_PARCEL, "k": k, "spacing": 70.0, "alt": 70.0, "sensors": ["rgb"], "axis": "y"}})
    plan = allocate(avail, tasks, DOCKS, ws.settings["rules"], 3.0)
    items = [f"{a['uav_id']} → {', '.join(a['task_ids'])}: {a['estimate']['time_s'] / 60:.1f} min, {a['estimate']['energy_wh']:.0f} Wh, "
             f"landing margin {a['energy_margin'] * 100:.0f}%" for a in plan["assignments"]]
    items += [f"{u['task_id']} unassigned: {'; '.join(u['reasons'])}" for u in plan["unassigned"]]
    return {"answer": f"For the 1.2 km² east survey parcel split into {k} equal-area strips, the optimiser proposes "
                      f"{len(plan['assignments'])} aircraft with a makespan of {plan['makespan_s'] / 60:.1f} min "
                      f"({plan['method']}, {plan['runtime_ms']} ms).",
            "items": items, "data_used": ["fleet registry", "energy model", "coverage partition of the survey parcel", "allocation rules"],
            "recommendations": ["Create this as a mission in Mission Control to review the full compatibility matrix and approve it"]}


def _a_summary_today(ws, q):
    runs = list(ws.runs.values())
    if runs:
        items = []
        for r in runs:
            m = r["metrics"]
            items.append(f"{ws.missions[r['mission_id']]['name']}: {m['outcome']}, {m['duration_s'] / 60:.1f} min, coverage {m['coverage'] * 100:.0f}%, "
                         f"{m['distance_km']} km, {m['energy_wh']:.0f} Wh, {m['proposals']} proposal(s)")
        return {"answer": f"{len(runs)} simulated mission(s) finished in this session.", "items": items,
                "data_used": ["simulation runs and reports (this session)"], "recommendations": []}
    last = [h for h in ws.history if h["day_offset"] == -1]
    return {"answer": f"No missions finished today in this session. Yesterday (synthetic history): {len(last)} mission(s).",
            "items": [f"{h['kind']}: {h['outcome']}, {h['actual_min']} min, {len(h['uavs'])} UAV(s)" for h in last],
            "data_used": ["synthetic mission history"], "recommendations": ["Run the SkyGrid demo scenario to generate a report"]}


def _a_utilization(ws, q):
    s = analytics.summary(ws)
    pu = [p for p in s["per_uav"]]
    top = pu[:3]
    low = [p for p in pu if ws.uavs[p["uav_id"]]["status"] == "available"][-3:]
    return {"answer": "Aircraft utilisation over the analytics window (share of an 8 h operating day):",
            "items": [f"Most used: {p['uav_id']} {p['hours']} h ({p['utilization'] * 100:.1f}%), {p['flights']} flights" for p in top] +
                     [f"Least used (available): {p['uav_id']} {p['hours']} h ({p['utilization'] * 100:.1f}%)" for p in low],
            "data_used": s["sources"], "recommendations": ["Rotate low-utilisation aircraft into routine inspections to balance airframe hours"]}


def _a_abnormal(ws, q):
    items = []
    if ws.session:
        for a in ws.session.coord.alerts.values():
            if a["type"] in ("energy", "link", "gnss"):
                items.append(f"[{a['level']}{'' if a['active'] else ', cleared'}] {a['title']}: {a['detail']}")
    s = analytics.summary(ws)
    vals = [p["wh_per_km"] for p in s["per_uav"] if p["wh_per_km"]]
    if vals:
        mu = sum(vals) / len(vals)
        sd = (sum((v - mu) ** 2 for v in vals) / len(vals)) ** 0.5 or 1
        for p in s["per_uav"]:
            if p["wh_per_km"] and (p["wh_per_km"] - mu) / sd > 1.5:
                items.append(f"{p['uav_id']} uses {p['wh_per_km']} Wh/km vs fleet mean {mu:.0f} (z = {(p['wh_per_km'] - mu) / sd:.1f}) — note: mixed aircraft types")
    return {"answer": f"{len(items)} telemetry pattern(s) worth reviewing." if items else "No abnormal telemetry patterns detected.",
            "items": items, "data_used": ["coordinator energy/link/GNSS monitors (observed vs. model drain)", "per-aircraft energy per km"],
            "recommendations": []}


def _a_conflict(ws, q):
    if not ws.session:
        plans = [m for m in ws.missions.values() if m.get("plan")]
        items = []
        for m in plans[-3:]:
            st = m["plan"]["strategic"]
            items.append(f"{m['name']}: strategic check {'clear' if st['ok'] else str(len(st['conflicts'])) + ' conflict(s)'} ({st['method']})")
        return {"answer": "No live mission; strategic (pre-flight) checks of recent plans:", "items": items or ["No plans yet."],
                "data_used": ["mission plans"], "recommendations": []}
    seps = [a for a in ws.session.coord.alerts.values() if a["type"] == "separation"]
    items = []
    for a in seps[-6:]:
        e = a["explain"]
        items.append(f"{a['title']} [{a['level']}{'' if a['active'] else ', cleared'}]: CPA {e.get('d_cpa', 0):.0f} m in {e.get('t_cpa', 0):.0f} s, "
                     f"uncertainty σ {e.get('sigma', 0):.0f} m, P(infringe) {e.get('p_infringe', 0) * 100:.0f}%, method: {e.get('method')}")
    return {"answer": f"{len([a for a in seps if a['active']])} active separation alert(s); minimum separation observed "
                      f"{ws.session.coord.min_sep_seen:.0f} m." if seps else "No separation alerts in the live mission.",
            "items": items, "data_used": ["Kalman ground tracks", "uploaded routes (intent)", "separation standard from settings"],
            "recommendations": ["SkyGrid is advisory: resolve conflicts by re-planning or by pausing an aircraft"] if seps else []}


def _a_maintenance(ws, q):
    items = []
    for u in ws.uavs.values():
        mx = u["maintenance"]
        left = mx["next_service_hours"] - mx["flight_hours"]
        if mx["status"] != "ok" or left < 10:
            items.append(f"{u['id']}: {mx['status']}, {mx['flight_hours']:.0f} h, next service at {mx['next_service_hours']:.0f} h ({left:.1f} h left)")
    open_ = [m for m in ws.maintenance.values() if m["status"] in ("open", "scheduled")]
    items += [f"Open record {m['id']} {m['uav_id']}: {m['kind']} ({m['status']}, {m['date']})" for m in open_]
    return {"answer": f"{len(items)} maintenance item(s) need attention.", "items": items,
            "data_used": ["maintenance records", "flight hours"], "recommendations": []}


def _a_status(ws, q):
    d = analytics.dashboard(ws)
    c = d["counts"]
    items = [f"{c['registered']} registered, {c['active']} airborne, {c['standby']} on standby, {c['returning']} returning, {c['attention']} need attention",
             f"Missions: {d['missions']['active']} active, {d['missions']['planned']} planned",
             f"Mean SoC {d['battery']['mean_soc'] * 100:.0f}%" if d["battery"]["mean_soc"] is not None else "No battery data",
             f"Airspace alerts: " + ", ".join(f"{k} {v}" for k, v in d["alerts"].items())]
    if ws.session:
        for a in ws.session.sim.agents.values():
            tel = ws.session.sim.telemetry.get(a.id)
            if tel:
                items.append(f"{a.id}: {a.mode}, task {tel.get('task_id') or '—'}, alt {tel['alt']:.0f} m, SoC {tel['soc'] * 100:.0f}%, link {tel['link'] * 100:.0f}%")
    return {"answer": "Fleet overview (simulation):", "items": items, "data_used": ["dashboard aggregates", "ground-station telemetry"], "recommendations": []}


def _a_help(ws, q):
    return {"answer": "I can analyse fleet status, availability, battery, risk, conflicts, delays, utilisation, abnormal telemetry, "
                      "maintenance, and recommend allocations. Try one of these:",
            "items": ["Which UAVs are available for a new inspection mission?", "Show me aircraft with low battery.",
                      "Which mission has the highest operational risk?", "Why did this mission take longer than planned?",
                      "Recommend a fleet allocation for this survey area.", "Summarize today's completed missions."],
            "data_used": [], "recommendations": []}
