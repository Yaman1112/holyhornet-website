"""Route generation: inspection patterns, area coverage partitioning and route estimates.

All geometry is in the site's local ENU frame (metres). A route is a list of waypoints
``{"e","n","u","kind","task_id","speed"}`` where kind is takeoff | transit | inspect | land.
"""

from __future__ import annotations

import math

from .energy import power_w
from .geo import clip_halfplane, polygon_area

INSPECT_SPEED_FACTOR = 0.7  # inspection legs flown at 70% of cruise


# ------------------------------------------------------------------ patterns
def orbit(center, radius: float, alt: float, laps: float = 1.0, pts_per_lap: int = 16, start_angle: float = 0.0):
    n = max(3, int(round(pts_per_lap * laps)))
    return [(center[0] + radius * math.cos(start_angle + 2 * math.pi * i / pts_per_lap),
             center[1] + radius * math.sin(start_angle + 2 * math.pi * i / pts_per_lap), alt) for i in range(n + 1)]


def lawnmower(ring, spacing: float, alt: float):
    """Boustrophedon sweep with rows parallel to the x (east) axis, clipped to the polygon."""
    ys = [p[1] for p in ring]
    y0, y1 = min(ys), max(ys)
    pts = []
    y = y0 + spacing / 2.0
    flip = False
    while y < y1:
        xs = []
        n = len(ring)
        for i in range(n):
            (xa, ya), (xb, yb) = ring[i][:2], ring[(i + 1) % n][:2]
            if (ya <= y < yb) or (yb <= y < ya):
                xs.append(xa + (y - ya) * (xb - xa) / (yb - ya))
        xs.sort()
        segs = [(xs[i], xs[i + 1]) for i in range(0, len(xs) - 1, 2)]
        if segs:
            a, b = segs[0][0], segs[-1][1]
            inset = min(spacing / 3.0, (b - a) / 4.0)
            a, b = a + inset, b - inset
            pts += [(b, y, alt), (a, y, alt)] if flip else [(a, y, alt), (b, y, alt)]
            flip = not flip
        y += spacing
    return pts


def offset_polyline(line, d: float):
    out = []
    n = len(line)
    for i in range(n):
        nx = ny = 0.0
        for j in (i - 1, i):
            if 0 <= j < n - 1:
                dx, dy = line[j + 1][0] - line[j][0], line[j + 1][1] - line[j][1]
                L = math.hypot(dx, dy) or 1.0
                nx += -dy / L
                ny += dx / L
        L = math.hypot(nx, ny) or 1.0
        out.append((line[i][0] + d * nx / L, line[i][1] + d * ny / L))
    return out


def corridor(line, offset: float, alt: float):
    out = [(x, y, alt) for x, y in offset_polyline(line, offset)]
    back = [(x, y, alt) for x, y in offset_polyline(line, -offset)][::-1]
    return out + back


def task_points(task: dict, entry=None):
    """Inspection waypoints for a task. ``entry`` (e, n) lets orbits start at the nearest point."""
    p = task["params"]
    kind = task["pattern"]
    if kind == "lawnmower":
        if p.get("axis") == "y":  # rows parallel to north: sweep in swapped coordinates
            pts = lawnmower([[q[1], q[0]] for q in task["ring"]], p["spacing"], p["alt"])
            return [(y, x, u) for x, y, u in pts]
        return lawnmower(task["ring"], p["spacing"], p["alt"])
    if kind == "corridor":
        return corridor(p["line"], p["offset"], p["alt"])
    if kind == "orbit":
        c = p["center"]
        a0 = math.atan2(entry[1] - c[1], entry[0] - c[0]) if entry else 0.0
        pts = []
        for alt in p.get("alts", [p.get("alt", 40.0)]):
            pts += orbit(c, p["radius"], alt, 1.0, 16, a0)
        return pts
    if kind == "multi_orbit":
        centers = [tuple(c) for c in p["centers"]]
        pos = entry or centers[0]
        pts = []
        while centers:
            c = min(centers, key=lambda q: math.hypot(q[0] - pos[0], q[1] - pos[1]))
            centers.remove(c)
            a0 = math.atan2(pos[1] - c[1], pos[0] - c[0])
            ring = orbit(c, p["radius"], p["alt"], 1.0, 14, a0)
            pts += ring
            pos = ring[-1]
        return pts
    if kind == "waypoints":
        return [tuple(w) for w in p["points"]]
    raise ValueError(f"unknown pattern {kind}")


# ------------------------------------------------------------------ coverage partition
def area_left_of(ring, x: float) -> float:
    c = clip_halfplane(ring, 0, x, True)
    return polygon_area(c) if len(c) >= 3 else 0.0


def partition_polygon(ring, k: int):
    """Split a polygon into k non-overlapping vertical strips of equal area (bisection on each cut)."""
    total = polygon_area(ring)
    xs = [p[0] for p in ring]
    lo_x, hi_x = min(xs), max(xs)
    cuts = [lo_x]
    for i in range(1, k):
        target = total * i / k
        lo, hi = cuts[-1], hi_x
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if area_left_of(ring, mid) < target:
                lo = mid
            else:
                hi = mid
        cuts.append(0.5 * (lo + hi))
    cuts.append(hi_x)
    parts = []
    for i in range(k):
        r = clip_halfplane(ring, 0, cuts[i], False)
        r = clip_halfplane(r, 0, cuts[i + 1], True)
        parts.append([[round(a, 3), round(b, 3)] for a, b in r])
    return parts


# ------------------------------------------------------------------ routes
def build_route(spec: dict, home: tuple, tasks: list[dict], transit_alt: float, start=None, zones=None):
    """home=(e,n). Returns waypoints: takeoff, transit, inspect..., transit home, land.

    ``start`` (e, n, u) begins the route in the air (used for reassignment while flying)."""
    cruise = spec["cruise_ms"]
    insp = cruise * INSPECT_SPEED_FACTOR if spec["category"] != "fixed_wing" else cruise
    wps = []
    if start is None:
        wps.append({"e": home[0], "n": home[1], "u": transit_alt, "kind": "takeoff", "task_id": None, "speed": spec["climb_ms"]})
        pos = (home[0], home[1])
    else:
        pos = (start[0], start[1])
    for t in tasks:
        pts = task_points(t, entry=pos)
        if not pts:
            continue
        wps.append({"e": pts[0][0], "n": pts[0][1], "u": transit_alt, "kind": "transit", "task_id": t["id"], "speed": cruise})
        for i, p in enumerate(pts):
            wps.append({"e": p[0], "n": p[1], "u": p[2], "kind": "inspect", "task_id": t["id"], "speed": insp, "idx": i})
        pos = (pts[-1][0], pts[-1][1])
        wps.append({"e": pos[0], "n": pos[1], "u": transit_alt, "kind": "transit", "task_id": t["id"], "speed": cruise})
    wps.append({"e": home[0], "n": home[1], "u": transit_alt, "kind": "transit", "task_id": None, "speed": cruise})
    wps.append({"e": home[0], "n": home[1], "u": 0.0, "kind": "land", "task_id": None, "speed": spec["descent_ms"]})
    return apply_detours(wps, zones, start=start if start is not None else (home[0], home[1], transit_alt))


def estimate(spec: dict, wps: list[dict], start=None, payload_kg: float = 0.0, wind: float = 0.0) -> dict:
    """Length, time and energy of a route with the same power model the simulator uses."""
    if not wps:
        return {"length_m": 0.0, "time_s": 0.0, "energy_wh": 0.0}
    prev = start if start is not None else (wps[0]["e"], wps[0]["n"], 0.0)
    L = T = E = 0.0
    for w in wps:
        dh = math.hypot(w["e"] - prev[0], w["n"] - prev[1])
        dv = w["u"] - prev[2]
        if dh < 1e-6 and abs(dv) < 1e-6:
            prev = (w["e"], w["n"], w["u"])
            continue
        v = max(w["speed"], 0.5)
        vz_rate = spec["climb_ms"] if dv > 0 else spec["descent_ms"]
        t = max(dh / v, abs(dv) / vz_rate)
        vh = dh / t if t > 0 else 0.0
        vz = dv / t if t > 0 else 0.0
        hovering = dh < 1.0
        if spec["category"] == "fixed_wing":
            vh = max(vh, spec.get("vmin_ms", 0))
        p = power_w(spec, vh, vz, wind, payload_kg, hovering=hovering)
        L += math.sqrt(dh * dh + dv * dv)
        T += t + 1.0  # small turn/settle allowance per waypoint
        E += p * (t + 1.0) / 3600.0
        prev = (w["e"], w["n"], w["u"])
    return {"length_m": L, "time_s": T, "energy_wh": E}


def time_parameterize(spec: dict, wps: list[dict], t0: float = 0.0, start=None):
    """[(t, e, n, u)] at each waypoint, using the same timing as ``estimate``."""
    out = []
    prev = start if start is not None else (wps[0]["e"], wps[0]["n"], 0.0)
    t = t0
    out.append((t, prev[0], prev[1], prev[2]))
    for w in wps:
        dh = math.hypot(w["e"] - prev[0], w["n"] - prev[1])
        dv = w["u"] - prev[2]
        if dh < 1e-6 and abs(dv) < 1e-6:
            continue
        v = max(w["speed"], 0.5)
        vz_rate = spec["climb_ms"] if dv > 0 else spec["descent_ms"]
        t += max(dh / v, abs(dv) / vz_rate) + 1.0
        prev = (w["e"], w["n"], w["u"])
        out.append((t, prev[0], prev[1], prev[2]))
    return out


# ------------------------------------------------------------------ restricted-zone avoidance
def _seg_intersect(p1, p2, q1, q2) -> bool:
    def orient(a, b, c):
        return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
    d1, d2 = orient(q1, q2, p1), orient(q1, q2, p2)
    d3, d4 = orient(p1, p2, q1), orient(p1, p2, q2)
    return (d1 * d2 < 0) and (d3 * d4 < 0)


def segment_hits(a, b, ring) -> bool:
    from .geo import point_in_polygon
    if point_in_polygon(a[0], a[1], ring) or point_in_polygon(b[0], b[1], ring):
        return True
    n = len(ring)
    return any(_seg_intersect(a, b, ring[i], ring[(i + 1) % n]) for i in range(n))


def detour(a, b, alt: float, zones, margin: float = 30.0, depth: int = 0):
    """Intermediate (e, n) points so that the leg a->b at ``alt`` avoids no-fly zones.

    Goes around the zone's bounding box (expanded by ``margin``) on the shorter side. Zones that contain
    a or b are ignored (the leg starts or ends inside: that is reported by the monitor, not hidden)."""
    from .geo import point_in_polygon
    if depth > 3:
        return []
    for z in zones or []:
        if z.get("rule") != "no_fly" or not z.get("active", True) or not (z["alt_min"] <= alt <= z["alt_max"]):
            continue
        ring = z["ring"]
        if point_in_polygon(a[0], a[1], ring) or point_in_polygon(b[0], b[1], ring) or not segment_hits(a, b, ring):
            continue
        xs, ys = [p[0] for p in ring], [p[1] for p in ring]
        x0, x1, y0, y1 = min(xs) - margin, max(xs) + margin, min(ys) - margin, max(ys) + margin
        c = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
        cands = [[c[i]] for i in range(4)] + [[c[i], c[(i + 1) % 4]] for i in range(4)] + [[c[(i + 1) % 4], c[i]] for i in range(4)]
        best = None
        for path in cands:
            pts = [a, *path, b]
            if any(segment_hits(pts[k], pts[k + 1], ring) for k in range(len(pts) - 1)):
                continue
            L = sum(math.hypot(pts[k + 1][0] - pts[k][0], pts[k + 1][1] - pts[k][1]) for k in range(len(pts) - 1))
            if best is None or L < best[0]:
                best = (L, path)
        if best is None:
            continue
        out = []
        pts = [a, *best[1], b]
        for k in range(len(pts) - 1):
            out += detour(pts[k], pts[k + 1], alt, zones, margin, depth + 1)
            if k < len(pts) - 2:
                out.append(pts[k + 1])
        return out
    return []


def apply_detours(wps: list[dict], zones, start=None) -> list[dict]:
    """Insert detour waypoints into transit/landing legs that would cross a no-fly zone."""
    if not zones or not wps:
        return wps
    out = []
    prev = start if start is not None else (wps[0]["e"], wps[0]["n"], wps[0]["u"])
    for w in wps:
        if w["kind"] in ("transit", "land"):
            alt = max(prev[2], w["u"])
            for p in detour((prev[0], prev[1]), (w["e"], w["n"]), alt, zones):
                out.append({"e": p[0], "n": p[1], "u": alt, "kind": "transit", "task_id": None,
                            "speed": w["speed"] if w["kind"] == "transit" else 8.0, "detour": True})
        out.append(w)
        prev = (w["e"], w["n"], w["u"])
    return out
