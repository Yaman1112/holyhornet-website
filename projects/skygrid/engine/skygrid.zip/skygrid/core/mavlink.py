"""Minimal, read-only MAVLink v1/v2 telemetry codec (no command messages).

Decodes HEARTBEAT, SYS_STATUS, GPS_RAW_INT, ATTITUDE, GLOBAL_POSITION_INT and VFR_HUD with CRC
(X.25 / MCRF4XX + CRC_EXTRA) checking and MAVLink 2 zero-truncation. ``encode`` exists only to build test
fixtures and loopback self-tests; SkyGrid has no uplink. Field layouts follow the common.xml wire order
(fields sorted by size), cross-checked against pymavlink in tests when it is installed.
"""

from __future__ import annotations

import math
import struct

MSGS = {
    0: ("HEARTBEAT", "<IBBBBB", 50, ["custom_mode", "type", "autopilot", "base_mode", "system_status", "mavlink_version"]),
    1: ("SYS_STATUS", "<IIIHHhHHHHHHb", 124, ["sensors_present", "sensors_enabled", "sensors_health", "load", "voltage_battery",
                                              "current_battery", "drop_rate_comm", "errors_comm", "errors_count1", "errors_count2",
                                              "errors_count3", "errors_count4", "battery_remaining"]),
    24: ("GPS_RAW_INT", "<QiiiHHHHBB", 24, ["time_usec", "lat", "lon", "alt", "eph", "epv", "vel", "cog", "fix_type", "satellites_visible"]),
    30: ("ATTITUDE", "<Iffffff", 39, ["time_boot_ms", "roll", "pitch", "yaw", "rollspeed", "pitchspeed", "yawspeed"]),
    33: ("GLOBAL_POSITION_INT", "<IiiiihhhH", 104, ["time_boot_ms", "lat", "lon", "alt", "relative_alt", "vx", "vy", "vz", "hdg"]),
    74: ("VFR_HUD", "<ffffhH", 20, ["airspeed", "groundspeed", "alt", "climb", "heading", "throttle"]),
}
NAME_TO_ID = {v[0]: k for k, v in MSGS.items()}


def crc_x25(data: bytes, crc: int = 0xFFFF) -> int:
    for b in data:
        tmp = b ^ (crc & 0xFF)
        tmp = (tmp ^ (tmp << 4)) & 0xFF
        crc = ((crc >> 8) ^ (tmp << 8) ^ (tmp << 3) ^ (tmp >> 4)) & 0xFFFF
    return crc


def encode(name: str, fields: dict, sysid: int = 1, compid: int = 1, seq: int = 0, v2: bool = True) -> bytes:
    mid = NAME_TO_ID[name]
    _, fmt, extra, keys = MSGS[mid]
    payload = struct.pack(fmt, *[fields.get(k, 0) for k in keys])
    if v2:
        payload = payload.rstrip(b"\x00") or b"\x00"
        hdr = bytes([len(payload), 0, 0, seq & 0xFF, sysid, compid]) + struct.pack("<I", mid)[:3]
        crc = crc_x25(hdr + payload + bytes([extra]))
        return b"\xfd" + hdr + payload + struct.pack("<H", crc)
    hdr = bytes([len(payload), seq & 0xFF, sysid, compid, mid])
    crc = crc_x25(hdr + payload + bytes([extra]))
    return b"\xfe" + hdr + payload + struct.pack("<H", crc)


class Parser:
    """Stream parser: feed bytes, get decoded messages. Counts CRC failures and unknown messages."""

    def __init__(self):
        self.buf = bytearray()
        self.crc_errors = 0
        self.unknown = 0

    def feed(self, data: bytes) -> list[dict]:
        self.buf += data
        out = []
        while True:
            i = next((k for k, b in enumerate(self.buf) if b in (0xFD, 0xFE)), None)
            if i is None:
                self.buf.clear()
                return out
            del self.buf[:i]
            if len(self.buf) < 8:
                return out
            v2 = self.buf[0] == 0xFD
            n = self.buf[1]
            if v2:
                sig = 13 if self.buf[2] & 0x01 else 0
                total = 10 + n + 2 + sig
                if len(self.buf) < total:
                    return out
                hdr = bytes(self.buf[1:10])
                mid = int.from_bytes(self.buf[7:10], "little")
                sysid, compid, seq = self.buf[5], self.buf[6], self.buf[4]
                payload = bytes(self.buf[10:10 + n])
                crc = struct.unpack("<H", self.buf[10 + n:12 + n])[0]
            else:
                total = 6 + n + 2
                if len(self.buf) < total:
                    return out
                hdr = bytes(self.buf[1:6])
                mid = self.buf[5]
                sysid, compid, seq = self.buf[3], self.buf[4], self.buf[2]
                payload = bytes(self.buf[6:6 + n])
                crc = struct.unpack("<H", self.buf[6 + n:8 + n])[0]
            spec = MSGS.get(mid)
            if spec is None:
                self.unknown += 1
                del self.buf[:total]
                continue
            name, fmt, extra, keys = spec
            if crc_x25(hdr + payload + bytes([extra])) != crc:
                self.crc_errors += 1
                del self.buf[:1]  # resync
                continue
            size = struct.calcsize(fmt)
            p = payload[:size].ljust(size, b"\x00")
            vals = struct.unpack(fmt, p)
            out.append({"name": name, "sysid": sysid, "compid": compid, "seq": seq, **dict(zip(keys, vals))})
            del self.buf[:total]


PX4_MAIN = {1: "MANUAL", 2: "ALTCTL", 3: "POSCTL", 4: "AUTO", 5: "ACRO", 6: "OFFBOARD", 7: "STABILIZED", 8: "RATTITUDE"}
PX4_AUTO = {1: "READY", 2: "TAKEOFF", 3: "LOITER", 4: "MISSION", 5: "RTL", 6: "LAND", 8: "FOLLOW", 9: "PRECLAND"}
ARDUCOPTER = {0: "STABILIZE", 1: "ACRO", 2: "ALT_HOLD", 3: "AUTO", 4: "GUIDED", 5: "LOITER", 6: "RTL", 7: "CIRCLE", 9: "LAND",
              16: "POSHOLD", 17: "BRAKE", 21: "SMART_RTL"}


def flight_mode(autopilot: int, custom_mode: int) -> str:
    if autopilot == 12:  # MAV_AUTOPILOT_PX4
        main = (custom_mode >> 16) & 0xFF
        sub = (custom_mode >> 24) & 0xFF
        m = PX4_MAIN.get(main, f"PX4_{main}")
        return f"AUTO.{PX4_AUTO.get(sub, sub)}" if main == 4 else m
    if autopilot == 3:  # MAV_AUTOPILOT_ARDUPILOTMEGA (copter numbering)
        return ARDUCOPTER.get(custom_mode, f"APM_{custom_mode}")
    return f"MODE_{custom_mode}"


class TelemetryState:
    """Folds decoded messages into SkyGrid's telemetry fields for one system id."""

    def __init__(self, sysid: int):
        self.sysid = sysid
        self.t: dict = {"sysid": sysid}

    def update(self, m: dict, rx_time: float):
        t = self.t
        n = m["name"]
        if n == "HEARTBEAT":
            t["armed"] = bool(m["base_mode"] & 0x80)
            t["mode"] = flight_mode(m["autopilot"], m["custom_mode"])
            t["autopilot"] = {12: "PX4", 3: "ArduPilot"}.get(m["autopilot"], str(m["autopilot"]))
        elif n == "SYS_STATUS":
            t["batt_v"] = m["voltage_battery"] / 1000.0 if m["voltage_battery"] != 0xFFFF else None
            t["batt_a"] = m["current_battery"] / 100.0 if m["current_battery"] != -1 else None
            t["soc"] = m["battery_remaining"] / 100.0 if m["battery_remaining"] >= 0 else None
        elif n == "GPS_RAW_INT":
            t["gps_fix"] = {0: "none", 1: "none", 2: "2D", 3: "3D", 4: "DGPS", 5: "RTK float", 6: "RTK fixed"}.get(m["fix_type"], str(m["fix_type"]))
            t["sats"] = m["satellites_visible"] if m["satellites_visible"] != 255 else None
            t["hdop"] = m["eph"] / 100.0 if m["eph"] != 0xFFFF else None
        elif n == "ATTITUDE":
            t["roll"], t["pitch"] = math.degrees(m["roll"]), math.degrees(m["pitch"])
            t["yaw"] = (math.degrees(m["yaw"]) + 360) % 360
        elif n == "GLOBAL_POSITION_INT":
            t["lat"], t["lon"] = m["lat"] / 1e7, m["lon"] / 1e7
            t["alt_msl"], t["alt"] = m["alt"] / 1000.0, m["relative_alt"] / 1000.0
            t["gs"] = math.hypot(m["vx"], m["vy"]) / 100.0
            t["vs"] = -m["vz"] / 100.0
            if m["hdg"] != 0xFFFF:
                t["hdg"] = m["hdg"] / 100.0
        elif n == "VFR_HUD":
            t["airspeed"] = m["airspeed"]
            t["throttle"] = m["throttle"]
        t["t_rx"] = rx_time
        return t
