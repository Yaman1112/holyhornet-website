"""Centralised fleet coordination: monitoring, alerts and recovery proposals.

The coordinator only uses ground-station information (received telemetry + Kalman tracks) — never the
simulator's ground truth — and never commands aircraft by itself. It raises alerts and builds proposals;
a proposal changes routes only after an authorised operator approves it (``apply_option``).
Decentralised coordination can later replace ``tick`` per agent using the same broadcastable inputs.
"""

from __future__ import annotations

import math

import numpy as np

from .conflict import DEFAULT_SEPARATION, LEVELS, in_terminal, classify, intent_min_separation, sample_path, tactical_pair, zone_status
from .energy import usable_wh
from .planning import build_route, estimate, time_parameterize


class Coordinator:
    def __init__(self, docks: list[dict], emergency_sites: list[dict], sep_cfg: dict | None = None,
                 reserve_fraction: float = 0.25, mission_id: str | None = None):
        self.docks = docks
        self.emergency = emergency_sites
        self.cfg = {**DEFAULT_SEPARATION, **(sep_cfg or {})}
        self.reserve = reserve_fraction
        self.mission_id = mission_id
        self.next_t = 0.5
        self.alerts: dict[str, dict] = {}
        self.alert_history: list[dict] = []
        self.proposals: list[dict] = []
        self.handled: set[str] = set()
        self.decisions: list[dict] = []
        self.soc_hist: dict[str, list] = {}
        self.min_sep_seen = math.inf
        self.mission_state = "executing"

    # ------------------------------------------------------------ alerts
    def _raise(self, sim, key, typ, level, title, detail, uavs, explain=None):
        a = self.alerts.get(key)
        if a is None:
            a = {"id": key, "type": typ, "level": level, "title": title, "detail": detail, "uavs": uavs,
                 "t_first": round(sim.t, 1), "t_last": round(sim.t, 1), "explain": explain or {}, "source": "simulation",
                 "peak": level, "peak_detail": detail, "active": True}
            self.alerts[key] = a
            sim.log("alert", f"[{level.upper()}] {title}: {detail}", uavs[0] if uavs else None, level)
        else:
            if LEVELS.index(level) > LEVELS.index(a["peak"]):
                a["peak"] = level
                a["peak_detail"] = detail
                sim.log("alert", f"[{level.upper()}] {title}: {detail}", uavs[0] if uavs else None, level)
            a.update(level=level, detail=detail, title=title, t_last=round(sim.t, 1), explain=explain or a["explain"], active=True)
        self._seen.add(key)

    def tick(self, sim):
        self._seen: set[str] = set()
        est = sim.ground_estimates()
        cfg = self.cfg
        airborne = {i: e for i, e in est.items() if e["pos"][2] > cfg["terminal_alt_m"] and sim.agents[i].mode not in ("landed", "parked", "failed")}
        paths = {i: self._predict(sim, i, e) for i, e in airborne.items()}

        # -------- separation (all pairs)
        ids = sorted(airborne)
        for x in range(len(ids)):
            for y in range(x + 1, len(ids)):
                a, b = airborne[ids[x]], airborne[ids[y]]
                if in_terminal(a["pos"], cfg) and in_terminal(b["pos"], cfg):
                    continue  # both inside a dock terminal area: pad sequencing separates them
                m = tactical_pair(a, b, cfg)
                self.min_sep_seen = min(self.min_sep_seen, m["d_now"]) if abs(m["rel_pos"][2]) < cfg["vertical_m"] else self.min_sep_seen
                pa, pb = paths[ids[x]], paths[ids[y]]
                method = "constant-velocity CPA"
                level = classify(m, cfg)
                if pa["intent"] and pb["intent"]:
                    d, tr, dz = intent_min_separation(pa["path"], pb["path"], cfg)
                    m.update(intent_d_min=None if d == math.inf else round(d, 1), intent_t=tr)
                    method = "intent (uploaded routes), CV-CPA shown for reference"
                    level = None
                    H = cfg["horizontal_m"]
                    if d < 0.5 * H and tr <= cfg["critical"]["t_s"]:
                        level = "critical"
                    elif d < H and tr <= cfg["warning"]["t_s"]:
                        level = "warning"
                    elif d < H:
                        level = "advisory"
                    elif d < cfg["info_factor"] * H:
                        level = "informational"
                    if m["d_now"] < 0.5 * H and abs(m["rel_pos"][2]) < cfg["vertical_m"]:
                        level = "critical"
                if level:
                    key = f"sep:{ids[x]}:{ids[y]}"
                    det = (f"CPA {m['d_cpa']:.0f} m in {m['t_cpa']:.0f} s (σ {m['sigma']:.0f} m, P {m['p_infringe'] * 100:.0f}%)"
                           + (f"; route-based min {m['intent_d_min']:.0f} m in {m['intent_t']:.0f} s" if m.get("intent_d_min") is not None else ""))
                    self._raise(sim, key, "separation", level, f"{ids[x]} / {ids[y]} separation", det, [ids[x], ids[y]],
                                {**{k: (round(v, 2) if isinstance(v, float) else v) for k, v in m.items()},
                                 "method": method, "standard": {"horizontal_m": cfg["horizontal_m"], "vertical_m": cfg["vertical_m"]},
                                 "pos_a": [round(float(q), 1) for q in a["pos"]], "pos_b": [round(float(q), 1) for q in b["pos"]],
                                 "vel_a": [round(float(q), 2) for q in a["vel"]], "vel_b": [round(float(q), 2) for q in b["vel"]],
                                 "data_age_s": [round(a["age"], 1), round(b["age"], 1)]})

        # -------- zones
        for i, e in airborne.items():
            if e["age"] > cfg["lost_s"]:
                continue  # no current data: the link alert carries the uncertainty instead of guessing zone status
            for z in sim.zones:
                r = zone_status(e["pos"], paths[i]["path"], z, sim.t)
                if r:
                    self._raise(sim, f"zone:{i}:{z['id']}", "zone", r[0], f"{i} · {z['name']}", r[1], [i],
                                {"zone_id": z["id"], "zone_source": z.get("source", "operator-defined"),
                                 "zone_timestamp": z.get("source_timestamp"), "pos": [round(float(q), 1) for q in e["pos"]],
                                 "method": "intent path" if paths[i]["intent"] else "constant-velocity path, 30 s"})

        # -------- link / gnss / energy
        for i, e in est.items():
            ag = sim.agents[i]
            tel = sim.telemetry.get(i, {})
            if ag.mode in ("parked",) and not ag.route:
                continue
            if tel.get("mode") in ("landed",) and e["age"] < cfg["lost_s"]:
                continue
            if e["age"] > cfg["lost_s"]:
                pol = ag.uav.get("contingency", {})
                self._raise(sim, f"link:{i}", "link", "warning", f"{i} C2 link lost",
                            f"no telemetry for {e['age']:.0f} s; position uncertainty 1σ {e['sigma']:.0f} m; configured onboard "
                            f"contingency: {pol.get('link_loss', 'hold_then_rth')} (timeout {pol.get('link_loss_timeout_s', 5):.0f} s, "
                            f"hold {pol.get('hold_s', 20):.0f} s)", [i],
                            {"age_s": round(e["age"], 1), "sigma_m": round(e["sigma"], 1), "last_mode": tel.get("mode"),
                             "method": "Kalman prediction without updates — uncertainty grows with time"})
            elif e["age"] > cfg["stale_s"]:
                self._raise(sim, f"link:{i}", "link", "advisory", f"{i} telemetry stale", f"last update {e['age']:.1f} s ago", [i],
                            {"age_s": round(e["age"], 1), "sigma_m": round(e["sigma"], 1)})
            elif tel.get("link", 1) < 0.45 and tel:
                self._raise(sim, f"link:{i}", "link", "advisory", f"{i} link degraded", f"link quality {tel['link'] * 100:.0f}%", [i],
                            {"link": tel["link"], "received": sim.tel_count[i][1], "sent": sim.tel_count[i][0]})
            if tel and (tel.get("sats", 20) < 6 or tel.get("hdop", 0) > 2.0) and e["pos"][2] > 2:
                self._raise(sim, f"gnss:{i}", "gnss", "warning" if tel.get("gps_fix") == "2D" else "advisory",
                            f"{i} GNSS degraded", f"{tel.get('sats')} satellites, HDOP {tel.get('hdop')}, fix {tel.get('gps_fix')}", [i],
                            {"sats": tel.get("sats"), "hdop": tel.get("hdop"), "sigma_m": round(e["sigma"], 1)})
            if tel:
                self._energy(sim, i, ag, tel, e)
            if ag.fault and i not in self.handled:
                self._raise(sim, f"fault:{i}", "system", "critical", f"{i} unavailable", "motor fault reported; aircraft performing emergency landing", [i])
                self._propose_recovery(sim, i, "aircraft unavailable (motor fault)")
            if ag.failsafe in ("link_rth",) and ag.remaining_work and i not in self.handled:
                self._propose_recovery(sim, i, "aircraft left mission on link-loss failsafe")

        for k, a in self.alerts.items():
            if k not in self._seen and a["active"]:
                a["active"] = False
                a["t_cleared"] = round(sim.t, 1)
                self.alert_history.append(dict(a))
        self._progress(sim)

    def _energy(self, sim, i, ag, tel, e):
        h = self.soc_hist.setdefault(i, [])
        h.append((sim.t, tel["soc"], tel.get("power_w", 0)))
        while h and sim.t - h[0][0] > 30:
            h.pop(0)
        if ag.mode in ("mission", "transit") and len(h) > 20 and h[-1][0] - h[0][0] > 20:
            rate = (h[0][1] - h[-1][1]) / (h[-1][0] - h[0][0]) * ag.cap_wh * 3600  # W implied by SoC decline
            measured = max(sum(x[2] for x in h) / len(h), 1)  # mean V*I from telemetry over the same window
            if rate > 1.35 * measured:
                self._raise(sim, f"drain:{i}", "energy", "advisory", f"{i} abnormal battery drain",
                            f"SoC falling at {rate:.0f} W-equivalent while V·I reads {measured:.0f} W (×{rate / measured:.1f})", [i],
                            {"soc_rate_w": round(rate), "measured_w": round(measured), "window_s": 30,
                             "method": "SoC decline rate vs measured electrical power over 30 s"})
        if ag.mode not in ("mission", "transit") or i in self.handled:
            return
        rem = ag.remaining_inspect()
        if not rem:
            return
        start = (float(e["pos"][0]), float(e["pos"][1]), float(e["pos"][2]))
        rest = ag.route[ag.idx:]
        need = estimate(ag.spec, rest, start=start, payload_kg=ag.uav["payload"]["mass_kg"])["energy_wh"]
        avail = tel["soc"] * ag.cap_wh
        reserve = self.reserve * ag.cap_wh
        if avail < need + reserve:
            self._raise(sim, f"energy:{i}", "energy", "warning", f"{i} insufficient energy to complete task",
                        f"needs {need:.0f} Wh + {reserve:.0f} Wh reserve, has {avail:.0f} Wh ({tel['soc'] * 100:.0f}%)", [i],
                        {"need_wh": round(need, 1), "reserve_wh": round(reserve, 1), "available_wh": round(avail, 1),
                         "remaining_waypoints": len(rem), "method": "same power model as planning, from the ground estimate"})
            self._propose_recovery(sim, i, f"insufficient energy: needs {need:.0f}+{reserve:.0f} Wh, has {avail:.0f} Wh")

    # ------------------------------------------------------------ prediction
    def _predict(self, sim, i, e):
        ag = sim.agents[i]
        tel = sim.telemetry.get(i, {})
        H = self.cfg["horizon_s"]
        conforming = e["age"] < self.cfg["stale_s"] and ag.mode in ("takeoff", "transit", "mission", "rth", "landing") and ag.idx < len(ag.route)
        if conforming:
            start = tuple(float(x) for x in e["pos"])
            tp = time_parameterize(ag.spec, ag.route[ag.idx:], sim.t, start=start)
            if ag.mode == "paused" or tel.get("mode") == "hold":
                tp = [(sim.t, *start)]
            return {"intent": True, "path": sample_path(tp, sim.t, sim.t + H, 2.0)}
        p, v = e["pos"], e["vel"]
        return {"intent": False, "path": [(sim.t + k, float(p[0] + v[0] * k), float(p[1] + v[1] * k), float(p[2] + v[2] * k)) for k in range(0, 31, 2)]}

    # ------------------------------------------------------------ recovery proposals
    def _nearest_landing(self, ag, pos, energy_avail):
        cands = [("dock", d) for d in self.docks] + [("emergency", s) for s in self.emergency]
        best = None
        for kind, s in cands:
            dist = math.hypot(s["e"] - pos[0], s["n"] - pos[1])
            need = estimate(ag.spec, ag.rth_route((s["e"], s["n"])), start=tuple(pos))["energy_wh"]
            home = kind == "dock" and math.hypot(s["e"] - ag.home[0], s["n"] - ag.home[1]) < 15
            score = (0 if home else (1 if kind == "dock" else 2), dist) if need < energy_avail * 0.9 else (3, dist)
            if best is None or score < best[0]:
                best = (score, kind, s, need)
        return best

    def _propose_recovery(self, sim, i, reason):
        self.handled.add(i)
        ag = sim.agents[i]
        e = sim.ground_estimates().get(i)
        pos = tuple(float(x) for x in (e["pos"] if e is not None else ag.pos))
        tel = sim.telemetry.get(i, {"soc": ag.soc})
        avail = tel["soc"] * ag.cap_wh
        work = ag.remaining_work or ag.remaining_inspect()
        task_ids = sorted({w["task_id"] for w in work if w.get("task_id")})
        land = self._nearest_landing(ag, pos, avail)
        home_action = None
        if not ag.fault and land:
            home_action = {"uav_id": i, "action": "rth", "target": land[2]["id"], "target_e": land[2]["e"], "target_n": land[2]["n"],
                           "text": f"{i}: return to {land[2]['name']} ({math.hypot(land[2]['e'] - pos[0], land[2]['n'] - pos[1]):.0f} m, ~{land[3]:.0f} Wh)"}
        options = []
        cands = []
        for cid, c in sim.agents.items():
            if cid == i or c.fault or c.failsafe or cid in self.handled:
                continue
            if c.mode in ("failed", "emergency_landing"):
                continue
            missing = [s for t in task_ids for s in self._task_sensors(sim, t) if s not in c.uav["sensors"]]
            if missing:
                continue
            ctel = sim.telemetry.get(cid)
            if c.mode in ("parked", "landed") and (c.uav["status"] != "available"):
                continue
            cands.append(c)
        for c in cands:
            plan = self._append_work(c, work)
            if plan:
                options.append({"kind": "reassign", "to": [c.id], **plan})
        options.sort(key=lambda o: (-1 if o["min_margin"] >= 0 else 0, o["finish_s"]), reverse=False)
        options.sort(key=lambda o: (o["min_margin"] < 0, o["finish_s"]))
        out = []
        if options:
            best = options[0]
            out.append(best)
        if len(work) >= 4 and len(cands) >= 2:
            feas = [o for o in options if o["min_margin"] >= 0][:2]
            if len(feas) == 2:
                half = len(work) // 2
                a = next(c for c in cands if c.id == feas[0]["to"][0])
                b = next(c for c in cands if c.id == feas[1]["to"][0])
                pa = self._append_work(a, work[:half])
                pb = self._append_work(b, work[half:])
                if pa and pb:
                    out.append({"kind": "split", "to": [a.id, b.id], "routes": {**pa["routes"], **pb["routes"]},
                                "finish_s": max(pa["finish_s"], pb["finish_s"]), "min_margin": min(pa["min_margin"], pb["min_margin"]),
                                "details": pa["details"] + pb["details"]})
        out.append({"kind": "defer", "to": [], "routes": {}, "finish_s": 0.0, "min_margin": 1.0,
                    "details": [f"{len(work)} inspection waypoints of {', '.join(task_ids) or 'the task'} left uncompleted and reported"]})
        # strategic check of each option's new routes against everyone else's remaining routes
        from .conflict import strategic_check
        for k, o in enumerate(out):
            routes = {}
            for cid, c in sim.agents.items():
                if c.mode in ("parked", "landed", "failed") and cid not in o["routes"]:
                    continue
                r = o["routes"].get(cid) or (c.route[c.idx:] if cid != i else (ag.rth_route((land[2]["e"], land[2]["n"])) if land and not ag.fault else []))
                if not r:
                    continue
                st = tuple(float(x) for x in c.pos) if c.mode not in ("parked", "landed") else (c.home[0], c.home[1], 0.0)
                routes[cid] = [(t - sim.t, *p) for (t, *p) in time_parameterize(c.spec, r, sim.t, start=st)]
            sc = strategic_check(routes, sim.zones, self.cfg, dt=2.0)
            o["conflict_check"] = {"ok": sc["ok"], "conflicts": sc["conflicts"][:5], "intrusions": sc["intrusions"][:5]}
            o["id"] = f"opt{k + 1}"
            o["feasible"] = o["min_margin"] >= 0
            if o["kind"] == "reassign":
                o["title"] = f"Reassign remaining work to {o['to'][0]}"
            elif o["kind"] == "split":
                o["title"] = f"Split remaining work between {o['to'][0]} and {o['to'][1]}"
            else:
                o["title"] = "Defer remaining work (report as incomplete)"
            o["summary"] = (f"completes in ~{o['finish_s'] / 60:.1f} min, lowest landing reserve {max(o['min_margin'], -1) * 100:.0f}% of battery"
                            if o["kind"] != "defer" else "no additional flying; task marked incomplete")
        rec = next((o["id"] for o in out if o["feasible"] and o["conflict_check"]["ok"]), out[-1]["id"])
        prop = {"id": f"P-{len(self.proposals) + 1:03d}", "type": "recovery", "uav_id": i, "reason": reason,
                "t": round(sim.t, 1), "state": "proposed", "immediate": home_action, "options": out, "recommended": rec,
                "remaining_waypoints": len(work), "task_ids": task_ids, "requires_approval": True,
                "explanation": (f"{i} cannot complete its assignment ({reason}). SkyGrid evaluated {len(cands)} aircraft with the "
                                f"required sensors using the planning energy model, kept a {self.reserve * 100:.0f}% landing reserve, "
                                f"and checked each option's routes for separation and zone conflicts.")}
        self.proposals.append(prop)
        sim.log("proposal", f"{prop['id']}: recovery plan for {i} awaiting operator approval ({reason})", i, "warning")
        return prop

    def _task_sensors(self, sim, tid):
        return getattr(sim, "task_sensors", {}).get(tid, [])

    def _append_work(self, c, work):
        """New route for candidate c: its remaining work, then the extra work, then home."""
        cur = c.route[c.idx:] if c.mode not in ("parked", "landed") else []
        keep = [w for w in cur if w["kind"] in ("inspect", "transit", "takeoff") and not (w["kind"] == "transit" and w.get("task_id") is None)]
        alt = next((w["u"] for w in c.route if w["kind"] == "transit"), 40.0)
        cruise = c.spec["cruise_ms"]
        new = list(keep)
        if c.mode in ("parked", "landed"):
            new = [{"e": c.home[0], "n": c.home[1], "u": alt, "kind": "takeoff", "task_id": None, "speed": c.spec["climb_ms"]}]
        new.append({"e": work[0]["e"], "n": work[0]["n"], "u": alt, "kind": "transit", "task_id": work[0].get("task_id"), "speed": cruise})
        new += [dict(w) for w in work]
        new.append({"e": work[-1]["e"], "n": work[-1]["n"], "u": alt, "kind": "transit", "task_id": None, "speed": cruise})
        new.append({"e": c.home[0], "n": c.home[1], "u": alt, "kind": "transit", "task_id": None, "speed": cruise})
        new.append({"e": c.home[0], "n": c.home[1], "u": 0.0, "kind": "land", "task_id": None, "speed": c.spec["descent_ms"]})
        start = tuple(float(x) for x in c.pos) if c.mode not in ("parked", "landed") else (c.home[0], c.home[1], 0.0)
        from .planning import apply_detours
        new = apply_detours(new, getattr(c, "zones", None), start=start)
        est = estimate(c.spec, new, start=start, payload_kg=c.uav["payload"]["mass_kg"])
        avail = c.soc * c.cap_wh
        margin = (avail - est["energy_wh"]) / usable_wh(c.uav)
        return {"routes": {c.id: new}, "finish_s": est["time_s"], "min_margin": round(margin - 0.0, 3),
                "details": [f"{c.id}: +{len(work)} waypoints, total {est['time_s'] / 60:.1f} min, {est['energy_wh']:.0f} of {avail:.0f} Wh, "
                            f"lands with {margin * 100:.0f}% battery (reserve target {self.reserve * 100:.0f}%)"]}

    def apply_option(self, sim, pid: str, oid: str, actor: str):
        p = next(x for x in self.proposals if x["id"] == pid)
        if p["state"] != "proposed":
            raise ValueError(f"proposal {pid} is {p['state']}")
        o = next(x for x in p["options"] if x["id"] == oid)
        if p["type"] == "recovery":
            ag = sim.agents[p["uav_id"]]
            if p["immediate"] and not ag.fault and ag.mode not in ("landed", "landing"):
                if ag.mode != "rth":
                    ag.go_home(f"operator-approved recovery {pid}: return to {p['immediate']['target']}", sim.t,
                               (p["immediate"]["target_e"], p["immediate"]["target_n"]))
                else:
                    ag.route = ag.rth_route((p["immediate"]["target_e"], p["immediate"]["target_n"]))
                    ag.idx = 0
            ag.remaining_work = []
            for cid, r in o["routes"].items():
                c = sim.agents[cid]
                c.route = r
                c.idx = 0
                c.recount_extra = True
                for w in r:
                    if w["kind"] == "inspect" and w.get("task_id"):
                        pass
                if c.mode in ("parked", "landed"):
                    c.mode = "parked"
                    c.launch_t = sim.t
                c.log(sim.t, "reassign", f"accepted {sum(1 for w in r if w['kind'] == 'inspect')} inspection waypoints ({pid})")
            # move the unfinished-waypoint counters from the affected aircraft to the receivers
            for tid in p["task_ids"]:
                left = ag.total_wps.get(tid, 0) - ag.done_wps.get(tid, 0)
                ag.total_wps[tid] = ag.done_wps.get(tid, 0)
                if o["kind"] in ("reassign", "split"):
                    for cid, r in o["routes"].items():
                        n = sum(1 for w in r if w["kind"] == "inspect" and w.get("task_id") == tid)
                        c = sim.agents[cid]
                        c.total_wps[tid] = c.total_wps.get(tid, 0) + n
                        c.done_wps.setdefault(tid, 0)
                else:
                    sim.deferred = getattr(sim, "deferred", {})
                    sim.deferred[tid] = sim.deferred.get(tid, 0) + left
        elif p["type"] == "abort":
            self._apply_abort(sim, o)
        p["state"] = "approved"
        p["decision"] = {"option": oid, "by": actor, "t": round(sim.t, 1)}
        self.decisions.append({"t": round(sim.t, 1), "proposal": pid, "option": oid, "title": o["title"], "by": actor})
        sim.log("decision", f"{pid} approved by {actor}: {o['title']}", p.get("uav_id"), "info")
        return p

    def reject(self, sim, pid: str, actor: str, note: str = ""):
        p = next(x for x in self.proposals if x["id"] == pid)
        p["state"] = "rejected"
        p["decision"] = {"option": None, "by": actor, "t": round(sim.t, 1), "note": note}
        self.decisions.append({"t": round(sim.t, 1), "proposal": pid, "option": None, "title": "rejected", "by": actor})
        sim.log("decision", f"{pid} rejected by {actor} {note}", p.get("uav_id"), "info")
        if p.get("uav_id"):
            self.handled.discard(p["uav_id"])  # allow re-proposal later
            self.handled.add(p["uav_id"])  # but not immediately: operator keeps control
        return p

    # ------------------------------------------------------------ mission interruption
    def propose_abort(self, sim, reason: str):
        flying = [a for a in sim.agents.values() if a.mode in ("takeoff", "transit", "mission", "hold", "paused")]
        opts = []
        rth_d = []
        ok = True
        for a in flying:
            need = estimate(a.spec, a.rth_route(), start=tuple(float(x) for x in a.pos))["energy_wh"]
            rth_d.append(f"{a.id}: home {math.hypot(a.home[0] - a.pos[0], a.home[1] - a.pos[1]):.0f} m, {need:.0f} Wh of {a.soc * a.cap_wh:.0f} Wh")
            ok &= need < a.soc * a.cap_wh * 0.9
        opts.append({"id": "opt1", "kind": "rth_all", "title": "Return all aircraft to their docks (staggered)", "feasible": ok,
                     "details": rth_d, "summary": "aircraft recovered to docks, 8 s stagger per dock", "routes": {}, "min_margin": 0, "finish_s": 0,
                     "conflict_check": {"ok": True, "conflicts": [], "intrusions": []}})
        land_d = []
        for a in flying:
            s = min(self.emergency + self.docks, key=lambda s: math.hypot(s["e"] - a.pos[0], s["n"] - a.pos[1]))
            land_d.append(f"{a.id}: land at {s['name']} ({math.hypot(s['e'] - a.pos[0], s['n'] - a.pos[1]):.0f} m)")
        opts.append({"id": "opt2", "kind": "land_nearest", "title": "Land each aircraft at the nearest safe site", "feasible": True,
                     "details": land_d, "summary": "fastest recovery; aircraft retrieved from landing sites", "routes": {}, "min_margin": 0, "finish_s": 0,
                     "conflict_check": {"ok": True, "conflicts": [], "intrusions": []}})
        opts.append({"id": "opt3", "kind": "hold", "title": "Hold position and await instructions", "feasible": True,
                     "details": [f"{a.id}: hold at {a.pos[2]:.0f} m, endurance left ~{a.soc * a.cap_wh / max(a.spec.get('hover_w', a.spec.get('cruise_w', 200)), 1) * 60:.0f} min" for a in flying],
                     "summary": "keeps options open; endurance keeps decreasing", "routes": {}, "min_margin": 0, "finish_s": 0,
                     "conflict_check": {"ok": True, "conflicts": [], "intrusions": []}})
        prop = {"id": f"P-{len(self.proposals) + 1:03d}", "type": "abort", "uav_id": None, "reason": reason, "t": round(sim.t, 1),
                "state": "proposed", "immediate": None, "options": opts, "recommended": "opt1" if ok else "opt2",
                "remaining_waypoints": sum(len(a.remaining_inspect()) for a in flying), "task_ids": [], "requires_approval": True,
                "explanation": f"Mission abort requested ({reason}). Options are ranked by safety: return home only if every aircraft keeps a 10% energy margin."}
        self.proposals.append(prop)
        sim.log("proposal", f"{prop['id']}: abort recovery options awaiting operator approval", None, "warning")
        return prop

    def _apply_abort(self, sim, o):
        self.mission_state = "aborted"
        flying = [a for a in sim.agents.values() if a.mode in ("takeoff", "transit", "mission", "hold", "paused")]
        per_dock: dict = {}
        for a in flying:
            a.failsafe = None
            if o["kind"] == "rth_all":
                k = per_dock.get(a.home, 0)
                per_dock[a.home] = k + 1
                a.go_home("operator-approved abort: return to dock", sim.t)
                a.route[0]["u"] = a.route[1]["u"] = max(a.pos[2], 30.0 + 6 * k)
            elif o["kind"] == "land_nearest":
                s = min(self.emergency + self.docks, key=lambda s: math.hypot(s["e"] - a.pos[0], s["n"] - a.pos[1]))
                a.go_home(f"operator-approved abort: land at {s['name']}", sim.t, (s["e"], s["n"]))
            else:
                a.saved = None
                a.mode = "paused"
        for a in sim.agents.values():
            if a.mode == "parked":
                a.route = []

    def _progress(self, sim):
        tot: dict[str, list] = {}
        for a in sim.agents.values():
            for tid, n in a.total_wps.items():
                d = min(a.done_wps.get(tid, 0), n)
                s = tot.setdefault(tid, [0, 0])
                s[0] += d
                s[1] += n
        for tid, n in getattr(sim, "deferred", {}).items():
            tot.setdefault(tid, [0, 0])[1] += n
        self.progress = {tid: {"done": d, "total": n, "frac": (d / n if n else 1.0)} for tid, (d, n) in tot.items()}
        active = [a for a in sim.agents.values() if a.route and a.mode not in ("landed", "failed", "parked")]
        pending_launch = [a for a in sim.agents.values() if a.mode == "parked" and a.route and a.idx == 0]
        if not active and not pending_launch and sim.t > 5 and sim.status == "running":
            sim.status = "completed"
            if self.mission_state == "executing":
                self.mission_state = "completed"
            sim.log("system", f"all aircraft on the ground; mission {self.mission_state}")
