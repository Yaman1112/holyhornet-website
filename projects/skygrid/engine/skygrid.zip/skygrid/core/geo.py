"""Local tangent plane (East-North-Up) conversion around a site origin on the WGS-84 ellipsoid.

Uses the meridional and prime-vertical radii of curvature at the origin latitude. Over the few
kilometres of an operational site the horizontal error is well under 1 m (checked in tests against an
exact geodetic forward computation).
"""

from __future__ import annotations

import math

A = 6378137.0  # WGS-84 semi-major axis [m]
F = 1 / 298.257223563
E2 = F * (2 - F)


class LocalFrame:
    def __init__(self, lat0: float, lon0: float, alt0: float = 0.0):
        self.lat0, self.lon0, self.alt0 = lat0, lon0, alt0
        phi = math.radians(lat0)
        s = math.sin(phi)
        w = math.sqrt(1 - E2 * s * s)
        self.rn = A / w  # prime vertical radius
        self.rm = A * (1 - E2) / w**3  # meridional radius
        self.cos0 = math.cos(phi)

    def to_geo(self, e: float, n: float, u: float = 0.0) -> tuple[float, float, float]:
        lat = self.lat0 + math.degrees(n / self.rm)
        lon = self.lon0 + math.degrees(e / (self.rn * self.cos0))
        return lat, lon, self.alt0 + u

    def to_enu(self, lat: float, lon: float, alt: float | None = None) -> tuple[float, float, float]:
        n = math.radians(lat - self.lat0) * self.rm
        e = math.radians(lon - self.lon0) * self.rn * self.cos0
        return e, n, (alt - self.alt0) if alt is not None else 0.0

    def ring_to_geo(self, ring: list[list[float]]) -> list[list[float]]:
        """ENU polygon ring [[e, n], ...] -> GeoJSON ring [[lon, lat], ...] (closed)."""
        out = []
        for p in ring:
            lat, lon, _ = self.to_geo(p[0], p[1])
            out.append([round(lon, 7), round(lat, 7)])
        if out and out[0] != out[-1]:
            out.append(out[0])
        return out


def heading_deg(ve: float, vn: float) -> float:
    """Course over ground in degrees clockwise from north, 0..360."""
    return (math.degrees(math.atan2(ve, vn)) + 360.0) % 360.0


def dist2(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def dist3(a, b) -> float:
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


def point_in_polygon(x: float, y: float, ring) -> bool:
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-300) + xi:
            inside = not inside
        j = i
    return inside


def polygon_area(ring) -> float:
    a = 0.0
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i][0], ring[i][1]
        x2, y2 = ring[(i + 1) % n][0], ring[(i + 1) % n][1]
        a += x1 * y2 - x2 * y1
    return abs(a) / 2.0


def polygon_centroid(ring) -> tuple[float, float]:
    a = cx = cy = 0.0
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i][0], ring[i][1]
        x2, y2 = ring[(i + 1) % n][0], ring[(i + 1) % n][1]
        c = x1 * y2 - x2 * y1
        a += c
        cx += (x1 + x2) * c
        cy += (y1 + y2) * c
    if abs(a) < 1e-9:
        xs = [p[0] for p in ring]
        ys = [p[1] for p in ring]
        return sum(xs) / n, sum(ys) / n
    return cx / (3 * a), cy / (3 * a)


def clip_halfplane(ring, axis: int, value: float, keep_less: bool):
    """Sutherland–Hodgman clip of a polygon against x<=value (axis 0) or y<=value (axis 1)."""

    def inside(p):
        return p[axis] <= value if keep_less else p[axis] >= value

    out = []
    n = len(ring)
    for i in range(n):
        cur, prev = ring[i], ring[i - 1]
        ci, pi_ = inside(cur), inside(prev)
        if ci:
            if not pi_:
                out.append(_intersect(prev, cur, axis, value))
            out.append(list(cur))
        elif pi_:
            out.append(_intersect(prev, cur, axis, value))
    return out


def _intersect(p, q, axis, value):
    t = (value - p[axis]) / (q[axis] - p[axis])
    return [p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])]


def segment_point_distance(p, a, b) -> float:
    ax, ay = a[0], a[1]
    dx, dy = b[0] - ax, b[1] - ay
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 == 0 else max(0.0, min(1.0, ((p[0] - ax) * dx + (p[1] - ay) * dy) / L2))
    return math.hypot(p[0] - ax - t * dx, p[1] - ay - t * dy)


def distance_to_polygon(x: float, y: float, ring) -> float:
    """0 inside, else distance to the boundary."""
    if point_in_polygon(x, y, ring):
        return 0.0
    n = len(ring)
    return min(segment_point_distance((x, y), ring[i], ring[(i + 1) % n]) for i in range(n))
