"""Mission and fleet reports (JSON, Markdown, HTML for print-to-PDF, CSV)."""

from __future__ import annotations

import datetime as dt
import html
import io
import csv


def _now():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def build(ws, s) -> dict:
    sim, c, m = s.sim, s.coord, s.mission
    aircraft = []
    for a in sim.agents.values():
        tasks = sorted({t for t in a.total_wps})
        aircraft.append({"uav_id": a.id, "name": a.uav["name"], "model": a.uav["model"], "final_mode": a.mode,
                         "flight_time_s": round(a.flight_time), "distance_m": round(a.distance), "energy_wh": round(a.energy_used, 1),
                         "soc_start": round(s.start_soc.get(a.id, 0), 3), "soc_end": round(a.soc, 3), "tasks": tasks,
                         "waypoints_done": sum(a.done_wps.values()), "failsafe": a.failsafe, "fault": a.fault,
                         "telemetry_received": sim.tel_count[a.id][1], "telemetry_sent": sim.tel_count[a.id][0]})
    prog = getattr(c, "progress", {})
    tasks = []
    for t in m["tasks"]:
        p = prog.get(t["id"], {"done": 0, "total": 0, "frac": 0.0})
        who = [a.id for a in sim.agents.values() if t["id"] in a.total_wps and a.done_wps.get(t["id"], 0) > 0]
        tasks.append({"task_id": t["id"], "name": t["name"], "sensors": t["sensors"], "done": p["done"], "total": p["total"],
                      "coverage": round(p["frac"], 3), "flown_by": who})
    levels = {}
    order = ["informational", "advisory", "warning", "critical"]
    merged: dict[str, dict] = {}
    for a in list(c.alert_history) + [a for a in c.alerts.values() if a["active"]]:
        g = merged.get(a["id"])
        if g is None:
            merged[a["id"]] = dict(a, occurrences=1, detail=a.get("peak_detail", a["detail"]))
        else:
            g["occurrences"] += 1
            g["t_last"] = max(g["t_last"], a["t_last"])
            if order.index(a["peak"]) > order.index(g["peak"]):
                g["peak"], g["detail"] = a["peak"], a.get("peak_detail", a["detail"])
    all_alerts = sorted(merged.values(), key=lambda a: a["t_first"])
    for a in all_alerts:
        levels[a["peak"]] = levels.get(a["peak"], 0) + 1
    coverage = (sum(t["done"] for t in tasks) / max(sum(t["total"] for t in tasks), 1))
    planned = m["plan"]["makespan_s"] if m.get("plan") else None
    if c.mission_state == "aborted":
        outcome = "aborted"
    elif coverage >= 0.999:
        outcome = "completed_with_reassignment" if any(p["state"] == "approved" and p["type"] == "recovery" for p in c.proposals) else "completed"
    else:
        outcome = "partially_completed"
    sent = sum(v[0] for v in sim.tel_count.values())
    recv = sum(v[1] for v in sim.tel_count.values())
    return {
        "title": f"Mission report — {m['name']}", "generated_at": _now(), "simulated": True,
        "disclaimer": "SIMULATION. Synthetic aircraft, telemetry and facility. Not an operational record.",
        "mission": {"id": m["id"], "name": m["name"], "type": m["type"], "objective": m["objective"],
                    "approvals": m.get("approvals", []), "scenario": (s.scenario or {}).get("name")},
        "summary": {"outcome": outcome, "duration_s": round(sim.t, 1), "planned_makespan_s": planned,
                    "coverage": round(coverage, 4), "aircraft": len(aircraft),
                    "distance_km": round(sum(a["distance_m"] for a in aircraft) / 1000, 2),
                    "energy_wh": round(sum(a["energy_wh"] for a in aircraft), 1),
                    "flight_hours": round(sum(a["flight_time_s"] for a in aircraft) / 3600, 3),
                    "alerts_by_level": levels, "proposals": len(c.proposals),
                    "decisions": len(c.decisions), "min_separation_m": None if c.min_sep_seen == float("inf") else round(c.min_sep_seen, 1),
                    "link_availability": round(recv / sent, 4) if sent else None,
                    "seed": (s.scenario or {}).get("seed"), "wind_ms": sim.wind_ms},
        "aircraft": aircraft, "tasks": tasks, "proposals": c.proposals, "decisions": c.decisions,
        "alerts": [{k: a[k] for k in ("id", "type", "peak", "title", "detail", "t_first", "t_last", "occurrences")} for a in all_alerts],
        "events": sim.event_log,
        "plan": {"method": m["plan"]["method"], "strategic_ok": m["plan"]["strategic"]["ok"],
                 "assignments": [{"uav_id": a["uav_id"], "task_ids": a["task_ids"], "estimate": a["estimate"]} for a in m["plan"]["assignments"]]},
    }


def fleet_report(ws) -> dict:
    from .analytics import summary
    s = summary(ws)
    return {"title": "Fleet utilisation report", "generated_at": _now(), "simulated": True,
            "disclaimer": "Includes synthetic history and simulation runs only.", "mission": {"id": None, "name": "Fleet", "type": "fleet"},
            "summary": {"outcome": "report", **s["kpis"]}, "aircraft": s["per_uav"], "tasks": [], "proposals": [], "decisions": [],
            "alerts": [], "events": [], "plan": None, "analytics": s}


def to_markdown(r: dict) -> str:
    s = r["summary"]
    lines = [f"# {r['title']}", "", f"> {r['disclaimer']}", "", f"Generated {r['generated_at']}", "", "## Summary", ""]
    for k, v in s.items():
        lines.append(f"- **{k.replace('_', ' ')}**: {v}")
    if r.get("aircraft"):
        lines += ["", "## Aircraft", "", "| UAV | tasks | flight (min) | distance (m) | energy (Wh) | SoC start→end | final |", "|---|---|---|---|---|---|---|"]
        for a in r["aircraft"]:
            if "flight_time_s" in a:
                lines.append(f"| {a['uav_id']} | {', '.join(a['tasks'])} | {a['flight_time_s'] / 60:.1f} | {a['distance_m']} | {a['energy_wh']} | "
                             f"{a['soc_start'] * 100:.0f}% → {a['soc_end'] * 100:.0f}% | {a['final_mode']} |")
    if r.get("tasks"):
        lines += ["", "## Inspection coverage", "", "| task | coverage | flown by |", "|---|---|---|"]
        for t in r["tasks"]:
            lines.append(f"| {t['task_id']} {t['name']} | {t['coverage'] * 100:.0f}% ({t['done']}/{t['total']}) | {', '.join(t['flown_by'])} |")
    if r.get("decisions"):
        lines += ["", "## Operator decisions", ""] + [f"- t={d['t']} s — {d['proposal']}: {d['title']} (by {d['by']})" for d in r["decisions"]]
    if r.get("events"):
        lines += ["", "## Event log", ""] + [f"- t={e['t']} s [{e.get('level', 'info')}] {e['text']}" for e in r["events"][:300]]
    return "\n".join(lines) + "\n"


def to_html(r: dict) -> str:
    md = to_markdown(r)
    body = []
    in_table = False
    for line in md.splitlines():
        if line.startswith("|"):
            cells = [html.escape(c.strip()) for c in line.strip("|").split("|")]
            if set(line.replace("|", "").strip()) <= {"-"}:
                continue
            if not in_table:
                body.append("<table>")
                in_table = True
                body.append("<tr>" + "".join(f"<th>{c}</th>" for c in cells) + "</tr>")
            else:
                body.append("<tr>" + "".join(f"<td>{c}</td>" for c in cells) + "</tr>")
            continue
        if in_table:
            body.append("</table>")
            in_table = False
        if line.startswith("# "):
            body.append(f"<h1>{html.escape(line[2:])}</h1>")
        elif line.startswith("## "):
            body.append(f"<h2>{html.escape(line[3:])}</h2>")
        elif line.startswith("> "):
            body.append(f"<p class='warn'>{html.escape(line[2:])}</p>")
        elif line.startswith("- "):
            body.append(f"<li>{html.escape(line[2:]).replace('**', '')}</li>")
        elif line.strip():
            body.append(f"<p>{html.escape(line)}</p>")
    if in_table:
        body.append("</table>")
    css = ("body{font-family:Inter,Segoe UI,Arial,sans-serif;color:#0b1220;margin:32px;max-width:900px}h1{font-size:22px}"
           "h2{font-size:15px;margin-top:22px;border-bottom:1px solid #ccd;padding-bottom:4px}table{border-collapse:collapse;width:100%;font-size:12px}"
           "td,th{border:1px solid #ccd;padding:4px 6px;text-align:left}li{font-size:12px}.warn{background:#fff4d6;padding:6px 10px;border-left:3px solid #e0a000}")
    return f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(r['title'])}</title><style>{css}</style></head><body>{''.join(body)}</body></html>"


def events_csv(r: dict) -> str:
    f = io.StringIO()
    w = csv.writer(f)
    w.writerow(["t_s", "level", "kind", "uav_id", "text"])
    for e in r.get("events", []):
        w.writerow([e["t"], e.get("level", "info"), e.get("kind"), e.get("uav_id") or "", e["text"]])
    return f.getvalue()


def aircraft_csv(r: dict) -> str:
    f = io.StringIO()
    rows = r.get("aircraft", [])
    if not rows:
        return ""
    keys = [k for k in rows[0] if not isinstance(rows[0][k], (list, dict))]
    w = csv.writer(f)
    w.writerow(keys)
    for a in rows:
        w.writerow([a.get(k) for k in keys])
    return f.getvalue()
