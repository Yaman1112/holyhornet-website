"""Multi-UAV simulation engine (SIMULATION ONLY — synthetic aircraft, synthetic telemetry).

Each agent is a point-mass with speed/acceleration/climb limits, attitude derived from acceleration, a
battery driven by the power model, an onboard contingency policy (link-loss hold/RTH, low-battery RTL,
critical-battery land, as a PX4/ArduPilot failsafe would provide) and GNSS/link models. The ground
station only sees telemetry that survives the link model and tracks each aircraft with a Kalman filter.
"""

from __future__ import annotations

import math
import random

import numpy as np

from .catalog import MODELS
from .energy import battery_vi, power_w, usable_wh
from .geo import LocalFrame, heading_deg
from .tracking import CVTrack

G = 9.81
MODES = ["parked", "takeoff", "transit", "mission", "hold", "paused", "rth", "landing", "landed",
         "emergency_landing", "failed"]
AIRBORNE = {"takeoff", "transit", "mission", "hold", "paused", "rth", "landing", "emergency_landing"}


class Agent:
    def __init__(self, uav: dict, home: tuple, route: list[dict] | None, launch_t: float, rng: random.Random):
        self.uav = uav
        self.id = uav["id"]
        self.spec = MODELS[uav["model_code"]]
        self.home = home
        self.pos = np.array([home[0], home[1], 0.0])
        self.vel = np.zeros(3)
        self.acc = np.zeros(3)
        self.heading = 0.0
        self.roll = self.pitch = 0.0
        self.cap_wh = usable_wh(uav)
        self.energy = self.cap_wh * uav["battery"]["soc"]
        self.drain_mult = 1.0
        self.route = route or []
        self.idx = 0
        self.launch_t = launch_t
        self.mode = "parked"
        self.armed = False
        self.rng = rng
        self.gps_sigma = 0.6
        self.gps_degraded_until = -1.0
        self.gps_bias = np.zeros(2)
        self.link_lost_until = -1.0
        self.link_factor = 1.0
        self.link_factor_until = -1.0
        self.last_uplink = 0.0
        self.failsafe = None  # None | "link_hold" | "link_rth" | "low_battery_rtl" | "critical_land" | "fault"
        self.hold_started = None
        self.saved = None  # (route, idx, mode) when paused
        self.remaining_work: list[dict] = []
        self.flight_time = 0.0
        self.distance = 0.0
        self.energy_used = 0.0
        self.power = 0.0
        self.volt, self.curr = 0.0, 0.0
        self.done_wps: dict[str, int] = {}
        self.total_wps: dict[str, int] = {}
        self.events: list[dict] = []
        self.landed_at = None
        self.fault = None
        self.recount()

    # -------------------------------------------------------------- bookkeeping
    def recount(self):
        for w in self.route:
            if w["kind"] == "inspect" and w.get("task_id"):
                self.total_wps[w["task_id"]] = self.total_wps.get(w["task_id"], 0) + 1
                self.done_wps.setdefault(w["task_id"], 0)

    @property
    def soc(self) -> float:
        return max(0.0, self.energy / self.cap_wh)

    def current_task(self):
        for w in self.route[self.idx:]:
            if w.get("task_id"):
                return w["task_id"]
        return None

    def remaining_inspect(self) -> list[dict]:
        return [w for w in self.route[self.idx:] if w["kind"] == "inspect"]

    def rth_route(self, target=None, alt=None):
        e, n = target if target else self.home
        cruise = self.spec["cruise_ms"]
        alt = max(self.pos[2], 25.0) if alt is None else alt
        from .planning import apply_detours
        r = [{"e": float(self.pos[0]), "n": float(self.pos[1]), "u": alt, "kind": "transit", "task_id": None, "speed": cruise},
             {"e": e, "n": n, "u": alt, "kind": "transit", "task_id": None, "speed": cruise},
             {"e": e, "n": n, "u": 0.0, "kind": "land", "task_id": None, "speed": self.spec["descent_ms"]}]
        return apply_detours(r, getattr(self, "zones", None), start=(float(self.pos[0]), float(self.pos[1]), alt))

    def go_home(self, reason: str, t: float, target=None):
        """Leave the mission: keep the unflown inspection work so the coordinator can reassign it."""
        rem = self.remaining_inspect()
        if rem:
            self.remaining_work = rem
        self.route = self.rth_route(target)
        self.idx = 0
        self.mode = "rth"
        self.saved = None
        self.log(t, "rth", reason)

    def log(self, t, kind, text):
        self.events.append({"t": round(t, 1), "uav_id": self.id, "kind": kind, "text": text})

    # -------------------------------------------------------------- dynamics
    def step(self, t: float, dt: float, wind: np.ndarray, link_ok: bool):
        if self.mode in ("failed",):
            return
        if self.mode == "parked":
            if self.route and t >= self.launch_t:
                self.mode = "takeoff"
                self.armed = True
                self.log(t, "launch", f"armed and taking off from home (launch slot t={self.launch_t:.0f} s)")
            else:
                return
        if self.mode == "landed":
            return

        # ---- onboard contingency logic (simulated flight-controller failsafes)
        if link_ok:
            self.last_uplink = t
            if self.failsafe == "link_hold":
                self.failsafe = None
                if self.saved:
                    self.route, self.idx, self.mode = self.saved
                    self.saved = None
                self.log(t, "link", "C2 link restored, onboard hold released, mission continues")
        c = self.uav.get("contingency", {})
        lost_for = t - self.last_uplink
        if self.mode in AIRBORNE and self.failsafe is None and lost_for > c.get("link_loss_timeout_s", 5.0):
            pol = c.get("link_loss", "hold_then_rth")
            if pol == "rth":
                self.failsafe = "link_rth"
                self.go_home("onboard failsafe: C2 link lost -> RTH", t)
            elif pol == "hold_then_rth":
                self.failsafe = "link_hold"
                self.saved = (self.route, self.idx, self.mode)
                self.route = [{"e": float(self.pos[0]), "n": float(self.pos[1]), "u": float(self.pos[2]), "kind": "hold", "task_id": None, "speed": 0.0}]
                self.idx = 0
                self.mode = "hold"
                self.hold_started = t
                self.log(t, "failsafe", f"onboard failsafe: C2 link lost {lost_for:.0f} s -> hold {c.get('hold_s', 20):.0f} s")
        if self.failsafe == "link_hold" and t - self.hold_started > c.get("hold_s", 20.0):
            self.failsafe = "link_rth"
            if self.saved:
                self.route, self.idx, _ = self.saved
                self.saved = None
            self.go_home("onboard failsafe: link not restored after hold -> RTH", t)
        if self.mode in AIRBORNE and self.soc < 0.05 and self.failsafe != "critical_land":
            self.failsafe = "critical_land"
            self.route = [{"e": float(self.pos[0]), "n": float(self.pos[1]), "u": 0.0, "kind": "land", "task_id": None, "speed": self.spec["descent_ms"]}]
            self.idx = 0
            self.mode = "emergency_landing"
            self.log(t, "failsafe", "onboard failsafe: critical battery -> land now")
        elif (self.mode in ("transit", "mission", "hold") and self.soc < c.get("low_battery_rtl_soc", 0.12)
              and self.failsafe not in ("low_battery_rtl", "critical_land")):
            self.failsafe = "low_battery_rtl"
            self.go_home(f"onboard failsafe: battery {self.soc * 100:.0f}% below RTL threshold", t)

        # ---- guidance
        target = self.route[self.idx] if self.idx < len(self.route) else None
        spec = self.spec
        fw = spec["category"] == "fixed_wing"
        if target is None or target["kind"] in ("hold",) or self.mode == "paused":
            v_des = np.zeros(3)
            if fw:  # loiter
                sp = spec.get("vmin_ms", 13) * 1.1
                w = sp / max(spec.get("min_turn_radius_m", 60), 1)
                h = math.atan2(self.vel[1], self.vel[0]) + w * dt
                v_des = np.array([sp * math.cos(h), sp * math.sin(h), 0.0])
        else:
            d = np.array([target["e"], target["n"], target["u"]]) - self.pos
            nav_err = np.array([*self.gps_bias, 0.0])
            d = d - nav_err
            dh = math.hypot(d[0], d[1])
            sp = target["speed"] if target["kind"] not in ("land", "takeoff") else 0.0
            if target["kind"] == "takeoff":
                vz = min(spec["climb_ms"], max(0.6, d[2]))
                v_des = np.array([0.0, 0.0, vz])
            elif target["kind"] == "land":
                if dh > 2.0:
                    v_des = np.array([d[0], d[1], 0.0]) / max(dh, 1e-6) * min(3.0, dh)
                else:
                    vz = -min(spec["descent_ms"], max(0.4, self.pos[2] * 0.6))
                    v_des = np.array([d[0] * 0.5, d[1] * 0.5, vz])
            else:
                nxt = self.route[self.idx + 1] if self.idx + 1 < len(self.route) else None
                brake = nxt is None or nxt["kind"] == "land"
                if nxt is not None and not brake:
                    a1 = math.atan2(d[1], d[0])
                    a2 = math.atan2(nxt["n"] - target["n"], nxt["e"] - target["e"])
                    turn = abs((a2 - a1 + math.pi) % (2 * math.pi) - math.pi)
                    brake = turn > math.radians(70) and not fw
                if brake:
                    sp = min(sp, math.sqrt(2 * spec["accel_ms2"] * 0.6 * max(dh, 0.0)) + 0.5)
                vh = (np.array([d[0], d[1]]) / dh * sp) if dh > 1e-6 else np.zeros(2)
                vz = max(-spec["descent_ms"], min(spec["climb_ms"], 0.8 * d[2]))
                v_des = np.array([vh[0], vh[1], vz])
            if fw:
                # constant-speed, turn-rate-limited heading toward the target
                sp = max(spec.get("vmin_ms", 13), target["speed"] or spec["cruise_ms"])
                cur = math.atan2(self.vel[1], self.vel[0]) if np.linalg.norm(self.vel[:2]) > 1 else math.atan2(d[1], d[0])
                want = math.atan2(d[1], d[0])
                if target["kind"] in ("land", "takeoff"):
                    # spiral climb / descent on a circle of the minimum turn radius around the pad
                    R = spec.get("min_turn_radius_m", 60)
                    rx, ry = -d[0], -d[1]
                    rn = math.hypot(rx, ry) or 1.0
                    tx, ty = -ry / rn, rx / rn  # counter-clockwise tangent
                    k = max(-1.0, min(1.0, (R - rn) / R))
                    want = math.atan2(ty + k * ry / rn, tx + k * rx / rn)
                    vz = spec["climb_ms"] if target["kind"] == "takeoff" else -spec["descent_ms"]
                    if target["kind"] == "land" and self.pos[2] < 3.0:
                        sp = spec.get("vmin_ms", 13) * 0.6  # flare / belly or parachute recovery (simplified)
                    v_des = np.array([0.0, 0.0, vz])
                err = (want - cur + math.pi) % (2 * math.pi) - math.pi
                wmax = sp / spec.get("min_turn_radius_m", 60)
                h = cur + max(-wmax * dt, min(wmax * dt, err))
                v_des = np.array([sp * math.cos(h), sp * math.sin(h), v_des[2]])

        amax = spec["accel_ms2"] if not fw else 6.0
        dv = v_des - self.vel
        n = np.linalg.norm(dv[:2])
        lim = amax * dt
        if n > lim:
            dv[:2] *= lim / n
        dv[2] = max(-2.5 * dt * 2, min(2.5 * dt * 2, dv[2]))
        self.acc = dv / dt
        self.vel = self.vel + dv
        step = self.vel * dt
        self.pos = self.pos + step
        if self.pos[2] < 0:
            self.pos[2] = 0.0
            self.vel[2] = 0.0
        self.distance += float(np.linalg.norm(step))

        # attitude: tilt needed for horizontal acceleration + drag
        drag_a = 0.25 * (self.vel[:2] - wind[:2])
        a_h = self.acc[:2] + drag_a
        sp_h = math.hypot(self.vel[0], self.vel[1])
        if sp_h > 0.8:
            self.heading = heading_deg(self.vel[0], self.vel[1])
        hr = math.radians(self.heading)
        fwd = np.array([math.sin(hr), math.cos(hr)])
        right = np.array([math.cos(hr), -math.sin(hr)])
        if fw:
            self.pitch = math.degrees(math.atan2(self.vel[2], max(sp_h, 1)))
            yaw_rate = 0.0
            if hasattr(self, "_prev_heading"):
                yaw_rate = math.radians(((self.heading - self._prev_heading + 540) % 360) - 180) / dt
            self.roll = math.degrees(math.atan2(sp_h * yaw_rate, G))
        else:
            self.pitch = -math.degrees(math.atan2(float(a_h @ fwd), G))
            self.roll = math.degrees(math.atan2(float(a_h @ right), G))
        self._prev_heading = self.heading

        # energy
        airspeed = float(np.linalg.norm(self.vel[:2] - wind[:2]))
        hovering = sp_h < 1.0
        if self.mode in AIRBORNE:
            # electrical power (what V*I telemetry measures); a battery fault drains SoC faster than that
            self.power = power_w(spec, airspeed, float(self.vel[2]), float(np.linalg.norm(wind[:2])),
                                 self.uav["payload"]["mass_kg"], hovering=hovering)
            e = self.power * self.drain_mult * dt / 3600.0
            self.energy = max(0.0, self.energy - e)
            self.energy_used += e
            self.flight_time += dt
            self.volt, self.curr = battery_vi(spec["cells"], self.soc, self.power)
        else:
            self.power = 0.0
            self.volt, self.curr = battery_vi(spec["cells"], self.soc, 5.0)

        # waypoint acceptance
        if target is not None and target["kind"] != "hold" and self.mode != "paused":
            d = np.array([target["e"], target["n"], target["u"]]) - self.pos + np.array([*self.gps_bias, 0.0])
            dh = math.hypot(d[0], d[1])
            acc_r = 30.0 if fw else 4.0
            ok = False
            if target["kind"] == "takeoff":
                ok = d[2] < 1.0
            elif target["kind"] == "land":
                ok = self.pos[2] <= 0.05
            else:
                ok = dh < acc_r and abs(d[2]) < (6.0 if fw else 2.0)
                if fw and not ok and dh < 2.5 * self.spec.get("min_turn_radius_m", 60):
                    ok = float(self.vel[0] * d[0] + self.vel[1] * d[1]) < 0  # passed abeam: do not circle back
            if ok:
                if target["kind"] == "inspect" and target.get("task_id"):
                    self.done_wps[target["task_id"]] = self.done_wps.get(target["task_id"], 0) + 1
                self.idx += 1
                if target["kind"] == "land":
                    self.mode = "landed" if self.failsafe != "critical_land" and self.fault is None else "failed"
                    self.armed = False
                    self.vel[:] = 0
                    self.landed_at = t
                    self.log(t, "landed", f"landed at ({self.pos[0]:.0f}, {self.pos[1]:.0f}), battery {self.soc * 100:.0f}%")
                    return
                nxt = self.route[self.idx] if self.idx < len(self.route) else None
                if self.mode not in ("rth", "emergency_landing", "hold", "paused") and nxt is not None:
                    self.mode = "mission" if nxt["kind"] == "inspect" else ("landing" if nxt["kind"] == "land" else "transit")
                elif self.mode == "rth" and nxt is not None and nxt["kind"] == "land":
                    self.mode = "landing"
        if self.mode == "takeoff" and target is not None and target["kind"] != "takeoff":
            self.mode = "transit"


class Simulation:
    """Owns agents, environment, ground-station telemetry/tracks and the recorder."""

    def __init__(self, frame: LocalFrame, agents: list[Agent], zones: list[dict], gcs: dict, seed: int = 1,
                 wind_ms: float = 3.0, wind_dir_deg: float = 300.0, gust_ms: float = 1.0, events=None,
                 dt: float = 0.1, telemetry_hz: float = 2.0):
        self.frame = frame
        self.agents = {a.id: a for a in agents}
        self.zones = zones
        for a in agents:
            a.zones = zones
        self.gcs = gcs
        self.rng = random.Random(seed)
        self.t = 0.0
        self.dt = dt
        self.tel_dt = 1.0 / telemetry_hz
        self.next_tel = 0.0
        self.wind_ms, self.wind_dir, self.gust = wind_ms, wind_dir_deg, gust_ms
        self.events_scheduled = sorted(events or [], key=lambda e: e["t"])
        self.tracks: dict[str, CVTrack] = {}
        self.telemetry: dict[str, dict] = {}
        self.event_log: list[dict] = []
        self.recording: list[dict] = []
        self.next_rec = 0.0
        self.tel_count = {a.id: [0, 0] for a in agents}  # sent, received
        self.speed = 8.0
        self.paused = True
        self.status = "ready"
        self.max_t = 3 * 3600.0

    # ------------------------------------------------------------ environment
    def wind(self) -> np.ndarray:
        # wind *from* wind_dir (meteorological), as an ENU velocity of the air mass
        th = math.radians(self.wind_dir)
        g = self.gust * math.sin(0.21 * self.t) * math.sin(0.057 * self.t + 1.3)
        s = max(0.0, self.wind_ms + g)
        return np.array([-s * math.sin(th), -s * math.cos(th), 0.0])

    def link_quality(self, a: Agent) -> float:
        if self.t < a.link_lost_until:
            return 0.0
        d = math.hypot(a.pos[0] - self.gcs["e"], a.pos[1] - self.gcs["n"])
        q = max(0.0, 1.0 - 0.6 * (d / self.gcs.get("range_m", 6000.0)) ** 2)
        if self.t < a.link_factor_until:
            q *= a.link_factor
        return max(0.0, min(1.0, q - 0.03 * abs(math.sin(0.37 * self.t + hash(a.id) % 7))))

    # ------------------------------------------------------------ events
    def log(self, kind: str, text: str, uav_id=None, level="info"):
        self.event_log.append({"t": round(self.t, 1), "kind": kind, "text": text, "uav_id": uav_id, "level": level})

    def inject(self, ev: dict):
        a = self.agents.get(ev.get("uav_id", ""))
        k = ev["type"]
        p = ev.get("params", {})
        if k == "battery_fault" and a:
            drop = p.get("soc_drop", 0.3)
            a.energy = max(0.0, a.energy - drop * a.cap_wh)
            a.drain_mult = p.get("drain_mult", 1.8)
            self.log("fault", f"{a.id}: simulated battery fault (cell imbalance): SoC -{drop * 100:.0f}%, drain x{a.drain_mult:.1f}", a.id, "warning")
        elif k == "link_loss" and a:
            a.link_lost_until = self.t + p.get("duration_s", 40.0)
            self.log("fault", f"{a.id}: simulated C2 link loss for {p.get('duration_s', 40):.0f} s", a.id, "warning")
        elif k == "link_degraded" and a:
            a.link_factor = p.get("factor", 0.35)
            a.link_factor_until = self.t + p.get("duration_s", 60.0)
            self.log("fault", f"{a.id}: simulated link degradation (x{a.link_factor:.2f}) for {p.get('duration_s', 60):.0f} s", a.id, "advisory")
        elif k == "gps_degraded" and a:
            a.gps_degraded_until = self.t + p.get("duration_s", 60.0)
            self.log("fault", f"{a.id}: simulated GNSS degradation for {p.get('duration_s', 60):.0f} s", a.id, "advisory")
        elif k == "motor_fault" and a:
            a.fault = "motor"
            a.failsafe = "fault"
            a.remaining_work = a.remaining_inspect()
            a.route = [{"e": float(a.pos[0]), "n": float(a.pos[1]), "u": 0.0, "kind": "land", "task_id": None, "speed": a.spec["descent_ms"]}]
            a.idx = 0
            a.mode = "emergency_landing"
            a.log(self.t, "fault", "motor fault: onboard emergency landing")
            self.log("fault", f"{a.id}: simulated motor fault -> aircraft unavailable, emergency landing", a.id, "critical")
        elif k == "wind":
            self.wind_ms = p.get("speed_ms", self.wind_ms)
            self.wind_dir = p.get("dir_deg", self.wind_dir)
            self.gust = p.get("gust_ms", self.gust)
            self.log("weather", f"wind now {self.wind_ms:.0f} m/s from {self.wind_dir:.0f}°, gusts {self.gust:.0f} m/s")
        elif k == "zone_activate":
            for z in self.zones:
                if z["id"] == p.get("zone_id"):
                    z["active"] = True
                    z["t_from"] = self.t
                    self.log("airspace", f"zone {z['name']} activated", None, "advisory")
        else:
            raise ValueError(f"unknown event {k}")

    # ------------------------------------------------------------ stepping
    def step(self):
        while self.events_scheduled and self.events_scheduled[0]["t"] <= self.t:
            self.inject(self.events_scheduled.pop(0))
        w = self.wind()
        for a in self.agents.values():
            q = self.link_quality(a)
            a._q = q
            # GNSS model
            if self.t < a.gps_degraded_until:
                a.gps_sigma = 6.0
                a.gps_bias = 0.995 * a.gps_bias + np.array([self.rng.gauss(0, 0.25), self.rng.gauss(0, 0.25)])
            else:
                a.gps_sigma = 0.6
                a.gps_bias *= 0.98
            a.step(self.t, self.dt, w, link_ok=q > 0.15)
            for ev in a.events:
                self.event_log.append({**ev, "level": "warning" if ev["kind"] in ("failsafe", "fault") else "info"})
            a.events.clear()
        self.t += self.dt
        if self.t >= self.next_tel:
            self.next_tel += self.tel_dt
            self._telemetry()
        if self.t >= self.next_rec:
            self.next_rec += 1.0
            self._record()

    def _telemetry(self):
        for a in self.agents.values():
            if a.mode == "parked" and a.id in self.telemetry and not a.route:
                continue
            self.tel_count[a.id][0] += 1
            q = getattr(a, "_q", 1.0)
            if q <= 0.15 or self.rng.random() > 0.5 + 0.5 * q:
                continue
            self.tel_count[a.id][1] += 1
            degraded = self.t < a.gps_degraded_until
            sig = a.gps_sigma
            meas = a.pos + np.array([self.rng.gauss(0, sig), self.rng.gauss(0, sig), self.rng.gauss(0, sig * 1.5)])
            vmeas = a.vel + np.array([self.rng.gauss(0, 0.2) for _ in range(3)])
            lat, lon, alt = self.frame.to_geo(meas[0], meas[1], meas[2])
            tr = self.tracks.get(a.id)
            if tr is None:
                tr = self.tracks[a.id] = CVTrack(meas, vmeas, self.t)
            tr.update(self.t, meas, vmeas, sig)
            sats = (5 + int(self.rng.random() * 2)) if degraded else (17 + int(self.rng.random() * 4))
            task = a.current_task()
            self.telemetry[a.id] = {
                "t_rx": round(self.t, 2), "lat": lat, "lon": lon, "alt_msl": round(alt, 1), "alt": round(float(meas[2]), 1),
                "e": round(float(meas[0]), 2), "n": round(float(meas[1]), 2),
                "gs": round(math.hypot(vmeas[0], vmeas[1]), 2), "vs": round(float(vmeas[2]), 2),
                "hdg": round(a.heading, 1), "roll": round(a.roll, 1), "pitch": round(a.pitch, 1), "yaw": round(a.heading, 1),
                "batt_v": round(a.volt, 2), "batt_a": round(a.curr, 1), "soc": round(a.soc, 4), "power_w": round(a.power),
                "mode": a.mode, "failsafe": a.failsafe, "gps_fix": "2D" if degraded and sats < 6 else "3D",
                "sats": sats, "hdop": round(2.8 if degraded else 0.7 + 0.1 * self.rng.random(), 2),
                "link": round(q, 2), "armed": a.armed, "task_id": task,
                "wp": a.idx, "wp_total": len(a.route),
            }

    def _record(self):
        self.recording.append({
            "t": round(self.t, 1),
            "a": {a.id: [round(float(a.pos[0]), 1), round(float(a.pos[1]), 1), round(float(a.pos[2]), 1),
                         round(a.heading), round(a.soc, 3), MODES.index(a.mode)] for a in self.agents.values()},
        })

    def advance(self, sim_seconds: float, coordinator=None, coord_dt: float = 0.5):
        """Advance by sim_seconds (stops early when complete)."""
        end = self.t + sim_seconds
        while self.t < end - 1e-9 and self.status == "running":
            self.step()
            if coordinator is not None and self.t + 1e-9 >= coordinator.next_t:
                coordinator.next_t += coord_dt
                coordinator.tick(self)
            if self.t > self.max_t:
                self.status = "completed"
                self.log("system", "simulation time limit reached")

    def ground_estimates(self):
        out = {}
        for i, tr in self.tracks.items():
            p, v, P = tr.state_at(self.t)
            tel = self.telemetry.get(i, {})
            out[i] = {"id": i, "pos": p, "vel": v, "P": tr.P.copy() if self.t <= tr.t else _prop(tr, self.t),
                      "age": self.t - tr.last_update, "mode": tel.get("mode"), "sigma": _sig(tr, self.t)}
        return out


def _prop(tr: CVTrack, t: float):
    _, _, P = tr.state_at(t)
    dt = max(0.0, t - tr.t)
    q = tr.q
    for k in range(3):
        P[k, k] += q * dt**3 / 3
        P[k + 3, k + 3] += q * dt
    return P


def _sig(tr: CVTrack, t: float) -> float:
    P = _prop(tr, t)
    return float(math.sqrt(max(np.linalg.eigvalsh(P[:2, :2]).max(), 0.0)))
