"""Mission allocation: feasibility checks, cost model and optimal assignment with explanations.

Method: for each round, build a cost matrix (aircraft × unassigned tasks, highest priority first) where
infeasible pairs get a prohibitive cost, solve it exactly with the Hungarian algorithm, and append the
assigned task to that aircraft's route. Rounds repeat while tasks remain and someone can take one, which
chains several tasks on one aircraft when there are more tasks than aircraft (a greedy-by-round VRP
heuristic; optimal per round, not globally). Every pair keeps its list of checks for the UI.
"""

from __future__ import annotations

import math
import time

from .catalog import MODELS
from .energy import usable_wh
from .hungarian import solve
from .planning import build_route, estimate

BIG = 1e6

DEFAULT_RULES = {
    "reserve_fraction": 0.25,      # energy reserve kept at landing, fraction of usable battery
    "min_start_soc": 0.50,
    "max_tasks_per_uav": 3,
    "allow_standby": False,
    "max_wind_check": True,
    "w_energy": 1.0, "w_time": 0.6, "w_health": 0.4, "w_maint": 0.3, "w_priority": 0.15,
    "transit_alts": [30.0, 45.0, 60.0, 75.0, 90.0, 105.0],  # 15 m layers = vertical separation minimum
    "launch_stagger_s": 12.0,
    "excluded_uavs": [],
}


PAD_OFFSETS = [(-7.0, -7.0), (7.0, -7.0), (-7.0, 7.0), (7.0, 7.0)]


def pad_position(dock: dict, k: int) -> tuple[float, float]:
    """Each dock has four landing pads 14 m apart; aircraft get their own pad."""
    o = PAD_OFFSETS[k % 4]
    return dock["e"] + o[0], dock["n"] + o[1]


def _dock(docks, did):
    for d in docks:
        if d["id"] == did:
            return d
    return docks[0]


def check_pair(uav: dict, task: dict, prior_tasks: list[dict], docks, rules: dict, wind: float, transit_alt=40.0, zones=None):
    spec = MODELS[uav["model_code"]]
    checks = []

    def add(name, ok, detail):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    allowed = ("available", "standby") if rules.get("allow_standby") else ("available",)
    add("availability", uav["status"] in allowed and uav["id"] not in rules.get("excluded_uavs", []),
        f"status {uav['status']}" + (" (excluded by rule)" if uav["id"] in rules.get("excluded_uavs", []) else ""))
    m = uav["maintenance"]["status"]
    add("maintenance", m in ("ok", "due_soon"), f"maintenance {m}")
    missing = [s for s in task["sensors"] if s not in uav["sensors"]]
    add("sensors", not missing, "has " + ", ".join(task["sensors"]) if not missing else "missing " + ", ".join(missing))
    payload = uav["payload"]["mass_kg"]
    add("payload", payload <= spec["payload_max_kg"], f"{payload:.2f} kg of {spec['payload_max_kg']} kg")
    if rules.get("max_wind_check", True):
        add("wind", wind <= spec["max_wind_ms"], f"wind {wind:.1f} m/s, limit {spec['max_wind_ms']} m/s")
    pat_ok, pat_detail = True, f"{task['pattern']} pattern"
    if spec["category"] in ("fixed_wing", "hybrid_vtol"):
        r = task["params"].get("radius")
        rmin = spec.get("min_turn_radius_m", 0)
        if task["pattern"] in ("orbit", "multi_orbit") and r is not None and r < rmin:
            pat_ok, pat_detail = False, f"orbit radius {r:.0f} m below min turn radius {rmin:.0f} m"
        if task["pattern"] == "lawnmower" and task["params"]["spacing"] < rmin:
            pat_ok, pat_detail = False, f"line spacing {task['params']['spacing']:.0f} m below turn radius {rmin:.0f} m"
        if task["pattern"] == "corridor":
            pat_ok, pat_detail = False, "low-altitude corridor needs hover capability"
    add("pattern", pat_ok, pat_detail)
    soc = uav["battery"]["soc"]
    add("start_soc", soc >= rules["min_start_soc"], f"SoC {soc * 100:.0f}% (min {rules['min_start_soc'] * 100:.0f}%)")

    d = _dock(docks, uav["home_dock"])
    wps = build_route(spec, (d["e"], d["n"]), prior_tasks + [task], transit_alt, zones=zones)
    est = estimate(spec, wps, payload_kg=payload, wind=wind)
    avail = usable_wh(uav) * soc
    need = est["energy_wh"] + rules["reserve_fraction"] * usable_wh(uav)
    margin = (avail - need) / usable_wh(uav)
    add("energy", need <= avail, f"needs {est['energy_wh']:.0f} Wh + {rules['reserve_fraction'] * 100:.0f}% reserve, has {avail:.0f} Wh")
    far = max(math.hypot(w["e"] - d["e"], w["n"] - d["n"]) for w in wps) / 1000.0
    add("range", far <= spec["range_km"], f"max distance {far:.2f} km of {spec['range_km']} km link range")
    add("task_count", len(prior_tasks) < rules["max_tasks_per_uav"], f"{len(prior_tasks)} task(s) already assigned")
    feasible = all(c["ok"] for c in checks)
    w = rules
    cost = (w["w_energy"] * est["energy_wh"] / max(avail, 1.0)
            + w["w_time"] * est["time_s"] / 3600.0
            + w["w_health"] * (1.0 - uav["battery"]["health"])
            + w["w_maint"] * (1.0 if m == "due_soon" else 0.0)
            - w["w_priority"] * task.get("priority", 1) * 0.0)  # priority orders rounds, not pair cost
    return {"feasible": feasible, "cost": round(cost, 4), "checks": checks, "estimate": est,
            "energy_margin": round(margin, 3), "route": wps}


def allocate(uavs: list[dict], tasks: list[dict], docks, rules: dict | None = None, wind: float = 0.0, zones=None) -> dict:
    t0 = time.perf_counter()
    rules = {**DEFAULT_RULES, **(rules or {})}
    plan = {u["id"]: [] for u in uavs}
    remaining = sorted(tasks, key=lambda t: -t.get("priority", 1))
    first_matrix = None
    rounds = 0
    while remaining and rounds < rules["max_tasks_per_uav"]:
        rounds += 1
        cells = [[check_pair(u, t, plan[u["id"]], docks, rules, wind, zones=zones) for t in remaining] for u in uavs]
        if first_matrix is None:
            first_matrix = {"uavs": [u["id"] for u in uavs], "tasks": [t["id"] for t in remaining],
                            "cells": [[{k: c[k] for k in ("feasible", "cost", "checks", "energy_margin")}
                                       | {"time_s": round(c["estimate"]["time_s"]), "energy_wh": round(c["estimate"]["energy_wh"], 1)}
                                       for c in row] for row in cells]}
        cost = [[c["cost"] if c["feasible"] else BIG for c in row] for row in cells]
        pairs = [(i, j) for i, j in solve(cost) if cells[i][j]["feasible"]]
        if not pairs:
            break
        for i, j in pairs:
            plan[uavs[i]["id"]].append(remaining[j])
        taken = {j for _, j in pairs}
        remaining = [t for j, t in enumerate(remaining) if j not in taken]

    # final routes, altitude layering, launch stagger, explanations
    assignments = []
    k = 0
    dock_count: dict[str, int] = {}
    for u in uavs:
        ts = plan[u["id"]]
        if not ts:
            continue
        spec = MODELS[u["model_code"]]
        d = _dock(docks, u["home_dock"])
        alt = rules["transit_alts"][k % len(rules["transit_alts"])]
        k += 1
        n_at_dock = dock_count.get(d["id"], 0)
        dock_count[d["id"]] = n_at_dock + 1
        home = pad_position(d, n_at_dock)
        wps = build_route(spec, home, ts, alt, zones=zones)
        est = estimate(spec, wps, payload_kg=u["payload"]["mass_kg"], wind=wind)
        avail = usable_wh(u) * u["battery"]["soc"]
        reasons = [f"has required sensors ({', '.join(sorted({s for t in ts for s in t['sensors']}))})",
                   f"estimated {est['energy_wh']:.0f} Wh of {avail:.0f} Wh available "
                   f"({100 * est['energy_wh'] / max(avail, 1):.0f}%), {est['time_s'] / 60:.1f} min",
                   f"battery health {u['battery']['health'] * 100:.0f}%, maintenance {u['maintenance']['status']}",
                   f"transit altitude {alt:.0f} m AGL, launch slot +{n_at_dock * rules['launch_stagger_s']:.0f} s from {d['id']}"]
        assignments.append({
            "uav_id": u["id"], "task_ids": [t["id"] for t in ts], "transit_alt": alt,
            "launch_delay_s": n_at_dock * rules["launch_stagger_s"], "dock": d["id"], "pad": n_at_dock % 4,
            "home": [round(home[0], 2), round(home[1], 2)], "route": wps,
            "estimate": {kk: round(v, 1) for kk, v in est.items()},
            "energy_margin": round((avail - est["energy_wh"]) / usable_wh(u), 3), "reasons": reasons,
        })
    # alternatives: next-best feasible aircraft for each first-round task
    if first_matrix:
        for a in assignments:
            alts = []
            for tid in a["task_ids"]:
                if tid not in first_matrix["tasks"]:
                    continue
                j = first_matrix["tasks"].index(tid)
                col = [(first_matrix["cells"][i][j]["cost"], first_matrix["uavs"][i]) for i in range(len(uavs))
                       if first_matrix["cells"][i][j]["feasible"] and first_matrix["uavs"][i] != a["uav_id"]]
                col.sort()
                mine = first_matrix["cells"][first_matrix["uavs"].index(a["uav_id"])][j]["cost"]
                if col:
                    alts.append({"task_id": tid, "uav_id": col[0][1], "cost_delta": round(col[0][0] - mine, 4)})
                else:
                    alts.append({"task_id": tid, "uav_id": None, "cost_delta": None})
            a["alternatives"] = alts
    unassigned = []
    for t in remaining:
        why = []
        if first_matrix and t["id"] in first_matrix["tasks"]:
            j = first_matrix["tasks"].index(t["id"])
            fails: dict[str, int] = {}
            for i in range(len(uavs)):
                for c in first_matrix["cells"][i][j]["checks"]:
                    if not c["ok"]:
                        fails[c["name"]] = fails.get(c["name"], 0) + 1
            why = [f"{n} aircraft fail '{k}'" for k, n in sorted(fails.items(), key=lambda kv: -kv[1])]
        unassigned.append({"task_id": t["id"], "reasons": why or ["all feasible aircraft already at task limit"]})
    return {
        "method": "Hungarian (Kuhn–Munkres) per round, priority-ordered rounds",
        "rules": rules, "wind_ms": wind, "rounds": rounds, "assignments": assignments, "unassigned": unassigned,
        "matrix": first_matrix, "runtime_ms": round((time.perf_counter() - t0) * 1000, 2),
        "total_energy_wh": round(sum(a["estimate"]["energy_wh"] for a in assignments), 1),
        "makespan_s": round(max([a["estimate"]["time_s"] + a["launch_delay_s"] for a in assignments] or [0])),
    }
