"""Fleet KPIs for the Command Center and the Analytics module (synthetic history + simulation runs)."""

from __future__ import annotations

import datetime as dt

from .sim import AIRBORNE


def _records(ws):
    recs = [dict(h, source="synthetic history") for h in ws.history]
    today = dt.date.today()
    for r in ws.runs.values():
        m = r["metrics"]
        recs.append({"id": r["id"], "day_offset": 0, "kind": ws.missions[r["mission_id"]]["type"],
                     "uavs": [x["uav_id"] for x in ws.reports[r["report_id"]]["aircraft"]],
                     "planned_min": round((m.get("planned_makespan_s") or 0) / 60, 1), "actual_min": round(m["duration_s"] / 60, 1),
                     "distance_km": m["distance_km"], "energy_wh": m["energy_wh"], "outcome": m["outcome"],
                     "interruptions": m.get("proposals", 0), "link_availability": m.get("link_availability") or 1.0, "source": "simulation run"})
    for x in recs:
        x["date"] = (today + dt.timedelta(days=x["day_offset"])).isoformat()
    return recs


def summary(ws) -> dict:
    recs = _records(ws)
    n = len(recs)
    done = [r for r in recs if r["outcome"].startswith("completed")]
    hours = sum(r["actual_min"] * len(r["uavs"]) for r in recs) / 60
    dist = sum(r["distance_km"] for r in recs)
    energy = sum(r["energy_wh"] for r in recs)
    per_day: dict[str, dict] = {}
    for r in recs:
        d = per_day.setdefault(r["date"], {"date": r["date"], "missions": 0, "flight_hours": 0.0, "completed": 0, "energy_wh": 0.0, "interruptions": 0})
        d["missions"] += 1
        d["flight_hours"] = round(d["flight_hours"] + r["actual_min"] * len(r["uavs"]) / 60, 2)
        d["completed"] += r["outcome"].startswith("completed")
        d["energy_wh"] = round(d["energy_wh"] + r["energy_wh"], 1)
        d["interruptions"] += r["interruptions"]
    per_uav: dict[str, dict] = {u: {"uav_id": u, "name": ws.uavs[u]["name"], "flights": 0, "hours": 0.0, "distance_km": 0.0, "energy_wh": 0.0}
                                for u in ws.uavs}
    for r in recs:
        share = 1 / max(len(r["uavs"]), 1)
        for u in r["uavs"]:
            if u in per_uav:
                p = per_uav[u]
                p["flights"] += 1
                p["hours"] = round(p["hours"] + r["actual_min"] / 60, 2)
                p["distance_km"] = round(p["distance_km"] + r["distance_km"] * share, 2)
                p["energy_wh"] = round(p["energy_wh"] + r["energy_wh"] * share, 1)
    days = max(len(per_day), 1)
    for p in per_uav.values():
        p["utilization"] = round(p["hours"] / (days * 8.0), 4)  # share of an 8-hour operating day
        p["wh_per_km"] = round(p["energy_wh"] / p["distance_km"], 1) if p["distance_km"] else None
        p["maintenance_events"] = sum(1 for m in ws.maintenance.values() if m["uav_id"] == p["uav_id"])
    by_kind: dict[str, int] = {}
    for r in recs:
        by_kind[r["kind"]] = by_kind.get(r["kind"], 0) + 1
    eff = [r["planned_min"] / r["actual_min"] for r in recs if r["actual_min"] and r["planned_min"]]
    return {
        "sources": ["synthetic history (30 days, labelled)", f"{len(ws.runs)} simulation run(s) this session"],
        "kpis": {"missions": n, "completion_rate": round(len(done) / n, 4) if n else None, "flight_hours": round(hours, 1),
                 "distance_km": round(dist, 1), "energy_kwh": round(energy / 1000, 2),
                 "avg_mission_min": round(sum(r["actual_min"] for r in recs) / n, 1) if n else None,
                 "avg_wh_per_km": round(energy / dist, 1) if dist else None,
                 "interruptions": sum(r["interruptions"] for r in recs),
                 "link_availability": round(sum(r["link_availability"] for r in recs) / n, 4) if n else None,
                 "schedule_efficiency": round(sum(eff) / len(eff), 3) if eff else None,
                 "maintenance_records": len(ws.maintenance)},
        "per_day": sorted(per_day.values(), key=lambda d: d["date"]),
        "per_uav": sorted(per_uav.values(), key=lambda p: -p["hours"]),
        "by_kind": [{"kind": k, "missions": v} for k, v in sorted(by_kind.items(), key=lambda kv: -kv[1])],
        "missions": sorted(recs, key=lambda r: r["date"], reverse=True)[:60],
    }


def dashboard(ws) -> dict:
    live = {}
    frame_alerts = []
    sess = ws.session
    if sess:
        for a in sess.sim.agents.values():
            tel = sess.sim.telemetry.get(a.id, {})
            live[a.id] = {"mode": a.mode, "soc": tel.get("soc", a.soc), "link": tel.get("link")}
        frame_alerts = [x for x in sess.coord.alerts.values() if x["active"]]
    uavs = list(ws.uavs.values())
    active = [u for u in uavs if live.get(u["id"], {}).get("mode") in AIRBORNE]
    rth = [u for u in uavs if live.get(u["id"], {}).get("mode") in ("rth", "landing")]
    standby = [u for u in uavs if u["status"] == "standby" or (u["status"] == "available" and live.get(u["id"], {}).get("mode") in (None, "parked", "landed"))]
    attention = {x for a in frame_alerts if a["level"] in ("warning", "critical") for x in a["uavs"]}
    attention |= {u["id"] for u in uavs if u["maintenance"]["status"] in ("due_soon", "in_maintenance") or u["status"] == "disabled"}
    socs = [live[u["id"]]["soc"] if u["id"] in live else u["battery"]["soc"] for u in uavs if u["status"] != "disabled"]
    links = [v["link"] for v in live.values() if v.get("link") is not None]
    s = summary(ws)
    lv = {k: 0 for k in ("informational", "advisory", "warning", "critical")}
    for a in frame_alerts:
        lv[a["level"]] += 1
    missions = list(ws.missions.values())
    available = [u for u in uavs if u["status"] == "available"]
    return {
        "simulated": True,
        "counts": {"registered": len(uavs), "active": len(active), "standby": len(standby), "returning": len(rth),
                   "attention": len(attention), "maintenance": sum(u["status"] == "maintenance" for u in uavs),
                   "disabled": sum(u["status"] == "disabled" for u in uavs)},
        "attention_uavs": sorted(attention),
        "missions": {"active": sum(m["status"] == "executing" for m in missions),
                     "completed": sum(m["status"] == "completed" for m in missions) + sum(1 for h in ws.history if h["outcome"] != "aborted"),
                     "planned": sum(m["status"] in ("draft", "proposed", "approved") for m in missions),
                     "success_rate": s["kpis"]["completion_rate"]},
        "battery": {"mean_soc": round(sum(socs) / len(socs), 3) if socs else None, "low": sum(1 for x in socs if x < 0.3)},
        "comms": {"mean_link": round(sum(links) / len(links), 3) if links else None, "tracked": len(links),
                  "stale": sum(1 for a in frame_alerts if a["type"] == "link")},
        "alerts": lv,
        "zones": {"total": len(ws.zones), "restricted_active": sum(1 for z in ws.zones.values() if z["rule"] == "no_fly" and z.get("active", True)),
                  "source": "operator-defined (synthetic demo); no live airspace feed connected"},
        "utilization": {"assigned_now": len(active), "available": len(available),
                        "fraction": round(len(active) / len(available), 3) if available else 0.0,
                        "flight_hours_30d": s["kpis"]["flight_hours"]},
        "operator_activity": list(reversed(ws.audit[-8:])),
        "session": None if not sess else {"mission": sess.mission["name"], "t": round(sess.sim.t, 1), "status": sess.sim.status,
                                          "scenario": (sess.scenario or {}).get("name")},
        "kpi_trend": s["per_day"][-14:],
    }
