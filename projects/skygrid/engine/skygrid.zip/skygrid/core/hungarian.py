"""Kuhn–Munkres (Hungarian) assignment with row/column potentials, O(n^2 m).

``solve(cost)`` takes a rectangular list-of-lists or numpy array and returns a list of (row, col) pairs
minimising total cost, assigning min(rows, cols) pairs. Tested against scipy.optimize.linear_sum_assignment.
"""

from __future__ import annotations

import math


def solve(cost) -> list[tuple[int, int]]:
    rows = len(cost)
    if rows == 0:
        return []
    cols = len(cost[0])
    if cols == 0:
        return []
    transposed = rows > cols
    a = [[float(cost[i][j]) for i in range(rows)] for j in range(cols)] if transposed else [[float(x) for x in r] for r in cost]
    n, m = len(a), len(a[0])  # n <= m
    INF = math.inf
    u = [0.0] * (n + 1)
    v = [0.0] * (m + 1)
    p = [0] * (m + 1)  # p[j] = row (1-based) matched to column j
    way = [0] * (m + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = [INF] * (m + 1)
        used = [False] * (m + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta = INF
            j1 = 0
            for j in range(1, m + 1):
                if not used[j]:
                    cur = a[i0 - 1][j - 1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j] = cur
                        way[j] = j0
                    if minv[j] < delta:
                        delta = minv[j]
                        j1 = j
            for j in range(m + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    pairs = [(p[j] - 1, j - 1) for j in range(1, m + 1) if p[j] != 0]
    if transposed:
        pairs = [(c, r) for r, c in pairs]
    return sorted(pairs)
