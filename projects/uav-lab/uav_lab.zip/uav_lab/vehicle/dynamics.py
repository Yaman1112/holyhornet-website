"""Quadrotor rigid-body dynamics (ground truth).

    p' = v
    m v' = R (T e3 + F_drag,B) + F_wind + F_ext - m g e3
    q' = 1/2 q (x) [0, w]
    J w' = M - w x J w - c_w w + tau_ext
    f_i' = (f_cmd,i - f_i) / tau_m          (first-order motor lag, exact discretisation)

Drag uses the air-relative velocity v - wind. Wind = mean + Ornstein-Uhlenbeck gust.
Battery energy from momentum theory: P_i = f_i^1.5 / (FM * sqrt(2 rho A)).
Integration: RK4 on (p, v, q, w) at the physics rate, quaternion renormalised each step.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import DisturbanceConfig, UAVConfig
from ..math3d import GRAVITY, quat_mul, quat_normalize, quat_to_rot
from .airframe import Airframe

RHO_AIR = 1.225


@dataclass
class VehicleState:
    p: np.ndarray
    v: np.ndarray
    q: np.ndarray
    w: np.ndarray
    f: np.ndarray                           # actual motor thrusts [N]
    a: np.ndarray = field(default_factory=lambda: np.zeros(3))  # world acceleration (last step)

    def copy(self) -> "VehicleState":
        return VehicleState(self.p.copy(), self.v.copy(), self.q.copy(), self.w.copy(), self.f.copy(), self.a.copy())


class QuadrotorDynamics:
    def __init__(self, uav: UAVConfig, dist: DisturbanceConfig, rng: np.random.Generator,
                 p0=(0, 0, 0), q0=(1, 0, 0, 0)):
        self.cfg = uav
        self.dist = dist
        self.af = Airframe(uav)
        self.rng = rng
        hover = np.full(4, 0.0)
        self.state = VehicleState(np.array(p0, float), np.zeros(3), np.array(q0, float), np.zeros(3), hover)
        self.f_cmd = hover.copy()
        self.gust = np.zeros(3)
        self.ext_torque = np.zeros(3)
        self.energy_used_j = 0.0
        self.capacity_j = uav.battery_capacity_wh * 3600.0
        self.on_ground = self.state.p[2] <= 1e-6
        self.t = 0.0
        self.specific_force_b = np.array([0.0, 0.0, GRAVITY])  # what an ideal accelerometer reads
        disc = np.pi * (0.5 * uav.propeller_diameter) ** 2
        self._power_k = 1.0 / (uav.figure_of_merit * np.sqrt(2 * RHO_AIR * disc))

    # -------------------------------------------------------------- environment
    @property
    def soc(self) -> float:
        return max(0.0, 1.0 - self.energy_used_j / self.capacity_j)

    def wind(self) -> np.ndarray:
        return np.array(self.dist.wind_mean) + self.gust

    def external_force(self, t: float) -> np.ndarray:
        F = np.zeros(3)
        for ti in self.dist.impulse_times:
            if ti <= t < ti + 0.2:
                F += np.array(self.dist.impulse_force)
        return F

    def thrust_limit(self) -> float:
        return self.cfg.max_motor_thrust * (0.9 + 0.1 * self.soc) if self.soc > 0 else 0.0

    # -------------------------------------------------------------- dynamics
    def _deriv(self, p, v, q, w, f, wind, F_ext):
        R = quat_to_rot(q)
        wr = self.af.wrench(f)
        T, M = wr[0], wr[1:]
        v_rel = v - wind
        Fd_b = -np.array(self.cfg.linear_drag) * (R.T @ v_rel)
        Fd_w = R @ Fd_b - self.cfg.quadratic_drag * np.linalg.norm(v_rel) * v_rel
        F_thrust = R @ np.array([0.0, 0.0, T])
        acc = (F_thrust + Fd_w + F_ext) / self.cfg.mass - np.array([0.0, 0.0, GRAVITY])
        dq = 0.5 * quat_mul(q, np.array([0.0, *w]))
        J = self.af.J
        dw = self.af.J_inv @ (M - np.cross(w, J @ w) - self.cfg.rotational_damping * w + self.ext_torque)
        return v, acc, dq, dw, (F_thrust + Fd_w + F_ext) / self.cfg.mass

    def step(self, f_cmd: np.ndarray, h: float) -> None:
        cfg = self.cfg
        fmax = self.thrust_limit()
        self.f_cmd = np.clip(f_cmd, 0.0, fmax)
        s = self.state
        # motor lag (exact for a first-order system with piecewise-constant command)
        alpha = 1.0 - np.exp(-h / cfg.motor_time_constant)
        s.f = s.f + alpha * (self.f_cmd - s.f)
        # gusts (OU) and torque noise
        if self.dist.gust_std > 0:
            tau = self.dist.gust_time_constant
            a = np.exp(-h / tau)
            self.gust = a * self.gust + self.dist.gust_std * np.sqrt(1 - a * a) * self.rng.standard_normal(3)
        self.ext_torque = self.dist.torque_noise_std * self.rng.standard_normal(3) if self.dist.torque_noise_std > 0 else np.zeros(3)
        wind = self.wind()
        F_ext = self.external_force(self.t)
        f = s.f
        y0 = (s.p, s.v, s.q, s.w)

        def d(y):
            return self._deriv(*y, f, wind, F_ext)
        k1 = d(y0)
        k2 = d(tuple(x + 0.5 * h * k for x, k in zip(y0, k1[:4])))
        k3 = d(tuple(x + 0.5 * h * k for x, k in zip(y0, k2[:4])))
        k4 = d(tuple(x + h * k for x, k in zip(y0, k3[:4])))
        new = [x + (h / 6.0) * (a1 + 2 * b + 2 * c + dd) for x, a1, b, c, dd in zip(y0, k1[:4], k2[:4], k3[:4], k4[:4])]
        p, v, q, w = new
        q = quat_normalize(q)
        acc_world = (v - s.v) / h
        # ground contact: the ground pushes back; when resting, it cancels motion
        if p[2] <= 0.0:
            p[2] = 0.0
            if v[2] < 0:
                v[2] = 0.0
            T = self.af.wrench(f)[0]
            if T < cfg.mass * GRAVITY:
                v[:] = 0.0
                w[:] = 0.0
                q = _level(q)
                acc_world = np.zeros(3)
            self.on_ground = True
        else:
            self.on_ground = False
        s.p, s.v, s.q, s.w, s.a = p, v, q, w, acc_world
        R = quat_to_rot(q)
        # specific force (what the accelerometer measures) = R^T (a - g_vec) = R^T (a + g e3)
        self.specific_force_b = R.T @ (acc_world + np.array([0.0, 0.0, GRAVITY]))
        P = float(np.sum(np.maximum(f, 0.0) ** 1.5) * self._power_k + cfg.avionics_power_w)
        self.energy_used_j += P * h
        self.power_w = P
        self.t += h


def _level(q: np.ndarray) -> np.ndarray:
    """Keep only the yaw of q (vehicle resting flat on the ground)."""
    R = quat_to_rot(q)
    yaw = np.arctan2(R[1, 0], R[0, 0])
    return np.array([np.cos(yaw / 2), 0.0, 0.0, np.sin(yaw / 2)])
