"""Airframe geometry: motor layout, control allocation (mixer) and the 3D component model.

X configuration, FLU body frame. Motor i sits at (x_i, y_i) and produces thrust f_i along +z_B
and a reaction yaw torque s_i * c_q * f_i.

    wrench = [T, Mx, My, Mz]^T = A f,
        T  = sum f_i
        Mx = sum  y_i f_i
        My = sum -x_i f_i
        Mz = sum  s_i c_q f_i
"""

from __future__ import annotations

import numpy as np

from ..config import CameraConfig, LidarConfig, UAVConfig
from ..math3d import R_BODY_FROM_OPTICAL, rot_y

MOTOR_NAMES = ("front-left", "rear-left", "rear-right", "front-right")
SPIN = np.array([1.0, -1.0, 1.0, -1.0])  # +1: CW propeller (yaw reaction +z), -1: CCW


class Airframe:
    def __init__(self, uav: UAVConfig):
        self.cfg = uav
        a = uav.arm_length / np.sqrt(2.0)
        self.motor_xy = np.array([[a, a], [-a, a], [-a, -a], [a, -a]])
        cq = uav.torque_coefficient
        x, y = self.motor_xy[:, 0], self.motor_xy[:, 1]
        self.A = np.vstack([np.ones(4), y, -x, SPIN * cq])
        self.A_inv = np.linalg.inv(self.A)
        self.J = np.diag(uav.inertia)
        self.J_inv = np.linalg.inv(self.J)
        self.mass = uav.mass

    def wrench(self, f: np.ndarray) -> np.ndarray:
        return self.A @ f

    def allocate(self, T: float, M: np.ndarray, f_min: float, f_max: float) -> tuple[np.ndarray, bool]:
        """Motor thrusts for a desired wrench with saturation.

        Priority: collective thrust and roll/pitch over yaw. Yaw torque is scaled down first,
        then roll/pitch is scaled about the collective, then motors are clipped.
        Returns (f, saturated).
        """
        def solve(Tc, Mc):
            return self.A_inv @ np.array([Tc, *Mc])

        T = float(np.clip(T, 4 * f_min, 4 * f_max))
        f = solve(T, M)
        if f.min() >= f_min - 1e-9 and f.max() <= f_max + 1e-9:
            return f, False
        # reduce yaw
        Mz_scale = 1.0
        for s in np.linspace(1.0, 0.0, 11):
            f = solve(T, np.array([M[0], M[1], M[2] * s]))
            Mz_scale = s
            if f.min() >= f_min and f.max() <= f_max:
                return f, True
        # reduce roll/pitch
        for s in np.linspace(1.0, 0.0, 21):
            f = solve(T, np.array([M[0] * s, M[1] * s, M[2] * Mz_scale]))
            if f.min() >= f_min and f.max() <= f_max:
                return f, True
        return np.clip(f, f_min, f_max), True


def camera_extrinsics(cam: CameraConfig) -> tuple[np.ndarray, np.ndarray]:
    """R_bc (optical -> body) and t_bc. Negative pitch tilts the optical axis down."""
    R = rot_y(-np.deg2rad(cam.pitch_deg)) @ R_BODY_FROM_OPTICAL
    return R, np.array(cam.mount_position)


def camera_intrinsics(cam: CameraConfig) -> np.ndarray:
    f = 0.5 * cam.width / np.tan(0.5 * np.deg2rad(cam.hfov_deg))
    return np.array([[f, 0.0, cam.width / 2.0], [0.0, f, cam.height / 2.0], [0.0, 0.0, 1.0]])


def lidar_extrinsics(lid: LidarConfig) -> tuple[np.ndarray, np.ndarray]:
    return np.eye(3), np.array(lid.mount_position)


def component_model(uav: UAVConfig, cam: CameraConfig, lid: LidarConfig) -> dict:
    """Geometry and frames of the vehicle for the 3D UAV designer (body frame, metres)."""
    af = Airframe(uav)
    R_bc, t_bc = camera_extrinsics(cam)
    R_bl, t_bl = lidar_extrinsics(lid)
    prop_r = 0.5 * uav.propeller_diameter
    parts = [
        {"name": "Electronics compartment", "kind": "box", "position": [0, 0, 0], "size": [0.18, 0.12, 0.07], "color": "#2c3440"},
        {"name": "Flight controller", "kind": "box", "position": [0, 0, 0.005], "size": [0.05, 0.05, 0.01], "color": "#1f8a4c", "internal": True},
        {"name": "IMU", "kind": "box", "position": [0, 0, 0.012], "size": [0.015, 0.015, 0.004], "color": "#e0b020", "internal": True,
         "frame": {"R": np.eye(3).tolist(), "t": [0, 0, 0.012]}},
        {"name": "Battery", "kind": "box", "position": [-0.02, 0, -0.05], "size": [0.14, 0.07, 0.035], "color": "#3a5fa0"},
        {"name": "LiDAR", "kind": "cylinder", "position": list(t_bl), "size": [0.035, 0.035, 0.04], "color": "#202020",
         "frame": {"R": R_bl.tolist(), "t": list(t_bl)}},
        {"name": "RGB-D camera" if cam.rgbd else "RGB camera", "kind": "box", "position": list(t_bc), "size": [0.025, 0.09, 0.025],
         "color": "#505860", "frame": {"R": R_bc.tolist(), "t": list(t_bc)}},
    ]
    for i, (x, y) in enumerate(af.motor_xy):
        parts.append({"name": f"Arm {MOTOR_NAMES[i]}", "kind": "arm", "from": [0, 0, 0], "to": [float(x), float(y), 0.0], "color": "#3b3f46"})
        parts.append({"name": f"Motor {MOTOR_NAMES[i]}", "kind": "cylinder", "position": [float(x), float(y), 0.02],
                      "size": [0.022, 0.022, 0.03], "color": "#9aa0a8", "spin": int(SPIN[i])})
        parts.append({"name": f"Propeller {MOTOR_NAMES[i]}", "kind": "propeller", "position": [float(x), float(y), 0.045],
                      "size": [prop_r, prop_r, 0.004], "color": "#d33c3c" if i in (0, 3) else "#d0d4da", "spin": int(SPIN[i])})
    return {
        "parts": parts,
        "mass": uav.mass,
        "inertia": list(uav.inertia),
        "mixer": af.A.tolist(),
        "camera_intrinsics": camera_intrinsics(cam).tolist(),
        "frames": {
            "body": "FLU (x forward, y left, z up), origin at centre of mass",
            "camera": "optical (x right, y down, z forward)",
            "lidar": "FLU-aligned",
            "world": "ENU, z up",
        },
        "hover_thrust_per_motor": uav.mass * 9.81 / 4,
        "thrust_to_weight": 4 * uav.max_motor_thrust / (uav.mass * 9.81),
    }
