"""Minimum-snap piecewise-polynomial trajectories in the flat outputs (x, y, z, yaw).

Each segment i is a degree-7 polynomial in normalised time s = (t - t_i)/T_i in [0, 1]:
    p_i(t) = sum_k c_ik s^k,   d^r p_i / dt^r = T_i^-r d^r p_i / ds^r
Cost (per axis):  J = sum_i int_0^T_i (d^4 p_i/dt^4)^2 dt = sum_i T_i^-7 c_i^T Q c_i,
    Q_kl = k!/(k-4)! l!/(l-4)! / (k + l - 7)   (k, l >= 4)
Constraints: waypoint positions at both ends of every segment, start and end velocity /
acceleration / jerk, and continuity of derivatives 1..4 at interior waypoints. The QP
    min c^T H c  s.t.  A c = b
is solved through its KKT system. (Optimality makes derivatives 5 and 6 continuous as well,
which the tests check.) A CasADi formulation of the same QP is provided for cross-checking.

Time allocation: trapezoidal velocity profile per segment, then iterative time scaling until
velocity, acceleration, jerk, snap, thrust, tilt and yaw-rate limits hold. Collisions with the
planning grid are removed by inserting the midpoint of the offending segment and re-solving.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from math import factorial

import numpy as np

from ..math3d import GRAVITY

DEG = 7
NC = DEG + 1


def _dcoef(k: int, r: int) -> float:
    return factorial(k) / factorial(k - r) if k >= r else 0.0


_DC = np.array([[_dcoef(k, r) for k in range(NC)] for r in range(NC)])
_POW = np.array([[max(k - r, 0) for k in range(NC)] for r in range(NC)])


def _basis(s: float, r: int) -> np.ndarray:
    return _DC[r] * np.power(s, _POW[r])


_Q4 = np.zeros((NC, NC))
for _k in range(4, NC):
    for _l in range(4, NC):
        _Q4[_k, _l] = _dcoef(_k, 4) * _dcoef(_l, 4) / (_k + _l - 7)


def solve_axis(wps: np.ndarray, T: np.ndarray, start_d: tuple, end_d: tuple, return_system: bool = False):
    """Minimum-snap coefficients (m, 8) for one axis. start_d / end_d = (vel, acc, jerk) or None entries."""
    m = len(T)
    nv = NC * m
    H = np.zeros((nv, nv))
    for i in range(m):
        H[i * NC:(i + 1) * NC, i * NC:(i + 1) * NC] = _Q4 / T[i] ** 7
    rows, b = [], []

    def row(i, s, r, scale=1.0):
        a = np.zeros(nv)
        a[i * NC:(i + 1) * NC] = _basis(s, r) / T[i] ** r * scale
        return a
    for i in range(m):
        rows.append(row(i, 0.0, 0)); b.append(wps[i])
        rows.append(row(i, 1.0, 0)); b.append(wps[i + 1])
    for r in (1, 2, 3):
        if start_d[r - 1] is not None:
            rows.append(row(0, 0.0, r)); b.append(start_d[r - 1])
        if end_d[r - 1] is not None:
            rows.append(row(m - 1, 1.0, r)); b.append(end_d[r - 1])
    for i in range(m - 1):
        for r in (1, 2, 3, 4):
            rows.append(row(i, 1.0, r) - row(i + 1, 0.0, r)); b.append(0.0)
    A = np.array(rows)
    b = np.array(b, float)
    nc = A.shape[0]
    # scale the cost so the KKT system is well conditioned
    sc = 1.0 / max(np.abs(H).max(), 1e-12)
    KKT = np.zeros((nv + nc, nv + nc))
    KKT[:nv, :nv] = 2 * H * sc
    KKT[:nv, nv:] = A.T
    KKT[nv:, :nv] = A
    rhs = np.r_[np.zeros(nv), b]
    try:
        sol = np.linalg.solve(KKT, rhs)
    except np.linalg.LinAlgError:
        sol = np.linalg.lstsq(KKT, rhs, rcond=None)[0]
    c = sol[:nv].reshape(m, NC)
    if return_system:
        return c, H, A, b
    return c


def solve_axis_casadi(wps, T, start_d, end_d):
    """Same QP solved with CasADi (used to validate the closed-form KKT solver)."""
    import casadi as ca
    _, H, A, b = solve_axis(np.asarray(wps, float), np.asarray(T, float), start_d, end_d, return_system=True)
    sc = 1.0 / max(np.abs(H).max(), 1e-12)
    x = ca.SX.sym("c", H.shape[0])
    qp = {"x": x, "f": ca.mtimes([x.T, ca.DM(H * sc), x]), "g": ca.mtimes(ca.DM(A), x)}
    solver = ca.qpsol("minsnap", "qrqp", qp, {"print_iter": False, "print_header": False, "print_info": False, "error_on_fail": False})
    res = solver(lbg=ca.DM(b), ubg=ca.DM(b))
    return np.array(res["x"]).ravel().reshape(len(T), NC)


@dataclass
class Trajectory:
    T: np.ndarray                  # segment durations (m,)
    C: np.ndarray                  # coefficients (4, m, 8): x, y, z, yaw
    waypoints: np.ndarray          # (m+1, 4)
    t0: float = 0.0                # absolute start time
    report: dict = field(default_factory=dict)

    @property
    def duration(self) -> float:
        return float(self.T.sum())

    def _seg(self, t: float):
        t = min(max(t, 0.0), self.duration)
        acc = np.cumsum(self.T)
        i = int(np.searchsorted(acc, t, side="right"))
        i = min(i, len(self.T) - 1)
        ts = t - (acc[i] - self.T[i])
        return i, min(max(ts / self.T[i], 0.0), 1.0)

    def deriv(self, t: float, r: int) -> np.ndarray:
        """r-th time derivative of (x, y, z, yaw) at local time t (clamped to [0, duration])."""
        if t >= self.duration and r > 0:
            i, s = len(self.T) - 1, 1.0
        else:
            i, s = self._seg(t)
        return self.C[:, i, :] @ _basis(s, r) / self.T[i] ** r

    def eval(self, t: float) -> dict:
        d = [self.deriv(t, r) for r in range(5)]
        return {"pos": d[0][:3], "vel": d[1][:3], "acc": d[2][:3], "jerk": d[3][:3], "snap": d[4][:3],
                "yaw": float(d[0][3]), "yaw_rate": float(d[1][3]), "yaw_acc": float(d[2][3])}

    def sample(self, dt: float = 0.05) -> dict:
        ts = np.arange(0.0, self.duration + 1e-9, dt)
        acc = np.cumsum(self.T)
        seg = np.minimum(np.searchsorted(acc, ts, side="right"), len(self.T) - 1)
        s = np.clip((ts - (acc[seg] - self.T[seg])) / self.T[seg], 0.0, 1.0)
        res = {"t": ts}
        Cs = self.C[:, seg, :]                       # (4, N, 8)
        for r, k in enumerate(("pos", "vel", "acc", "jerk", "snap")):
            B = _DC[r][None, :] * np.power(s[:, None], _POW[r][None, :])
            v = np.einsum("ank,nk->an", Cs, B) / (self.T[seg] ** r)[None, :]
            res[k] = v[:3].T
            if r == 0:
                res["yaw"] = v[3]
        return res


def _alloc_time(d: float, v: float, a: float) -> float:
    if d < 1e-6:
        return 0.5
    if d < v * v / a:
        return 2.0 * np.sqrt(d / a)
    return d / v + v / a


def solve(wps4: np.ndarray, T: np.ndarray, v0=None, a0=None, j0=None, yaw_rate0=0.0) -> np.ndarray:
    v0 = np.zeros(3) if v0 is None else v0
    a0 = np.zeros(3) if a0 is None else a0
    j0 = np.zeros(3) if j0 is None else j0
    C = np.zeros((4, len(T), NC))
    for ax in range(3):
        C[ax] = solve_axis(wps4[:, ax], T, (v0[ax], a0[ax], j0[ax]), (0.0, 0.0, 0.0))
    C[3] = solve_axis(wps4[:, 3], T, (yaw_rate0, 0.0, 0.0), (0.0, 0.0, 0.0))
    return C


def yaw_waypoints(pts: np.ndarray, yaw0: float, mode: str = "velocity", fixed: float = 0.0) -> np.ndarray:
    """Yaw at each waypoint: heading of the next segment (unwrapped), or a fixed value."""
    n = len(pts)
    if mode == "fixed":
        return np.full(n, fixed)
    yaws = [yaw0]
    for i in range(1, n):
        d = pts[min(i, n - 1)] - pts[i - 1] if i == n - 1 else pts[i + 1] - pts[i]
        if np.linalg.norm(d[:2]) < 0.3:
            y = yaws[-1]
        else:
            y = np.arctan2(d[1], d[0])
        prev = yaws[-1]
        y = prev + (y - prev + np.pi) % (2 * np.pi) - np.pi
        yaws.append(y)
    return np.array(yaws)


def generate(points, cfg, mass: float, max_motor_thrust: float, max_tilt_deg: float,
             v0=None, a0=None, yaw0: float = 0.0, yaw_rate0: float = 0.0, grid=None, max_iter: int = 12) -> Trajectory:
    """Feasible, collision-checked minimum-snap trajectory through `points` (n, 3)."""
    pts = np.asarray(points, float)
    if not np.all(np.isfinite(pts)) or np.abs(pts).max() > 1e4:
        raise ValueError("trajectory waypoints are not finite / out of range")
    keep = [0]
    for i in range(1, len(pts)):
        if np.linalg.norm(pts[i] - pts[keep[-1]]) > 0.05:
            keep.append(i)
    pts = pts[keep]
    if len(pts) < 2:
        pts = np.vstack([pts[0], pts[0] + np.array([0, 0, 0.01])])
    # subdivide long segments: a single degree-7 segment has a bell-shaped speed profile, shorter
    # segments let the trajectory cruise near the speed limit and stay close to the straight path
    seg_max = max(2.0, 1.2 * cfg.max_velocity, float(np.linalg.norm(np.diff(pts, axis=0), axis=1).sum()) / 60.0)  # <= ~60 segments
    dense = [pts[0]]
    for a_, b_ in zip(pts[:-1], pts[1:]):
        k = int(np.ceil(np.linalg.norm(b_ - a_) / seg_max))
        for i in range(1, k + 1):
            dense.append(a_ + (b_ - a_) * i / k)
    pts = np.array(dense)
    v0 = np.zeros(3) if v0 is None else np.asarray(v0, float)
    a0 = np.zeros(3) if a0 is None else np.asarray(a0, float)
    report = {"time_scaling_iterations": 0, "collision_iterations": 0, "collision_free": True}
    max_col_iter = 4
    for col_it in range(max_col_iter):
        yaws = yaw_waypoints(pts, yaw0, cfg.yaw_mode, cfg.fixed_yaw)
        wps4 = np.c_[pts, yaws]
        d = np.linalg.norm(np.diff(pts, axis=0), axis=1)
        dyaw = np.abs(np.diff(yaws))
        # cruise allocation d/v per segment (min-snap does not stop at interior waypoints), plus
        # the acceleration / deceleration phases on the first and last segment; violations are
        # then removed by the global time scaling below
        v, a = cfg.max_velocity, cfg.max_acceleration
        T = np.array([max(di / v * 1.15, dy / cfg.max_yaw_rate * 1.5, 0.4) for di, dy in zip(d, dyaw)])
        if len(T) == 1:
            T[0] = max(T[0], _alloc_time(d[0], v, a))
        else:
            T[0] = max(T[0], _alloc_time(d[0], v, a) * 0.75 + 0.5 * v / a)
            T[-1] = max(T[-1], _alloc_time(d[-1], v, a) * 0.75 + 0.5 * v / a)
        T = T * cfg.time_allocation_factor
        if cfg.trajectory_duration is not None:
            T *= cfg.trajectory_duration / T.sum()
        a_tilt = GRAVITY * np.tan(np.deg2rad(max_tilt_deg)) * 0.9
        a_thrust = 0.85 * 4 * max_motor_thrust / mass - GRAVITY
        for it in range(max_iter):
            C = solve(wps4, T, v0, a0, None, yaw_rate0)
            tr = Trajectory(T.copy(), C, wps4)
            smp = tr.sample(min(0.02, tr.duration / 50))
            vm = np.linalg.norm(smp["vel"], axis=1).max()
            am = np.linalg.norm(smp["acc"], axis=1).max()
            jm = np.linalg.norm(smp["jerk"], axis=1).max()
            sm = np.linalg.norm(smp["snap"], axis=1).max()
            ahm = np.linalg.norm(smp["acc"][:, :2], axis=1).max()
            atm = (np.linalg.norm(smp["acc"] + np.array([0, 0, GRAVITY]), axis=1) - GRAVITY).max()
            yr = np.abs(np.gradient(smp["yaw"], smp["t"])).max() if len(smp["t"]) > 2 else 0.0
            ratio = max(vm / cfg.max_velocity, np.sqrt(am / cfg.max_acceleration), np.cbrt(jm / cfg.max_jerk),
                        (sm / cfg.max_snap) ** 0.25, np.sqrt(max(ahm, 0) / a_tilt), np.sqrt(max(atm, 0) / max(a_thrust, 0.1)),
                        yr / cfg.max_yaw_rate)
            report.update(max_velocity=float(vm), max_acceleration=float(am), max_jerk=float(jm), max_snap=float(sm),
                          max_yaw_rate=float(yr), limit_ratio=float(ratio), time_scaling_iterations=it)
            if ratio <= 1.0 + 1e-3 or cfg.trajectory_duration is not None:
                break
            T = T * max(ratio, 1.03) ** (1.0 if it < 6 else 0.5)
        report["within_limits"] = bool(report["limit_ratio"] <= 1.0 + 1e-3)
        if grid is None:
            break
        free = grid.points_free(smp["pos"], hard=True)
        if free.all() or len(T) >= 40:
            break
        report["collision_iterations"] = col_it + 1
        # insert midpoints into the segments that contain collisions
        acc = np.cumsum(T)
        bad_segs = sorted(set(int(min(np.searchsorted(acc, t, side="right"), len(T) - 1)) for t in smp["t"][~free]))
        new_pts = [pts[0]]
        for i in range(len(T)):
            if i in bad_segs:
                new_pts.append(0.5 * (pts[i] + pts[i + 1]))
            new_pts.append(pts[i + 1])
        pts = np.array(new_pts)
    if grid is not None:
        report["collision_free"] = bool(grid.points_free(tr.sample(0.05)["pos"], hard=True).all())
    report["duration"] = tr.duration
    report["segments"] = len(tr.T)
    tr.report = report
    return tr
