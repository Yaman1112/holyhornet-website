"""Quadrotor differential flatness: flat outputs (x, y, z, yaw) and their derivatives ->
thrust, attitude, body rates, body angular acceleration and torques.

    t  = a + g e3,  T = m |t|,  z_B = t / |t|
    x_C = (cos psi, sin psi, 0),  y_B = (z_B x x_C)/|z_B x x_C|,  x_B = y_B x z_B,  R = [x_B y_B z_B]

Exact derivatives (no small-angle approximation): with n = |t|, w = j - (z_B.j) z_B,
    z_B'  = w / n
    z_B'' = (w' n - w n') / n^2,   n' = z_B.j,   w' = s - (z_B'.j + z_B.s) z_B - (z_B.j) z_B'
and y_B', y_B'', x_B', x_B'' by differentiating the normalised cross products. Then
    [w]x = R^T R',        [alpha]x = R^T R'' + R'^T R'
    M = J alpha + w x J w
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..math3d import GRAVITY, E3


@dataclass
class FlatState:
    T: float
    R: np.ndarray
    omega: np.ndarray
    alpha: np.ndarray
    M: np.ndarray
    thrust_dot: float


def flat_to_state(a, j, s, yaw, yaw_rate, yaw_acc, mass: float, J: np.ndarray) -> FlatState:
    a, j, s = np.asarray(a, float), np.asarray(j, float), np.asarray(s, float)
    t = a + GRAVITY * E3
    n = np.linalg.norm(t)
    zb = t / n
    nd = zb @ j
    w = j - nd * zb
    zbd = w / n
    wd = s - (zbd @ j + zb @ s) * zb - nd * zbd
    zbdd = (wd * n - w * nd) / n**2
    c, si = np.cos(yaw), np.sin(yaw)
    xc = np.array([c, si, 0.0])
    xcd = yaw_rate * np.array([-si, c, 0.0])
    xcdd = yaw_acc * np.array([-si, c, 0.0]) - yaw_rate**2 * np.array([c, si, 0.0])
    u = np.cross(zb, xc)
    mu = np.linalg.norm(u)
    yb = u / mu
    ud = np.cross(zbd, xc) + np.cross(zb, xcd)
    mud = yb @ ud
    ybd = (ud - mud * yb) / mu
    udd = np.cross(zbdd, xc) + 2 * np.cross(zbd, xcd) + np.cross(zb, xcdd)
    mudd = ybd @ ud + yb @ udd
    ybdd = (udd - mudd * yb - 2 * mud * ybd) / mu
    xb = np.cross(yb, zb)
    xbd = np.cross(ybd, zb) + np.cross(yb, zbd)
    xbdd = np.cross(ybdd, zb) + 2 * np.cross(ybd, zbd) + np.cross(yb, zbdd)
    R = np.column_stack([xb, yb, zb])
    Rd = np.column_stack([xbd, ybd, zbd])
    Rdd = np.column_stack([xbdd, ybdd, zbdd])
    W = R.T @ Rd
    A = R.T @ Rdd + Rd.T @ Rd
    omega = np.array([W[2, 1] - W[1, 2], W[0, 2] - W[2, 0], W[1, 0] - W[0, 1]]) * 0.5
    alpha = np.array([A[2, 1] - A[1, 2], A[0, 2] - A[2, 0], A[1, 0] - A[0, 1]]) * 0.5
    M = J @ alpha + np.cross(omega, J @ omega)
    return FlatState(mass * n, R, omega, alpha, M, mass * nd)


def feasibility(traj, mass: float, J: np.ndarray, airframe, max_tilt_deg: float, dt: float = 0.02) -> dict:
    """Sample a trajectory and check thrust, per-motor thrust and tilt limits."""
    ts = np.arange(0.0, traj.duration + 1e-9, dt)
    T_max = 0.0
    T_min = np.inf
    tilt_max = 0.0
    motor_max = 0.0
    motor_min = np.inf
    w_max = 0.0
    for t in ts:
        r = traj.eval(t)
        fs = flat_to_state(r["acc"], r["jerk"], r["snap"], r["yaw"], r["yaw_rate"], r["yaw_acc"], mass, J)
        f = airframe.A_inv @ np.r_[fs.T, fs.M]
        T_max, T_min = max(T_max, fs.T), min(T_min, fs.T)
        motor_max, motor_min = max(motor_max, f.max()), min(motor_min, f.min())
        tilt_max = max(tilt_max, np.degrees(np.arccos(np.clip(fs.R[2, 2], -1, 1))))
        w_max = max(w_max, float(np.linalg.norm(fs.omega)))
    cfg = airframe.cfg
    ok = (motor_max <= cfg.max_motor_thrust) and (motor_min >= 0.0) and (tilt_max <= max_tilt_deg)
    return {"feasible": bool(ok), "thrust_max": T_max, "thrust_min": T_min, "motor_max": motor_max,
            "motor_min": motor_min, "tilt_max_deg": tilt_max, "omega_max": w_max}
