"""3D log-odds occupancy map and point cloud, built only from LiDAR scans and estimated poses.

Each scan is inserted with the EKF pose at the scan time. For every ray the voxels traversed
before the return are updated with `log_odds_miss` (free) and the end voxel with `log_odds_hit`
(occupied); rays with no return carve free space up to max range. Each voxel is updated at most
once per scan; values are clamped to [log_odds_min, log_odds_max] so that space vacated by a
moving obstacle becomes free again.

Cell state: occupied (L > occupied_threshold), free (L < free_threshold), unknown otherwise
(never observed: L = 0).
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from ..config import MappingConfig
from ..math3d import quat_to_rot

UNKNOWN, FREE, OCCUPIED = 0, 1, 2


class OccupancyMap:
    def __init__(self, cfg: MappingConfig, bmin, bmax):
        self.cfg = cfg
        self.res = cfg.voxel_size
        self.origin = np.array(bmin, float)
        self.shape = tuple(int(x) for x in np.ceil((np.array(bmax) - self.origin) / self.res))
        self.L = np.zeros(self.shape, np.float32)
        self.observed = np.zeros(self.shape, bool)
        self._pc_keys: set[int] = set()
        self._pc_new: list[np.ndarray] = []
        self.points = np.zeros((0, 3), np.float32)
        self.n_scans = 0
        self.version = 0

    # ------------------------------------------------------------------ indexing
    def index(self, pts: np.ndarray) -> np.ndarray:
        return np.floor((pts - self.origin) / self.res).astype(int)

    def inside(self, ijk: np.ndarray) -> np.ndarray:
        return np.all((ijk >= 0) & (ijk < np.array(self.shape)), axis=-1)

    def center(self, ijk: np.ndarray) -> np.ndarray:
        return self.origin + (np.asarray(ijk) + 0.5) * self.res

    def flat(self, ijk: np.ndarray) -> np.ndarray:
        return np.ravel_multi_index(ijk.T, self.shape)

    # ------------------------------------------------------------------ insertion
    def insert_scan(self, ranges: np.ndarray, dirs_sensor: np.ndarray, max_range: float,
                    p: np.ndarray, q: np.ndarray, R_bl: np.ndarray, t_bl: np.ndarray) -> np.ndarray:
        """Integrate one scan; returns world-frame hit points."""
        cfg = self.cfg
        R = quat_to_rot(q)
        origin = p + R @ t_bl
        dirs = dirs_sensor @ (R @ R_bl).T
        valid = ~np.isnan(ranges)
        hit = valid & np.isfinite(ranges)
        free_len = np.where(hit, ranges - 0.5 * self.res, np.where(valid, max_range, 0.0))
        free_len = np.maximum(free_len, 0.0)
        step = 0.5 * self.res
        n_s = int(np.ceil(max_range / step))
        s = (np.arange(n_s) + 0.5) * step
        mask = s[None, :] < free_len[:, None]
        pts = origin + dirs[:, None, :] * s[None, :, None]
        free_pts = pts[mask]
        hit_pts = origin + dirs[hit] * ranges[hit][:, None]
        f_ijk = self.index(free_pts)
        f_ijk = f_ijk[self.inside(f_ijk)]
        h_ijk = self.index(hit_pts)
        h_in = self.inside(h_ijk)
        h_flat = np.unique(self.flat(h_ijk[h_in])) if h_in.any() else np.zeros(0, int)
        f_flat = np.unique(self.flat(f_ijk)) if len(f_ijk) else np.zeros(0, int)
        f_flat = np.setdiff1d(f_flat, h_flat, assume_unique=True)
        Lf = self.L.reshape(-1)
        Of = self.observed.reshape(-1)
        Lf[f_flat] = np.clip(Lf[f_flat] + cfg.log_odds_miss, cfg.log_odds_min, cfg.log_odds_max)
        Lf[h_flat] = np.clip(Lf[h_flat] + cfg.log_odds_hit, cfg.log_odds_min, cfg.log_odds_max)
        Of[f_flat] = True
        Of[h_flat] = True
        self._add_points(hit_pts[h_in])
        self.n_scans += 1
        self.version += 1
        return hit_pts

    def _add_points(self, pts: np.ndarray) -> None:
        if len(pts) == 0 or len(self._pc_keys) >= self.cfg.max_points:
            return
        r = self.cfg.pointcloud_voxel
        k = np.floor((pts - self.origin) / r).astype(np.int64)
        keys = (k[:, 0] * 100003 + k[:, 1]) * 100003 + k[:, 2]
        _, first = np.unique(keys, return_index=True)
        new = [i for i in first if int(keys[i]) not in self._pc_keys]
        if not new:
            return
        for i in new:
            self._pc_keys.add(int(keys[i]))
        cent = (self.origin + (k[new] + 0.5) * r).astype(np.float32)
        self._pc_new.append(cent)
        self.points = np.vstack([self.points, cent])

    def take_new_points(self) -> np.ndarray:
        if not self._pc_new:
            return np.zeros((0, 3), np.float32)
        out = np.vstack(self._pc_new)
        self._pc_new = []
        return out

    # ------------------------------------------------------------------ queries
    def state(self) -> np.ndarray:
        s = np.zeros(self.shape, np.uint8)
        s[self.L < self.cfg.free_threshold] = FREE
        s[self.L > self.cfg.occupied_threshold] = OCCUPIED
        s[~self.observed] = UNKNOWN
        return s

    def occupied_centers(self) -> np.ndarray:
        return self.center(np.argwhere(self.L > self.cfg.occupied_threshold))

    def counts(self) -> dict:
        st = self.state()
        return {"occupied": int((st == OCCUPIED).sum()), "free": int((st == FREE).sum()),
                "unknown": int((st == UNKNOWN).sum()), "total": int(st.size)}

    # ------------------------------------------------------------------ persistence
    def save(self, path: str | Path, landmarks: list[dict] | None = None) -> None:
        path = Path(path)
        np.savez_compressed(path.with_suffix(".npz"), L=self.L, observed=self.observed, origin=self.origin,
                            res=np.array([self.res]), points=self.points)
        meta = {"shape": list(self.shape), "res": self.res, "origin": self.origin.tolist(), "landmarks": landmarks or [],
                "n_scans": self.n_scans, "mapping": self.cfg.model_dump()}
        path.with_suffix(".json").write_text(json.dumps(meta, indent=1))

    @classmethod
    def load(cls, path: str | Path) -> tuple["OccupancyMap", list[dict]]:
        path = Path(path)
        meta = json.loads(path.with_suffix(".json").read_text())
        d = np.load(path.with_suffix(".npz"))
        cfg = MappingConfig.model_validate(meta["mapping"])
        origin = d["origin"]
        bmax = origin + np.array(meta["shape"]) * meta["res"]
        m = cls(cfg, origin, bmax)
        m.L = d["L"]
        m.observed = d["observed"]
        m.points = d["points"]
        m.n_scans = meta["n_scans"]
        r = cfg.pointcloud_voxel
        k = np.floor((m.points - m.origin) / r).astype(np.int64)
        m._pc_keys = set(((k[:, 0] * 100003 + k[:, 1]) * 100003 + k[:, 2]).tolist())
        return m, meta["landmarks"]
