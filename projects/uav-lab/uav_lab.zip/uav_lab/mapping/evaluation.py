"""Map accuracy against ground truth (evaluation only; never used by the vehicle).

Voxel metrics on cells the vehicle has observed:
    precision = TP / (TP + FP), recall = TP / (TP + FN), IoU = TP / (TP + FP + FN)
where positives are occupied cells. Coverage = fraction of ground-truth free space (below the
flight ceiling) that the map knows to be free; surface recall = fraction of ground-truth
surface voxels (occupied with a free 6-neighbour) inside the explored region that are mapped
occupied.
"""

from __future__ import annotations

import numpy as np
from scipy import ndimage

from .occupancy import FREE, OCCUPIED, OccupancyMap


class MapEvaluator:
    def __init__(self, gt_occ: np.ndarray, z_ceiling_idx: int | None = None):
        self.gt = gt_occ
        gt_free = ~gt_occ
        self.surface = gt_occ & ndimage.binary_dilation(gt_free, structure=ndimage.generate_binary_structure(3, 1))
        self.zc = z_ceiling_idx if z_ceiling_idx is not None else gt_occ.shape[2]
        self.gt_free_count = int(gt_free[:, :, : self.zc].sum())

    def evaluate(self, m: OccupancyMap) -> dict:
        st = m.state()
        obs = st != 0
        pred_occ = st == OCCUPIED
        gt = self.gt
        tp = int((pred_occ & gt & obs).sum())
        fp = int((pred_occ & ~gt & obs).sum())
        fn = int((~pred_occ & gt & obs).sum())
        tn = int((~pred_occ & ~gt & obs).sum())
        n_obs = max(int(obs.sum()), 1)
        explored = ndimage.binary_dilation(obs, iterations=1)
        surf = self.surface & explored
        known_free = int(((st == FREE) & ~gt)[:, :, : self.zc].sum())
        # tolerate one-voxel misalignment for surface recall (pose error, quantisation)
        occ_dil = ndimage.binary_dilation(pred_occ, iterations=1)
        return {
            "precision": tp / max(tp + fp, 1),
            "recall": tp / max(tp + fn, 1),
            "iou": tp / max(tp + fp + fn, 1),
            "accuracy": (tp + tn) / n_obs,
            "coverage": known_free / max(self.gt_free_count, 1),
            "surface_recall": int((surf & occ_dil).sum()) / max(int(surf.sum()), 1),
            "observed_voxels": n_obs,
            "tp": tp, "fp": fp, "fn": fn,
        }
