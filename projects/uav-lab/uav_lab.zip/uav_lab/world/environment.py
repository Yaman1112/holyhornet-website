"""Ground-truth 3D environment: obstacles, landmarks, ray casting and rendering.

Only the simulator and the sensor models may read this module. The autonomy stack never does.

Obstacles are axis-aligned boxes, vertical cylinders and spheres, plus the ground plane z = 0.
Landmarks are point features attached to obstacle surfaces (window corners, markers, bark
texture...). Each has a hidden true id, a unit appearance descriptor, and a `known` flag; known
landmarks also carry a fiducial id that is printed in the known-landmark database.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import EnvironmentConfig, ObstacleSpec

DESCRIPTOR_DIM = 16


@dataclass
class Landmark:
    true_id: int
    position: np.ndarray
    normal: np.ndarray
    descriptor: np.ndarray
    known: bool
    marker_id: int | None = None          # printed fiducial id (known landmarks only)
    prior_position: np.ndarray | None = None
    prior_std: float = 0.0
    obstacle: int = -1


@dataclass
class Obstacle:
    kind: str
    center: np.ndarray
    size: np.ndarray
    label: str
    color: str
    velocity: np.ndarray = field(default_factory=lambda: np.zeros(3))
    amplitude: float = 0.0
    center0: np.ndarray | None = None

    @property
    def dynamic(self) -> bool:
        return bool(np.any(self.velocity != 0))


def _hex_rgb(h: str) -> np.ndarray:
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float) / 255.0


class Environment:
    def __init__(self, cfg: EnvironmentConfig, start_xy=(0.0, 0.0), goal_xy=(0.0, 0.0)):
        self.cfg = cfg
        self.rng = np.random.default_rng(cfg.seed)
        self.bmin = np.array(cfg.bounds_min, float)
        self.bmax = np.array(cfg.bounds_max, float)
        self.obstacles: list[Obstacle] = []
        self.landmarks: list[Landmark] = []
        self._keepout = [np.array(start_xy, float), np.array(goal_xy, float)]
        if cfg.preset != "custom":
            getattr(self, f"_gen_{cfg.preset}")()
        for o in cfg.obstacles:
            self._add_spec(o)
        self._gen_dynamic()
        self._pack()
        self._gen_landmarks()
        for spec in cfg.landmarks:
            p = np.array(spec.position, float)
            self._add_landmark(p, np.array([0, 0, 1.0]), spec.known, -1, spec.prior_std, np.array(spec.prior_offset))
        self._pack()

    # ------------------------------------------------------------------ generation
    def _free_xy(self, xy, r) -> bool:
        if np.any(xy - r < self.bmin[:2] + 1) or np.any(xy + r > self.bmax[:2] - 1):
            return False
        for k in self._keepout:
            if np.linalg.norm(xy - k) < r + 3.0:
                return False
        for o in self.obstacles:
            rr = 0.5 * max(o.size[0], o.size[1]) if o.kind == "box" else o.size[0]
            if np.linalg.norm(xy - o.center[:2]) < r + rr + 1.6:
                return False
        return True

    def _try_place(self, n, make, attempts=60):
        for _ in range(int(n)):
            for _ in range(attempts):
                ob = make()
                r = 0.5 * max(ob.size[0], ob.size[1]) if ob.kind == "box" else ob.size[0]
                if self._free_xy(ob.center[:2], r):
                    self.obstacles.append(ob)
                    break

    def _rand_xy(self):
        return self.rng.uniform(self.bmin[:2] + 2, self.bmax[:2] - 2)

    def _box(self, xy, w, d, h, label, color):
        return Obstacle("box", np.array([xy[0], xy[1], h / 2]), np.array([w, d, h]), label, color)

    def _cyl(self, xy, r, h, label, color, z0=0.0):
        return Obstacle("cylinder", np.array([xy[0], xy[1], z0 + h / 2]), np.array([r, r, h]), label, color)

    def _gen_urban(self):
        k = self.cfg.obstacle_density
        rng = self.rng
        self._try_place(9 * k, lambda: self._box(self._rand_xy(), rng.uniform(3, 6), rng.uniform(3, 6), rng.uniform(4, 10), "building",
                                                 rng.choice(["#9aa3ad", "#b8a48c", "#8c9cb0", "#a89a90"])))
        def wall():
            if rng.random() < 0.5:
                return self._box(self._rand_xy(), rng.uniform(5, 9), 0.4, rng.uniform(2.5, 4), "wall", "#c4b8a8")
            return self._box(self._rand_xy(), 0.4, rng.uniform(5, 9), rng.uniform(2.5, 4), "wall", "#c4b8a8")
        self._try_place(4 * k, wall)
        self._try_place(8 * k, lambda: self._cyl(self._rand_xy(), rng.uniform(0.3, 0.5), rng.uniform(4, 7), "pillar", "#d8d8d0"))
        self._gen_trees(6 * k)
        self._try_place(3 * k, lambda: Obstacle("sphere", np.array([*self._rand_xy(), rng.uniform(1.5, 3.5)]),
                                                np.full(3, rng.uniform(0.6, 1.0)), "sculpture", "#c06040"))

    def _gen_trees(self, n):
        rng = self.rng
        for _ in range(int(n)):
            for _ in range(60):
                xy = self._rand_xy()
                h = rng.uniform(3, 5)
                rc = rng.uniform(1.0, 1.6)
                if self._free_xy(xy, rc):
                    self.obstacles.append(self._cyl(xy, rng.uniform(0.15, 0.25), h, "tree trunk", "#6b4a2b"))
                    self.obstacles.append(Obstacle("sphere", np.array([xy[0], xy[1], h + 0.6 * rc]), np.full(3, rc), "tree canopy", "#3d7a3a"))
                    break

    def _gen_forest(self):
        self._gen_trees(28 * self.cfg.obstacle_density)
        rng = self.rng
        self._try_place(6 * self.cfg.obstacle_density, lambda: self._box(self._rand_xy(), rng.uniform(1, 2), rng.uniform(1, 2), rng.uniform(0.8, 2), "rock", "#7d7a74"))

    def _gen_warehouse(self):
        rng = self.rng
        k = self.cfg.obstacle_density
        for gx in np.arange(self.bmin[0] + 6, self.bmax[0] - 4, 8):
            for gy in np.arange(self.bmin[1] + 6, self.bmax[1] - 4, 8):
                xy = np.array([gx, gy])
                if self._free_xy(xy, 0.4):
                    self.obstacles.append(self._cyl(xy, 0.4, self.bmax[2], "column", "#b0b0b0"))
        self._try_place(10 * k, lambda: self._box(self._rand_xy(), rng.uniform(6, 10), 1.2, rng.uniform(2.5, 5), "shelf", "#d08a30")
                        if rng.random() < 0.5 else self._box(self._rand_xy(), 1.2, rng.uniform(6, 10), rng.uniform(2.5, 5), "shelf", "#d08a30"))

    def _gen_open(self):
        rng = self.rng
        self._try_place(5 * self.cfg.obstacle_density, lambda: self._cyl(self._rand_xy(), rng.uniform(0.3, 0.6), rng.uniform(3, 6), "pillar", "#d8d8d0"))
        self._try_place(3 * self.cfg.obstacle_density, lambda: self._box(self._rand_xy(), rng.uniform(2, 4), rng.uniform(2, 4), rng.uniform(2, 5), "block", "#9aa3ad"))

    def _add_spec(self, o: ObstacleSpec):
        ob = Obstacle(o.kind, np.array(o.center, float), np.array(o.size, float), o.label, o.color,
                      np.array(o.velocity, float), o.motion_amplitude)
        ob.center0 = ob.center.copy()
        self.obstacles.append(ob)

    def _gen_dynamic(self):
        rng = self.rng
        for _ in range(self.cfg.n_dynamic_obstacles):
            xy = self._rand_xy() * 0.6
            ang = rng.uniform(0, 2 * np.pi)
            ob = Obstacle("cylinder", np.array([xy[0], xy[1], 1.75]), np.array([0.5, 0.5, 3.5]), "moving obstacle", "#e04848",
                          velocity=np.array([np.cos(ang), np.sin(ang), 0.0]) * rng.uniform(0.4, 0.8), amplitude=rng.uniform(4, 7))
            ob.center0 = ob.center.copy()
            self.obstacles.append(ob)

    # ------------------------------------------------------------------ landmarks
    def _surface_point(self, ob: Obstacle):
        rng = self.rng
        if ob.kind == "box":
            half = ob.size / 2
            face = rng.integers(0, 4)
            axis, sgn = (0, 1, 0, 1)[face], (1, 1, -1, -1)[face]
            n = np.zeros(3)
            n[axis] = sgn
            p = ob.center.copy()
            p[axis] += sgn * half[axis]
            other = 1 - axis
            p[other] += rng.uniform(-0.85, 0.85) * half[other]
            p[2] = rng.uniform(0.5, min(ob.size[2], 7.0) - 0.2)
            return p, n
        if ob.kind == "cylinder":
            a = rng.uniform(0, 2 * np.pi)
            n = np.array([np.cos(a), np.sin(a), 0.0])
            p = ob.center + ob.size[0] * n
            p[2] = rng.uniform(0.5, min(ob.center[2] + ob.size[2] / 2, 7.0) - 0.1)
            return p, n
        u = rng.normal(size=3)
        u[2] = abs(u[2]) * 0.5 - 0.2
        n = u / np.linalg.norm(u)
        return ob.center + ob.size[0] * n, n

    def _add_landmark(self, p, n, known, obstacle_idx, prior_std=0.0, prior_offset=None):
        tid = len(self.landmarks)
        d = self.rng.normal(size=DESCRIPTOR_DIM)
        lm = Landmark(tid, p + 0.02 * n, n, d / np.linalg.norm(d), known, obstacle=obstacle_idx)
        if known:
            lm.marker_id = 100 + sum(1 for l in self.landmarks if l.known)
            off = prior_offset if prior_offset is not None else self.rng.normal(scale=self.cfg.known_prior_error, size=3)
            lm.prior_position = lm.position + off
            lm.prior_std = prior_std if prior_std > 0 else self.cfg.known_prior_std
        self.landmarks.append(lm)

    def _gen_landmarks(self):
        static = [i for i, o in enumerate(self.obstacles) if not o.dynamic and o.kind != "sphere" or (o.kind == "sphere" and o.label == "sculpture")]
        if not static:
            self._gen_ground_features()
            return
        weights = np.array([max(self.obstacles[i].size[0] * self.obstacles[i].size[2], 1.0) for i in static])
        weights = weights / weights.sum()
        # known landmarks: spread over different obstacles, preferring large ones
        n_known = min(self.cfg.n_known_landmarks, len(static) * 3)
        order = self.rng.permutation(len(static))
        for j in range(n_known):
            i = static[order[j % len(static)]]
            p, n = self._surface_point(self.obstacles[i])
            self._add_landmark(p, n, True, i)
        for _ in range(self.cfg.n_unknown_landmarks):
            i = static[self.rng.choice(len(static), p=weights)]
            p, n = self._surface_point(self.obstacles[i])
            self._add_landmark(p, n, False, i)
        self._gen_ground_features()

    def _gen_ground_features(self):
        k = 0
        for _ in range(self.cfg.n_ground_features * 3):
            if k >= self.cfg.n_ground_features:
                break
            xy = self.rng.uniform(self.bmin[:2] + 0.5, self.bmax[:2] - 0.5)
            p = np.array([xy[0], xy[1], 0.0])
            if self.obstacles and self.signed_distance(p[None] + [0, 0, 0.05])[0] < 0.2:
                continue
            self._add_landmark(p, np.array([0.0, 0.0, 1.0]), False, -2)
            k += 1

    def known_database(self) -> list[dict]:
        """What the vehicle is given: marker id, prior coordinates and prior std. No true positions."""
        return [{"marker_id": l.marker_id, "position": l.prior_position.tolist(), "std": l.prior_std, "descriptor": l.descriptor.tolist()}
                for l in self.landmarks if l.known]

    # ------------------------------------------------------------------ dynamics
    def update(self, t: float) -> None:
        moved = False
        for ob in self.obstacles:
            if ob.dynamic:
                if ob.amplitude > 0:
                    speed = np.linalg.norm(ob.velocity)
                    w = speed / ob.amplitude
                    ob.center = ob.center0 + ob.velocity / max(speed, 1e-9) * ob.amplitude * np.sin(w * t)
                else:
                    ob.center = ob.center0 + ob.velocity * t
                moved = True
        if moved:
            self._pack()

    def _pack(self):
        def arr(kind):
            obs = [(i, o) for i, o in enumerate(self.obstacles) if o.kind == kind]
            idx = np.array([i for i, _ in obs], int)
            c = np.array([o.center for _, o in obs]).reshape(-1, 3)
            s = np.array([o.size for _, o in obs]).reshape(-1, 3)
            return idx, c, s
        self._box_idx, bc, bs = arr("box")
        self._box_min, self._box_max = bc - bs / 2, bc + bs / 2
        self._cyl_idx, self._cyl_c, cs = arr("cylinder")
        self._cyl_r, self._cyl_h = cs[:, 0], cs[:, 2]
        self._sph_idx, self._sph_c, ss = arr("sphere")
        self._sph_r = ss[:, 0]
        self._colors = np.array([_hex_rgb(o.color) for o in self.obstacles]).reshape(-1, 3)
        self.lm_pos = np.array([l.position for l in self.landmarks]).reshape(-1, 3)

    # ------------------------------------------------------------------ ray casting
    def raycast(self, origins: np.ndarray, dirs: np.ndarray, max_range: float) -> tuple[np.ndarray, np.ndarray]:
        """Distance along each unit ray to the first surface (inf if none within max_range),
        and the index of the obstacle hit (-1 none, -2 ground)."""
        o = np.atleast_2d(origins)
        d = np.atleast_2d(dirs)
        n = d.shape[0]
        if o.shape[0] == 1 and n > 1:
            o = np.broadcast_to(o, d.shape)
        best = np.full(n, np.inf)
        hit = np.full(n, -1, int)
        with np.errstate(divide="ignore", invalid="ignore"):
            # ground
            tg = np.where(d[:, 2] < -1e-9, -o[:, 2] / d[:, 2], np.inf)
            tg = np.where(tg >= 0, tg, np.inf)
            m = tg < best
            best[m], hit[m] = tg[m], -2
            # boxes (slab test)
            if len(self._box_idx):
                inv = 1.0 / d[:, None, :]
                t1 = (self._box_min[None] - o[:, None, :]) * inv
                t2 = (self._box_max[None] - o[:, None, :]) * inv
                tmin = np.nanmax(np.minimum(t1, t2), axis=2)
                tmax = np.nanmin(np.maximum(t1, t2), axis=2)
                ok = (tmax >= np.maximum(tmin, 0))
                t = np.where(ok, np.where(tmin > 0, tmin, 0.0), np.inf)
                j = np.argmin(t, axis=1)
                tb = t[np.arange(n), j]
                m = tb < best
                best[m], hit[m] = tb[m], self._box_idx[j[m]]
            # vertical cylinders (side + caps)
            if len(self._cyl_idx):
                ox = o[:, None, 0] - self._cyl_c[None, :, 0]
                oy = o[:, None, 1] - self._cyl_c[None, :, 1]
                dx, dy, dz = d[:, None, 0], d[:, None, 1], d[:, None, 2]
                a = dx * dx + dy * dy
                b = 2 * (ox * dx + oy * dy)
                c = ox * ox + oy * oy - self._cyl_r[None] ** 2
                disc = b * b - 4 * a * c
                sq = np.sqrt(np.maximum(disc, 0))
                ts = (-b - sq) / (2 * a)
                ts = np.where(ts < 0, (-b + sq) / (2 * a), ts)
                zlo = self._cyl_c[None, :, 2] - self._cyl_h[None] / 2
                zhi = self._cyl_c[None, :, 2] + self._cyl_h[None] / 2
                zs = o[:, None, 2] + ts * dz
                side = np.where((disc >= 0) & (a > 1e-12) & (ts >= 0) & (zs >= zlo) & (zs <= zhi), ts, np.inf)
                tc = np.full_like(side, np.inf)
                for zc in (zlo, zhi):
                    tcap = (zc - o[:, None, 2]) / dz
                    px, py = ox + tcap * dx, oy + tcap * dy
                    okc = (tcap >= 0) & (px * px + py * py <= self._cyl_r[None] ** 2)
                    tc = np.minimum(tc, np.where(okc, tcap, np.inf))
                inside = (c <= 0) & (o[:, None, 2] >= zlo) & (o[:, None, 2] <= zhi)
                t = np.where(inside, 0.0, np.minimum(side, tc))
                j = np.argmin(t, axis=1)
                tcm = t[np.arange(n), j]
                m = tcm < best
                best[m], hit[m] = tcm[m], self._cyl_idx[j[m]]
            # spheres
            if len(self._sph_idx):
                oc = o[:, None, :] - self._sph_c[None]
                b = np.einsum("nkj,nj->nk", oc, d)
                c = np.einsum("nkj,nkj->nk", oc, oc) - self._sph_r[None] ** 2
                disc = b * b - c
                sq = np.sqrt(np.maximum(disc, 0))
                t0 = -b - sq
                t = np.where(c <= 0, 0.0, np.where((disc >= 0) & (t0 >= 0), t0, np.inf))
                j = np.argmin(t, axis=1)
                tsp = t[np.arange(n), j]
                m = tsp < best
                best[m], hit[m] = tsp[m], self._sph_idx[j[m]]
        out = best > max_range
        best[out] = np.inf
        hit[out] = -1
        return best, hit

    def normals(self, points: np.ndarray, hit: np.ndarray) -> np.ndarray:
        nrm = np.zeros_like(points)
        nrm[hit == -2] = [0, 0, 1]
        for i in np.unique(hit[hit >= 0]):
            m = hit == i
            ob = self.obstacles[i]
            rel = points[m] - ob.center
            if ob.kind == "sphere":
                nrm[m] = rel
            elif ob.kind == "cylinder":
                top = np.abs(np.abs(rel[:, 2]) - ob.size[2] / 2) < 1e-3
                nr = rel.copy()
                nr[:, 2] = 0
                nr[top] = np.c_[np.zeros((top.sum(), 2)), np.sign(rel[top, 2])]
                nrm[m] = nr
            else:
                q = rel / (ob.size / 2)
                ax = np.argmax(np.abs(q), axis=1)
                nr = np.zeros_like(rel)
                nr[np.arange(len(ax)), ax] = np.sign(q[np.arange(len(ax)), ax])
                nrm[m] = nr
        return nrm / np.maximum(np.linalg.norm(nrm, axis=1, keepdims=True), 1e-9)

    def render(self, origin, dirs, max_range):
        """Shaded RGB (0..1) and depth along rays (for the camera preview)."""
        t, hit = self.raycast(origin, dirs, max_range)
        rgb = np.tile(np.array([0.62, 0.75, 0.90]), (len(t), 1))
        rgb = rgb * (0.85 + 0.15 * np.clip(dirs[:, 2:3], 0, 1))
        ok = np.isfinite(t)
        if ok.any():
            pts = origin + dirs[ok] * t[ok, None]
            nrm = self.normals(pts, hit[ok])
            light = np.array([0.4, 0.3, 0.86])
            shade = 0.45 + 0.55 * np.clip(nrm @ light, 0, 1)
            col = np.empty((ok.sum(), 3))
            g = hit[ok] == -2
            chk = ((np.floor(pts[g, 0]) + np.floor(pts[g, 1])) % 2)[:, None]
            col[g] = np.array([0.42, 0.48, 0.38]) * (0.9 + 0.1 * chk)
            col[~g] = self._colors[hit[ok][~g]]
            fog = np.exp(-t[ok] / (max_range * 1.5))[:, None]
            rgb[ok] = (col * shade[:, None]) * fog + np.array([0.7, 0.75, 0.8]) * (1 - fog)
        return rgb, t, hit

    # ------------------------------------------------------------------ geometry queries
    def signed_distance(self, pts: np.ndarray) -> np.ndarray:
        """Signed distance from points (N,3) to the nearest obstacle surface (ground excluded)."""
        pts = np.atleast_2d(pts)
        d = np.full(len(pts), np.inf)
        if len(self._box_idx):
            c = (self._box_min + self._box_max) / 2
            h = (self._box_max - self._box_min) / 2
            q = np.abs(pts[:, None, :] - c[None]) - h[None]
            out = np.linalg.norm(np.maximum(q, 0), axis=2)
            ins = np.minimum(np.max(q, axis=2), 0)
            d = np.minimum(d, np.min(out + ins, axis=1))
        if len(self._cyl_idx):
            rxy = np.linalg.norm(pts[:, None, :2] - self._cyl_c[None, :, :2], axis=2) - self._cyl_r[None]
            rz = np.abs(pts[:, None, 2] - self._cyl_c[None, :, 2]) - self._cyl_h[None] / 2
            q = np.stack([rxy, rz], -1)
            out = np.linalg.norm(np.maximum(q, 0), axis=2)
            ins = np.minimum(np.max(q, axis=2), 0)
            d = np.minimum(d, np.min(out + ins, axis=1))
        if len(self._sph_idx):
            d = np.minimum(d, np.min(np.linalg.norm(pts[:, None] - self._sph_c[None], axis=2) - self._sph_r[None], axis=1))
        return d

    def occupancy_grid(self, voxel: float) -> tuple[np.ndarray, np.ndarray]:
        """Ground-truth occupancy of voxel centres (bool array) and the grid origin."""
        n = np.ceil((self.bmax - self.bmin) / voxel).astype(int)
        ix = [self.bmin[k] + (np.arange(n[k]) + 0.5) * voxel for k in range(3)]
        X, Y, Z = np.meshgrid(*ix, indexing="ij")
        pts = np.c_[X.ravel(), Y.ravel(), Z.ravel()]
        occ = np.zeros(len(pts), bool)
        for s in range(0, len(pts), 40000):
            occ[s:s + 40000] = self.signed_distance(pts[s:s + 40000]) <= voxel * 0.5
        occ |= pts[:, 2] <= voxel * 0.5          # the ground plane is a real surface too
        return occ.reshape(n), self.bmin.copy()

    def visible(self, origin: np.ndarray, targets: np.ndarray, eps: float = 0.06) -> np.ndarray:
        """Line-of-sight test from origin to each target point (occlusion)."""
        if len(targets) == 0:
            return np.zeros(0, bool)
        v = targets - origin
        dist = np.linalg.norm(v, axis=1)
        t, _ = self.raycast(origin[None], v / dist[:, None], 1e9)
        return t >= dist - eps

    def describe(self) -> dict:
        return {
            "bounds_min": self.bmin.tolist(), "bounds_max": self.bmax.tolist(),
            "obstacles": [{"id": i, "kind": o.kind, "center": o.center.tolist(), "size": o.size.tolist(), "label": o.label,
                           "color": o.color, "dynamic": o.dynamic} for i, o in enumerate(self.obstacles)],
            "landmarks": [{"true_id": l.true_id, "position": l.position.tolist(), "known": l.known, "marker_id": l.marker_id,
                           "prior": None if l.prior_position is None else l.prior_position.tolist()} for l in self.landmarks],
        }
