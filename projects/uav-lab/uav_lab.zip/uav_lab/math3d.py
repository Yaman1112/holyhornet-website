"""Rotation and quaternion utilities (Hamilton, scalar-first, body->world)."""

from __future__ import annotations

import numpy as np

E3 = np.array([0.0, 0.0, 1.0])
GRAVITY = 9.81
G_VEC = np.array([0.0, 0.0, -GRAVITY])


def skew(v: np.ndarray) -> np.ndarray:
    return np.array([[0.0, -v[2], v[1]], [v[2], 0.0, -v[0]], [-v[1], v[0], 0.0]])


def vee(S: np.ndarray) -> np.ndarray:
    """Inverse of skew; takes the antisymmetric part first so it is robust to round-off."""
    A = 0.5 * (S - S.T)
    return np.array([A[2, 1], A[0, 2], A[1, 0]])


def quat_mul(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array([
        aw * bw - ax * bx - ay * by - az * bz,
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
    ])


def quat_conj(q: np.ndarray) -> np.ndarray:
    return np.array([q[0], -q[1], -q[2], -q[3]])


def quat_normalize(q: np.ndarray) -> np.ndarray:
    q = q / np.linalg.norm(q)
    return q if q[0] >= 0 else -q


def quat_to_rot(q: np.ndarray) -> np.ndarray:
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def rot_to_quat(R: np.ndarray) -> np.ndarray:
    tr = np.trace(R)
    if tr > 0:
        s = np.sqrt(tr + 1.0) * 2
        q = [0.25 * s, (R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s]
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        q = [(R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s]
    elif R[1, 1] > R[2, 2]:
        s = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        q = [(R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s]
    else:
        s = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        q = [(R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s]
    return quat_normalize(np.array(q))


def quat_exp(rv: np.ndarray) -> np.ndarray:
    """Quaternion of the rotation vector rv (Exp map)."""
    th = np.linalg.norm(rv)
    if th < 1e-10:
        q = np.array([1.0, 0.5 * rv[0], 0.5 * rv[1], 0.5 * rv[2]])
        return q / np.linalg.norm(q)
    a = rv / th
    s = np.sin(0.5 * th)
    return np.array([np.cos(0.5 * th), a[0] * s, a[1] * s, a[2] * s])


def quat_log(q: np.ndarray) -> np.ndarray:
    q = quat_normalize(q)
    v = q[1:]
    n = np.linalg.norm(v)
    if n < 1e-10:
        return 2.0 * v
    return 2.0 * np.arctan2(n, q[0]) * v / n


def rot_exp(rv: np.ndarray) -> np.ndarray:
    th = np.linalg.norm(rv)
    K = skew(rv)
    if th < 1e-8:
        return np.eye(3) + K + 0.5 * K @ K
    return np.eye(3) + np.sin(th) / th * K + (1 - np.cos(th)) / th**2 * K @ K


def rot_log(R: np.ndarray) -> np.ndarray:
    return quat_log(rot_to_quat(R))


def euler_zyx_from_quat(q: np.ndarray) -> np.ndarray:
    """(roll, pitch, yaw) for R = Rz(yaw) Ry(pitch) Rx(roll)."""
    R = quat_to_rot(q)
    pitch = -np.arcsin(np.clip(R[2, 0], -1, 1))
    roll = np.arctan2(R[2, 1], R[2, 2])
    yaw = np.arctan2(R[1, 0], R[0, 0])
    return np.array([roll, pitch, yaw])


def quat_from_euler_zyx(roll: float, pitch: float, yaw: float) -> np.ndarray:
    cr, sr = np.cos(roll / 2), np.sin(roll / 2)
    cp, sp = np.cos(pitch / 2), np.sin(pitch / 2)
    cy, sy = np.cos(yaw / 2), np.sin(yaw / 2)
    return quat_normalize(np.array([
        cr * cp * cy + sr * sp * sy,
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
    ]))


def rot_z(yaw: float) -> np.ndarray:
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def rot_y(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])


def wrap_pi(a):
    return (np.asarray(a) + np.pi) % (2 * np.pi) - np.pi


# Camera optical frame (x right, y down, z forward) expressed in an FLU body frame.
R_BODY_FROM_OPTICAL = np.array([[0.0, 0.0, 1.0], [-1.0, 0.0, 0.0], [0.0, -1.0, 0.0]])
