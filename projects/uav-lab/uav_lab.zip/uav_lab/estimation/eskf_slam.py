"""Error-state (multiplicative) EKF-SLAM for a quadrotor with an IMU, a camera and landmarks.

Nominal state  x = [p, v, q, b_a, b_g, m_1 .. m_n]           (q: unit quaternion body->world)
Error state   dx = [dp, dv, dth, db_a, db_g, dm_1 .. dm_n]    (15 + 3n), true q = q (x) Exp(dth)

Prediction (IMU, a = a_m - b_a, w = w_m - b_g, R = R(q), g = (0,0,-9.81)):
    p <- p + v dt + 1/2 (R a + g) dt^2
    v <- v + (R a + g) dt
    q <- q (x) Exp(w dt)
    F = d(dx+)/d(dx):
        dp:  I, I dt, -1/2 R[a]x dt^2, -1/2 R dt^2, 0
        dv:  0, I,    -R[a]x dt,        -R dt,        0
        dth: 0, 0,     Exp(w dt)^T,      0,           -I dt
        dba, dbg: identity (random walks)
    Q_d = diag(0, s_a^2 dt I, s_g^2 dt I, s_ba^2 dt I, s_bg^2 dt I)
    Only the robot block and robot-landmark cross terms change: P_rr <- F P_rr F^T + Q_d, P_rm <- F P_rm.

Camera measurement of landmark m (pixel, plus depth for RGB-D):
    p_B = R^T (m - p),  p_C = R_bc^T (p_B - t_bc) = (X, Y, Z)
    h = (fx X/Z + cx, fy Y/Z + cy [, Z])
    dp_C/ddp = -R_bc^T R^T,  dp_C/ddth = R_bc^T [p_B]x,  dp_C/ddm = R_bc^T R^T

Update (batched): S = H P H^T + R, K = P H^T S^-1, dx = K (z - h),
    Joseph form P <- (I - K H) P (I - K H)^T + K R K^T, then symmetrised.
Injection: p += dp, v += dv, q <- q (x) Exp(dth) (renormalised), biases and landmarks additive.
Reset:     P <- G P G^T with G_th = I - 1/2 [dth]x.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import EKFConfig, IMUConfig
from ..math3d import G_VEC, quat_exp, quat_mul, quat_normalize, quat_to_rot, rot_exp, skew

NR = 15  # robot error-state size
IP, IV, ITH, IBA, IBG = slice(0, 3), slice(3, 6), slice(6, 9), slice(9, 12), slice(12, 15)


@dataclass
class CameraModel:
    K: np.ndarray
    R_bc: np.ndarray
    t_bc: np.ndarray
    width: int
    height: int
    rgbd: bool
    min_depth: float
    max_depth: float

    def backproject(self, uv: np.ndarray, depth: float) -> np.ndarray:
        fx, fy, cx, cy = self.K[0, 0], self.K[1, 1], self.K[0, 2], self.K[1, 2]
        return np.array([(uv[0] - cx) / fx * depth, (uv[1] - cy) / fy * depth, depth])

    def backproject_jacobian(self, uv: np.ndarray, depth: float) -> np.ndarray:
        fx, fy, cx, cy = self.K[0, 0], self.K[1, 1], self.K[0, 2], self.K[1, 2]
        return np.array([[depth / fx, 0.0, (uv[0] - cx) / fx],
                         [0.0, depth / fy, (uv[1] - cy) / fy],
                         [0.0, 0.0, 1.0]])


@dataclass
class LandmarkRecord:
    map_id: int
    known: bool
    marker_id: int | None
    descriptor: np.ndarray
    n_obs: int = 0
    n_matched_frames: int = 0
    created_t: float = 0.0
    last_seen_t: float = 0.0
    desc_sum: np.ndarray | None = field(default=None, repr=False)


class ESKFSlam:
    def __init__(self, cfg: EKFConfig, imu: IMUConfig, cam: CameraModel, p0, q0):
        self.cfg = cfg
        self.cam = cam
        self.p = np.array(p0, float)
        self.v = np.zeros(3)
        self.q = quat_normalize(np.array(q0, float))
        self.ba = np.zeros(3)
        self.bg = np.zeros(3)
        self.L = np.zeros((0, 3))
        self.L_fe = np.zeros((0, 3))     # first estimates (FEJ linearisation points)
        self.lms: list[LandmarkRecord] = []
        s = cfg.process_noise_scale
        self.sig_a = imu.accel_noise_density * s
        self.sig_g = imu.gyro_noise_density * s
        self.sig_ba = max(imu.accel_bias_rw * s, 1e-6)
        self.sig_bg = max(imu.gyro_bias_rw * s, 1e-7)
        self.P = np.diag(np.r_[np.full(3, cfg.init_pos_std**2), np.full(3, cfg.init_vel_std**2),
                               np.full(3, np.deg2rad(cfg.init_att_std_deg) ** 2),
                               np.full(3, cfg.init_accel_bias_std**2), np.full(3, cfg.init_gyro_bias_std**2)])
        self.t = 0.0
        self.last_acc = np.zeros(3)
        self.last_gyr = np.zeros(3)
        self.nis_log: list[tuple[float, float, int]] = []   # (t, NIS, dof)
        self.innovations: list[tuple[float, float]] = []    # (t, rms normalised innovation)
        self.rejected_outliers = 0
        # innovation-based adaptive process noise: q_scale follows the camera NIS per degree of
        # freedom (expected value 1); it inflates Q when the IMU is noisier than modelled
        self.q_scale = 1.0          # from the camera NIS
        self.q_scale_imu = 1.0      # from the IMU's own measured noise
        self._nis_ema = 1.0
        self._imu_hist: list[tuple[np.ndarray, np.ndarray]] = []
        self._d2_acc = None
        self._d2_gyr = None
        self.health = {"symmetric": True, "positive_diag": True, "q_norm_err": 0.0, "min_eig_robot": 0.0}

    # ------------------------------------------------------------------ accessors
    @property
    def n(self) -> int:
        return self.L.shape[0]

    @property
    def R(self) -> np.ndarray:
        return quat_to_rot(self.q)

    def lm_slice(self, j: int) -> slice:
        return slice(NR + 3 * j, NR + 3 * j + 3)

    def landmark_cov(self, j: int) -> np.ndarray:
        s = self.lm_slice(j)
        return self.P[s, s]

    # ------------------------------------------------------------------ prediction
    def propagate(self, acc_m: np.ndarray, gyr_m: np.ndarray, dt: float) -> None:
        a = acc_m - self.ba
        w = gyr_m - self.bg
        R = self.R
        acc_w = R @ a + G_VEC
        self.p = self.p + self.v * dt + 0.5 * acc_w * dt * dt
        self.v = self.v + acc_w * dt
        self.q = quat_normalize(quat_mul(self.q, quat_exp(w * dt)))
        F = np.eye(NR)
        Ra = R @ skew(a)
        F[IP, IV] = np.eye(3) * dt
        F[IP, ITH] = -0.5 * Ra * dt * dt
        F[IP, IBA] = -0.5 * R * dt * dt
        F[IV, ITH] = -Ra * dt
        F[IV, IBA] = -R * dt
        F[ITH, ITH] = rot_exp(w * dt).T
        F[ITH, IBG] = -np.eye(3) * dt
        self._measure_imu_noise(acc_m, gyr_m, dt)
        qs = max(self.q_scale, self.q_scale_imu)
        Qd = np.zeros(NR)
        Qd[3:6] = self.sig_a**2 * dt * qs
        Qd[6:9] = self.sig_g**2 * dt * qs
        Qd[9:12] = self.sig_ba**2 * dt
        Qd[12:15] = self.sig_bg**2 * dt
        P = self.P
        P[:NR, :NR] = F @ P[:NR, :NR] @ F.T + np.diag(Qd)
        if self.n:
            P[:NR, NR:] = F @ P[:NR, NR:]
            P[NR:, :NR] = P[:NR, NR:].T
        self.t += dt
        self.last_acc, self.last_gyr = acc_m, gyr_m

    def _measure_imu_noise(self, acc, gyr, dt):
        """Online IMU white-noise estimate from second differences of consecutive samples.

        For white noise n_k with variance s^2, var(n_k - 2 n_(k-1) + n_(k-2)) = 6 s^2, while the
        true motion contributes only ~ (jerk dt^2)^2. The measured per-sample std gives the noise
        density s sqrt(dt); its ratio to the modelled density scales the process noise.
        """
        if not self.cfg.adaptive_process_noise:
            return
        h = self._imu_hist
        h.append((acc.copy(), gyr.copy()))
        if len(h) < 3:
            return
        if len(h) > 3:
            del h[0]
        d2a = h[2][0] - 2 * h[1][0] + h[0][0]
        d2g = h[2][1] - 2 * h[1][1] + h[0][1]
        va, vg = float(d2a @ d2a) / 18.0, float(d2g @ d2g) / 18.0   # per-axis variance of n (3 axes, factor 6)
        a = 0.002
        self._d2_acc = va if self._d2_acc is None else (1 - a) * self._d2_acc + a * va
        self._d2_gyr = vg if self._d2_gyr is None else (1 - a) * self._d2_gyr + a * vg
        dens_a = np.sqrt(self._d2_acc * dt)
        dens_g = np.sqrt(self._d2_gyr * dt)
        r = max(dens_a / max(self.sig_a, 1e-12), dens_g / max(self.sig_g, 1e-12))
        self.q_scale_imu = float(np.clip(r * r, 1.0, self.cfg.adaptive_max_scale))

    # ------------------------------------------------------------------ generic update
    def update(self, z: np.ndarray, h: np.ndarray, H: np.ndarray, Rm: np.ndarray, kind: str = "",
               reject_prob_chi2: float | None = None) -> bool:
        """Batch EKF update with dense H (k x N). Returns False if rejected by the chi-square test."""
        P = self.P
        r = z - h
        PHt = P @ H.T
        S = H @ PHt + Rm
        S = 0.5 * (S + S.T)
        try:
            Sinv_r = np.linalg.solve(S, r)
        except np.linalg.LinAlgError:
            return False
        nis = float(r @ Sinv_r)
        if reject_prob_chi2 is not None and nis > reject_prob_chi2:
            self.rejected_outliers += 1
            return False
        K = np.linalg.solve(S, PHt.T).T
        dx = K @ r
        # Joseph form (I-KH) P (I-KH)^T + K R K^T, expanded so it costs O(N^2 k) instead of O(N^3):
        #   = P - K (HP) - (HP)^T K^T + K (H P H^T + R) K^T
        # It is algebraically identical to the Joseph form for any gain K (hence keeps its
        # robustness to gain errors), and is symmetrised afterwards.
        HP = PHt.T
        KHP = K @ HP
        self.P = P - KHP - KHP.T + K @ S @ K.T
        self._inject(dx)
        self.nis_log.append((self.t, nis, len(z)))
        if kind == "camera" and self.cfg.adaptive_process_noise:
            self._nis_ema = 0.9 * self._nis_ema + 0.1 * nis / len(z)
            target = float(np.clip(self._nis_ema ** 2, 1.0, self.cfg.adaptive_max_scale))
            # rise quickly, decay slowly back to the nominal model
            self.q_scale = target if target > self.q_scale else 0.98 * self.q_scale + 0.02 * target
        self.innovations.append((self.t, float(np.sqrt(nis / max(len(z), 1)))))
        if len(self.nis_log) > 5000:
            del self.nis_log[:1000]
            del self.innovations[:1000]
        return True

    def _inject(self, dx: np.ndarray) -> None:
        self.p = self.p + dx[IP]
        self.v = self.v + dx[IV]
        dth = dx[ITH]
        self.q = quat_normalize(quat_mul(self.q, quat_exp(dth)))
        self.ba = self.ba + dx[IBA]
        self.bg = self.bg + dx[IBG]
        if self.n:
            self.L = self.L + dx[NR:].reshape(-1, 3)
        G = np.eye(3) - 0.5 * skew(dth)
        P = self.P
        P[ITH, :] = G @ P[ITH, :]
        P[:, ITH] = P[:, ITH] @ G.T
        self.P = 0.5 * (P + P.T)
        self._check()

    def _check(self) -> None:
        d = np.diag(self.P)
        self.health["positive_diag"] = bool(np.all(d > 0))
        if not self.health["positive_diag"]:
            # numerical safety net: should not trigger with the Joseph form; counted if it does
            self.P[np.diag_indices_from(self.P)] = np.maximum(d, 1e-12)
        self.health["q_norm_err"] = float(abs(np.linalg.norm(self.q) - 1.0))

    def consistency_check(self) -> dict:
        """Covariance health: symmetry, positive-definiteness of the robot block, quaternion norm."""
        P = self.P
        self.health["symmetric"] = bool(np.abs(P - P.T).max() <= 1e-9 * max(np.abs(P).max(), 1e-12))
        self.health["min_eig_robot"] = float(np.linalg.eigvalsh(P[:NR, :NR]).min())
        self.health["positive_diag"] = bool(np.all(np.diag(P) > 0))
        return dict(self.health)

    # ------------------------------------------------------------------ simple sensors
    def update_baro(self, z: float, sigma: float) -> bool:
        H = np.zeros((1, self.P.shape[0]))
        H[0, 2] = 1.0
        return self.update(np.array([z]), np.array([self.p[2]]), H, np.array([[sigma**2]]), "baro", 15.0)

    def update_gnss(self, z: np.ndarray, sigma: float) -> bool:
        H = np.zeros((3, self.P.shape[0]))
        H[:, IP] = np.eye(3)
        return self.update(z, self.p.copy(), H, np.eye(3) * sigma**2, "gnss", 25.0)

    def zero_velocity_update(self, sigma: float = 0.02) -> None:
        H = np.zeros((3, self.P.shape[0]))
        H[:, IV] = np.eye(3)
        self.update(np.zeros(3), self.v.copy(), H, np.eye(3) * sigma**2, "zupt")

    # ------------------------------------------------------------------ camera model
    def predict_landmark(self, j: int, with_depth: bool):
        """Predicted measurement and Jacobians for landmark j. Returns (h, H_r (k x 15), H_m (k x 3), p_C)."""
        R = self.R
        cam = self.cam
        pB = R.T @ (self.L[j] - self.p)
        pC = cam.R_bc.T @ (pB - cam.t_bc)
        if self.cfg.first_estimate_jacobians:
            # FEJ: Jacobians use the landmark's first estimate; the residual uses the current one
            pB_lin = R.T @ (self.L_fe[j] - self.p)
            pC_lin = cam.R_bc.T @ (pB_lin - cam.t_bc)
        else:
            pB_lin, pC_lin = pB, pC
        X, Y, Z = pC
        fx, fy, cx, cy = cam.K[0, 0], cam.K[1, 1], cam.K[0, 2], cam.K[1, 2]
        Zs = Z if abs(Z) > 1e-6 else 1e-6
        if with_depth:
            h = np.array([fx * X / Zs + cx, fy * Y / Zs + cy, Z])
            Jp = np.array([[fx / Zs, 0.0, -fx * X / Zs**2], [0.0, fy / Zs, -fy * Y / Zs**2], [0.0, 0.0, 1.0]])
        else:
            h = np.array([fx * X / Zs + cx, fy * Y / Zs + cy])
            Jp = np.array([[fx / Zs, 0.0, -fx * X / Zs**2], [0.0, fy / Zs, -fy * Y / Zs**2]])
        if pC_lin is not pC:
            Xl, Yl, Zl = pC_lin
            Zl = Zl if abs(Zl) > 1e-6 else 1e-6
            Jp = np.array([[fx / Zl, 0.0, -fx * Xl / Zl**2], [0.0, fy / Zl, -fy * Yl / Zl**2], [0.0, 0.0, 1.0]])[: len(h)]
            pB = pB_lin
        RcRt = cam.R_bc.T @ R.T
        Hr = np.zeros((len(h), NR))
        Hr[:, IP] = Jp @ (-RcRt)
        Hr[:, ITH] = Jp @ (cam.R_bc.T @ skew(pB))
        Hm = Jp @ RcRt
        return h, Hr, Hm, pC

    def measurement_noise(self, depth: float | None) -> np.ndarray:
        s = self.cfg.pixel_noise_std
        if depth is None:
            return np.eye(2) * s * s
        sd = self.cfg.depth_noise_coeff * max(depth, 0.3) ** 2 + 0.01
        return np.diag([s * s, s * s, sd * sd])

    def camera_update(self, obs: list[tuple[int, np.ndarray, float | None]], reject_chi2: float | None = None) -> bool:
        """Joint update from several landmark observations [(landmark j, uv, depth or None)]."""
        if not obs:
            return False
        N = self.P.shape[0]
        zs, hs, Hs, Rs = [], [], [], []
        for j, uv, depth in obs:
            h, Hr, Hm, _ = self.predict_landmark(j, depth is not None)
            z = np.r_[uv, depth] if depth is not None else uv
            H = np.zeros((len(h), N))
            H[:, :NR] = Hr
            H[:, self.lm_slice(j)] = Hm
            zs.append(z), hs.append(h), Hs.append(H), Rs.append(self.measurement_noise(depth))
        from scipy.linalg import block_diag
        return self.update(np.concatenate(zs), np.concatenate(hs), np.vstack(Hs), block_diag(*Rs), "camera", reject_chi2)

    # ------------------------------------------------------------------ landmark initialisation
    def _append(self, m: np.ndarray, P_mm: np.ndarray, P_mx: np.ndarray, rec: LandmarkRecord) -> int:
        N = self.P.shape[0]
        Pn = np.zeros((N + 3, N + 3))
        Pn[:N, :N] = self.P
        Pn[N:, :N] = P_mx
        Pn[:N, N:] = P_mx.T
        Pn[N:, N:] = 0.5 * (P_mm + P_mm.T)
        self.P = Pn
        self.L = np.vstack([self.L, m])
        self.L_fe = np.vstack([self.L_fe, m])
        self.lms.append(rec)
        return self.n - 1

    def add_landmark_rgbd(self, uv: np.ndarray, depth: float, rec: LandmarkRecord) -> int:
        """Inverse observation model m = p + R (R_bc g(uv, d) + t_bc) with full Jacobian covariance."""
        cam = self.cam
        R = self.R
        pc = cam.backproject(uv, depth)
        pB = cam.R_bc @ pc + cam.t_bc
        m = self.p + R @ pB
        Gx = np.zeros((3, self.P.shape[0]))
        Gx[:, IP] = np.eye(3)
        Gx[:, ITH] = -R @ skew(pB)
        Gz = R @ cam.R_bc @ cam.backproject_jacobian(uv, depth)
        Rz = self.measurement_noise(depth)
        P_mx = Gx @ self.P
        P_mm = Gx @ self.P @ Gx.T + Gz @ Rz @ Gz.T
        return self._append(m, P_mm, P_mx, rec)

    def add_landmark_point(self, m: np.ndarray, rel_cov: np.ndarray, rec: LandmarkRecord, anchor_body: np.ndarray | None = None) -> int:
        """Add a landmark at world point m with uncertainty rel_cov relative to the current pose
        (used for triangulated monocular landmarks). If anchor_body is given, correlations with the
        robot pose are propagated through m = p + R anchor_body."""
        Gx = np.zeros((3, self.P.shape[0]))
        Gx[:, IP] = np.eye(3)
        if anchor_body is not None:
            Gx[:, ITH] = -self.R @ skew(anchor_body)
        P_mx = Gx @ self.P
        P_mm = Gx @ self.P @ Gx.T + rel_cov
        return self._append(np.asarray(m, float), P_mm, P_mx, rec)

    def add_landmark_prior(self, m: np.ndarray, std: float, rec: LandmarkRecord) -> int:
        """Known landmark from the database: independent prior N(m, std^2 I)."""
        return self._append(np.asarray(m, float), np.eye(3) * max(std, 1e-4) ** 2, np.zeros((3, self.P.shape[0])), rec)

    # ------------------------------------------------------------------ evaluation helpers (truth supplied by caller)
    def robot_cov(self) -> np.ndarray:
        return self.P[:NR, :NR]
