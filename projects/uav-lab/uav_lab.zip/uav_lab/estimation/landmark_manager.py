"""Feature tracking and new-landmark initialisation.

Unmatched features become *candidates*. A candidate is tracked across frames (descriptor match
plus a spatial gate: world-point distance for RGB-D, pixel motion for monocular). It is promoted
to a map landmark only after `candidate_min_observations` consistent observations within
`candidate_max_age` seconds; transient clutter therefore never reaches the map.

Initialisation:
* RGB-D: inverse observation model of the latest observation with full Jacobian covariance
  (`ESKFSlam.add_landmark_rgbd`).
* Monocular: delayed initialisation. The candidate stores camera rays from the estimated poses;
  once the parallax between the first and latest ray exceeds `mono_min_parallax_deg`, the point
  is triangulated (midpoint of the closest points of the two rays) and its covariance is taken
  from the triangulation geometry (depth sigma ~ d^2 sigma_px / (f * baseline)).
* Known landmarks: placed in the state at start from the database prior (if enabled), otherwise
  added on first verified marker observation and flagged known.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..config import EKFConfig
from ..sensors.messages import Feature
from .eskf_slam import ESKFSlam, LandmarkRecord


@dataclass
class Candidate:
    cid: int
    descriptor: np.ndarray
    first_t: float
    last_t: float
    n: int = 1
    world_pts: list = field(default_factory=list)        # RGB-D world estimates
    rays: list = field(default_factory=list)             # mono: (origin, unit dir) in world
    last_uv: np.ndarray | None = None
    marker_id: int | None = None
    last_feature: Feature | None = None


class LandmarkManager:
    def __init__(self, cfg: EKFConfig, known_db: list[dict]):
        self.cfg = cfg
        self.candidates: list[Candidate] = []
        self._next_cid = 0
        self._next_map_id = 0
        self.known_db = {d["marker_id"]: d for d in known_db}
        self.promoted = 0
        self.expired = 0

    def new_map_id(self) -> int:
        self._next_map_id += 1
        return self._next_map_id - 1

    def insert_known_priors(self, slam: ESKFSlam, t: float) -> None:
        for mid, d in self.known_db.items():
            rec = LandmarkRecord(self.new_map_id(), True, mid, np.array(d["descriptor"]), created_t=t)
            slam.add_landmark_prior(np.array(d["position"]), d["std"], rec)

    def _world_point(self, slam: ESKFSlam, f: Feature) -> np.ndarray:
        pc = slam.cam.backproject(f.uv, f.depth)
        return slam.p + slam.R @ (slam.cam.R_bc @ pc + slam.cam.t_bc)

    def _ray(self, slam: ESKFSlam, f: Feature):
        cam = slam.cam
        d_c = np.linalg.solve(cam.K, np.array([f.uv[0], f.uv[1], 1.0]))
        R_wc = slam.R @ cam.R_bc
        d = R_wc @ d_c
        return slam.p + slam.R @ cam.t_bc, d / np.linalg.norm(d)

    def process(self, slam: ESKFSlam, features: list[Feature], unmatched: list[int], t: float) -> list[int]:
        """Track unmatched features as candidates and promote mature ones. Returns new landmark indices."""
        cfg = self.cfg
        # expire
        keep = []
        for c in self.candidates:
            if t - c.last_t > 0.6 or t - c.first_t > cfg.candidate_max_age:
                self.expired += 1
            else:
                keep.append(c)
        self.candidates = keep
        new_idx = []
        used = set()
        for fi in unmatched:
            f = features[fi]
            if f.depth is not None and not (cfg.min_init_depth <= f.depth <= cfg.max_init_depth):
                continue
            wp = self._world_point(slam, f) if f.depth is not None else None
            best, best_d = None, cfg.descriptor_gate
            for c in self.candidates:
                if c.cid in used:
                    continue
                dd = float(np.linalg.norm(c.descriptor - f.descriptor))
                if dd >= best_d:
                    continue
                if wp is not None and c.world_pts and np.linalg.norm(wp - np.mean(c.world_pts, axis=0)) > 1.0:
                    continue
                if wp is None and c.last_uv is not None and np.linalg.norm(c.last_uv - f.uv) > 80:
                    continue
                best, best_d = c, dd
            if best is None:
                c = Candidate(self._next_cid, f.descriptor.copy(), t, t, marker_id=f.marker_id)
                self._next_cid += 1
                if wp is not None:
                    c.world_pts.append(wp)
                else:
                    c.rays.append(self._ray(slam, f))
                c.last_uv, c.last_feature = f.uv, f
                self.candidates.append(c)
                used.add(c.cid)
                f.track_id = -1000 - c.cid
                continue
            c = best
            used.add(c.cid)
            c.n += 1
            c.last_t = t
            c.descriptor = (c.descriptor * (c.n - 1) + f.descriptor) / c.n
            c.descriptor /= np.linalg.norm(c.descriptor)
            c.last_uv, c.last_feature = f.uv, f
            f.track_id = -1000 - c.cid
            if f.marker_id is not None:
                c.marker_id = f.marker_id
            if wp is not None:
                c.world_pts.append(wp)
            else:
                c.rays.append(self._ray(slam, f))
            if c.n >= cfg.candidate_min_observations and slam.n < cfg.max_landmarks:
                j = self._promote(slam, c, t)
                if j is not None:
                    new_idx.append(j)
                    f.track_id = slam.lms[j].map_id
        # drop promoted (n set to 1e9) and rejected (n set to 0) candidates
        self.candidates = [c for c in self.candidates if 0 < c.n < 10**9]
        return new_idx

    def _promote(self, slam: ESKFSlam, c: Candidate, t: float) -> int | None:
        cfg = self.cfg
        f = c.last_feature
        known = c.marker_id is not None and c.marker_id in self.known_db and \
            not any(r.marker_id == c.marker_id for r in slam.lms)
        rec = LandmarkRecord(self.new_map_id(), known, c.marker_id if known else None,
                             c.descriptor.copy(), n_obs=c.n, created_t=t, last_seen_t=t)
        if f.depth is not None:
            pts = np.array(c.world_pts)
            if len(pts) >= 2 and np.max(np.linalg.norm(pts - pts.mean(0), axis=1)) > 0.8:
                c.n = 0  # inconsistent track: drop it
                self.expired += 1
                return None
            self.promoted += 1
            c.n = 10**9
            return slam.add_landmark_rgbd(f.uv, f.depth, rec)
        # monocular: triangulate from first and last ray
        (o1, d1), (o2, d2) = c.rays[0], c.rays[-1]
        parallax = np.degrees(np.arccos(np.clip(d1 @ d2, -1, 1)))
        if parallax < cfg.mono_min_parallax_deg:
            return None
        w0 = o1 - o2
        a, b, cc, d, e = d1 @ d1, d1 @ d2, d2 @ d2, d1 @ w0, d2 @ w0
        den = a * cc - b * b
        if den < 1e-9:
            return None
        s = (b * e - cc * d) / den
        u = (a * e - b * d) / den
        if s <= 0 or u <= 0:
            return None
        m = 0.5 * ((o1 + s * d1) + (o2 + u * d2))
        depth = np.linalg.norm(m - o2)
        if not (cfg.min_init_depth <= depth <= cfg.max_init_depth):
            return None
        baseline = np.linalg.norm(o2 - o1)
        fpx = slam.cam.K[0, 0]
        sig_d = max(depth**2 * cfg.pixel_noise_std / (fpx * max(baseline, 1e-3)) * 2.0, 0.05)
        sig_t = depth * cfg.pixel_noise_std / fpx * 2.0 + 0.02
        ray = d2
        rel = sig_d**2 * np.outer(ray, ray) + sig_t**2 * (np.eye(3) - np.outer(ray, ray))
        anchor = slam.R.T @ (m - slam.p)
        self.promoted += 1
        c.n = 10**9
        return slam.add_landmark_point(m, rel, rec, anchor)
