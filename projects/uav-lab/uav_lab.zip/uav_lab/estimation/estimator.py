"""Time-synchronised state estimation with delayed measurements.

Sensors arrive with different transport delays. The EKF therefore runs on a *fusion horizon*
`t_now - max_delay`: all messages (IMU included) are processed strictly in measurement-time
order, so every measurement is fused against the state at the time it was taken. An output
predictor then re-integrates the buffered IMU samples from the horizon to `t_now` (nominal
state only) to give the controller a current, low-latency estimate.

LiDAR scans are not fused in the EKF; they are returned together with the filter pose at the
scan time so the map is built with delay-compensated estimated poses.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass

import numpy as np

from ..config import LabConfig
from ..math3d import G_VEC, quat_exp, quat_mul, quat_normalize, quat_to_rot
from ..sensors.messages import BaroMsg, CameraMsg, GNSSMsg, IMUMsg, LidarMsg
from .association import associate
from .eskf_slam import CameraModel, ESKFSlam
from .landmark_manager import LandmarkManager
from scipy.stats import chi2


@dataclass
class EstimateNow:
    t: float
    p: np.ndarray
    v: np.ndarray
    q: np.ndarray
    w: np.ndarray
    P_pos: np.ndarray
    P_vel: np.ndarray
    P_att: np.ndarray


class StateEstimator:
    def __init__(self, cfg: LabConfig, cam: CameraModel, known_db: list[dict], p0, q0):
        self.cfg = cfg
        self.slam = ESKFSlam(cfg.ekf, cfg.sensors.imu, cam, p0, q0)
        self.lm = LandmarkManager(cfg.ekf, known_db)
        if cfg.ekf.use_known_priors:
            self.lm.insert_known_priors(self.slam, 0.0)
        s = cfg.sensors
        delays = [s.imu.delay]
        if s.camera.enabled:
            delays.append(s.camera.delay)
        if s.lidar.enabled:
            delays.append(s.lidar.delay)
        if s.gnss.enabled:
            delays.append(s.gnss.delay)
        if s.baro.enabled:
            delays.append(s.baro.delay)
        self.horizon = max(delays) + 1e-6
        self.pending: list = []
        self.imu_recent: deque[IMUMsg] = deque()
        self.t_filter = 0.0
        self.last_imu: IMUMsg | None = None
        self.stats = {"matched": 0, "matched_known": 0, "new": 0, "unmatched": 0, "rejected_marker": 0,
                      "ambiguous": 0, "features": 0, "visible_pred": 0, "camera_updates": 0}
        self.last_tracks: list[tuple[np.ndarray, int]] = []
        self.on_ground = True
        self.reject_chi2 = {2: chi2.ppf(cfg.ekf.innovation_outlier_prob, 2), 3: chi2.ppf(cfg.ekf.innovation_outlier_prob, 3)}

    # ------------------------------------------------------------------ input
    def receive(self, msgs: list) -> None:
        for m in msgs:
            self.pending.append(m)
            if isinstance(m, IMUMsg):
                self.imu_recent.append(m)
        self.pending.sort(key=lambda m: (m.t, 0 if isinstance(m, IMUMsg) else 1))

    # ------------------------------------------------------------------ fusion
    def step(self, now: float) -> list[tuple[LidarMsg, np.ndarray, np.ndarray]]:
        horizon_t = now - self.horizon
        scans = []
        k = 0
        while k < len(self.pending) and self.pending[k].t <= horizon_t:
            m = self.pending[k]
            k += 1
            if isinstance(m, IMUMsg):
                dt = m.dt if self.last_imu is None else m.t - self.last_imu.t
                if dt > 0:
                    self.slam.propagate(m.accel, m.gyro, dt)
                self.last_imu = m
                self.t_filter = m.t
                if self.on_ground and int(round(m.t / m.dt)) % 10 == 0:
                    self.slam.zero_velocity_update()
            elif isinstance(m, CameraMsg):
                self._camera(m)
            elif isinstance(m, BaroMsg):
                self.slam.update_baro(m.altitude, self.cfg.ekf.baro_noise_std)
            elif isinstance(m, GNSSMsg):
                self.slam.update_gnss(m.position, self.cfg.ekf.gnss_noise_std)
            elif isinstance(m, LidarMsg):
                scans.append((m, self.slam.p.copy(), self.slam.q.copy()))
        del self.pending[:k]
        while self.imu_recent and self.imu_recent[0].t <= self.t_filter:
            self.imu_recent.popleft()
        return scans

    def _camera(self, m: CameraMsg) -> None:
        cfg = self.cfg.ekf
        slam = self.slam
        feats = m.features
        assoc = associate(feats, slam, cfg.association_gate_prob, cfg.descriptor_gate, cfg.ambiguity_ratio)
        matches = sorted(assoc.matches, key=lambda x: x[2])[: cfg.max_updates_per_frame]
        obs = []
        for fi, j, _ in matches:
            f = feats[fi]
            f.track_id = slam.lms[j].map_id
            rec = slam.lms[j]
            rec.n_obs += 1
            rec.last_seen_t = m.t
            obs.append((j, f.uv, f.depth))
        if obs:
            dof = 3 if obs[0][2] is not None else 2
            ok = slam.camera_update(obs, reject_chi2=self.reject_chi2[dof] * len(obs) if len(obs) == 1 else None)
            if ok:
                self.stats["camera_updates"] += 1
        new = self.lm.process(slam, feats, assoc.unmatched, m.t)
        self.stats.update(features=len(feats), matched=len(obs),
                          matched_known=sum(1 for fi, j, _ in matches if slam.lms[j].known),
                          new=len(new), unmatched=len(assoc.unmatched), rejected_marker=assoc.rejected_marker,
                          ambiguous=assoc.ambiguous, visible_pred=len(assoc.predicted_visible or []))
        self.last_tracks = [(f.uv, f.track_id) for f in feats]

    # ------------------------------------------------------------------ output predictor
    def current(self, now: float) -> EstimateNow:
        s = self.slam
        p, v, q = s.p.copy(), s.v.copy(), s.q.copy()
        last_t = self.t_filter
        gyr = s.last_gyr
        for m in self.imu_recent:
            if m.t <= last_t or m.t > now:
                continue
            dt = m.t - last_t
            a = m.accel - s.ba
            w = m.gyro - s.bg
            acc_w = quat_to_rot(q) @ a + G_VEC
            p = p + v * dt + 0.5 * acc_w * dt * dt
            v = v + acc_w * dt
            q = quat_normalize(quat_mul(q, quat_exp(w * dt)))
            last_t = m.t
            gyr = m.gyro
        P = s.P
        return EstimateNow(now, p, v, q, gyr - s.bg, P[0:3, 0:3].copy(), P[3:6, 3:6].copy(), P[6:9, 6:9].copy())
