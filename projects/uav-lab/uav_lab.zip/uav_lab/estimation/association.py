"""Robust data association between camera features and mapped landmarks.

1. Prediction: for every mapped landmark in front of the camera, compute h_j, H_j and the
   innovation covariance S_j = H_j P H_j^T + R.
2. Known landmarks with a decoded marker id: the id names the candidate; the pairing is
   accepted only if its Mahalanobis distance d^2 = r^T S^-1 r passes the chi-square gate
   (this rejects misread ids).
3. Every other feature: cost = d^2 for pairs that pass both the chi-square gate and the
   descriptor gate. A feature whose best and second-best costs are too close is ambiguous and
   dropped. The remaining assignment is solved globally (Hungarian, one landmark per feature
   and one feature per landmark).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.stats import chi2

from ..sensors.messages import Feature
from .eskf_slam import NR, ESKFSlam


@dataclass
class Association:
    matches: list[tuple[int, int, float]]   # (feature index, landmark index, d^2)
    unmatched: list[int]
    rejected_marker: int = 0
    ambiguous: int = 0
    predicted_visible: list[int] | None = None


def predict_visible(slam: ESKFSlam, margin_px: float = 20.0) -> list[int]:
    cam = slam.cam
    if slam.n == 0:
        return []
    R = slam.R
    pB = (slam.L - slam.p) @ R
    pC = (pB - cam.t_bc) @ cam.R_bc
    Z = pC[:, 2]
    ok = (Z > cam.min_depth * 0.8) & (Z < cam.max_depth * 1.2)
    uv = (pC @ cam.K.T)
    uv = uv[:, :2] / np.where(np.abs(uv[:, 2:3]) > 1e-9, uv[:, 2:3], 1e-9)
    ok &= (uv[:, 0] > -margin_px) & (uv[:, 0] < cam.width + margin_px) & (uv[:, 1] > -margin_px) & (uv[:, 1] < cam.height + margin_px)
    return list(np.nonzero(ok)[0])


def associate(features: list[Feature], slam: ESKFSlam, gate_prob: float, desc_gate: float, ambiguity_ratio: float) -> Association:
    vis = predict_visible(slam)
    nf = len(features)
    if nf == 0:
        return Association([], [], predicted_visible=vis)
    rgbd = features[0].depth is not None
    dof = 3 if rgbd else 2
    gate = chi2.ppf(gate_prob, dof)
    P = slam.P
    pred = {}
    for j in vis:
        h, Hr, Hm, _ = slam.predict_landmark(j, rgbd)
        s = slam.lm_slice(j)
        # H P H^T using the sparse structure [Hr | 0 .. Hm .. 0]
        S = (Hr @ P[:NR, :NR] @ Hr.T + Hr @ P[:NR, s] @ Hm.T + Hm @ P[s, :NR] @ Hr.T + Hm @ P[s, s] @ Hm.T)
        pred[j] = (h, S)
    marker_to_lm = {rec.marker_id: j for j, rec in enumerate(slam.lms) if rec.marker_id is not None}
    matches: list[tuple[int, int, float]] = []
    used_f, used_l = set(), set()
    rejected_marker = 0

    def d2(fi, j):
        f = features[fi]
        h, S = pred[j]
        z = np.r_[f.uv, f.depth] if rgbd else f.uv
        Rm = slam.measurement_noise(f.depth if rgbd else None)
        r = z - h
        try:
            return float(r @ np.linalg.solve(S + Rm, r))
        except np.linalg.LinAlgError:
            return np.inf

    # 2. marker-identified known landmarks
    for fi, f in enumerate(features):
        if f.marker_id is not None and f.marker_id in marker_to_lm:
            j = marker_to_lm[f.marker_id]
            if j in pred and j not in used_l:
                dd = d2(fi, j)
                if dd < gate:
                    matches.append((fi, j, dd))
                    used_f.add(fi)
                    used_l.add(j)
                    continue
            rejected_marker += 1
            used_f.add(fi)   # an unverifiable marker read is not used to create a new landmark
    # 3. descriptor + Mahalanobis for the rest
    rest_f = [i for i in range(nf) if i not in used_f]
    rest_l = [j for j in pred if j not in used_l]
    ambiguous = 0
    if rest_f and rest_l:
        BIG = 1e6
        C = np.full((len(rest_f), len(rest_l)), BIG)
        Dl = np.array([slam.lms[j].descriptor for j in rest_l])
        for a, fi in enumerate(rest_f):
            dd_desc = np.linalg.norm(Dl - features[fi].descriptor, axis=1)
            for b in np.nonzero(dd_desc < desc_gate)[0]:
                v = d2(fi, rest_l[b])
                if v < gate:
                    C[a, b] = v
        # ambiguity test per feature
        for a in range(len(rest_f)):
            row = np.sort(C[a])
            if len(row) > 1 and row[1] < BIG and row[0] / max(row[1], 1e-9) > ambiguity_ratio:
                C[a, :] = BIG
                ambiguous += 1
        ri, ci = linear_sum_assignment(C)
        for a, b in zip(ri, ci):
            if C[a, b] < BIG:
                matches.append((rest_f[a], rest_l[b], float(C[a, b])))
                used_f.add(rest_f[a])
    unmatched = [i for i in range(nf) if i not in used_f]
    return Association(matches, unmatched, rejected_marker, ambiguous, vis)
