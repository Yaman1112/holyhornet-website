"""Trajectory-tracking LQR for the quadrotor, with differential-flatness feed-forward.

Error state (12): x = [e_p, e_v, e_R, e_w]
    e_p, e_v : position / velocity error expressed in the yaw-aligned frame of the reference
    e_R      : log(R_d^T R)  (body-frame attitude error, ~ [roll, pitch, yaw] errors)
    e_w      : w - R^T R_d w_d
Input (4): u = [dT, dM_x, dM_y, dM_z] about the feed-forward T_ff, M_ff = J alpha_d + w x J w.

Linearisation about hover (exact for the error dynamics when the reference is hover, and the
standard approximation along a feasible flat trajectory):
    e_p' = e_v
    e_v' = [ g e_pitch, -g e_roll, dT/m ]
    e_R' = e_w
    e_w' = J^-1 dM
LQR: minimise int x^T Q x + u^T R u; K = R^-1 B^T P with P from the continuous algebraic
Riccati equation A^T P + P A - P B R^-1 B^T P + Q = 0 (scipy.linalg.solve_continuous_are).

Saturation: position and velocity errors are clipped (bounded tilt demand), the total thrust is
limited, the attitude error contribution is limited to the max tilt, and motor allocation clips
with yaw-first desaturation. A clamped integral of the position error adds robustness to
constant disturbances (wind, mass error).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.linalg import solve_continuous_are

from ..config import LQRConfig, UAVConfig
from ..math3d import GRAVITY, quat_to_rot, rot_log, rot_z
from ..trajectory.flatness import flat_to_state
from ..vehicle.airframe import Airframe


def linear_model(mass: float, J: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    A = np.zeros((12, 12))
    B = np.zeros((12, 4))
    A[0:3, 3:6] = np.eye(3)
    A[3, 7] = GRAVITY       # x'' = g * pitch
    A[4, 6] = -GRAVITY      # y'' = -g * roll
    A[6:9, 9:12] = np.eye(3)
    B[5, 0] = 1.0 / mass
    B[9:12, 1:4] = np.linalg.inv(J)
    return A, B


def lqr_gain(cfg: LQRConfig, mass: float, J: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    A, B = linear_model(mass, J)
    Q = np.diag(np.r_[cfg.q_position, cfg.q_velocity, cfg.q_attitude, cfg.q_rate])
    R = np.diag(np.r_[cfg.r_thrust, cfg.r_torque])
    P = solve_continuous_are(A, B, Q, R)
    K = np.linalg.solve(R, B.T @ P)
    return K, P, A, B


@dataclass
class ControlOutput:
    f: np.ndarray            # motor thrust commands [N]
    T: float
    M: np.ndarray
    error: np.ndarray        # 12-dim error state
    saturated: bool
    T_ff: float
    M_ff: np.ndarray


class LQRController:
    def __init__(self, uav: UAVConfig, cfg: LQRConfig):
        self.uav = uav
        self.cfg = cfg
        self.af = Airframe(uav)
        self.K, self.P, self.A, self.B = lqr_gain(cfg, uav.mass, self.af.J)
        self.int_e = np.zeros(3)
        cl = np.linalg.eigvals(self.A - self.B @ self.K)
        self.closed_loop_poles = cl
        self.stable = bool(np.all(cl.real < 0))

    def reset(self):
        self.int_e = np.zeros(3)

    def compute(self, p, v, q, w, ref: dict, dt: float, f_max: float | None = None) -> ControlOutput:
        uav, cfg = self.uav, self.cfg
        m, J = uav.mass, self.af.J
        fs = flat_to_state(ref["acc"], ref["jerk"], ref["snap"], ref["yaw"], ref["yaw_rate"], ref["yaw_acc"], m, J)
        R = quat_to_rot(q)
        Rpsi = rot_z(ref["yaw"])
        e_p = Rpsi.T @ (p - ref["pos"])
        e_v = Rpsi.T @ (v - ref["vel"])
        e_p = np.clip(e_p, -2.0, 2.0)
        e_v = np.clip(e_v, -2.5, 2.5)
        if cfg.integral_gain > 0 and np.linalg.norm(e_p) < 0.5:
            # conditional integration (anti-windup): only near the reference
            self.int_e = np.clip(self.int_e + e_p * dt, -2.0, 2.0)
        e_R = rot_log(fs.R.T @ R)
        tilt_lim = np.deg2rad(cfg.max_tilt_command_deg)
        e_w = w - R.T @ fs.R @ fs.omega
        x = np.r_[e_p + cfg.integral_gain * self.int_e, e_v, e_R, e_w]
        # bound the tilt the position loop may demand: the attitude-error equivalent of the
        # position/velocity feedback torque (roll: Mx / K[Mx, roll], pitch: My / K[My, pitch])
        # must not exceed tilt_lim
        Kpv = self.K[:, :6] @ x[:6]
        Krest = self.K[:, 6:] @ x[6:]
        demand = np.abs(Kpv[1:3]) / (np.abs([self.K[1, 6], self.K[2, 7]]) + 1e-9)
        sc = min(1.0, tilt_lim / max(demand.max(), 1e-9))
        u = -(np.r_[Kpv[0], Kpv[1:3] * sc, Kpv[3]] + Krest)
        T = fs.T + u[0]
        M = fs.M + u[1:4]
        fmax = uav.max_motor_thrust if f_max is None else f_max
        T = float(np.clip(T, 4 * uav.min_motor_thrust, 4 * fmax * 0.98))
        f, sat = self.af.allocate(T, M, uav.min_motor_thrust, fmax)
        return ControlOutput(f, T, M, x, sat, fs.T, fs.M)


def hover_reference(pos, yaw=0.0) -> dict:
    z = np.zeros(3)
    return {"pos": np.asarray(pos, float), "vel": z, "acc": z, "jerk": z, "snap": z, "yaw": float(yaw), "yaw_rate": 0.0, "yaw_acc": 0.0}
