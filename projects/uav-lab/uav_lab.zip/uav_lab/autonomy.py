"""The vehicle's onboard autonomy: estimation -> mapping -> planning -> trajectory -> control.

Inputs are sensor messages, the known-landmark database, the configured start pose (with its
initial uncertainty) and the operating-area bounds. It has no access to the ground-truth
environment or the true vehicle state (`tests/uav_lab/test_separation.py`).

Mission state machine:
    IDLE -> TAKEOFF -> { NAVIGATE | EXPLORE | TRACK | HOVER } -> ARRIVED / DONE -> (LAND)
    any flying state -> BRAKE (obstacle closer than emergency distance ahead) -> replan
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .config import LabConfig
from .control.lqr import LQRController, hover_reference
from .estimation.eskf_slam import CameraModel
from .estimation.estimator import StateEstimator
from .mapping.occupancy import OccupancyMap
from .math3d import euler_zyx_from_quat, quat_from_euler_zyx, quat_to_rot
from .planning.astar import astar, path_length, shortcut
from .planning.frontiers import find_frontiers, select_goal
from .planning.grid import PlanningGrid
from .planning.rrtstar import rrtstar
from .sensors.messages import LidarMsg
from .trajectory import minsnap
from .vehicle.airframe import camera_extrinsics, camera_intrinsics, lidar_extrinsics


@dataclass
class Event:
    t: float
    kind: str
    text: str


class Autonomy:
    def __init__(self, cfg: LabConfig, known_db: list[dict]):
        self.cfg = cfg
        cc = cfg.sensors.camera
        R_bc, t_bc = camera_extrinsics(cc)
        self.cam = CameraModel(camera_intrinsics(cc), R_bc, t_bc, cc.width, cc.height, cc.rgbd, cc.min_depth, cc.max_depth)
        self.R_bl, self.t_bl = lidar_extrinsics(cfg.sensors.lidar)
        m = cfg.mission
        q0 = quat_from_euler_zyx(0, 0, m.start_yaw)
        self.est = StateEstimator(cfg, self.cam, known_db, m.start, q0)
        self.map = OccupancyMap(cfg.mapping, cfg.environment.bounds_min, cfg.environment.bounds_max)
        self.ctrl = LQRController(cfg.uav, cfg.lqr)
        self.state = "IDLE"
        self.traj: minsnap.Trajectory | None = None
        self.hold = hover_reference(m.start, m.start_yaw)
        self.path: list[np.ndarray] = []
        self.goal: np.ndarray | None = None
        self.events: list[Event] = []
        self.last_replan_check = 0.0
        self.last_plan_t = -1e9
        self.plan_failures = 0
        self.frontier_points = np.zeros((0, 3))
        self.frontier_goals: list = []
        self.blacklist: list[np.ndarray] = []
        self.last_scan_world = np.zeros((0, 3))
        self.ref = self.hold
        self.last_out = None
        self.home = np.array(m.start, float) + np.array([0, 0, m.takeoff_altitude])
        self.via = [np.array(v, float) for v in m.via]
        self.nav_goal = self.via.pop(0) if self.via else np.array(m.goal, float)
        self.final_goal = np.array(m.goal, float)
        self.hold_t0 = 0.0
        self.state_before_hold = None
        self.track_points = None
        self.explore_done = False
        self.replans = 0
        self.planner_stats: dict = {}
        self.rng = np.random.default_rng(cfg.sim.seed + 99)
        self.grid: PlanningGrid | None = None
        self.min_obstacle_ahead = np.inf
        self.nearest_obstacle = (np.inf, np.zeros(3))
        self.scan_seq = 0
        self._pushed_seq = -1
        self._escape_t = -1e9
        self.mode_override: str | None = None
        self._log("info", f"autonomy ready: mode={m.mode}, {len(known_db)} known landmarks in database")

    # ------------------------------------------------------------------ utilities
    def _log(self, kind, text):
        self.events.append(Event(self.est.t_filter if hasattr(self, "est") else 0.0, kind, text))
        if len(self.events) > 400:
            del self.events[:100]

    @property
    def mode(self) -> str:
        return self.mode_override or self.cfg.mission.mode

    # ------------------------------------------------------------------ sensor input
    def receive(self, msgs: list) -> None:
        self.est.receive(msgs)

    def update_estimation(self, now: float) -> None:
        scans = self.est.step(now)
        for scan, p, q in scans:
            self._insert_scan(scan, p, q)

    def _insert_scan(self, scan: LidarMsg, p, q) -> None:
        self.last_scan_world = self.map.insert_scan(scan.ranges, scan.dirs_sensor, scan.max_range, p, q, self.R_bl, self.t_bl)
        # relative geometry of the closest obstacle return (independent of global position error)
        rel = self.last_scan_world - p
        keep = self.last_scan_world[:, 2] > 0.3          # ignore ground returns
        if keep.any():
            d = np.linalg.norm(rel[keep], axis=1)
            k = int(np.argmin(d))
            self.nearest_obstacle = (float(d[k]), rel[keep][k] / max(d[k], 1e-6))
        else:
            self.nearest_obstacle = (np.inf, np.zeros(3))
        self.scan_seq += 1
        # local obstacle detection: closest return inside a cone around the direction of motion
        v = self.est.slam.v
        sp = np.linalg.norm(v)
        if sp > 0.2 and len(self.last_scan_world):
            rel = self.last_scan_world - p
            d = np.linalg.norm(rel, axis=1)
            cosang = rel @ v / (d * sp + 1e-9)
            ahead = (cosang > np.cos(np.deg2rad(25))) & (np.abs(rel[:, 2]) < 0.8)
            self.min_obstacle_ahead = float(d[ahead].min()) if ahead.any() else np.inf
        else:
            self.min_obstacle_ahead = np.inf

    # ------------------------------------------------------------------ planning
    def _grid(self) -> PlanningGrid:
        self.grid = PlanningGrid(self.map, self.cfg.planner, hard_clearance=self.cfg.uav.collision_radius + 0.1)
        return self.grid

    def plan_to(self, goal, t: float, start_state=None) -> bool:
        pc = self.cfg.planner
        grid = self._grid()
        s = self.est.current(t)
        p0 = s.p if start_state is None else start_state["pos"]
        v0 = s.v if start_state is None else start_state["vel"]
        a0 = None if start_state is None else start_state["acc"]
        if pc.algorithm == "rrtstar":
            path, info = rrtstar(grid, p0, goal, pc.rrt_iterations, pc.rrt_step, self.rng)
        else:
            path, info = astar(grid, p0, goal, pc.heuristic_weight)
        self.planner_stats = {k: (float(v) if isinstance(v, (int, float, np.floating)) else v) for k, v in info.items()}
        if path is None:
            self.plan_failures += 1
            self._log("warn", f"{pc.algorithm}: no path to {np.round(goal, 1).tolist()}")
            return False
        path = shortcut(grid, path)
        self.path = path
        yaw0 = euler_zyx_from_quat(s.q)[2]
        if not np.all(np.isfinite(s.p)) or np.abs(s.p).max() > 1e3:
            self._log("warn", "position estimate invalid: not planning")
            return False
        tr = minsnap.generate(np.array(path), self.cfg.trajectory, self.cfg.uav.mass, self.cfg.uav.max_motor_thrust,
                              min(self.cfg.uav.max_tilt_deg, self.cfg.lqr.max_tilt_command_deg) * 0.8,
                              v0=v0, a0=a0, yaw0=yaw0, grid=grid)
        nominal = path_length(path) / self.cfg.trajectory.max_velocity
        if tr.duration > 3.0 * nominal + 10.0 and np.linalg.norm(v0) > 0.3:
            # the measured start velocity (e.g. right after a large correction) forces extreme time
            # scaling: plan from hover instead; the LQR absorbs the short velocity mismatch
            tr = minsnap.generate(np.array(path), self.cfg.trajectory, self.cfg.uav.mass, self.cfg.uav.max_motor_thrust,
                                  min(self.cfg.uav.max_tilt_deg, self.cfg.lqr.max_tilt_command_deg) * 0.8,
                                  v0=np.zeros(3), a0=np.zeros(3), yaw0=yaw0, grid=grid)
        tr.t0 = t
        self.traj = tr
        self.goal = np.asarray(goal, float)
        self.last_plan_t = t
        self.plan_failures = 0
        self.replans += 1
        self.planner_stats.update(path_length=path_length(path), waypoints=len(path))
        self._log("plan", f"{pc.algorithm} path {path_length(path):.1f} m, {len(path)} wp, min-snap {tr.duration:.1f} s"
                  + ("" if tr.report.get("collision_free", True) else " (collision not fully resolved)"))
        return True

    def _trajectory_blocked(self, t: float) -> bool:
        if self.traj is None:
            return False
        grid = self._grid()
        tl = t - self.traj.t0
        if tl >= self.traj.duration:
            return False
        smp = self.traj.sample(0.1)
        ahead = smp["t"] >= tl
        pts = smp["pos"][ahead]
        # only the part within sensing range matters for an emergency replan
        cur = self.traj.eval(tl)["pos"]
        near = np.linalg.norm(pts - cur, axis=1) < self.cfg.sensors.lidar.max_range
        return bool((~grid.points_free(pts[near], hard=True)).any())

    # ------------------------------------------------------------------ mission logic
    def _reference(self, t: float) -> dict:
        if self.traj is not None:
            return self.traj.eval(t - self.traj.t0)
        return self.hold

    def _traj_done(self, t: float) -> bool:
        return self.traj is None or t - self.traj.t0 >= self.traj.duration

    def _set_hold_here(self, t):
        s = self.est.current(t)
        yaw = euler_zyx_from_quat(s.q)[2]
        self.hold = hover_reference(s.p if self.state != "IDLE" else self.cfg.mission.start, yaw)
        self.traj = None

    def _start_mission(self, t: float):
        mode = self.mode
        if mode == "navigate":
            self.state = "NAVIGATE"
            self.plan_to(self.nav_goal, t)
        elif mode == "explore":
            self.state = "EXPLORE"
            self._next_frontier(t)
        elif mode == "track":
            self.state = "TRACK"
            s = self.est.current(t)
            pts = np.vstack([s.p, np.array(self.cfg.trajectory.waypoints, float)])
            tr = minsnap.generate(pts, self.cfg.trajectory, self.cfg.uav.mass, self.cfg.uav.max_motor_thrust,
                                  self.cfg.lqr.max_tilt_command_deg * 0.8, v0=s.v, yaw0=euler_zyx_from_quat(s.q)[2], grid=None)
            tr.t0 = t
            self.traj = tr
            self.path = list(pts)
            self._log("plan", f"trajectory lab: {len(pts)} waypoints, min-snap {tr.duration:.1f} s, within limits={tr.report['within_limits']}")
        else:
            self.state = "HOVER"

    def _keep_clear(self, pos: np.ndarray, dt: float = 0.01) -> tuple[np.ndarray, np.ndarray]:
        """Reactive LiDAR safety while hovering: retreat from the closest return at 0.5 m/s.

        Uses only the relative scan geometry, so it keeps working when the global position
        estimate drifts. Returns the (moved) hold position and the retreat velocity.
        """
        d, u = self.nearest_obstacle
        safe = self.cfg.uav.collision_radius + 0.8
        if d < safe:
            away = -u.copy()
            away[2] = 0.0
            n = np.linalg.norm(away)
            if n > 1e-6:
                v = away / n * 0.5
                if self.scan_seq != self._pushed_seq:
                    self._pushed_seq = self.scan_seq
                    self._log("warn", f"obstacle {d:.2f} m away while hovering: moving clear")
                return pos + v * dt, v
        return pos, np.zeros(3)

    def _resume(self, t: float, state: str) -> None:
        """Continue the mission after a brake / hold / relocalisation leg, respecting the mode."""
        if state == "RETURN":
            self.state = "RETURN"
            self.plan_to(self.home, t)
        elif self.mode == "explore":
            self.state = "EXPLORE"
            self._next_frontier(t)
        else:
            self.state = "NAVIGATE"
            self.plan_to(self.nav_goal, t)

    def _relocalize_target(self, est):
        slam = self.est.slam
        if slam.n == 0:
            return None
        sig = np.array([np.sqrt(np.trace(slam.landmark_cov(j))) for j in range(slam.n)])
        good = np.nonzero((sig < 0.3) & (slam.L[:, 2] > 0.3))[0]   # well-mapped, not on the ground
        if not len(good):
            good = np.nonzero(sig < 0.3)[0]
        if not len(good):
            return None
        d = np.linalg.norm(slam.L[good] - est.p, axis=1)
        far = good[d > 4.0]
        j = far[np.argmin(np.linalg.norm(slam.L[far] - est.p, axis=1))] if len(far) else good[np.argmax(d)]
        m = slam.L[j]
        dirv = est.p - m
        dirv[2] = 0
        dirv = dirv / (np.linalg.norm(dirv) + 1e-9)
        goal = m + 3.5 * dirv
        goal[2] = np.clip(max(m[2], 2.0), self.cfg.planner.min_altitude + 0.2, self.cfg.planner.max_altitude - 0.2)
        return goal

    def _uncertainty(self) -> float:
        return float(np.sqrt(np.max(np.linalg.eigvalsh(self.est.slam.P[0:3, 0:3]))))

    def _next_frontier(self, t: float) -> None:
        ec = self.cfg.exploration
        s = self.est.current(t)
        if t > ec.max_time:
            self._finish_exploration(t, "time limit")
            return
        # uncertainty-aware: revisit well-mapped landmarks to re-localise (active loop closure)
        slam = self.est.slam
        if self._uncertainty() > ec.uncertainty_threshold and slam.n > 0:
            sig = np.array([np.sqrt(np.trace(slam.landmark_cov(j))) for j in range(slam.n)])
            good = np.nonzero(sig < 0.25)[0]
            if len(good):
                d = np.linalg.norm(slam.L[good] - s.p, axis=1)
                j = good[np.argsort(d)[min(len(good) - 1, 3)]]  # not the very closest: it is probably in view already
                m = slam.L[j]
                dirv = s.p - m
                dirv[2] = 0
                dirv = dirv / (np.linalg.norm(dirv) + 1e-9)
                goal = m + 3.5 * dirv
                goal[2] = np.clip(m[2], self.cfg.planner.min_altitude + 0.2, self.cfg.planner.max_altitude - 0.2)
                if self.plan_to(goal, t):
                    self.state = "RELOCALIZE"
                    self._log("explore", f"position sigma {self._uncertainty():.2f} m > threshold: revisiting landmark {slam.lms[j].map_id}")
                    return
        clusters, pts = find_frontiers(self.map, self.cfg.planner, ec)
        self.frontier_points = pts
        self.frontier_goals = clusters
        own_cov = self.map_known_fraction()
        if own_cov >= ec.coverage_target:
            self._finish_exploration(t, f"known fraction {own_cov:.2f} reached target")
            return
        tries = 0
        while clusters and tries < 4:
            c = select_goal(clusters, s.p, ec, blacklist=self.blacklist)
            if c is None:
                break
            if self.plan_to(c.goal, t):
                self.state = "EXPLORE"
                self._log("explore", f"frontier goal {np.round(c.goal, 1).tolist()} gain={c.gain:.0f} utility={c.utility:.1f}")
                return
            self.blacklist.append(c.goal)
            clusters = [k for k in clusters if k is not c]
            tries += 1
        if not clusters:
            self._finish_exploration(t, "no frontiers left")
        else:
            self._log("warn", "no reachable frontier this cycle")
            self._set_hold_here(t)

    def _finish_exploration(self, t, why):
        if not self.explore_done:
            self._log("explore", f"exploration complete ({why}); returning home")
            self.explore_done = True
        self.state = "RETURN"
        self.plan_to(self.home, t)

    def map_known_fraction(self) -> float:
        pc = self.cfg.planner
        z = self.map.origin[2] + (np.arange(self.map.shape[2]) + 0.5) * self.map.res
        band = (z >= pc.min_altitude) & (z <= pc.max_altitude)
        obs = self.map.observed[:, :, band]
        return float(obs.mean()) if obs.size else 0.0

    def set_goal(self, goal, t):
        self.nav_goal = np.asarray(goal, float)
        self.final_goal = self.nav_goal.copy()
        self.via = []
        self.mode_override = "navigate"
        if self.state not in ("IDLE", "TAKEOFF"):
            self.state = "NAVIGATE"
            self.plan_to(self.nav_goal, t)
            self._log("info", f"new goal {np.round(goal, 2).tolist()}")

    def set_mode(self, mode, t):
        self.mode_override = mode
        if self.state not in ("IDLE", "TAKEOFF"):
            self.explore_done = False
            self._start_mission(t)

    # ------------------------------------------------------------------ control step
    def control(self, t: float, dt: float, f_max: float | None = None) -> np.ndarray:
        m = self.cfg.mission
        pc = self.cfg.planner
        est = self.est.current(t)
        uav = self.cfg.uav
        if self.state == "IDLE":
            self.est.on_ground = True
            self.ref = self.hold
            if t >= 0.5:
                self.est.on_ground = False
                self.state = "TAKEOFF"
                self.ctrl.reset()
                top = np.array([est.p[0], est.p[1], m.start[2] + m.takeoff_altitude])
                tr = minsnap.generate(np.array([est.p, top]), self.cfg.trajectory, uav.mass, uav.max_motor_thrust, 30,
                                      yaw0=m.start_yaw)
                tr.t0 = t
                self.traj = tr
                self.home = top
                self._log("info", f"takeoff to {top[2]:.1f} m")
            else:
                f = np.full(4, uav.min_motor_thrust)
                return f
        # uncertainty-aware safety: hold and scan for landmarks when the position estimate is poor
        sig = self._uncertainty()
        if self.state in ("NAVIGATE", "EXPLORE", "RETURN") and sig > pc.max_position_sigma and self.mode != "track":
            self._log("warn", f"position sigma {sig:.2f} m > {pc.max_position_sigma} m: holding and scanning for landmarks")
            self.state_before_hold = self.state
            self.state = "LOC_HOLD"
            self.hold_t0 = t
            self.hold_yaw0 = euler_zyx_from_quat(est.q)[2]
            self.hold_pos = est.p.copy()
            self.traj = None
        if self.state == "LOC_HOLD":
            # a filter correction moves the estimate, not the vehicle: re-anchor instead of flying back
            if np.linalg.norm(est.p - self.hold_pos) > 0.3:
                self.hold_pos = est.p.copy()
            self.hold_pos, v_away = self._keep_clear(self.hold_pos, dt)
            wz = pc.relocalization_yaw_rate
            yaw = self.hold_yaw0 + wz * (t - self.hold_t0)
            self.hold = {**hover_reference(self.hold_pos, yaw), "yaw_rate": wz, "vel": v_away}
            # escape: no landmarks found by scanning in place -> fly towards well-mapped landmarks
            if t - self.hold_t0 > 8.0 and t - self._escape_t > 3.0 and sig >= 0.6 * pc.max_position_sigma                     and self._relocalize_target(est) is not None:
                self._escape_t = t     # at most one attempt every 3 s
                goal = self._relocalize_target(est)
                if self.plan_to(goal, t):
                    self._log("explore", f"no landmarks in view for {t - self.hold_t0:.0f} s: flying to mapped landmarks at {np.round(goal, 1).tolist()}")
                    self.state = "RELOCALIZE"
            if sig < 0.6 * pc.max_position_sigma:
                self._log("info", f"re-localised (sigma {sig:.2f} m) after {t - self.hold_t0:.1f} s: resuming")
                self._set_hold_here(t)
                self._resume(t, self.state_before_hold)
        # a relocalisation leg is flown on a degraded estimate; abort it if the estimate keeps degrading
        if self.state == "RELOCALIZE" and self.mode != "explore" and sig > 2.0 * pc.max_position_sigma:
            self._log("warn", f"position sigma {sig:.2f} m while relocalising: stopping")
            self.state_before_hold, self.state, self.hold_t0 = "NAVIGATE", "LOC_HOLD", t
            self.hold_yaw0, self.hold_pos = euler_zyx_from_quat(est.q)[2], est.p.copy()
            self.traj = None
        # emergency braking on local obstacle detection (stopping distance grows with speed)
        sp = float(np.linalg.norm(est.v))
        stop_d = max(pc.emergency_stop_distance, sp * sp / (2 * 0.8 * self.cfg.trajectory.max_acceleration) + self.cfg.uav.collision_radius + 0.3)
        if self.state in ("NAVIGATE", "EXPLORE", "RETURN", "RELOCALIZE") and self.min_obstacle_ahead < stop_d:
            self._log("warn", f"obstacle {self.min_obstacle_ahead:.2f} m ahead: braking and replanning")
            self.min_obstacle_ahead = np.inf
            self._set_hold_here(t)
            self.state_before_brake = self.state
            self.state = "BRAKE"
            self.brake_t = t
        if self.state == "BRAKE":
            hp, v_away = self._keep_clear(np.asarray(self.hold["pos"], float), dt)
            self.hold = {**self.hold, "pos": hp, "vel": v_away}
        if self.state == "BRAKE" and t - self.brake_t > 0.8:
            if self.state_before_brake == "RELOCALIZE" and self.mode != "explore":
                self.state = "RELOCALIZE"
                tgt = self._relocalize_target(est)
                if tgt is None or not self.plan_to(tgt, t):
                    self._resume(t, "NAVIGATE")
            else:
                self._resume(t, self.state_before_brake)
        if self.state == "TAKEOFF" and self._traj_done(t):
            self._set_hold_here(t)
            self._start_mission(t)
        # a large estimate correction leaves the reference far from the (corrected) estimate:
        # replan from where the vehicle now believes it is instead of flying straight back
        if self.state in ("NAVIGATE", "EXPLORE", "RETURN", "RELOCALIZE") and self.traj is not None:
            ref_now = self._reference(t)
            if np.linalg.norm(est.p - ref_now["pos"]) > 1.0 and t - self.last_plan_t > 0.5:
                self._log("plan", f"estimate {np.linalg.norm(est.p - ref_now['pos']):.1f} m from reference after a correction: replanning")
                target = self.goal if self.goal is not None else self.nav_goal
                if not self.plan_to(target, t):
                    self._set_hold_here(t)
        # periodic re-check of the remaining trajectory against the updated map
        if self.state in ("NAVIGATE", "EXPLORE", "RETURN", "RELOCALIZE") and t - self.last_replan_check > pc.replan_period:
            self.last_replan_check = t
            if self.traj is not None and self._trajectory_blocked(t):
                self._log("plan", "map update blocks the trajectory: replanning")
                target = self.goal if self.goal is not None else self.nav_goal
                if not self.plan_to(target, t, start_state=None):
                    self._set_hold_here(t)
            elif self.traj is None and self.state in ("NAVIGATE", "RELOCALIZE") and self.mode != "explore":
                self._resume(t, "NAVIGATE")
            elif self.traj is None and self.state in ("EXPLORE", "RELOCALIZE"):
                self._next_frontier(t)
        # arrival logic
        if self.state == "NAVIGATE":
            if np.linalg.norm(est.p - self.nav_goal) < pc.goal_tolerance and np.linalg.norm(est.v) < 0.3                     and sig < pc.max_position_sigma:
                if self.via:
                    self._log("info", f"via point {np.round(self.nav_goal, 1).tolist()} reached at t={t:.1f} s")
                    self.nav_goal = self.via.pop(0) if len(self.via) > 0 else self.final_goal
                    if not self.via and np.allclose(self.nav_goal, self.final_goal):
                        pass
                    self.plan_to(self.nav_goal, t)
                elif not np.allclose(self.nav_goal, self.final_goal) and self.mode_override is None:
                    self.nav_goal = self.final_goal
                    self.plan_to(self.nav_goal, t)
                else:
                    self.state = "ARRIVED"
                    self._log("info", f"goal reached at t={t:.1f} s (estimated position, sigma {sig:.2f} m)")
                    if m.land_at_goal:
                        self._land(t, est)
            elif self._traj_done(t) and t - self.last_plan_t > 1.0:
                self.plan_to(self.nav_goal, t)
        elif self.state == "RELOCALIZE" and self._traj_done(t) and self.mode != "explore":
            self.state = "NAVIGATE" if sig < pc.max_position_sigma else "LOC_HOLD"
            if self.state == "NAVIGATE":
                self.plan_to(self.nav_goal, t)
            else:
                self.state_before_hold, self.hold_t0 = "NAVIGATE", t
                self.hold_yaw0, self.hold_pos = euler_zyx_from_quat(est.q)[2], est.p.copy()
                self.traj = None
        elif self.state in ("EXPLORE", "RELOCALIZE") and self._traj_done(t):
            if self.goal is not None:
                self.blacklist.append(self.goal)
            self._next_frontier(t)
        elif self.state == "RETURN" and self._traj_done(t):
            if np.linalg.norm(est.p - self.home) < 1.0:
                self.state = "DONE"
                self._log("info", "back home: exploration mission done")
                self._set_hold_here(t)
            elif t - self.last_plan_t > 1.0:
                self.plan_to(self.home, t)
        elif self.state == "TRACK" and self._traj_done(t):
            self.state = "DONE"
            self._log("info", "trajectory complete")
            ref = self._reference(t)
            self.hold = hover_reference(ref["pos"], ref["yaw"])
            self.traj = None
        elif self.state == "LANDING" and self._traj_done(t) and est.p[2] < 0.15:
            self.state = "LANDED"
            self._log("info", "landed")
        if self.state == "LANDED":
            self.est.on_ground = True
            return np.full(4, uav.min_motor_thrust)
        self.ref = self._reference(t)
        out = self.ctrl.compute(est.p, est.v, est.q, est.w, self.ref, dt, f_max)
        self.last_out = out
        return out.f

    def _land(self, t, est):
        self.state = "LANDING"
        tr = minsnap.generate(np.array([est.p, [est.p[0], est.p[1], self.cfg.mission.start[2] + 0.05]]), self.cfg.trajectory,
                              self.cfg.uav.mass, self.cfg.uav.max_motor_thrust, 25, yaw0=euler_zyx_from_quat(est.q)[2])
        tr.t0 = t
        self.traj = tr

    # ------------------------------------------------------------------ outputs for display
    def landmarks_view(self) -> list[dict]:
        s = self.est.slam
        out = []
        for j, rec in enumerate(s.lms):
            C = s.landmark_cov(j)
            out.append({"id": rec.map_id, "known": rec.known, "marker": rec.marker_id, "p": s.L[j].round(3).tolist(),
                        "cov": np.round(C, 5).tolist(), "sigma": float(np.sqrt(np.trace(C))), "n_obs": rec.n_obs,
                        "confidence": float(np.exp(-np.sqrt(np.trace(C)) / 0.2))})
        return out

    def body_rot(self) -> np.ndarray:
        return quat_to_rot(self.est.slam.q)
