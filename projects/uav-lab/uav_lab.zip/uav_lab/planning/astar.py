"""Weighted A* on the 26-connected planning grid, with line-of-sight path shortening.

Edge cost = Euclidean length x mean cell cost (unknown cells cost more). Heuristic =
Euclidean distance (admissible for weight 1; weight > 1 trades optimality for speed, with
cost <= weight * optimal).
"""

from __future__ import annotations

import heapq
import itertools

import numpy as np

from .grid import PlanningGrid

_OFFS = np.array([(i, j, k) for i in (-1, 0, 1) for j in (-1, 0, 1) for k in (-1, 0, 1) if (i, j, k) != (0, 0, 0)])
_LEN = np.linalg.norm(_OFFS, axis=1)


def astar(grid: PlanningGrid, start, goal, weight: float = 1.0, max_expansions: int = 400000) -> tuple[list[np.ndarray] | None, dict]:
    s = grid.nearest_free(start)
    g = grid.nearest_free(goal)
    info = {"expansions": 0, "cost": np.inf, "algorithm": "astar"}
    if s is None or g is None:
        return None, info
    sh = np.array(grid.shape)
    blocked = grid.blocked.ravel()
    cost = grid.cost.ravel()
    strides = np.array([sh[1] * sh[2], sh[2], 1])
    off_flat = _OFFS @ strides
    si = int(s @ strides)
    gi = int(g @ strides)
    gpos = g.astype(float)

    def coords(i):
        return np.array([i // strides[0], (i // strides[1]) % sh[1], i % sh[2]])

    gscore = {si: 0.0}
    parent = {si: -1}
    closed = set()
    cnt = itertools.count()
    heap = [(weight * np.linalg.norm(s - gpos), next(cnt), si)]
    while heap:
        _, _, cur = heapq.heappop(heap)
        if cur in closed:
            continue
        if cur == gi:
            break
        closed.add(cur)
        info["expansions"] += 1
        if info["expansions"] > max_expansions:
            return None, info
        c = coords(cur)
        nb = c + _OFFS
        ok = np.all((nb >= 0) & (nb < sh), axis=1)
        nbi = cur + off_flat
        gc = gscore[cur]
        for k in np.nonzero(ok)[0]:
            n = int(nbi[k])
            if blocked[n] or n in closed:
                continue
            ng = gc + _LEN[k] * 0.5 * (cost[cur] + cost[n])
            if ng < gscore.get(n, np.inf):
                gscore[n] = ng
                parent[n] = cur
                h = np.sqrt(((nb[k] - gpos) ** 2).sum())
                heapq.heappush(heap, (ng + weight * h, next(cnt), n))
    if gi not in parent:
        return None, info
    path = []
    cur = gi
    while cur != -1:
        path.append(grid.center(coords(cur)))
        cur = parent[cur]
    path.reverse()
    info["cost"] = gscore[gi]
    path[0] = np.asarray(start, float) if grid.is_free_point(start) else path[0]
    if grid.is_free_point(goal):
        path[-1] = np.asarray(goal, float)
    return path, info


def shortcut(grid: PlanningGrid, path: list[np.ndarray]) -> list[np.ndarray]:
    """Greedy line-of-sight simplification (keeps endpoints)."""
    if len(path) <= 2:
        return list(path)
    out = [path[0]]
    i = 0
    while i < len(path) - 1:
        j = len(path) - 1
        while j > i + 1 and not grid.segment_free(path[i], path[j]):
            j -= 1
        out.append(path[j])
        i = j
    return out


def path_length(path) -> float:
    return float(sum(np.linalg.norm(np.asarray(b) - np.asarray(a)) for a, b in zip(path[:-1], path[1:])))
