"""RRT* in continuous 3D space with collision checks against the planning grid.

Goal-biased sampling, steering by `rrt_step`, choose-parent and rewiring inside the radius
r = min(gamma (log n / n)^(1/3), eta).
"""

from __future__ import annotations

import numpy as np

from .grid import PlanningGrid


def rrtstar(grid: PlanningGrid, start, goal, iterations: int, step: float, rng: np.random.Generator,
            goal_bias: float = 0.1) -> tuple[list[np.ndarray] | None, dict]:
    start, goal = np.asarray(start, float), np.asarray(goal, float)
    lo = grid.origin
    hi = grid.origin + np.array(grid.shape) * grid.res
    lo = np.maximum(lo, [lo[0], lo[1], grid.cfg.min_altitude])
    hi = np.minimum(hi, [hi[0], hi[1], grid.cfg.max_altitude])
    nodes = [start]
    parent = [-1]
    cost = [0.0]
    best_goal, best_cost = -1, np.inf
    gamma = 2.0 * (1 + 1 / 3) ** (1 / 3) * (np.prod(hi - lo) / (4 / 3 * np.pi)) ** (1 / 3)
    for it in range(iterations):
        x = goal if rng.random() < goal_bias else rng.uniform(lo, hi)
        P = np.array(nodes)
        d = np.linalg.norm(P - x, axis=1)
        i_near = int(np.argmin(d))
        v = x - nodes[i_near]
        dist = np.linalg.norm(v)
        if dist < 1e-9:
            continue
        xn = nodes[i_near] + v / dist * min(step, dist)
        if not grid.is_free_point(xn) or not grid.segment_free(nodes[i_near], xn):
            continue
        n = len(nodes)
        r = min(gamma * (np.log(n + 1) / (n + 1)) ** (1 / 3), 3 * step)
        dn = np.linalg.norm(P - xn, axis=1)
        near = np.nonzero(dn <= r)[0]
        bp, bc = i_near, cost[i_near] + np.linalg.norm(xn - nodes[i_near])
        for j in near:
            c = cost[j] + dn[j]
            if c < bc and grid.segment_free(nodes[j], xn):
                bp, bc = j, c
        nodes.append(xn)
        parent.append(bp)
        cost.append(bc)
        k = len(nodes) - 1
        for j in near:
            c = bc + dn[j]
            if c < cost[j] and grid.segment_free(xn, nodes[j]):
                parent[j] = k
                cost[j] = c
        if np.linalg.norm(xn - goal) <= step and grid.segment_free(xn, goal):
            c = bc + np.linalg.norm(goal - xn)
            if c < best_cost:
                best_goal, best_cost = k, c
    info = {"iterations": iterations, "nodes": len(nodes), "cost": best_cost, "algorithm": "rrtstar"}
    if best_goal < 0:
        return None, info
    path = [goal]
    k = best_goal
    while k != -1:
        path.append(nodes[k])
        k = parent[k]
    path.reverse()
    return path, info
