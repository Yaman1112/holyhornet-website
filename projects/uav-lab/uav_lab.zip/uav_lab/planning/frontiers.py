"""Frontier-based exploration on the vehicle's own occupancy map.

Frontier cell: a known-free voxel with at least one unknown 6-neighbour, inside the altitude
band. Frontier cells are clustered (26-connectivity); each cluster with at least
`min_frontier_size` cells is a candidate goal at the free cell closest to its centroid.

Information gain of a candidate = number of unknown voxels within `sensor_radius` (computed by
a box filter over the unknown mask). Utility = gain * exp(-lambda * path_cost).
When the position uncertainty exceeds `uncertainty_threshold`, the goal is instead the mapped
landmark cluster that is best observed (active re-localisation / loop closure).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import ndimage

from ..config import ExplorationConfig, PlannerConfig
from ..mapping.occupancy import FREE, UNKNOWN, OccupancyMap


@dataclass
class FrontierCluster:
    centroid: np.ndarray
    goal: np.ndarray
    size: int
    gain: float
    utility: float = 0.0


def find_frontiers(m: OccupancyMap, pcfg: PlannerConfig, ecfg: ExplorationConfig) -> tuple[list[FrontierCluster], np.ndarray]:
    st = m.state()
    free = st == FREE
    unknown = st == UNKNOWN
    nb_unknown = ndimage.binary_dilation(unknown, structure=ndimage.generate_binary_structure(3, 1))
    z = m.origin[2] + (np.arange(m.shape[2]) + 0.5) * m.res
    band = (z >= pcfg.min_altitude) & (z <= pcfg.max_altitude)
    front = free & nb_unknown & band[None, None, :]
    lab, n = ndimage.label(front, structure=np.ones((3, 3, 3)))
    if n == 0:
        return [], np.zeros((0, 3))
    k = max(1, int(round(ecfg.sensor_radius / m.res)))
    # unknown voxels in a (2k+1)^3 box, restricted to the altitude band +- 2 m
    zb = (z >= pcfg.min_altitude - 2) & (z <= pcfg.max_altitude + 2)
    unk_band = unknown & zb[None, None, :]
    gain_map = ndimage.uniform_filter(unk_band.astype(np.float32), size=2 * k + 1, mode="constant") * (2 * k + 1) ** 3
    idx = np.argwhere(front)
    labels = lab[front]
    clusters = []
    sizes = np.bincount(labels)
    for c in range(1, n + 1):
        if sizes[c] < ecfg.min_frontier_size:
            continue
        cells = idx[labels == c]
        cen = cells.mean(axis=0)
        best = cells[np.argmin(np.linalg.norm(cells - cen, axis=1))]
        clusters.append(FrontierCluster(m.center(cen), m.center(best), int(sizes[c]), float(gain_map[tuple(best)])))
    return clusters, m.center(idx)


def select_goal(clusters: list[FrontierCluster], position: np.ndarray, ecfg: ExplorationConfig,
                path_cost=None, blacklist: list[np.ndarray] | None = None) -> FrontierCluster | None:
    best = None
    for c in clusters:
        if blacklist and any(np.linalg.norm(c.goal - b) < 2.0 for b in blacklist):
            continue
        cost = path_cost(c.goal) if path_cost else np.linalg.norm(c.goal - position)
        if not np.isfinite(cost) or np.linalg.norm(c.goal - position) < 1.5:
            continue
        c.utility = c.gain * np.exp(-ecfg.distance_weight * cost)
        if best is None or c.utility > best.utility:
            best = c
    return best
