"""Planning grid derived from the vehicle's own occupancy map.

Cells (at `grid_resolution`) are *blocked* if any occupied map voxel lies within `clearance`
(+ half a cell) of the cell, or the cell is outside [min_altitude, max_altitude]. Unknown cells
are traversable with a cost multiplier (optimistic planning; the vehicle replans when the
LiDAR reveals an obstacle on its path).
"""

from __future__ import annotations

import numpy as np
from scipy import ndimage

from ..config import PlannerConfig
from ..mapping.occupancy import OCCUPIED, UNKNOWN, OccupancyMap


class PlanningGrid:
    def __init__(self, m: OccupancyMap, cfg: PlannerConfig, extra_occupied: np.ndarray | None = None,
                 hard_clearance: float = 0.35):
        self.cfg = cfg
        self.res = cfg.grid_resolution
        self.origin = m.origin.copy()
        f = max(1, int(round(self.res / m.res)))
        self.res = f * m.res
        st = m.state()
        sh = tuple(s // f for s in st.shape)
        st = st[: sh[0] * f, : sh[1] * f, : sh[2] * f]
        blocks = st.reshape(sh[0], f, sh[1], f, sh[2], f)
        occ = (blocks == OCCUPIED).any(axis=(1, 3, 5))
        unk = (blocks == UNKNOWN).all(axis=(1, 3, 5))
        if extra_occupied is not None and len(extra_occupied):
            ijk = np.floor((extra_occupied - self.origin) / self.res).astype(int)
            ok = np.all((ijk >= 0) & (ijk < np.array(sh)), axis=1)
            occ[tuple(ijk[ok].T)] = True
        r = int(np.ceil(cfg.clearance / self.res))
        if r > 0:
            g = np.arange(-r, r + 1)
            X, Y, Z = np.meshgrid(g, g, g, indexing="ij")
            ball = (X**2 + Y**2 + Z**2) * self.res**2 <= (cfg.clearance + 0.5 * self.res) ** 2
            infl = ndimage.binary_dilation(occ, structure=ball)
        else:
            infl = occ.copy()
        z = self.origin[2] + (np.arange(sh[2]) + 0.5) * self.res
        alt_bad = (z < cfg.min_altitude - 1e-9) | (z > cfg.max_altitude + 1e-9)
        # "hard" grid: occupied cells inflated only by the vehicle radius; used to validate smooth
        # trajectories, which may cut corners of the conservative planning clearance
        rh = int(np.ceil(hard_clearance / self.res))
        if rh > 0:
            g = np.arange(-rh, rh + 1)
            X, Y, Z = np.meshgrid(g, g, g, indexing="ij")
            ball_h = (X**2 + Y**2 + Z**2) * self.res**2 <= (hard_clearance + 0.5 * self.res) ** 2
            self.hard_blocked = ndimage.binary_dilation(occ, structure=ball_h)
        else:
            self.hard_blocked = occ.copy()
        self.hard_blocked |= (z < 0.3)[None, None, :]
        self.occupied = occ
        self.blocked = infl | alt_bad[None, None, :]
        self.unknown = unk
        self.cost = np.where(unk, cfg.unknown_cost, 1.0).astype(float)
        self.shape = sh

    def index(self, p) -> np.ndarray:
        return np.floor((np.asarray(p) - self.origin) / self.res).astype(int)

    def center(self, ijk) -> np.ndarray:
        return self.origin + (np.asarray(ijk) + 0.5) * self.res

    def in_bounds(self, ijk) -> bool:
        return bool(np.all(np.asarray(ijk) >= 0) and np.all(np.asarray(ijk) < np.array(self.shape)))

    def is_free_point(self, p) -> bool:
        ijk = self.index(p)
        return self.in_bounds(ijk) and not self.blocked[tuple(ijk)]

    def points_free(self, pts: np.ndarray, hard: bool = False) -> np.ndarray:
        ijk = np.floor((pts - self.origin) / self.res).astype(int)
        ok = np.all((ijk >= 0) & (ijk < np.array(self.shape)), axis=1)
        out = np.zeros(len(pts), bool)
        grid = self.hard_blocked if hard else self.blocked
        out[ok] = ~grid[tuple(ijk[ok].T)]
        return out

    def segment_free(self, a, b) -> bool:
        a, b = np.asarray(a, float), np.asarray(b, float)
        n = max(2, int(np.ceil(np.linalg.norm(b - a) / (0.25 * self.res))) + 1)
        pts = a + (b - a) * np.linspace(0, 1, n)[:, None]
        return bool(self.points_free(pts).all())

    def nearest_free(self, p, max_r: int = 6) -> np.ndarray | None:
        ijk = self.index(p)
        ijk = np.clip(ijk, 0, np.array(self.shape) - 1)
        if not self.blocked[tuple(ijk)]:
            return ijk
        best, bd = None, np.inf
        for r in range(1, max_r + 1):
            g = np.arange(-r, r + 1)
            X, Y, Z = np.meshgrid(g, g, g, indexing="ij")
            cand = np.c_[X.ravel(), Y.ravel(), Z.ravel()] + ijk
            ok = np.all((cand >= 0) & (cand < np.array(self.shape)), axis=1)
            cand = cand[ok]
            free = ~self.blocked[tuple(cand.T)]
            if free.any():
                c = cand[free]
                d = np.linalg.norm(c - ijk, axis=1)
                i = int(np.argmin(d))
                if d[i] < bd:
                    best, bd = c[i], d[i]
                return best
        return None
