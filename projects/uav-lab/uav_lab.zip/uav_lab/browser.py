"""Bridge for running the lab inside a web browser (Pyodide / WebAssembly).

The web worker calls these functions with JSON strings and receives JSON strings, so no Python
objects cross the JavaScript boundary. It is the same engine as the FastAPI service: the same
`Session`, the same frames, the same laboratory functions.
"""

from __future__ import annotations

import json

from .config import LabConfig, merge
from .scenarios import scenario_config
from .server import tools
from .server.session import Session

_session: Session | None = None


def _dump(o) -> str:
    return json.dumps(o, default=tools._np)


def create(body_json: str) -> str:
    global _session
    body = json.loads(body_json or "{}")
    base = scenario_config(body["scenario"]) if body.get("scenario") else LabConfig()
    cfg = merge(base, body.get("config") or {})
    _session = Session(cfg, body.get("scenario"), threaded=False)
    if body.get("autostart"):
        _session.command({"cmd": "start"})
    return _dump({"id": _session.id, "scene": _session.static_scene()})


def command(cmd_json: str) -> str:
    if _session is None:
        return _dump({"ok": False, "error": "no session"})
    try:
        return _dump(_session.command(json.loads(cmd_json)))
    except Exception as e:  # report to the UI like the server does
        return _dump({"ok": False, "error": str(e)})


def advance(seconds: float = 0.1) -> str:
    if _session is None:
        return "null"
    if _session.sim.finished:
        _session.running = False
    return _dump(_session.advance(seconds))


def frame() -> str:
    return _dump(_session.frame if _session else None)


def running() -> bool:
    return bool(_session and _session.running and not _session.sim.finished)


def call(name: str, arg_json: str = "null") -> str:
    arg = json.loads(arg_json) if arg_json else None
    if name == "default_config":
        return _dump(tools.default_config())
    if name == "scenarios":
        return _dump(tools.scenarios())
    if name == "scenario_cfg":
        return _dump(tools.scenario_cfg(arg))
    if name == "uav_model":
        return _dump(tools.uav_model(arg))
    if name == "trajectory_lab":
        return _dump(tools.trajectory_lab(arg or {}))
    if name == "lqr_lab":
        return _dump(tools.lqr_lab(arg or {}))
    if name == "telemetry":
        return _dump(_session.sim.telemetry.since(0) if _session else {})
    if name == "summary":
        if not _session:
            return "null"
        out = _session.sim.summary()
        out["landmarks_detail"] = _session.sim.landmark_errors()["per_landmark"]
        return _dump(out)
    if name == "maps":
        from .server.storage import list_maps
        return _dump(list_maps())
    raise ValueError(f"unknown call {name!r}")
