"""Run the test scenarios headless, check their criteria against ground truth, write reports.

    python -m uav_lab.experiments                 # all scenarios
    python -m uav_lab.experiments loop_closure    # one
Writes docs/uav_lab/reports/<scenario>.json and docs/uav_lab/reports/REPORT.md.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

from .scenarios import SCENARIOS, scenario_config
from .sim.simulator import Simulator

REPORT_DIR = Path(__file__).resolve().parents[2] / "docs" / "uav_lab" / "reports"


def run_scenario(name: str, cfg=None) -> tuple[Simulator, dict]:
    cfg = cfg or scenario_config(name)
    sim = Simulator(cfg)
    sim.run(stop_on_arrival=True)
    summ = sim.summary()
    checks = evaluate(name, sim, summ)
    summ["checks"] = checks
    summ["passed"] = all(c["ok"] for c in checks)
    return sim, summ


def _window_mean(tel, key, t0, t1):
    t = np.array(tel["t"])
    v = np.array(tel[key], float)
    m = (t >= t0) & (t < t1)
    return float(np.nanmean(v[m])) if m.any() else float("nan")


def evaluate(name: str, sim: Simulator, s: dict) -> list[dict]:
    crit = SCENARIOS[name]["criteria"]
    tel = sim.telemetry
    out = []

    def chk(label, ok, value):
        out.append({"criterion": label, "ok": bool(ok), "value": value})

    for k, v in crit.items():
        if k == "no_crash":
            chk("no collision", not s["crashed"], s["crash"])
        elif k == "reach_goal":
            chk("goal reached (estimated) and true error < 2.5 m", s["state"] == "ARRIVED" and s["goal_error_true"] < 2.5,
                {"state": s["state"], "true_goal_error_m": round(s["goal_error_true"], 3)})
        elif k == "pos_rmse_max":
            chk(f"position RMSE <= {v} m", s.get("pos_rmse", 9e9) <= v, round(s.get("pos_rmse", float("nan")), 3))
        elif k == "track_rmse_max":
            chk(f"tracking RMSE <= {v} m", s.get("track_rmse", 9e9) <= v, round(s.get("track_rmse", float("nan")), 3))
        elif k == "known_observed_min":
            chk(f">= {v} known landmarks recognised", s["known_observed"] >= v, s["known_observed"])
        elif k == "new_landmarks_min":
            chk(f">= {v} landmarks discovered", s["n_new_in_map"] >= v, s["n_new_in_map"])
        elif k == "false_landmarks_max":
            chk(f"false landmarks <= {v}", s["landmarks"]["false_landmarks"] <= v, s["landmarks"]["false_landmarks"])
        elif k == "landmark_error_max":
            chk(f"mean landmark error <= {v} m", s["landmarks"]["mean_error"] <= v, round(s["landmarks"]["mean_error"], 3))
        elif k == "map_precision_min":
            chk(f"map precision >= {v}", s["map"].get("precision", 0) >= v, round(s["map"].get("precision", 0), 3))
        elif k == "coverage_min":
            chk(f"free-space coverage >= {v}", s["map"].get("coverage", 0) >= v, round(s["map"].get("coverage", 0), 3))
        elif k == "within_limits":
            tr = sim.autonomy.traj
            rep = getattr(tr, "report", None) or {}
            ok = rep.get("within_limits", True)
            chk("trajectory within v/a/j/s/thrust/tilt limits", ok, {k2: round(v2, 3) for k2, v2 in rep.items() if isinstance(v2, float)})
        elif k == "nees_ok":
            chk("mean position NEES < 7.8 (chi2_3 95%)", s.get("nees_pos_mean", 99) < 7.81, round(s.get("nees_pos_mean", float("nan")), 3))
        elif k == "sigma_grows_in_outage":
            w = sim.cfg.faults.camera_blackout[0]
            before = _window_mean(tel, "trace_pos", w[0] - 3, w[0])
            during = _window_mean(tel, "trace_pos", w[1] - 2, w[1])
            after = _window_mean(tel, "trace_pos", w[1] + 4, w[1] + 7)
            chk("position covariance grows during the outage and shrinks after", during > 2 * before and after < during,
                {"trace_before": before, "trace_end_of_outage": during, "trace_after": after})
        elif k == "recovers":
            w = sim.cfg.faults.camera_blackout[0]
            before = _window_mean(tel, "pos_err", w[0] - 4, w[0])
            during = _window_mean(tel, "pos_err", w[1] - 2, w[1])
            after = _window_mean(tel, "pos_err", w[1] + 6, w[1] + 10)
            chk("error after recovery < error during degradation and < 0.6 m", after < during and after < 0.6,
                {"err_before": before, "err_end_of_fault": during, "err_after": after})
        elif k == "loop_closure_gain":
            t = np.array(tel["t"])
            e = np.array(tel["pos_err"])
            tr = np.array(tel["trace_pos"])
            # closure: the largest single drop of position variance in the last 40 % of the flight
            i0 = int(0.6 * len(t))
            k_peak = i0 + int(np.argmax(tr[i0:]))
            peak_err, peak_tr = float(e[k_peak]), float(tr[k_peak])
            end_err, end_tr = float(np.mean(e[-10:])), float(np.mean(tr[-10:]))
            chk("variance and error drop after re-observing the first landmarks", end_tr < 0.5 * peak_tr and end_err <= peak_err + 0.05,
                {"peak_err": peak_err, "peak_trace": peak_tr, "end_err": end_err, "end_trace": end_tr, "t_peak": float(t[k_peak])})
    return out


def write_report(results: dict[str, dict], path: Path = REPORT_DIR) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    lines = ["# Autonomous UAV Lab — scenario report", "",
             f"Generated {time.strftime('%Y-%m-%d %H:%M')} by `python -m uav_lab.experiments`. All numbers below come from these runs;",
             "ground truth is used only for this evaluation.", "",
             "| Scenario | Result | Pos RMSE [m] | Track RMSE [m] | NEES | Landmarks (known/new) | False LM | Map precision | Coverage | Sim time [s] | x real time |",
             "|---|---|---|---|---|---|---|---|---|---|---|"]
    for name, s in results.items():
        f = lambda k, d=3: ("%.*f" % (d, s[k])) if isinstance(s.get(k), (int, float)) and s.get(k) == s.get(k) else "–"
        lines.append(f"| {SCENARIOS[name]['title']} | {'PASS' if s['passed'] else 'FAIL'} | {f('pos_rmse')} | {f('track_rmse')} | {f('nees_pos_mean', 2)} | "
                     f"{s['n_known_in_map']}/{s['n_new_in_map']} | {s['landmarks']['false_landmarks']} | {s['map'].get('precision', 0):.2f} | "
                     f"{s['map'].get('coverage', 0):.2f} | {s['t_end']:.1f} | {s['realtime_factor']:.2f} |")
    lines.append("")
    for name, s in results.items():
        lines.append(f"## {SCENARIOS[name]['title']}")
        lines.append(SCENARIOS[name]["description"])
        lines.append("")
        for c in s["checks"]:
            lines.append(f"- {'✅' if c['ok'] else '❌'} {c['criterion']}: `{json.dumps(c['value'], default=_num)}`")
        lines.append("")
    p = path / "REPORT.md"
    p.write_text("\n".join(lines), encoding="utf-8")
    return p


def _num(o):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    return str(o)


def main(argv=None):
    names = (argv or sys.argv[1:]) or list(SCENARIOS)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    results = {}
    for n in names:
        t0 = time.time()
        sim, s = run_scenario(n)
        s.pop("events", None)
        results[n] = s
        (REPORT_DIR / f"{n}.json").write_text(json.dumps(s, indent=1, default=_num))
        print(f"{n:24s} {'PASS' if s['passed'] else 'FAIL'}  t={s['t_end']:.1f}s wall={time.time() - t0:.0f}s "
              + "; ".join(f"{c['criterion']}={'ok' if c['ok'] else 'NO'}" for c in s["checks"]), flush=True)
    if len(names) == len(SCENARIOS):
        print("report:", write_report(results))
    else:
        prev = {}
        for n in SCENARIOS:
            f = REPORT_DIR / f"{n}.json"
            if f.exists():
                prev[n] = json.loads(f.read_text())
        print("report:", write_report(prev))
    return results


if __name__ == "__main__":
    main()
