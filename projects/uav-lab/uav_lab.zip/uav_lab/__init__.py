"""uav_lab — Autonomous UAV Lab: a single quadrotor with 3D EKF-SLAM, mapping, planning,
differential-flatness trajectories and LQR control, simulated in closed loop.

Frames (used everywhere in this package):
* World W: ENU, z up, gravity g = (0, 0, -9.81) m/s^2.
* Body B: FLU (x forward, y left, z up), origin at the centre of mass.
* Camera C: optical (x right, y down, z forward), pose R_bc / t_bc in the body frame.
* LiDAR L: FLU-aligned sensor frame, pose R_bl / t_bl in the body frame.
* Quaternions are Hamilton, scalar first [w, x, y, z], and rotate body -> world.

Ground truth (the environment and the true vehicle state) lives in `world` and `sim`.
The autonomy stack (`autonomy`, `estimation`, `mapping`, `planning`, `trajectory`, `control`)
only ever receives sensor messages; `tests/uav_lab/test_separation.py` enforces this.
"""

import os as _os

# The matrices here are small (<= ~700 x 700); multi-threaded BLAS only adds spin-wait overhead
# and collapses when several simulations run side by side. Must be set before numpy loads.
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    _os.environ.setdefault(_v, "1")

__version__ = "0.1.0"
