"""All configurable parameters of the lab, as validated Pydantic models.

Units are SI throughout (m, s, kg, N, rad) unless a field name says otherwise (`_deg`, `_hz`).
Every field is editable from the web interface; the UI reads `LabConfig.model_json_schema()`.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class _M(BaseModel):
    model_config = ConfigDict(extra="forbid")


class UAVConfig(_M):
    mass: float = Field(1.5, gt=0.1, le=20, description="Take-off mass [kg]")
    inertia: tuple[float, float, float] = Field((0.0290, 0.0290, 0.0550), description="Jxx, Jyy, Jzz [kg m^2]")
    arm_length: float = Field(0.25, gt=0.05, le=1.0, description="Centre-to-motor distance [m]")
    max_motor_thrust: float = Field(8.0, gt=0.5, le=100, description="Max thrust per motor [N]")
    min_motor_thrust: float = Field(0.05, ge=0, description="Idle thrust per motor [N]")
    motor_time_constant: float = Field(0.03, gt=0.001, le=0.5, description="First-order motor lag [s]")
    torque_coefficient: float = Field(0.016, gt=0, le=0.1, description="Rotor drag torque / thrust [m]")
    linear_drag: tuple[float, float, float] = Field((0.25, 0.25, 0.35), description="Body linear drag [N s/m]")
    quadratic_drag: float = Field(0.02, ge=0, description="Quadratic drag [N s^2/m^2]")
    rotational_damping: float = Field(0.002, ge=0, description="Angular damping [N m s/rad]")
    max_velocity: float = Field(3.0, gt=0.1, le=30, description="Planner velocity limit [m/s]")
    max_acceleration: float = Field(3.0, gt=0.1, le=30, description="Planner acceleration limit [m/s^2]")
    max_tilt_deg: float = Field(35.0, gt=5, le=80, description="Max tilt [deg]")
    battery_capacity_wh: float = Field(60.0, gt=1, le=2000, description="Battery energy [Wh]")
    battery_voltage: float = Field(14.8, gt=3, le=60, description="Nominal pack voltage [V]")
    propeller_diameter: float = Field(0.254, gt=0.05, le=1.0, description="Propeller diameter [m]")
    figure_of_merit: float = Field(0.6, gt=0.1, le=1.0, description="Rotor figure of merit (momentum theory)")
    avionics_power_w: float = Field(8.0, ge=0, description="Constant electronics power [W]")
    collision_radius: float = Field(0.35, gt=0.05, le=2, description="Radius used for crash detection [m]")


class DisturbanceConfig(_M):
    wind_mean: tuple[float, float, float] = Field((0.0, 0.0, 0.0), description="Mean wind, world frame [m/s]")
    gust_std: float = Field(0.0, ge=0, le=10, description="Gust intensity (Ornstein-Uhlenbeck std) [m/s]")
    gust_time_constant: float = Field(2.0, gt=0.05, description="Gust correlation time [s]")
    impulse_times: list[float] = Field(default_factory=list, description="Times of impulsive pushes [s]")
    impulse_force: tuple[float, float, float] = Field((4.0, 0.0, 0.0), description="Push force [N] (0.2 s)")
    torque_noise_std: float = Field(0.0, ge=0, description="Random torque disturbance std [N m]")


class IMUConfig(_M):
    rate_hz: float = Field(200.0, ge=50, le=1000)
    accel_noise_density: float = Field(0.02, ge=0, description="[m/s^2/sqrt(Hz)]")
    gyro_noise_density: float = Field(0.002, ge=0, description="[rad/s/sqrt(Hz)]")
    accel_bias_rw: float = Field(0.002, ge=0, description="Accel bias random walk [m/s^3/sqrt(Hz)]")
    gyro_bias_rw: float = Field(0.0002, ge=0, description="Gyro bias random walk [rad/s^2/sqrt(Hz)]")
    accel_bias_init: tuple[float, float, float] = Field((0.08, -0.05, 0.10), description="True initial accel bias [m/s^2]")
    gyro_bias_init: tuple[float, float, float] = Field((0.004, -0.003, 0.002), description="True initial gyro bias [rad/s]")
    delay: float = Field(0.0, ge=0, le=0.05, description="Transport delay [s]")


class LidarConfig(_M):
    enabled: bool = True
    rate_hz: float = Field(5.0, ge=0.5, le=20)
    max_range: float = Field(15.0, ge=2, le=100)
    min_range: float = Field(0.3, ge=0.0, le=2)
    horizontal_fov_deg: float = Field(360.0, ge=10, le=360)
    vertical_fov_deg: float = Field(60.0, ge=2, le=180)
    horizontal_resolution_deg: float = Field(3.0, ge=0.2, le=20)
    vertical_resolution_deg: float = Field(4.0, ge=0.2, le=20)
    range_noise_std: float = Field(0.02, ge=0, le=2)
    dropout_probability: float = Field(0.02, ge=0, le=1, description="Probability a valid return is lost")
    delay: float = Field(0.02, ge=0, le=0.3)
    mount_position: tuple[float, float, float] = Field((0.0, 0.0, 0.08), description="t_bl in body [m]")


class CameraConfig(_M):
    enabled: bool = True
    rgbd: bool = Field(True, description="RGB-D (depth per feature) instead of monocular RGB")
    rate_hz: float = Field(10.0, ge=1, le=60)
    width: int = Field(640, ge=64, le=1920)
    height: int = Field(480, ge=48, le=1080)
    hfov_deg: float = Field(90.0, ge=30, le=150)
    pixel_noise_std: float = Field(1.0, ge=0, le=20, description="[px]")
    depth_noise_coeff: float = Field(0.004, ge=0, le=0.1, description="sigma_d = coeff * d^2 [m]")
    min_depth: float = Field(0.3, ge=0.05)
    max_depth: float = Field(12.0, ge=1, le=60)
    detection_probability: float = Field(0.95, ge=0, le=1)
    id_decode_probability: float = Field(0.9, ge=0, le=1, description="Known-landmark marker read success")
    id_misread_probability: float = Field(0.02, ge=0, le=1, description="Marker read as a wrong ID")
    descriptor_noise: float = Field(0.08, ge=0, le=1)
    clutter_rate: float = Field(1.0, ge=0, le=50, description="Spurious features per frame (Poisson mean)")
    pitch_deg: float = Field(-10.0, ge=-90, le=45, description="Camera pitch (negative = down)")
    mount_position: tuple[float, float, float] = Field((0.12, 0.0, -0.02), description="t_bc in body [m]")
    delay: float = Field(0.03, ge=0, le=0.3)
    image_rate_hz: float = Field(2.0, ge=0, le=10, description="Rendered RGB/depth preview rate")
    image_width: int = Field(96, ge=16, le=320)
    image_height: int = Field(72, ge=12, le=240)


class GNSSConfig(_M):
    enabled: bool = False
    rate_hz: float = Field(5.0, ge=0.2, le=20)
    noise_std: tuple[float, float, float] = Field((0.5, 0.5, 0.8))
    delay: float = Field(0.1, ge=0, le=1)


class BaroConfig(_M):
    enabled: bool = True
    rate_hz: float = Field(20.0, ge=1, le=100)
    noise_std: float = Field(0.15, ge=0, le=5)
    delay: float = Field(0.0, ge=0, le=0.3)


class SensorsConfig(_M):
    imu: IMUConfig = IMUConfig()
    lidar: LidarConfig = LidarConfig()
    camera: CameraConfig = CameraConfig()
    gnss: GNSSConfig = GNSSConfig()
    baro: BaroConfig = BaroConfig()


class EKFConfig(_M):
    init_pos_std: float = Field(0.05, ge=0, description="[m]")
    init_vel_std: float = Field(0.05, ge=0, description="[m/s]")
    init_att_std_deg: float = Field(2.0, ge=0)
    init_accel_bias_std: float = Field(0.2, ge=0, description="[m/s^2]")
    init_gyro_bias_std: float = Field(0.01, ge=0, description="[rad/s]")
    process_noise_scale: float = Field(1.5, gt=0, le=100, description="Multiplier on IMU noise densities")
    pixel_noise_std: float = Field(1.5, gt=0, description="Assumed pixel noise [px]")
    depth_noise_coeff: float = Field(0.006, gt=0, description="Assumed depth noise sigma = c d^2 [m]")
    baro_noise_std: float = Field(0.2, gt=0)
    gnss_noise_std: float = Field(0.8, gt=0)
    association_gate_prob: float = Field(0.997, gt=0.5, lt=1.0, description="Chi-square gate probability")
    descriptor_gate: float = Field(0.45, gt=0, le=2, description="Max descriptor distance for a match")
    ambiguity_ratio: float = Field(0.6, gt=0, le=1, description="Reject if best/second-best Mahalanobis ratio is above this")
    candidate_min_observations: int = Field(4, ge=2, le=50, description="Observations before a new landmark is added")
    candidate_max_age: float = Field(2.0, gt=0, description="Unconfirmed candidate lifetime [s]")
    min_init_depth: float = Field(0.5, ge=0)
    max_init_depth: float = Field(6.0, gt=0, description="Only initialise landmarks closer than this [m]: depth noise grows with d^2 and FEJ keeps the first estimate as linearisation point")
    mono_min_parallax_deg: float = Field(3.0, gt=0, le=45)
    max_landmarks: int = Field(220, ge=5, le=600)
    max_updates_per_frame: int = Field(25, ge=1, le=200)
    innovation_outlier_prob: float = Field(0.9999, gt=0.9, lt=1.0, description="Chi-square level to reject an innovation at update")
    use_known_priors: bool = Field(True, description="Insert the known-landmark database into the state at start")
    first_estimate_jacobians: bool = Field(True, description="FEJ: linearise landmark Jacobians at the landmark's first estimate (consistency of the unobservable yaw/position directions)")
    adaptive_process_noise: bool = Field(True, description="Scale IMU process noise from the camera NIS (innovation-based adaptation)")
    adaptive_max_scale: float = Field(30.0, ge=1, le=1000)


class MappingConfig(_M):
    voxel_size: float = Field(0.5, ge=0.1, le=2.0)
    log_odds_hit: float = Field(0.85, gt=0)
    log_odds_miss: float = Field(-0.4, lt=0)
    log_odds_min: float = Field(-2.0)
    log_odds_max: float = Field(3.5)
    occupied_threshold: float = Field(0.7)
    free_threshold: float = Field(-0.35, description="One LiDAR miss (log_odds_miss) marks a voxel free")
    pointcloud_voxel: float = Field(0.25, ge=0.05, le=2.0)
    max_points: int = Field(60000, ge=1000, le=400000)


class PlannerConfig(_M):
    algorithm: Literal["astar", "rrtstar"] = "astar"
    grid_resolution: float = Field(1.0, ge=0.25, le=3.0, description="Planning grid cell [m]")
    clearance: float = Field(0.6, ge=0.1, le=3.0, description="Obstacle clearance [m]")
    unknown_cost: float = Field(2.0, ge=1.0, le=50, description="Cost multiplier for unknown cells (optimistic planning)")
    heuristic_weight: float = Field(1.3, ge=1.0, le=5.0)
    min_altitude: float = Field(1.0, ge=0.3)
    max_altitude: float = Field(6.0, ge=1.0)
    replan_period: float = Field(1.0, gt=0.1, description="Collision re-check period [s]")
    goal_tolerance: float = Field(0.5, gt=0.05)
    rrt_iterations: int = Field(2500, ge=100, le=20000)
    rrt_step: float = Field(1.5, gt=0.1)
    emergency_stop_distance: float = Field(1.0, ge=0.2, description="Minimum LiDAR braking distance [m]; grows with v^2/(2a)")
    max_position_sigma: float = Field(0.7, gt=0.05, description="Position 1-sigma [m] above which the vehicle holds and scans for landmarks")
    relocalization_yaw_rate: float = Field(0.5, ge=0, le=2, description="Yaw rate while holding to re-localise [rad/s]")


class ExplorationConfig(_M):
    sensor_radius: float = Field(6.0, gt=1)
    distance_weight: float = Field(0.25, ge=0, description="lambda in gain * exp(-lambda * cost)")
    min_frontier_size: int = Field(6, ge=1)
    uncertainty_threshold: float = Field(0.6, gt=0, description="Position 1-sigma [m] that triggers a revisit of mapped landmarks")
    coverage_target: float = Field(0.8, gt=0, le=1.0, description="Stop exploring at this fraction of reachable volume")
    max_time: float = Field(240.0, gt=5)


class TrajectoryConfig(_M):
    max_velocity: float = Field(2.5, gt=0.1, le=30)
    max_acceleration: float = Field(2.5, gt=0.1, le=30)
    max_jerk: float = Field(8.0, gt=0.1, le=500)
    max_snap: float = Field(40.0, gt=0.1, le=5000)
    max_yaw_rate: float = Field(1.2, gt=0.05, le=10)
    time_allocation_factor: float = Field(1.0, gt=0.2, le=5.0)
    trajectory_duration: float | None = Field(None, gt=0.5, le=600, description="Force total duration [s] (None = automatic)")
    waypoints: list[tuple[float, float, float]] = Field(
        default_factory=lambda: [(0.0, 0.0, 2.0), (6.0, 0.0, 2.5), (6.0, 6.0, 3.0), (0.0, 6.0, 2.5), (0.0, 0.0, 2.0)],
        description="Waypoints for the trajectory laboratory (world frame, m)")
    yaw_mode: Literal["velocity", "fixed"] = "velocity"
    fixed_yaw: float = 0.0


class LQRConfig(_M):
    q_position: tuple[float, float, float] = Field((14.0, 14.0, 20.0))
    q_velocity: tuple[float, float, float] = Field((4.0, 4.0, 6.0))
    q_attitude: tuple[float, float, float] = Field((8.0, 8.0, 4.0))
    q_rate: tuple[float, float, float] = Field((0.3, 0.3, 0.3))
    r_thrust: float = Field(0.05, gt=0)
    r_torque: tuple[float, float, float] = Field((60.0, 60.0, 30.0))
    max_tilt_command_deg: float = Field(35.0, gt=5, le=80)
    integral_gain: float = Field(0.15, ge=0, le=5, description="Integral action on position error (anti-windup clamped)")


class LandmarkSpec(_M):
    position: tuple[float, float, float]
    known: bool = False
    prior_std: float = Field(0.05, ge=0, description="Prior uncertainty of a known landmark [m]")
    prior_offset: tuple[float, float, float] = Field((0.0, 0.0, 0.0), description="Error injected in the database coordinates [m]")


class ObstacleSpec(_M):
    kind: Literal["box", "cylinder", "sphere"]
    center: tuple[float, float, float]
    size: tuple[float, float, float] = Field((1.0, 1.0, 1.0), description="box: full extents; cylinder: (radius, radius, height); sphere: (radius, ...)")
    label: str = "obstacle"
    color: str = "#8a8f98"
    velocity: tuple[float, float, float] = Field((0.0, 0.0, 0.0), description="Dynamic obstacle velocity [m/s]")
    motion_amplitude: float = Field(0.0, ge=0, description="Oscillation amplitude along velocity direction [m] (0 = constant velocity)")


class EnvironmentConfig(_M):
    preset: Literal["urban", "forest", "warehouse", "open", "custom"] = "urban"
    seed: int = 7
    bounds_min: tuple[float, float, float] = (-20.0, -20.0, 0.0)
    bounds_max: tuple[float, float, float] = (20.0, 20.0, 10.0)
    obstacle_density: float = Field(1.0, ge=0, le=3, description="Scales the number of generated obstacles")
    n_known_landmarks: int = Field(12, ge=0, le=100)
    n_unknown_landmarks: int = Field(600, ge=0, le=2000)
    known_prior_std: float = Field(0.05, ge=0)
    known_prior_error: float = Field(0.0, ge=0, description="Std of error injected in the known database [m]")
    n_ground_features: int = Field(400, ge=0, le=2000, description="Texture features on the ground plane (unknown landmarks)")
    n_dynamic_obstacles: int = Field(0, ge=0, le=10)
    obstacles: list[ObstacleSpec] = Field(default_factory=list, description="Used when preset == custom (added otherwise)")
    landmarks: list[LandmarkSpec] = Field(default_factory=list, description="Extra landmarks")


class FaultConfig(_M):
    camera_blackout: list[tuple[float, float]] = Field(default_factory=list, description="(start, end) [s]")
    lidar_blackout: list[tuple[float, float]] = Field(default_factory=list)
    gnss_outage: list[tuple[float, float]] = Field(default_factory=list)
    imu_noise_multiplier: float = Field(1.0, ge=1, le=100)
    imu_noise_window: tuple[float, float] | None = None
    lidar_noise_multiplier: float = Field(1.0, ge=1, le=100)
    camera_noise_multiplier: float = Field(1.0, ge=1, le=100)


class MissionConfig(_M):
    mode: Literal["navigate", "explore", "track", "hover"] = "navigate"
    start: tuple[float, float, float] = (-14.0, -14.0, 0.0)
    start_yaw: float = 0.0
    goal: tuple[float, float, float] = (14.0, 14.0, 2.5)
    via: list[tuple[float, float, float]] = Field(default_factory=list, description="Intermediate goals visited (with planning) before the goal")
    takeoff_altitude: float = Field(2.0, gt=0.3)
    duration: float = Field(120.0, gt=1, le=1200, description="Maximum simulated time [s]")
    land_at_goal: bool = False


class SimConfig(_M):
    physics_rate_hz: float = Field(400.0, ge=100, le=2000)
    control_rate_hz: float = Field(100.0, ge=20, le=500)
    telemetry_rate_hz: float = Field(10.0, ge=1, le=50)
    seed: int = 1


class LabConfig(_M):
    name: str = "lab"
    uav: UAVConfig = UAVConfig()
    disturbance: DisturbanceConfig = DisturbanceConfig()
    sensors: SensorsConfig = SensorsConfig()
    ekf: EKFConfig = EKFConfig()
    mapping: MappingConfig = MappingConfig()
    planner: PlannerConfig = PlannerConfig()
    exploration: ExplorationConfig = ExplorationConfig()
    trajectory: TrajectoryConfig = TrajectoryConfig()
    lqr: LQRConfig = LQRConfig()
    environment: EnvironmentConfig = EnvironmentConfig()
    faults: FaultConfig = FaultConfig()
    mission: MissionConfig = MissionConfig()
    sim: SimConfig = SimConfig()


def merge(base: LabConfig, patch: dict) -> LabConfig:
    """Deep-merge a partial dict into a config and re-validate."""
    def rec(a: dict, b: dict) -> dict:
        out = dict(a)
        for k, v in b.items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k] = rec(out[k], v)
            else:
                out[k] = v
        return out
    return LabConfig.model_validate(rec(base.model_dump(), patch))
