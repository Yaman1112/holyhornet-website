"""The 15 test scenarios. Each is a patch on the default LabConfig plus pass criteria.

Criteria are evaluated against ground truth by `experiments.py` only after (or during) the run.
"""

from __future__ import annotations

from .config import LabConfig, merge

LOOP = [(-14.0, -14.0, 2.5), (-12.0, 12.0, 2.5), (12.0, 12.0, 2.5), (12.0, -12.0, 2.5), (-10.0, -13.0, 2.5), (-13.0, -8.0, 2.5)]

SCENARIOS: dict[str, dict] = {
    "known_landmarks": {
        "title": "1. Known landmarks only",
        "description": "Only database landmarks (marker ids, prior coordinates). The EKF recognises them and corrects its pose.",
        "patch": {"environment": {"n_known_landmarks": 60, "n_unknown_landmarks": 0}, "mission": {"duration": 70}},
        "criteria": {"pos_rmse_max": 0.5, "no_crash": True, "reach_goal": True, "known_observed_min": 3},
    },
    "unknown_landmarks": {
        "title": "2. Unknown landmarks only",
        "description": "No database. Every landmark is discovered, initialised and tracked by the SLAM front end.",
        "patch": {"environment": {"n_known_landmarks": 0}, "ekf": {"use_known_priors": False}, "mission": {"duration": 70}},
        "criteria": {"pos_rmse_max": 0.8, "no_crash": True, "reach_goal": True, "new_landmarks_min": 15, "false_landmarks_max": 0},
    },
    "mixed_landmarks": {
        "title": "3. Mixed known and unknown landmarks",
        "description": "Default urban map: 12 known (with 0.3 m database error to be corrected) and 260 unknown landmarks.",
        "patch": {"environment": {"known_prior_error": 0.3, "known_prior_std": 0.4}, "mission": {"duration": 70}},
        "criteria": {"pos_rmse_max": 0.8, "no_crash": True, "reach_goal": True, "landmark_error_max": 0.35},
    },
    "unknown_environment": {
        "title": "4. Completely unknown environment",
        "description": "Dense obstacles, no database, no GNSS. Map, landmarks and path are all built online.",
        "patch": {"environment": {"n_known_landmarks": 0, "obstacle_density": 1.4, "seed": 11}, "ekf": {"use_known_priors": False},
                  "mission": {"duration": 150}},
        "criteria": {"pos_rmse_max": 1.0, "no_crash": True, "reach_goal": True, "map_precision_min": 0.6},
    },
    "noisy_imu": {
        "title": "5. Noisy IMU",
        "description": "IMU white noise x5 for the whole flight; the filter's process noise is not retuned.",
        "patch": {"faults": {"imu_noise_multiplier": 5.0}, "mission": {"duration": 70}},
        "criteria": {"pos_rmse_max": 1.2, "no_crash": True, "reach_goal": True},
    },
    "noisy_lidar": {
        "title": "6. Noisy LiDAR",
        "description": "LiDAR range noise x10 (0.2 m) and 20 % dropouts; the map degrades gracefully.",
        "patch": {"faults": {"lidar_noise_multiplier": 10.0}, "sensors": {"lidar": {"dropout_probability": 0.2}}, "mission": {"duration": 70}},
        "criteria": {"no_crash": True, "reach_goal": True, "map_precision_min": 0.5},
    },
    "camera_feature_loss": {
        "title": "7. Camera feature loss",
        "description": "Camera blacked out from 8 s to 16 s: IMU + baro dead reckoning, covariance grows, then shrinks on re-observation.",
        "patch": {"faults": {"camera_blackout": [(8.0, 16.0)]}, "mission": {"duration": 70}},
        "criteria": {"no_crash": True, "reach_goal": True, "sigma_grows_in_outage": True, "nees_ok": True},
    },
    "gnss_unavailable": {
        "title": "8. GNSS unavailable",
        "description": "GNSS fixes for the first 6 s, then denied for the rest of the mission (SLAM-only navigation).",
        "patch": {"sensors": {"gnss": {"enabled": True}}, "faults": {"gnss_outage": [(6.0, 1e9)]}, "mission": {"duration": 70}},
        "criteria": {"pos_rmse_max": 0.8, "no_crash": True, "reach_goal": True},
    },
    "landmark_occlusion": {
        "title": "9. Landmark occlusion",
        "description": "Twice the obstacle density: many landmarks are hidden behind other obstacles (ray-cast occlusion).",
        "patch": {"environment": {"obstacle_density": 2.0, "seed": 5}, "mission": {"duration": 150}},
        "criteria": {"no_crash": True, "reach_goal": True, "false_landmarks_max": 0},
    },
    "loop_closure": {
        "title": "10. Loop closure",
        "description": "A large loop with no database and no GNSS; re-observing the first landmarks at the end collapses the accumulated drift.",
        "patch": {"environment": {"n_known_landmarks": 0}, "ekf": {"use_known_priors": False},
                  "mission": {"mode": "navigate", "duration": 160, "via": LOOP[1:-1], "goal": LOOP[-1]}},
        "criteria": {"no_crash": True, "loop_closure_gain": True},
    },
    "dynamic_obstacles": {
        "title": "11. Dynamic obstacles",
        "description": "Four moving obstacles cross the area. The map clears vacated space; the planner replans and brakes when needed.",
        "patch": {"environment": {"n_dynamic_obstacles": 4, "seed": 3}, "mission": {"duration": 90}},
        "criteria": {"no_crash": True, "reach_goal": True},
    },
    "exploration": {
        "title": "12. Autonomous exploration",
        "description": "Frontier-based exploration with information gain and uncertainty-triggered landmark revisits.",
        "patch": {"mission": {"mode": "explore", "duration": 180}, "exploration": {"max_time": 150}},
        "criteria": {"no_crash": True, "coverage_min": 0.45},
    },
    "flatness_tracking": {
        "title": "13. Differential-flatness trajectory tracking",
        "description": "Aggressive min-snap figure in open space, perfect-weather LQR tracking of the flat outputs.",
        "patch": {"environment": {"preset": "open", "obstacle_density": 0.0},
                  "mission": {"mode": "track", "start": (0.0, 0.0, 0.0), "duration": 60},
                  "trajectory": {"max_velocity": 4.0, "max_acceleration": 4.0, "max_jerk": 15, "max_snap": 80,
                                 "waypoints": [(0, 0, 2.0), (8, 0, 3.0), (8, 8, 4.0), (0, 8, 3.0), (-8, 0, 2.0), (0, -8, 3.0), (0, 0, 2.0)]}},
        "criteria": {"no_crash": True, "track_rmse_max": 0.3, "within_limits": True},
    },
    "lqr_disturbance": {
        "title": "14. LQR tracking under disturbances",
        "description": "Same figure with 3 m/s wind, 1 m/s gusts and two 4 N impulsive pushes.",
        "patch": {"environment": {"preset": "open", "obstacle_density": 0.0},
                  "mission": {"mode": "track", "start": (0.0, 0.0, 0.0), "duration": 60},
                  "disturbance": {"wind_mean": (3.0, 1.0, 0.0), "gust_std": 1.0, "impulse_times": [8.0, 14.0], "impulse_force": (4.0, -3.0, 0.0)},
                  "trajectory": {"waypoints": [(0, 0, 2.0), (8, 0, 3.0), (8, 8, 4.0), (0, 8, 3.0), (-8, 0, 2.0), (0, -8, 3.0), (0, 0, 2.0)]}},
        "criteria": {"no_crash": True, "track_rmse_max": 0.5},
    },
    "sensor_recovery": {
        "title": "15. Localisation recovery after sensor degradation",
        "description": "Camera blackout 8-18 s plus IMU noise x4 in the same window, then nominal sensors: the error returns to its pre-fault level.",
        "patch": {"faults": {"camera_blackout": [(8.0, 18.0)], "imu_noise_multiplier": 4.0, "imu_noise_window": (8.0, 18.0)},
                  "mission": {"duration": 70}},
        "criteria": {"no_crash": True, "recovers": True, "nees_ok": True},
    },
}


def scenario_config(name: str, base: LabConfig | None = None) -> LabConfig:
    sc = SCENARIOS[name]
    cfg = merge(base or LabConfig(), sc["patch"])
    return cfg.model_copy(update={"name": name})


def list_scenarios() -> list[dict]:
    return [{"id": k, "title": v["title"], "description": v["description"], "criteria": v["criteria"]} for k, v in SCENARIOS.items()]
