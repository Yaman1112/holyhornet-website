"""Sensor messages: the only data that crosses from the simulated world into the autonomy stack.

Every message carries `t` (time of measurement) and `t_arrival` (t + transport delay). Nothing in
here contains ground truth: feature messages have no true landmark id (evaluation side tables are
kept by the simulator).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class IMUMsg:
    t: float
    t_arrival: float
    accel: np.ndarray    # specific force, body frame [m/s^2]
    gyro: np.ndarray     # angular rate, body frame [rad/s]
    dt: float


@dataclass
class LidarMsg:
    t: float
    t_arrival: float
    ranges: np.ndarray        # (n,) metres; nan = invalid return (dropout); inf = no return within max range
    dirs_sensor: np.ndarray   # (n, 3) unit directions in the LiDAR frame
    max_range: float


@dataclass
class Feature:
    uv: np.ndarray                 # pixel (u, v)
    depth: float | None            # RGB-D depth along optical axis [m], None for monocular
    descriptor: np.ndarray         # unit appearance descriptor
    marker_id: int | None = None   # decoded fiducial id (known landmarks), possibly misread
    track_id: int = -1             # assigned by the front-end tracker


@dataclass
class CameraMsg:
    t: float
    t_arrival: float
    features: list[Feature]
    image: np.ndarray | None = None        # (h, w, 3) uint8 preview
    depth_image: np.ndarray | None = None  # (h, w) float32, nan where no return


@dataclass
class GNSSMsg:
    t: float
    t_arrival: float
    position: np.ndarray


@dataclass
class BaroMsg:
    t: float
    t_arrival: float
    altitude: float


@dataclass(order=True)
class _Queued:
    t_arrival: float
    seq: int
    msg: object = field(compare=False)
