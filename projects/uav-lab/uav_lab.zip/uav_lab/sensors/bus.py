"""Delivers sensor messages when their transport delay has elapsed (in arrival order)."""

from __future__ import annotations

import heapq
import itertools

from .messages import _Queued


class SensorBus:
    def __init__(self):
        self._q: list[_Queued] = []
        self._seq = itertools.count()

    def publish(self, msg) -> None:
        heapq.heappush(self._q, _Queued(msg.t_arrival, next(self._seq), msg))

    def deliver(self, now: float) -> list:
        out = []
        while self._q and self._q[0].t_arrival <= now + 1e-12:
            out.append(heapq.heappop(self._q).msg)
        return out

    def __len__(self) -> int:
        return len(self._q)
