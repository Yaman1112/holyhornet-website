"""RGB / RGB-D camera.

Pinhole model with intrinsics K (calibrated: fx = fy, principal point at the image centre):

    p_C = R_bc^T ( R^T (m - p) - t_bc ),   u = fx X/Z + cx,   v = fy Y/Z + cy

Feature extraction: a landmark is detected when it is inside the image, within [min, max]
depth, faces the camera, is not occluded (line-of-sight ray cast) and passes a detection draw
whose probability falls with distance and viewing angle. Each detection reports a noisy pixel,
a noisy depth (RGB-D: sigma = c d^2), a noisy appearance descriptor and, for known landmarks,
the decoded fiducial id (which can fail or be misread). Spurious "clutter" features are added.

The returned `truth` list (true landmark id per feature, -1 for clutter) is for evaluation only;
the simulator keeps it and never passes it to the autonomy stack.

A low-resolution shaded RGB image and depth image are also ray-traced for display.
"""

from __future__ import annotations

import numpy as np

from ..config import CameraConfig
from ..math3d import quat_to_rot
from ..vehicle.airframe import camera_extrinsics, camera_intrinsics
from .messages import CameraMsg, Feature


class Camera:
    def __init__(self, cfg: CameraConfig, rng: np.random.Generator, marker_ids: list[int]):
        self.cfg = cfg
        self.rng = rng
        self.K = camera_intrinsics(cfg)
        self.R_bc, self.t_bc = camera_extrinsics(cfg)
        self.noise_mult = 1.0
        self.marker_ids = marker_ids
        self._last_image_t = -1e9
        # preview ray directions in the optical frame
        w, h = cfg.image_width, cfg.image_height
        fx = 0.5 * w / np.tan(0.5 * np.deg2rad(cfg.hfov_deg))
        u, v = np.meshgrid(np.arange(w) + 0.5, np.arange(h) + 0.5)
        d = np.c_[((u - w / 2) / fx).ravel(), ((v - h / 2) / fx).ravel(), np.ones(u.size)]
        self._img_dirs = d / np.linalg.norm(d, axis=1, keepdims=True)
        self._img_z = 1.0 / np.linalg.norm(np.c_[((u - w / 2) / fx).ravel(), ((v - h / 2) / fx).ravel(), np.ones(u.size)], axis=1)

    def pose(self, p, q):
        R = quat_to_rot(q)
        return R @ self.R_bc, p + R @ self.t_bc

    def capture(self, t: float, env, p: np.ndarray, q: np.ndarray) -> tuple[CameraMsg, list[int]]:
        c, rng = self.cfg, self.rng
        R_wc, o = self.pose(p, q)
        feats: list[Feature] = []
        truth: list[int] = []
        if len(env.landmarks):
            P = env.lm_pos
            pc = (P - o) @ R_wc               # rows: R_wc^T (m - o)
            Z = pc[:, 2]
            cand = (Z > c.min_depth) & (Z < c.max_depth)
            uvw = pc @ self.K.T
            uv = uvw[:, :2] / np.where(np.abs(uvw[:, 2:3]) > 1e-9, uvw[:, 2:3], 1e-9)
            cand &= (uv[:, 0] >= 0) & (uv[:, 0] < c.width) & (uv[:, 1] >= 0) & (uv[:, 1] < c.height)
            idx = np.nonzero(cand)[0]
            if len(idx):
                normals = np.array([env.landmarks[i].normal for i in idx])
                view = (o - P[idx])
                dist = np.linalg.norm(view, axis=1)
                cosang = np.einsum("ij,ij->i", normals, view / dist[:, None])
                facing = cosang > 0.15
                idx, dist, cosang = idx[facing], dist[facing], cosang[facing]
                vis = env.visible(o, P[idx])
                idx, dist, cosang = idx[vis], dist[vis], cosang[vis]
                # detection probability falls off with range and with grazing viewing angles
                pdet = c.detection_probability * np.clip(1.3 - 0.6 * dist / c.max_depth, 0, 1) * np.clip(0.5 + cosang, 0, 1)
                det = rng.random(len(idx)) < pdet
                for i in idx[det]:
                    lm = env.landmarks[i]
                    s_px = c.pixel_noise_std * self.noise_mult
                    z = uv[i] + s_px * rng.standard_normal(2)
                    depth = None
                    if c.rgbd:
                        depth = float(Z[i] + self.noise_mult * c.depth_noise_coeff * Z[i] ** 2 * rng.standard_normal())
                    d = lm.descriptor + c.descriptor_noise * rng.standard_normal(lm.descriptor.size) / np.sqrt(lm.descriptor.size)
                    marker = None
                    if lm.known and rng.random() < c.id_decode_probability:
                        marker = lm.marker_id
                        if rng.random() < c.id_misread_probability and len(self.marker_ids) > 1:
                            marker = int(rng.choice([m for m in self.marker_ids if m != lm.marker_id]))
                    feats.append(Feature(z, depth, d / np.linalg.norm(d), marker))
                    truth.append(lm.true_id)
        # clutter
        n_cl = rng.poisson(c.clutter_rate)
        for _ in range(n_cl):
            d = rng.standard_normal(len(env.landmarks[0].descriptor) if env.landmarks else 16)
            depth = float(rng.uniform(c.min_depth, c.max_depth)) if c.rgbd else None
            feats.append(Feature(np.array([rng.uniform(0, c.width), rng.uniform(0, c.height)]), depth, d / np.linalg.norm(d), None))
            truth.append(-1)
        order = rng.permutation(len(feats))
        feats = [feats[i] for i in order]
        truth = [truth[i] for i in order]
        msg = CameraMsg(t, t + c.delay, feats)
        if c.image_rate_hz > 0 and t - self._last_image_t >= 1.0 / c.image_rate_hz - 1e-9:
            self._last_image_t = t
            dirs_w = self._img_dirs @ R_wc.T
            rgb, rng_t, _ = env.render(o, dirs_w, c.max_depth * 2)
            msg.image = (np.clip(rgb, 0, 1) * 255).astype(np.uint8).reshape(c.image_height, c.image_width, 3)
            depth = (rng_t * self._img_z).astype(np.float32)
            depth[~np.isfinite(depth)] = np.nan
            msg.depth_image = depth.reshape(c.image_height, c.image_width)
        return msg, truth
