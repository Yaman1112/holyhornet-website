"""Three-axis accelerometer + gyroscope with white noise, constant initial bias and bias random walk.

    a_m = f_B + b_a + n_a,      n_a ~ N(0, sigma_a^2 / dt)       (sigma_a: noise density)
    w_m = w_B + b_g + n_g,      n_g ~ N(0, sigma_g^2 / dt)
    b_a(k+1) = b_a(k) + N(0, sigma_ba^2 dt),  b_g likewise
"""

from __future__ import annotations

import numpy as np

from ..config import IMUConfig
from .messages import IMUMsg


class IMU:
    def __init__(self, cfg: IMUConfig, rng: np.random.Generator):
        self.cfg = cfg
        self.rng = rng
        self.dt = 1.0 / cfg.rate_hz
        self.ba = np.array(cfg.accel_bias_init, float)
        self.bg = np.array(cfg.gyro_bias_init, float)
        self.noise_mult = 1.0

    def measure(self, t: float, specific_force_b: np.ndarray, omega_b: np.ndarray) -> IMUMsg:
        c, dt, r = self.cfg, self.dt, self.rng
        self.ba = self.ba + c.accel_bias_rw * np.sqrt(dt) * r.standard_normal(3)
        self.bg = self.bg + c.gyro_bias_rw * np.sqrt(dt) * r.standard_normal(3)
        k = self.noise_mult
        acc = specific_force_b + self.ba + k * c.accel_noise_density / np.sqrt(dt) * r.standard_normal(3)
        gyr = omega_b + self.bg + k * c.gyro_noise_density / np.sqrt(dt) * r.standard_normal(3)
        return IMUMsg(t, t + c.delay, acc, gyr, dt)
