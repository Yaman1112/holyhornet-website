"""3D scanning LiDAR: a grid of rays (azimuth x elevation) cast against the true environment.

Returns the first-surface range per ray (occlusion is inherent to ray casting), with Gaussian
range noise, random dropouts (nan) and no-return rays (inf) beyond max range or below min range.
The whole scan is taken at one instant (no motion distortion).
"""

from __future__ import annotations

import numpy as np

from ..config import LidarConfig
from ..math3d import quat_to_rot
from ..vehicle.airframe import lidar_extrinsics
from .messages import LidarMsg


def ray_pattern(cfg: LidarConfig) -> np.ndarray:
    hf = np.deg2rad(cfg.horizontal_fov_deg)
    vf = np.deg2rad(cfg.vertical_fov_deg)
    n_az = max(1, int(round(cfg.horizontal_fov_deg / cfg.horizontal_resolution_deg)))
    n_el = max(1, int(round(cfg.vertical_fov_deg / cfg.vertical_resolution_deg)) + 1)
    if cfg.horizontal_fov_deg >= 360:
        az = np.linspace(-np.pi, np.pi, n_az, endpoint=False)
    else:
        az = np.linspace(-hf / 2, hf / 2, n_az)
    el = np.linspace(-vf / 2, vf / 2, n_el)
    A, E = np.meshgrid(az, el)
    return np.c_[(np.cos(E) * np.cos(A)).ravel(), (np.cos(E) * np.sin(A)).ravel(), np.sin(E).ravel()]


class Lidar:
    def __init__(self, cfg: LidarConfig, rng: np.random.Generator):
        self.cfg = cfg
        self.rng = rng
        self.dirs = ray_pattern(cfg)
        self.R_bl, self.t_bl = lidar_extrinsics(cfg)
        self.noise_mult = 1.0

    def scan(self, t: float, env, p: np.ndarray, q: np.ndarray) -> LidarMsg:
        c = self.cfg
        R = quat_to_rot(q)
        origin = p + R @ self.t_bl
        dw = self.dirs @ (R @ self.R_bl).T
        rng_true, _ = env.raycast(origin[None], dw, c.max_range)
        r = rng_true + self.noise_mult * c.range_noise_std * self.rng.standard_normal(len(rng_true))
        r[~np.isfinite(rng_true)] = np.inf
        r[rng_true < c.min_range] = np.inf
        drop = self.rng.random(len(r)) < c.dropout_probability
        r[drop & np.isfinite(r)] = np.nan
        return LidarMsg(t, t + c.delay, r, self.dirs, c.max_range)
