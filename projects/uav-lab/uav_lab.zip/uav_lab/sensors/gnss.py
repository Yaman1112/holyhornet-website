"""GNSS position fix and barometric altimeter (white Gaussian noise)."""

from __future__ import annotations

import numpy as np

from ..config import BaroConfig, GNSSConfig
from .messages import BaroMsg, GNSSMsg


class GNSS:
    def __init__(self, cfg: GNSSConfig, rng: np.random.Generator):
        self.cfg, self.rng = cfg, rng

    def measure(self, t: float, p: np.ndarray) -> GNSSMsg:
        return GNSSMsg(t, t + self.cfg.delay, p + np.array(self.cfg.noise_std) * self.rng.standard_normal(3))


class Barometer:
    def __init__(self, cfg: BaroConfig, rng: np.random.Generator):
        self.cfg, self.rng = cfg, rng

    def measure(self, t: float, p: np.ndarray) -> BaroMsg:
        return BaroMsg(t, t + self.cfg.delay, float(p[2] + self.cfg.noise_std * self.rng.standard_normal()))
