"""Closed-loop simulation: true world + vehicle + sensors <-> onboard autonomy.

Per physics step (default 400 Hz):
    1. dynamic obstacles move (20 Hz)
    2. sensors sample the TRUE state/environment at their own rates (with fault injection)
       and publish timestamped messages on the bus with their transport delay
    3. delivered messages go to the autonomy; at the control rate the autonomy runs the
       estimator (fusion horizon), mapping, planning and the LQR, and returns motor commands
    4. rigid-body dynamics integrate one step
Ground truth is used only here for evaluation metrics (`Telemetry`), never fed back.
"""

from __future__ import annotations

import time
from collections import defaultdict

import numpy as np

from ..autonomy import Autonomy
from ..config import LabConfig
from ..mapping.evaluation import MapEvaluator
from ..math3d import euler_zyx_from_quat, quat_to_rot, rot_log
from ..sensors.bus import SensorBus
from ..sensors.camera import Camera
from ..sensors.gnss import GNSS, Barometer
from ..sensors.imu import IMU
from ..sensors.lidar import Lidar
from ..vehicle.dynamics import QuadrotorDynamics
from ..world.environment import Environment
from .telemetry import Telemetry


def _in(windows, t) -> bool:
    return any(a <= t < b for a, b in windows)


class Simulator:
    def __init__(self, cfg: LabConfig):
        self.cfg = cfg
        m = cfg.mission
        rng = np.random.default_rng(cfg.sim.seed)
        self.rng = rng
        self.env = Environment(cfg.environment, start_xy=m.start[:2], goal_xy=m.goal[:2])
        from ..math3d import quat_from_euler_zyx
        self.dyn = QuadrotorDynamics(cfg.uav, cfg.disturbance, rng, p0=m.start, q0=quat_from_euler_zyx(0, 0, m.start_yaw))
        s = cfg.sensors
        self.imu = IMU(s.imu, rng)
        self.lidar = Lidar(s.lidar, rng)
        self.camera = Camera(s.camera, rng, [l.marker_id for l in self.env.landmarks if l.known])
        self.gnss = GNSS(s.gnss, rng)
        self.baro = Barometer(s.baro, rng)
        self.bus = SensorBus()
        self.autonomy = Autonomy(cfg, self.env.known_database())
        self.h = 1.0 / cfg.sim.physics_rate_hz
        self.t = 0.0
        self.k = 0
        self._next = defaultdict(float)
        self.f_cmd = np.full(4, cfg.uav.min_motor_thrust)
        self.crashed = False
        self.crash_info: dict | None = None
        self.finished = False
        self.telemetry = Telemetry()
        self._cam_pending: list = []
        self.lm_votes: dict[int, dict[int, int]] = defaultdict(lambda: defaultdict(int))
        self.false_associations = 0
        self.true_associations = 0
        self.last_camera_msg = None
        self.last_lidar_world = np.zeros((0, 3))
        self.true_traj: list[np.ndarray] = []
        self.est_traj: list[np.ndarray] = []
        gt, _ = self.env.occupancy_grid(cfg.mapping.voxel_size)
        zc = int(np.ceil((cfg.planner.max_altitude + 1.0 - cfg.environment.bounds_min[2]) / cfg.mapping.voxel_size))
        self.map_eval = MapEvaluator(gt, zc)
        self.map_metrics: dict = {}
        self.wall_time = 0.0
        self._apply_fault_multipliers(0.0)

    # ------------------------------------------------------------------ faults
    def _apply_fault_multipliers(self, t):
        f = self.cfg.faults
        w = f.imu_noise_window
        self.imu.noise_mult = f.imu_noise_multiplier if (w is None or w[0] <= t < w[1]) else 1.0
        self.lidar.noise_mult = f.lidar_noise_multiplier
        self.camera.noise_mult = f.camera_noise_multiplier

    def _due(self, name: str, rate: float) -> bool:
        if self.t + 1e-9 >= self._next[name]:
            self._next[name] += 1.0 / rate
            return True
        return False

    # ------------------------------------------------------------------ main loop
    def step(self) -> None:
        if self.finished:
            return
        cfg, t = self.cfg, self.t
        s = self.dyn.state
        if self._due("env", 20.0):
            self.env.update(t)
        self._apply_fault_multipliers(t)
        sc = cfg.sensors
        f = cfg.faults
        if self._due("imu", sc.imu.rate_hz):
            self.bus.publish(self.imu.measure(t, self.dyn.specific_force_b, s.w))
        if sc.lidar.enabled and self._due("lidar", sc.lidar.rate_hz) and not _in(f.lidar_blackout, t):
            msg = self.lidar.scan(t, self.env, s.p, s.q)
            self.bus.publish(msg)
        if sc.camera.enabled and self._due("camera", sc.camera.rate_hz) and not _in(f.camera_blackout, t):
            msg, truth = self.camera.capture(t, self.env, s.p, s.q)
            self.bus.publish(msg)
            self._cam_pending.append((msg, truth))
            self.last_camera_msg = msg
        if sc.gnss.enabled and self._due("gnss", sc.gnss.rate_hz) and not _in(f.gnss_outage, t):
            self.bus.publish(self.gnss.measure(t, s.p))
        if sc.baro.enabled and self._due("baro", sc.baro.rate_hz):
            self.bus.publish(self.baro.measure(t, s.p))
        self.autonomy.receive(self.bus.deliver(t))
        if self._due("control", cfg.sim.control_rate_hz):
            self.autonomy.update_estimation(t)
            self.f_cmd = self.autonomy.control(t, 1.0 / cfg.sim.control_rate_hz, self.dyn.thrust_limit())
            self._score_associations()
        self.dyn.step(self.f_cmd, self.h)
        self.t = self.dyn.t
        self.k += 1
        # crash detection (ground truth)
        if not self.dyn.on_ground:
            d = float(self.env.signed_distance(self.dyn.state.p[None])[0])
            if d < cfg.uav.collision_radius:
                self.crashed = True
                self.finished = True
                self.crash_info = {"t": self.t, "position": self.dyn.state.p.tolist(), "clearance": d}
                self.autonomy._log("crash", f"COLLISION at t={self.t:.2f} s, clearance {d:.2f} m")
        if self._due("telemetry", cfg.sim.telemetry_rate_hz):
            self._record()
        if self._due("mapeval", 0.5):
            self.map_metrics = self.map_eval.evaluate(self.autonomy.map)
        if self.t >= cfg.mission.duration or self.dyn.soc <= 0 or (self.autonomy.state in ("DONE", "LANDED") and self.t > 3):
            self.finished = True

    def run(self, until: float | None = None, wall_limit: float | None = None, stop_on_arrival: bool = True) -> "Simulator":
        until = self.cfg.mission.duration if until is None else until
        w0 = time.perf_counter()
        while not self.finished and self.t < until:
            self.step()
            if stop_on_arrival and self.autonomy.state == "ARRIVED":
                # hover 2 s at the goal for settling metrics, then stop
                if not hasattr(self, "_arrived_t"):
                    self._arrived_t = self.t
                elif self.t - self._arrived_t > 2.0:
                    self.finished = True
            if wall_limit and time.perf_counter() - w0 > wall_limit:
                break
        self.wall_time += time.perf_counter() - w0
        self.map_metrics = self.map_eval.evaluate(self.autonomy.map)
        return self

    # ------------------------------------------------------------------ evaluation
    def _score_associations(self):
        """Compare the estimator's association decisions with the hidden truth (evaluation only)."""
        tf = self.autonomy.est.t_filter
        keep = []
        for msg, truth in self._cam_pending:
            if msg.t > tf:
                keep.append((msg, truth))
                continue
            for f, tid in zip(msg.features, truth):
                if f.track_id >= 0:
                    self.lm_votes[f.track_id][tid] += 1
        self._cam_pending = keep

    def landmark_truth_map(self) -> dict[int, int]:
        """map_id -> true landmark id by majority vote of the associations (-1 = clutter)."""
        out = {}
        for mid, votes in self.lm_votes.items():
            out[mid] = max(votes.items(), key=lambda kv: kv[1])[0]
        return out

    def landmark_errors(self) -> dict:
        slam = self.autonomy.est.slam
        tm = self.landmark_truth_map()
        errs, false_lm = [], 0
        correct_assoc, wrong_assoc = 0, 0
        per = []
        for j, rec in enumerate(slam.lms):
            tid = tm.get(rec.map_id)
            if rec.known and rec.marker_id is not None:
                tid = next((l.true_id for l in self.env.landmarks if l.marker_id == rec.marker_id), tid)
            votes = self.lm_votes.get(rec.map_id, {})
            if tid is None:
                continue
            if tid < 0:
                false_lm += 1
                continue
            for k, v in votes.items():
                if k == tid:
                    correct_assoc += v
                else:
                    wrong_assoc += v
            e = float(np.linalg.norm(slam.L[j] - self.env.landmarks[tid].position))
            errs.append(e)
            per.append({"id": rec.map_id, "true_id": tid, "error": e, "sigma": float(np.sqrt(np.trace(slam.landmark_cov(j))))})
        return {"mean_error": float(np.mean(errs)) if errs else float("nan"),
                "max_error": float(np.max(errs)) if errs else float("nan"),
                "n_evaluated": len(errs), "false_landmarks": false_lm,
                "association_precision": correct_assoc / max(correct_assoc + wrong_assoc, 1),
                "wrong_associations": wrong_assoc, "per_landmark": per}

    def _record(self):
        a = self.autonomy
        s = self.dyn.state
        est = a.est.current(self.t)
        slam = a.est.slam
        Rt, Re = quat_to_rot(s.q), quat_to_rot(est.q)
        att_err = float(np.degrees(np.linalg.norm(rot_log(Re.T @ Rt))))
        ref = a.ref
        pe = s.p - est.p
        Ppos = slam.P[0:3, 0:3]
        try:
            nees = float(pe @ np.linalg.solve(Ppos, pe))
        except np.linalg.LinAlgError:
            nees = float("nan")
        out = a.last_out
        lm_known = sum(1 for r in slam.lms if r.known)
        nis = slam.nis_log[-1][1] / max(slam.nis_log[-1][2], 1) if slam.nis_log else float("nan")
        innov = slam.innovations[-1][1] if slam.innovations else float("nan")
        self.true_traj.append(s.p.copy())
        self.est_traj.append(est.p.copy())
        lme = self._lm_err_fast()
        self.telemetry.append(
            t=self.t,
            p_true=s.p.copy(), p_est=est.p.copy(), v_true=s.v.copy(), v_est=est.v.copy(),
            euler_true=np.degrees(euler_zyx_from_quat(s.q)), euler_est=np.degrees(euler_zyx_from_quat(est.q)),
            pos_err=float(np.linalg.norm(pe)), vel_err=float(np.linalg.norm(s.v - est.v)), att_err=att_err,
            sigma_pos=np.sqrt(np.diag(Ppos)), sigma_vel=np.sqrt(np.diag(slam.P[3:6, 3:6])),
            sigma_att=np.degrees(np.sqrt(np.diag(slam.P[6:9, 6:9]))), trace_pos=float(np.trace(Ppos)),
            nees_pos=nees, nis=nis, innovation=innov,
            ba_err=float(np.linalg.norm(slam.ba - self.imu.ba)), bg_err=float(np.linalg.norm(slam.bg - self.imu.bg)),
            n_landmarks=slam.n, n_known=lm_known, n_new=slam.n - lm_known, lm_err=lme,
            p_ref=np.asarray(ref["pos"]).copy(), v_ref=np.asarray(ref["vel"]).copy(), a_ref=np.asarray(ref["acc"]).copy(),
            j_ref=np.asarray(ref["jerk"]).copy(),
            track_err=float(np.linalg.norm(s.p - ref["pos"])), track_err_est=float(np.linalg.norm(est.p - ref["pos"])),
            vel_track_err=float(np.linalg.norm(s.v - ref["vel"])),
            att_track_err=float(np.degrees(np.linalg.norm(out.error[6:9]))) if out is not None else 0.0,
            speed=float(np.linalg.norm(s.v)), accel=float(np.linalg.norm(s.a)),
            thrust=float(out.T) if out else 0.0, torque=(out.M.copy() if out else np.zeros(3)),
            motors=self.dyn.state.f.copy(), saturated=bool(out.saturated) if out else False,
            soc=self.dyn.soc, power=float(getattr(self.dyn, "power_w", 0.0)),
            coverage=float(self.map_metrics.get("coverage", 0.0)), map_iou=float(self.map_metrics.get("iou", 0.0)),
            map_precision=float(self.map_metrics.get("precision", 0.0)),
            state=a.state, features=a.est.stats.get("features", 0), matched=a.est.stats.get("matched", 0),
            wind=self.dyn.wind().copy(),
        )

    def _lm_err_fast(self) -> float:
        slam = self.autonomy.est.slam
        if slam.n == 0 or not self.lm_votes:
            return float("nan")
        errs = []
        for j, rec in enumerate(slam.lms):
            votes = self.lm_votes.get(rec.map_id)
            if votes:
                tid = max(votes.items(), key=lambda kv: kv[1])[0]
                if tid >= 0:
                    errs.append(np.linalg.norm(slam.L[j] - self.env.landmarks[tid].position))
        return float(np.mean(errs)) if errs else float("nan")

    # ------------------------------------------------------------------ summary
    def summary(self) -> dict:
        tel = self.telemetry
        a = self.autonomy
        res = {"t_end": self.t, "state": a.state, "crashed": self.crashed, "crash": self.crash_info,
               "realtime_factor": self.t / max(self.wall_time, 1e-9)}
        if len(tel):
            pe = np.array(tel["pos_err"])
            res.update(
                pos_rmse=float(np.sqrt(np.mean(pe**2))), pos_err_final=float(pe[-1]), pos_err_max=float(pe.max()),
                vel_rmse=float(np.sqrt(np.mean(np.array(tel["vel_err"]) ** 2))),
                att_rmse_deg=float(np.sqrt(np.mean(np.array(tel["att_err"]) ** 2))),
                track_rmse=float(np.sqrt(np.mean(np.array(tel["track_err"]) ** 2))),
                track_max=float(np.max(tel["track_err"])),
                nees_pos_mean=float(np.nanmean(tel["nees_pos"])),
                three_sigma_fraction=float(np.mean(np.all(np.abs(np.array(tel["p_true"]) - np.array(tel["p_est"])) <= 3 * np.array(tel["sigma_pos"]), axis=1))),
                saturation_fraction=float(np.mean(tel["saturated"])),
                energy_used_wh=self.dyn.energy_used_j / 3600.0,
                control_effort=float(np.mean(np.sum((np.array(tel["motors"]) - self.cfg.uav.mass * 9.81 / 4) ** 2, axis=1))),
            )
        lm = self.landmark_errors()
        res["landmarks"] = {k: v for k, v in lm.items() if k != "per_landmark"}
        res["n_landmarks"] = a.est.slam.n
        res["n_known_in_map"] = sum(1 for r in a.est.slam.lms if r.known)
        res["n_new_in_map"] = a.est.slam.n - res["n_known_in_map"]
        res["known_observed"] = sum(1 for r in a.est.slam.lms if r.known and r.n_obs > 0)
        res["map"] = {k: v for k, v in self.map_metrics.items()}
        res["goal_error_true"] = float(np.linalg.norm(self.dyn.state.p - a.nav_goal))
        res["replans"] = a.replans
        res["outliers_rejected"] = a.est.slam.rejected_outliers
        res["filter_health"] = a.est.slam.consistency_check()
        res["landmark_manager"] = {"promoted": a.est.lm.promoted, "expired_candidates": a.est.lm.expired}
        res["events"] = [(e.t, e.kind, e.text) for e in a.events[-30:]]
        return res
