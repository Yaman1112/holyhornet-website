"""Columnar time-series store for simulation telemetry."""

from __future__ import annotations

from collections import defaultdict

import numpy as np


class Telemetry:
    def __init__(self):
        self.cols: dict[str, list] = defaultdict(list)
        self.n = 0

    def append(self, **kw) -> None:
        for k, v in kw.items():
            self.cols[k].append(v)
        self.n += 1

    def __len__(self) -> int:
        return self.n

    def __getitem__(self, k):
        return self.cols[k]

    def row(self, i: int = -1) -> dict:
        return {k: _js(v[i]) for k, v in self.cols.items()}

    def since(self, i0: int) -> dict:
        return {k: [_js(x) for x in v[i0:]] for k, v in self.cols.items()}


def _js(v):
    if isinstance(v, np.ndarray):
        return np.round(v.astype(float), 5).tolist()
    if isinstance(v, (np.floating, float)):
        f = float(v)
        return None if not np.isfinite(f) else round(f, 6)
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    return v
