"""FastAPI service for the Autonomous UAV Lab.

    uvicorn uav_lab.server.app:app --port 8100

REST under /lab, live stream over WebSocket /lab/sessions/{id}/stream. `router` can be mounted
into another FastAPI app (e.g. the UAV Swarm Intelligence service).
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import numpy as np
from fastapi import APIRouter, FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from ..config import LabConfig, LQRConfig, TrajectoryConfig, UAVConfig, merge
from ..control.lqr import LQRController, hover_reference, lqr_gain
from ..math3d import GRAVITY
from ..scenarios import list_scenarios, scenario_config
from ..trajectory import minsnap
from ..trajectory.flatness import feasibility, flat_to_state
from ..vehicle.airframe import Airframe, component_model
from ..vehicle.dynamics import QuadrotorDynamics
from .session import SessionManager
from . import tools
from .storage import list_maps

router = APIRouter(prefix="/lab")
manager = SessionManager()
REPORT_DIR = Path(__file__).resolve().parents[3] / "docs" / "uav_lab" / "reports"


class CreateSession(BaseModel):
    scenario: str | None = None
    config: dict | None = None
    autostart: bool = False


@router.get("/health")
def health():
    return {"ok": True, "sessions": len(manager.sessions)}


@router.get("/config/default")
def default_config():
    return LabConfig().model_dump()


@router.get("/config/schema")
def config_schema():
    return LabConfig.model_json_schema()


@router.get("/scenarios")
def scenarios():
    return list_scenarios()


@router.get("/scenarios/{name}/config")
def scenario_cfg(name: str):
    try:
        return scenario_config(name).model_dump()
    except KeyError:
        raise HTTPException(404, f"unknown scenario {name}")


@router.post("/sessions")
def create_session(req: CreateSession):
    try:
        base = scenario_config(req.scenario) if req.scenario else LabConfig()
        cfg = merge(base, req.config or {})
    except KeyError:
        raise HTTPException(404, f"unknown scenario {req.scenario}")
    except Exception as e:  # validation error
        raise HTTPException(422, str(e))
    s = manager.create(cfg, req.scenario)
    if req.autostart:
        s.command({"cmd": "start"})
    return {"id": s.id, "scene": s.static_scene()}


@router.get("/sessions/{sid}")
def get_session(sid: str):
    s = _get(sid)
    return {"id": s.id, "t": s.sim.t, "running": s.running, "state": s.sim.autonomy.state, "scene": s.static_scene()}


@router.delete("/sessions/{sid}")
def delete_session(sid: str):
    manager.delete(sid)
    return {"ok": True}


@router.post("/sessions/{sid}/command")
def command(sid: str, cmd: dict):
    s = _get(sid)
    try:
        return s.command(cmd)
    except Exception as e:
        raise HTTPException(400, str(e))


@router.get("/sessions/{sid}/telemetry")
def telemetry(sid: str):
    s = _get(sid)
    with s.lock:
        return s.sim.telemetry.since(0)


@router.get("/sessions/{sid}/summary")
def summary(sid: str):
    s = _get(sid)
    with s.lock:
        out = s.sim.summary()
        out["landmarks_detail"] = s.sim.landmark_errors()["per_landmark"]
        return json.loads(json.dumps(out, default=_np))


@router.get("/maps")
def maps():
    return list_maps()


@router.websocket("/sessions/{sid}/stream")
async def stream(ws: WebSocket, sid: str):
    await ws.accept()
    if sid not in manager.sessions:
        await ws.close(code=4404)
        return
    s = manager.get(sid)
    last = 0

    async def reader():
        while True:
            msg = await ws.receive_text()
            try:
                res = await asyncio.to_thread(s.command, json.loads(msg))
                await ws.send_text(json.dumps({"type": "ack", "result": res}, default=_np))
            except Exception as e:  # report to the client, keep the stream alive
                await ws.send_text(json.dumps({"type": "error", "error": str(e)}))

    rt = asyncio.create_task(reader())
    try:
        while True:
            f = s.frame
            if f is not None and f["seq"] != last:
                if f["seq"] != last + 1 and last != 0:
                    # frames are incremental (points, telemetry); the client re-fetches on gaps
                    f = dict(f, gap=True)
                last = f["seq"]
                await ws.send_text(json.dumps({"type": "frame", "frame": f}, default=_np))
            if rt.done():
                break
            await asyncio.sleep(0.02)
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        rt.cancel()


# ------------------------------------------------------------------ laboratories (no full simulation needed)
class TrajRequest(BaseModel):
    trajectory: dict | None = None
    uav: dict | None = None
    lqr: dict | None = None
    simulate: bool = True
    disturbance: dict | None = None


@router.post("/tools/trajectory")
def trajectory_lab(req: TrajRequest):
    """Min-snap through waypoints + flatness map + (optional) closed-loop LQR tracking on true dynamics."""
    try:
        return tools.trajectory_lab(req.model_dump())
    except ValueError as e:
        raise HTTPException(422, str(e))


@router.post("/tools/lqr")
def lqr_lab(req: TrajRequest):
    """LQR gains, closed-loop poles and the hover step response on the nonlinear dynamics."""
    return tools.lqr_lab(req.model_dump())


@router.get("/uav/model")
def uav_model():
    cfg = LabConfig()
    return component_model(cfg.uav, cfg.sensors.camera, cfg.sensors.lidar)


@router.post("/uav/model")
def uav_model_cfg(patch: dict):
    cfg = merge(LabConfig(), patch)
    return component_model(cfg.uav, cfg.sensors.camera, cfg.sensors.lidar)


@router.get("/experiments")
def experiments():
    out = {}
    if REPORT_DIR.exists():
        for f in sorted(REPORT_DIR.glob("*.json")):
            out[f.stem] = json.loads(f.read_text())
    md = (REPORT_DIR / "REPORT.md").read_text(encoding="utf-8") if (REPORT_DIR / "REPORT.md").exists() else ""
    return {"results": out, "report_md": md, "scenarios": list_scenarios()}


def _get(sid):
    if sid not in manager.sessions:
        raise HTTPException(404, "session not found")
    return manager.get(sid)


def _np(o):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, float) and not np.isfinite(o):
        return None
    return str(o)


app = FastAPI(title="Autonomous UAV Lab", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.include_router(router)
