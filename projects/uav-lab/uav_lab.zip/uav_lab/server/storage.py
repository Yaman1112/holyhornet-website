"""Map persistence for the server (occupancy grid + point cloud + landmark map)."""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np

from ..mapping.occupancy import OccupancyMap

MAP_DIR = Path(__file__).resolve().parents[3] / "data" / "uav_lab_maps"


def _safe(name: str) -> str:
    n = re.sub(r"[^A-Za-z0-9_-]", "_", name)[:60]
    return n or "map"


def save_map(autonomy, name: str) -> str:
    MAP_DIR.mkdir(parents=True, exist_ok=True)
    n = _safe(name)
    autonomy.map.save(MAP_DIR / n, autonomy.landmarks_view())
    return n


def list_maps() -> list[str]:
    if not MAP_DIR.exists():
        return []
    return sorted(p.stem for p in MAP_DIR.glob("*.json"))


def load_map(autonomy, name: str) -> None:
    """Replace the vehicle's occupancy map with a saved one (a prior map; landmarks are informational)."""
    m, _ = OccupancyMap.load(MAP_DIR / _safe(name))
    if m.shape != autonomy.map.shape or not np.allclose(m.origin, autonomy.map.origin):
        raise ValueError("saved map has different bounds/resolution")
    autonomy.map = m
