"""Laboratory computations shared by the FastAPI service and the in-browser (Pyodide) engine.

No web framework imports here, so this module runs unchanged inside WebAssembly.
"""

from __future__ import annotations

import json

import numpy as np

from ..config import LabConfig, LQRConfig, TrajectoryConfig, UAVConfig, merge
from ..control.lqr import LQRController, hover_reference, lqr_gain
from ..math3d import GRAVITY
from ..scenarios import list_scenarios, scenario_config
from ..trajectory import minsnap
from ..trajectory.flatness import feasibility, flat_to_state
from ..vehicle.airframe import Airframe, component_model
from ..vehicle.dynamics import QuadrotorDynamics


def _np(o):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, float) and not np.isfinite(o):
        return None
    return str(o)


def default_config() -> dict:
    return LabConfig().model_dump()


def scenarios() -> list:
    return list_scenarios()


def scenario_cfg(name: str) -> dict:
    return scenario_config(name).model_dump()


def uav_model(patch: dict | None = None) -> dict:
    cfg = merge(LabConfig(), patch or {})
    return component_model(cfg.uav, cfg.sensors.camera, cfg.sensors.lidar)


def trajectory_lab(req: dict) -> dict:
    """Min-snap through waypoints + flatness map + (optional) closed-loop LQR tracking on true dynamics."""
    tc = TrajectoryConfig.model_validate({**TrajectoryConfig().model_dump(), **(req.get("trajectory") or {})})
    uav = UAVConfig.model_validate({**UAVConfig().model_dump(), **(req.get("uav") or {})})
    lq = LQRConfig.model_validate({**LQRConfig().model_dump(), **(req.get("lqr") or {})})
    pts = np.array(tc.waypoints, float)
    if len(pts) < 2:
        raise ValueError("need at least two waypoints")
    tr = minsnap.generate(pts, tc, uav.mass, uav.max_motor_thrust, min(uav.max_tilt_deg, lq.max_tilt_command_deg))
    af = Airframe(uav)
    J = af.J
    dt = 0.02
    smp = tr.sample(dt)
    rows = {"t": smp["t"].tolist(), "pos": smp["pos"].tolist(), "vel": smp["vel"].tolist(), "acc": smp["acc"].tolist(),
            "jerk": smp["jerk"].tolist(), "snap": smp["snap"].tolist(), "yaw": smp["yaw"].tolist(),
            "thrust": [], "tilt_deg": [], "omega": [], "alpha": [], "torque": [], "motors": [], "euler_deg": []}
    for t in smp["t"]:
        r = tr.eval(t)
        fs = flat_to_state(r["acc"], r["jerk"], r["snap"], r["yaw"], r["yaw_rate"], r["yaw_acc"], uav.mass, J)
        rows["thrust"].append(fs.T)
        rows["tilt_deg"].append(float(np.degrees(np.arccos(np.clip(fs.R[2, 2], -1, 1)))))
        rows["omega"].append(fs.omega.tolist())
        rows["alpha"].append(fs.alpha.tolist())
        rows["torque"].append(fs.M.tolist())
        rows["motors"].append((af.A_inv @ np.r_[fs.T, fs.M]).tolist())
        R = fs.R
        rows["euler_deg"].append(np.degrees([np.arctan2(R[2, 1], R[2, 2]), -np.arcsin(np.clip(R[2, 0], -1, 1)), np.arctan2(R[1, 0], R[0, 0])]).tolist())
    feas = feasibility(tr, uav.mass, J, af, uav.max_tilt_deg)
    out = {"report": tr.report, "feasibility": feas, "segments": tr.T.tolist(), "waypoints": tr.waypoints.tolist(), "reference": rows}
    if req.get("simulate", True):
        from ..config import DisturbanceConfig
        dist = DisturbanceConfig.model_validate({**DisturbanceConfig().model_dump(), **(req.get("disturbance") or {})})
        dyn = QuadrotorDynamics(uav, dist, np.random.default_rng(0), p0=tuple(pts[0]))
        dyn.state.f[:] = uav.mass * GRAVITY / 4
        from ..math3d import quat_from_euler_zyx
        dyn.state.q = quat_from_euler_zyx(0, 0, float(tr.waypoints[0, 3]))
        ctrl = LQRController(uav, lq)
        h, cdt = 0.0025, 0.01
        sim = {"t": [], "pos": [], "err": [], "vel_err": [], "att_err_deg": [], "thrust": [], "torque": [], "motors": [], "saturated": []}
        out_c = None
        T_total = tr.duration + 2.0
        for k in range(int(T_total / h)):
            t = k * h
            if k % int(cdt / h) == 0:
                st = dyn.state
                ref = tr.eval(t)
                out_c = ctrl.compute(st.p, st.v, st.q, st.w, ref, cdt)
                if k % int(0.02 / h) == 0:
                    sim["t"].append(t)
                    sim["pos"].append(st.p.tolist())
                    sim["err"].append(float(np.linalg.norm(st.p - ref["pos"])))
                    sim["vel_err"].append(float(np.linalg.norm(st.v - ref["vel"])))
                    sim["att_err_deg"].append(float(np.degrees(np.linalg.norm(out_c.error[6:9]))))
                    sim["thrust"].append(out_c.T)
                    sim["torque"].append(out_c.M.tolist())
                    sim["motors"].append(st.f.tolist())
                    sim["saturated"].append(bool(out_c.saturated))
            dyn.step(out_c.f, h)
        e = np.array(sim["err"])
        settle = None
        above = np.nonzero(e > 0.1)[0]
        settle = float(sim["t"][above[-1]] - tr.duration) if len(above) and sim["t"][above[-1]] > tr.duration else 0.0
        sim["metrics"] = {"rmse": float(np.sqrt(np.mean(e**2))), "max": float(e.max()), "final": float(e[-1]),
                          "vel_rmse": float(np.sqrt(np.mean(np.array(sim["vel_err"]) ** 2))),
                          "att_rmse_deg": float(np.sqrt(np.mean(np.array(sim["att_err_deg"]) ** 2))),
                          "control_effort": float(np.mean(np.sum((np.array(sim["motors"]) - uav.mass * GRAVITY / 4) ** 2, axis=1))),
                          "settling_after_end_s": settle, "saturation_fraction": float(np.mean(sim["saturated"]))}
        out["closed_loop"] = sim
    return json.loads(json.dumps(out, default=_np))


def lqr_lab(req: dict) -> dict:
    """LQR gains, closed-loop poles and the hover step response (1 m in x, y and z, true nonlinear dynamics)."""
    uav = UAVConfig.model_validate({**UAVConfig().model_dump(), **(req.get("uav") or {})})
    lq = LQRConfig.model_validate({**LQRConfig().model_dump(), **(req.get("lqr") or {})})
    K, P, A, B = lqr_gain(lq, uav.mass, np.diag(uav.inertia))
    poles = np.linalg.eigvals(A - B @ K)
    from ..config import DisturbanceConfig
    dyn = QuadrotorDynamics(uav, DisturbanceConfig.model_validate(req.get("disturbance") or {}), np.random.default_rng(0), p0=(0, 0, 2))
    dyn.state.f[:] = uav.mass * GRAVITY / 4
    ctrl = LQRController(uav, lq)
    ref = hover_reference([1.0, 1.0, 3.0])
    h = 0.0025
    resp = {"t": [], "pos": [], "motors": [], "euler_deg": []}
    from ..math3d import euler_zyx_from_quat
    out_c = None
    for k in range(int(6.0 / h)):
        if k % 4 == 0:
            st = dyn.state
            out_c = ctrl.compute(st.p, st.v, st.q, st.w, ref, 0.01)
            if k % 8 == 0:
                resp["t"].append(k * h)
                resp["pos"].append(st.p.tolist())
                resp["motors"].append(st.f.tolist())
                resp["euler_deg"].append(np.degrees(euler_zyx_from_quat(st.q)).tolist())
        dyn.step(out_c.f, h)
    pos = np.array(resp["pos"])
    err = np.linalg.norm(pos - ref["pos"], axis=1)
    above = np.nonzero(err > 0.05 * np.sqrt(3))[0]
    settle = float(resp["t"][above[-1]]) if len(above) else 0.0
    over = float(max(0.0, (pos[:, 2].max() - 3.0)))
    return {"K": K.round(5).tolist(), "P_diag": np.diag(P).round(5).tolist(), "A": A.tolist(), "B": B.round(5).tolist(),
            "poles": [[float(p.real), float(p.imag)] for p in poles], "stable": bool(np.all(poles.real < 0)),
            "state_labels": ["ex", "ey", "ez", "evx", "evy", "evz", "eroll", "epitch", "eyaw", "ep", "eq", "er"],
            "input_labels": ["dT", "Mx", "My", "Mz"],
            "step_response": resp, "metrics": {"settling_time_5pct_s": settle, "z_overshoot_m": over, "final_error_m": float(err[-1])}}
