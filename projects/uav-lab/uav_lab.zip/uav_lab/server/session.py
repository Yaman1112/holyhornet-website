"""A live simulation session: runs the closed loop in a worker thread and produces display frames.

Frames separate the vehicle's own belief (estimate, map, landmarks, plan) from ground truth
(true pose, true environment), which is sent for visual comparison and evaluation only.
"""

from __future__ import annotations

import base64
import threading
import time
import uuid

import numpy as np

from ..config import LabConfig, merge
from ..math3d import quat_to_rot
from ..sim.simulator import Simulator
from ..sim.telemetry import _js
from ..vehicle.airframe import component_model

FRAME_DT = 0.1  # sim seconds between frames


def _r(a, d=3):
    return np.round(np.asarray(a, float), d).tolist()


class Session:
    def __init__(self, cfg: LabConfig, scenario: str | None = None, threaded: bool = True):
        self.id = uuid.uuid4().hex[:10]
        self.cfg = cfg
        self.scenario = scenario
        self.lock = threading.RLock()
        self.speed = 1.0
        self.running = False
        self.alive = True
        self.frame_seq = 0
        self.frame: dict | None = None
        self._reset_sim()
        # threaded: the server runs the loop itself; unthreaded: the caller (e.g. the in-browser
        # Pyodide worker) calls advance() at its own pace
        self.thread = None
        if threaded:
            self.thread = threading.Thread(target=self._loop, daemon=True)
            self.thread.start()

    def _reset_sim(self):
        self.sim = Simulator(self.cfg)
        self._tel_sent = 0
        self._lm_t = -1.0
        self._vox_t = -10.0
        self._traj_id = None
        self._ev_sent = 0
        self._img_sent = None
        self._first = True
        self._make_frame()

    # ------------------------------------------------------------------ control
    def command(self, cmd: dict) -> dict:
        c = cmd.get("cmd")
        with self.lock:
            if c == "start":
                self.running = True
            elif c == "pause":
                self.running = False
            elif c == "reset":
                self.running = False
                if "config" in cmd:
                    self.cfg = merge(self.cfg, cmd["config"])
                self._reset_sim()
            elif c == "speed":
                self.speed = float(np.clip(cmd.get("value", 1.0), 0.1, 20.0))
            elif c == "step":
                self._advance(float(cmd.get("seconds", FRAME_DT)))
            elif c == "goal":
                self.sim.autonomy.set_goal(np.array(cmd["goal"], float), self.sim.t)
            elif c == "mode":
                self.sim.autonomy.set_mode(cmd["mode"], self.sim.t)
            elif c == "gains":
                # live LQR retuning
                from ..config import LQRConfig
                from ..control.lqr import LQRController
                lq = LQRConfig.model_validate({**self.cfg.lqr.model_dump(), **cmd.get("lqr", {})})
                self.cfg = self.cfg.model_copy(update={"lqr": lq})
                self.sim.autonomy.ctrl = LQRController(self.cfg.uav, lq)
            elif c == "save_map":
                from .storage import save_map
                return {"ok": True, "saved": save_map(self.sim.autonomy, cmd.get("name", "map"))}
            elif c == "load_map":
                from .storage import load_map
                load_map(self.sim.autonomy, cmd["name"])
                self._vox_t = -10.0
            else:
                return {"ok": False, "error": f"unknown command {c!r}"}
            return {"ok": True, "running": self.running, "t": self.sim.t}

    def close(self):
        self.alive = False

    # ------------------------------------------------------------------ worker
    def advance(self, seconds: float = FRAME_DT) -> dict:
        """Step the simulation (unthreaded use) and return the new display frame."""
        with self.lock:
            self._advance(seconds)
            return self.frame

    def _advance(self, seconds: float):
        t_end = self.sim.t + seconds
        while self.sim.t < t_end - 1e-9 and not self.sim.finished:
            self.sim.step()
        self._make_frame()

    def _loop(self):
        while self.alive:
            if not self.running or self.sim.finished:
                if self.sim.finished:
                    self.running = False
                time.sleep(0.05)
                continue
            w0 = time.perf_counter()
            with self.lock:
                self._advance(FRAME_DT)
            elapsed = time.perf_counter() - w0
            target = FRAME_DT / self.speed
            if elapsed < target:
                time.sleep(target - elapsed)

    # ------------------------------------------------------------------ frames
    def static_scene(self) -> dict:
        sim = self.sim
        cfg = self.cfg
        cc = cfg.sensors.camera
        return {
            "truth_environment": sim.env.describe(),
            "uav_model": component_model(cfg.uav, cc, cfg.sensors.lidar),
            "known_database": sim.env.known_database(),
            "camera": {"hfov_deg": cc.hfov_deg, "aspect": cc.width / cc.height, "max_depth": cc.max_depth,
                       "R_bc": sim.autonomy.cam.R_bc.tolist(), "t_bc": sim.autonomy.cam.t_bc.tolist(), "width": cc.width, "height": cc.height},
            "lidar": {"max_range": cfg.sensors.lidar.max_range, "vfov_deg": cfg.sensors.lidar.vertical_fov_deg},
            "map": {"origin": sim.autonomy.map.origin.tolist(), "res": sim.autonomy.map.res, "shape": list(sim.autonomy.map.shape)},
            "mission": cfg.mission.model_dump(),
            "config": cfg.model_dump(),
            "lqr": {"K": np.round(sim.autonomy.ctrl.K, 4).tolist(), "poles": [[float(p.real), float(p.imag)] for p in sim.autonomy.ctrl.closed_loop_poles]},
            "scenario": self.scenario,
        }

    def _make_frame(self):
        sim = self.sim
        a = sim.autonomy
        s = sim.dyn.state
        est = a.est.current(sim.t)
        slam = a.est.slam
        f: dict = {"seq": self.frame_seq + 1, "t": round(sim.t, 3), "state": a.state, "running": self.running,
                   "finished": sim.finished, "crashed": sim.crashed, "speed": self.speed}
        f["truth"] = {"p": _r(s.p), "q": _r(s.q, 5), "v": _r(s.v)}
        f["est"] = {"p": _r(est.p), "q": _r(est.q, 5), "v": _r(est.v), "cov_pos": _r(slam.P[0:3, 0:3], 5),
                    "ba": _r(slam.ba, 4), "bg": _r(slam.bg, 5), "sigma_att_deg": _r(np.degrees(np.sqrt(np.diag(slam.P[6:9, 6:9]))), 3)}
        ref = a.ref
        f["ref"] = {"p": _r(ref["pos"]), "v": _r(ref["vel"]), "a": _r(ref["acc"]), "j": _r(ref["jerk"]), "yaw": round(float(ref["yaw"]), 4)}
        f["motors"] = _r(s.f, 3)
        f["battery"] = round(sim.dyn.soc, 4)
        f["wind"] = _r(sim.dyn.wind(), 2)
        dyn_obs = [[i, _r(o.center, 2)] for i, o in enumerate(sim.env.obstacles) if o.dynamic]
        if dyn_obs:
            f["dynamic_obstacles"] = dyn_obs
        # telemetry rows since the last frame
        n = len(sim.telemetry)
        if n > self._tel_sent:
            f["telemetry"] = sim.telemetry.since(self._tel_sent)
            self._tel_sent = n
        # incremental point cloud and current scan
        pts = a.map.take_new_points()
        if len(pts):
            f["new_points"] = np.round(pts, 2).ravel().tolist()
        scan = a.last_scan_world
        if len(scan):
            idx = np.linspace(0, len(scan) - 1, min(len(scan), 700)).astype(int)
            f["scan"] = np.round(scan[idx], 2).ravel().tolist()
        # landmarks (estimated, with covariance) every 0.5 s
        if sim.t - self._lm_t >= 0.5 or self._first:
            self._lm_t = sim.t
            f["landmarks"] = a.landmarks_view()
            truth_map = sim.landmark_truth_map()
            f["landmark_truth"] = {str(k): v for k, v in truth_map.items()}
            f["candidates"] = len(a.est.lm.candidates)
        # occupied voxels every 1 s
        if sim.t - self._vox_t >= 1.0 or self._first:
            self._vox_t = sim.t
            occ = np.argwhere(a.map.L > a.map.cfg.occupied_threshold)
            f["voxels"] = occ.ravel().tolist()
            free = np.argwhere(a.map.L < a.map.cfg.free_threshold)
            if len(free) > 6000:
                free = free[np.linspace(0, len(free) - 1, 6000).astype(int)]
            f["free_voxels"] = free.ravel().tolist()
            f["map_counts"] = a.map.counts()
            f["map_metrics"] = {k: _js(v) for k, v in sim.map_metrics.items()}
            fp = a.frontier_points
            if len(fp) > 1500:
                fp = fp[np.linspace(0, len(fp) - 1, 1500).astype(int)]
            f["frontiers"] = np.round(fp, 2).ravel().tolist()
            f["frontier_goals"] = [{"goal": _r(c.goal), "gain": c.gain, "utility": round(c.utility, 2), "size": c.size} for c in a.frontier_goals[:30]]
            f["known_fraction"] = round(a.map_known_fraction(), 4)
        # trajectory when it changes
        tr = a.traj
        tid = None if tr is None else id(tr)
        if tid != self._traj_id or self._first:
            self._traj_id = tid
            if tr is None:
                f["trajectory"] = None
            else:
                smp = tr.sample(0.1)
                f["trajectory"] = {"t0": tr.t0, "duration": tr.duration, "pos": np.round(smp["pos"], 3).ravel().tolist(),
                                   "speed": np.round(np.linalg.norm(smp["vel"], axis=1), 3).tolist(),
                                   "waypoints": np.round(tr.waypoints[:, :3], 3).ravel().tolist(), "report": {k: _js(v) for k, v in tr.report.items()},
                                   "path": np.round(np.array(a.path), 3).ravel().tolist() if a.path else []}
        # camera
        cm = sim.last_camera_msg
        if cm is not None:
            f["features"] = [[round(float(ft.uv[0]), 1), round(float(ft.uv[1]), 1), int(ft.track_id),
                              None if ft.depth is None else round(ft.depth, 2), ft.marker_id] for ft in cm.features]
            if cm.image is not None and cm.image is not self._img_sent:
                self._img_sent = cm.image
                f["image"] = {"w": cm.image.shape[1], "h": cm.image.shape[0], "rgb": base64.b64encode(cm.image.tobytes()).decode()}
                d = cm.depth_image
                dn = np.nan_to_num(np.clip(d / self.cfg.sensors.camera.max_depth, 0, 1), nan=1.0)
                f["depth_image"] = base64.b64encode((dn * 255).astype(np.uint8).tobytes()).decode()
        f["ekf"] = dict(a.est.stats)
        f["ekf"]["n_landmarks"] = slam.n
        f["ekf"]["outliers"] = slam.rejected_outliers
        f["ekf"]["state_dim"] = int(slam.P.shape[0])
        f["planner"] = {k: _js(v) for k, v in a.planner_stats.items()}
        f["goal"] = _r(a.nav_goal)
        f["control"] = None if a.last_out is None else {"T": round(a.last_out.T, 3), "M": _r(a.last_out.M, 4), "T_ff": round(a.last_out.T_ff, 3),
                                                         "error": _r(a.last_out.error, 4), "saturated": a.last_out.saturated}
        if len(a.events) > self._ev_sent or self._first:
            f["events"] = [[round(e.t, 2), e.kind, e.text] for e in a.events[self._ev_sent:]]
            self._ev_sent = len(a.events)
        if sim.finished:
            summ = sim.summary()
            summ.pop("events", None)
            f["summary"] = summ
        self._first = False
        self.frame_seq += 1
        self.frame = f


class SessionManager:
    def __init__(self, max_sessions: int = 8):
        self.sessions: dict[str, Session] = {}
        self.max = max_sessions

    def create(self, cfg: LabConfig, scenario=None) -> Session:
        if len(self.sessions) >= self.max:
            oldest = next(iter(self.sessions))
            self.sessions.pop(oldest).close()
        s = Session(cfg, scenario)
        self.sessions[s.id] = s
        return s

    def get(self, sid: str) -> Session:
        return self.sessions[sid]

    def delete(self, sid: str):
        s = self.sessions.pop(sid, None)
        if s:
            s.close()
