"""Sensor models with noise, bias and injectable faults, plus a health monitor.

The noise figures are representative of hobby/research-grade parts (u-blox M8/M9-class GNSS,
MS5611/BMP388-class barometer, MS4525-class differential pressure pitot, MEMS IMU + AHRS). They are
**assumptions** for simulation, not datasheet guarantees — see docs/ELECTRONICS.md.

The AHRS attitude is modelled as truth + noise (the attitude filter itself is not simulated);
this is a documented simplification.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from pydantic import BaseModel, Field

from ..aircraft.model import G
from ..frames import euler_from_quat, quat_to_dcm


class SensorConfig(BaseModel):
    gnss_rate_hz: float = 5.0
    gnss_pos_sigma_m: float = 1.2
    gnss_alt_sigma_m: float = 2.5
    gnss_vel_sigma_ms: float = 0.08
    baro_sigma_m: float = 0.25
    baro_drift_m_per_s: float = 0.002
    airspeed_sigma_ms: float = 0.25
    airspeed_scale_error: float = 0.02
    attitude_sigma_deg: float = 0.4
    heading_sigma_deg: float = 1.5
    gyro_sigma_rad_s: float = 0.004
    accel_sigma_ms2: float = 0.08


class FaultEvent(BaseModel):
    kind: str = Field(description="baro_failure | gnss_degradation | gnss_loss | airspeed_failure | imu_bias | comm_loss | wind_uncertainty")
    start_s: float
    end_s: float = 1e9
    severity: float = 1.0


@dataclass
class Measurements:
    t: float
    gnss_valid: bool
    gnss_pos: tuple  # n, e, alt
    gnss_vel: tuple  # vn, ve, vd
    baro_alt: float | None
    airspeed: float | None
    roll: float
    pitch: float
    yaw: float
    gyro: tuple
    accel: tuple
    link_ok: bool
    gnss_new: bool = False


@dataclass
class SensorHealth:
    baro_ok: bool = True
    gnss_ok: bool = True
    airspeed_ok: bool = True
    imu_ok: bool = True
    link_ok: bool = True
    messages: list = field(default_factory=list)

    def as_dict(self):
        return {"baro": self.baro_ok, "gnss": self.gnss_ok, "airspeed": self.airspeed_ok, "imu": self.imu_ok, "link": self.link_ok}


class SensorSuite:
    def __init__(self, cfg: SensorConfig, faults: list[FaultEvent], seed: int):
        self.cfg = cfg
        self.faults = faults
        self.rng = random.Random(seed * 104729 + 3)
        self.baro_bias = 0.0
        self.gnss_bias = [0.0, 0.0, 0.0]
        self._last_gnss_t = -1e9
        self._gnss_hold: tuple | None = None
        self._baro_frozen: float | None = None
        self._pitot_blocked: float | None = None
        self.airspeed_scale = 1.0 + cfg.airspeed_scale_error * (2 * self.rng.random() - 1)
        self.att_err = [0.0, 0.0, 0.0]  # AHRS output errors are filtered, i.e. time-correlated

    def active(self, kind: str, t: float) -> FaultEvent | None:
        for f in self.faults:
            if f.kind == kind and f.start_s <= t < f.end_s:
                return f
        return None

    def measure(self, t: float, dt: float, x, aux) -> Measurements:
        c, g = self.cfg, self.rng.gauss
        pn, pe, pd = x[0], x[1], x[2]
        h = -pd
        r = quat_to_dcm(tuple(x[6:10]))
        u, v, w = x[3], x[4], x[5]
        vn = r[0][0] * u + r[0][1] * v + r[0][2] * w
        ve = r[1][0] * u + r[1][1] * v + r[1][2] * w
        vd = r[2][0] * u + r[2][1] * v + r[2][2] * w
        # ---- GNSS
        gnss_new = False
        degr = self.active("gnss_degradation", t)
        lost = self.active("gnss_loss", t)
        k = 1.0 + (9.0 * degr.severity if degr else 0.0)
        for i in range(3):
            self.gnss_bias[i] += g(0, 0.02 * k) * math.sqrt(dt)
            self.gnss_bias[i] *= 0.999
        valid = lost is None and not (degr and self.rng.random() < 0.15 * degr.severity * dt * 5)
        if t - self._last_gnss_t >= 1.0 / c.gnss_rate_hz - 1e-9:
            self._last_gnss_t = t
            if valid:
                gnss_new = True
                self._gnss_hold = (
                    (pn + self.gnss_bias[0] + g(0, c.gnss_pos_sigma_m * k), pe + self.gnss_bias[1] + g(0, c.gnss_pos_sigma_m * k),
                     h + self.gnss_bias[2] + g(0, c.gnss_alt_sigma_m * k)),
                    (vn + g(0, c.gnss_vel_sigma_ms * k), ve + g(0, c.gnss_vel_sigma_ms * k), vd + g(0, 1.5 * c.gnss_vel_sigma_ms * k)),
                )
        hold = self._gnss_hold or ((pn, pe, h), (vn, ve, vd))
        # ---- barometer
        self.baro_bias += c.baro_drift_m_per_s * dt * g(0, 1)
        baro: float | None = h + self.baro_bias + g(0, c.baro_sigma_m)
        if self.active("baro_failure", t):
            if self._baro_frozen is None:
                self._baro_frozen = baro
            baro = self._baro_frozen  # stuck sensor: classic silent failure
        else:
            self._baro_frozen = None
        # ---- pitot
        va = aux.get("va", 0.0)
        airspeed: float | None = va * self.airspeed_scale + g(0, c.airspeed_sigma_ms)
        pf = self.active("airspeed_failure", t)
        if pf:
            # partially blocked pitot (water / insect): reading decays toward a low value
            if self._pitot_blocked is None:
                self._pitot_blocked = airspeed
            self._pitot_blocked += (0.35 * va - self._pitot_blocked) * min(1.0, 0.3 * dt * pf.severity)
            airspeed = self._pitot_blocked + g(0, 0.4)
        else:
            self._pitot_blocked = None
        # ---- AHRS + IMU
        roll, pitch, yaw = euler_from_quat(tuple(x[6:10]))
        a_s = math.radians(c.attitude_sigma_deg)
        tau = 2.0
        aa = math.exp(-dt / tau)
        bb = math.sqrt(1 - aa * aa)
        sig = (a_s, a_s, math.radians(c.heading_sigma_deg))
        for i in range(3):
            self.att_err[i] = aa * self.att_err[i] + bb * sig[i] * g(0, 1)
        gb = self.active("imu_bias", t)
        bias = 0.04 * gb.severity if gb else 0.0  # rad/s step bias on the yaw/roll gyros
        gyro = (x[10] + bias + g(0, c.gyro_sigma_rad_s), x[11] + g(0, c.gyro_sigma_rad_s), x[12] + bias + g(0, c.gyro_sigma_rad_s))
        fs = aux.get("f_spec", (0.0, 0.0, -G))
        accel = (fs[0] + g(0, c.accel_sigma_ms2), fs[1] + g(0, c.accel_sigma_ms2), fs[2] + g(0, c.accel_sigma_ms2))
        # an uncorrected gyro bias slowly corrupts the AHRS roll estimate
        roll_err = bias * 2.0 if gb else 0.0
        return Measurements(
            t=t, gnss_valid=valid and self._gnss_hold is not None, gnss_pos=hold[0], gnss_vel=hold[1],
            baro_alt=baro, airspeed=airspeed,
            roll=roll + roll_err + self.att_err[0], pitch=pitch + self.att_err[1], yaw=yaw + self.att_err[2],
            gyro=gyro, accel=accel, link_ok=self.active("comm_loss", t) is None, gnss_new=gnss_new,
        )


class HealthMonitor:
    """Detects sensor faults from *measurements only* (no access to truth or the fault schedule)."""

    def __init__(self):
        self.h = SensorHealth()
        self._baro_hist: list[tuple[float, float, float]] = []
        self._as_resid = 0.0
        self._gnss_gap = 0.0
        self._link_gap = 0.0
        self._gyro_resid = 0.0
        self._last_yaw = None
        self.events: list[dict] = []

    def _flag(self, attr: str, ok: bool, t: float, msg: str):
        if getattr(self.h, attr) != ok:
            setattr(self.h, attr, ok)
            self.events.append({"t": round(t, 2), "sensor": attr.replace("_ok", ""), "ok": ok, "message": msg})

    def update(self, m: Measurements, dt: float, wind_est: tuple[float, float] | None) -> SensorHealth:
        t = m.t
        # GNSS: fix loss for > 1.5 s or implausible jumps
        self._gnss_gap = 0.0 if m.gnss_new else self._gnss_gap + dt
        self._flag("gnss_ok", self._gnss_gap < 1.5, t,
                   "GNSS fix lost or degraded (no valid update > 1.5 s)" if self._gnss_gap >= 1.5 else "GNSS fix restored")
        # Barometer: frozen output while GNSS altitude changes, or large disagreement
        if m.baro_alt is not None:
            self._baro_hist.append((t, m.baro_alt, m.gnss_pos[2]))
            while self._baro_hist and t - self._baro_hist[0][0] > 4.0:
                self._baro_hist.pop(0)
            if len(self._baro_hist) > 20 and self.h.gnss_ok:
                bs = [b for _, b, _ in self._baro_hist]
                gs = [gg for _, _, gg in self._baro_hist]
                frozen = max(bs) - min(bs) < 1e-6 and (max(gs) - min(gs)) > 2.0
                diff = abs(bs[-1] - gs[-1])
                bad = frozen or diff > 25.0
                self._flag("baro_ok", not bad, t, "Barometer frozen/inconsistent with GNSS altitude" if bad else "Barometer consistent again")
        # Airspeed: compare against GNSS ground velocity minus wind estimate
        if m.airspeed is not None and wind_est is not None and self.h.gnss_ok:
            vn, ve, vd = m.gnss_vel
            synth = math.sqrt((vn - wind_est[0]) ** 2 + (ve - wind_est[1]) ** 2 + vd * vd)
            resid = m.airspeed - synth
            self._as_resid += (resid - self._as_resid) * min(1.0, dt / 3.0)
            bad = abs(self._as_resid) > 3.0
            self._flag("airspeed_ok", not bad, t,
                       f"Airspeed sensor disagrees with GNSS-wind synthetic airspeed by {self._as_resid:.1f} m/s" if bad else "Airspeed sensor consistent again")
        # IMU: yaw-rate gyro vs AHRS heading rate (in a coordinated turn psi_dot ~ r cos(phi) / cos(theta))
        if self._last_yaw is not None:
            dyaw = ((m.yaw - self._last_yaw + math.pi) % (2 * math.pi) - math.pi) / dt
            pred = (m.gyro[1] * math.sin(m.roll) + m.gyro[2] * math.cos(m.roll)) / max(0.3, math.cos(m.pitch))
            self._gyro_resid += (pred - dyaw - self._gyro_resid) * min(1.0, dt / 8.0)
            bad = abs(self._gyro_resid) > 0.025
            self._flag("imu_ok", not bad, t, f"Gyro bias suspected ({math.degrees(self._gyro_resid):.1f} deg/s)" if bad else "Gyro consistent again")
        self._last_yaw = m.yaw
        # Link: heartbeat timeout
        self._link_gap = 0.0 if m.link_ok else self._link_gap + dt
        self._flag("link_ok", self._link_gap < 3.0, t, "Telemetry link lost (> 3 s without heartbeat)" if self._link_gap >= 3.0 else "Telemetry link restored")
        return self.h
