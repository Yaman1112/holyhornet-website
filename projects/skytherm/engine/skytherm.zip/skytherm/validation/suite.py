"""Verification & validation suite.

Each check returns a dict with: id, category, name, criterion, measured, passed, details.
"Validation" here means *against analytical benchmarks and synthetic ground truth*. Nothing in this
suite validates real-world atmospheric performance — that needs flight data (docs/VALIDATION.md).
"""

from __future__ import annotations

import math
import time
from concurrent.futures import ProcessPoolExecutor

from ..aircraft import performance
from ..aircraft.config import AircraftConfig
from ..aircraft.model import G, AircraftModel
from ..atmosphere import isa
from ..dynamics.linearize import linearize, modes, trim_glide
from ..dynamics.six_dof import Controls, SixDOF, normalize_and_check, rk4_step
from ..energy.battery import Battery
from ..frames import body_to_ned, euler_from_quat, ned_to_body, quat_from_euler


def _chk(cid, cat, name, criterion, measured, passed, details=""):
    return {"id": cid, "category": cat, "name": name, "criterion": criterion, "measured": measured, "passed": bool(passed), "details": details}


# ------------------------------------------------------------------------------------ mathematical
def check_isa():
    rho0, rho1k, t1k = isa.density(0), isa.density(1000), isa.temperature(1000)
    ok = abs(rho0 - 1.225) < 1e-3 and abs(rho1k - 1.1117) < 2e-3 and abs(t1k - 281.65) < 0.01
    return _chk("M1", "mathematical", "ISA atmosphere", "rho(0)=1.225, rho(1000)=1.1117 kg/m3, T(1000)=281.65 K",
                {"rho0": round(rho0, 5), "rho1000": round(rho1k, 5), "T1000": round(t1k, 3)}, ok)


def check_lift_drag_equations():
    m = AircraftModel(AircraftConfig())
    rho, v, alpha = 1.2, 11.0, 0.06
    cl, cd, *_ = m.coefficients(alpha, 0.0, v, 0, 0, 0, 0, 0, 0)
    fx, fy, fz, *_ = m.forces_moments(v, alpha, 0.0, 0, 0, 0, 0, 0, 0, 0, rho)
    q = 0.5 * rho * v * v * m.geometry.area
    lift = fx * math.sin(alpha) - fz * math.cos(alpha)
    drag = -fx * math.cos(alpha) - fz * math.sin(alpha)
    e1, e2 = abs(lift - q * cl), abs(drag - q * cd)
    ki = 1 / (math.pi * m.cfg.wing.oswald_e * m.geometry.aspect_ratio_effective)
    ok = e1 < 1e-9 and e2 < 1e-9 and abs(m.k_induced - ki) < 1e-12
    return _chk("M2", "mathematical", "Lift, drag and induced-drag equations",
                "L = 1/2 rho V^2 S CL, D = 1/2 rho V^2 S CD, CDi = CL^2/(pi e AR) exactly",
                {"lift_err_n": e1, "drag_err_n": e2, "k_induced": m.k_induced}, ok)


def check_polar_points():
    m = AircraftModel(AircraftConfig())
    rho = isa.density(300)
    bg, ms = performance.best_glide(m, rho), performance.min_sink(m, rho)
    ok = ms["v"] < bg["v"] - 0.3 and ms["sink"] < bg["sink"] and bg["ld"] > ms["ld"]
    return _chk("M3", "mathematical", "Min-sink and best-glide are distinct operating points",
                "V_minsink < V_bestglide, sink_minsink < sink_bestglide, L/D_bestglide > L/D_minsink",
                {"v_min_sink": round(ms["v"], 3), "sink_min": round(ms["sink"], 4), "v_best_glide": round(bg["v"], 3),
                 "ld_max": round(bg["ld"], 3)}, ok)


def check_frames():
    errs = []
    for r, p, y in ((0.3, -0.2, 1.0), (-1.2, 0.5, -2.5), (0.0, 1.2, 0.4)):
        q = quat_from_euler(r, p, y)
        rr, pp, yy = euler_from_quat(q)
        errs.append(max(abs(rr - r), abs(pp - p), abs(math.remainder(yy - y, 2 * math.pi))))
        v = (1.0, -2.0, 0.5)
        back = ned_to_body(q, body_to_ned(q, v))
        errs.append(max(abs(a - b) for a, b in zip(v, back)))
    e = max(errs)
    return _chk("M4", "mathematical", "Coordinate transformations (Euler <-> quaternion, body <-> NED)",
                "round-trip error < 1e-12", {"max_error": e}, e < 1e-12)


def _ballistic_run(dt, t_end=6.0):
    m = AircraftModel(AircraftConfig())
    dyn = SixDOF(m)
    x = [0, 0, -200, 15, 0, 2, *quat_from_euler(0.1, 0.2, 0.0), 0.8, -0.5, 1.2]
    n = int(round(t_end / dt))
    e0 = G * 200 + 0.5 * (15 ** 2 + 2 ** 2)
    max_q = 0.0
    for _ in range(n):
        x = rk4_step(dyn.derivatives, x, dt, Controls(), (0.0, 0.0, 0.0), 0.0)  # rho=0: no aerodynamics
        qn = math.sqrt(sum(v * v for v in x[6:10]))
        max_q = max(max_q, abs(qn - 1))
    e1 = G * (-x[2]) + 0.5 * (x[3] ** 2 + x[4] ** 2 + x[5] ** 2)
    return x, e0, e1, max_q


def check_energy_conservation():
    x, e0, e1, max_q = _ballistic_run(0.01)
    rel = abs(e1 - e0) / e0
    return _chk("M5", "mathematical", "Energy conservation (gravity only, tumbling body)",
                "|dE|/E < 1e-6 over 6 s with rotation", {"relative_energy_error": rel, "quat_norm_max_dev": max_q}, rel < 1e-6 and max_q < 1e-6)


def check_rk4_convergence():
    m = AircraftModel(AircraftConfig())
    dyn = SixDOF(m)
    tr = trim_glide(m, 11.0, 300)

    def run(dt):
        x = list(tr["state"])
        x[10] = 0.6  # roll-rate disturbance excites lateral + longitudinal dynamics
        x[11] = 0.3
        c = Controls(elevator=tr["controls"].elevator, aileron=0.02)
        for _ in range(int(round(2.0 / dt))):
            x = rk4_step(dyn.derivatives, x, dt, c, (1.0, -2.0, 0.0), 1.15)
        return x

    ref = run(0.000625)
    errs = []
    dts = (0.04, 0.02, 0.01)
    for dt in dts:
        xx = run(dt)
        errs.append(max(abs(a - b) for a, b in zip(xx[:6] + xx[10:], ref[:6] + ref[10:])))
    orders = [math.log(errs[i] / errs[i + 1], 2) for i in range(len(errs) - 1)]
    ok = all(o > 3.3 for o in orders)
    return _chk("M6", "numerical", "RK4 convergence order on the full nonlinear 6-DOF model",
                "observed order > 3.3 (theory 4)", {"dt": list(dts), "errors": errs, "observed_order": [round(o, 2) for o in orders]}, ok)


def check_quaternion_normalisation():
    from ..dynamics.six_dof import SimulationDivergence

    x = [0, 0, -100, 10, 0, 0, 1.2, 0.0, 0.0, 0.0, 0, 0, 0]
    normalize_and_check(list(x[:6]) + [1.0, 0.01, 0.0, 0.0] + [0, 0, 0])
    try:
        normalize_and_check(x)
        caught = False
    except SimulationDivergence:
        caught = True
    xb = [0, 0, -100, 10, 0, 0, 1.0, 0.01, 0.0, 0.0, 0, 0, 0]
    xn = normalize_and_check(list(xb))
    n = math.sqrt(sum(v * v for v in xn[6:10]))
    return _chk("M7", "numerical", "Quaternion normalisation and divergence guard",
                "normalised |q|=1; a drifted |q| (1.2) raises SimulationDivergence", {"norm_after": n, "divergence_caught": caught},
                abs(n - 1) < 1e-14 and caught)


def check_steady_glide_vs_polar():
    from ..simulation.runner import SimulationRunner
    from ..simulation.scenarios import get_scenario

    cfg = get_scenario("A_conventional_glide")
    cfg.duration_s = 200
    cfg.atmosphere.turbulence_sigma_ms = 0.0
    r = SimulationRunner(cfg).run()
    fr = [f for f in r["frames"] if f["t"] > 40]
    sink = -sum(f["vz"] for f in fr) / len(fr)
    va = sum(f["va"] for f in fr) / len(fr)
    h = sum(f["h"] for f in fr) / len(fr)
    m = AircraftModel(cfg.aircraft)
    pred = performance.sink_rate(m, va, isa.density(h))
    err = abs(sink - pred) / pred
    return _chk("A1", "aerodynamic", "6-DOF steady glide sink vs analytical polar",
                "relative error < 6 % (6-DOF includes trim, control and sideslip drag the polar omits)",
                {"sink_6dof": round(sink, 4), "sink_polar": round(pred, 4), "airspeed": round(va, 3), "rel_error": round(err, 4)}, err < 0.06)


def check_modal_stability():
    m = AircraftModel(AircraftConfig())
    rep = []
    ok = True
    for v in (10.0, 13.0, 17.0):
        tr = trim_glide(m, v, 300)
        A, _, _ = linearize(m, tr)
        md = modes(A)
        for mm in md:
            if mm["mode"] != "spiral" and not mm["stable"]:
                ok = False
            if mm["mode"] == "spiral" and mm["time_to_double_s"] and mm["time_to_double_s"] < 5.0:
                ok = False
        rep.append({"v": v, "modes": [{"mode": x["mode"], "real": round(x["real"], 3), "imag": round(x["imag"], 3)} for x in md]})
    return _chk("D1", "flight dynamics", "Trim and modal stability (short period, phugoid, roll, Dutch roll, spiral)",
                "all modes stable except a slow spiral (time-to-double > 5 s), at 10/13/17 m/s", rep, ok)


# ------------------------------------------------------------------------------------ control
def _control_run(override, duration=40.0, airspeed=10.5):
    from ..atmosphere.environment import AtmosphereConfig
    from ..simulation.runner import SimulationRunner
    from ..simulation.scenarios import InitialState, ScenarioConfig

    cfg = ScenarioConfig(duration_s=duration, log_rate_hz=25, initial=InitialState(altitude_m=300, airspeed_ms=airspeed),
                         atmosphere=AtmosphereConfig(wind_speed_ms=0, turbulence_sigma_ms=0, environment_sink_ms=0))
    return SimulationRunner(cfg, override).run()


def check_bank_step():
    from ..control.autopilot import GuidanceCommand

    def ov(t, nav):
        return GuidanceCommand(mode="bank", bank=math.radians(30.0) if t >= 5 else 0.0, airspeed=10.5, bank_limit_deg=45)

    r = _control_run(ov, 25)
    fr = [f for f in r["frames"] if f["t"] >= 5]
    peak = max(f["roll"] for f in fr)
    settle = None
    for f in fr:
        if all(abs(g["roll"] - 30) < 3 for g in fr if g["t"] >= f["t"]):
            settle = f["t"] - 5
            break
    ss = sum(f["roll"] for f in fr[-50:]) / 50
    beta = max(abs(f["beta"]) for f in fr if f["t"] > 10)
    ok = settle is not None and settle < 4.0 and peak < 36 and abs(ss - 30) < 1.5
    return _chk("C1", "flight control", "Bank-angle step 0 -> 30 deg",
                "settling (+/-3 deg) < 4 s, overshoot < 6 deg, steady error < 1.5 deg",
                {"settling_s": settle, "peak_deg": round(peak, 2), "steady_deg": round(ss, 2), "max_sideslip_after_10s_deg": beta}, ok)


def check_airspeed_step():
    from ..control.autopilot import GuidanceCommand

    def ov(t, nav):
        return GuidanceCommand(mode="course", course=0.0, airspeed=13.0 if t >= 5 else 10.5)

    r = _control_run(ov, 45)
    fr = [f for f in r["frames"] if f["t"] >= 30]
    mean = sum(f["va"] for f in fr) / len(fr)
    sd = math.sqrt(sum((f["va"] - mean) ** 2 for f in fr) / len(fr))
    ok = abs(mean - 13.0) < 0.4 and sd < 0.3
    return _chk("C2", "flight control", "Airspeed step 10.5 -> 13 m/s (pitch-on-speed)",
                "|mean error| < 0.4 m/s and std < 0.3 m/s after 25 s", {"mean_ms": round(mean, 3), "std_ms": round(sd, 3)}, ok)


def check_orbit_tracking():
    from ..control.autopilot import GuidanceCommand

    def ov(t, nav):
        return GuidanceCommand(mode="orbit", orbit_center=(150.0, 0.0), orbit_radius=30.0, orbit_dir=1, airspeed=10.5, bank_limit_deg=40)

    r = _control_run(ov, 120)
    fr = [f for f in r["frames"] if f["t"] > 60]
    errs = [abs(math.hypot(f["n"] - 150, f["e"]) - 30) for f in fr]
    rms = math.sqrt(sum(e * e for e in errs) / len(errs))
    return _chk("C3", "flight control", "Orbit tracking (r = 30 m, calm air)", "RMS radial error < 2 m after convergence",
                {"rms_radial_error_m": round(rms, 3), "max_error_m": round(max(errs), 3)}, rms < 2.0)


def check_envelope_protection():
    from ..control.autopilot import GuidanceCommand

    def ov(t, nav):
        # an (unsafe) request: 75 deg bank at 8 m/s — the envelope must refuse it
        return GuidanceCommand(mode="bank", bank=math.radians(75.0) if t > 5 else 0.0, airspeed=8.0, bank_limit_deg=89)

    r = _control_run(ov, 30)
    fr = [f for f in r["frames"] if f["t"] > 5]
    max_bank = max(abs(f["roll"]) for f in fr)
    min_va = min(f["va"] for f in fr)
    max_alpha = max(f["alpha"] for f in fr)
    m = AircraftModel(AircraftConfig())
    ok = max_bank < 50 and max_alpha < math.degrees(m.alpha_stall)
    return _chk("C4", "flight control", "Flight-envelope protection against an unsafe command",
                "75 deg bank @ 8 m/s requested -> bank stays < 50 deg and alpha below stall",
                {"max_bank_deg": round(max_bank, 2), "min_airspeed": round(min_va, 2), "max_alpha_deg": round(max_alpha, 2),
                 "alpha_stall_deg": round(math.degrees(m.alpha_stall), 2), "interventions": r["summary"]["envelope_interventions"]}, ok)


# ------------------------------------------------------------------------------------ energy
def check_battery():
    cfg = AircraftConfig().battery
    b = Battery(cfg)
    e_int = 0.0
    v_start = b.ocv
    for _ in range(3600):
        b.step(150.0, 1.0)
        e_int += b.voltage * b.current / 3600.0
    nominal = Battery(cfg).nominal_energy_wh
    sag = v_start - Battery(cfg).ocv  # placeholder 0; real sag measured below
    b2 = Battery(cfg)
    b2.step(300.0, 0.1)
    sag = b2.ocv - b2.voltage
    ok = (abs(e_int - b.energy_out_wh) < 1e-6 * max(1, e_int) and 30 < nominal < 45 and b.depleted
          and e_int <= nominal * 1.02 and sag > 0)
    return _chk("E1", "energy", "Battery energy accounting, sag and cut-off",
                "sum(V I dt) == logged energy; nominal 3S 3.3 Ah in [30, 45] Wh; delivered <= nominal; cut-off reached; sag > 0 under load",
                {"integrated_wh": round(e_int, 4), "logged_wh": round(b.energy_out_wh, 4), "nominal_wh": round(nominal, 2),
                 "soc_end": round(b.soc, 4), "depleted": b.depleted, "sag_at_300w_v": round(sag, 3), "temp_end_c": round(b.temp_c, 2)}, ok)


def check_ds_energy_budget():
    from ..dynamic_soaring.model import DSParams, optimize_cycle

    r = optimize_cycle(DSParams(), "max_energy", w_ref=10.0)
    closure = abs(r["drag_energy_j_per_kg"] + r["shear_energy_j_per_kg"] - r["energy_gain_j_per_kg"])
    r0 = optimize_cycle(DSParams(), "max_energy", w_ref=0.0)
    ok = r["ok"] and closure < 0.03 * abs(r["shear_energy_j_per_kg"]) + 1.0 and r0["energy_gain_j_per_kg"] < 0
    return _chk("S1", "dynamic soaring", "Dynamic-soaring energy budget closure and zero-wind sanity",
                "|drag + shear - dE| small (trapezoid error); with no wind a cycle must lose energy",
                {"dE": round(r["energy_gain_j_per_kg"], 2), "drag": round(r["drag_energy_j_per_kg"], 2), "shear": round(r["shear_energy_j_per_kg"], 2),
                 "closure_error": round(closure, 3), "dE_zero_wind": round(r0["energy_gain_j_per_kg"], 2)}, ok)


# ------------------------------------------------------------------------------------ atmospheric (Monte Carlo)
def _mc_one(seed: int) -> dict:
    from ..simulation.runner import SimulationRunner
    from ..simulation.scenarios import get_scenario

    cfg = get_scenario("milestone")
    cfg.seed = seed
    run = SimulationRunner(cfg)
    r = run.run()
    s = r["summary"]
    th = cfg.atmosphere.thermals[0]
    # strength error at confirmation vs truth at that altitude
    strength_err = None
    calib = []
    for rec in r["thermal_map"]:
        cn, ce = run.atm.thermal_center(th, rec["t_last"])
        correct = math.hypot(rec["n"] - cn, rec["e"] - ce) < th.radius_m
        calib.append((rec["confidence"], correct))
        if rec["history"]:
            h0 = rec["history"][min(len(rec["history"]) - 1, 5)]
            truth = th.strength_ms * run.atm.vertical_profile(h0["h"], th.zi_m)
            strength_err = h0["strength"] - truth
    return {"seed": seed, "found": s["true_thermals_found"], "false": s["false_detections"], "confirmed": s["thermals_confirmed"],
            "centre_err": s["centre_error_circling_mean_m"], "gain": s["altitude_gained_circling_m"], "prop_wh": s["propulsion_energy_wh"],
            "netto_rmse": s["netto_rmse_ms"], "wind_rmse": s["wind_rmse_ms"], "strength_err": strength_err, "calib": calib}


def check_thermal_monte_carlo(seeds=range(101, 113), workers: int = 4):
    with ProcessPoolExecutor(max_workers=workers) as ex:
        res = list(ex.map(_mc_one, list(seeds)))
    n = len(res)
    det_rate = sum(1 for r in res if r["found"]) / n
    false_per_run = sum(r["false"] for r in res) / n
    ce = [r["centre_err"] for r in res if r["centre_err"] is not None]
    gains = [r["gain"] for r in res]
    se = [r["strength_err"] for r in res if r["strength_err"] is not None]
    hi = [c for cs in res for c in cs["calib"] if c[0] >= 0.6]
    lo = [c for cs in res for c in cs["calib"] if c[0] < 0.6]
    calib = {"conf>=0.6": {"n": len(hi), "fraction_correct": round(sum(1 for c in hi if c[1]) / len(hi), 3) if hi else None},
             "conf<0.6": {"n": len(lo), "fraction_correct": round(sum(1 for c in lo if c[1]) / len(lo), 3) if lo else None}}
    successful = sum(1 for g in gains if g > 100) / n
    measured = {
        "runs": n, "detection_rate": det_rate, "false_detections_per_run": round(false_per_run, 3),
        "centre_error_mean_m": round(sum(ce) / len(ce), 2) if ce else None, "centre_error_median_m": round(sorted(ce)[len(ce) // 2], 2) if ce else None,
        "climb_success_rate(>100 m)": round(successful, 3), "altitude_gain_mean_m": round(sum(gains) / n, 1),
        "strength_bias_ms": round(sum(se) / len(se), 3) if se else None,
        "netto_rmse_mean": round(sum(r["netto_rmse"] or 0 for r in res) / n, 3), "wind_rmse_mean": round(sum(r["wind_rmse"] or 0 for r in res) / n, 3),
        "confidence_calibration": calib, "per_seed": [{k: v for k, v in r.items() if k != "calib"} for r in res],
    }
    ok = det_rate >= 0.9 and false_per_run <= 0.5 and (measured["centre_error_median_m"] or 99) < 20
    return _chk("T1", "atmospheric", "Thermal detection & estimation vs synthetic truth (Monte Carlo, milestone scenario)",
                "detection rate >= 90 %, false detections <= 0.5/run, median circling centre error < 20 m", measured, ok,
                "Strength bias and climb success rate are reported, not gated: they are known weaknesses of the baseline (see VALIDATION.md).")


def check_reproducibility():
    from ..simulation.runner import SimulationRunner
    from ..simulation.scenarios import get_scenario

    cfg = get_scenario("milestone")
    cfg.duration_s = 90
    a = SimulationRunner(cfg).run()
    b = SimulationRunner(cfg.model_copy(deep=True)).run()
    sa, sb = dict(a["summary"]), dict(b["summary"])
    for k in ("wall_time_s", "realtime_factor"):
        sa.pop(k)
        sb.pop(k)
    same = sa == sb and a["frames"][-1] == b["frames"][-1]
    return _chk("R1", "reproducibility", "Bit-identical re-run from stored config + seed", "identical summary and final frame",
                {"config_hash": a["meta"]["config_hash"], "identical": same}, same)


ALL_CHECKS = [check_isa, check_lift_drag_equations, check_polar_points, check_frames, check_energy_conservation, check_rk4_convergence,
              check_quaternion_normalisation, check_steady_glide_vs_polar, check_modal_stability, check_bank_step, check_airspeed_step,
              check_orbit_tracking, check_envelope_protection, check_battery, check_ds_energy_budget, check_reproducibility]


def run_suite(include_monte_carlo: bool = True, progress=None) -> dict:
    t0 = time.time()
    checks = ALL_CHECKS + ([check_thermal_monte_carlo] if include_monte_carlo else [])
    results = []
    for i, fn in enumerate(checks):
        try:
            results.append(fn())
        except Exception as exc:  # report, never hide
            results.append(_chk(fn.__name__, "error", fn.__name__, "runs without exception", {"error": repr(exc)}, False))
        if progress:
            progress((i + 1) / len(checks))
    from .. import MODEL_VERSIONS

    return {"created": time.strftime("%Y-%m-%d %H:%M:%S"), "wall_s": round(time.time() - t0, 1), "model_versions": MODEL_VERSIONS,
            "passed": sum(r["passed"] for r in results), "total": len(results), "checks": results,
            "scope_note": "Benchmarks are analytical or synthetic-truth based. No check validates real atmospheric performance."}
