"""python -m skytherm.validation [--no-mc]  ->  reports/VALIDATION_REPORT.{md,json}"""

import json
import sys
from pathlib import Path

from .suite import run_suite


def main():
    mc = "--no-mc" not in sys.argv
    rep = run_suite(include_monte_carlo=mc, progress=lambda f: print(f"\r{f * 100:5.1f} %", end="", flush=True))
    print()
    out = Path(__file__).resolve().parents[3] / "reports"
    out.mkdir(exist_ok=True)
    (out / "VALIDATION_REPORT.json").write_text(json.dumps(rep, indent=1))
    lines = [f"# SkyTherm validation report", "", f"Generated {rep['created']} · {rep['passed']}/{rep['total']} checks passed · wall {rep['wall_s']} s", "",
             f"> {rep['scope_note']}", "", "| ID | Category | Check | Criterion | Result |", "|---|---|---|---|---|"]
    for c in rep["checks"]:
        lines.append(f"| {c['id']} | {c['category']} | {c['name']} | {c['criterion']} | {'PASS' if c['passed'] else 'FAIL'} |")
    lines += ["", "## Measured values", ""]
    for c in rep["checks"]:
        m = dict(c["measured"]) if isinstance(c["measured"], dict) else c["measured"]
        if isinstance(m, dict):
            m.pop("per_seed", None)
        lines += [f"### {c['id']} — {c['name']}", "", "```json", json.dumps(m, indent=1), "```", ""]
        if c.get("details"):
            lines += [c["details"], ""]
    (out / "VALIDATION_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"{rep['passed']}/{rep['total']} passed -> {out}")
    sys.exit(0 if rep["passed"] == rep["total"] else 1)


if __name__ == "__main__":
    main()
