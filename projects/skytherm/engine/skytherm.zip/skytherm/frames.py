"""Coordinate frames and attitude math.

Conventions (see docs/FRAMES.md):
* Inertial frame: flat-earth **NED** (x north, y east, z down), origin at the home point on the ground.
* Body frame: **FRD** (x forward through the nose, y out the right wing, z down).
* Attitude quaternion ``q = [w, x, y, z]`` (Hamilton, scalar first) rotates body -> NED:
  ``v_ned = R(q) @ v_body``.
* Euler angles are ZYX (yaw psi, pitch theta, roll phi).
* Altitude ``h = -z_ned``. Vertical air velocity ``w_up`` is positive upward, so the NED wind
  down-component is ``-w_up``.

Functions use plain floats/tuples (not numpy) because they sit in the inner simulation loop.
"""

from __future__ import annotations

import math

Vec3 = tuple[float, float, float]
Quat = tuple[float, float, float, float]


def quat_normalize(q: Quat) -> Quat:
    w, x, y, z = q
    n = math.sqrt(w * w + x * x + y * y + z * z)
    if n == 0.0 or not math.isfinite(n):
        raise ValueError("degenerate quaternion")
    return (w / n, x / n, y / n, z / n)


def quat_mul(a: Quat, b: Quat) -> Quat:
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return (
        aw * bw - ax * bx - ay * by - az * bz,
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
    )


def quat_conj(q: Quat) -> Quat:
    return (q[0], -q[1], -q[2], -q[3])


def quat_to_dcm(q: Quat) -> tuple[Vec3, Vec3, Vec3]:
    """Rotation matrix body->NED as three row tuples."""
    w, x, y, z = q
    return (
        (1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)),
        (2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)),
        (2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)),
    )


def body_to_ned(q: Quat, v: Vec3) -> Vec3:
    r = quat_to_dcm(q)
    return (
        r[0][0] * v[0] + r[0][1] * v[1] + r[0][2] * v[2],
        r[1][0] * v[0] + r[1][1] * v[1] + r[1][2] * v[2],
        r[2][0] * v[0] + r[2][1] * v[1] + r[2][2] * v[2],
    )


def ned_to_body(q: Quat, v: Vec3) -> Vec3:
    r = quat_to_dcm(q)
    return (
        r[0][0] * v[0] + r[1][0] * v[1] + r[2][0] * v[2],
        r[0][1] * v[0] + r[1][1] * v[1] + r[2][1] * v[2],
        r[0][2] * v[0] + r[1][2] * v[1] + r[2][2] * v[2],
    )


def quat_from_euler(roll: float, pitch: float, yaw: float) -> Quat:
    cr, sr = math.cos(roll / 2), math.sin(roll / 2)
    cp, sp = math.cos(pitch / 2), math.sin(pitch / 2)
    cy, sy = math.cos(yaw / 2), math.sin(yaw / 2)
    return (
        cr * cp * cy + sr * sp * sy,
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
    )


def euler_from_quat(q: Quat) -> Vec3:
    """Return (roll, pitch, yaw) in radians, ZYX convention."""
    w, x, y, z = q
    roll = math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))
    s = 2 * (w * y - z * x)
    pitch = math.asin(max(-1.0, min(1.0, s)))
    yaw = math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))
    return (roll, pitch, yaw)


def quat_derivative(q: Quat, omega: Vec3) -> Quat:
    """q_dot = 0.5 * q (x) [0, omega_body]."""
    w, x, y, z = q
    p, qq, r = omega
    return (
        0.5 * (-x * p - y * qq - z * r),
        0.5 * (w * p + y * r - z * qq),
        0.5 * (w * qq - x * r + z * p),
        0.5 * (w * r + x * qq - y * p),
    )


def wrap_pi(a: float) -> float:
    return (a + math.pi) % (2 * math.pi) - math.pi


def cross(a: Vec3, b: Vec3) -> Vec3:
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def norm(a: Vec3) -> float:
    return math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])


# NED -> visualisation frame (three.js, y-up): x = east, y = up, z = -north.
NED_TO_VIS = ((0.0, 1.0, 0.0), (0.0, 0.0, -1.0), (-1.0, 0.0, 0.0))


def ned_to_vis(v: Vec3) -> Vec3:
    return (v[1], -v[2], -v[0])
