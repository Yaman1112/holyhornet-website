"""Versioned storage for runs, experiments and configurations (SQLite + gzip JSON blobs).

Every stored run records: config JSON, config hash, seed, model versions and the full result.
Re-running a stored config reproduces the result bit-for-bit (verified in tests/test_reproducibility.py).
PostgreSQL/PostGIS from the brief is deferred: no geospatial queries are needed yet and SQLite keeps the
platform zero-install (see docs/ARCHITECTURE.md, "Deviations").
"""

from __future__ import annotations

import gzip
import json
import os
import sqlite3
import threading
import time
import uuid
from pathlib import Path

DATA_DIR = Path(os.environ.get("SKYTHERM_DATA", Path(__file__).resolve().parents[3] / "data"))

_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY, created REAL, scenario_id TEXT, name TEXT, kind TEXT, status TEXT, progress REAL,
  seed INTEGER, config_hash TEXT, model_versions TEXT, config TEXT, summary TEXT, error TEXT, label TEXT
);
CREATE TABLE IF NOT EXISTS experiments (
  id TEXT PRIMARY KEY, created REAL, template TEXT, title TEXT, hypothesis TEXT, status TEXT, progress REAL,
  definition TEXT, results TEXT, conclusions TEXT, limitations TEXT, algorithm_version TEXT
);
CREATE TABLE IF NOT EXISTS configs (
  id TEXT PRIMARY KEY, created REAL, kind TEXT, name TEXT, version INTEGER, hash TEXT, body TEXT
);
"""


def _json_default(o):
    """numpy scalars/arrays -> plain JSON types."""
    if hasattr(o, "tolist"):
        return o.tolist()
    if hasattr(o, "item"):
        return o.item()
    raise TypeError(f"not JSON serialisable: {type(o).__name__}")


class Store:
    def __init__(self, path: Path | None = None):
        self.dir = Path(path) if path else DATA_DIR
        self.dir.mkdir(parents=True, exist_ok=True)
        (self.dir / "runs").mkdir(exist_ok=True)
        self.db_path = self.dir / "skytherm.db"
        self._lock = threading.Lock()
        with self._conn() as c:
            c.executescript(_SCHEMA)

    def _conn(self):
        c = sqlite3.connect(self.db_path, timeout=30)
        c.row_factory = sqlite3.Row
        return c

    # ------------------------------------------------------------------ runs
    def create_run(self, cfg, label: str = "") -> str:
        from .. import MODEL_VERSIONS

        rid = time.strftime("R%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        with self._lock, self._conn() as c:
            c.execute("INSERT INTO runs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (rid, time.time(), cfg.id, cfg.name, cfg.kind, "queued", 0.0, cfg.seed, cfg.config_hash(),
                       json.dumps(MODEL_VERSIONS), cfg.model_dump_json(), None, None, label))
        return rid

    def update_run(self, rid: str, **fields):
        if not fields:
            return
        cols = ", ".join(f"{k}=?" for k in fields)
        vals = [json.dumps(v) if isinstance(v, (dict, list)) else v for v in fields.values()]
        with self._lock, self._conn() as c:
            c.execute(f"UPDATE runs SET {cols} WHERE id=?", (*vals, rid))

    def save_result(self, rid: str, result: dict):
        final = self.dir / "runs" / f"{rid}.json.gz"
        tmp = final.with_suffix(".tmp")
        with gzip.open(tmp, "wt", encoding="utf-8") as f:
            json.dump(result, f, separators=(",", ":"), default=_json_default, allow_nan=False)
        os.replace(tmp, final)

    def load_result(self, rid: str) -> dict | None:
        p = self.dir / "runs" / f"{rid}.json.gz"
        if not p.exists():
            return None
        with gzip.open(p, "rt", encoding="utf-8") as f:
            return json.load(f)

    def get_run(self, rid: str) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT * FROM runs WHERE id=?", (rid,)).fetchone()
        return self._run_row(r) if r else None

    def list_runs(self, limit: int = 100) -> list[dict]:
        with self._conn() as c:
            rows = c.execute("SELECT * FROM runs ORDER BY created DESC LIMIT ?", (limit,)).fetchall()
        out = []
        for r in rows:
            d = self._run_row(r)
            d.pop("config", None)
            out.append(d)
        return out

    def delete_run(self, rid: str):
        with self._lock, self._conn() as c:
            c.execute("DELETE FROM runs WHERE id=?", (rid,))
        p = self.dir / "runs" / f"{rid}.json.gz"
        if p.exists():
            p.unlink()

    @staticmethod
    def _run_row(r) -> dict:
        d = dict(r)
        for k in ("model_versions", "config", "summary"):
            if d.get(k):
                d[k] = json.loads(d[k])
        return d

    # ------------------------------------------------------------------ experiments
    def create_experiment(self, template: str, title: str, hypothesis: str, definition: dict, algorithm_version: str) -> str:
        eid = time.strftime("X%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        with self._lock, self._conn() as c:
            c.execute("INSERT INTO experiments VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                      (eid, time.time(), template, title, hypothesis, "queued", 0.0, json.dumps(definition), None, "", "", algorithm_version))
        return eid

    def update_experiment(self, eid: str, **fields):
        cols = ", ".join(f"{k}=?" for k in fields)
        vals = [json.dumps(v) if isinstance(v, (dict, list)) else v for v in fields.values()]
        with self._lock, self._conn() as c:
            c.execute(f"UPDATE experiments SET {cols} WHERE id=?", (*vals, eid))

    def get_experiment(self, eid: str) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT * FROM experiments WHERE id=?", (eid,)).fetchone()
        return self._exp_row(r) if r else None

    def list_experiments(self) -> list[dict]:
        with self._conn() as c:
            rows = c.execute("SELECT * FROM experiments ORDER BY created DESC").fetchall()
        return [self._exp_row(r) for r in rows]

    def delete_experiment(self, eid: str):
        with self._lock, self._conn() as c:
            c.execute("DELETE FROM experiments WHERE id=?", (eid,))

    @staticmethod
    def _exp_row(r) -> dict:
        d = dict(r)
        for k in ("definition", "results"):
            if d.get(k):
                d[k] = json.loads(d[k])
        return d

    # ------------------------------------------------------------------ versioned configs
    def save_config(self, kind: str, name: str, body: dict) -> dict:
        import hashlib

        h = hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()[:16]
        with self._lock, self._conn() as c:
            row = c.execute("SELECT MAX(version) FROM configs WHERE kind=? AND name=?", (kind, name)).fetchone()
            ver = (row[0] or 0) + 1
            cid = f"{kind}:{name}:v{ver}"
            c.execute("INSERT INTO configs VALUES (?,?,?,?,?,?,?)", (cid, time.time(), kind, name, ver, h, json.dumps(body)))
        return {"id": cid, "version": ver, "hash": h}

    def list_configs(self, kind: str | None = None) -> list[dict]:
        with self._conn() as c:
            if kind:
                rows = c.execute("SELECT id, created, kind, name, version, hash FROM configs WHERE kind=? ORDER BY created DESC", (kind,)).fetchall()
            else:
                rows = c.execute("SELECT id, created, kind, name, version, hash FROM configs ORDER BY created DESC").fetchall()
        return [dict(r) for r in rows]

    def get_config(self, cid: str) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT * FROM configs WHERE id=?", (cid,)).fetchone()
        if not r:
            return None
        d = dict(r)
        d["body"] = json.loads(d["body"])
        return d
