"""Research experiment manager: templates, parameter sweeps x Monte-Carlo seeds, aggregation.

An experiment = hypothesis + base scenario (or analytic model) + one swept parameter + seeds +
metrics. Every individual run stores its config hash so any cell can be reproduced exactly.
Conclusions are *descriptive* (what changed, by how much, with spread); interpretation is left to
the researcher. Limitations are attached per template.
"""

from __future__ import annotations

import math
from concurrent.futures import ProcessPoolExecutor

from .. import MODEL_VERSIONS

TEMPLATES = [
    {"id": "thermal_detection_sensitivity", "title": "Thermal detection sensitivity", "kind": "sim", "scenario": "E_weak_turbulent",
     "hypothesis": "Lowering the netto detection threshold finds more weak thermals but raises false detections in turbulence.",
     "param": "autonomy.detect_threshold", "values": [0.3, 0.5, 0.8], "seeds": [201, 202, 203], "duration_s": 360,
     "metrics": ["thermals_detected", "false_detections", "true_thermals_found", "thermals_confirmed"],
     "limitations": ["Synthetic Gedeon/Allen thermals and Gauss-Markov turbulence only.", "3 seeds per cell: indicative, not statistically conclusive."]},
    {"id": "thermal_centre_accuracy", "title": "Thermal-centre estimation accuracy", "kind": "sim", "scenario": "milestone",
     "hypothesis": "The 6-state EKF keeps the circling centre error below the thermal core radius (~35 m).",
     "param": "seed_only", "values": [0], "seeds": [301, 302, 303, 304, 305, 306, 307, 308], "duration_s": 300,
     "metrics": ["centre_error_circling_mean_m", "altitude_gained_circling_m", "thermals_confirmed", "false_detections"],
     "limitations": ["Single thermal geometry and wind; truth model is Gedeon, estimator is Gaussian (deliberate mismatch)."]},
    {"id": "thermal_drift_prediction", "title": "Thermal drift prediction", "kind": "sim", "scenario": "C_thermal_drift",
     "hypothesis": "Estimating drift velocity keeps centre error roughly independent of wind speed.",
     "param": "atmosphere.wind_speed_ms", "values": [0.0, 3.0, 6.0], "seeds": [401, 402, 403], "duration_s": 360,
     "metrics": ["centre_error_circling_mean_m", "altitude_gained_circling_m", "thermals_confirmed"],
     "limitations": ["Thermals drift as rigid columns (no lean/tilt), which flatters the estimator."]},
    {"id": "drift_prior_ablation", "title": "Drift prior: local wind vs. shear-aware layer mean", "kind": "sim", "scenario": "C_thermal_drift",
     "hypothesis": "Anchoring the thermal-drift estimate to the estimated mixed-layer mean wind (instead of the wind at the aircraft) reduces centring error in a sheared 5 m/s wind.",
     "param": "autonomy.drift_prior", "values": ["local", "layer"], "seeds": [401, 402, 403, 404], "duration_s": 360,
     "metrics": ["centre_error_circling_mean_m", "altitude_gained_circling_m", "thermals_confirmed"],
     "limitations": ["Truth drift uses the wind at 0.5 zi and the same power-law/veer family the prior assumes, which flatters the prior.",
                     "zi is taken from configuration/forecast, not measured."]},
    {"id": "plume_search_ablation", "title": "Drift-projected plume search in strong wind", "kind": "sim", "scenario": "C_thermal_drift",
     "hypothesis": "After an empty forecast hotspot in strong wind, a crosswind gate plus downwind sweep along the drift-projected axis finds the thermal more often than replanning to the search pattern.",
     "param": "autonomy.plume_search", "values": [False, True], "seeds": [401, 402, 403, 404, 405, 406, 407, 408], "duration_s": 360,
     "overrides": {"atmosphere.wind_speed_ms": 6.0},
     "metrics": ["thermals_confirmed", "altitude_gained_circling_m", "centre_error_circling_mean_m", "false_detections"],
     "limitations": ["Single-thermal scenario: a real hotspot releases thermals repeatedly, which the sweep would exploit better.",
                     "Altitude gain is truncated by the 360 s run, which penalises later finds."]},
    {"id": "recentre_ablation", "title": "Per-circle lift-harmonic re-centring in strong wind", "kind": "sim", "scenario": "C_thermal_drift",
     "hypothesis": "Feeding the EKF a per-circle first-harmonic centre fix (in the drifting frame) keeps the orbit on a narrow, fast-drifting thermal and increases the climb at 6 m/s.",
     "param": "autonomy.recentre", "values": [False, True], "seeds": [401, 402, 403, 404, 405, 406, 407, 408], "duration_s": 360,
     "overrides": {"atmosphere.wind_speed_ms": 6.0},
     "metrics": ["altitude_gained_circling_m", "centre_error_circling_mean_m", "thermals_confirmed", "false_detections"],
     "limitations": ["4 of 6 climbs at 6 m/s end at the 1500 m geofence after 70-130 s, which caps the gain for both arms.",
                     "Both arms include the EKF strength floor (0.2 m/s) introduced with re-centring."]},
    {"id": "fence_aware_ablation", "title": "Geofence-aware planning with drifting thermals", "kind": "sim", "scenario": "J_windy_hotspots",
     "hypothesis": "Weighting options by drift room before the geofence, skipping lift that will drift out, and leaving thermals before the fence avoids geofence breaches and increases the climb.",
     "param": "autonomy.fence_aware", "values": [False, True], "seeds": [801, 802, 803, 804, 805, 806, 807, 808], "duration_s": 900,
     "metrics": ["altitude_gained_circling_m", "geofence_breaches", "fence_planned_exits", "final_altitude_m", "propulsion_energy_wh", "thermals_confirmed"],
     "limitations": ["Scenario J was designed to exercise this feature (equal forecasts upwind/downwind).",
                     "A breach ends the mission (return + landing) while a planned exit continues it, so motor energy is not comparable between arms.",
                     "The drift used is the on-board layer-mean estimate; the fence is a simple circle around home."]},
    {"id": "min_sink_mass", "title": "Minimum-sink speed vs. mass (ballast)", "kind": "analytic",
     "hypothesis": "Min-sink and best-glide speeds scale with sqrt(mass); best L/D is unchanged by mass.",
     "param": "aircraft.mass_scale", "values": [0.8, 1.0, 1.2, 1.4], "seeds": [0],
     "metrics": ["v_min_sink", "sink_min", "v_best_glide", "ld_max", "stall_speed"],
     "limitations": ["Reynolds-number effects on the polar are not modelled (lighter = slower = lower Re = more drag in reality)."]},
    {"id": "glide_ratio_wingspan", "title": "Glide ratio vs. wingspan", "kind": "analytic",
     "hypothesis": "Increasing span at fixed root chord raises aspect ratio and best L/D.",
     "param": "aircraft.wing.wingspan_m", "values": [2.0, 2.5, 3.0], "seeds": [0],
     "metrics": ["ld_max", "v_best_glide", "sink_min", "aspect_ratio", "mass_kg"],
     "limitations": ["Wing mass is held constant across spans (structural weight growth not modelled)."]},
    {"id": "wind_gradient_sensitivity", "title": "Dynamic soaring: shear-layer thickness", "kind": "ds",
     "hypothesis": "Thicker (weaker-gradient) shear layers need more wind for an energy-neutral cycle.",
     "param": "layer_thickness_m", "values": [1.5, 2.5, 4.0, 6.0], "seeds": [0], "metrics": ["min_wind_ms", "period_s", "max_load_factor"],
     "limitations": ["Point-mass optimal control; theoretical lower bound."]},
    {"id": "ds_energy_exchange", "title": "Dynamic soaring energy exchange vs. wind", "kind": "ds_sweep",
     "hypothesis": "Net energy gain per cycle grows with wind above the energy-neutral threshold.",
     "param": "w_ref_ms", "values": [3.0, 6.0, 9.0, 12.0], "seeds": [0], "metrics": ["energy_gain_j_per_kg", "net_power_w_per_kg", "max_load_factor"],
     "limitations": ["Idealised steady shear; no gusts or roll dynamics."]},
    {"id": "battery_consumption", "title": "Propulsion energy: soaring vs. conventional", "kind": "sim", "scenario": "milestone",
     "hypothesis": "Thermal soaring reduces net propulsion energy per mission versus glide+re-climb and continuous powered flight.",
     "param": "variant", "values": ["soaring", "no_soaring", "powered_sustain"], "seeds": [501, 502, 503], "duration_s": 480,
     "metrics": ["propulsion_energy_wh", "motor_on_time_s", "max_altitude_m", "atmospheric_energy_true_wh"],
     "limitations": ["Simulated atmosphere; energy savings are simulated, not measured."]},
    {"id": "wind_estimation_accuracy", "title": "Wind-estimation accuracy vs. turbulence", "kind": "sim", "scenario": "C_thermal_drift",
     "hypothesis": "Wind RMSE grows with turbulence intensity but stays below 1 m/s for sigma <= 1 m/s.",
     "param": "atmosphere.turbulence_sigma_ms", "values": [0.0, 0.5, 1.0], "seeds": [601, 602], "duration_s": 240,
     "metrics": ["wind_rmse_ms", "netto_rmse_ms"],
     "limitations": ["RMSE is against the local truth wind including gusts; sideslip assumed zero in the estimator."]},
    {"id": "atmospheric_uncertainty", "title": "Polar-model error vs. netto estimation", "kind": "sim", "scenario": "milestone",
     "hypothesis": "A biased glide polar biases netto one-for-one and degrades thermal detection.",
     "param": "polar_error", "values": [-0.15, 0.0, 0.15, 0.3], "seeds": [701, 702], "duration_s": 300,
     "metrics": ["netto_rmse_ms", "altitude_gained_circling_m", "false_detections", "thermals_confirmed"],
     "limitations": ["Polar error is a uniform multiplicative bias."]},
    {"id": "ai_policy_comparison", "title": "Planner policy comparison", "kind": "sim", "scenario": "D_multiple_thermals",
     "hypothesis": "The explainable utility planner gains more altitude per propulsion Wh than nearest-first or no planner.",
     "param": "autonomy.planner", "values": ["utility", "nearest", "none"], "seeds": [801, 802], "duration_s": 600,
     "metrics": ["altitude_gained_circling_m", "propulsion_energy_wh", "true_thermals_found", "max_altitude_m"],
     "limitations": ["Deterministic baseline policies only; no learned policy is compared yet."]},
    {"id": "mpc_performance", "title": "Model Predictive Control performance", "kind": "planned",
     "hypothesis": "An MPC circling controller reduces centring error vs. the PID/vector-field baseline.",
     "param": "-", "values": [], "seeds": [], "metrics": [],
     "limitations": ["NOT IMPLEMENTED: MPC is a Phase-5 roadmap item. Template kept so the experiment is planned, not claimed."]},
]


def template(tid: str) -> dict:
    for t in TEMPLATES:
        if t["id"] == tid:
            return t
    raise KeyError(tid)


def set_path(obj, path: str, value):
    parts = path.split(".")
    for p in parts[:-1]:
        obj = obj[int(p)] if p.isdigit() else getattr(obj, p)
    last = parts[-1]
    if last.isdigit():
        obj[int(last)] = value
    else:
        setattr(obj, last, value)


def _sim_cell(args) -> dict:
    scenario, param, value, seed, duration = args[:5]
    overrides = args[5] if len(args) > 5 else None
    from ..simulation.runner import BASELINES, SimulationRunner
    from ..simulation.scenarios import get_scenario

    cfg = get_scenario(scenario)
    cfg.seed = seed
    cfg.compare_baselines = []
    if duration:
        cfg.duration_s = duration
    for path, v in (overrides or {}).items():
        set_path(cfg, path, v)
    if param == "variant":
        if value != "soaring":
            for k, v in BASELINES[value][1].items():
                setattr(cfg.autonomy, k, v)
    elif param != "seed_only":
        set_path(cfg, param, value)
    s = SimulationRunner(cfg).run()["summary"]
    s["config_hash"] = cfg.config_hash()
    return {"value": value, "seed": seed, "summary": s}


def _analytic_cell(param: str, value) -> dict:
    from ..aircraft import performance
    from ..aircraft.config import AircraftConfig
    from ..aircraft.model import AircraftModel
    from ..atmosphere import isa

    cfg = AircraftConfig()
    set_path(cfg, param.replace("aircraft.", ""), value)
    m = AircraftModel(cfg)
    rho = isa.density(300)
    bg, ms = performance.best_glide(m, rho), performance.min_sink(m, rho)
    return {"value": value, "seed": 0, "summary": {"v_min_sink": ms["v"], "sink_min": ms["sink"], "v_best_glide": bg["v"], "ld_max": bg["ld"],
                                                   "stall_speed": performance.stall_speed(m, rho), "aspect_ratio": m.geometry.aspect_ratio,
                                                   "mass_kg": m.mass.mass, "config_hash": cfg.config_hash()}}


def run_experiment(definition: dict, progress=None, workers: int = 4) -> dict:
    kind = definition["kind"]
    param, values, seeds, metrics = definition["param"], definition["values"], definition["seeds"], definition["metrics"]
    cells: list[dict] = []
    if kind == "planned":
        return {"status": "not_implemented", "rows": [], "aggregate": [], "conclusions": "Template only — MPC is not implemented yet."}
    if kind == "sim":
        jobs = [(definition["scenario"], param, v, s, definition.get("duration_s"), definition.get("overrides")) for v in values for s in seeds]
        done = 0
        with ProcessPoolExecutor(max_workers=workers) as ex:
            for res in ex.map(_sim_cell, jobs):
                cells.append(res)
                done += 1
                if progress:
                    progress(done / len(jobs))
    elif kind == "analytic":
        for i, v in enumerate(values):
            cells.append(_analytic_cell(param, v))
            if progress:
                progress((i + 1) / len(values))
    elif kind in ("ds", "ds_sweep"):
        from ..dynamic_soaring.model import DSParams, optimize_cycle

        for i, v in enumerate(values):
            if kind == "ds":
                p = DSParams(**{param: v})
                r = optimize_cycle(p, "min_wind")
                summ = {"min_wind_ms": r["w_ref_ms"], "period_s": r["period_s"], "max_load_factor": r["max_load_factor"], "solver_ok": r["ok"]}
            else:
                r = optimize_cycle(DSParams(), "max_energy", w_ref=v)
                summ = {"energy_gain_j_per_kg": r["energy_gain_j_per_kg"], "net_power_w_per_kg": r["energy_gain_j_per_kg"] / r["period_s"],
                        "max_load_factor": r["max_load_factor"], "solver_ok": r["ok"]}
            cells.append({"value": v, "seed": 0, "summary": summ})
            if progress:
                progress((i + 1) / len(values))
    agg = []
    for v in values:
        row = {"value": v}
        cs = [c for c in cells if c["value"] == v]
        for mname in metrics:
            xs = [c["summary"].get(mname) for c in cs if isinstance(c["summary"].get(mname), (int, float))]
            if xs:
                mean = sum(xs) / len(xs)
                sd = math.sqrt(sum((x - mean) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else 0.0
                row[mname] = {"mean": round(mean, 4), "std": round(sd, 4), "n": len(xs), "min": round(min(xs), 4), "max": round(max(xs), 4)}
            else:
                row[mname] = None
        agg.append(row)
    concl = []
    for mname in metrics:
        series = [(r["value"], r[mname]["mean"]) for r in agg if r.get(mname)]
        if len(series) >= 2:
            lo = min(series, key=lambda s: s[1])
            hi = max(series, key=lambda s: s[1])
            concl.append(f"{mname}: from {series[0][1]:.3g} ({param}={series[0][0]}) to {series[-1][1]:.3g} ({param}={series[-1][0]}); "
                         f"max {hi[1]:.3g} at {hi[0]}, min {lo[1]:.3g} at {lo[0]}.")
        elif len(series) == 1:
            r = next(row[mname] for row in agg if row.get(mname))
            concl.append(f"{mname}: mean {r['mean']:.3g} +/- {r['std']:.3g} (n={r['n']}, range {r['min']:.3g}..{r['max']:.3g}).")
    rows = [{"value": c["value"], "seed": c["seed"], **{k: c["summary"].get(k) for k in metrics}, "config_hash": c["summary"].get("config_hash")}
            for c in cells]
    return {"status": "done", "rows": rows, "aggregate": agg, "conclusions": " ".join(concl), "model_versions": MODEL_VERSIONS}
