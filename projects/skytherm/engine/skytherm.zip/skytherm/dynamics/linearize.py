"""Trim and small-perturbation (modal) analysis of the 6-DOF model.

``trim_glide`` solves for the steady, wings-level unpowered glide at a given airspeed (alpha,
elevator, flight-path angle). ``linearize`` builds the numerical Jacobian of the full nonlinear
model about that trim point in Euler-angle form and ``modes`` classifies the eigenvalues into the
classical aircraft modes (short period, phugoid, roll subsidence, spiral, Dutch roll).
"""

from __future__ import annotations

import math

import numpy as np
from scipy.optimize import fsolve

from ..aircraft.model import AircraftModel
from ..atmosphere import isa
from ..frames import euler_from_quat, quat_from_euler
from .six_dof import Controls, SixDOF


def trim_glide(model: AircraftModel, v: float, altitude: float = 300.0, throttle: float = 0.0, flight_path_deg: float | None = None):
    """Return dict(alpha, elevator, gamma, theta, state) for a steady wings-level flight."""
    dyn = SixDOF(model)
    rho = isa.density(altitude)

    def build(alpha, de, gamma):
        theta = alpha + gamma
        q = quat_from_euler(0.0, theta, 0.0)
        return [0.0, 0.0, -altitude, v * math.cos(alpha), 0.0, v * math.sin(alpha), *q, 0.0, 0.0, 0.0], Controls(elevator=de, throttle=throttle)

    def resid(z):
        alpha, de, gamma = z
        if flight_path_deg is not None:
            gamma = math.radians(flight_path_deg)
        x, c = build(alpha, de, gamma)
        d = dyn.derivatives(x, c, (0.0, 0.0, 0.0), rho)
        # du, dw, dq must vanish (inertial accel along the path = 0)
        r3 = d[3] if flight_path_deg is None else d[3]
        return [r3, d[5], d[11]]

    if flight_path_deg is not None:
        # powered trim: unknowns alpha, de, throttle at fixed gamma
        def resid_p(z):
            alpha, de, thr = z
            gamma = math.radians(flight_path_deg)
            x, _ = build(alpha, de, gamma)
            d = dyn.derivatives(x, Controls(elevator=de, throttle=thr), (0.0, 0.0, 0.0), rho)
            return [d[3], d[5], d[11]]

        sol = fsolve(resid_p, [0.08, -0.01, 0.3], full_output=True)
        alpha, de, thr = sol[0]
        gamma = math.radians(flight_path_deg)
        x, c = build(alpha, de, gamma)
        c.throttle = thr
        return {"alpha": alpha, "elevator": de, "gamma": gamma, "theta": alpha + gamma, "throttle": thr, "state": x,
                "controls": c, "converged": sol[2] == 1, "rho": rho}
    sol = fsolve(resid, [0.08, -0.01, -0.04], full_output=True)
    alpha, de, gamma = sol[0]
    x, c = build(alpha, de, gamma)
    return {"alpha": alpha, "elevator": de, "gamma": gamma, "theta": alpha + gamma, "throttle": 0.0, "state": x, "controls": c,
            "converged": sol[2] == 1, "rho": rho}


STATE_NAMES = ["u", "v", "w", "p", "q", "r", "phi", "theta", "psi"]


def linearize(model: AircraftModel, trim: dict):
    """Jacobian A (9x9) of [u v w p q r phi theta psi] about trim, plus B (9x4) for [da de dr thr]."""
    dyn = SixDOF(model)
    rho = trim["rho"]
    x0 = trim["state"]
    c0 = trim["controls"]
    phi0, th0, psi0 = euler_from_quat(tuple(x0[6:10]))

    def f(s, u):
        uu, vv, ww, p, q, r, phi, th, psi = s
        quat = quat_from_euler(phi, th, psi)
        x = [0.0, 0.0, x0[2], uu, vv, ww, *quat, p, q, r]
        c = Controls(aileron=c0.aileron + u[0], elevator=c0.elevator + u[1], rudder=c0.rudder + u[2], throttle=c0.throttle + u[3])
        d = dyn.derivatives(x, c, (0.0, 0.0, 0.0), rho)
        # Euler-angle rates from body rates
        sphi, cphi, tth, cth = math.sin(phi), math.cos(phi), math.tan(th), math.cos(th)
        dphi = p + (q * sphi + r * cphi) * tth
        dth = q * cphi - r * sphi
        dpsi = (q * sphi + r * cphi) / cth
        return np.array([d[3], d[4], d[5], d[10], d[11], d[12], dphi, dth, dpsi])

    s0 = np.array([x0[3], x0[4], x0[5], 0.0, 0.0, 0.0, phi0, th0, psi0])
    u0 = np.zeros(4)
    f0 = f(s0, u0)
    A = np.zeros((9, 9))
    B = np.zeros((9, 4))
    for i in range(9):
        h = 1e-5 * max(1.0, abs(s0[i]))
        sp, sm = s0.copy(), s0.copy()
        sp[i] += h
        sm[i] -= h
        A[:, i] = (f(sp, u0) - f(sm, u0)) / (2 * h)
    for j in range(4):
        h = 1e-5
        up, um = u0.copy(), u0.copy()
        up[j] += h
        um[j] -= h
        B[:, j] = (f(s0, up) - f(s0, um)) / (2 * h)
    return A, B, f0


def modes(A: np.ndarray) -> list[dict]:
    """Split into longitudinal (u, w, q, theta) and lateral (v, p, r, phi) subsystems and classify."""
    lon_idx = [0, 2, 4, 7]
    lat_idx = [1, 3, 5, 6]
    out = []
    for name, idx in (("longitudinal", lon_idx), ("lateral", lat_idx)):
        sub = A[np.ix_(idx, idx)]
        ev = np.linalg.eigvals(sub)
        seen = []
        for e in sorted(ev, key=lambda z: -abs(z)):
            if any(abs(e - np.conj(s)) < 1e-9 for s in seen):
                continue
            seen.append(e)
            wn = abs(e)
            zeta = -e.real / wn if wn > 0 else 1.0
            osc = abs(e.imag) > 1e-6
            if name == "longitudinal":
                label = "short period" if osc and wn > 1.0 else ("phugoid" if osc else "real longitudinal")
            else:
                if osc:
                    label = "Dutch roll"
                elif abs(e.real) > 2.0:
                    label = "roll subsidence"
                else:
                    label = "spiral"
            out.append({
                "axis": name, "mode": label, "real": float(e.real), "imag": float(abs(e.imag)),
                "wn": float(wn), "zeta": float(zeta) if osc else None, "stable": bool(e.real < 0),
                "time_constant_s": float(-1 / e.real) if (not osc and e.real != 0) else None,
                "period_s": float(2 * math.pi / abs(e.imag)) if osc else None,
                "time_to_double_s": float(math.log(2) / e.real) if e.real > 0 else None,
            })
    return out


def stability_report(model: AircraftModel, speeds=(8.5, 10.0, 13.0, 17.0, 22.0), altitude: float = 300.0) -> list[dict]:
    rep = []
    for v in speeds:
        tr = trim_glide(model, v, altitude)
        A, _, _ = linearize(model, tr)
        rep.append({"airspeed": v, "alpha_deg": math.degrees(tr["alpha"]), "elevator_deg": math.degrees(tr["elevator"]),
                    "gamma_deg": math.degrees(tr["gamma"]), "converged": tr["converged"], "modes": modes(A)})
    return rep
