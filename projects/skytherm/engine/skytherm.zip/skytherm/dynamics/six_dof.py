"""Nonlinear rigid-body six-degree-of-freedom flight dynamics.

State ``x = [pn, pe, pd, u, v, w, q0, q1, q2, q3, p, q, r]``:

* ``p``  — position of the CG in NED (m)
* ``v``  — inertial velocity expressed in body FRD axes (m/s)
* ``q``  — attitude quaternion body->NED
* ``w``  — body angular rate (rad/s)

Translational:  m (dv_b/dt) = F_b - m (omega x v_b)
Rotational:     I (domega/dt) + omega x (I omega) = M
Kinematics:     dp/dt = R(q) v_b,   dq/dt = 1/2 q (x) [0, omega]

Aerodynamic forces use the air-relative velocity v_b - R^T w_ned, so wind (including its time and
spatial variation along the path, i.e. shear) enters the dynamics physically; dynamic-soaring
energy exchange is therefore representable in this model, not bolted on.

The wind is held constant across one RK4 step (it is sampled at the start of the step); with the
default 0.02 s step and aircraft speeds ~10 m/s this is a 0.2 m spatial hold. Documented limitation.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..aircraft.model import G, AircraftModel


class SimulationDivergence(RuntimeError):
    pass


@dataclass
class Controls:
    aileron: float = 0.0  # rad, positive -> right-wing-down rolling moment
    elevator: float = 0.0  # rad, positive trailing-edge down -> nose-down moment
    rudder: float = 0.0  # rad, positive -> nose-left yawing moment (Cn_dr < 0)
    flap: float = 0.0
    throttle: float = 0.0  # 0..1


class SixDOF:
    def __init__(self, model: AircraftModel):
        self.model = model
        mp = model.mass
        self.m = mp.mass
        ixx, iyy, izz, ixz = mp.ixx, mp.iyy, mp.izz, mp.ixz
        gam = ixx * izz - ixz * ixz
        self.ixx, self.iyy, self.izz, self.ixz = ixx, iyy, izz, ixz
        self.g1 = ixz * (ixx - iyy + izz) / gam
        self.g2 = (izz * (izz - iyy) + ixz * ixz) / gam
        self.g3 = izz / gam
        self.g4 = ixz / gam
        self.g5 = (izz - ixx) / iyy
        self.g6 = ixz / iyy
        self.g7 = ((ixx - iyy) * ixx + ixz * ixz) / gam
        self.g8 = ixx / gam

    def derivatives(self, x, ctl: Controls, wind, rho, out_aux: dict | None = None):
        pn, pe, pd, u, v, w, q0, q1, q2, q3, p, q, r = x
        # rotation body->NED
        r00 = 1 - 2 * (q2 * q2 + q3 * q3); r01 = 2 * (q1 * q2 - q0 * q3); r02 = 2 * (q1 * q3 + q0 * q2)
        r10 = 2 * (q1 * q2 + q0 * q3); r11 = 1 - 2 * (q1 * q1 + q3 * q3); r12 = 2 * (q2 * q3 - q0 * q1)
        r20 = 2 * (q1 * q3 - q0 * q2); r21 = 2 * (q2 * q3 + q0 * q1); r22 = 1 - 2 * (q1 * q1 + q2 * q2)
        wn, we, wd = wind
        # wind in body axes (R^T w)
        wbx = r00 * wn + r10 * we + r20 * wd
        wby = r01 * wn + r11 * we + r21 * wd
        wbz = r02 * wn + r12 * we + r22 * wd
        ur, vr, wr = u - wbx, v - wby, w - wbz
        va = math.sqrt(ur * ur + vr * vr + wr * wr)
        if va < 0.5:
            va_s = 0.5
        else:
            va_s = va
        alpha = math.atan2(wr, ur)
        beta = math.asin(max(-1.0, min(1.0, vr / va_s)))
        fx, fy, fz, ml, mm, mn = self.model.forces_moments(
            va_s, alpha, beta, p, q, r, ctl.aileron, ctl.elevator, ctl.rudder, ctl.flap, rho)
        thrust, p_elec = self.model.thrust(ctl.throttle, va)
        fx += thrust
        m = self.m
        # gravity in body: R^T [0,0,mg]
        mg = m * G
        gx, gy, gz = r20 * mg, r21 * mg, r22 * mg
        du = (fx + gx) / m - (q * w - r * v)
        dv = (fy + gy) / m - (r * u - p * w)
        dw = (fz + gz) / m - (p * v - q * u)
        # Beard & McLain rotational equations (with Ixz)
        dp = self.g1 * p * q - self.g2 * q * r + self.g3 * ml + self.g4 * mn
        dq = self.g5 * p * r - self.g6 * (p * p - r * r) + mm / self.iyy
        dr = self.g7 * p * q - self.g1 * q * r + self.g4 * ml + self.g8 * mn
        # kinematics
        dpn = r00 * u + r01 * v + r02 * w
        dpe = r10 * u + r11 * v + r12 * w
        dpd = r20 * u + r21 * v + r22 * w
        # quaternion with mild norm-restoring term (Baumgarte-style)
        nerr = 1.0 - (q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3)
        k = 2.0
        dq0 = 0.5 * (-q1 * p - q2 * q - q3 * r) + k * nerr * q0
        dq1 = 0.5 * (q0 * p + q2 * r - q3 * q) + k * nerr * q1
        dq2 = 0.5 * (q0 * q - q1 * r + q3 * p) + k * nerr * q2
        dq3 = 0.5 * (q0 * r + q1 * q - q2 * p) + k * nerr * q3
        if out_aux is not None:
            out_aux["va"] = va
            out_aux["alpha"] = alpha
            out_aux["beta"] = beta
            out_aux["thrust"] = thrust
            out_aux["p_elec"] = p_elec
            # specific force (what an accelerometer measures), body axes
            out_aux["f_spec"] = ((fx) / m, fy / m, fz / m)
            qs = 0.5 * rho * va_s * va_s * self.model.geometry.area
            out_aux["lift"] = -(fz * math.cos(alpha)) + fx * math.sin(alpha) - thrust * math.sin(alpha)
            out_aux["drag"] = -(fx - thrust) * math.cos(alpha) - fz * math.sin(alpha)
            out_aux["qbar_s"] = qs
        return [dpn, dpe, dpd, du, dv, dw, dq0, dq1, dq2, dq3, dp, dq, dr]


def rk4_step(f, x, dt, *args):
    k1 = f(x, *args)
    x2 = [xi + 0.5 * dt * ki for xi, ki in zip(x, k1)]
    k2 = f(x2, *args)
    x3 = [xi + 0.5 * dt * ki for xi, ki in zip(x, k2)]
    k3 = f(x3, *args)
    x4 = [xi + dt * ki for xi, ki in zip(x, k3)]
    k4 = f(x4, *args)
    return [xi + dt / 6.0 * (a + 2 * b + 2 * c + d) for xi, a, b, c, d in zip(x, k1, k2, k3, k4)]


def rk4_step_aux(f, x, dt, ctl, wind, rho, aux):
    """RK4 step that also fills ``aux`` with outputs evaluated at the start-of-step state."""
    k1 = f(x, ctl, wind, rho, aux)
    h = 0.5 * dt
    k2 = f([xi + h * ki for xi, ki in zip(x, k1)], ctl, wind, rho)
    k3 = f([xi + h * ki for xi, ki in zip(x, k2)], ctl, wind, rho)
    k4 = f([xi + dt * ki for xi, ki in zip(x, k3)], ctl, wind, rho)
    s = dt / 6.0
    return [xi + s * (a + 2 * b + 2 * c + d) for xi, a, b, c, d in zip(x, k1, k2, k3, k4)]


def euler_step(f, x, dt, *args):
    k = f(x, *args)
    return [xi + dt * ki for xi, ki in zip(x, k)]


def normalize_and_check(x, max_rate=50.0, max_speed=200.0):
    """Quaternion normalisation plus numerical health checks; raises SimulationDivergence."""
    for v in x:
        if not math.isfinite(v):
            raise SimulationDivergence("non-finite state")
    q0, q1, q2, q3 = x[6:10]
    n = math.sqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3)
    if abs(n - 1.0) > 0.05:
        raise SimulationDivergence(f"quaternion norm drifted to {n:.4f}")
    x[6], x[7], x[8], x[9] = q0 / n, q1 / n, q2 / n, q3 / n
    if abs(x[10]) > max_rate or abs(x[11]) > max_rate or abs(x[12]) > max_rate:
        raise SimulationDivergence("angular rate out of physical range")
    if abs(x[3]) > max_speed or abs(x[4]) > max_speed or abs(x[5]) > max_speed:
        raise SimulationDivergence("speed out of physical range")
    return x


def specific_energy(x, wind_ne=(0.0, 0.0), airspeed: float | None = None):
    """Specific mechanical energy E_s = g h + V^2/2 (inertial speed by default)."""
    h = -x[2]
    if airspeed is None:
        v2 = x[3] * x[3] + x[4] * x[4] + x[5] * x[5]
    else:
        v2 = airspeed * airspeed
    return G * h + 0.5 * v2
