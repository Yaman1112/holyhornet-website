"""Lithium-polymer battery model: OCV(SOC), temperature-dependent internal resistance, voltage
sag, lumped thermal model, usable-energy and reserve estimates.

The OCV curve is a generic LiPo curve (typical published shape), not a characterised cell. Replace
with bench-measured data before using it for flight planning.
"""

from __future__ import annotations

import math

from ..aircraft.config import BatteryConfig

_SOC = [0.0, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00]
_OCV = [3.27, 3.50, 3.62, 3.70, 3.75, 3.79, 3.83, 3.87, 3.92, 3.98, 4.06, 4.18]


def ocv_cell(soc: float) -> float:
    s = max(0.0, min(1.0, soc))
    for i in range(1, len(_SOC)):
        if s <= _SOC[i]:
            a = (s - _SOC[i - 1]) / (_SOC[i] - _SOC[i - 1])
            return _OCV[i - 1] + a * (_OCV[i] - _OCV[i - 1])
    return _OCV[-1]


class Battery:
    def __init__(self, cfg: BatteryConfig):
        self.cfg = cfg
        self.soc = cfg.initial_soc
        self.temp_c = cfg.initial_temp_c
        self.current = 0.0
        self.voltage = self.ocv
        self.energy_out_wh = 0.0  # delivered at the terminals
        self.energy_loss_wh = 0.0  # I^2 R heat
        self.propulsion_wh = 0.0
        self.avionics_wh = 0.0
        self.power_limited = False
        self.depleted = False  # SOC exhausted or terminal voltage below cutoff: ESC/BMS cuts the load

    @property
    def ocv(self) -> float:
        return ocv_cell(self.soc) * self.cfg.cells_series

    @property
    def resistance(self) -> float:
        c = self.cfg
        cold = max(0.0, 25.0 - self.temp_c)
        return c.internal_resistance_cell_ohm * c.cells_series * (1 + c.resistance_temp_coeff * cold)

    def step(self, p_propulsion: float, dt: float) -> None:
        c = self.cfg
        if self.depleted:
            self.current, self.voltage = 0.0, self.ocv
            return
        p = p_propulsion + c.avionics_power_w
        voc, r = self.ocv, self.resistance
        disc = voc * voc - 4 * r * p
        self.power_limited = disc < 0
        i = (voc - math.sqrt(max(disc, 0.0))) / (2 * r) if p > 0 else 0.0
        self.current = i
        self.voltage = voc - i * r
        self.soc = max(0.0, self.soc - i * dt / (c.capacity_ah * 3600.0))
        e_out = self.voltage * i * dt / 3600.0
        self.energy_out_wh += e_out
        self.energy_loss_wh += i * i * r * dt / 3600.0
        if p > 0:
            self.propulsion_wh += e_out * p_propulsion / p
            self.avionics_wh += e_out * c.avionics_power_w / p
        if self.soc <= 0.0 or self.voltage / c.cells_series < c.cutoff_v_cell - 0.25:
            self.depleted = True
        heat = i * i * r - c.cooling_w_per_k * (self.temp_c - c.ambient_temp_c)
        self.temp_c += heat * dt / c.thermal_mass_j_per_k

    def usable_energy_wh(self, to_soc: float = 0.0, load_w: float = 60.0) -> float:
        """Energy available from current SOC down to ``to_soc`` (or cutoff voltage) at a constant load."""
        c = self.cfg
        e, s, ds = 0.0, self.soc, 0.01
        r = self.resistance
        while s - ds > to_soc:
            voc = ocv_cell(s) * c.cells_series
            disc = voc * voc - 4 * r * load_w
            if disc < 0:
                break
            i = (voc - math.sqrt(disc)) / (2 * r)
            v = voc - i * r
            if v / c.cells_series < c.cutoff_v_cell:
                break
            e += v * ds * c.capacity_ah
            s -= ds
        return e

    @property
    def nominal_energy_wh(self) -> float:
        c = self.cfg
        return sum(ocv_cell(s / 100) for s in range(0, 100)) / 100 * c.cells_series * c.capacity_ah

    def snapshot(self) -> dict:
        return {"soc": round(self.soc, 4), "voltage": round(self.voltage, 3), "current": round(self.current, 3),
                "temp_c": round(self.temp_c, 2), "energy_out_wh": round(self.energy_out_wh, 4),
                "propulsion_wh": round(self.propulsion_wh, 4), "power_limited": self.power_limited, "depleted": self.depleted}
