"""Layered flight control.

Level 1  actuators   : servo first-order lag, rate and deflection limits (``Actuators``)
Level 2  attitude    : roll / pitch PID with q-scheduled gains, yaw damper + turn coordination
Level 3  flight ctl  : airspeed-on-pitch, altitude/climb-on-throttle, course-to-bank
Level 4  guidance    : straight-line / orbit vector fields (``Guidance``) driven by the autonomy layer

Envelope protection sits *below* the autonomy layer and above Level 2: bank and load-factor
limits, a stall-margin airspeed floor and over-speed protection are always enforced, whatever
the soaring logic or any experimental policy requests.

The gains are a hand-tuned baseline verified by the step-response tests in tests/ and the
validation suite — not an optimised or formally robust design (LQR/MPC are roadmap items).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from pydantic import BaseModel

from ..aircraft import performance
from ..aircraft.model import G, AircraftModel
from ..dynamics.six_dof import Controls
from ..frames import wrap_pi


class AutopilotConfig(BaseModel):
    v_ref: float = 10.0  # gain-scheduling reference airspeed
    roll_kp: float = 1.4
    roll_ki: float = 0.4
    roll_kd: float = 0.0
    aileron_rudder_interconnect: float = 0.3  # cancels adverse yaw (dr = -k * da)
    pitch_kp: float = 0.9
    pitch_ki: float = 0.25
    pitch_kd: float = 0.10
    yaw_damper: float = 0.25
    turn_coord: float = 0.12  # rad rudder per m/s^2 lateral specific force
    turn_coord_ki: float = 0.15
    bank_slew_deg_s: float = 90.0
    orbit_k: float = 1.0
    orbit_kp: float = 0.022  # rad bank per m radial error
    orbit_kd: float = 0.07  # rad bank per m/s radial rate
    speed_kp: float = 0.045  # rad pitch per m/s
    speed_ki: float = 0.012
    course_k: float = 0.9  # rad bank per rad course error
    climb_kp: float = 0.18  # throttle per m/s climb error
    climb_ki: float = 0.05
    alt_k: float = 0.15  # m/s climb per m altitude error
    bank_max_deg: float = 45.0
    stall_margin: float = 1.18  # airspeed floor = margin * Vs(n)
    overspeed_fraction: float = 0.9


@dataclass
class GuidanceCommand:
    mode: str = "course"  # "course" | "orbit" | "wings_level" | "bank"
    bank: float = 0.0
    course: float = 0.0
    orbit_center: tuple[float, float] = (0.0, 0.0)
    orbit_radius: float = 30.0
    orbit_dir: int = 1  # +1 clockwise (right turn) seen from above
    airspeed: float = 10.0
    throttle_mode: str = "off"  # "off" | "fixed" | "climb" | "altitude"
    throttle: float = 0.0
    climb_rate: float = 0.0
    altitude: float = 0.0
    bank_limit_deg: float = 30.0  # cruise default; orbits pass their own limit
    air_frame: tuple[float, float] = (0.0, 0.0)  # orbit in the air mass moving with this (wind) velocity


@dataclass
class NavState:
    """Estimated state the controllers use (from sensors/estimators, never truth)."""

    n: float
    e: float
    h: float
    hdot: float
    vn: float
    ve: float
    roll: float
    pitch: float
    yaw: float
    p: float
    q: float
    r: float
    airspeed: float
    ay: float
    rho: float

    @property
    def course(self) -> float:
        return math.atan2(self.ve, self.vn)

    @property
    def groundspeed(self) -> float:
        return math.hypot(self.vn, self.ve)


class Actuators:
    def __init__(self, max_defl_rad: float, tau: float, rate_rad_s: float):
        self.max = max_defl_rad
        self.tau = tau
        self.rate = rate_rad_s
        self.state = Controls()

    def step(self, cmd: Controls, dt: float) -> Controls:
        s = self.state
        for name in ("aileron", "elevator", "rudder", "flap"):
            c = max(-self.max, min(self.max, getattr(cmd, name)))
            cur = getattr(s, name)
            d = (c - cur) * min(1.0, dt / self.tau)
            d = max(-self.rate * dt, min(self.rate * dt, d))
            setattr(s, name, cur + d)
        s.throttle += (max(0.0, min(1.0, cmd.throttle)) - s.throttle) * min(1.0, dt / 0.15)
        return s


@dataclass
class EnvelopeStatus:
    bank_limited: bool = False
    speed_floor_active: bool = False
    stall_recovery: bool = False
    overspeed: bool = False
    alpha_limited: bool = False
    interventions: int = 0
    log: list = field(default_factory=list)


class Autopilot:
    def __init__(self, model: AircraftModel, cfg: AutopilotConfig | None = None):
        self.model = model
        self.cfg = cfg or AutopilotConfig()
        self.i_roll = 0.0
        self.i_pitch = 0.0
        self.i_speed = 0.0
        self.i_climb = 0.0
        self.i_ay = 0.0
        self.phi_c_prev = 0.0
        self.theta_trim = math.radians(2.0)
        self.env = EnvelopeStatus()
        self.last_cmd = {}
        self._last_note: dict = {}
        self.n_max = model.cfg.n_max

    def reset_integrators(self):
        self.i_roll = self.i_pitch = self.i_speed = self.i_climb = self.i_ay = 0.0

    # ---------------------------------------------------------------- guidance (Level 4 helpers)
    @staticmethod
    def orbit_course(nav: NavState, center, radius, direction, k_orbit: float = 2.0) -> tuple[float, float]:
        """Beard & McLain orbit vector field. Returns (course command, distance-to-centre)."""
        dn, de = nav.n - center[0], nav.e - center[1]
        d = math.hypot(dn, de)
        ang = math.atan2(de, dn)
        chi = ang + direction * (math.pi / 2 + math.atan(k_orbit * (d - radius) / radius))
        return chi, d

    # ---------------------------------------------------------------- main loop
    def step(self, nav: NavState, gc: GuidanceCommand, dt: float, t: float) -> Controls:
        c = self.cfg
        m = self.model
        va = max(nav.airspeed, 3.0)
        sched = (c.v_ref / va) ** 2
        # ---------------- envelope limits
        speed_limited = False
        bank_lim = math.radians(min(gc.bank_limit_deg, c.bank_max_deg))
        bank_lim = min(bank_lim, math.acos(min(1.0, 1.0 / (0.9 * self.n_max))))
        vs1 = performance.stall_speed(m, nav.rho, 1.0)
        # bank allowed by current airspeed: Vs(n) * margin <= V  ->  n <= (V/(margin Vs1))^2
        n_allow = (va / (c.stall_margin * vs1)) ** 2
        if n_allow < 1.0 / math.cos(bank_lim):
            new_lim = math.acos(min(1.0, 1.0 / max(1.0, n_allow))) if n_allow > 1.0 else math.radians(5.0)
            if new_lim < bank_lim:
                bank_lim = new_lim
                speed_limited = True
        stall_recovery = va < 1.03 * vs1
        if stall_recovery:
            self._note(t, "stall_recovery", f"stall recovery: airspeed {va:.1f} m/s < 1.03 Vs ({vs1:.1f})")
        # ---------------- lateral: course / orbit -> bank
        phi_ff = 0.0
        chi_c = gc.course
        if gc.mode == "wings_level":
            phi_c = 0.0
        elif gc.mode == "bank":
            phi_c = gc.bank
        elif gc.mode == "orbit":
            # Orbit in the air-mass frame: a thermal drifts with the wind, so use air-relative velocity.
            wn, we = gc.air_frame
            avn, ave = nav.vn - wn, nav.ve - we
            air_course = math.atan2(ave, avn)
            nav_air = NavState(nav.n, nav.e, nav.h, nav.hdot, avn, ave, nav.roll, nav.pitch, nav.yaw, nav.p, nav.q, nav.r,
                               nav.airspeed, nav.ay, nav.rho)
            chi_v, d_c = self.orbit_course(nav_air, gc.orbit_center, gc.orbit_radius, gc.orbit_dir, c.orbit_k)
            chi_c = chi_v
            v_air = max(math.hypot(avn, ave), 2.0)
            R = gc.orbit_radius
            dn, de_ = nav.n - gc.orbit_center[0], nav.e - gc.orbit_center[1]
            ddot = (avn * dn + ave * de_) / max(d_c, 1.0)
            phi_near = gc.orbit_dir * (math.atan(v_air * v_air / (G * R)) + c.orbit_kp * (d_c - R) + c.orbit_kd * ddot)
            phi_far = c.course_k * wrap_pi(chi_v - air_course)
            tangent = math.atan2(de_, dn) + gc.orbit_dir * math.pi / 2
            align = math.cos(wrap_pi(air_course - tangent))
            w = max(0.0, min(1.0, 2.0 - abs(d_c - R) / (0.5 * R))) * max(0.0, min(1.0, 2.0 * align))
            phi_c = w * phi_near + (1 - w) * phi_far
        else:
            err = wrap_pi(chi_c - nav.course)
            phi_c = c.course_k * err
        if stall_recovery:
            phi_c = 0.0
        if abs(phi_c) > bank_lim + 1e-6 and speed_limited:
            self._note(t, "bank_limited", f"bank command {math.degrees(phi_c):.0f} deg limited to {math.degrees(bank_lim):.0f} deg by airspeed/stall margin")
        phi_c = max(-bank_lim, min(bank_lim, phi_c))
        slew = math.radians(c.bank_slew_deg_s) * dt
        phi_c = max(self.phi_c_prev - slew, min(self.phi_c_prev + slew, phi_c))
        self.phi_c_prev = phi_c
        self.env.bank_limited = abs(phi_c) >= bank_lim - 1e-6
        # roll loop (Level 2)
        e_roll = phi_c - nav.roll
        self.i_roll = max(-0.3, min(0.3, self.i_roll + e_roll * dt))
        da = sched * (c.roll_kp * e_roll + c.roll_ki * self.i_roll - c.roll_kd * nav.p)
        # yaw damper + coordination: body yaw rate of a coordinated turn r = g sin(phi) cos(theta) / V
        r_ref = G * math.sin(nav.roll) * math.cos(nav.pitch) / va
        self.i_ay = max(-0.15, min(0.15, self.i_ay + nav.ay * dt))
        dr = sched * (c.yaw_damper * (nav.r - r_ref)) + c.turn_coord * nav.ay + c.turn_coord_ki * self.i_ay - c.aileron_rudder_interconnect * da
        # ---------------- longitudinal
        n_turn = 1.0 / max(0.2, math.cos(nav.roll))
        v_floor = c.stall_margin * vs1 * math.sqrt(n_turn)
        v_cmd = gc.airspeed
        self.env.speed_floor_active = v_cmd < v_floor
        if v_cmd < v_floor:
            v_cmd = v_floor
        v_max = c.overspeed_fraction * m.cfg.vne_ms
        self.env.overspeed = va > v_max
        v_cmd = min(v_cmd, v_max)
        e_v = va - v_cmd  # too fast -> pitch up
        self.i_speed = max(-12.0, min(12.0, self.i_speed + e_v * dt))
        theta_c = self.theta_trim + c.speed_kp * e_v + c.speed_ki * self.i_speed
        if stall_recovery:
            theta_c = math.radians(-8.0)
            self.i_speed = min(self.i_speed, 0.0)
        theta_c = max(math.radians(-25), min(math.radians(25), theta_c))
        e_th = theta_c - nav.pitch
        self.i_pitch = max(-0.3, min(0.3, self.i_pitch + e_th * dt))
        # extra lift needed in a turn -> elevator feed-forward (positive de = nose down)
        de_ff = -0.08 * (n_turn - 1.0)
        de = -sched * (c.pitch_kp * e_th + c.pitch_ki * self.i_pitch - c.pitch_kd * nav.q) + de_ff * sched
        # angle-of-attack protection: never command more nose-up elevator than trims at alpha_max
        # (model-based limiter - the aircraft has no AoA vane). Pitch-rate term keeps margin in pull-ups.
        de_lim = m.de_alpha_max - 0.5 * m.cm_q / m.cm_de * nav.q * m.geometry.mac / (2 * va)
        self.env.alpha_limited = de < de_lim
        if de < de_lim:
            de = de_lim
            self.i_pitch = max(self.i_pitch - e_th * dt, -0.3)  # anti-windup
        # ---------------- throttle
        thr = 0.0
        if gc.throttle_mode == "fixed":
            thr = gc.throttle
        elif gc.throttle_mode in ("climb", "altitude"):
            hdot_c = gc.climb_rate if gc.throttle_mode == "climb" else max(-1.5, min(1.5, c.alt_k * (gc.altitude - nav.h)))
            e_c = hdot_c - nav.hdot
            self.i_climb = max(-1.5, min(3.0, self.i_climb + e_c * dt))
            thr = 0.35 + c.climb_kp * e_c + c.climb_ki * self.i_climb
            thr = max(0.0, min(1.0, thr))
        else:
            self.i_climb = 0.0
        if self.env.overspeed or stall_recovery:
            thr = 0.0 if self.env.overspeed else thr
        self.last_cmd = {"phi_c": phi_c, "theta_c": theta_c, "v_cmd": v_cmd, "chi_c": chi_c, "bank_lim": bank_lim}
        return Controls(aileron=da, elevator=de, rudder=dr, flap=0.0, throttle=thr)

    def _note(self, t: float, kind: str, msg: str):
        last = self._last_note.get(kind, -1e9)
        if t - last < 1.0:
            return
        self._last_note[kind] = t
        self.env.interventions += 1
        if not self.env.log or self.env.log[-1]["kind"] != kind or t - self.env.log[-1]["t"] > 5.0:
            self.env.log.append({"t": round(t, 2), "kind": kind, "message": msg})
