"""HolyHornet SkyTherm API (FastAPI).

Run:  uvicorn skytherm.api.main:app --app-dir backend --port 8700

Simulation-only service: there is no hardware mode and no endpoint can command an actuator.
(Hardware integration is a Phase-6 item and must arrive behind an explicit, separately
authenticated operator-authorisation path — see docs/SAFETY.md.)
"""

from __future__ import annotations

import asyncio
import csv
import io
import json
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse, Response
from pydantic import BaseModel

from .. import MODEL_VERSIONS, __version__
from ..aircraft import performance
from ..aircraft.config import AircraftConfig, BatteryConfig
from ..aircraft.model import AircraftModel
from ..atmosphere import isa
from ..atmosphere.environment import Atmosphere, AtmosphereConfig
from ..autonomy.soaring import TRANSITIONS, Mode
from ..dynamics.linearize import stability_report
from ..electronics.architecture import architecture
from ..energy.battery import Battery
from ..research.experiments import TEMPLATES, run_experiment, template
from ..research.store import Store
from ..simulation.runner import run_scenario
from ..simulation.scenarios import ScenarioConfig, preset_scenarios

app = FastAPI(title="HolyHornet SkyTherm API", version=__version__,
              description="Autonomous atmospheric-energy research UAV — simulation, estimation, autonomy and research data. Simulation only.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

store = Store()
_pool = ThreadPoolExecutor(max_workers=2)
_live: dict[str, dict] = {}  # run id -> {"frames": deque, "progress": float, "done": bool}
_validation: dict[str, Any] = {"status": "idle", "progress": 0.0, "report": None}
_lock = threading.Lock()


def deep_merge(base: dict, patch: dict) -> dict:
    out = dict(base)
    for k, v in patch.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


# ----------------------------------------------------------------------------------- meta
@app.get("/api/health")
def health():
    return {"ok": True, "version": __version__, "mode": "simulation-only"}


@app.get("/api/meta")
def meta():
    return {
        "product": "HolyHornet SkyTherm", "version": __version__, "model_versions": MODEL_VERSIONS,
        "modes": [m.value for m in Mode], "transitions": TRANSITIONS,
        "provenance_labels": {"measured": "from hardware sensors (none yet)", "estimated": "onboard estimator output",
                              "forecast": "prior/forecast products (e.g. forecast hotspots)", "simulated": "simulator ground truth"},
        "safety": ["Simulation only: no endpoint can command an actuator.", "SkyTherm is not certified aviation software.",
                   "Predicted atmospheric conditions are never guaranteed; simulated energy gains are not measured savings."],
    }


# ----------------------------------------------------------------------------------- aircraft
class AnalyzeRequest(BaseModel):
    aircraft: AircraftConfig = AircraftConfig()
    altitude_m: float = 300.0
    stability: bool = True


@app.get("/api/aircraft/default")
def aircraft_default():
    return AircraftConfig().model_dump()


@app.post("/api/aircraft/analyze")
def aircraft_analyze(req: AnalyzeRequest):
    m = AircraftModel(req.aircraft)
    out = m.summary()
    out["performance"] = performance.performance_summary(m, req.altitude_m)
    out["config_hash"] = req.aircraft.config_hash()
    if req.stability:
        try:
            out["stability"] = stability_report(m, (9.5, 11.0, 14.0, 18.0), req.altitude_m)
        except Exception as exc:  # trim can fail for extreme configs: report, don't crash
            out["stability_error"] = repr(exc)
    return out


class CompareRequest(BaseModel):
    configs: list[AircraftConfig]
    altitude_m: float = 300.0


@app.post("/api/aircraft/compare")
def aircraft_compare(req: CompareRequest):
    res = []
    for cfg in req.configs[:6]:
        m = AircraftModel(cfg)
        p = performance.performance_summary(m, req.altitude_m)
        res.append({"name": cfg.name, "hash": cfg.config_hash(), "mass_kg": m.mass.mass, "aspect_ratio": m.geometry.aspect_ratio,
                    "wing_area_m2": m.geometry.area, "stall_speed": p["stall_speed"], "best_glide": p["best_glide"], "min_sink": p["min_sink"],
                    "polar": [{"v": q["v"], "sink": q["sink"], "ld": q["ld"], "power_w": q["electric_power_level_w"]} for q in p["polar"]]})
    return res


# ----------------------------------------------------------------------------------- atmosphere
class FieldRequest(BaseModel):
    atmosphere: AtmosphereConfig = AtmosphereConfig()
    t: float = 0.0
    extent_m: float = 800.0
    step_m: float = 100.0
    heights: list[float] = [50, 150, 300, 500]


@app.post("/api/atmosphere/field")
def atmosphere_field(req: FieldRequest):
    atm = Atmosphere(req.atmosphere)
    ext = req.extent_m
    return {"grid": atm.field_grid(req.t, (-ext, ext), (-ext, ext), tuple(req.heights), max(25.0, req.step_m)),
            "thermals": atm.thermal_states(req.t), "profile": atm.profile(), "provenance": "simulated"}


# ----------------------------------------------------------------------------------- scenarios & runs
@app.get("/api/scenarios")
def scenarios():
    return [{"id": s.id, "name": s.name, "description": s.description, "kind": s.kind, "duration_s": s.duration_s,
             "config": s.model_dump(mode="json")} for s in preset_scenarios().values()]


class RunRequest(BaseModel):
    scenario_id: str = "milestone"
    overrides: dict = {}
    label: str = ""


def _execute(rid: str, cfg: ScenarioConfig):
    live = _live[rid]
    store.update_run(rid, status="running")

    def prog(f):
        live["progress"] = f
        store.update_run(rid, progress=round(f, 4))

    def on_frame(fr):
        live["frames"].append(fr)

    try:
        res = run_scenario(cfg, prog, on_frame)
        res["meta"]["run_id"] = rid
        store.save_result(rid, res)
        store.update_run(rid, status="done", progress=1.0, summary=res.get("summary", {}))
    except Exception as exc:
        store.update_run(rid, status="error", error=repr(exc))
    finally:
        live["done"] = True


@app.post("/api/runs")
def create_run(req: RunRequest):
    presets = preset_scenarios()
    if req.scenario_id not in presets:
        raise HTTPException(404, f"unknown scenario {req.scenario_id}")
    base = presets[req.scenario_id].model_dump(mode="json")
    try:
        cfg = ScenarioConfig.model_validate(deep_merge(base, req.overrides))
    except Exception as exc:
        raise HTTPException(422, f"invalid overrides: {exc}")
    rid = store.create_run(cfg, req.label)
    _live[rid] = {"frames": deque(maxlen=20000), "progress": 0.0, "done": False}
    _pool.submit(_execute, rid, cfg)
    return {"id": rid, "config_hash": cfg.config_hash()}


@app.get("/api/runs")
def list_runs(limit: int = 100):
    return store.list_runs(limit)


@app.get("/api/runs/{rid}")
def get_run(rid: str):
    r = store.get_run(rid)
    if not r:
        raise HTTPException(404, "run not found")
    return r


@app.get("/api/runs/{rid}/result")
def get_result(rid: str):
    r = store.load_result(rid)
    if r is None:
        raise HTTPException(404, "result not available (run pending, failed or unknown)")
    return r


@app.delete("/api/runs/{rid}")
def delete_run(rid: str):
    store.delete_run(rid)
    return {"deleted": rid}


@app.post("/api/runs/{rid}/rerun")
def rerun(rid: str):
    r = store.get_run(rid)
    if not r:
        raise HTTPException(404, "run not found")
    cfg = ScenarioConfig.model_validate(r["config"])
    nid = store.create_run(cfg, f"re-run of {rid}")
    _live[nid] = {"frames": deque(maxlen=20000), "progress": 0.0, "done": False}
    _pool.submit(_execute, nid, cfg)
    return {"id": nid, "config_hash": cfg.config_hash(), "original_hash": r["config_hash"]}


FRAME_COLS = ["t", "n", "e", "h", "roll", "pitch", "yaw", "va", "vg", "vz", "alpha", "beta", "da", "de", "dr", "thr", "mode",
              "netto_est", "netto_sigma", "w_air_true", "updraft_true", "es_true", "es_air_true", "soc", "v_batt", "i_batt", "p_elec", "e_prop_wh", "ld"]


@app.get("/api/runs/{rid}/export")
def export_run(rid: str, format: str = "csv"):
    r = store.load_result(rid)
    if r is None:
        raise HTTPException(404, "result not available")
    if format == "json":
        return Response(json.dumps(r), media_type="application/json",
                        headers={"Content-Disposition": f'attachment; filename="{rid}.json"'})
    if "frames" not in r:
        raise HTTPException(400, "this run has no frame log (dynamic-soaring report) — use format=json")
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(FRAME_COLS + ["wind_est_n", "wind_est_e", "wind_true_n", "wind_true_e"])
    for f in r["frames"]:
        w.writerow([f.get(c) for c in FRAME_COLS] + [*f["wind_est"], *f["wind_true"]])
    return PlainTextResponse(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{rid}.csv"'})


@app.websocket("/ws/runs/{rid}")
async def ws_run(ws: WebSocket, rid: str):
    """Live telemetry: streams frames of a running simulation (every 2nd frame) plus progress."""
    await ws.accept()
    live = _live.get(rid)
    if live is None:
        await ws.send_json({"type": "error", "message": "run not live (finished before this server started?)"})
        await ws.close()
        return
    idx = 0
    try:
        while True:
            frames = list(live["frames"])
            batch = frames[idx::2] if idx < len(frames) else []
            idx = len(frames)
            await ws.send_json({"type": "progress", "progress": live["progress"], "frames": batch[-50:]})
            if live["done"]:
                await ws.send_json({"type": "done"})
                break
            await asyncio.sleep(0.25)
    except WebSocketDisconnect:
        return
    await ws.close()


# ----------------------------------------------------------------------------------- dynamic soaring
class DSRequest(BaseModel):
    params: dict = {}
    objective: str = "min_wind"
    w_ref: float | None = None


@app.post("/api/dynamic-soaring/optimize")
def ds_optimize(req: DSRequest):
    from ..dynamic_soaring.model import DSParams, optimize_cycle, wind_profile_table

    p = DSParams(**req.params)
    r = optimize_cycle(p, req.objective, w_ref=req.w_ref)
    r["wind_profile"] = wind_profile_table(p)
    r["params"] = p.model_dump(mode="json", exclude={"aircraft"})
    return r


@app.post("/api/dynamic-soaring/sweep")
def ds_sweep(req: DSRequest):
    from ..dynamic_soaring.model import DSParams, energy_sweep

    return energy_sweep(DSParams(**req.params))


# ----------------------------------------------------------------------------------- energy
class EnergyRequest(BaseModel):
    aircraft: AircraftConfig = AircraftConfig()
    altitude_m: float = 300.0
    mission_s: float = 1800.0


@app.post("/api/energy/model")
def energy_model(req: EnergyRequest):
    m = AircraftModel(req.aircraft)
    rho = isa.density(req.altitude_m)
    pc = req.aircraft.propulsion
    perf = performance.performance_summary(m, req.altitude_m)
    bg = perf["best_glide"]
    p_level = bg["power_required_w"] / (pc.prop_efficiency * pc.motor_esc_efficiency)
    w = m.mass.mass * 9.80665
    climb_rate = 2.0
    p_climb = (bg["power_required_w"] + w * climb_rate) / (pc.prop_efficiency * pc.motor_esc_efficiency)
    av = req.aircraft.battery.avionics_power_w
    T = req.mission_s
    # first-order mission strategies (analytic estimates — the 6-DOF runs give the simulated numbers)
    sink = bg["sink"]
    strategies = [
        {"strategy": "Continuous powered flight (level, best-L/D speed)", "propulsion_wh": p_level * T / 3600},
        {"strategy": "Powered climb + glide cycles (sawtooth)", "propulsion_wh": (p_climb * (sink * T / climb_rate)) / 3600},
        {"strategy": "Thermal-assisted (50 % of altitude loss recovered in lift)", "propulsion_wh": 0.5 * (p_climb * (sink * T / climb_rate)) / 3600},
    ]
    for s in strategies:
        s["total_wh"] = s["propulsion_wh"] + av * T / 3600
        s["provenance"] = "estimated (first-order energy model)"
    b = Battery(req.aircraft.battery)
    curve = []
    bb = Battery(req.aircraft.battery)
    for k in range(0, 2400):
        bb.step(p_climb if k < 120 else 6.0, 1.0)
        if k % 20 == 0:
            curve.append({"t": k, "soc": bb.soc, "v": bb.voltage, "i": bb.current, "temp": bb.temp_c})
        if bb.depleted:
            break
    return {"level_power_w": p_level, "climb_power_w": p_climb, "climb_rate_ms": climb_rate, "avionics_w": av,
            "nominal_energy_wh": b.nominal_energy_wh, "usable_to_reserve_wh": b.usable_energy_wh(0.25, p_level),
            "endurance_powered_min": b.usable_energy_wh(0.25, p_level + av) / (p_level + av) * 60,
            "power_vs_speed": [{"v": q["v"], "power_w": q["electric_power_level_w"], "sink": q["sink"]} for q in perf["polar"]],
            "strategies": strategies, "battery_curve": curve, "provenance": "estimated"}


# ----------------------------------------------------------------------------------- experiments
@app.get("/api/experiments/templates")
def exp_templates():
    return TEMPLATES


class ExperimentRequest(BaseModel):
    template: str
    title: str | None = None
    hypothesis: str | None = None
    values: list | None = None
    seeds: list[int] | None = None


def _run_exp(eid: str, definition: dict):
    store.update_experiment(eid, status="running")
    try:
        res = run_experiment(definition, lambda f: store.update_experiment(eid, progress=round(f, 3)))
        store.update_experiment(eid, status=res["status"], progress=1.0, results=res, conclusions=res["conclusions"],
                                limitations="\n".join(definition.get("limitations", [])))
    except Exception as exc:
        store.update_experiment(eid, status="error", conclusions=repr(exc))


@app.post("/api/experiments")
def create_experiment(req: ExperimentRequest):
    try:
        t = dict(template(req.template))
    except KeyError:
        raise HTTPException(404, "unknown template")
    if req.values is not None:
        t["values"] = req.values
    if req.seeds is not None:
        t["seeds"] = req.seeds
    eid = store.create_experiment(t["id"], req.title or t["title"], req.hypothesis or t["hypothesis"], t, MODEL_VERSIONS["autonomy"])
    threading.Thread(target=_run_exp, args=(eid, t), daemon=True).start()
    return {"id": eid}


@app.get("/api/experiments")
def list_experiments():
    return store.list_experiments()


@app.get("/api/experiments/{eid}")
def get_experiment(eid: str):
    e = store.get_experiment(eid)
    if not e:
        raise HTTPException(404, "experiment not found")
    return e


class ExperimentUpdate(BaseModel):
    conclusions: str | None = None
    limitations: str | None = None


@app.patch("/api/experiments/{eid}")
def update_experiment(eid: str, req: ExperimentUpdate):
    fields = {k: v for k, v in req.model_dump().items() if v is not None}
    if fields:
        store.update_experiment(eid, **fields)
    return store.get_experiment(eid)


@app.delete("/api/experiments/{eid}")
def delete_experiment(eid: str):
    store.delete_experiment(eid)
    return {"deleted": eid}


@app.get("/api/experiments/{eid}/export")
def export_experiment(eid: str, format: str = "csv"):
    e = store.get_experiment(eid)
    if not e or not e.get("results"):
        raise HTTPException(404, "no results")
    if format == "json":
        return Response(json.dumps(e), media_type="application/json", headers={"Content-Disposition": f'attachment; filename="{eid}.json"'})
    rows = e["results"]["rows"]
    buf = io.StringIO()
    if rows:
        w = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return PlainTextResponse(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{eid}.csv"'})


# ----------------------------------------------------------------------------------- validation
@app.post("/api/validation/run")
def validation_run(monte_carlo: bool = True):
    from ..validation.suite import run_suite

    with _lock:
        if _validation["status"] == "running":
            return {"status": "running"}
        _validation.update(status="running", progress=0.0)

    def job():
        try:
            rep = run_suite(monte_carlo, lambda f: _validation.update(progress=f))
            _validation.update(status="done", report=rep, progress=1.0)
            (store.dir / "validation_latest.json").write_text(json.dumps(rep, indent=1))
        except Exception as exc:
            _validation.update(status="error", report={"error": repr(exc)})

    threading.Thread(target=job, daemon=True).start()
    return {"status": "running"}


@app.get("/api/validation/latest")
def validation_latest():
    rep = _validation["report"]
    if rep is None:
        p = store.dir / "validation_latest.json"
        if p.exists():
            rep = json.loads(p.read_text())
    return {"status": _validation["status"], "progress": _validation["progress"], "report": rep}


# ----------------------------------------------------------------------------------- electronics & configs
@app.get("/api/electronics")
def electronics():
    return architecture()


class ConfigSave(BaseModel):
    kind: str
    name: str
    body: dict


@app.post("/api/configs")
def save_config(req: ConfigSave):
    if req.kind == "aircraft":
        AircraftConfig.model_validate(req.body)
    elif req.kind == "scenario":
        ScenarioConfig.model_validate(req.body)
    return store.save_config(req.kind, req.name, req.body)


@app.get("/api/configs")
def list_configs(kind: str | None = None):
    return store.list_configs(kind)


@app.get("/api/configs/{cid}")
def get_config(cid: str):
    c = store.get_config(cid)
    if not c:
        raise HTTPException(404, "config not found")
    return c


@app.get("/api/battery/curve")
def battery_curve(power_w: float = 60.0):
    b = Battery(BatteryConfig())
    out = []
    t = 0
    while not b.depleted and t < 4 * 3600:
        b.step(power_w, 5.0)
        t += 5
        if t % 60 == 0:
            out.append({"t": t, "soc": b.soc, "v": b.voltage, "temp": b.temp_c})
    return out
