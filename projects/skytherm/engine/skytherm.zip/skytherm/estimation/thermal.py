"""Thermal estimation: 4-state EKF (centre, strength, radius) and an uncertainty-aware thermal map.

EKF state ``x = [xc, yc, W, R]`` with measurement model (Gaussian updraft)
    z = W exp(-((pn - xc)^2 + (pe - yc)^2) / R^2) + v,     v ~ N(0, sigma_netto^2)
The centre is propagated with the *estimated* wind (thermals drift with the air mass), so drift is
handled by the process model instead of being treated as estimation error. The truth model is a
Gedeon bell with a sink ring, so there is deliberate model mismatch (as there would be in reality).

A thermal record moves through explicit statuses:
    candidate  -> netto above detection threshold for the persistence time (not yet a thermal)
    confirmed  -> EKF converged (centre sigma below limit) AND a sustained achieved climb
    exploited  -> left after use (still on the map, decays with age)
    rejected   -> investigated, no persistent lift found (false/transient detection)
Confidence is a heuristic in [0, 1] combining EKF covariance, sample count and achieved climb; its
calibration is checked in the validation suite, not assumed.
"""

from __future__ import annotations

import math

import numpy as np


class ThermalEKF:
    """6-state EKF: x = [xc, yc, vn_drift, ve_drift, W, R].

    The drift velocity is estimated (initialised from the wind estimate) because a thermal moves
    with the mean wind of the layer it rises through, which differs from the wind measured at the
    aircraft's altitude (shear + veer). Measurement: Gaussian updraft at the lag-compensated
    aircraft position.
    """

    def __init__(self, xc: float, yc: float, w0: float = 1.0, r0: float = 50.0, drift=(0.0, 0.0),
                 profile: str = "gaussian", netto_floor: float | None = None, w_floor: float = 0.2):
        # profile: "gaussian" w = W exp(-q) (R = e-folding radius) or "gedeon" w = W exp(-q)(1-q)
        # (R = zero-lift radius, sink ring outside). netto_floor clips readings from below so a
        # Gaussian model is not dragged by sink-ring readings it cannot represent.
        self.profile = profile
        self.w_floor = w_floor
        self.netto_floor = netto_floor
        self.x = np.array([xc, yc, drift[0], drift[1], w0, r0], dtype=float)
        self.P = np.diag([40.0 ** 2, 40.0 ** 2, 0.7 ** 2, 0.7 ** 2, 1.0 ** 2, 25.0 ** 2])
        self.Q = np.diag([0.1, 0.1, 0.0005, 0.0005, 0.002, 0.05])  # per second (tuned: tests/test_estimation.py)
        self.n_updates = 0
        self.nis_avg = 1.0

    def predict(self, dt: float, wind_ne=None):
        self.x[0] += self.x[2] * dt
        self.x[1] += self.x[3] * dt
        F = np.eye(6)
        F[0, 2] = dt
        F[1, 3] = dt
        self.P = F @ self.P @ F.T + self.Q * dt

    def update(self, pn: float, pe: float, z: float, sigma: float):
        xc, yc, _, _, w, r = self.x
        r = max(r, 8.0)
        dx, dy = pn - xc, pe - yc
        q = (dx * dx + dy * dy) / (r * r)
        e = math.exp(-q)
        if self.netto_floor is not None:
            z = max(z, self.netto_floor)
        if self.profile == "gedeon":
            g = w * e * (2.0 - q)  # -dh/dq
            h = w * e * (1.0 - q)
            H = np.array([g * 2 * dx / (r * r), g * 2 * dy / (r * r), 0.0, 0.0, e * (1.0 - q), g * 2 * q / r])
        else:
            h = w * e
            H = np.array([w * e * 2 * dx / (r * r), w * e * 2 * dy / (r * r), 0.0, 0.0, e, w * e * 2 * q / r])
        sigma = max(sigma, 0.45)  # floor: TE-compensation + turbulence errors are larger than sensor noise
        S = float(H @ self.P @ H) + sigma * sigma
        K = self.P @ H / S
        innov = z - h
        nis = innov * innov / S
        if nis > 16.0:  # gate gross outliers (turbulence spikes)
            innov *= 4.0 / math.sqrt(nis)
        self.x = self.x + K * innov
        I_KH = np.eye(6) - np.outer(K, H)
        self.P = I_KH @ self.P @ I_KH.T + np.outer(K, K) * sigma * sigma  # Joseph form
        # W floor: a tracked candidate with negative core strength flips the gradient and the centre
        # runs away (observed at 6 m/s wind); dead air is handled by the climb-based exit logic instead
        self.x[4] = min(max(self.x[4], self.w_floor), 6.0)
        self.x[5] = min(max(self.x[5], 25.0), 200.0)
        sp = math.hypot(self.x[2], self.x[3])
        if sp > 15.0:
            self.x[2:4] *= 15.0 / sp
        self.n_updates += 1
        self.nis_avg += (nis - self.nis_avg) * 0.02
        # consistency guard: persistent large normalised innovations mean the model does not fit
        # (wrong centre, not a thermal, strong turbulence) -> inflate covariance instead of trusting it
        if self.nis_avg > 3.0:
            self.P *= 1.02

    def position_fix(self, n: float, e: float, sigma: float):
        """Linear pseudo-measurement of the centre (e.g. from the per-circle lift harmonic)."""
        for i, v in ((0, n), (1, e)):
            H = np.zeros(6)
            H[i] = 1.0
            S = self.P[i, i] + sigma * sigma
            K = self.P[:, i] / S
            self.x = self.x + K * (v - self.x[i])
            self.P = self.P - np.outer(K, H @ self.P)

    def lift_slope(self, r: float) -> float:
        """|dw/dr| of the fitted profile at distance r from the centre."""
        w, R = float(self.x[4]), max(float(self.x[5]), 8.0)
        q = r * r / (R * R)
        if self.profile == "gedeon":
            return abs(w * math.exp(-q) * (2.0 - q) * 2 * r / (R * R))
        return abs(w * math.exp(-q) * 2 * r / (R * R))

    def anchor_drift(self, wind_ne, sigma: float = 1.0, max_dev: float = 2.0):
        """Pseudo-measurement drift ~= wind (sigma m/s) plus a hard bound on the deviation.

        Without it the centre/drift correlation can run away: a lagging centre estimate pushes the
        drift the wrong way, the orbit follows, the aircraft leaves the core and low readings
        reinforce the error (observed in closed-loop runs before this anchor was added).
        """
        for i, w in ((2, wind_ne[0]), (3, wind_ne[1])):
            H = np.zeros(6)
            H[i] = 1.0
            S = self.P[i, i] + sigma * sigma
            K = self.P[:, i] / S
            self.x = self.x + K * (w - self.x[i])
            self.P = self.P - np.outer(K, H @ self.P)
        dev = np.array([self.x[2] - wind_ne[0], self.x[3] - wind_ne[1]])
        m = float(np.hypot(*dev))
        if m > max_dev:
            self.x[2] = wind_ne[0] + dev[0] * max_dev / m
            self.x[3] = wind_ne[1] + dev[1] * max_dev / m

    @property
    def pos_sigma(self) -> float:
        return math.sqrt(max(0.0, 0.5 * (self.P[0, 0] + self.P[1, 1])))

    @property
    def drift(self) -> tuple[float, float]:
        return float(self.x[2]), float(self.x[3])

    def snapshot(self) -> dict:
        return {
            "n": float(self.x[0]), "e": float(self.x[1]), "drift_n": float(self.x[2]), "drift_e": float(self.x[3]),
            "strength": float(self.x[4]), "radius": float(self.x[5]),
            "sigma_pos": self.pos_sigma, "sigma_strength": math.sqrt(max(0.0, self.P[4, 4])),
            "sigma_radius": math.sqrt(max(0.0, self.P[5, 5])), "sigma_drift": math.sqrt(max(0.0, 0.5 * (self.P[2, 2] + self.P[3, 3]))),
            "cov_ne": [[float(self.P[0, 0]), float(self.P[0, 1])], [float(self.P[1, 0]), float(self.P[1, 1])]],
        }


class ThermalRecord:
    def __init__(self, t: float, n: float, e: float, h: float, source: str = "detected"):
        self.id = "E?"  # assigned by ThermalMap.add (per-run numbering keeps runs reproducible)
        self.status = "candidate"
        self.source = source
        self.t_first = t
        self.t_last = t
        self.n, self.e = n, e
        self.strength = 0.0
        self.radius = 50.0
        self.sigma_pos = 60.0
        self.drift = (0.0, 0.0)
        self.h_min = h
        self.h_max = h
        self.climb_achieved = 0.0
        self.confidence = 0.1
        self.history: list[dict] = []
        self.notes: list[str] = []

    def update_from_ekf(self, t: float, ekf: ThermalEKF, h: float, drift, climb_avg: float):
        s = ekf.snapshot()
        drift = (s["drift_n"], s["drift_e"])
        self.n, self.e = s["n"], s["e"]
        self.strength, self.radius, self.sigma_pos = s["strength"], s["radius"], s["sigma_pos"]
        self.drift = drift
        self.t_last = t
        self.h_min, self.h_max = min(self.h_min, h), max(self.h_max, h)
        self.climb_achieved = climb_avg
        self.confidence = self.compute_confidence(ekf.n_updates, climb_avg)
        if not self.history or t - self.history[-1]["t"] >= 2.0:
            self.history.append({"t": round(t, 1), "n": round(self.n, 1), "e": round(self.e, 1), "strength": round(self.strength, 3),
                                 "radius": round(self.radius, 1), "sigma_pos": round(self.sigma_pos, 1),
                                 "confidence": round(self.confidence, 3), "h": round(h, 1), "climb": round(climb_avg, 3)})

    def compute_confidence(self, n_updates: int, climb_avg: float) -> float:
        c_samples = 1 - math.exp(-n_updates / 120.0)
        c_cov = math.exp(-self.sigma_pos / 25.0)
        c_lift = 1 / (1 + math.exp(-(self.strength - 0.6) / 0.25))
        c_climb = 1 / (1 + math.exp(-(climb_avg + 0.1) / 0.15))
        return max(0.0, min(1.0, c_samples * (0.35 + 0.65 * c_cov) * c_lift * (0.4 + 0.6 * c_climb)))

    def predicted_position(self, t: float) -> tuple[float, float]:
        dt = t - self.t_last
        return self.n + self.drift[0] * dt, self.e + self.drift[1] * dt

    def as_dict(self, t_now: float | None = None) -> dict:
        pn, pe = self.predicted_position(t_now) if t_now is not None else (self.n, self.e)
        return {
            "id": self.id, "status": self.status, "source": self.source, "provenance": "estimated",
            "n": round(self.n, 2), "e": round(self.e, 2), "predicted_n": round(pn, 2), "predicted_e": round(pe, 2),
            "strength": round(self.strength, 3), "radius": round(self.radius, 1), "sigma_pos": round(self.sigma_pos, 1),
            "drift_n": round(self.drift[0], 3), "drift_e": round(self.drift[1], 3),
            "h_min": round(self.h_min, 1), "h_max": round(self.h_max, 1), "climb_achieved": round(self.climb_achieved, 3),
            "confidence": round(self.confidence, 3), "t_first": round(self.t_first, 1), "t_last": round(self.t_last, 1),
            "history": self.history, "notes": self.notes,
        }


class ThermalMap:
    def __init__(self):
        self.records: list[ThermalRecord] = []

    def add(self, rec: ThermalRecord) -> ThermalRecord:
        rec.id = f"E{len(self.records) + 1}"
        self.records.append(rec)
        return rec

    def usable(self, t: float, max_age: float = 600.0) -> list[ThermalRecord]:
        return [r for r in self.records if r.status in ("confirmed", "exploited") and t - r.t_last < max_age]

    def as_list(self, t: float) -> list[dict]:
        return [r.as_dict(t) for r in self.records]
