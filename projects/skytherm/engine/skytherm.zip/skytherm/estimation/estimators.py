"""Onboard estimators — they only consume ``Measurements`` (never simulator truth).

* ``Variometer``: total-energy-compensated "netto" variometer — the estimated vertical air velocity
      w_air ~= dh/dt + (V/g) dV/dt + V_sink(V, n)
  dh/dt comes from a 2-state Kalman filter fusing barometric (or GNSS, after a baro fault) altitude
  with accelerometer vertical acceleration; V_sink(V, n) is the *model* polar at the measured load
  factor n. Sign convention: positive = rising air. This is an estimator with known error sources
  (polar error, unmodelled manoeuvre energy, sensor noise) and it reports its own uncertainty.
* ``WindEstimator``: 2-state Kalman filter on horizontal wind from GNSS ground velocity minus the
  air-relative velocity (airspeed, attitude, model angle of attack, sideslip assumed zero), plus an
  altitude-binned wind profile. A single pitot + GNSS cannot observe a full 3-D wind field — this
  estimates the horizontal wind *along the flown path* only.
"""

from __future__ import annotations

import math

import numpy as np

from ..aircraft import performance
from ..aircraft.model import G, AircraftModel
from ..atmosphere import isa


class SinkTable:
    """Pre-tabulated model polar sink(V, n) for fast bilinear lookup in the loop."""

    def __init__(self, model: AircraftModel, rho: float, polar_error: float = 0.0):
        self.v0, self.dv, self.nv = 5.0, 0.25, 121
        self.n0, self.dn, self.nn = 0.6, 0.1, 30
        self.tab = []
        for i in range(self.nv):
            v = self.v0 + i * self.dv
            row = []
            for j in range(self.nn):
                n = self.n0 + j * self.dn
                s = performance.sink_rate(model, v, rho, n)
                row.append(s * (1.0 + polar_error))
            self.tab.append(row)

    def __call__(self, v: float, n: float) -> float:
        fi = (min(max(v, self.v0), self.v0 + (self.nv - 1.001) * self.dv) - self.v0) / self.dv
        fj = (min(max(n, self.n0), self.n0 + (self.nn - 1.001) * self.dn) - self.n0) / self.dn
        i, j = int(fi), int(fj)
        a, b = fi - i, fj - j
        t = self.tab
        return (t[i][j] * (1 - a) * (1 - b) + t[i + 1][j] * a * (1 - b) + t[i][j + 1] * (1 - a) * b + t[i + 1][j + 1] * a * b)


class Variometer:
    def __init__(self, sink_table: SinkTable, tau_netto: float = 0.8):
        self.sink = sink_table
        self.h = None
        self.hd = 0.0
        self.P = [[25.0, 0.0], [0.0, 4.0]]
        self.v_f = None
        self.vd_f = 0.0
        self.n_f = 1.0
        self.netto = 0.0
        self.netto_fast = 0.0
        self.te = 0.0
        self.tau = tau_netto
        self.var_resid = 0.04
        self.source = "baro"

    def update(self, dt, alt_meas, alt_sigma, accel_body, roll, pitch, airspeed):
        # vertical acceleration (up positive) from specific force rotated to level frame
        ax, ay, az = accel_body
        cr, sr, cp, sp = math.cos(roll), math.sin(roll), math.cos(pitch), math.sin(pitch)
        f_down = -sp * ax + sr * cp * ay + cr * cp * az
        a_up = -(f_down + G)
        if self.h is None:
            self.h = alt_meas
        # predict
        h_pred = self.h + self.hd * dt + 0.5 * a_up * dt * dt
        hd_pred = self.hd + a_up * dt
        q_acc = 0.5 ** 2  # accel noise + unmodelled
        p00, p01, p11 = self.P[0][0], self.P[0][1], self.P[1][1]
        p00 = p00 + dt * (2 * p01 + dt * p11) + 0.25 * dt ** 4 * q_acc
        p01 = p01 + dt * p11 + 0.5 * dt ** 3 * q_acc
        p11 = p11 + dt * dt * q_acc
        # update with altitude
        r = alt_sigma * alt_sigma
        s = p00 + r
        k0, k1 = p00 / s, p01 / s
        y = alt_meas - h_pred
        self.h = h_pred + k0 * y
        self.hd = hd_pred + k1 * y
        self.P = [[(1 - k0) * p00, (1 - k0) * p01], [(1 - k0) * p01, p11 - k1 * p01]]
        # airspeed derivative for TE compensation
        if airspeed is not None:
            if self.v_f is None:
                self.v_f = airspeed
            v_old = self.v_f
            self.v_f += (airspeed - self.v_f) * min(1.0, dt / 0.3)
            self.vd_f += ((self.v_f - v_old) / dt - self.vd_f) * min(1.0, dt / 0.5)
        v = self.v_f or 10.0
        n_meas = max(0.3, -az / G)
        self.n_f += (n_meas - self.n_f) * min(1.0, dt / 0.4)
        self.te = self.hd + v * self.vd_f / G
        raw = self.te + self.sink(v, self.n_f)
        self.netto_fast += (raw - self.netto_fast) * min(1.0, dt / 0.3)
        self.netto += (raw - self.netto) * min(1.0, dt / self.tau)
        self.var_resid += ((raw - self.netto) ** 2 - self.var_resid) * min(1.0, dt / 5.0)
        return self.netto

    @property
    def sigma(self) -> float:
        """1-sigma uncertainty of the netto estimate: filter variance + polar error floor + turbulence spread."""
        return math.sqrt(self.P[1][1] + 0.1 ** 2 + 0.25 * self.var_resid)


class WindEstimator:
    def __init__(self, model: AircraftModel, q_rw: float = 0.03):
        self.model = model
        self.x = [0.0, 0.0]
        self.P = [[25.0, 0.0], [0.0, 25.0]]
        self.q = q_rw
        self.bins: dict[int, list[float]] = {}  # 50 m bins: [count, sum_n, sum_e]
        self.updates = 0

    def predict(self, dt: float, inflate: float = 1.0):
        qq = self.q * self.q * dt * inflate
        self.P[0][0] += qq
        self.P[1][1] += qq

    def air_velocity_ned(self, airspeed, roll, pitch, yaw, rho):
        m = self.model
        cl_req = 2 * m.mass.mass * G / (rho * airspeed * airspeed * m.geometry.area)
        alpha = max(-0.1, min(m.alpha_stall, m.alpha_for_cl(min(cl_req, m.cl_max))))
        ub, wb = airspeed * math.cos(alpha), airspeed * math.sin(alpha)
        cr, sr, cp, sp, cy, sy = math.cos(roll), math.sin(roll), math.cos(pitch), math.sin(pitch), math.cos(yaw), math.sin(yaw)
        # body->NED for vector (ub, 0, wb)
        vn = cp * cy * ub + (cr * sp * cy + sr * sy) * wb
        ve = cp * sy * ub + (cr * sp * sy - sr * cy) * wb
        return vn, ve

    def update(self, gnss_vel, airspeed, roll, pitch, yaw, alt, sigma_heading=0.03):
        rho = isa.density(alt)
        an, ae = self.air_velocity_ned(airspeed, roll, pitch, yaw, rho)
        zn, ze = gnss_vel[0] - an, gnss_vel[1] - ae
        r = 0.4 ** 2 + (airspeed * sigma_heading) ** 2
        for i, z in ((0, zn), (1, ze)):
            s = self.P[i][i] + r
            k = self.P[i][i] / s
            self.x[i] += k * (z - self.x[i])
            self.P[i][i] *= (1 - k)
        self.updates += 1
        b = int(max(0.0, alt) // 50)
        acc = self.bins.setdefault(b, [0.0, 0.0, 0.0])
        acc[0] += 1
        acc[1] += zn
        acc[2] += ze

    @property
    def sigma(self) -> float:
        return math.sqrt(0.5 * (self.P[0][0] + self.P[1][1]))

    def drift_prior(self, h_now: float, zi_m: float, alpha_prior: float = 0.14, alpha_prior_sigma: float = 0.07,
                    veer_prior_deg_100m: float = 1.0, veer_prior_sigma_deg_100m: float = 1.5, min_span_m: float = 150.0) -> dict:
        """Shear-aware prior for thermal drift: estimated wind averaged over the mixed layer.

        A thermal drifts with the mean wind of the layer it rises through, not the wind at the
        aircraft. The local filtered wind is extrapolated over [0.1 zi, 0.9 zi] with a power-law
        speed profile and a linear veer. Exponent and veer are fitted to the 50 m-binned wind
        samples when they span >= ``min_span_m`` of height, blended with the priors otherwise
        (1/7-type exponent; mild clockwise Ekman veering for the northern hemisphere). The
        returned sigma covers the local wind uncertainty plus the extrapolation uncertainty.
        Provenance: *estimated* (on-board), using a *forecast/configured* zi.
        """
        wn, we = self.x
        spd0 = math.hypot(wn, we)
        h0 = max(30.0, h_now)
        th0 = math.atan2(we, wn)
        alpha, s_alpha = alpha_prior, alpha_prior_sigma
        veer = math.radians(veer_prior_deg_100m) / 100.0
        s_veer = math.radians(veer_prior_sigma_deg_100m) / 100.0
        rows = [(b * 50 + 25.0, sn / c, se / c, c) for b, (c, sn, se) in self.bins.items() if c >= 10 and b * 50 + 25 >= 30]
        fit_w = 0.0
        if len(rows) >= 3:
            hs = np.array([r[0] for r in rows])
            span = float(hs.max() - hs.min())
            sp = np.array([math.hypot(r[1], r[2]) for r in rows])
            if span >= min_span_m and sp.min() > 1.0:
                wts = np.sqrt(np.array([r[3] for r in rows]))
                fit_w = min(1.0, (span - min_span_m) / 300.0 + 0.3)
                a_fit = float(np.polyfit(np.log(hs), np.log(sp), 1, w=wts)[0])
                ths = np.unwrap(np.array([math.atan2(r[2], r[1]) for r in rows]))
                v_fit = float(np.polyfit(hs, ths, 1, w=wts)[0])
                a_fit = min(0.45, max(-0.05, a_fit))
                v_fit = min(0.005, max(-0.005, v_fit))
                alpha = (1 - fit_w) * alpha + fit_w * a_fit
                veer = (1 - fit_w) * veer + fit_w * v_fit
                s_alpha = (1 - fit_w) * s_alpha + fit_w * 0.04
                s_veer = (1 - fit_w) * s_veer + fit_w * math.radians(1.0) / 100.0
        zs = np.linspace(0.1 * zi_m, 0.9 * zi_m, 17)
        spds = spd0 * (zs / h0) ** alpha
        dirs = th0 + veer * (zs - h0)
        dn, de = float(np.mean(spds * np.cos(dirs))), float(np.mean(spds * np.sin(dirs)))
        z_eff = float(np.mean(zs))
        spd_eff = math.hypot(dn, de)
        s_extrap = math.hypot(spd_eff * abs(math.log(z_eff / h0)) * s_alpha, spd_eff * abs(z_eff - h0) * s_veer)
        return {"drift": (dn, de), "sigma": math.hypot(self.sigma, s_extrap), "alpha": alpha, "veer_deg_100m": math.degrees(veer) * 100.0,
                "fit_weight": fit_w, "local": (wn, we), "provenance": "estimated (zi from forecast/config)"}

    def profile(self) -> list[dict]:
        out = []
        for b in sorted(self.bins):
            c, sn, se = self.bins[b]
            if c < 10:
                continue
            out.append({"h": b * 50 + 25, "wn": sn / c, "we": se / c, "samples": int(c), "provenance": "estimated"})
        return out
