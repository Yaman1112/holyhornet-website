"""Electronics architecture data: blocks, buses, power budget, compatibility, BOM.

Rules followed (from the brief): no invented pin assignments, no invented electrical specifications.
Components are *candidate classes* with example parts to evaluate. Every numeric power figure is an
ESTIMATE for budgeting and must be replaced with datasheet / bench-measured values; every
compatibility entry must be re-verified against the exact firmware version chosen.
"""

from __future__ import annotations

BLOCKS = [
    {"id": "fc", "name": "Real-time flight controller", "domain": "real-time", "candidates": ["Pixhawk-class (FMUv5/v6) running PX4 or ArduPlane"],
     "role": "Sensor sampling, attitude estimation, attitude/airspeed/TECS loops, actuator outputs, failsafes, envelope protection"},
    {"id": "imu", "name": "IMU (redundant MEMS)", "domain": "real-time", "candidates": ["Integrated on flight controller"], "role": "Angular rate + specific force"},
    {"id": "baro", "name": "Barometer", "domain": "real-time", "candidates": ["Integrated on flight controller (MS5611/BMP388-class)"], "role": "Static pressure / altitude for TE variometer"},
    {"id": "gnss", "name": "GNSS receiver + compass", "domain": "real-time", "candidates": ["u-blox M9N/M10-class module"], "role": "Position, ground velocity"},
    {"id": "pitot", "name": "Differential-pressure airspeed sensor + pitot-static probe", "domain": "real-time",
     "candidates": ["MS4525DO / SDP3x-class digital sensor"], "role": "Airspeed (TE compensation, stall protection, wind estimation)"},
    {"id": "te_probe", "name": "Total-energy probe (optional)", "domain": "real-time", "candidates": ["Braunschweig-type TE tube to a second pressure sensor"],
     "role": "Pneumatic TE compensation (research comparison against the software TE vario)"},
    {"id": "air_temp", "name": "Air temperature / humidity sensor", "domain": "companion", "candidates": ["SHT3x / BME280-class in a shielded, ventilated housing"],
     "role": "Atmospheric profile logging (density altitude, thermal signatures)"},
    {"id": "batmon", "name": "Battery voltage/current monitor", "domain": "real-time", "candidates": ["Power module matched to the flight controller"],
     "role": "SOC estimation, reserve logic, energy accounting"},
    {"id": "esc", "name": "ESC + brushless motor + folding propeller", "domain": "propulsion", "candidates": ["Size to the feasibility study (see MASS_ENERGY_BUDGET)"],
     "role": "Take-off, climb, recovery"},
    {"id": "servos", "name": "Servos (2 aileron, elevator, rudder, optional 2 flap)", "domain": "actuation", "candidates": ["Digital thin-wing servos"],
     "role": "Control surfaces"},
    {"id": "telemetry", "name": "Telemetry radio", "domain": "comms", "candidates": ["SiK-class 433/868/915 MHz (per jurisdiction)", "or LTE/mesh for long range"],
     "role": "MAVLink to ground station"},
    {"id": "rc", "name": "RC receiver (safety pilot)", "domain": "comms", "candidates": ["Receiver matched to the safety pilot's transmitter"], "role": "Manual override"},
    {"id": "cc", "name": "Companion computer", "domain": "companion", "candidates": ["Raspberry Pi CM4/5-class or similar low-power SBC"],
     "role": "Atmospheric intelligence, thermal EKF, planner, logging; MAVLink/MAVSDK to the FC"},
    {"id": "camera", "name": "RGB camera (optional)", "domain": "companion", "candidates": ["Camera module supported by the companion computer"], "role": "Cloud/terrain observation research"},
    {"id": "bec", "name": "Power distribution / BEC", "domain": "power", "candidates": ["Isolated regulators for FC, servos and companion"], "role": "Separate noisy servo rail from avionics"},
]

LINKS = [
    {"from": "imu", "to": "fc", "bus": "on-board (SPI)"}, {"from": "baro", "to": "fc", "bus": "on-board (SPI/I2C)"},
    {"from": "gnss", "to": "fc", "bus": "UART (+I2C compass)"}, {"from": "pitot", "to": "fc", "bus": "I2C"},
    {"from": "te_probe", "to": "fc", "bus": "I2C (2nd pressure sensor)"}, {"from": "batmon", "to": "fc", "bus": "analog / I2C (power port)"},
    {"from": "fc", "to": "esc", "bus": "PWM / DShot"}, {"from": "fc", "to": "servos", "bus": "PWM"},
    {"from": "rc", "to": "fc", "bus": "SBUS / CRSF"}, {"from": "fc", "to": "telemetry", "bus": "UART (MAVLink)"},
    {"from": "fc", "to": "cc", "bus": "UART/Ethernet (MAVLink 2 / MAVSDK)"}, {"from": "air_temp", "to": "cc", "bus": "I2C"},
    {"from": "camera", "to": "cc", "bus": "CSI / USB"}, {"from": "bec", "to": "fc", "bus": "power"}, {"from": "bec", "to": "servos", "bus": "power"},
    {"from": "bec", "to": "cc", "bus": "power"},
]

# ESTIMATES for budgeting only — replace with datasheet / measured values.
POWER_BUDGET = [
    {"item": "Flight controller + IMU + baro", "est_w": 1.5, "basis": "estimate (typical class)"},
    {"item": "GNSS + compass", "est_w": 0.4, "basis": "estimate"},
    {"item": "Telemetry radio (avg, TX duty)", "est_w": 0.6, "basis": "estimate"},
    {"item": "RC receiver", "est_w": 0.3, "basis": "estimate"},
    {"item": "Companion computer (avg)", "est_w": 3.0, "basis": "estimate — dominant avionics load; measure"},
    {"item": "Air-data + T/RH sensors", "est_w": 0.1, "basis": "estimate"},
    {"item": "Servos (soaring, avg)", "est_w": 1.0, "basis": "estimate — strongly manoeuvre dependent"},
    {"item": "Propulsion (climb)", "est_w": 220.0, "basis": "simulation model (250 W shaft max, 80 % motor+ESC)"},
]

COMPATIBILITY = [
    {"feature": "Digital airspeed (MS4525/SDP3x)", "px4": "supported", "ardupilot": "supported", "note": "verify driver for chosen part/firmware"},
    {"feature": "Software TE variometer / netto", "px4": "not built-in (compute on companion)", "ardupilot": "ArduSoar computes TE-netto internally",
     "note": "SkyTherm runs its own estimator on the companion for research control"},
    {"feature": "Thermal centring (built-in)", "px4": "no", "ardupilot": "ArduSoar (EKF-based)", "note": "useful as an independent baseline"},
    {"feature": "Humidity/temperature logging", "px4": "not native", "ardupilot": "not native", "note": "log on companion computer"},
    {"feature": "Guidance from companion", "px4": "Offboard mode (MAVSDK)", "ardupilot": "GUIDED mode (MAVLink)", "note": "companion sends setpoints; FC keeps envelope protection"},
    {"feature": "Geofence / RTL failsafes", "px4": "supported", "ardupilot": "supported", "note": "configure before any flight"},
]

BOM = [
    {"qty": 1, "item": "Airframe: 2.5 m composite electric glider (kit or custom moulds)", "class": "structure", "status": "select after structural study"},
    {"qty": 1, "item": "Flight controller (Pixhawk-class)", "class": "avionics", "status": "candidate"},
    {"qty": 1, "item": "GNSS + compass module", "class": "avionics", "status": "candidate"},
    {"qty": 1, "item": "Digital airspeed sensor + pitot-static tube", "class": "air data", "status": "candidate"},
    {"qty": 1, "item": "TE probe + 2nd differential sensor (optional research)", "class": "air data", "status": "optional"},
    {"qty": 1, "item": "T/RH sensor + radiation shield", "class": "air data", "status": "candidate"},
    {"qty": 1, "item": "Power module (V/I sensing)", "class": "power", "status": "match to FC"},
    {"qty": 1, "item": "Brushless motor + ESC + folding propeller + spinner", "class": "propulsion", "status": "size from MASS_ENERGY_BUDGET"},
    {"qty": 1, "item": "LiPo/Li-ion pack (baseline 3S 3.3 Ah)", "class": "energy", "status": "trade study: Li-ion has better Wh/kg at low C"},
    {"qty": 4, "item": "Thin-wing digital servos (+2 if flaps)", "class": "actuation", "status": "candidate"},
    {"qty": 1, "item": "Telemetry radio pair (legal band for jurisdiction)", "class": "comms", "status": "candidate"},
    {"qty": 1, "item": "RC receiver for safety pilot", "class": "comms", "status": "match transmitter"},
    {"qty": 1, "item": "Companion computer + storage", "class": "compute", "status": "candidate"},
    {"qty": 1, "item": "Separate BEC for servo rail", "class": "power", "status": "candidate"},
    {"qty": 1, "item": "Wiring, connectors, vibration mounts", "class": "integration", "status": "-"},
]


def architecture() -> dict:
    total_avionics = sum(p["est_w"] for p in POWER_BUDGET if p["item"] != "Propulsion (climb)")
    return {
        "blocks": BLOCKS, "links": LINKS, "power_budget": POWER_BUDGET, "avionics_total_est_w": round(total_avionics, 2),
        "compatibility": COMPATIBILITY, "bom": BOM,
        "separation": {
            "real_time_flight_controller": ["sensor sampling", "attitude stabilisation", "actuator control", "flight-envelope protection", "failsafes"],
            "companion_computer": ["atmospheric intelligence", "thermal estimation", "mission planning", "AI analysis", "data logging", "research computation"],
        },
        "rules": ["No pin assignments are given: take them from the chosen flight controller's official documentation.",
                  "All power numbers are estimates for budgeting; replace with datasheet/bench values.",
                  "Re-verify every compatibility row against the exact firmware version before integration."],
        "provenance": "design estimate",
    }
