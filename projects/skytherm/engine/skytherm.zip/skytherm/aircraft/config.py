"""Parametric aircraft configuration.

All values are *research targets* (see docs/REQUIREMENTS.md), not a frozen design. Every field
is configurable through the API and the web Aircraft Design workspace.
"""

from __future__ import annotations

import hashlib
import json

from pydantic import BaseModel, Field


class MassComponent(BaseModel):
    """A lumped mass. Position in body FRD metres relative to the wing quarter-chord root (datum)."""

    name: str
    mass_kg: float = Field(gt=0)
    x_m: float = 0.0
    y_m: float = 0.0
    z_m: float = 0.0
    # shape used for its own inertia: "point", "rod_x" (length along x), "plate_y" (span along y)
    shape: str = "point"
    length_m: float = 0.0
    group: str = "airframe"


def default_components() -> list[MassComponent]:
    # Estimates for a 2.5 m composite electric glider; to be replaced with weighed values.
    return [
        MassComponent(name="Main wing (incl. spars, ribs, skins)", mass_kg=0.70, x_m=-0.02, shape="plate_y", length_m=2.5, group="airframe"),
        MassComponent(name="Fuselage pod + boom", mass_kg=0.30, x_m=0.05, shape="rod_x", length_m=1.25, group="airframe"),
        MassComponent(name="Horizontal + vertical tail", mass_kg=0.10, x_m=-0.85, z_m=-0.05, group="airframe"),
        MassComponent(name="Servos (4) + linkages", mass_kg=0.10, x_m=-0.05, group="avionics"),
        MassComponent(name="Motor, ESC, folding propeller", mass_kg=0.21, x_m=0.42, group="propulsion"),
        MassComponent(name="Battery 3S 3300 mAh LiPo", mass_kg=0.27, x_m=0.20, group="energy"),
        MassComponent(name="Flight controller, GNSS, telemetry", mass_kg=0.12, x_m=0.10, group="avionics"),
        MassComponent(name="Air-data (pitot, baro, T/RH)", mass_kg=0.05, x_m=0.30, group="avionics"),
        MassComponent(name="Companion computer", mass_kg=0.06, x_m=0.12, group="avionics"),
        MassComponent(name="Ballast / environmental payload", mass_kg=0.13, x_m=0.15, group="payload"),
    ]


class AirfoilConfig(BaseModel):
    name: str = "Generic thermal-glider section (SD7037-class)"
    cl_alpha_2d: float = Field(6.0, gt=0, description="2-D lift slope per rad")
    alpha_zero_lift_deg: float = -3.0
    cl_max: float = Field(1.25, gt=0, description="3-D wing CLmax")
    cd0: float = Field(0.0100, ge=0, description="minimum profile drag coefficient")
    cd_profile_k: float = Field(0.0080, ge=0, description="profile drag growth k_p in k_p*(CL-CL_md)^2")
    cl_min_drag: float = 0.45
    cl_knee: float = Field(0.85, description="CL above which profile drag rises steeply")
    cd_k_high: float = Field(0.12, ge=0, description="high-CL drag rise coefficient")


class WingConfig(BaseModel):
    wingspan_m: float = Field(2.5, gt=0.3, le=6.0)
    root_chord_m: float = Field(0.22, gt=0.02)
    taper_ratio: float = Field(0.6, gt=0.1, le=1.0)
    sweep_deg: float = Field(0.0, ge=-30, le=40, description="quarter-chord sweep")
    twist_deg: float = Field(-2.0, ge=-8, le=4, description="tip washout (negative = washout)")
    dihedral_deg: float = Field(4.0, ge=-10, le=15)
    winglet_height_m: float = Field(0.0, ge=0, le=0.4)
    oswald_e: float = Field(0.90, gt=0.4, le=1.0)
    incidence_deg: float = 1.5
    aileron_span_start: float = Field(0.55, ge=0, lt=1, description="fraction of semi-span")
    aileron_span_end: float = Field(0.95, gt=0, le=1)
    aileron_chord_fraction: float = Field(0.25, gt=0.05, lt=0.6)
    flaps_enabled: bool = False
    flap_span_fraction: float = Field(0.5, ge=0, le=0.6)
    flap_chord_fraction: float = Field(0.25, gt=0.05, lt=0.5)


class TailConfig(BaseModel):
    tail_arm_m: float = Field(0.85, gt=0.2)
    h_tail_volume: float = Field(0.45, gt=0.1, le=1.2)
    v_tail_volume: float = Field(0.025, gt=0.005, le=0.1)
    h_tail_aspect_ratio: float = 4.5
    v_tail_aspect_ratio: float = 1.8
    elevator_chord_fraction: float = Field(0.35, gt=0.05, lt=1)
    rudder_chord_fraction: float = Field(0.40, gt=0.05, lt=1)
    static_margin: float = Field(0.10, ge=0.02, le=0.35, description="fraction of MAC")
    tail_efficiency: float = 0.9


class PropulsionConfig(BaseModel):
    enabled: bool = True
    max_shaft_power_w: float = Field(250.0, gt=0)
    static_thrust_n: float = Field(12.0, gt=0)
    prop_efficiency: float = Field(0.62, gt=0.1, le=0.9)
    motor_esc_efficiency: float = Field(0.80, gt=0.3, le=0.98)
    idle_power_w: float = Field(1.5, ge=0, description="avionics-independent ESC idle draw while armed")


class BatteryConfig(BaseModel):
    cells_series: int = Field(3, ge=1, le=12)
    capacity_ah: float = Field(3.3, gt=0.1)
    internal_resistance_cell_ohm: float = Field(0.008, gt=0)
    resistance_temp_coeff: float = Field(0.015, ge=0, description="fractional R increase per degC below 25 C")
    cutoff_v_cell: float = 3.30
    initial_soc: float = Field(1.0, ge=0.05, le=1.0)
    initial_temp_c: float = 20.0
    ambient_temp_c: float = 15.0
    thermal_mass_j_per_k: float = 220.0
    cooling_w_per_k: float = 0.25
    avionics_power_w: float = Field(4.0, ge=0, description="flight controller + companion + telemetry")


class ActuatorConfig(BaseModel):
    max_deflection_deg: float = 22.0
    time_constant_s: float = 0.05
    rate_limit_deg_s: float = 300.0


class AircraftConfig(BaseModel):
    name: str = "SkyTherm SR-1 (2.5 m research baseline)"
    wing: WingConfig = WingConfig()
    airfoil: AirfoilConfig = AirfoilConfig()
    tail: TailConfig = TailConfig()
    propulsion: PropulsionConfig = PropulsionConfig()
    battery: BatteryConfig = BatteryConfig()
    actuators: ActuatorConfig = ActuatorConfig()
    components: list[MassComponent] = Field(default_factory=default_components)
    cd0_parasite: float = Field(0.0075, ge=0, description="fuselage, tail, interference drag on wing area")
    mass_scale: float = Field(1.0, gt=0.3, le=3.0, description="multiplies every component mass (ballast study)")
    n_max: float = Field(3.5, gt=1.2, le=8.0, description="structural limit load factor")
    vne_ms: float = Field(30.0, gt=10)

    def config_hash(self) -> str:
        return hashlib.sha256(json.dumps(self.model_dump(), sort_keys=True).encode()).hexdigest()[:16]
