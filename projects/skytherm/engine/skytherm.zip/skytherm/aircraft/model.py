"""Derived aircraft model: geometry, mass properties and aerodynamic coefficients.

The aerodynamic model is a first-order *parametric estimate* built from geometry using classic
handbook methods (Helmbold lift slope, tail-volume derivatives, strip-theory control power,
thin-aerofoil flap effectiveness). It is good enough to study trends and to close control loops
in simulation; it is **not** a substitute for CFD / wind-tunnel / flight identification
(see docs/AERODYNAMICS.md, "Limitations").
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from .config import AircraftConfig

G = 9.80665


def flap_effectiveness(chord_fraction: float) -> float:
    """Thin-aerofoil-theory flap effectiveness tau with a 0.8 empirical viscous correction."""
    theta = math.acos(max(-1.0, min(1.0, 2.0 * chord_fraction - 1.0)))
    return 0.8 * (1.0 - (theta - math.sin(theta)) / math.pi)


def helmbold_lift_slope(aspect_ratio: float, a0: float = 2 * math.pi * 0.95, sweep_rad: float = 0.0) -> float:
    """DATCOM/Helmbold finite-wing lift-curve slope per rad."""
    kappa = a0 / (2 * math.pi)
    return 2 * math.pi * aspect_ratio / (
        2 + math.sqrt(4 + aspect_ratio**2 * (1 + math.tan(sweep_rad) ** 2) / kappa**2)
    )


@dataclass
class Geometry:
    wingspan: float
    root_chord: float
    tip_chord: float
    area: float
    aspect_ratio: float
    aspect_ratio_effective: float
    mac: float
    y_mac: float
    sweep_rad: float
    dihedral_rad: float
    h_tail_area: float
    v_tail_area: float
    tail_arm: float
    fin_height: float


@dataclass
class MassProperties:
    mass: float
    cg_x: float
    cg_z: float
    ixx: float
    iyy: float
    izz: float
    ixz: float
    breakdown: list[dict]


class AircraftModel:
    """Numerical model used by the performance tools and the 6-DOF simulation."""

    def __init__(self, cfg: AircraftConfig):
        self.cfg = cfg
        self.geometry = self._geometry(cfg)
        self.mass = self._mass_properties(cfg)
        self._derive_aero(cfg)

    # ------------------------------------------------------------------ geometry
    @staticmethod
    def _geometry(cfg: AircraftConfig) -> Geometry:
        w = cfg.wing
        b, cr, lam = w.wingspan_m, w.root_chord_m, w.taper_ratio
        ct = lam * cr
        s = b * (cr + ct) / 2
        ar = b * b / s
        # Winglet benefit: Hoerner-type estimate AR_eff = AR (1 + 1.9 h/b). Heuristic, flagged in docs.
        ar_eff = ar * (1 + 1.9 * w.winglet_height_m / b)
        mac = 2 / 3 * cr * (1 + lam + lam * lam) / (1 + lam)
        y_mac = b / 6 * (1 + 2 * lam) / (1 + lam)
        t = cfg.tail
        sh = t.h_tail_volume * s * mac / t.tail_arm_m
        sv = t.v_tail_volume * s * b / t.tail_arm_m
        fin_h = math.sqrt(sv * t.v_tail_aspect_ratio)
        return Geometry(
            wingspan=b, root_chord=cr, tip_chord=ct, area=s, aspect_ratio=ar, aspect_ratio_effective=ar_eff,
            mac=mac, y_mac=y_mac, sweep_rad=math.radians(w.sweep_deg), dihedral_rad=math.radians(w.dihedral_deg),
            h_tail_area=sh, v_tail_area=sv, tail_arm=t.tail_arm_m, fin_height=fin_h,
        )

    @staticmethod
    def _mass_properties(cfg: AircraftConfig) -> MassProperties:
        k = cfg.mass_scale
        comps = cfg.components
        m_tot = sum(c.mass_kg * k for c in comps)
        cx = sum(c.mass_kg * k * c.x_m for c in comps) / m_tot
        cy = sum(c.mass_kg * k * c.y_m for c in comps) / m_tot
        cz = sum(c.mass_kg * k * c.z_m for c in comps) / m_tot
        ixx = iyy = izz = jxz = 0.0
        breakdown = []
        for c in comps:
            m = c.mass_kg * k
            dx, dy, dz = c.x_m - cx, c.y_m - cy, c.z_m - cz
            if c.shape == "plate_y":
                # tapered wing: mass biased inboard -> 0.85 of uniform-bar value
                own = 0.85 * m * c.length_m**2 / 12
                ixx += own
                izz += own
            elif c.shape == "rod_x":
                own = m * c.length_m**2 / 12
                iyy += own
                izz += own
            ixx += m * (dy * dy + dz * dz)
            iyy += m * (dx * dx + dz * dz)
            izz += m * (dx * dx + dy * dy)
            jxz += m * dx * dz
            breakdown.append({"name": c.name, "group": c.group, "mass_kg": round(m, 4), "x_m": c.x_m})
        return MassProperties(mass=m_tot, cg_x=cx, cg_z=cz, ixx=ixx, iyy=iyy, izz=izz, ixz=jxz, breakdown=breakdown)

    # ------------------------------------------------------------------ aerodynamics
    def _derive_aero(self, cfg: AircraftConfig) -> None:
        g = self.geometry
        af, w, t = cfg.airfoil, cfg.wing, cfg.tail
        lam = w.taper_ratio
        a = helmbold_lift_slope(g.aspect_ratio_effective, af.cl_alpha_2d, g.sweep_rad)
        a_t = helmbold_lift_slope(t.h_tail_aspect_ratio)
        a_v = helmbold_lift_slope(t.v_tail_aspect_ratio)
        eta = t.tail_efficiency
        deps = 2 * a / (math.pi * g.aspect_ratio_effective)
        sh_s, sv_s = g.h_tail_area / g.area, g.v_tail_area / g.area
        a_tot = a + a_t * eta * sh_s * (1 - deps)
        self.a_wing, self.a_tail, self.a_fin, self.downwash_grad = a, a_t, a_v, deps
        self.cl_alpha = a_tot
        self.cl0 = a * (math.radians(w.incidence_deg) - math.radians(af.alpha_zero_lift_deg) + 0.4 * math.radians(w.twist_deg))
        self.cl_max = af.cl_max
        self.alpha_stall = (self.cl_max - self.cl0) / a_tot
        self.alpha_stall_neg = (-0.7 * self.cl_max - self.cl0) / a_tot
        self.cd0 = af.cd0 + cfg.cd0_parasite
        self.cd_k_profile = af.cd_profile_k
        self.cl_min_drag = af.cl_min_drag
        self.cl_knee = af.cl_knee
        self.cd_k_high = af.cd_k_high
        self.k_induced = 1.0 / (math.pi * w.oswald_e * g.aspect_ratio_effective)
        # longitudinal
        tau_e = flap_effectiveness(t.elevator_chord_fraction)
        vh = t.h_tail_volume
        self.cm_alpha = -a_tot * t.static_margin
        self.cl_q = 2 * a_t * eta * vh
        self.cm_q = -2.2 * a_t * eta * vh * t.tail_arm_m / g.mac
        self.cl_de = a_t * eta * tau_e * sh_s
        self.cm_de = -a_t * eta * tau_e * vh
        self.cl_design = 0.75
        alpha_design = (self.cl_design - self.cl0) / a_tot
        self.cm0 = -self.cm_alpha * alpha_design
        # lateral-directional
        vv = t.v_tail_volume
        tau_r = flap_effectiveness(t.rudder_chord_fraction)
        tau_a = flap_effectiveness(w.aileron_chord_fraction)
        z_v = 0.5 * g.fin_height
        self.cy_beta = -a_v * eta * sv_s
        self.cn_beta = 0.8 * a_v * eta * vv
        self.cl_beta = -a * g.dihedral_rad * (1 + 2 * lam) / (6 * (1 + lam)) - a_v * eta * sv_s * z_v / g.wingspan
        self.cl_p = -(a / 12) * (1 + 3 * lam) / (1 + lam)
        # tail term (Etkin) + empirical wing/fuselage contribution
        self.cn_r = -2 * a_v * eta * vv * t.tail_arm_m / g.wingspan - 0.02 - self.cd0 / 4
        self.cy_dr = a_v * eta * tau_r * sv_s
        self.cn_dr = -a_v * eta * tau_r * vv
        self.cl_dr = self.cy_dr * z_v / g.wingspan
        y1, y2 = w.aileron_span_start * g.wingspan / 2, w.aileron_span_end * g.wingspan / 2
        eta_mid = 0.5 * (w.aileron_span_start + w.aileron_span_end)
        c_ail = g.root_chord * (1 - (1 - lam) * eta_mid)
        self.cl_da = 0.85 * a * tau_a * c_ail * (y2 * y2 - y1 * y1) / (g.area * g.wingspan)
        # flaps (optional)
        tau_f = flap_effectiveness(w.flap_chord_fraction)
        self.flaps_enabled = w.flaps_enabled
        self.cl_df = 0.9 * a * tau_f * w.flap_span_fraction if w.flaps_enabled else 0.0
        self.cd_df = 0.9 * tau_f * w.flap_span_fraction if w.flaps_enabled else 0.0
        self.cm_df = -0.2 * self.cl_df
        self.max_defl = math.radians(cfg.actuators.max_deflection_deg)
        # elevator deflection that trims at alpha_max (used by the alpha-protection limiter)
        self.alpha_max = 0.85 * self.alpha_stall
        self.de_alpha_max = -(self.cm0 + self.cm_alpha * self.alpha_max) / self.cm_de

    # ------------------------------------------------------------------ coefficient helpers
    def stall_blend(self, alpha: float) -> float:
        m = 55.0
        x1 = max(-60.0, min(60.0, -m * (alpha - self.alpha_stall)))
        x2 = max(-60.0, min(60.0, -m * (self.alpha_stall_neg - alpha)))
        return min(1.0, 1.0 / (1.0 + math.exp(x1)) + 1.0 / (1.0 + math.exp(x2)))

    def cd_polar(self, cl: float) -> float:
        d = cl - self.cl_min_drag
        # high-CL profile drag rise (laminar bucket edge / incipient separation near CLmax)
        e = cl - self.cl_knee
        hi = self.cd_k_high * e * e if e > 0.0 else 0.0
        return self.cd0 + self.cd_k_profile * d * d + hi + self.k_induced * cl * cl

    def cl_static(self, alpha: float) -> float:
        sig = self.stall_blend(alpha)
        lin = self.cl0 + self.cl_alpha * alpha
        sa = math.sin(alpha)
        plate = 2.0 * math.copysign(1.0, alpha) * sa * sa * math.cos(alpha)
        return (1 - sig) * lin + sig * plate

    def alpha_for_cl(self, cl: float) -> float:
        return (cl - self.cl0) / self.cl_alpha

    def coefficients(self, alpha, beta, va, p, q, r, da, de, dr, df=0.0):
        """Return (CL, CD, CY, Cl, Cm, Cn) in the stability/body convention of Beard & McLain."""
        g = self.geometry
        b2v = g.wingspan / (2 * va)
        c2v = g.mac / (2 * va)
        sig = self.stall_blend(alpha)
        lin = self.cl0 + self.cl_alpha * alpha
        sa = math.sin(alpha)
        plate = 2.0 * math.copysign(1.0, alpha) * sa * sa * math.cos(alpha)
        cl_alpha_part = (1 - sig) * lin + sig * plate
        cl = cl_alpha_part + self.cl_q * q * c2v + self.cl_de * de + self.cl_df * df
        cl_lin = max(-self.cl_max, min(self.cl_max * 1.05, lin))
        cd_att = self.cd_polar(cl_lin)
        cd = (1 - sig) * cd_att + sig * (1.8 * sa * sa + self.cd0) + 0.25 * beta * beta
        cd += 0.03 * (de * de + dr * dr + 0.5 * da * da) + self.cd_df * df * df
        cy = self.cy_beta * beta + self.cy_dr * dr
        cl_roll = self.cl_beta * beta + self.cl_p * p * b2v + (cl_alpha_part / 4) * r * b2v + self.cl_da * da + self.cl_dr * dr
        cm = self.cm0 + self.cm_alpha * alpha + self.cm_q * q * c2v + self.cm_de * de + self.cm_df * df
        cn = (self.cn_beta * beta + (-cl_alpha_part / 8) * p * b2v + self.cn_r * r * b2v
              - 0.08 * cl_alpha_part * self.cl_da * da + self.cn_dr * dr)
        return cl, cd, cy, cl_roll, cm, cn

    def forces_moments(self, va, alpha, beta, p, q, r, da, de, dr, df, rho):
        """Aerodynamic forces (body X,Y,Z) and moments (L,M,N) about the CG."""
        cl, cd, cy, c_l, c_m, c_n = self.coefficients(alpha, beta, va, p, q, r, da, de, dr, df)
        g = self.geometry
        qs = 0.5 * rho * va * va * g.area
        ca, sa = math.cos(alpha), math.sin(alpha)
        fx = qs * (-cd * ca + cl * sa)
        fz = qs * (-cd * sa - cl * ca)
        fy = qs * cy
        return fx, fy, fz, qs * g.wingspan * c_l, qs * g.mac * c_m, qs * g.wingspan * c_n

    # ------------------------------------------------------------------ propulsion
    def thrust(self, throttle: float, va: float) -> tuple[float, float]:
        """Return (thrust N, electrical power W). Simple power-limited propeller model."""
        pc = self.cfg.propulsion
        if not pc.enabled or throttle <= 0.0:
            return 0.0, 0.0
        thr = min(1.0, throttle)
        p_shaft = thr * pc.max_shaft_power_w
        v_static = pc.prop_efficiency * pc.max_shaft_power_w / pc.static_thrust_n
        t = pc.prop_efficiency * p_shaft / (max(va, 0.0) + v_static)
        p_elec = p_shaft / pc.motor_esc_efficiency + pc.idle_power_w
        return t, p_elec

    def summary(self) -> dict:
        g, m = self.geometry, self.mass
        return {
            "geometry": {
                "wingspan_m": g.wingspan, "root_chord_m": g.root_chord, "tip_chord_m": g.tip_chord,
                "wing_area_m2": g.area, "aspect_ratio": g.aspect_ratio, "aspect_ratio_effective": g.aspect_ratio_effective,
                "mac_m": g.mac, "y_mac_m": g.y_mac, "h_tail_area_m2": g.h_tail_area, "v_tail_area_m2": g.v_tail_area,
                "tail_arm_m": g.tail_arm, "fin_height_m": g.fin_height,
                "wing_loading_n_m2": m.mass * G / g.area,
            },
            "mass": {
                "mass_kg": m.mass, "cg_x_m": m.cg_x, "cg_z_m": m.cg_z,
                "ixx": m.ixx, "iyy": m.iyy, "izz": m.izz, "ixz": m.ixz, "components": m.breakdown,
                "neutral_point_x_m": m.cg_x + self.cfg.tail.static_margin * g.mac,
            },
            "aero": {
                "cl_alpha_wing": self.a_wing, "cl_alpha_total": self.cl_alpha, "cl0": self.cl0, "cl_max": self.cl_max,
                "alpha_stall_deg": math.degrees(self.alpha_stall), "cd0": self.cd0, "k_induced": self.k_induced,
                "oswald_e": self.cfg.wing.oswald_e, "downwash_gradient": self.downwash_grad,
                "cm0": self.cm0, "cm_alpha": self.cm_alpha, "cm_q": self.cm_q, "cl_q": self.cl_q,
                "cl_de": self.cl_de, "cm_de": self.cm_de, "cy_beta": self.cy_beta, "cl_beta": self.cl_beta,
                "cn_beta": self.cn_beta, "cl_p": self.cl_p, "cn_r": self.cn_r, "cl_da": self.cl_da,
                "cy_dr": self.cy_dr, "cn_dr": self.cn_dr, "cl_df": self.cl_df,
            },
            "provenance": "estimated (parametric handbook methods; not measured)",
        }
