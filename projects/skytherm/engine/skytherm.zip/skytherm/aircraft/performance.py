"""Steady-state performance: glide polar, circling polar, speed-to-fly, power required.

The steady glide is solved *exactly* (L = W cos(gamma), D = W sin(gamma)) by fixed-point iteration,
not with the small-angle shortcut. Best glide (max L/D) and minimum sink are found
independently — they are different operating points (min sink is always slower).
"""

from __future__ import annotations

import math

from scipy.optimize import minimize_scalar

from ..atmosphere import isa
from .model import G, AircraftModel


def stall_speed(model: AircraftModel, rho: float, load_factor: float = 1.0) -> float:
    w = model.mass.mass * G
    return math.sqrt(2 * w * load_factor / (rho * model.geometry.area * model.cl_max))


def glide_point(model: AircraftModel, v: float, rho: float, load_factor: float = 1.0) -> dict:
    """Steady (or steadily turning, via load factor n) unpowered glide at true airspeed v."""
    w = model.mass.mass * G
    s = model.geometry.area
    q = 0.5 * rho * v * v
    gamma = 0.0
    for _ in range(6):
        cl = load_factor * w * math.cos(gamma) / (q * s)
        cd = model.cd_polar(cl)
        gamma = math.atan(cd / cl)
    sink = v * math.sin(gamma)
    return {
        "v": v, "cl": cl, "cd": cd, "ld": cl / cd, "gamma_deg": math.degrees(gamma), "sink": sink,
        "lift_n": q * s * cl, "drag_n": q * s * cd, "power_required_w": q * s * cd * v,
        "stalled": cl > model.cl_max,
    }


def sink_rate(model: AircraftModel, v: float, rho: float, load_factor: float = 1.0) -> float:
    return glide_point(model, v, rho, load_factor)["sink"]


def best_glide(model: AircraftModel, rho: float) -> dict:
    vs = stall_speed(model, rho)
    res = minimize_scalar(lambda v: -glide_point(model, v, rho)["ld"], bounds=(vs * 1.02, vs * 4), method="bounded")
    return glide_point(model, float(res.x), rho)


def min_sink(model: AircraftModel, rho: float, load_factor: float = 1.0) -> dict:
    vs = stall_speed(model, rho, load_factor)
    res = minimize_scalar(lambda v: glide_point(model, v, rho, load_factor)["sink"], bounds=(vs * 1.02, vs * 3), method="bounded")
    return glide_point(model, float(res.x), rho, load_factor)


def maccready_speed(model: AircraftModel, rho: float, climb_expected: float, headwind: float = 0.0, sink_air: float = 0.0) -> float:
    """Speed-to-fly maximising cross-country speed (V - headwind)/(sink + sink_air + climb) — MacCready theory."""
    vs = stall_speed(model, rho)

    def cost(v):
        return -(v - headwind) / (sink_rate(model, v, rho) + sink_air + max(climb_expected, 0.0) + 1e-6)

    res = minimize_scalar(cost, bounds=(vs * 1.1, min(model.cfg.vne_ms, vs * 4)), method="bounded")
    return float(res.x)


def circling_point(model: AircraftModel, v: float, bank_rad: float, rho: float) -> dict:
    n = 1.0 / math.cos(bank_rad)
    pt = glide_point(model, v, rho, n)
    radius = v * v / (G * math.tan(bank_rad)) if bank_rad > 1e-3 else math.inf
    pt.update({"bank_deg": math.degrees(bank_rad), "load_factor": n, "radius_m": radius})
    return pt


def circling_polar(model: AircraftModel, rho: float, banks_deg=(15, 20, 25, 30, 35, 40, 45, 50)) -> list[dict]:
    """For each bank angle: the minimum-sink speed in the turn, its radius and sink."""
    out = []
    for b in banks_deg:
        br = math.radians(b)
        ms = min_sink(model, rho, 1 / math.cos(br))
        v = ms["v"] * 1.05  # 5 % margin above min-sink in the turn
        out.append(circling_point(model, v, br, rho))
    return out


def best_circle_in_thermal(model: AircraftModel, rho: float, w_core: float, radius: float, profile: str = "gaussian") -> dict:
    """Bank angle that maximises climb in an axisymmetric thermal of strength w_core and radius R.

    climb(phi) = w(r(phi)) - sink(V(phi), n(phi)), r = V^2/(g tan phi). This is the textbook trade:
    steep bank -> closer to the core but higher sink.
    """
    best = None
    for b in range(15, 56):
        br = math.radians(b)
        n = 1 / math.cos(br)
        v = 1.05 * min_sink(model, rho, n)["v"]
        r = v * v / (G * math.tan(br))
        x = r / radius
        w = w_core * math.exp(-x * x) if profile == "gaussian" else w_core * math.exp(-x * x) * (1 - x * x)
        s = sink_rate(model, v, rho, n)
        climb = w - s
        if best is None or climb > best["climb"]:
            best = {"bank_deg": b, "v": v, "radius_m": r, "lift_at_radius": w, "sink": s, "climb": climb}
    return best


def performance_summary(model: AircraftModel, altitude_m: float = 300.0) -> dict:
    rho = isa.density(altitude_m)
    bg = best_glide(model, rho)
    ms = min_sink(model, rho)
    vs = stall_speed(model, rho)
    speeds = [vs * 1.0 + i * 0.25 for i in range(0, int((min(model.cfg.vne_ms, vs * 3.2) - vs) / 0.25))]
    polar = []
    pc = model.cfg.propulsion
    for v in speeds:
        p = glide_point(model, v, rho)
        p["electric_power_level_w"] = p["power_required_w"] / (pc.prop_efficiency * pc.motor_esc_efficiency) if pc.enabled else None
        polar.append(p)
    mc = [{"climb": c, "v": maccready_speed(model, rho, c)} for c in (0.0, 0.5, 1.0, 1.5, 2.0, 3.0)]
    return {
        "altitude_m": altitude_m, "rho": rho,
        "stall_speed": vs, "best_glide": bg, "min_sink": ms,
        "level_flight_power_at_best_glide_w": bg["power_required_w"] / (pc.prop_efficiency * pc.motor_esc_efficiency),
        "polar": polar, "circling": circling_polar(model, rho), "maccready": mc,
        "provenance": "estimated (model-based polar)",
    }
