"""Browser edition bridge: the unmodified FastAPI application inside Pyodide (CPython on WebAssembly).

The web worker calls ``boot()`` once, then ``request(method, path, headers_json, body)`` for every API call.
Requests go through the full ASGI stack (validation, models, SQLite store) exactly as on a server; only the
transport differs (postMessage instead of TCP). Differences, all reported to the user by the API itself:

* Pyodide has no threads. Simulation runs are started right after the POST returns and run inside the
  worker; progress and live frames are pushed to the page with ``postMessage`` (the WebSocket equivalent).
  While a run executes, other requests wait.
* Multi-run research experiments and the validation suite need worker threads / processes -> HTTP 501
  with an explanation; their stored results (shipped with the page) are readable.
* Dynamic-soaring optimisation needs CasADi/IPOPT, which is not available for WebAssembly. Results for the
  page's default settings were computed with the same code at build time and are served from
  ``precomputed.json``; other settings -> HTTP 501.
"""
from __future__ import annotations

import asyncio
import json
import os

_app = None
_pre: dict = {}
_ds_scenarios: set[str] = set()
_busy = {"rid": None}

_LOCAL_ONLY = ("This needs the local SkyTherm backend (worker threads / CasADi), which a web page cannot run. "
               "Stored results shipped with this page are shown; run `uvicorn skytherm.api.main:app` locally to compute new ones.")


def _post(msg: dict):
    try:
        import js  # Pyodide: the worker's global scope

        js.postMessage(js.JSON.parse(json.dumps(msg)))
    except Exception:  # not in a browser (tests)
        pass


class _LiveFrames(list):
    """Stands in for the server's deque: forwards every 2nd frame to the page in small batches."""

    def __init__(self, rid: str):
        super().__init__()
        self.rid, self.buf, self.k = rid, [], 0

    def append(self, fr):
        self.k += 1
        if self.k % 2:
            self.buf.append(fr)
        if len(self.buf) >= 25:
            self.flush()

    def flush(self, progress=None):
        _post({"type": "live", "rid": self.rid, "progress": progress, "frames": self.buf})
        self.buf = []


class _Live(dict):
    """Stands in for the server's live-state dict: progress updates are pushed to the page (throttled)."""

    def __setitem__(self, k, v):
        super().__setitem__(k, v)
        if k == "progress" and isinstance(self.get("frames"), _LiveFrames):
            last = self.get("_last", -1.0)
            if v - last >= 0.01 or v >= 1.0:
                dict.__setitem__(self, "_last", v)
                self["frames"].flush(v)
        elif k == "done" and v:
            fr = self.get("frames")
            if isinstance(fr, _LiveFrames):
                fr.flush(1.0)
            _post({"type": "live", "rid": self.get("_rid"), "done": True})


class _DeferredPool:
    """Replaces the ThreadPoolExecutor: run the job on the event loop after the HTTP response is sent."""

    def submit(self, fn, *args):
        from .api import main

        rid = args[0] if args else None
        if rid in main._live:
            live = _Live(main._live[rid])
            live["frames"] = _LiveFrames(rid)
            dict.__setitem__(live, "_rid", rid)
            main._live[rid] = live

        def job():
            _busy["rid"] = rid
            try:
                fn(*args)
            finally:
                _busy["rid"] = None

        asyncio.get_event_loop().call_later(0.05, job)


def boot(data_dir: str = "/home/pyodide/skytherm_data", precomputed_path: str = "") -> dict:
    global _app, _pre, _ds_scenarios
    import time

    t = time.time()
    os.environ["SKYTHERM_DATA"] = data_dir
    os.environ["SKYTHERM_BROWSER"] = "1"
    import anyio.to_thread

    async def _inline(func, *args, abandon_on_cancel=False, cancellable=None, limiter=None):
        return func(*args)

    anyio.to_thread.run_sync = _inline
    from .api import main
    from .simulation.scenarios import preset_scenarios

    main._pool = _DeferredPool()
    _app = main.app
    if precomputed_path and os.path.exists(precomputed_path):
        with open(precomputed_path, encoding="utf-8") as f:
            _pre = json.load(f)
    _ds_scenarios = {s.id for s in preset_scenarios().values() if s.kind == "dynamic_soaring"}
    return {"ok": True, "boot_s": round(time.time() - t, 1), "runs": len(main.store.list_runs(1000)),
            "experiments": len(main.store.list_experiments())}


def _canon(raw: bytes) -> str:
    try:
        return json.dumps(json.loads(raw or b"{}"), sort_keys=True, separators=(",", ":"))
    except Exception:
        return ""


def _json_response(status: int, obj) -> dict:
    return {"status": status, "headers": {"content-type": "application/json"}, "body": json.dumps(obj).encode()}


def _intercept(method: str, p: str, raw: bytes):
    """Endpoints that cannot run in a web page (see module docstring)."""
    m = method.upper()
    if m == "POST" and p in ("/api/dynamic-soaring/optimize", "/api/dynamic-soaring/sweep"):
        hit = _pre.get(p, {}).get(_canon(raw))
        if hit is not None:
            return _json_response(200, hit)
        return _json_response(501, {"detail": "Dynamic-soaring optimisation uses CasADi/IPOPT, which cannot run in a web page. "
                                              "Results are available here for the default settings only (computed with the same code). "
                                              "Run the local backend to optimise other settings."})
    if m == "POST" and (p == "/api/experiments" or p == "/api/validation/run"):
        return _json_response(501, {"detail": _LOCAL_ONLY})
    if m == "POST" and p == "/api/runs":
        try:
            sid = json.loads(raw or b"{}").get("scenario_id", "milestone")
        except Exception:
            sid = ""
        if sid in _ds_scenarios:
            return _json_response(501, {"detail": "The dynamic-soaring scenario uses CasADi/IPOPT (not available in a web page). "
                                                  "See the Dynamic Soaring workspace for precomputed results."})
    return None


async def request(method: str, path: str, headers_json: str = "{}", body=None) -> dict:
    if _app is None:
        raise RuntimeError("call boot() first")
    headers = json.loads(headers_json or "{}")
    p, _, qs = path.partition("?")
    raw = bytes(body) if body is not None and type(body).__name__ != "JsNull" else b""
    hit = _intercept(method, p, raw)
    if hit is not None:
        return hit
    hdrs = [(k.lower().encode(), str(v).encode()) for k, v in headers.items()]
    hdrs.append((b"host", b"skytherm.local"))
    if raw:
        hdrs.append((b"content-length", str(len(raw)).encode()))
    from urllib.parse import unquote

    scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": method.upper(), "scheme": "http",
             "path": unquote(p), "raw_path": p.encode(), "query_string": qs.encode(), "root_path": "", "headers": hdrs,
             "client": ("browser", 0), "server": ("skytherm.local", 80)}
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": raw, "more_body": False}
        return {"type": "http.disconnect"}

    out = {"status": 500, "headers": {}, "body": b""}
    chunks = []

    async def send(msg):
        if msg["type"] == "http.response.start":
            out["status"] = msg["status"]
            out["headers"] = {k.decode(): v.decode() for k, v in msg.get("headers", [])}
        elif msg["type"] == "http.response.body":
            chunks.append(msg.get("body", b""))

    await _app(scope, receive, send)
    out["body"] = b"".join(chunks)
    return out
