"""Autonomous soaring decision engine: deterministic state machine + explainable utility planner.

Design rules (docs/AUTONOMY.md):
* Every mode transition has a measurable entry condition and is logged with the values that
  triggered it.
* The planner is *advisory*: it ranks opportunities and explains its ranking; the state machine
  decides; the autopilot's envelope protection is always applied after both. No policy can command
  outside the envelope or switch hardware modes.
* Thermal detection is inhibited while the motor runs (thrust contaminates the netto estimate).
* Dynamic soaring is NOT flown by this state machine. It is a separate point-mass research
  module (skytherm.dynamic_soaring); requesting it here is refused and logged.
"""

from __future__ import annotations

import math

import numpy as np
from dataclasses import dataclass, field
from enum import Enum

from pydantic import BaseModel, Field

from ..aircraft import performance
from ..aircraft.model import G, AircraftModel
from ..control.autopilot import GuidanceCommand, NavState
from ..estimation.thermal import ThermalEKF, ThermalMap, ThermalRecord
from ..frames import wrap_pi


class Mode(str, Enum):
    POWERED_CLIMB = "POWERED_CLIMB"
    THERMAL_SEARCH = "THERMAL_SEARCH"
    THERMAL_INVESTIGATION = "THERMAL_INVESTIGATION"
    THERMAL_CIRCLING = "THERMAL_CIRCLING"
    TRANSITION_GLIDE = "TRANSITION_GLIDE"
    DYNAMIC_SOARING_RESEARCH = "DYNAMIC_SOARING_RESEARCH"
    ENERGY_CRUISE = "ENERGY_CRUISE"
    MISSION_NAV = "MISSION_NAV"
    RETURN_RECOVERY = "RETURN_RECOVERY"
    LANDED = "LANDED"


# Documented transition table (also served to the UI).
TRANSITIONS = [
    {"from": "any", "to": "RETURN_RECOVERY", "condition": "GNSS fix lost > 1.5 s, OR link lost > link_timeout, OR SOC < reserve and below motor floor, OR outside final-glide reach with no motor energy, OR beyond geofence"},
    {"from": "any (airborne)", "to": "POWERED_CLIMB", "condition": "height AGL < motor_on_agl AND motor available AND SOC > reserve AND not climbing in confirmed lift"},
    {"from": "POWERED_CLIMB", "to": "THERMAL_SEARCH / ENERGY_CRUISE / MISSION_NAV", "condition": "height AGL >= motor_off_agl"},
    {"from": "THERMAL_SEARCH / MISSION_NAV / TRANSITION_GLIDE(after min time)", "to": "THERMAL_INVESTIGATION", "condition": "netto > detect_threshold for detect_persistence s, netto sigma < 0.6 m/s, motor off, not inside an exploited thermal"},
    {"from": "THERMAL_INVESTIGATION", "to": "THERMAL_CIRCLING", "condition": "time >= confirm_min_time AND EKF centre sigma < confirm_sigma AND estimated W > 0.8*detect AND 20 s mean climb > confirm_climb"},
    {"from": "THERMAL_INVESTIGATION", "to": "THERMAL_SEARCH", "condition": "time > investigation_timeout, OR (time > 15 s AND mean climb < -0.3 AND W_est < 0.3) -> record REJECTED"},
    {"from": "THERMAL_CIRCLING", "to": "TRANSITION_GLIDE", "condition": "height >= ceiling, OR 20 s mean climb < exit_climb for exit_weak_time, OR W_est < 0.25 -> record EXPLOITED"},
    {"from": "TRANSITION_GLIDE", "to": "THERMAL_SEARCH", "condition": "time in mode >= transition_time"},
    {"from": "RETURN_RECOVERY", "to": "LANDED", "condition": "touch-down detected (height AGL <= 0)"},
    {"from": "any", "to": "DYNAMIC_SOARING_RESEARCH", "condition": "never in 6-DOF flight: refused (research module only)"},
]


class AutonomyConfig(BaseModel):
    soaring_enabled: bool = True
    motor_policy: str = Field("reclimb", description="reclimb | sustain (continuous powered altitude hold) | never")
    planner: str = Field("utility", description="utility | nearest | none (AI policy comparison)")
    motor_on_agl: float = 70.0
    motor_off_agl: float = 220.0
    ceiling_m: float = 700.0
    sustain_altitude_m: float = 200.0
    reserve_soc: float = Field(0.25, ge=0.05, le=0.9)
    detect_threshold: float = 0.5
    detect_persistence_s: float = 1.6
    confirm_sigma_m: float = 22.0
    confirm_climb: float = 0.15
    confirm_min_time_s: float = 14.0
    investigation_timeout_s: float = 55.0
    exit_climb: float = 0.25
    exit_weak_time_s: float = 40.0
    circle_settle_s: float = 30.0
    transition_time_s: float = 12.0
    circle_bank_max_deg: float = 30.0
    circle_radius_min_m: float = 25.0
    centre_smoothing_s: float = 5.0
    probe_max_s: float = Field(6.0, ge=0, le=20, description="max straight flight after detection while lift increases")
    probe_drop_ms: float = Field(0.2, ge=0.05, le=1.0, description="netto drop below the peak that ends the probe")
    circle_speed_margin: float = Field(1.14, ge=1.0, le=1.5, description="circling speed / min-sink speed in the turn (gust margin)")
    centre_max_rate_ms: float = 2.5
    search_radius_m: float = 450.0
    geofence_radius_m: float = 1500.0
    link_timeout_s: float = 10.0
    cruise_speed_mode: str = Field("maccready", description="maccready | best_glide")
    waypoints: list[tuple[float, float]] = Field(default_factory=list)
    loop_mission: bool = True
    home: tuple[float, float] = (0.0, 0.0)
    request_dynamic_soaring: bool = False
    drift_prior: str = Field("layer", description="layer (shear-aware: estimated wind averaged over the mixed layer) | local (wind at the aircraft)")
    ekf_profile: str = Field("gaussian", description="thermal EKF measurement model: gaussian | gedeon (with sink ring)")
    ekf_netto_floor: float | None = Field(None, description="clip netto from below before the EKF update (None = off)")
    fence_aware: bool = Field(True, description="plan entry/exit with the time until drifting lift crosses the geofence")
    fence_margin_m: float = Field(60.0, ge=0, description="margin inside the geofence used by the drift-time predictions")
    fence_exit_lead_s: float = Field(10.0, ge=0, description="leave a thermal this long before its circle would cross the fence")
    fence_min_climb_s: float = Field(60.0, ge=0, description="do not start on lift (or keep sweeping) with less drift room than this")
    fence_ref_s: float = Field(180.0, gt=0, description="planner: options with this much drift room or more get full score")
    recentre: bool = Field(True, description="per-circle lift-harmonic re-centring (pilot technique) fed to the EKF as a position fix")
    plume_search: bool = Field(True, description="after an empty forecast hotspot in wind, sweep downwind along the drift-projected plume axis")
    plume_min_drift_frac: float = Field(0.6, ge=0, le=2, description="plume sweep only when layer drift >= this x best-glide speed (below it the aircraft can simply turn back upwind)")
    plume_gate_s: float = Field(30.0, ge=0, le=120, description="crosswind 'gate' legs across the drift axis at the source before the sweep (catches a late thermal)")
    plume_gate_half_m: float = Field(50.0, ge=10, le=200, description="half-length of the crosswind gate legs")
    plume_search_s: float = Field(45.0, ge=0, le=180, description="maximum downwind sweep duration after the gate")
    zi_estimate_m: float = Field(1200.0, gt=100, le=4000, description="mixed-layer depth used by the drift prior (forecast/config value, not measured)")


@dataclass
class Decision:
    t: float
    kind: str
    message: str
    data: dict = field(default_factory=dict)

    def as_dict(self):
        return {"t": round(self.t, 2), "kind": self.kind, "message": self.message, "data": self.data}


class SoaringAutonomy:
    def __init__(self, model: AircraftModel, cfg: AutonomyConfig, forecast: list | None = None, rho: float = 1.19):
        self.model = model
        self.cfg = cfg
        self.mode = Mode.POWERED_CLIMB
        self.t_mode = 0.0
        self.map = ThermalMap()
        self.ekf: ThermalEKF | None = None
        self.active: ThermalRecord | None = None
        self.orbit_center = (0.0, 0.0)
        self.orbit_dir = 1
        self.orbit_radius = 25.0
        self.detect_timer = 0.0
        self.climb_hist: list[tuple[float, float]] = []
        self.netto_hist: list[tuple[float, float]] = []
        self.pos_hist: list[tuple[float, float, float]] = []
        self.netto_lag_s = 0.4
        self.probe: dict | None = None
        self.t_circle0 = 0.0
        self.weak_timer = 0.0
        self.log: list[Decision] = []
        self.plan_log: list[dict] = []
        self.target: dict | None = None
        self.last_plan_t = -1e9
        self.search_idx = 0
        self.wp_idx = 0
        self.forecast = forecast or []
        self.visited_forecast: set[str] = set()
        self.cooldown: dict[str, float] = {}
        self.rho = rho
        self.vs = performance.stall_speed(model, rho)
        self.bg = performance.best_glide(model, rho)
        self.ms = performance.min_sink(model, rho)
        self.mc_cache: dict[float, float] = {}
        self.landed = False
        self.reserve_used = False
        self.reason_return = ""
        if cfg.request_dynamic_soaring:
            self._log(0.0, "refusal", "Dynamic-soaring mode requested but refused: it is a separate point-mass research "
                      "module and is not flight-qualified in the 6-DOF autonomy stack.")
        n = 8
        r = cfg.search_radius_m
        self.search_pts = [(cfg.home[0] + r * math.cos(2 * math.pi * k / n), cfg.home[1] + r * math.sin(2 * math.pi * k / n)) for k in range(n)]

    # ---------------------------------------------------------------- helpers
    def _log(self, t, kind, msg, **data):
        self.log.append(Decision(t, kind, msg, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in data.items()}))

    def _set_mode(self, t: float, new: Mode, reason: str, **data):
        if new == self.mode:
            return
        self._log(t, "mode", f"{self.mode.value} -> {new.value}: {reason}", from_mode=self.mode.value, to_mode=new.value, **data)
        self.mode = new
        self.t_mode = t

    def maccready(self, climb: float) -> float:
        key = round(max(0.0, climb) * 4) / 4
        if key not in self.mc_cache:
            self.mc_cache[key] = performance.maccready_speed(self.model, self.rho, key)
        return self.mc_cache[key]

    def climb_avg(self, t: float, window: float = 20.0) -> float:
        pts = [(tt, h) for tt, h in self.climb_hist if t - tt <= window]
        if len(pts) < 2 or pts[-1][0] - pts[0][0] < 3.0:
            return 0.0
        return (pts[-1][1] - pts[0][1]) / (pts[-1][0] - pts[0][0])

    def mean_netto(self, t: float, window: float) -> float:
        v = [z for tt, z in self.netto_hist if t - tt <= window]
        return sum(v) / len(v) if v else 0.0

    def motor_available(self, soc: float, health) -> bool:
        pc = self.model.cfg.propulsion
        return pc.enabled and self.cfg.motor_policy != "never" and soc > self.cfg.reserve_soc

    # ---------------------------------------------------------------- planner
    def plan(self, t: float, nav: NavState, wind, agl: float, motor_ok: bool) -> dict:
        """Rank thermal opportunities. Returns the chosen option with an explanation."""
        c = self.cfg
        h_floor = c.motor_on_agl if motor_ok else 30.0
        usable_h = max(1.0, agl - h_floor)
        opts = []
        for rec in self.map.usable(t, max_age=300.0):
            if self.cooldown.get(rec.id, -1e9) > t or rec.confidence < 0.1:
                continue
            pn, pe = rec.predicted_position(t)
            climb = rec.climb_achieved if rec.status == "exploited" else max(0.0, 0.6 * rec.strength - self.ms["sink"])
            opts.append({"id": rec.id, "kind": f"map:{rec.status}", "n": pn, "e": pe, "p": rec.confidence, "climb": climb,
                         "sigma": rec.sigma_pos})
        for fh in self.forecast:
            if fh.id in self.visited_forecast:
                continue
            opts.append({"id": fh.id, "kind": "forecast", "n": fh.x_m, "e": fh.y_m, "p": fh.probability,
                         "climb": max(0.0, 0.6 * fh.expected_strength_ms - self.ms["sink"]), "sigma": fh.position_sigma_m})
        sp = self.search_pts[self.search_idx % len(self.search_pts)]
        opts.append({"id": f"S{self.search_idx % len(self.search_pts) + 1}", "kind": "search", "n": sp[0], "e": sp[1], "p": 0.15,
                     "climb": 0.8, "sigma": 200.0})
        for o in opts:
            dn, de = o["n"] - nav.n, o["e"] - nav.e
            d = math.hypot(dn, de)
            brg = math.atan2(de, dn)
            tail = wind[0] * math.cos(brg) + wind[1] * math.sin(brg)
            vg = max(1.0, self.bg["v"] + tail)
            dh = self.bg["sink"] * d / vg
            o.update(distance=d, arrival_agl=agl - dh, cost=dh / usable_h)
            from_home = math.hypot(o["n"] - c.home[0], o["e"] - c.home[1])
            feasible = (o["arrival_agl"] > h_floor + 15 or motor_ok) and from_home < 0.8 * c.geofence_radius_m
            o["feasible"] = feasible
            room = self._fence_time(o["n"], o["e"], *self._layer_drift(), margin=c.fence_margin_m) if c.fence_aware else float("inf")
            o["drift_room_s"] = room
            f_room = min(1.0, room / c.fence_ref_s)
            o["score"] = (o["p"] * o["climb"] * max(0.0, 1 - o["cost"]) * f_room - 0.0005 * o["sigma"]) if feasible else -1.0
        if c.planner == "nearest":
            cand = [o for o in opts if o["p"] >= 0.3 and o["feasible"]] or [o for o in opts if o["kind"] == "search"]
            best = min(cand, key=lambda o: o["distance"])
            why = f"nearest-opportunity policy: {best['id']} at {best['distance']:.0f} m"
        elif c.planner == "none":
            best = [o for o in opts if o["kind"] == "search"][0]
            why = f"no planner: follow search pattern point {best['id']}"
        else:
            best = max(opts, key=lambda o: o["score"])
            rejected = sorted([o for o in opts if o is not best], key=lambda o: -o["score"])[:3]
            parts = [f"{o['id']} ({'infeasible: arrival ' + format(o['arrival_agl'], '.0f') + ' m AGL' if not o['feasible'] else 'score ' + format(o['score'], '.3f')})" for o in rejected]
            why = (f"{best['id']} [{best['kind']}]: expected climb {best['climb']:.2f} m/s x P={best['p']:.2f}, "
                   f"{best['distance']:.0f} m away, arrival {best['arrival_agl']:.0f} m AGL "
                   f"({100 * best['cost']:.0f}% of usable height)"
                   + (f", drift room before the geofence {best['drift_room_s']:.0f} s" if best["drift_room_s"] < 1e6 else "")
                   + f" -> score {best['score']:.3f}. Next best: " + ("; ".join(parts) or "none"))
        best = dict(best)
        best["explanation"] = why
        return best

    # ---------------------------------------------------------------- main update (10 Hz)
    def update(self, t: float, dt: float, nav: NavState, netto: float, netto_fast: float, netto_sigma: float,
               wind: tuple[float, float], health, soc: float, agl: float, motor_on: bool) -> GuidanceCommand:
        c = self.cfg
        self._wind = wind
        self._wind_sigma = getattr(self, "_wind_sigma_ext", 0.5)
        self.climb_hist.append((t, nav.h))
        self.netto_hist.append((t, netto))
        while self.netto_hist and t - self.netto_hist[0][0] > 20.0:
            self.netto_hist.pop(0)
        while self.climb_hist and t - self.climb_hist[0][0] > 60.0:
            self.climb_hist.pop(0)
        motor_ok = self.motor_available(soc, health)
        if self.mode == Mode.LANDED:
            return GuidanceCommand(mode="wings_level", airspeed=self.ms["v"])
        # ---------------- global safety transitions (priority order)
        dist_home = math.hypot(nav.n - c.home[0], nav.e - c.home[1])
        if self.mode != Mode.RETURN_RECOVERY:
            reason = None
            if not health.gnss_ok:
                reason = "GNSS fix lost - navigation degraded, returning on estimated position"
            elif not health.link_ok and t - self._link_lost_since(t, health) > c.link_timeout_s:
                reason = f"telemetry link lost > {c.link_timeout_s:.0f} s (lost-link procedure)"
            elif soc <= c.reserve_soc and agl < c.motor_on_agl and self.mode not in (Mode.THERMAL_CIRCLING, Mode.THERMAL_INVESTIGATION):
                reason = f"battery at reserve (SOC {soc:.2f} <= {c.reserve_soc:.2f}) and below motor floor"
            elif dist_home > c.geofence_radius_m:
                reason = f"geofence: {dist_home:.0f} m from home > {c.geofence_radius_m:.0f} m"
            elif not motor_ok and self.mode not in (Mode.THERMAL_CIRCLING, Mode.THERMAL_INVESTIGATION):
                need = dist_home / max(5.0, self.bg["ld"] * 0.6) + 25.0
                if agl < need:
                    reason = f"final-glide reach: need {need:.0f} m AGL to reach home with margin, have {agl:.0f} m and no usable motor energy"
            if reason:
                self.reason_return = reason
                self._end_thermal(t, "abandoned", "return triggered")
                self._set_mode(t, Mode.RETURN_RECOVERY, reason, soc=soc, agl=agl, dist_home=dist_home)
        else:
            if health.gnss_ok and health.link_ok and soc > c.reserve_soc + 0.05 and "GNSS" in self.reason_return and agl > 60:
                self._set_mode(t, Mode.THERMAL_SEARCH if c.soaring_enabled else Mode.ENERGY_CRUISE, "GNSS restored, resuming mission")
        # ---------------- low-altitude motor recovery
        if self.mode not in (Mode.POWERED_CLIMB, Mode.RETURN_RECOVERY) and agl < c.motor_on_agl and motor_ok:
            climbing = self.mode == Mode.THERMAL_CIRCLING and self.climb_avg(t) > 0.3
            if not climbing:
                self._end_thermal(t, "abandoned", "too low - powered recovery")
                self._set_mode(t, Mode.POWERED_CLIMB, f"height {agl:.0f} m AGL < motor floor {c.motor_on_agl:.0f} m; SOC {soc:.2f} above reserve",
                               agl=agl, soc=soc)
        if c.motor_policy == "sustain" and self.mode not in (Mode.RETURN_RECOVERY,):
            if self.mode != Mode.ENERGY_CRUISE:
                self._set_mode(t, Mode.ENERGY_CRUISE, "continuous powered flight baseline (altitude hold on motor)")
        # ---------------- mode logic
        m = self.mode
        if m == Mode.POWERED_CLIMB:
            if not motor_ok and agl > 20:
                self._set_mode(t, Mode.THERMAL_SEARCH if c.soaring_enabled else Mode.ENERGY_CRUISE, "motor unavailable (reserve reached) - gliding")
            elif agl >= c.motor_off_agl:
                nxt = Mode.MISSION_NAV if c.waypoints else (Mode.THERMAL_SEARCH if c.soaring_enabled else Mode.ENERGY_CRUISE)
                self._set_mode(t, nxt, f"reached motor-off height {agl:.0f} m AGL", agl=agl)
            course = self._nav_course(t, nav, wind, agl, motor_ok)
            return GuidanceCommand(mode="course", course=course, airspeed=12.0, throttle_mode="climb", climb_rate=2.0)
        detecting = c.soaring_enabled and not motor_on and m in (Mode.THERMAL_SEARCH, Mode.MISSION_NAV, Mode.ENERGY_CRUISE, Mode.TRANSITION_GLIDE)
        if m == Mode.TRANSITION_GLIDE and t - self.t_mode < c.transition_time_s:
            detecting = False
        if m == Mode.ENERGY_CRUISE and not c.soaring_enabled:
            detecting = False
        if detecting:
            inside_old = any(math.hypot(nav.n - r.predicted_position(t)[0], nav.e - r.predicted_position(t)[1]) < 1.5 * r.radius
                             and self.cooldown.get(r.id, -1e9) > t for r in self.map.records if r.status in ("exploited", "rejected"))
            if netto > c.detect_threshold and netto_sigma < 0.6 and not inside_old:
                self.detect_timer += dt
            else:
                self.detect_timer = max(0.0, self.detect_timer - 2 * dt)
            if self.detect_timer >= c.detect_persistence_s:
                self.detect_timer = 0.0
                room = self._fence_time(nav.n, nav.e, *self._layer_drift(), margin=self.cfg.fence_margin_m)
                if c.fence_aware and room < c.fence_min_climb_s:
                    if t - getattr(self, "_fence_skip_t", -1e9) > 20.0:
                        self._fence_skip_t = t
                        self._log(t, "plan", f"lift ignored: it would drift out of the geofence in {room:.0f} s (< {c.fence_min_climb_s:.0f} s of climb)",
                                  netto=netto, room_s=room)
                else:
                    self._start_investigation(t, nav, netto, netto_sigma)
                m = self.mode
        if m in (Mode.THERMAL_INVESTIGATION, Mode.THERMAL_CIRCLING):
            return self._thermal_logic(t, dt, nav, netto_fast, netto_sigma, wind, agl)
        if m == Mode.TRANSITION_GLIDE:
            if t - self.t_mode >= c.transition_time_s:
                self._set_mode(t, Mode.THERMAL_SEARCH, "transition complete, resuming search")
            course = self._nav_course(t, nav, wind, agl, motor_ok)
            return GuidanceCommand(mode="course", course=course, airspeed=self._cruise_speed())
        if m == Mode.RETURN_RECOVERY:
            return self._return_logic(t, nav, wind, agl, soc, dist_home)
        if m == Mode.ENERGY_CRUISE and c.motor_policy == "sustain":
            course = self._nav_course(t, nav, wind, agl, True)
            return GuidanceCommand(mode="course", course=course, airspeed=self.bg["v"] * 1.05, throttle_mode="altitude", altitude=c.sustain_altitude_m)
        course = self._nav_course(t, nav, wind, agl, motor_ok)
        return GuidanceCommand(mode="course", course=course, airspeed=self._cruise_speed())

    def _link_lost_since(self, t, health):
        if health.link_ok:
            self._link_t0 = None
            return t
        if getattr(self, "_link_t0", None) is None:
            self._link_t0 = t
        return self._link_t0

    def _cruise_speed(self) -> float:
        if self.cfg.cruise_speed_mode == "best_glide" or not self.cfg.soaring_enabled:
            return self.bg["v"]
        mc = self.target["climb"] * self.target["p"] if self.target else 0.5
        return self.maccready(mc)

    def _nav_course(self, t, nav, wind, agl, motor_ok) -> float:
        c = self.cfg
        if c.waypoints and self.mode in (Mode.MISSION_NAV, Mode.POWERED_CLIMB):
            wp = c.waypoints[self.wp_idx % len(c.waypoints)]
            if math.hypot(wp[0] - nav.n, wp[1] - nav.e) < 40:
                self._log(t, "mission", f"waypoint {self.wp_idx % len(c.waypoints) + 1} reached")
                self.wp_idx += 1
                if not c.loop_mission and self.wp_idx >= len(c.waypoints):
                    self.reason_return = "mission complete"
                    self._set_mode(t, Mode.RETURN_RECOVERY, "mission complete - returning home")
                wp = c.waypoints[self.wp_idx % len(c.waypoints)]
            return math.atan2(wp[1] - nav.e, wp[0] - nav.n)
        if self.target is not None and self.target["kind"] == "plume":
            return self._plume_course(t, nav)
        if t - self.last_plan_t > 5.0 or self.target is None:
            self.last_plan_t = t
            choice = self.plan(t, nav, wind, agl, motor_ok)
            if self.target is None or choice["id"] != self.target["id"]:
                self._log(t, "plan", "target -> " + choice["explanation"], target=choice["id"], score=choice.get("score", 0.0))
                self.plan_log.append({"t": round(t, 1), "target": choice["id"], "kind": choice["kind"], "explanation": choice["explanation"]})
            self.target = choice
        tg = self.target
        if math.hypot(tg["n"] - nav.n, tg["e"] - nav.e) < 50:
            if tg["kind"] == "search":
                self.search_idx += 1
            elif tg["kind"] == "forecast":
                if self._start_plume(t, nav, tg):
                    return self._plume_course(t, nav)
                self.visited_forecast.add(tg["id"])
                self._log(t, "plan", f"forecast {tg['id']} reached - no lift detected there (forecast not confirmed)")
            else:
                self.cooldown[tg["id"]] = t + 120.0
            self.target = None
            self.last_plan_t = -1e9
            return nav.course
        return math.atan2(tg["e"] - nav.e, tg["n"] - nav.n)

    # ---------------------------------------------------------------- thermal handling
    def _start_investigation(self, t, nav, netto, sigma):
        # Probe phase (classic glider-pilot entry): keep flying straight while the lift still increases,
        # then centre the first circle and the EKF on the (lag-compensated) netto peak.
        cn, ce = nav.n, nav.e
        self.ekf = None
        self.probe = {"t0": t, "max": netto, "pos": (cn, ce), "course": nav.course}
        rec = self.map.add(ThermalRecord(t, cn, ce, nav.h))
        rec.notes.append(f"detected at t={t:.1f}s: netto {netto:.2f}+/-{sigma:.2f} m/s for >= {self.cfg.detect_persistence_s:.1f} s")
        self.active = rec
        self.orbit_center = (cn, ce)
        self.orbit_dir = 1
        self.weak_timer = 0.0
        self.t_circle0 = t
        # A forecast counts as "explained" only if this detection is inside its position uncertainty;
        # otherwise a gust-triggered candidate on the way would cancel a still-valid forecast.
        if self.target and self.target["kind"] == "forecast" and math.hypot(cn - self.target["n"], ce - self.target["e"]) < self.target["sigma"]:
            self.visited_forecast.add(self.target["id"])
        if self.target and self.target["kind"] == "plume":
            # a detection on the plume axis explains the forecast; if it is rejected the sweep resumes (until its time is up)
            self.visited_forecast.add(self.target["source"])
        self._set_mode(t, Mode.THERMAL_INVESTIGATION, f"lift detected: netto {netto:.2f} m/s (sigma {sigma:.2f}) above {self.cfg.detect_threshold:.2f} m/s",
                       netto=netto, sigma=sigma, record=rec.id)

    def _end_thermal(self, t, status, why):
        if self.active is not None:
            if status == "abandoned":
                # left for a safety/energy reason: a confirmed thermal stays a (used) thermal, a candidate is unconfirmed
                status = "rejected" if self.active.status == "candidate" else "exploited"
            self.active.status = status
            self.active.notes.append(f"t={t:.1f}s {status}: {why}")
            self.cooldown[self.active.id] = t + (180.0 if status != "rejected" else 90.0)
        self.active = None
        self.ekf = None
        self.probe = None

    # ---------------------------------------------------------------- drift-projected plume sweep
    def _layer_drift(self):
        pr = getattr(self, "drift_prior", None)
        if self.cfg.drift_prior == "layer" and pr is not None:
            return pr["drift"]
        return self._wind

    def _start_plume(self, t, nav, tg) -> bool:
        """Forecast hotspot reached without lift. A hotspot is a ground *source*: thermals it released
        drift downwind along the layer-mean drift. In wind, sweep that axis downwind: ground speed
        (airspeed + local wind) exceeds the drift, so thermals released in the last ~sweep time are
        overtaken. A thermal not yet released is not found (documented limitation)."""
        c = self.cfg
        dn, de = self._layer_drift()
        sp = math.hypot(dn, de)
        if not c.plume_search or sp < c.plume_min_drift_frac * self.bg["v"] or c.plume_search_s <= 0:
            return False
        self.target = {"id": tg["id"] + "-plume", "kind": "plume", "source": tg["id"], "n": tg["n"], "e": tg["e"],
                       "axis": math.atan2(de, dn), "t0": t, "phase": "gate" if c.plume_gate_s > 0 else "sweep", "t_phase": t, "side": 1,
                       "p": tg["p"], "climb": tg["climb"], "sigma": tg["sigma"]}
        msg = (f"forecast {tg['id']} reached without lift; layer drift {sp:.1f} m/s toward {math.degrees(math.atan2(de, dn)) % 360:.0f} deg "
               f"-> crosswind gate across the drift axis for {c.plume_gate_s:.0f} s (thermal arriving late), then downwind sweep "
               f"along the drift-projected axis for up to {c.plume_search_s:.0f} s (thermal already passed)")
        self._log(t, "plan", msg, target=self.target["id"])
        self.plan_log.append({"t": round(t, 1), "target": self.target["id"], "kind": "plume", "explanation": msg})
        return True

    def _plume_course(self, t, nav) -> float:
        tg = self.target
        ax = tg["axis"]
        rn, re = nav.n - tg["n"], nav.e - tg["e"]
        along = rn * math.cos(ax) + re * math.sin(ax)
        cross = -rn * math.sin(ax) + re * math.cos(ax)
        c = self.cfg
        # time spent investigating a candidate does not count against the gate/sweep budgets
        gap = t - tg.get("t_last", t)
        if gap > 1.0:
            tg["t_phase"] += gap
        tg["t_last"] = t
        if tg["phase"] == "gate":
            if t - tg["t_phase"] < c.plume_gate_s:
                if tg["side"] * cross > c.plume_gate_half_m:
                    tg["side"] = -tg["side"]
                perp = ax + tg["side"] * 0.5 * math.pi
                wn = tg["n"] + c.plume_gate_half_m * 1.2 * math.cos(perp)
                we = tg["e"] + c.plume_gate_half_m * 1.2 * math.sin(perp)
                return math.atan2(we - nav.e, wn - nav.n)
            tg["phase"], tg["t_phase"] = "sweep", t
            self._log(t, "plan", f"plume gate at {tg['source']}: no lift in {c.plume_gate_s:.0f} s -> downwind sweep")
        if c.fence_aware and self._fence_time(nav.n, nav.e, *self._layer_drift(), margin=c.fence_margin_m) < c.fence_min_climb_s:
            self.visited_forecast.add(tg["source"])
            self._log(t, "plan", f"plume sweep from {tg['source']} stopped {along:.0f} m downwind: lift found further on would drift out of the geofence within {c.fence_min_climb_s:.0f} s")
            self.target = None
            self.last_plan_t = -1e9
            return nav.course
        if t - tg["t_phase"] > c.plume_search_s:
            self.visited_forecast.add(tg["source"])
            self._log(t, "plan", f"plume sweep from {tg['source']} ended after {t - tg['t0']:.0f} s / {along:.0f} m downwind - no lift (forecast not confirmed)")
            self.target = None
            self.last_plan_t = -1e9
            return nav.course
        # line following onto the axis (40 m look-ahead), never steering upwind of the source
        return ax - math.atan2(cross, 40.0)

    def _fence_time(self, n, e, vn, ve, margin: float = 0.0) -> float:
        """Seconds until a point at (n, e) moving with (vn, ve) leaves the geofence circle shrunk by
        ``margin``; 0 if already outside, inf if it never leaves."""
        c = self.cfg
        R = c.geofence_radius_m - margin
        pn, pe = n - c.home[0], e - c.home[1]
        if pn * pn + pe * pe >= R * R:
            return 0.0
        a = vn * vn + ve * ve
        if a < 1e-6:
            return float("inf")
        b = 2 * (pn * vn + pe * ve)
        cc = pn * pn + pe * pe - R * R
        return (-b + math.sqrt(b * b - 4 * a * cc)) / (2 * a)

    def _recentre(self, t, pn, pe, z, sigma):
        """Classic pilot re-centring, made estimator-independent: over each full circle, fit
        netto = a0 + a1 cos(th) + b1 sin(th) in the frame moving with the thermal. For any axisymmetric
        thermal the first harmonic peaks toward the core, whatever its radial profile. The shift
        (amplitude / local lift slope, capped at half the circle radius) enters the EKF as a position fix."""
        ekf = self.ekf
        if getattr(self, "_rc_ekf", None) is not ekf:
            self._rc_ekf, self._rc_buf, self._rc_last = ekf, [], t
        buf = self._rc_buf
        buf.append((t, pn, pe, z))
        r_orb = getattr(self, "orbit_radius", self.cfg.circle_radius_min_m) or self.cfg.circle_radius_min_m
        t_circ = 2 * math.pi * r_orb / max(6.0, getattr(self, "_vcirc", 10.0))
        while buf and t - buf[0][0] > t_circ:
            buf.pop(0)
        if t - self._rc_last < t_circ or len(buf) < 30 or t - buf[0][0] < 0.9 * t_circ:
            return
        self._rc_last = t
        dn, de = ekf.drift
        q = np.array([[p_n + dn * (t - ti), p_e + de * (t - ti)] for ti, p_n, p_e, _ in buf])
        zz = np.array([b[3] for b in buf])
        m = q.mean(axis=0)
        th = np.arctan2(q[:, 1] - m[1], q[:, 0] - m[0])
        span = np.ptp(np.unwrap(th))
        if span < 1.6 * math.pi:
            return  # not a full circle (e.g. straight probe segment)
        X = np.column_stack([np.ones_like(th), np.cos(th), np.sin(th)])
        coef, *_ = np.linalg.lstsq(X, zz, rcond=None)
        amp = float(math.hypot(coef[1], coef[2]))
        sig_amp = max(0.45, sigma) * math.sqrt(2.0 / len(zz))
        if amp < 2.5 * sig_amp:
            return
        u = (coef[1] / amp, coef[2] / amp)
        r_mean = float(np.mean(np.hypot(q[:, 0] - m[0], q[:, 1] - m[1])))
        step = min(0.5 * r_mean, amp / max(0.03, ekf.lift_slope(r_mean)))
        ekf.position_fix(m[0] + u[0] * step, m[1] + u[1] * step, 0.5 * step + 8.0)
        self._rc_count = getattr(self, "_rc_count", 0) + 1

    def _drift_anchor(self, wind):
        """Drift pseudo-measurement: shear-aware layer-mean wind (default) or the local wind."""
        base = 1.0 + 0.5 * min(1.0, self._wind_sigma)
        pr = getattr(self, "drift_prior", None)
        if self.cfg.drift_prior == "layer" and pr is not None:
            return pr["drift"], max(base, pr["sigma"]), 2.0 + pr["sigma"]
        return wind, base, 2.0

    def _thermal_logic(self, t, dt, nav, z, sigma, wind, agl):
        c = self.cfg
        # netto is ~0.4 s behind the aircraft (filters): pair it with the position 0.4 s ago
        self.pos_hist.append((t, nav.n, nav.e))
        while len(self.pos_hist) > 2 and t - self.pos_hist[1][0] >= self.netto_lag_s:
            self.pos_hist.pop(0)
        _, pn_d, pe_d = self.pos_hist[0]
        if self.probe is not None:
            pr = self.probe
            if z > pr["max"]:
                pr["max"], pr["pos"] = z, (pn_d, pe_d)
            elapsed = t - pr["t0"]
            if z < pr["max"] - c.probe_drop_ms or elapsed > c.probe_max_s:
                cn, ce = pr["pos"]
                anchor0, _, _ = self._drift_anchor(wind)
                self.ekf = ThermalEKF(cn, ce, w0=max(pr["max"] + 0.3, 1.0), r0=50.0 if c.ekf_profile == "gaussian" else 70.0, drift=anchor0,
                                      profile=c.ekf_profile, netto_floor=c.ekf_netto_floor)
                self.orbit_center = (cn, ce)
                self.active.n, self.active.e = cn, ce
                self.active.notes.append(f"probe: netto peak {pr['max']:.2f} m/s after {elapsed:.1f} s straight flight; first circle centred on the peak")
                self.probe = None
                self.t_circle0 = t
            else:
                return GuidanceCommand(mode="course", course=pr["course"], airspeed=1.1 * self.ms["v"])
        ekf = self.ekf
        ekf.predict(dt, wind)
        ekf.update(pn_d, pe_d, z, max(0.25, sigma))
        anchor, a_sigma, a_dev = self._drift_anchor(wind)
        ekf.anchor_drift(anchor, sigma=a_sigma, max_dev=a_dev)
        if c.recentre:
            self._recentre(t, pn_d, pe_d, z, sigma)
        snap = ekf.snapshot()
        climb = self.climb_avg(t)
        rec = self.active
        rec.update_from_ekf(t, ekf, nav.h, wind, climb)
        # smooth the orbit centre toward the estimate
        # smooth + rate-limit the orbit centre (beyond the wind drift) so EKF jitter does not shake the circle
        k = min(1.0, dt / self.cfg.centre_smoothing_s)
        dn_c = k * (snap["n"] - self.orbit_center[0])
        de_c = k * (snap["e"] - self.orbit_center[1])
        lim = self.cfg.centre_max_rate_ms * dt
        mag = math.hypot(dn_c, de_c)
        if mag > lim:
            dn_c, de_c = dn_c * lim / mag, de_c * lim / mag
        drift = ekf.drift
        self.orbit_center = (self.orbit_center[0] + dn_c + drift[0] * dt, self.orbit_center[1] + de_c + drift[1] * dt)
        best = performance.best_circle_in_thermal(self.model, self.rho, max(0.5, snap["strength"]), snap["radius"], profile=c.ekf_profile) if int(t * 10) % 20 == 0 or not hasattr(self, "_best") else self._best
        self._best = best
        bank = min(c.circle_bank_max_deg, best["bank_deg"])
        n = 1 / math.cos(math.radians(bank))
        v = c.circle_speed_margin * performance.min_sink(self.model, self.rho, n)["v"] if int(t * 10) % 20 == 0 or not hasattr(self, "_vcirc") else self._vcirc
        self._vcirc = v
        radius = max(c.circle_radius_min_m, v * v / (G * math.tan(math.radians(bank))))
        self.orbit_radius = radius
        t_in = t - self.t_mode
        if self.mode == Mode.THERMAL_INVESTIGATION:
            t_in = t - self.t_circle0  # time spent circling (after the probe)
            if (t_in >= c.confirm_min_time_s and snap["sigma_pos"] < c.confirm_sigma_m and snap["strength"] > 0.8 * c.detect_threshold
                    and climb > c.confirm_climb):
                rec.status = "confirmed"
                rec.notes.append(f"confirmed t={t:.1f}s: centre sigma {snap['sigma_pos']:.1f} m, W {snap['strength']:.2f} m/s, climb {climb:.2f} m/s")
                self._set_mode(t, Mode.THERMAL_CIRCLING, f"thermal confirmed: W={snap['strength']:.2f} m/s, R={snap['radius']:.0f} m, centre sigma {snap['sigma_pos']:.1f} m, mean climb {climb:.2f} m/s",
                               record=rec.id, strength=snap["strength"], radius=snap["radius"], sigma=snap["sigma_pos"], climb=climb)
            elif t_in > c.investigation_timeout_s or (t_in > 25 and climb < 0.0 and self.mean_netto(t, 15.0) < 0.15):
                why = (f"not confirmed after {t_in:.0f} s (W_est={snap['strength']:.2f}, sigma {snap['sigma_pos']:.0f} m, "
                       f"mean climb {climb:.2f} m/s, mean netto {self.mean_netto(t, 15.0):.2f} m/s)")
                self._end_thermal(t, "rejected", why)
                self._set_mode(t, Mode.THERMAL_SEARCH, "investigation rejected: " + why)
                return GuidanceCommand(mode="course", course=nav.course, airspeed=self._cruise_speed())
        else:
            if climb < c.exit_climb and t_in > c.circle_settle_s:
                self.weak_timer += dt
            else:
                self.weak_timer = 0.0
            reason = None
            room = self._fence_time(self.orbit_center[0], self.orbit_center[1], *ekf.drift, margin=radius + 20.0)
            if c.fence_aware and room < c.fence_exit_lead_s:
                reason = (f"thermal drifting out of the geofence in {room:.0f} s (drift {math.hypot(*ekf.drift):.1f} m/s): "
                          f"leaving at {nav.h:.0f} m instead of breaching the fence")
            elif nav.h >= c.ceiling_m:
                reason = f"ceiling reached ({nav.h:.0f} m)"
            elif self.weak_timer > c.exit_weak_time_s:
                reason = f"thermal weakening: mean climb {climb:.2f} m/s < {c.exit_climb:.2f} for {self.weak_timer:.0f} s"
            elif t_in > 30 and self.mean_netto(t, 20.0) < -0.1 and climb < 0.0:
                reason = f"lift lost (20 s mean netto {self.mean_netto(t, 20.0):.2f} m/s, mean climb {climb:.2f} m/s)"
            if reason:
                if "ceiling" not in reason and "geofence" not in reason and self.active is not None:
                    self.active.confidence *= 0.4  # weakening/lost lift: less worth returning to
                self._end_thermal(t, "exploited", reason)
                self._set_mode(t, Mode.TRANSITION_GLIDE, reason, climb=climb, h=nav.h)
                return GuidanceCommand(mode="course", course=nav.course, airspeed=self._cruise_speed())
        return GuidanceCommand(mode="orbit", orbit_center=self.orbit_center, orbit_radius=radius, orbit_dir=self.orbit_dir,
                               airspeed=v, bank_limit_deg=min(c.circle_bank_max_deg + 8, math.degrees(math.atan(v * v / (G * radius))) + 12), air_frame=ekf.drift)

    # ---------------------------------------------------------------- recovery
    def _return_logic(self, t, nav, wind, agl, soc, dist_home):
        c = self.cfg
        home = c.home
        brg = math.atan2(home[1] - nav.e, home[0] - nav.n)
        head = -(wind[0] * math.cos(brg) + wind[1] * math.sin(brg))
        v = performance.maccready_speed(self.model, self.rho, 0.0, headwind=max(0.0, head)) if int(t) % 5 == 0 or not hasattr(self, "_vret") else self._vret
        self._vret = v
        need = dist_home / max(5.0, self.bg["ld"] * 0.6) + 15.0
        thr_mode, alt = "off", 0.0
        pc = self.model.cfg.propulsion
        if pc.enabled and c.motor_policy != "never" and agl < need and dist_home > 80 and soc > 0.08:
            if not self.reserve_used:
                self.reserve_used = True
                self._log(t, "energy", f"using reserve energy to reach recovery area (need {need:.0f} m AGL, have {agl:.0f} m)", soc=soc)
            thr_mode, alt = "altitude", nav.h + 10
        if dist_home < 80:
            return GuidanceCommand(mode="orbit", orbit_center=home, orbit_radius=40.0, orbit_dir=1, airspeed=self.ms["v"] * 1.05,
                                   throttle_mode=thr_mode, altitude=alt, bank_limit_deg=30)
        return GuidanceCommand(mode="course", course=brg, airspeed=v, throttle_mode=thr_mode, altitude=alt)
