"""Scenario definitions (A-I from the research brief plus the first-milestone demonstration).

Every scenario is fully described by a ``ScenarioConfig`` (aircraft, atmosphere, sensors, faults,
autonomy, seed). Running the same config twice gives bit-identical results; the config hash and the
model versions are stored with every run.
"""

from __future__ import annotations

import hashlib
import json

from pydantic import BaseModel, Field

from ..aircraft.config import AircraftConfig, BatteryConfig
from ..atmosphere.environment import AtmosphereConfig, ForecastHint, RidgeConfig, ThermalConfig
from ..autonomy.soaring import AutonomyConfig
from ..control.autopilot import AutopilotConfig
from ..sensors.models import FaultEvent, SensorConfig


class InitialState(BaseModel):
    n_m: float = 0.0
    e_m: float = 0.0
    altitude_m: float = 220.0
    heading_deg: float = 0.0
    airspeed_ms: float = 10.5
    mode: str = "THERMAL_SEARCH"


class ScenarioConfig(BaseModel):
    id: str = "custom"
    name: str = "Custom scenario"
    description: str = ""
    kind: str = Field("six_dof", description="six_dof | dynamic_soaring")
    duration_s: float = Field(420.0, gt=5, le=3600)
    dt_s: float = Field(0.02, ge=0.002, le=0.05)
    log_rate_hz: float = Field(5.0, gt=0.5, le=50)
    seed: int = 1
    polar_error: float = Field(0.05, ge=-0.3, le=0.3, description="estimator polar sink bias (model error)")
    initial: InitialState = InitialState()
    aircraft: AircraftConfig = AircraftConfig()
    atmosphere: AtmosphereConfig = AtmosphereConfig()
    sensors: SensorConfig = SensorConfig()
    faults: list[FaultEvent] = Field(default_factory=list)
    autonomy: AutonomyConfig = AutonomyConfig()
    autopilot: AutopilotConfig = AutopilotConfig()
    compare_baselines: list[str] = Field(default_factory=list, description="no_soaring | powered_sustain | glide_only")

    def config_hash(self) -> str:
        d = self.model_dump()
        d.pop("compare_baselines", None)
        return hashlib.sha256(json.dumps(d, sort_keys=True, default=str).encode()).hexdigest()[:16]


def place_thermal(atm: AtmosphereConfig, th: ThermalConfig, n_at: float, e_at: float, t_at: float) -> ThermalConfig:
    """Choose the t=0 position so the drifting thermal is centred at (n_at, e_at) at time t_at."""
    from ..atmosphere.environment import Atmosphere

    probe = Atmosphere(atm.model_copy(update={"thermals": [th]}))
    dn, de = probe._drift_n * th.drift_factor, probe._drift_e * th.drift_factor
    return th.model_copy(update={"x_m": n_at - dn * t_at, "y_m": e_at - de * t_at})


def _milestone() -> ScenarioConfig:
    atm = AtmosphereConfig(wind_speed_ms=2.0, wind_from_deg=250,
                           forecast=[ForecastHint(id="F1", x_m=60, y_m=20, probability=0.6, expected_strength_ms=1.8, position_sigma_m=120)])
    atm.thermals = [place_thermal(atm, ThermalConfig(id="T1", strength_ms=2.4, radius_m=70, zi_m=1100), 75, 25, 40.0)]
    return ScenarioConfig(
        id="milestone", name="M1 — Thermal discovery & circling vs. conventional glide",
        description=("First demonstrable milestone. The glider cruises toward a forecast hotspot at 220 m, detects a "
                     "simulated thermal with its TE-netto variometer, estimates its centre with the thermal EKF, enters a "
                     "controlled circling trajectory and climbs. The same seed is re-run with soaring disabled to compare "
                     "against conventional gliding + powered re-climb."),
        duration_s=480,
        initial=InitialState(n_m=-380, e_m=-60, altitude_m=220, heading_deg=10, mode="THERMAL_SEARCH"),
        atmosphere=atm,
        autonomy=AutonomyConfig(ceiling_m=650),
        compare_baselines=["no_soaring", "powered_sustain"],
    )


def preset_scenarios() -> dict[str, ScenarioConfig]:
    s: dict[str, ScenarioConfig] = {}
    s["milestone"] = _milestone()
    s["A_conventional_glide"] = ScenarioConfig(
        id="A_conventional_glide", name="A — Conventional gliding",
        description="Unpowered glide from 300 m with no thermals. Measures sink rate, glide ratio and distance and compares them with the model polar.",
        duration_s=900, initial=InitialState(n_m=-600, altitude_m=300, heading_deg=0, mode="ENERGY_CRUISE"),
        atmosphere=AtmosphereConfig(wind_speed_ms=0.0, turbulence_sigma_ms=0.0, environment_sink_ms=0.0),
        autonomy=AutonomyConfig(soaring_enabled=False, motor_policy="never", search_radius_m=600, cruise_speed_mode="best_glide",
                                geofence_radius_m=5000),
    )
    s["B_thermal_discovery"] = ScenarioConfig(
        id="B_thermal_discovery", name="B — Thermal discovery",
        description="Single strong, stationary thermal on the search pattern. Tests detection, centring and circling with no drift.",
        duration_s=420, initial=InitialState(n_m=-400, e_m=0, altitude_m=200, heading_deg=0),
        atmosphere=AtmosphereConfig(wind_speed_ms=0.0, thermals=[ThermalConfig(id="T1", x_m=0, y_m=0, strength_ms=2.5, radius_m=65, drift_factor=0.0)],
                                    forecast=[ForecastHint(id="F1", x_m=0, y_m=0, probability=0.5)]),
        compare_baselines=["no_soaring"],
    )
    s["C_thermal_drift"] = ScenarioConfig(
        id="C_thermal_drift", name="C — Thermal drift",
        description="5 m/s wind: the thermal drifts downwind (it is defined by where it is at t = 38 s, so the encounter geometry stays fixed when wind is swept). The EKF estimates the drift; the orbit follows the drifting core.",
        duration_s=480, initial=InitialState(n_m=-350, e_m=-150, altitude_m=230, heading_deg=20),
        atmosphere=AtmosphereConfig(wind_speed_ms=5.0, wind_from_deg=270, turbulence_sigma_ms=0.4,
                                    thermals=[ThermalConfig(id="T1", x_m=20, y_m=10, strength_ms=2.6, radius_m=75, rendezvous_t_s=38.0)],
                                    forecast=[ForecastHint(id="F1", x_m=0, y_m=0, probability=0.6, position_sigma_m=150)]),
        compare_baselines=["no_soaring"],
    )
    s["D_multiple_thermals"] = ScenarioConfig(
        id="D_multiple_thermals", name="D — Multiple thermals",
        description=("Light wind; four hotspot-fed (quasi-stationary, drift factor 0.25) thermals of different strength and three forecast "
                     "hints of different reliability. The utility planner ranks options by expected climb x probability against the "
                     "height cost of reaching them, and explains each choice."),
        duration_s=900, initial=InitialState(n_m=0, e_m=0, altitude_m=240, heading_deg=45),
        atmosphere=AtmosphereConfig(wind_speed_ms=1.0, wind_from_deg=220, thermals=[
            ThermalConfig(id="T1", x_m=350, y_m=300, strength_ms=1.2, radius_m=60, lifetime_s=2400, drift_factor=0.25),
            ThermalConfig(id="T2", x_m=-300, y_m=420, strength_ms=2.8, radius_m=80, lifetime_s=2400, drift_factor=0.25),
            ThermalConfig(id="T3", x_m=-420, y_m=-260, strength_ms=1.8, radius_m=70, lifetime_s=2400, drift_factor=0.25),
            ThermalConfig(id="T4", x_m=420, y_m=-380, strength_ms=0.9, radius_m=55, lifetime_s=2400, drift_factor=0.25),
        ], forecast=[
            ForecastHint(id="F-north", x_m=340, y_m=290, probability=0.7, expected_strength_ms=1.2),
            ForecastHint(id="F-west", x_m=-290, y_m=400, probability=0.5, expected_strength_ms=2.5),
            ForecastHint(id="F-south", x_m=-410, y_m=-250, probability=0.4, expected_strength_ms=1.5),
        ]),
        autonomy=AutonomyConfig(ceiling_m=600, search_radius_m=500),
        compare_baselines=["no_soaring"],
    )
    s["E_weak_turbulent"] = ScenarioConfig(
        id="E_weak_turbulent", name="E — Weak and turbulent conditions",
        description="Weak (0.7 m/s) thermals in strong turbulence (sigma 1.0 m/s). The system must not promote gust-induced detections to confirmed thermals.",
        duration_s=600, initial=InitialState(n_m=-300, altitude_m=230, heading_deg=0),
        atmosphere=AtmosphereConfig(wind_speed_ms=6.0, wind_from_deg=300, turbulence_sigma_ms=1.0, turbulence_length_m=80,
                                    environment_sink_ms=0.15,
                                    thermals=[ThermalConfig(id="T1", x_m=100, y_m=50, strength_ms=0.7, radius_m=55),
                                              ThermalConfig(id="T2", x_m=-200, y_m=-300, strength_ms=0.6, radius_m=50)]),
        compare_baselines=["no_soaring"],
    )
    s["F_dynamic_soaring"] = ScenarioConfig(
        id="F_dynamic_soaring", name="F — Dynamic-soaring research",
        description="Runs the separate point-mass dynamic-soaring module in a logistic wind-shear layer: optimal energy-neutral cycle (CasADi) and energy-exchange sweep. Theoretical — not flown by the 6-DOF autonomy.",
        kind="dynamic_soaring", duration_s=60,
    )
    s["G_powered_recovery"] = ScenarioConfig(
        id="G_powered_recovery", name="G — Powered recovery",
        description="No usable thermals and broad sink. The aircraft glides down to the motor floor, re-climbs on the motor while SOC stays above reserve, and finally returns when the reserve is reached.",
        duration_s=1500, initial=InitialState(n_m=0, altitude_m=180, heading_deg=90),
        aircraft=AircraftConfig(battery=BatteryConfig(initial_soc=0.45)),
        atmosphere=AtmosphereConfig(wind_speed_ms=4.0, environment_sink_ms=0.35, thermals=[]),
        autonomy=AutonomyConfig(reserve_soc=0.30, motor_on_agl=80, motor_off_agl=180),
    )
    s["H_sensor_failure"] = ScenarioConfig(
        id="H_sensor_failure", name="H — Sensor failures",
        description="Scheduled faults: barometer freezes (120 s), pitot blocks (200 s), GNSS degrades (280 s), gyro bias (340 s), telemetry link lost (420 s). Faults are detected from measurement consistency only.",
        duration_s=520, initial=InitialState(n_m=-300, altitude_m=230, heading_deg=0),
        atmosphere=AtmosphereConfig(wind_speed_ms=3.0, thermals=[ThermalConfig(id="T1", x_m=0, y_m=0, strength_ms=2.4, radius_m=70)],
                                    forecast=[ForecastHint(id="F1", x_m=0, y_m=0, probability=0.6)]),
        faults=[FaultEvent(kind="baro_failure", start_s=120, end_s=200), FaultEvent(kind="airspeed_failure", start_s=200, end_s=260),
                FaultEvent(kind="gnss_degradation", start_s=280, end_s=330), FaultEvent(kind="imu_bias", start_s=340, end_s=390),
                FaultEvent(kind="comm_loss", start_s=420, end_s=520)],
    )
    s["I_energy_reserve"] = ScenarioConfig(
        id="I_energy_reserve", name="I — Energy reserve and recovery",
        description="Out-and-back mission into a 7 m/s headwind with a part-charged battery. The energy manager must keep the configured reserve and the final-glide logic must bring the aircraft back to the recovery area.",
        duration_s=1500, initial=InitialState(n_m=0, altitude_m=200, heading_deg=270, mode="MISSION_NAV"),
        aircraft=AircraftConfig(battery=BatteryConfig(initial_soc=0.40)),
        atmosphere=AtmosphereConfig(wind_speed_ms=6.0, wind_from_deg=270, environment_sink_ms=0.2,
                                    thermals=[ThermalConfig(id="T1", x_m=150, y_m=-700, strength_ms=1.5, radius_m=60)]),
        autonomy=AutonomyConfig(waypoints=[(0, -900), (300, -900), (0, 0)], reserve_soc=0.25, geofence_radius_m=1400),
    )
    s["R_ridge_lift"] = ScenarioConfig(
        id="R_ridge_lift", name="Ridge (terrain) lift",
        description="Wind blowing onto a 120 m ridge produces orographic lift on the windward slope. Demonstrates terrain-related airflow in the atmosphere model and how the thermal estimator treats lift that is not a thermal.",
        duration_s=420, initial=InitialState(n_m=300, e_m=-300, altitude_m=230, heading_deg=0),
        atmosphere=AtmosphereConfig(wind_speed_ms=7.0, wind_from_deg=180, ridge=RidgeConfig(enabled=True, x_m=800, orientation_deg=90)),
        autonomy=AutonomyConfig(search_radius_m=600),
    )
    # J: two ground hotspots that release a thermal every 120 s; each thermal drifts with the wind
    # from its source. Same forecast quality at both; the downwind one is cheaper to reach, the upwind one
    # leaves far more drift room before the geofence. Designed to exercise geofence-aware planning.
    rel = [-60.0, 60.0, 180.0, 300.0, 420.0, 540.0, 660.0, 780.0]
    srcs = {"W": (0.0, -500.0), "E": (0.0, 600.0)}
    s["J_windy_hotspots"] = ScenarioConfig(
        id="J_windy_hotspots", name="J — Windy hotspots near the geofence",
        description=("4 m/s wind (~7 m/s thermal drift). Two hotspots release a 2.2 m/s thermal every 120 s: one 500 m upwind "
                     "of home, one 600 m downwind (900 m from the 1500 m geofence). Both have the same forecast. Downwind is cheaper "
                     "to reach; upwind gives ~4 min of drift room instead of ~2 min. Tests geofence-aware entry, exit and planning."),
        duration_s=900, initial=InitialState(n_m=0, e_m=0, altitude_m=400, heading_deg=0),
        atmosphere=AtmosphereConfig(wind_speed_ms=4.0, wind_from_deg=270, turbulence_sigma_ms=0.4, thermals=[
            ThermalConfig(id=f"{k}{i + 1}", x_m=src[0], y_m=src[1], strength_ms=2.2, radius_m=70, t_start_s=tr, lifetime_s=300,
                          rendezvous_t_s=tr)
            for k, src in srcs.items() for i, tr in enumerate(rel)],
            forecast=[ForecastHint(id="F-upwind", x_m=0, y_m=-500, probability=0.6, expected_strength_ms=2.0, position_sigma_m=100),
                      ForecastHint(id="F-downwind", x_m=0, y_m=600, probability=0.6, expected_strength_ms=2.0, position_sigma_m=100)]),
        compare_baselines=["no_soaring"],
    )
    return s


def get_scenario(sid: str) -> ScenarioConfig:
    p = preset_scenarios()
    if sid not in p:
        raise KeyError(sid)
    return p[sid]
