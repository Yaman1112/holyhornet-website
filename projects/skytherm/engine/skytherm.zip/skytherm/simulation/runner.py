"""Closed-loop simulation runner.

Per step (dt, default 0.02 s):
  truth atmosphere -> sensors (+faults) -> health monitor -> estimators (variometer, wind, nav)
  -> autonomy (10 Hz) -> autopilot + envelope (every step) -> actuators -> 6-DOF RK4 -> battery.

Data provenance is explicit in every logged frame: keys ending in ``_true`` are simulated ground
truth; ``_est`` are onboard estimates; nothing measured from hardware exists yet.
"""

from __future__ import annotations

import math
import time
from typing import Callable

from .. import MODEL_VERSIONS
from ..aircraft import performance
from ..aircraft.model import G, AircraftModel
from ..atmosphere import isa
from ..atmosphere.environment import Atmosphere
from ..autonomy.soaring import Mode, SoaringAutonomy
from ..control.autopilot import Actuators, Autopilot, GuidanceCommand, NavState
from ..dynamics.linearize import trim_glide
from ..dynamics.six_dof import SimulationDivergence, SixDOF, normalize_and_check, rk4_step_aux
from ..energy.battery import Battery
from ..estimation.estimators import SinkTable, Variometer, WindEstimator
from ..frames import euler_from_quat, quat_from_euler, quat_mul, quat_to_dcm
from ..sensors.models import HealthMonitor, SensorSuite
from .scenarios import ScenarioConfig


def _r(x, n=3):
    return round(float(x), n)


class SimulationRunner:
    def __init__(self, cfg: ScenarioConfig, guidance_override=None):
        self.cfg = cfg
        self.guidance_override = guidance_override  # validation hook: callable(t, nav) -> GuidanceCommand | None
        self.model = AircraftModel(cfg.aircraft)
        self.dyn = SixDOF(self.model)
        self.atm = Atmosphere(cfg.atmosphere, cfg.seed)
        self.sensors = SensorSuite(cfg.sensors, cfg.faults, cfg.seed)
        self.health = HealthMonitor()
        rho_ref = isa.density(cfg.initial.altitude_m)
        self.rho_ref = rho_ref
        self.vario = Variometer(SinkTable(self.model, rho_ref, cfg.polar_error))
        self.windest = WindEstimator(self.model)
        self._drift_prior_t = None
        self.autonomy = SoaringAutonomy(self.model, cfg.autonomy, cfg.atmosphere.forecast, rho_ref)
        self.autopilot = Autopilot(self.model, cfg.autopilot)
        a = cfg.aircraft.actuators
        self.act = Actuators(math.radians(a.max_deflection_deg), a.time_constant_s, math.radians(a.rate_limit_deg_s))
        self.battery = Battery(cfg.aircraft.battery)
        try:
            self.autonomy.mode = Mode(cfg.initial.mode)
        except ValueError:
            self.autonomy.mode = Mode.THERMAL_SEARCH
        if cfg.autonomy.motor_policy == "sustain":
            self.autonomy.mode = Mode.ENERGY_CRUISE
        self.x = self._initial_state()

    def _initial_state(self):
        ic = self.cfg.initial
        tr = trim_glide(self.model, ic.airspeed_ms, ic.altitude_m)
        x = list(tr["state"])
        q_yaw = quat_from_euler(0.0, 0.0, math.radians(ic.heading_deg))
        q = quat_mul(q_yaw, tuple(x[6:10]))
        x[6:10] = list(q)
        x[0], x[1], x[2] = ic.n_m, ic.e_m, -ic.altitude_m
        # start air-relative trimmed: add the wind so the aircraft is in equilibrium with the air mass
        wn, we, wd, _ = self.atm.wind_ned(ic.n_m, ic.e_m, ic.altitude_m, 0.0, include_gust=False)
        r = quat_to_dcm(q)
        x[3] += r[0][0] * wn + r[1][0] * we + r[2][0] * wd
        x[4] += r[0][1] * wn + r[1][1] * we + r[2][1] * wd
        x[5] += r[0][2] * wn + r[1][2] * we + r[2][2] * wd
        self.autopilot.theta_trim = tr["theta"]
        return x

    # -------------------------------------------------------------------------------------------
    def run(self, progress: Callable[[float], None] | None = None, frame_cb: Callable[[dict], None] | None = None) -> dict:
        cfg = self.cfg
        dt = cfg.dt_s
        n_steps = int(round(cfg.duration_s / dt))
        log_every = max(1, int(round(1.0 / (cfg.log_rate_hz * dt))))
        auto_every = max(1, int(round(0.1 / dt)))
        x = self.x
        m = self.model
        mass = m.mass.mass
        aux: dict = {"va": cfg.initial.airspeed_ms, "f_spec": (0.0, 0.0, -G), "p_elec": 0.0, "thrust": 0.0, "alpha": 0.0, "beta": 0.0}
        gc = GuidanceCommand(airspeed=cfg.initial.airspeed_ms)
        frames: list[dict] = []
        thermal_truth: list[dict] = []
        t = 0.0
        end_reason = "time_limit"
        e_atm_true = 0.0
        e_atm_est = 0.0
        motor_time = 0.0
        mode_time: dict[str, float] = {}
        alt_gain_circling = 0.0
        dist = 0.0
        h_max = -x[2]
        prev_h = -x[2]
        nav_n, nav_e = x[0], x[1]
        last_vn, last_ve = 0.0, 0.0
        sq_netto = 0.0
        n_netto = 0
        sq_wind = 0.0
        n_wind = 0
        opt_cache: dict = {}
        wall0 = time.time()
        meas = None
        for k in range(n_steps):
            h = -x[2]
            agl = h - self.atm.terrain_height(x[0], x[1])
            if agl <= 0.0 and k > 0:
                end_reason = "landed"
                self.autonomy._set_mode(t, Mode.LANDED, f"touch-down at {math.hypot(x[0], x[1]):.0f} m from home")
                break
            # ---- truth atmosphere
            up_det = self.atm.updraft(x[0], x[1], h, t)
            self.atm.step_turbulence(dt, aux["va"], up_det)
            wn, we, wd, _ = self.atm.wind_ned(x[0], x[1], h, t)
            rho = self.atm.density(h)
            # ---- sensors + health
            meas = self.sensors.measure(t, dt, x, aux)
            health = self.health.update(meas, dt, tuple(self.windest.x) if self.windest.updates > 20 else None)
            # ---- nav + estimators
            if health.gnss_ok and meas.gnss_new:
                nav_n, nav_e = meas.gnss_pos[0], meas.gnss_pos[1]
                last_vn, last_ve = meas.gnss_vel[0], meas.gnss_vel[1]
            elif not health.gnss_ok:
                # dead reckoning on airspeed + heading + last wind estimate
                va_m = meas.airspeed if (health.airspeed_ok and meas.airspeed) else 10.0
                last_vn = va_m * math.cos(meas.yaw) + self.windest.x[0]
                last_ve = va_m * math.sin(meas.yaw) + self.windest.x[1]
                nav_n += last_vn * dt
                nav_e += last_ve * dt
            else:
                nav_n += last_vn * dt
                nav_e += last_ve * dt
            if health.baro_ok and meas.baro_alt is not None:
                alt_m, alt_s = meas.baro_alt, cfg.sensors.baro_sigma_m + 0.1
                self.vario.source = "baro"
            else:
                alt_m, alt_s = meas.gnss_pos[2], cfg.sensors.gnss_alt_sigma_m * 1.5
                self.vario.source = "gnss"
            airspeed_used = meas.airspeed if health.airspeed_ok else None
            if airspeed_used is None:
                # synthetic airspeed from GNSS velocity minus wind estimate (frozen while pitot is bad)
                airspeed_used = math.sqrt((last_vn - self.windest.x[0]) ** 2 + (last_ve - self.windest.x[1]) ** 2) or 10.0
            self.vario.update(dt, alt_m, alt_s, meas.accel, meas.roll, meas.pitch, airspeed_used)
            self.windest.predict(dt, 4.0 if not health.airspeed_ok else 1.0)
            if meas.gnss_new and health.gnss_ok and health.airspeed_ok and meas.airspeed and meas.airspeed > 5:
                self.windest.update(meas.gnss_vel, meas.airspeed, meas.roll, meas.pitch, meas.yaw, self.vario.h)
            h_est = self.vario.h
            nav = NavState(n=nav_n, e=nav_e, h=h_est, hdot=self.vario.hd, vn=last_vn, ve=last_ve, roll=meas.roll, pitch=meas.pitch,
                           yaw=meas.yaw, p=meas.gyro[0], q=meas.gyro[1], r=meas.gyro[2], airspeed=airspeed_used, ay=meas.accel[1],
                           rho=isa.density(h_est))
            # netto uncertainty grows when falling back to degraded sources
            sigma = self.vario.sigma * (1.0 if health.baro_ok else 2.0) * (1.0 if health.airspeed_ok else 1.6)
            agl_est = h_est - self.atm.terrain_height(nav_n, nav_e)
            # ---- autonomy (10 Hz)
            if k % auto_every == 0:
                if self.windest.updates > 20 and (self._drift_prior_t is None or t - self._drift_prior_t >= 1.0):
                    self.autonomy.drift_prior = self.windest.drift_prior(h_est, self.autonomy.cfg.zi_estimate_m)
                    self._drift_prior_t = t
                gc = self.autonomy.update(t, dt * auto_every, nav, self.vario.netto, self.vario.netto_fast, sigma,
                                          (self.windest.x[0], self.windest.x[1]), health, self.battery.soc, agl_est,
                                          self.act.state.throttle > 0.05)
            if self.guidance_override is not None:
                ov = self.guidance_override(t, nav)
                if ov is not None:
                    gc = ov
            # ---- control
            cmd = self.autopilot.step(nav, gc, dt, t)
            if self.autonomy.mode == Mode.LANDED or self.battery.depleted:
                cmd.throttle = 0.0
            ctl = self.act.step(cmd, dt)
            # ---- dynamics
            try:
                x = rk4_step_aux(self.dyn.derivatives, x, dt, ctl, (wn, we, wd), rho, aux)
                x = normalize_and_check(x)
            except SimulationDivergence as exc:
                end_reason = f"diverged: {exc}"
                break
            self.battery.step(aux["p_elec"], dt)
            # ---- metrics
            h_new = -x[2]
            w_up_true = -wd
            e_atm_true += mass * G * w_up_true * dt
            e_atm_est += mass * G * self.vario.netto * dt
            if aux["p_elec"] > 2.0:
                motor_time += dt
            mode_time[self.autonomy.mode.value] = mode_time.get(self.autonomy.mode.value, 0.0) + dt
            if self.autonomy.mode == Mode.THERMAL_CIRCLING and h_new > prev_h:
                alt_gain_circling += h_new - prev_h
            prev_h = h_new
            h_max = max(h_max, h_new)
            r_ = quat_to_dcm(tuple(x[6:10]))
            vn = r_[0][0] * x[3] + r_[0][1] * x[4] + r_[0][2] * x[5]
            ve = r_[1][0] * x[3] + r_[1][1] * x[4] + r_[1][2] * x[5]
            vd = r_[2][0] * x[3] + r_[2][1] * x[4] + r_[2][2] * x[5]
            dist += math.hypot(vn, ve) * dt
            t += dt
            if k % log_every == 0:
                if t > 20 and aux["p_elec"] < 2.0:
                    sq_netto += (self.vario.netto - up_det) ** 2
                    n_netto += 1
                if self.windest.updates > 20:
                    sq_wind += (self.windest.x[0] - wn) ** 2 + (self.windest.x[1] - we) ** 2
                    n_wind += 1
                fr = self._frame(t, x, aux, ctl, gc, meas, health, nav, up_det, w_up_true, (wn, we), vn, ve, vd, sigma, opt_cache, h_new)
                frames.append(fr)
                if frame_cb:
                    frame_cb(fr)
                if int(t / dt) % int(round(10.0 / dt)) < log_every:
                    thermal_truth.append({"t": _r(t, 1), "thermals": [
                        {"id": s["id"], "n": _r(s["n"], 1), "e": _r(s["e"], 1), "strength": _r(s["strength"]), "radius_ref": _r(s["radius_ref"], 1)}
                        for s in self.atm.thermal_states(t, h_new)]})
            if progress and k % 500 == 0:
                progress(k / n_steps)
        if progress:
            progress(1.0)
        summary = self._summary(t, end_reason, x, frames, e_atm_true, e_atm_est, motor_time, mode_time, alt_gain_circling, dist,
                                h_max, sq_netto, n_netto, sq_wind, n_wind, time.time() - wall0)
        return {
            "meta": {"scenario_id": cfg.id, "name": cfg.name, "config_hash": cfg.config_hash(), "seed": cfg.seed,
                     "model_versions": MODEL_VERSIONS, "dt_s": dt, "log_rate_hz": cfg.log_rate_hz,
                     "provenance": {"_true": "simulated ground truth", "_est": "onboard estimate", "measured": "none (no hardware data yet)"}},
            "config": cfg.model_dump(mode="json"),
            "summary": summary,
            "frames": frames,
            "events": [d.as_dict() for d in self.autonomy.log],
            "plans": self.autonomy.plan_log,
            "health_events": self.health.events,
            "envelope_events": self.autopilot.env.log,
            "thermal_map": self.autonomy.map.as_list(t),
            "thermal_truth": thermal_truth,
            "thermals_config": [th.model_dump() for th in cfg.atmosphere.thermals],
            "forecast": [f.model_dump() for f in cfg.atmosphere.forecast],
            "wind_profile_est": self.windest.profile(),
            "drift_prior_est": ({k: (list(v) if isinstance(v, tuple) else v) for k, v in self.autonomy.drift_prior.items()} if getattr(self.autonomy, "drift_prior", None) else None),
            "wind_profile_true": self.atm.profile(max(400.0, h_max + 100), 25.0),
            "aircraft": self.model.summary(),
        }

    def _frame(self, t, x, aux, ctl, gc, meas, health, nav, up_det, w_up_true, wind_ne, vn, ve, vd, sigma, opt_cache, h):
        roll, pitch, yaw = euler_from_quat(tuple(x[6:10]))
        va = aux["va"]
        ap = self.autonomy
        fr = {
            "t": _r(t, 2), "n": _r(x[0], 2), "e": _r(x[1], 2), "h": _r(h, 2),
            "q": [_r(v, 5) for v in x[6:10]], "roll": _r(math.degrees(roll), 2), "pitch": _r(math.degrees(pitch), 2), "yaw": _r(math.degrees(yaw) % 360, 2),
            "va": _r(va), "vg": _r(math.hypot(vn, ve)), "vz": _r(-vd), "alpha": _r(math.degrees(aux["alpha"]), 2), "beta": _r(math.degrees(aux["beta"]), 2),
            "da": _r(math.degrees(ctl.aileron), 2), "de": _r(math.degrees(ctl.elevator), 2), "dr": _r(math.degrees(ctl.rudder), 2), "thr": _r(ctl.throttle),
            "mode": ap.mode.value,
            "netto_est": _r(self.vario.netto), "netto_sigma": _r(sigma), "te_vario_est": _r(self.vario.te),
            "w_air_true": _r(w_up_true), "updraft_true": _r(up_det),
            "wind_est": [_r(self.windest.x[0]), _r(self.windest.x[1])], "wind_sigma": _r(self.windest.sigma), "wind_true": [_r(wind_ne[0]), _r(wind_ne[1])],
            "es_true": _r(G * h + 0.5 * (vn * vn + ve * ve + vd * vd), 2), "es_air_true": _r(G * h + 0.5 * va * va, 2),
            "soc": _r(self.battery.soc, 4), "v_batt": _r(self.battery.voltage), "i_batt": _r(self.battery.current), "p_elec": _r(aux["p_elec"], 2),
            "e_prop_wh": _r(self.battery.propulsion_wh, 4), "e_batt_wh": _r(self.battery.energy_out_wh, 4), "t_batt": _r(self.battery.temp_c, 2),
            "ld": _r(min(99.0, math.hypot(vn, ve) / max(1e-3, vd)) if vd > 0.05 else 99.0, 2),
            "health": health.as_dict(), "vario_src": self.vario.source,
            "env": {"bank_lim": bool(self.autopilot.env.bank_limited), "speed_floor": bool(self.autopilot.env.speed_floor_active),
                    "alpha_lim": bool(getattr(self.autopilot.env, "alpha_limited", False)), "overspeed": bool(self.autopilot.env.overspeed)},
            "cmd": {"phi": _r(math.degrees(self.autopilot.last_cmd.get("phi_c", 0.0)), 1), "v": _r(self.autopilot.last_cmd.get("v_cmd", 0.0), 2)},
        }
        if gc.mode == "orbit":
            fr["plan"] = {"type": "orbit", "n": _r(gc.orbit_center[0], 1), "e": _r(gc.orbit_center[1], 1), "r": _r(gc.orbit_radius, 1), "dir": gc.orbit_dir}
        else:
            tg = ap.target
            if ap.mode == Mode.RETURN_RECOVERY:
                fr["plan"] = {"type": "goto", "n": ap.cfg.home[0], "e": ap.cfg.home[1], "id": "HOME"}
            elif ap.cfg.waypoints and ap.mode in (Mode.MISSION_NAV, Mode.POWERED_CLIMB):
                wp = ap.cfg.waypoints[ap.wp_idx % len(ap.cfg.waypoints)]
                fr["plan"] = {"type": "goto", "n": wp[0], "e": wp[1], "id": f"WP{ap.wp_idx % len(ap.cfg.waypoints) + 1}"}
            elif tg:
                fr["plan"] = {"type": "goto", "n": _r(tg["n"], 1), "e": _r(tg["e"], 1), "id": tg["id"]}
        if ap.ekf is not None:
            s = ap.ekf.snapshot()
            fr["th_est"] = {"id": ap.active.id if ap.active else None, "n": _r(s["n"], 1), "e": _r(s["e"], 1), "w": _r(s["strength"]), "r": _r(s["radius"], 1),
                            "sigma": _r(s["sigma_pos"], 1), "conf": _r(ap.active.confidence if ap.active else 0.0)}
        # energy-optimal reference circle around the TRUE nearest thermal centre (simulated reference)
        best = None
        for th in self.cfg.atmosphere.thermals:
            cn, ce = self.atm.thermal_center(th, t)
            d = math.hypot(x[0] - cn, x[1] - ce)
            if best is None or d < best[0]:
                best = (d, th, cn, ce)
        if best and best[0] < 3 * best[1].radius_m:
            th = best[1]
            key = (th.id, int(h // 25), int(t // 30))
            if key not in opt_cache:
                w_at = th.strength_ms * self.atm.thermal_life_factor(th, t) * self.atm.vertical_profile(h, th.zi_m)
                r_at = self.atm.radius_at(th, h)
                if w_at > 0.3:
                    # Gedeon bell ~ Gaussian with R_g ~ 0.6 R for the core
                    opt_cache[key] = performance.best_circle_in_thermal(self.model, self.rho_ref, w_at, r_at, profile="gedeon")
                else:
                    opt_cache[key] = None
            o = opt_cache[key]
            if o:
                fr["opt"] = {"n": _r(best[2], 1), "e": _r(best[3], 1), "r": _r(o["radius_m"], 1), "climb": _r(o["climb"]), "bank": o["bank_deg"], "id": th.id}
        return fr

    def _summary(self, t, end_reason, x, frames, e_atm_true, e_atm_est, motor_time, mode_time, alt_gain, dist, h_max,
                 sq_netto, n_netto, sq_wind, n_wind, wall):
        tm = self.autonomy.map
        cfgs = self.cfg.atmosphere.thermals
        # thermal estimation accuracy against truth (centre error at confirmation & during circling)
        centre_err = []
        false_det = 0
        matched = set()
        for rec in tm.records:
            best = None
            for th in cfgs:
                cn, ce = self.atm.thermal_center(th, rec.t_last)
                d = math.hypot(rec.n - cn, rec.e - ce)
                if best is None or d < best[0]:
                    best = (d, th)
            if best is None or best[0] > 1.5 * best[1].radius_m:
                false_det += 1
            else:
                matched.add(best[1].id)
                if rec.status in ("confirmed", "exploited"):
                    centre_err.append(best[0])
        circ_frames = [f for f in frames if f["mode"] == "THERMAL_CIRCLING" and "th_est" in f]
        err_track = []
        for f in circ_frames:
            for th in cfgs:
                cn, ce = self.atm.thermal_center(th, f["t"])
                d = math.hypot(f["th_est"]["n"] - cn, f["th_est"]["e"] - ce)
                if d < 1.5 * th.radius_m:
                    err_track.append(d)
                    break
        b = self.battery
        h_end = -x[2]
        return {
            "duration_s": _r(t, 1), "end_reason": end_reason, "final_altitude_m": _r(h_end, 1), "max_altitude_m": _r(h_max, 1),
            "distance_flown_m": _r(dist, 0), "dist_home_end_m": _r(math.hypot(x[0], x[1]), 0),
            "propulsion_energy_wh": _r(b.propulsion_wh, 3), "battery_energy_wh": _r(b.energy_out_wh, 3), "battery_loss_wh": _r(b.energy_loss_wh, 4),
            "soc_end": _r(b.soc, 4), "motor_on_time_s": _r(motor_time, 1), "battery_temp_end_c": _r(b.temp_c, 1),
            "atmospheric_energy_true_wh": _r(e_atm_true / 3600.0, 3), "atmospheric_energy_est_wh": _r(e_atm_est / 3600.0, 3),
            "altitude_gained_circling_m": _r(alt_gain, 1), "mode_time_s": {k: _r(v, 1) for k, v in mode_time.items()},
            "thermals_detected": len(tm.records), "thermals_confirmed": sum(1 for r in tm.records if r.status in ("confirmed", "exploited")),
            "thermals_rejected": sum(1 for r in tm.records if r.status == "rejected"),
            "false_detections": false_det, "true_thermals_found": len(matched), "true_thermals_total": len(cfgs),
            "centre_error_at_end_m": [_r(e, 1) for e in centre_err],
            "centre_error_circling_mean_m": _r(sum(err_track) / len(err_track), 1) if err_track else None,
            "netto_rmse_ms": _r(math.sqrt(sq_netto / n_netto), 3) if n_netto else None,
            "wind_rmse_ms": _r(math.sqrt(sq_wind / n_wind), 3) if n_wind else None,
            "sensor_faults_detected": [e for e in self.health.events if not e["ok"]],
            "envelope_interventions": self.autopilot.env.interventions,
            "geofence_breaches": sum(1 for d in self.autonomy.log if d.kind == "mode" and "geofence:" in d.message),
            "fence_planned_exits": sum(1 for d in self.autonomy.log if d.kind == "mode" and "drifting out of the geofence" in d.message),
            "wall_time_s": _r(wall, 2), "realtime_factor": _r(t / max(wall, 1e-6), 1),
            "provenance": "simulated",
        }


BASELINES = {
    "no_soaring": ("Conventional glide + powered re-climb", {"soaring_enabled": False, "motor_policy": "reclimb"}),
    "powered_sustain": ("Continuous powered flight (altitude hold)", {"soaring_enabled": False, "motor_policy": "sustain"}),
    "glide_only": ("Pure glide (no motor, no soaring)", {"soaring_enabled": False, "motor_policy": "never"}),
}


def run_scenario(cfg: ScenarioConfig, progress=None, frame_cb=None) -> dict:
    if cfg.kind == "dynamic_soaring":
        from ..dynamic_soaring.model import scenario_report
        return scenario_report(cfg)
    n_runs = 1 + len(cfg.compare_baselines)
    done = [0]

    def prog(f):
        if progress:
            progress((done[0] + f) / n_runs)

    result = SimulationRunner(cfg).run(prog, frame_cb)
    comps = [{"variant": "soaring", "label": "Autonomous soaring", "summary": result["summary"], "series": _series(result["frames"])}]
    for b in cfg.compare_baselines:
        if b not in BASELINES:
            continue
        done[0] += 1
        label, patch = BASELINES[b]
        c2 = cfg.model_copy(deep=True)
        for k, v in patch.items():
            setattr(c2.autonomy, k, v)
        c2.compare_baselines = []
        r2 = SimulationRunner(c2).run(prog)
        comps.append({"variant": b, "label": label, "summary": r2["summary"], "series": _series(r2["frames"])})
    result["comparison"] = comps
    return result


def _series(frames: list[dict], every_s: float = 1.0) -> list[dict]:
    out = []
    last = -1e9
    for f in frames:
        if f["t"] - last >= every_s - 1e-6:
            last = f["t"]
            out.append({"t": f["t"], "h": f["h"], "es": f["es_air_true"], "soc": f["soc"], "e_prop_wh": f["e_prop_wh"], "mode": f["mode"]})
    return out
