"""Dynamic-soaring research module (separate from thermal soaring by design).

Model: 3-DOF point mass in a horizontal wind W(h) blowing along +x (Zhao 2004, "Optimal patterns of
glider dynamic soaring", Optim. Control Appl. Meth. 25):

    m dV/dt      = -D - m g sin(gamma) - m Wdot cos(gamma) sin(psi)
    m V dgamma/dt = L cos(mu) - m g cos(gamma) + m Wdot sin(gamma) sin(psi)
    m V cos(gamma) dpsi/dt = L sin(mu) - m Wdot cos(psi)
    dx/dt = V cos(gamma) sin(psi) + W,   dy/dt = V cos(gamma) cos(psi),   dh/dt = V sin(gamma)
    Wdot = (dW/dh) dh/dt

V is airspeed, gamma the air-relative flight-path angle, psi the air-relative heading (from +y),
mu the bank angle; controls are CL and mu. Air-relative specific energy E = g h + V^2/2 changes as

    dE/dt = -D V / m  -  V cos(gamma) sin(psi) Wdot      (drag loss + wind-gradient gain)

Results are THEORETICAL. The point-mass model ignores rotational dynamics, control limits on roll
rate, turbulence, wing-tip clearance in waves, gusts and structural dynamics — idealised energy gains
must not be read as achievable in real atmospheric conditions.
"""

from __future__ import annotations

import math

import numpy as np
from pydantic import BaseModel, Field

from ..aircraft.config import AircraftConfig
from ..aircraft.model import G, AircraftModel
from ..atmosphere import isa


class DSParams(BaseModel):
    profile: str = Field("logistic", description="logistic (shear layer) | log (boundary layer)")
    w_ref_ms: float = Field(8.0, ge=0, le=40, description="wind above the layer (logistic) or at h_ref (log)")
    layer_center_m: float = Field(8.0, description="logistic layer centre height")
    layer_thickness_m: float = Field(2.5, gt=0.2, description="logistic layer scale delta")
    h_ref_m: float = 10.0
    z0_m: float = Field(0.03, gt=0, description="roughness length (log profile)")
    h_min_m: float = Field(2.0, ge=0.5, description="minimum height (wing-tip clearance)")
    n_max: float = Field(4.0, gt=1.2, le=8)
    cl_max: float | None = None
    v_min_ms: float = 8.5
    nodes: int = Field(60, ge=20, le=200)
    cycle: str = Field("loiter", description="loiter (heading +360 deg per cycle) | travel (heading periodic)")
    aircraft: AircraftConfig = AircraftConfig()


def _wind(p: DSParams, h, sym=False):
    if sym:
        import casadi as ca
        exp, log = ca.exp, ca.log
    else:
        exp, log = np.exp, np.log
    if p.profile == "logistic":
        z = (h - p.layer_center_m) / p.layer_thickness_m
        s = 1 / (1 + exp(-z))
        return p.w_ref_ms * s, p.w_ref_ms * s * (1 - s) / p.layer_thickness_m
    hh = h if sym else np.maximum(h, p.z0_m * 1.5)
    k = p.w_ref_ms / math.log(p.h_ref_m / p.z0_m)
    return k * log(hh / p.z0_m), k / hh


def _aero(p: DSParams):
    m = AircraftModel(p.aircraft)
    rho = isa.density(5.0)
    return {
        "mass": m.mass.mass, "S": m.geometry.area, "rho": rho, "cd0": m.cd0, "kp": m.cd_k_profile, "clmd": m.cl_min_drag,
        "ki": m.k_induced, "cl_max": p.cl_max or m.cl_max,
    }


def _rhs(p: DSParams, a: dict, X, U, w_ref_scale=1.0, sym=False):
    if sym:
        import casadi as ca
        sin, cos, vert = ca.sin, ca.cos, ca.vertcat
    else:
        sin, cos = np.sin, np.cos
        vert = lambda *v: np.array(v)  # noqa: E731
    x, y, h, V, gam, psi = (X[i] for i in range(6))
    CL, mu = U[0], U[1]
    W, dWdh = _wind(p, h, sym)
    W = W * w_ref_scale
    dWdh = dWdh * w_ref_scale
    q = 0.5 * a["rho"] * V * V * a["S"]
    L = q * CL
    CD = a["cd0"] + a["kp"] * (CL - a["clmd"]) ** 2 + a["ki"] * CL * CL
    D = q * CD
    m = a["mass"]
    hdot = V * sin(gam)
    Wdot = dWdh * hdot
    Vdot = (-D - m * G * sin(gam) - m * Wdot * cos(gam) * sin(psi)) / m
    gdot = (L * cos(mu) - m * G * cos(gam) + m * Wdot * sin(gam) * sin(psi)) / (m * V)
    pdot = (L * sin(mu) - m * Wdot * cos(psi)) / (m * V * cos(gam))
    return vert(V * cos(gam) * sin(psi) + W, V * cos(gam) * cos(psi), hdot, Vdot, gdot, pdot)


def energy_terms(p: DSParams, a: dict, X: np.ndarray, U: np.ndarray, w_scale=1.0) -> dict:
    """Specific-energy budget along a trajectory: drag loss and wind-gradient gain (W/kg)."""
    h, V, gam, psi = X[2], X[3], X[4], X[5]
    CL = U[0]
    W, dWdh = _wind(p, h)
    dWdh = dWdh * w_scale
    q = 0.5 * a["rho"] * V * V * a["S"]
    CD = a["cd0"] + a["kp"] * (CL - a["clmd"]) ** 2 + a["ki"] * CL * CL
    drag_loss = -q * CD * V / a["mass"]
    gain = -V * np.cos(gam) * np.sin(psi) * dWdh * V * np.sin(gam)
    n = q * CL / (a["mass"] * G)
    return {"drag_power": drag_loss, "shear_power": gain, "load_factor": n, "wind": W * w_scale}


def optimize_cycle(p: DSParams, objective: str = "min_wind", w_ref: float | None = None, t_bounds=(3.0, 20.0)) -> dict:
    """Direct trapezoidal collocation with IPOPT (CasADi).

    objective="min_wind": smallest reference wind for which an energy-neutral periodic cycle exists.
    objective="max_energy": for a fixed wind, maximise the specific-energy gain of one cycle.
    """
    import casadi as ca

    a = _aero(p)
    N = p.nodes
    opti = ca.Opti()
    X = opti.variable(6, N + 1)
    U = opti.variable(2, N + 1)
    T = opti.variable()
    if objective == "min_wind":
        scale = opti.variable()
        opti.subject_to(opti.bounded(0.05, scale, 6.0))
    else:
        scale = (w_ref if w_ref is not None else p.w_ref_ms) / max(p.w_ref_ms, 1e-6)
    dt = T / N
    for k in range(N):
        f0 = _rhs(p, a, X[:, k], U[:, k], scale, sym=True)
        f1 = _rhs(p, a, X[:, k + 1], U[:, k + 1], scale, sym=True)
        opti.subject_to(X[:, k + 1] == X[:, k] + dt / 2 * (f0 + f1))
    h, V, gam, psi = X[2, :], X[3, :], X[4, :], X[5, :]
    CL, mu = U[0, :], U[1, :]
    opti.subject_to(X[0, 0] == 0)
    opti.subject_to(X[1, 0] == 0)
    opti.subject_to(opti.bounded(p.h_min_m, h, 80.0))
    opti.subject_to(opti.bounded(p.v_min_ms, V, 45.0))
    opti.subject_to(opti.bounded(-1.2, gam, 1.2))
    opti.subject_to(opti.bounded(-0.2, CL, a["cl_max"]))
    opti.subject_to(opti.bounded(-1.4, mu, 1.4))
    qv = 0.5 * a["rho"] * V ** 2 * a["S"]
    opti.subject_to(qv * CL / (a["mass"] * G) <= p.n_max)
    opti.subject_to(opti.bounded(t_bounds[0], T, t_bounds[1]))
    opti.subject_to(h[N] == h[0])
    opti.subject_to(gam[N] == gam[0])
    if p.cycle == "loiter":
        opti.subject_to(psi[N] == psi[0] + 2 * math.pi)
    else:
        opti.subject_to(psi[N] == psi[0])
    opti.subject_to(psi[0] == 0)
    if objective == "min_wind":
        opti.subject_to(V[N] == V[0])
        opti.minimize(scale + 1e-4 * ca.sumsqr(U[1, 1:] - U[1, :-1]))
    else:
        opti.subject_to(V[0] == 16.0)
        e0 = G * h[0] + 0.5 * V[0] ** 2
        e1 = G * h[N] + 0.5 * V[N] ** 2
        opti.minimize(-(e1 - e0) + 1e-4 * ca.sumsqr(U[1, 1:] - U[1, :-1]))
    # initial guess: tilted circle through the shear layer
    s = np.linspace(0, 1, N + 1)
    psi0 = 2 * math.pi * s if p.cycle == "loiter" else 0.6 * np.sin(2 * math.pi * s)
    hc = max(p.h_min_m + 4, p.layer_center_m)
    h0 = hc + 5.0 * np.sin(2 * math.pi * s - math.pi / 2) * -1
    opti.set_initial(X[2, :], h0)
    opti.set_initial(X[3, :], 16.0)
    opti.set_initial(X[4, :], 0.3 * np.cos(2 * math.pi * s))
    opti.set_initial(X[5, :], psi0)
    opti.set_initial(U[0, :], 0.6)
    opti.set_initial(U[1, :], 0.6 if p.cycle == "loiter" else 0.0)
    opti.set_initial(T, 7.0)
    if objective == "min_wind":
        opti.set_initial(scale, 1.0)
    opti.solver("ipopt", {"print_time": False}, {"print_level": 0, "max_iter": 800, "tol": 1e-6, "sb": "yes"})
    try:
        sol = opti.solve()
        ok = True
        val = sol.value
    except RuntimeError:
        ok = False
        val = opti.debug.value
    Xs = np.array(val(X))
    Us = np.array(val(U))
    Ts = float(val(T))
    sc = float(val(scale)) if objective == "min_wind" else float(scale)
    t = np.linspace(0, Ts, N + 1)
    terms = energy_terms(p, a, Xs, Us, sc)
    e = G * Xs[2] + 0.5 * Xs[3] ** 2
    traj = [{"t": float(t[k]), "x": float(Xs[0, k]), "y": float(Xs[1, k]), "h": float(Xs[2, k]), "V": float(Xs[3, k]),
             "gamma_deg": math.degrees(Xs[4, k]), "psi_deg": math.degrees(Xs[5, k]), "CL": float(Us[0, k]), "bank_deg": math.degrees(Us[1, k]),
             "n": float(terms["load_factor"][k]), "wind": float(terms["wind"][k]), "E": float(e[k]),
             "drag_power": float(terms["drag_power"][k]), "shear_power": float(terms["shear_power"][k])} for k in range(N + 1)]
    # energy-equivalent comparison: gliding at best L/D for the same time loses g*sink*T
    from ..aircraft import performance
    model = AircraftModel(p.aircraft)
    bg = performance.best_glide(model, a["rho"])
    return {
        "ok": ok, "objective": objective, "w_ref_ms": sc * p.w_ref_ms, "period_s": Ts,
        "energy_gain_j_per_kg": float(e[-1] - e[0]), "max_load_factor": float(np.max(terms["load_factor"])),
        "min_height_m": float(np.min(Xs[2])), "max_height_m": float(np.max(Xs[2])),
        "drag_energy_j_per_kg": float(np.trapezoid(terms["drag_power"], t)), "shear_energy_j_per_kg": float(np.trapezoid(terms["shear_power"], t)),
        "glide_energy_loss_same_time_j_per_kg": -G * bg["sink"] * Ts,
        "trajectory": traj, "provenance": "theoretical (point-mass optimal control; not validated in flight)",
    }


def wind_profile_table(p: DSParams, h_max: float = 30.0) -> list[dict]:
    hs = np.linspace(max(0.2, p.z0_m * 2), h_max, 60)
    w, dw = _wind(p, hs)
    return [{"h": float(h), "W": float(a), "dWdh": float(b)} for h, a, b in zip(hs, w, dw)]


def energy_sweep(p: DSParams, winds=(4.0, 6.0, 8.0, 10.0, 12.0, 14.0)) -> list[dict]:
    out = []
    for w in winds:
        r = optimize_cycle(p, "max_energy", w_ref=w)
        out.append({"w_ref_ms": w, "ok": r["ok"], "energy_gain_j_per_kg": r["energy_gain_j_per_kg"], "period_s": r["period_s"],
                    "max_load_factor": r["max_load_factor"], "net_power_w_per_kg": r["energy_gain_j_per_kg"] / max(r["period_s"], 1e-6),
                    "glide_loss_j_per_kg": r["glide_energy_loss_same_time_j_per_kg"]})
    return out


def scenario_report(cfg) -> dict:
    p = DSParams(aircraft=cfg.aircraft)
    mn = optimize_cycle(p, "min_wind")
    sweep = energy_sweep(p)
    return {
        "meta": {"scenario_id": cfg.id, "name": cfg.name, "kind": "dynamic_soaring", "config_hash": cfg.config_hash(),
                 "provenance": "theoretical"},
        "params": p.model_dump(mode="json"), "min_wind_cycle": mn, "sweep": sweep, "wind_profile": wind_profile_table(p),
        "summary": {"min_wind_ms": mn["w_ref_ms"], "period_s": mn["period_s"], "max_load_factor": mn["max_load_factor"], "solver_ok": mn["ok"],
                    "provenance": "theoretical"},
        "limitations": [
            "Point-mass model: no roll dynamics/rate limits, so bank reversals are instantaneous.",
            "Steady, laminar shear profile; real marine/terrain boundary layers are gusty and non-stationary.",
            "Parabolic drag polar without the high-CL drag rise used in the 6-DOF model.",
            "Not flown by the autonomy stack; no flight-test evidence.",
        ],
    }
