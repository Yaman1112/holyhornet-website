"""HolyHornet SkyTherm — autonomous atmospheric-energy research UAV, engineering core.

Every model carries a version string so simulation results can record exactly which
models produced them (see ``MODEL_VERSIONS``).
"""

import os

# Small dense linear algebra only — multi-threaded BLAS slows concurrent sims badly.
for _var in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ.setdefault(_var, "1")

__version__ = "0.1.4"

MODEL_VERSIONS = {
    "skytherm": __version__,
    "aerodynamics": "aero-1.0 (Helmbold lift slope, parabolic polar + profile term, flat-plate post-stall blend)",
    "six_dof": "6dof-1.0 (flat-earth NED, body FRD, quaternion, RK4)",
    "atmosphere": "atm-1.0 (ISA troposphere, power-law shear + veer, Gauss-Markov turbulence, Gedeon/Allen thermals, ridge lift)",
    "sensors": "sens-1.0 (GNSS 5 Hz, baro, pitot, AHRS, IMU, fault injection)",
    "estimation": "est-1.1 (TE-netto variometer, wind KF + shear-aware layer-mean drift prior, 6-state thermal EKF)",
    "control": "ctl-1.0 (cascaded PID, vector-field orbit/line guidance, envelope protection)",
    "autonomy": "auto-1.4 (deterministic soaring state machine + utility planner; layer-mean drift anchor; plume search; per-circle harmonic re-centring; geofence-aware drift planning)",
    "energy": "bat-1.0 (LiPo OCV(SOC), R(T) sag, lumped thermal)",
    "dynamic_soaring": "ds-1.0 (3-DOF point mass in shear layer, CasADi collocation)",
}
