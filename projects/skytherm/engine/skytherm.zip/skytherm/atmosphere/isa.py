"""International Standard Atmosphere (troposphere, 0-11 km) with optional temperature offset."""

from __future__ import annotations

import math

T0 = 288.15  # K
P0 = 101325.0  # Pa
RHO0 = 1.225  # kg/m^3
LAPSE = 0.0065  # K/m
R_AIR = 287.053
G0 = 9.80665
_EXP = G0 / (R_AIR * LAPSE)


def temperature(h: float, dt_isa: float = 0.0) -> float:
    return T0 - LAPSE * max(-500.0, min(11000.0, h)) + dt_isa


def pressure(h: float) -> float:
    hh = max(-500.0, min(11000.0, h))
    return P0 * (1 - LAPSE * hh / T0) ** _EXP


def density(h: float, dt_isa: float = 0.0) -> float:
    return pressure(h) / (R_AIR * temperature(h, dt_isa))


def pressure_altitude(p: float) -> float:
    """Invert the ISA pressure law (what a barometric altimeter reports)."""
    return T0 / LAPSE * (1 - (p / P0) ** (1 / _EXP))


def speed_of_sound(h: float, dt_isa: float = 0.0) -> float:
    return math.sqrt(1.4 * R_AIR * temperature(h, dt_isa))
