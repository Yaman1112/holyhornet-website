"""Simulated atmosphere: mean wind with shear and veer, turbulence, thermals, ridge lift.

Everything in this module is **simulated ground truth** (provenance = "simulated"). The aircraft
never reads it directly; it only sees it through the sensor models.

Thermal model
-------------
Radial shape: Gedeon (1989) bell with a surrounding sink ring,
``w(r) = W * exp(-(r/R)^2) * (1 - (r/R)^2)`` — zero at r = R, minimum -0.135 W at r = sqrt(2) R.
Vertical profile: Allen (2006, NASA/TM-2006-214382) convective scaling
``f(z) = (z/zi)^(1/3) (1 - 1.1 z/zi)``, normalised to peak 1, zero above 0.91 zi, faded in near the ground.
Radius grows with height as ``(z/zi)^(1/3) (1 - 0.25 z/zi)`` (Allen). Thermals have a life cycle
(smooth rise/decay) and drift with the mean wind at mid mixed-layer height.
"""

from __future__ import annotations

import math
import random

from pydantic import BaseModel, Field

from . import isa

_FMAX = (0.25 / 1.1) ** (1 / 3) * (1 - 1.1 * 0.25 / 1.1)  # peak of s^(1/3)(1-1.1 s) at s = 1/4.4


class ThermalConfig(BaseModel):
    id: str = "T1"
    x_m: float = 0.0  # north position of the thermal base at t = 0
    y_m: float = 0.0  # east
    strength_ms: float = Field(2.5, ge=-2, le=8, description="peak core updraft W")
    radius_m: float = Field(60.0, gt=5, le=400, description="zero-crossing radius R at mid mixed layer")
    zi_m: float = Field(1200.0, gt=100, le=4000, description="convective mixed-layer depth (thermal top)")
    t_start_s: float = -600.0
    lifetime_s: float = 3600.0
    drift_factor: float = Field(1.0, ge=0, le=1.5, description="fraction of mean wind the thermal drifts with")
    rendezvous_t_s: float | None = Field(None, description="if set, (x_m, y_m) is the centre at this time instead of at t=0 "
                                                           "(keeps an encounter geometry fixed when the wind is swept)")


class ForecastHint(BaseModel):
    """A *forecast* thermal opportunity (e.g. from a terrain/heating model) — not a measurement."""

    id: str
    x_m: float
    y_m: float
    probability: float = Field(0.5, ge=0, le=1)
    expected_strength_ms: float = 1.5
    position_sigma_m: float = 120.0


class RidgeConfig(BaseModel):
    enabled: bool = False
    x_m: float = 800.0  # ridge axis passes through this north coordinate ...
    orientation_deg: float = 90.0  # ... running along this bearing
    height_m: float = 120.0
    half_width_m: float = 250.0


class AtmosphereConfig(BaseModel):
    wind_speed_ms: float = Field(3.0, ge=0, le=25, description="mean wind at reference height")
    wind_from_deg: float = Field(270.0, description="meteorological direction the wind blows FROM")
    reference_height_m: float = 10.0
    shear_exponent: float = Field(0.14, ge=0, le=0.6, description="power-law exponent alpha")
    veer_deg_per_100m: float = Field(2.0, ge=-30, le=30)
    max_shear_height_m: float = 600.0
    turbulence_sigma_ms: float = Field(0.3, ge=0, le=4)
    turbulence_length_m: float = Field(150.0, gt=5)
    thermal_turbulence_gain: float = Field(0.25, ge=0, le=2, description="extra sigma per m/s of local updraft")
    environment_sink_ms: float = Field(0.05, ge=0, le=1.5, description="broad sink between thermals")
    temperature_offset_k: float = 0.0
    humidity_pct: float = 55.0
    thermals: list[ThermalConfig] = Field(default_factory=list)
    forecast: list[ForecastHint] = Field(default_factory=list)
    ridge: RidgeConfig = RidgeConfig()


class Atmosphere:
    """Ground-truth atmosphere. ``sample`` returns the wind at a point; ``step_turbulence`` advances
    the Gauss–Markov gust states along the aircraft path (frozen-turbulence approximation)."""

    def __init__(self, cfg: AtmosphereConfig, seed: int = 0):
        self.cfg = cfg
        self.rng = random.Random(seed * 7919 + 17)
        th = math.radians(cfg.wind_from_deg)
        # wind blows TOWARD the opposite direction
        self._dir_n = -math.cos(th)
        self._dir_e = -math.sin(th)
        self.gust = [0.0, 0.0, 0.0]
        mid = 0.5 * (cfg.thermals[0].zi_m if cfg.thermals else 1200.0)
        self._drift_n, self._drift_e = self.mean_wind_ne(mid)

    # ----------------------------------------------------------------- mean wind
    def wind_speed_at(self, h: float) -> float:
        c = self.cfg
        hh = max(0.5, min(h, c.max_shear_height_m))
        return c.wind_speed_ms * (hh / c.reference_height_m) ** c.shear_exponent

    def mean_wind_ne(self, h: float) -> tuple[float, float]:
        c = self.cfg
        spd = self.wind_speed_at(h)
        veer = math.radians(c.veer_deg_per_100m * max(0.0, min(h, c.max_shear_height_m)) / 100.0)
        cv, sv = math.cos(veer), math.sin(veer)
        dn = self._dir_n * cv - self._dir_e * sv
        de = self._dir_n * sv + self._dir_e * cv
        return spd * dn, spd * de

    # ----------------------------------------------------------------- thermals
    def thermal_center(self, th: ThermalConfig, t: float) -> tuple[float, float]:
        k = th.drift_factor
        t_ref = th.rendezvous_t_s or 0.0
        return th.x_m + k * self._drift_n * (t - t_ref), th.y_m + k * self._drift_e * (t - t_ref)

    @staticmethod
    def thermal_life_factor(th: ThermalConfig, t: float) -> float:
        age = t - th.t_start_s
        if age < 0 or age > th.lifetime_s:
            return 0.0
        ramp = 0.15 * th.lifetime_s
        if age < ramp:
            return math.sin(0.5 * math.pi * age / ramp) ** 2
        if age > th.lifetime_s - ramp:
            return math.sin(0.5 * math.pi * (th.lifetime_s - age) / ramp) ** 2
        return 1.0

    @staticmethod
    def vertical_profile(z: float, zi: float) -> float:
        s = z / zi
        if s <= 0 or s >= 1 / 1.1:
            return 0.0
        f = s ** (1 / 3) * (1 - 1.1 * s) / _FMAX
        ground = min(1.0, z / 30.0)  # thermals are not fully formed in the surface layer
        return max(0.0, f) * ground

    @staticmethod
    def radius_at(th: ThermalConfig, z: float) -> float:
        s = max(0.02, min(0.9, z / th.zi_m))
        g = s ** (1 / 3) * (1 - 0.25 * s) / (0.5 ** (1 / 3) * 0.875)
        return th.radius_m * max(0.35, g)

    def thermal_updraft(self, n: float, e: float, h: float, t: float) -> float:
        w = 0.0
        for th in self.cfg.thermals:
            life = self.thermal_life_factor(th, t)
            if life == 0.0:
                continue
            cn, ce = self.thermal_center(th, t)
            r = self.radius_at(th, h)
            dn, de = n - cn, e - ce
            d2 = dn * dn + de * de
            x2 = d2 / (r * r)
            if x2 > 9.0:
                continue
            w += th.strength_ms * life * self.vertical_profile(h, th.zi_m) * math.exp(-x2) * (1 - x2)
        return w

    def ridge_updraft(self, n: float, e: float, h: float) -> float:
        rc = self.cfg.ridge
        if not rc.enabled:
            return 0.0
        ang = math.radians(rc.orientation_deg)
        # signed distance from ridge axis (normal points to the right of the ridge bearing)
        nn, ne_ = -math.sin(ang), math.cos(ang)
        d = (n - rc.x_m) * nn + e * ne_
        # terrain z(d) = H exp(-(d/a)^2); slope dz/dd
        a = rc.half_width_m
        slope = -2 * d / (a * a) * rc.height_m * math.exp(-(d / a) ** 2)
        wn, we = self.mean_wind_ne(h)
        u_normal = wn * nn + we * ne_
        agl = h - self.terrain_height(n, e)
        # potential-flow-like decay with height above terrain
        return u_normal * slope * math.exp(-max(0.0, agl) / (1.5 * a))

    def terrain_height(self, n: float, e: float) -> float:
        rc = self.cfg.ridge
        if not rc.enabled:
            return 0.0
        ang = math.radians(rc.orientation_deg)
        d = (n - rc.x_m) * (-math.sin(ang)) + e * math.cos(ang)
        return rc.height_m * math.exp(-(d / rc.half_width_m) ** 2)

    # ----------------------------------------------------------------- full field
    def step_turbulence(self, dt: float, airspeed: float, local_updraft: float) -> None:
        c = self.cfg
        sigma = c.turbulence_sigma_ms + c.thermal_turbulence_gain * max(0.0, local_updraft)
        if sigma <= 0:
            self.gust = [0.0, 0.0, 0.0]
            return
        a = math.exp(-max(airspeed, 1.0) * dt / c.turbulence_length_m)
        b = math.sqrt(1 - a * a)
        g = self.rng.gauss
        self.gust = [
            a * self.gust[0] + b * sigma * g(0, 1),
            a * self.gust[1] + b * sigma * g(0, 1),
            a * self.gust[2] + b * 0.7 * sigma * g(0, 1),  # vertical gusts weaker near the surface layer
        ]

    def updraft(self, n: float, e: float, h: float, t: float) -> float:
        """Deterministic vertical air velocity (positive up), excluding turbulence."""
        return self.thermal_updraft(n, e, h, t) + self.ridge_updraft(n, e, h) - self.cfg.environment_sink_ms

    def wind_ned(self, n: float, e: float, h: float, t: float, include_gust: bool = True) -> tuple[float, float, float, float]:
        """Return (wn, we, wd, w_up_deterministic). wd is the NED down component (= -w_up)."""
        wn, we = self.mean_wind_ne(h)
        up = self.updraft(n, e, h, t)
        if include_gust:
            return wn + self.gust[0], we + self.gust[1], -(up + self.gust[2]), up
        return wn, we, -up, up

    def density(self, h: float) -> float:
        return isa.density(h, self.cfg.temperature_offset_k)

    # ----------------------------------------------------------------- visualisation helpers
    def thermal_states(self, t: float, h_ref: float = 300.0) -> list[dict]:
        out = []
        for th in self.cfg.thermals:
            cn, ce = self.thermal_center(th, t)
            life = self.thermal_life_factor(th, t)
            levels = []
            for z in range(50, int(th.zi_m * 0.9), 50):
                levels.append({"h": z, "radius": self.radius_at(th, z), "w": th.strength_ms * life * self.vertical_profile(z, th.zi_m)})
            out.append({
                "id": th.id, "n": cn, "e": ce, "strength": th.strength_ms * life, "radius_ref": self.radius_at(th, h_ref),
                "zi": th.zi_m, "drift_n": th.drift_factor * self._drift_n, "drift_e": th.drift_factor * self._drift_e,
                "levels": levels, "provenance": "simulated",
            })
        return out

    def field_grid(self, t: float, n_range=(-800, 800), e_range=(-800, 800), heights=(50, 150, 300, 500), step=100.0) -> list[dict]:
        pts = []
        n0, n1 = n_range
        e0, e1 = e_range
        for h in heights:
            n = n0
            while n <= n1:
                e = e0
                while e <= e1:
                    wn, we, wd, _ = self.wind_ned(n, e, h, t, include_gust=False)
                    pts.append({"n": n, "e": e, "h": h, "wn": wn, "we": we, "wd": wd})
                    e += step
                n += step
        return pts

    def profile(self, h_max: float = 800.0, step: float = 25.0) -> list[dict]:
        out = []
        h = 0.0
        while h <= h_max:
            wn, we = self.mean_wind_ne(h)
            out.append({"h": h, "speed": math.hypot(wn, we), "wn": wn, "we": we,
                        "dir_to_deg": math.degrees(math.atan2(we, wn)) % 360,
                        "rho": self.density(h), "temp_c": isa.temperature(h, self.cfg.temperature_offset_k) - 273.15})
            h += step
        return out
