"""Small rotation/quaternion toolkit (Hamilton, scalar-first, body -> world)."""

from __future__ import annotations

import numpy as np

GRAVITY = 9.81
E3 = np.array([0.0, 0.0, 1.0])


def cross(a, b):
    """3-vector cross product (much faster than np.cross for single vectors)."""
    return np.array([a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]])


def skew(v):
    return np.array([[0.0, -v[2], v[1]], [v[2], 0.0, -v[0]], [-v[1], v[0], 0.0]])


def vee(S):
    A = 0.5 * (S - S.T)
    return np.array([A[2, 1], A[0, 2], A[1, 0]])


def quat_mul(a, b):
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array([
        aw * bw - ax * bx - ay * by - az * bz,
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
    ])


def quat_normalize(q):
    q = q / np.linalg.norm(q)
    return q if q[0] >= 0 else -q


def quat_to_rot(q):
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def rot_to_quat(R):
    tr = np.trace(R)
    if tr > 0:
        s = np.sqrt(tr + 1.0) * 2
        q = [0.25 * s, (R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s]
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        q = [(R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s]
    elif R[1, 1] > R[2, 2]:
        s = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        q = [(R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s]
    else:
        s = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        q = [(R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s]
    return quat_normalize(np.array(q))


def quat_exp(rv):
    """Quaternion of the rotation vector rv (axis * angle)."""
    a = np.linalg.norm(rv)
    if a < 1e-12:
        return quat_normalize(np.array([1.0, *(0.5 * rv)]))
    return np.array([np.cos(a / 2), *(np.sin(a / 2) * rv / a)])


def rot_exp(rv):
    a = np.linalg.norm(rv)
    K = skew(rv)
    if a < 1e-9:
        return np.eye(3) + K
    return np.eye(3) + np.sin(a) / a * K + (1 - np.cos(a)) / a ** 2 * K @ K


def rot_log(R):
    c = np.clip(0.5 * (np.trace(R) - 1.0), -1.0, 1.0)
    a = np.arccos(c)
    if a < 1e-9:
        return vee(R - R.T) * 0.5
    if np.pi - a < 1e-6:
        # axis from the largest diagonal element
        i = int(np.argmax(np.diag(R)))
        v = R[:, i] + np.eye(3)[:, i]
        return np.pi * v / np.linalg.norm(v)
    return a / (2 * np.sin(a)) * vee(R - R.T)


def rot_x(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_y(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def rot_z(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def yaw_of(R):
    return float(np.arctan2(R[1, 0], R[0, 0]))


def wrap_pi(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


def unit(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-12 else v * 0.0


def orthonormal_basis(n):
    """Two unit vectors (u, w) with (u, w, n) right-handed and orthonormal."""
    n = unit(np.asarray(n, float))
    ref = np.array([0.0, 0.0, 1.0]) if abs(n[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    u = unit(np.cross(ref, n))
    w = np.cross(n, u)
    return u, w
