"""Explainable perching-suitability evaluation.

A candidate is scored only if every HARD gate passes; otherwise its score is 0 and the failed gates
are reported. Soft factors (0..1) are combined with a weighted geometric mean so that any weak
factor pulls the score down. Every gate records value, threshold and a sentence of explanation.

Inputs are estimates only: the fused candidate geometry, the material-classifier posterior, the
site/structural database (declared, possibly wrong) and the wind estimate. True holding force is
not knowable before contact; it is re-checked with the EPM flux sensor after engagement.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .geom import unit
from .materials import MATERIALS
from .mechanism import (BOOM_POSES, ClawParams, EPMPadParams, claw_capacity, design_gust, epm_capacity,
                        worst_case_utilisation)


DIAMETER_TOL = 0.015      # m, pre-contact bar-diameter estimation tolerance (64x48 depth model)


@dataclass
class SiteRecord:
    name: str
    position: tuple
    radius: float
    declared_max_load_n: float | None
    declared_coating_mm: float | None = 0.1
    steel_thickness_mm: float | None = 5.0


@dataclass
class Gate:
    name: str
    passed: bool
    value: object
    threshold: object
    why: str
    hard: bool = True


@dataclass
class PerchPlan:
    boom: str
    target: np.ndarray            # attachment point on the surface (world)
    normal: np.ndarray            # outward normal at the target
    R_perch: np.ndarray           # body orientation when perched
    p_perch: np.ndarray           # CoM position when perched (pad touching, uncompressed)
    yaw: float
    standoff: np.ndarray          # CoM position at the start of the final approach
    long_axis: np.ndarray         # magnet axis (EPM) or bar axis (claw) in world


@dataclass
class SuitabilityReport:
    candidate_id: str
    score: float
    suitable: bool
    gates: list
    soft: dict
    predicted_sf: float
    plan: PerchPlan | None
    summary: str = ""
    expected_capacity_n: float = 0.0
    failure_mode: str = ""
    p_ferro: float = 0.0
    extras: dict = field(default_factory=dict)

    def failed(self):
        return [g for g in self.gates if g.hard and not g.passed]


def _perch_pose(boom, n, yaw_hint, bar_axis=None):
    """Body orientation when perched for a given boom setting and surface normal."""
    up = np.array([0.0, 0.0, 1.0])
    if boom == "down":
        z = unit(n)
        x0 = np.array([np.cos(yaw_hint), np.sin(yaw_hint), 0.0])
        if bar_axis is not None:        # claw: body y along the bar
            y = unit(bar_axis - (bar_axis @ z) * z)
            x = np.cross(y, z)
            return np.c_[x, y, z]
        x = unit(x0 - (x0 @ z) * z)
        y = np.cross(z, x)
        return np.c_[x, y, z]
    if boom == "forward":
        x = -unit(n)
        z = unit(up - (up @ x) * x)
        y = np.cross(z, x)
        return np.c_[x, y, z]
    # up: level, pad on top
    x0 = np.array([np.cos(yaw_hint), np.sin(yaw_hint), 0.0])
    return np.c_[x0, np.cross(up, x0), up]


def choose_boom(n, max_incline_deg=25.0):
    ang = float(np.degrees(np.arccos(np.clip(n[2], -1, 1))))
    if ang <= max_incline_deg:
        return "down", ang
    if 78.0 <= ang <= 102.0:
        return "forward", ang
    if ang >= 165.0:
        return "up", ang
    return None, ang


def p_ferromagnetic(probs):
    if not probs:
        return 0.0
    return float(sum(p for m, p in probs.items() if MATERIALS[m]["k_mag"] >= 0.5))


def evaluate(cand, module, mass, wind_mean_est, wind_turb_est, site_db, other_cands, yaw_hint=0.0,
             min_sf=2.0, max_perch_wind=8.0, require_declared_load=True, standoff_dist=1.0,
             feet=None) -> SuitabilityReport:
    gates: list[Gate] = []
    soft: dict[str, float] = {}
    is_epm = isinstance(module, EPMPadParams)
    n = unit(cand.normal)

    # ---------------------------------------------------------------- geometry / configuration
    if is_epm:
        gates.append(Gate("geometry_type", cand.kind == "plane", cand.kind, "plane",
                          "EPM pad needs a flat patch" if cand.kind != "plane" else "flat patch"))
        boom, incl = choose_boom(n)
        gates.append(Gate("orientation", boom is not None, round(incl, 1),
                          "<=25 | 78-102 | >=165 deg",
                          f"surface inclination {incl:.0f} deg -> boom '{boom}'" if boom else
                          f"inclination {incl:.0f} deg is outside every boom configuration"))
        bar_axis = None
    else:
        gates.append(Gate("geometry_type", cand.kind == "cylinder", cand.kind, "cylinder",
                          "claw needs a bar/pipe" if cand.kind != "cylinder" else "bar/pipe"))
        boom = "down"
        bar_axis = cand.u if cand.kind == "cylinder" else None
        tilt = float(np.degrees(np.arcsin(min(1.0, abs(cand.u[2]))))) if cand.kind == "cylinder" else 90.0
        gates.append(Gate("orientation", tilt <= 15.0, round(tilt, 1), "<=15 deg",
                          f"bar axis {tilt:.0f} deg from horizontal"))
        incl = tilt

    # ---------------------------------------------------------------- size / flatness
    su, sw = cand.size
    if is_epm:
        need = 0.30 if boom == "down" else module.footprint
        ok = min(su, sw) >= need
        gates.append(Gate("patch_size", ok, round(min(su, sw), 3), need,
                          f"smallest side {min(su, sw):.2f} m vs {need:.2f} m needed (pad + feet margin)"))
        soft["size_margin"] = float(np.clip(min(su, sw) / (2 * need), 0.2, 1.0))
        gates.append(Gate("flatness", cand.rms <= 0.006, round(cand.rms * 1000, 1), "6 mm RMS",
                          f"plane residual {cand.rms*1000:.1f} mm"))
        soft["flatness"] = float(np.clip(1 - cand.rms / 0.012, 0.2, 1.0))
    else:
        d = 2 * cand.radius
        # pre-contact diameter is uncertain (depth noise ~ bar radius at 1-1.5 m); the claw's closure
        # encoder is the authoritative check at contact, so the gate only rejects clear mismatches
        tol = DIAMETER_TOL
        ok = (module.min_diameter - tol) <= d <= (module.max_diameter + tol)
        gates.append(Gate("diameter", ok, round(d * 1000), f"{module.min_diameter*1000:.0f}-{module.max_diameter*1000:.0f} mm "
                          f"(±{tol*1000:.0f} mm estimate tolerance)", f"estimated bar diameter {d*1000:.0f} mm "
                          f"(verified by claw closure at contact)"))
        gates.append(Gate("bar_length", su >= module.min_bar_length, round(su, 2), module.min_bar_length,
                          f"visible bar length {su:.2f} m"))
        mid = 0.5 * (module.min_diameter + module.max_diameter)
        soft["diameter_margin"] = float(np.clip(1 - abs(d - mid) / mid, 0.2, 1.0))

    gates.append(Gate("observations", cand.n_obs >= 3, cand.n_obs, 3, f"{cand.n_obs} fused detections"))
    soft["detection_confidence"] = float(np.clip(cand.n_obs / 10, 0.2, 1.0))

    # ---------------------------------------------------------------- material
    probs = cand.material_probs or {}
    pf = p_ferromagnetic(probs)
    best_mat = max(probs, key=probs.get) if probs else None
    if is_epm:
        gates.append(Gate("ferromagnetic", pf >= 0.70, round(pf, 2), 0.70,
                          f"P(ferromagnetic) = {pf:.2f} (classifier top class: {best_mat})"))
        soft["material_confidence"] = float(np.clip(pf, 0.2, 1.0))
    else:
        soft["material_confidence"] = float(np.clip(max(probs.values()) if probs else 0.3, 0.2, 1.0))

    # ---------------------------------------------------------------- site database / load rating
    centre = cand.centre() if cand.kind == "plane" else cand.axis_point
    rec = None
    for r in site_db or []:
        if np.linalg.norm(np.array(r.position) - centre) <= r.radius:
            rec = r
            break
    coating = (rec.declared_coating_mm if rec and rec.declared_coating_mm is not None else 0.3)
    if cand.rust_flag:
        coating += 0.4
    steel_t = rec.steel_thickness_mm if rec and rec.steel_thickness_mm is not None else 3.0

    # ---------------------------------------------------------------- perched pose
    plan = None
    sf = 0.0
    mode = ""
    cap_total = 0.0
    if boom is not None and all(g.passed for g in gates if g.name in ("geometry_type", "orientation")):
        if is_epm:
            target = centre
        else:
            target = cand.axis_point + cand.radius * np.array([0.0, 0.0, 1.0])
            n = np.array([0.0, 0.0, 1.0])
        R_p = _perch_pose(boom, n, yaw_hint, bar_axis)
        tip = np.array(BOOM_POSES[boom].tip)
        p_perch = target - R_p @ tip
        standoff = p_perch + standoff_dist * n
        long_axis = R_p @ np.array(BOOM_POSES[boom].long_axis) if is_epm else unit(bar_axis)
        yaw = float(np.arctan2(R_p[1, 0], R_p[0, 0])) if boom != "forward" else float(np.arctan2(-n[1], -n[0]))
        plan = PerchPlan(boom, target, n, R_p, p_perch, yaw, standoff, long_axis)

        # predicted holding with estimated properties at the design gust
        v_design = design_gust(wind_mean_est, wind_turb_est)
        if is_epm:
            mat = best_mat if (best_mat and MATERIALS[best_mat]["k_mag"] >= 0.5) else "mild_steel"
            cap = epm_capacity(module, mat, coating, steel_t, 0.05, 0.0, None)
        else:
            mat = best_mat or "mild_steel"
            # diameter already passed its gate (with estimation tolerance): predict at the clamped value
            d_c = float(np.clip(2 * cand.radius, module.min_diameter, module.max_diameter))
            cap = claw_capacity(module, mat, d_c)
        cap_total = cap.total_normal
        u = worst_case_utilisation(module, cap, mass, R_p, BOOM_POSES[boom], n, long_axis, v_design, feet)
        sf, mode = u.safety_factor, u.mode
        gates.append(Gate("holding_safety_factor", sf >= min_sf, round(sf, 2), min_sf,
                          f"predicted SF {sf:.2f} at design gust {v_design:.1f} m/s (limiting mode: {mode}; "
                          f"assumed coating {coating:.2f} mm)"))
        soft["holding_margin"] = float(np.clip(sf / (2 * min_sf), 0.2, 1.0))

        # structural load rating (declared)
        req = mass * 9.81 * min_sf + 20.0
        if rec is None or rec.declared_max_load_n is None:
            gates.append(Gate("load_rating", not require_declared_load, None, f">= {req:.0f} N",
                              "no structural record for this surface: load-bearing capacity unknown"))
        else:
            gates.append(Gate("load_rating", rec.declared_max_load_n >= req, rec.declared_max_load_n, round(req),
                              f"declared capacity {rec.declared_max_load_n:.0f} N ('{rec.name}')"))

        # rotor / hull clearance at the perched pose against other known surfaces
        a = 0.18 / np.sqrt(2)
        rotors = [p_perch + R_p @ np.array([sx * a, sy * a, 0.03]) for sx in (1, -1) for sy in (1, -1)]
        clear = np.inf
        for oc in other_cands:
            if oc.id == cand.id or oc.kind != "plane":
                continue
            if abs(oc.normal @ n) > np.cos(np.radians(10)) and abs(oc.normal @ (oc.centroid - centre)) < 0.06:
                continue                      # coplanar fragment of the same surface
            for rc in rotors:
                rel = rc - oc.centre()
                du, dw = rel @ oc.u, rel @ oc.w
                if abs(du) <= 0.5 * oc.size[0] + 0.1 and abs(dw) <= 0.5 * oc.size[1] + 0.1:
                    clear = min(clear, abs(rel @ oc.normal))
        gates.append(Gate("rotor_clearance", clear >= 0.089 + 0.06, None if not np.isfinite(clear) else round(clear, 3),
                          0.15, "no other surface near the rotor discs" if not np.isfinite(clear) else
                          f"closest other surface {clear:.2f} m from a rotor centre"))
        # ground clearance below the perched vehicle
        h = p_perch[2]
        gates.append(Gate("ground_clearance", h >= 0.5 or boom == "down", round(float(h), 2), 0.5,
                          f"CoM {h:.2f} m above ground when perched"))
        soft["approach_space"] = 1.0 if standoff[2] > 0.8 else 0.4

    gates.append(Gate("wind", wind_mean_est <= max_perch_wind, round(wind_mean_est, 1), max_perch_wind,
                      f"mean wind estimate {wind_mean_est:.1f} m/s"))

    hard_ok = all(g.passed for g in gates if g.hard)
    weights = {"holding_margin": 2.0, "material_confidence": 1.5, "detection_confidence": 1.0,
               "flatness": 1.0, "size_margin": 0.7, "diameter_margin": 1.0, "approach_space": 0.5}
    if soft:
        ws = np.array([weights.get(k, 1.0) for k in soft])
        vs = np.array(list(soft.values()))
        score = float(np.exp(np.sum(ws * np.log(vs)) / ws.sum()))
    else:
        score = 0.0
    if not hard_ok:
        score = 0.0
    failed = [g for g in gates if g.hard and not g.passed]
    summary = (f"{cand.id}: SUITABLE score {score:.2f}, predicted SF {sf:.2f}" if hard_ok else
               f"{cand.id}: REJECTED — " + "; ".join(g.why for g in failed))
    return SuitabilityReport(cand.id, score, hard_ok, gates, soft, sf, plan if hard_ok else plan, summary,
                             cap_total, mode, pf)
