"""Validation scenarios. Every surface declares material, coating, steel thickness and load rating.

S1  horizontal steel deck            S6  failed attachment (hidden corrosion) and recovery
S2  vertical steel wall              S7  long-duration stationary monitoring (12 h, quasi-static)
S3  inclined steel roof (20 deg)     S8  autonomous detachment with a blocked corridor, then resume
S4  horizontal steel pipe (claw)     S9  propulsion fault found at pre-takeoff -> remain attached
S5  only unsuitable surfaces         S10 release-mechanism fault -> remain attached and report
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .autonomy import Mission, Waypoint
from .suitability import SiteRecord
from .world import AmbientModel, MovingObstacle, Surface, WindModel, World, ground


@dataclass
class Scenario:
    name: str
    title: str
    surfaces: list
    mission: Mission
    module: str = "epm"                 # epm | claw
    wind: dict = field(default_factory=lambda: dict(mean=(2.0, 1.0, 0.0), turbulence_std=0.5))
    obstacles: list = field(default_factory=list)
    ambient: AmbientModel = field(default_factory=AmbientModel)
    site_db: list = field(default_factory=list)
    illumination: float = 1.0
    t_max: float = 400.0
    quasi_static: bool = True
    position_source: str = "rtk"
    faults: dict = field(default_factory=dict)   # e.g. {"motor_health": (t, idx, h)}, {"release_fault": t}
    soc0: float = 1.0
    expect: dict = field(default_factory=dict)   # expected outcome used by tests

    def build_world(self) -> World:
        surfs = [ground()] + [Surface(**s) for s in self.surfaces]
        return World(surfs, [MovingObstacle(**o) for o in self.obstacles], WindModel(**self.wind), self.ambient,
                     self.illumination)


def _steel_deck(center=(8.0, 0.0, 2.0), half=(0.5, 0.5), **kw):
    d = dict(id="deck", kind="plane", material="painted_steel", center=center, normal=(0, 0, 1),
             half_extents=half, thickness=0.02, coating_mm=0.15, steel_thickness_mm=8.0, max_load_n=3000.0,
             label="steel platform deck")
    d.update(kw)
    return d


def s1_horizontal():
    return Scenario(
        "S1", "Perching on a horizontal steel deck",
        [_steel_deck()],
        Mission(home=(0, 0, 0), search=[Waypoint((6.4, 0.0, 3.2), 0.0)], monitor_s=40.0),
        site_db=[SiteRecord("platform deck", (8, 0, 2), 1.0, 3000.0, 0.15, 8.0)],
        expect=dict(perch=True, detach=True, complete=True))


def s2_vertical():
    return Scenario(
        "S2", "Perching on a vertical steel wall (tank shell)",
        [dict(id="tank_wall", kind="plane", material="mild_steel", center=(9.0, 0.0, 2.5), normal=(-1, 0, 0),
              half_extents=(2.0, 2.0), thickness=0.012, coating_mm=0.05, steel_thickness_mm=10.0, max_load_n=5000.0,
              label="storage tank shell (blasted steel)")],
        Mission(home=(0, 0, 0), search=[Waypoint((6.6, 0.0, 2.5), 0.0)], monitor_s=40.0),
        site_db=[SiteRecord("tank T-2 shell", (9, 0, 2.5), 2.5, 5000.0, 0.05, 10.0)],
        expect=dict(perch=True, detach=True, complete=True))


def s3_inclined():
    a = np.radians(20)
    return Scenario(
        "S3", "Perching on a 20 deg inclined steel roof panel",
        [dict(id="roof", kind="plane", material="painted_steel", center=(8.0, 0.0, 2.0),
              normal=(-np.sin(a), 0.0, np.cos(a)), half_extents=(0.6, 0.6), thickness=0.01, coating_mm=0.12,
              steel_thickness_mm=6.0, max_load_n=2000.0, label="inclined steel roof panel")],
        Mission(home=(0, 0, 0), search=[Waypoint((7.0, 0.0, 3.3), 0.0)], monitor_s=40.0),
        site_db=[SiteRecord("roof panel", (8, 0, 2), 1.0, 2000.0, 0.12, 6.0)],
        expect=dict(perch=True, detach=True, complete=True))


def s4_pole():
    return Scenario(
        "S4", "Perching on a horizontal steel pipe with the claw module",
        [dict(id="pipe", kind="cylinder", material="painted_steel", center=(8.0, 0.0, 2.0), axis=(0, 1, 0),
              radius=0.02, length=2.0, coating_mm=0.1, max_load_n=1500.0, label="40 mm handrail pipe")],
        Mission(home=(0, 0, 0), search=[Waypoint((7.5, 0.0, 3.0), 0.0)], monitor_s=40.0),
        module="claw",
        site_db=[SiteRecord("handrail", (8, 0, 2), 1.2, 1500.0, 0.1, 3.0)],
        expect=dict(perch=True, detach=True, complete=True))


def s5_unsuitable():
    return Scenario(
        "S5", "Only unsuitable surfaces: glass, aluminium, austenitic stainless, too-small sign",
        [dict(id="glass_facade", kind="plane", material="glass", center=(9.5, 0.0, 2.5), normal=(-1, 0, 0),
              half_extents=(1.5, 1.5), thickness=0.02, max_load_n=800.0, label="glass facade"),
         dict(id="alu_roof", kind="plane", material="aluminium", center=(7.8, 1.6, 1.8), normal=(0, 0, 1),
              half_extents=(0.5, 0.5), thickness=0.005, max_load_n=600.0, label="aluminium sheet"),
         dict(id="ss304_panel", kind="plane", material="stainless_304", center=(7.8, -1.6, 1.8), normal=(0, 0, 1),
              half_extents=(0.5, 0.5), thickness=0.005, steel_thickness_mm=3.0, max_load_n=600.0,
              label="austenitic stainless cover (looks like steel, non-magnetic)"),
         dict(id="small_sign", kind="plane", material="mild_steel", center=(7.5, 0.0, 1.5), normal=(0, 0, 1),
              half_extents=(0.09, 0.09), thickness=0.003, steel_thickness_mm=2.0, max_load_n=200.0,
              label="small steel sign")],
        Mission(home=(0, 0, 0), search=[Waypoint((6.3, 0.0, 3.0), 0.0)], monitor_s=20.0),
        site_db=[SiteRecord("facade", (9.5, 0, 2.5), 2.0, 800.0, 0.0, 0.0),
                 SiteRecord("alu roof", (7.8, 1.6, 1.8), 0.8, 600.0, 0.0, 0.0),
                 SiteRecord("ss cover", (7.8, -1.6, 1.8), 0.8, 600.0, 0.0, 3.0),
                 SiteRecord("sign", (7.5, 0, 1.5), 0.3, 200.0, 0.0, 2.0)],
        expect=dict(perch=False, complete=True))


def s6_failed_attachment():
    return Scenario(
        "S6", "Failed attachment (hidden corrosion under paint) and recovery to a second wall panel",
        [dict(id="panel_A", kind="plane", material="painted_steel", center=(9.0, -1.4, 2.5), normal=(-1, 0, 0),
              half_extents=(0.9, 0.9), thickness=0.01, coating_mm=0.9, declared_coating_mm=0.05, coating_visible=False,
              steel_thickness_mm=8.0, max_load_n=4000.0, label="panel A: survey says 0.05 mm (blasted), truly 0.9 mm paint over rust"),
         dict(id="panel_B", kind="plane", material="painted_steel", center=(9.0, 1.3, 2.5), normal=(-1, 0, 0),
              half_extents=(0.7, 0.7), thickness=0.01, coating_mm=0.08, declared_coating_mm=0.08,
              steel_thickness_mm=8.0, max_load_n=4000.0, label="panel B: thin fresh primer")],
        Mission(home=(0, 0, 0), search=[Waypoint((6.4, 0.0, 2.5), 0.0)], monitor_s=30.0),
        site_db=[SiteRecord("panel A", (9, -1.4, 2.5), 1.2, 4000.0, 0.05, 8.0),
                 SiteRecord("panel B", (9, 1.3, 2.5), 1.0, 4000.0, 0.08, 8.0)],
        wind=dict(mean=(1.5, 0.5, 0.0), turbulence_std=0.4),
        expect=dict(perch=True, aborts_min=1, complete=True))


def s7_long_duration(hours=12.0):
    amb = AmbientModel(acoustic_events=[(2 * 3600, 120, 88.0), (9 * 3600, 60, 92.0)],
                       vibration_events=[(4 * 3600, 300, 1.2)], hotspots=[(7 * 3600, 7.5 * 3600, 95.0)],
                       gas_events=[(10 * 3600, 900, 2000.0)])
    sc = Scenario(
        "S7", f"Long-duration stationary monitoring ({hours:.0f} h) on a horizontal deck",
        [_steel_deck()],
        Mission(home=(0, 0, 0), search=[Waypoint((6.4, 0.0, 3.2), 0.0)], monitor_s=hours * 3600),
        site_db=[SiteRecord("platform deck", (8, 0, 2), 1.0, 3000.0, 0.15, 8.0)],
        wind=dict(mean=(3.0, 1.0, 0.0), turbulence_std=0.8, gust_events=[(5 * 3600, 30, (9.0, 3.0, 0.0))]),
        ambient=amb, t_max=hours * 3600 + 600,
        faults={"sensor": [("humidity", "stuck", 3 * 3600), ("gas", "dropout", 6 * 3600)]},
        expect=dict(perch=True, detach=True, complete=True))
    return sc


def s8_detach_resume():
    sc = s2_vertical()
    sc.name, sc.title = "S8", "Autonomous detachment with a moving obstacle in the departure corridor, then resume"
    sc.mission = Mission(home=(0, 0, 0), search=[Waypoint((6.6, 0.0, 2.5), 0.0)], monitor_s=30.0,
                         resume=[Waypoint((5.0, 4.0, 3.0), 0.0)])
    # a drone-sized obstacle crosses in front of the wall while the vehicle wants to leave
    # (activated by the harness 4 s before the planned departure, for 20 s)
    sc.obstacles = [dict(id="crossing_uav", a=(7.0, -3.0, 2.6), b=(7.0, 3.0, 2.6), radius=0.35, period=30.0,
                         t_start=1e9, t_end=1e9)]
    sc.faults = {"obstacle_window": True}
    sc.expect = dict(perch=True, detach=True, complete=True)
    return sc


def s9_propulsion_fault():
    sc = s1_horizontal()
    sc.name, sc.title = "S9", "Motor degradation found by the pre-takeoff check -> remain attached"
    sc.faults = {"motor_health_on_perch": (2, 0.75)}
    sc.mission.monitor_s = 20.0
    sc.t_max = 220.0
    sc.expect = dict(perch=True, detach=False, remain_attached=True)
    return sc


def s10_release_fault():
    sc = s2_vertical()
    sc.name, sc.title = "S10", "Release mechanism fault -> stays attached, re-verifies, reports"
    sc.faults = {"release_fault_on_perch": True}
    sc.mission.monitor_s = 20.0
    sc.t_max = 220.0
    sc.expect = dict(perch=True, detach=False, remain_attached=True)
    return sc


ALL = {"S1": s1_horizontal, "S2": s2_vertical, "S3": s3_inclined, "S4": s4_pole, "S5": s5_unsuitable,
       "S6": s6_failed_attachment, "S7": s7_long_duration, "S8": s8_detach_resume, "S9": s9_propulsion_fault,
       "S10": s10_release_fault}
