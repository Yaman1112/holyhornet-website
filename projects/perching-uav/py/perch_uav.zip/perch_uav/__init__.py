"""perch_uav — Perching UAV Intelligence: autonomous perching, attachment and sensor mode.

Frames (used everywhere in this package):
* World W: ENU, z up, gravity (0, 0, -9.81) m/s^2.
* Body B: FLU (x forward, y left, z up), origin at the centre of mass.
* Quaternions: Hamilton, scalar first [w, x, y, z], rotate body -> world.

Separation of truth and estimate:
* `world`, `dynamics` and the ground-truth parts of `sensors` own the true state.
* The autonomy stack (`estimation`, `perception`, `control`, `state_machine`, `decision`,
  `sensor_mode`) only receives sensor messages. `tests/perch/test_separation.py` checks that
  the autonomy modules never import the ground-truth modules.

Nothing in this package connects to flight hardware.
"""

__version__ = "0.1.0"
