"""Stationary sensor mode: schedules, health monitoring, local storage, scheduled transmission.

The station is driven by a `read(name, t)` callable (the sensor models), so it has no access to
truth. Energy modes change sampling periods and which sensors run.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

import numpy as np

DEFAULT_SCHEDULE = {
    # name: (period_s normal, period_s eco, active in critical, bytes/sample, power W while sampling, sample s)
    "temperature": (10, 60, True, 8, 0.01, 0.1),
    "humidity": (10, 60, True, 8, 0.01, 0.1),
    "acoustic": (5, 30, False, 16, 0.15, 1.0),
    "vibration": (5, 30, True, 16, 0.05, 1.0),
    "thermal": (60, 300, False, 2048, 1.0, 1.0),
    "visual": (120, 900, False, 60_000, 2.0, 1.0),
    "gas": (30, 300, False, 8, 0.30, 2.0),
}

PLAUSIBLE = {"temperature": (-40, 85), "humidity": (0, 100), "acoustic": (30, 130), "vibration": (0, 50),
             "thermal": (-20, 400), "visual": (0, 1), "gas": (300, 5000)}


@dataclass
class StationConfig:
    schedule: dict = field(default_factory=lambda: dict(DEFAULT_SCHEDULE))
    storage_bytes: int = 32 * 1024 * 1024
    tx_period_s: float = 900.0
    tx_rate_bps: float = 50_000.0
    tx_power_w: float = 1.2
    base_power_w: float = 1.0          # MCU + radio idle + EPM/attachment monitoring (EPM holds at 0 W)
    acoustic_event_dba: float = 75.0
    vibration_event_ms2: float = 0.5
    thermal_event_c: float = 60.0
    gas_event_ppm: float = 1500.0


class SensorHealth:
    def __init__(self, window=12):
        self.hist: dict[str, deque] = {}
        self.status: dict[str, str] = {}
        self.window = window
        self.missing: dict[str, int] = {}

    def check(self, name, v):
        if v is None:
            self.missing[name] = self.missing.get(name, 0) + 1
            self.status[name] = "dropout" if self.missing[name] >= 3 else self.status.get(name, "ok")
            return self.status[name]
        self.missing[name] = 0
        lo, hi = PLAUSIBLE[name]
        if not (lo <= v <= hi):
            self.status[name] = "out_of_range"
            return self.status[name]
        h = self.hist.setdefault(name, deque(maxlen=self.window))
        h.append(v)
        if name in ("temperature", "humidity", "acoustic", "gas") and len(h) == self.window and np.ptp(h) < 1e-9:
            self.status[name] = "stuck"
        else:
            self.status[name] = "ok"
        return self.status[name]


class SensorStation:
    def __init__(self, read, cfg: StationConfig | None = None):
        self.read = read
        self.cfg = cfg or StationConfig()
        self.mode = "normal"
        self.next_due = {k: 0.0 for k in self.cfg.schedule}
        self.storage: deque = deque()
        self.stored_bytes = 0
        self.sent_bytes = 0
        self.dropped_records = 0
        self.records = 0
        self.health = SensorHealth()
        self.events: list[tuple[float, str, float]] = []
        self.energy_j = 0.0
        self.next_tx = self.cfg.tx_period_s
        self.tx_log: list[tuple[float, int]] = []
        self.event_until = -1.0
        self.series: dict[str, list] = {k: [] for k in self.cfg.schedule}

    def set_mode(self, mode):
        self.mode = mode

    def _period(self, name):
        p_norm, p_eco, crit, *_ = self.cfg.schedule[name]
        if self.mode == "critical":
            return p_eco * 4 if crit else None
        if self.mode == "eco":
            return p_eco
        return p_norm

    def tick(self, t, dt) -> float:
        """Advance the station to time t. Returns average payload power [W] over the step."""
        e = self.cfg.base_power_w * dt
        event = t <= self.event_until
        for name, (pn, pe, crit, nbytes, pw, ts) in self.cfg.schedule.items():
            period = self._period(name)
            if period is None:
                continue
            if event and name in ("visual", "thermal", "acoustic"):
                period = min(period, 10.0)
            while self.next_due[name] <= t:
                v = self.read(name, self.next_due[name])
                st = self.health.check(name, v)
                e += pw * ts
                if v is not None:
                    self._store(t, name, v, nbytes, st)
                    self._detect(t, name, v)
                self.next_due[name] += period
        if t >= self.next_tx:
            e += self._transmit(t)
            self.next_tx += self.cfg.tx_period_s if self.mode != "critical" else 4 * self.cfg.tx_period_s
        self.energy_j += e
        return e / dt if dt > 0 else 0.0

    def _store(self, t, name, v, nbytes, status):
        rec = (t, name, v, status, nbytes)
        while self.stored_bytes + nbytes > self.cfg.storage_bytes and self.storage:
            old = self.storage.popleft()
            self.stored_bytes -= old[4]
            self.dropped_records += 1
        self.storage.append(rec)
        self.stored_bytes += nbytes
        self.records += 1
        if len(self.series[name]) < 50_000:
            self.series[name].append((t, v, status))

    def _detect(self, t, name, v):
        c = self.cfg
        trig = ((name == "acoustic" and v > c.acoustic_event_dba) or (name == "vibration" and v > c.vibration_event_ms2)
                or (name == "thermal" and v > c.thermal_event_c) or (name == "gas" and v > c.gas_event_ppm))
        if trig and self.health.status.get(name) == "ok":
            if not self.events or t - self.events[-1][0] > 30 or self.events[-1][1] != name:
                self.events.append((t, name, v))
            self.event_until = t + 60.0

    def _transmit(self, t):
        budget = int(self.cfg.tx_rate_bps / 8 * 60)        # 60 s transmit window
        sent = 0
        while self.storage and sent + self.storage[0][4] <= budget:
            r = self.storage.popleft()
            self.stored_bytes -= r[4]
            sent += r[4]
        self.sent_bytes += sent
        self.tx_log.append((t, sent))
        return self.cfg.tx_power_w * (sent / (self.cfg.tx_rate_bps / 8) + 2.0)

    def summary(self):
        return dict(mode=self.mode, records=self.records, stored_bytes=self.stored_bytes, sent_bytes=self.sent_bytes,
                    dropped_records=self.dropped_records, events=len(self.events), energy_j=round(self.energy_j, 1),
                    health=dict(self.health.status), transmissions=len(self.tx_log))
