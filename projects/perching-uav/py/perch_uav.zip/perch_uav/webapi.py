"""Server-free entry points (used by the browser build under Pyodide and by perch_service).

    catalog()                 -> list of scenario descriptions (JSON-safe)
    build_scenario(req: dict) -> Scenario with the request's overrides applied (values clamped)
    run(req: dict, post)      -> runs a simulation, calling post(json_string) for every message

Inputs come from untrusted users (web form), so every number is clamped to a safe range and
identifiers are checked against the catalogue.
"""

from __future__ import annotations

import json
import math

import numpy as np

from . import scenarios as S
from .materials import MATERIAL_NAMES
from .simulation import Simulation
from .streaming import world_message

LIMITS = dict(wind_speed=(0.0, 20.0), turbulence=(0.0, 4.0), illumination=(0.0, 1.0), monitor_s=(5.0, 86_400.0),
              coating_mm=(0.0, 5.0), declared_coating_mm=(0.0, 5.0), steel_thickness_mm=(0.0, 50.0),
              max_load_n=(0.0, 1e5), t_max=(10.0, 100_000.0), seed=(0, 1_000_000))
SENSORS = {"temperature", "humidity", "acoustic", "gas", "thermal", "vibration"}


def finite(x):
    """JSON-safe copy: numpy scalars -> Python, non-finite floats -> None."""
    if isinstance(x, dict):
        return {str(k): finite(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [finite(v) for v in x]
    if isinstance(x, np.ndarray):
        return finite(x.tolist())
    if isinstance(x, (bool, np.bool_)):
        return bool(x)
    if isinstance(x, (int, np.integer)):
        return int(x)
    if isinstance(x, (float, np.floating)):
        f = float(x)
        return f if math.isfinite(f) else None
    return x


def _clamp(name, v):
    lo, hi = LIMITS[name]
    v = float(v)
    if not math.isfinite(v):
        raise ValueError(f"{name} must be a finite number")
    return min(max(v, lo), hi)


def catalog():
    out = []
    for k, f in S.ALL.items():
        sc = f()
        out.append(dict(id=k, title=sc.title, module=sc.module, monitor_s=sc.mission.monitor_s,
                        wind=finite(sc.wind), illumination=sc.illumination, faults=finite(sc.faults),
                        surfaces=finite([{kk: v for kk, v in s.items() if kk in (
                            "id", "kind", "material", "label", "coating_mm", "declared_coating_mm",
                            "steel_thickness_mm", "max_load_n", "coating_visible")} for s in sc.surfaces])))
    return out


def build_scenario(req: dict):
    sid = req.get("scenario", "S1")
    if sid not in S.ALL:
        raise ValueError(f"unknown scenario '{sid}'")
    sc = S.ALL[sid]()
    ws, tu = req.get("wind_speed"), req.get("turbulence")
    if ws is not None or tu is not None:
        w = dict(sc.wind)
        if ws is not None:
            a = math.radians(float(req.get("wind_dir_deg", 0.0)) % 360.0)
            spd = _clamp("wind_speed", ws)
            w["mean"] = (spd * math.cos(a), spd * math.sin(a), 0.0)
        if tu is not None:
            w["turbulence_std"] = _clamp("turbulence", tu)
        sc.wind = w
    if req.get("illumination") is not None:
        sc.illumination = _clamp("illumination", req["illumination"])
    if req.get("position_source") in ("rtk", "gnss", "vio"):
        sc.position_source = req["position_source"]
    if req.get("module") in ("epm", "claw"):
        sc.module = req["module"]
    if req.get("monitor_s") is not None:
        sc.mission.monitor_s = _clamp("monitor_s", req["monitor_s"])
        sc.t_max = max(sc.t_max, sc.mission.monitor_s + 400.0)
    if req.get("t_max") is not None:
        sc.t_max = _clamp("t_max", req["t_max"])
    ids = {s["id"] for s in sc.surfaces}
    for ov in (req.get("surface_overrides") or [])[:20]:
        if ov.get("id") not in ids:
            raise ValueError(f"unknown surface '{ov.get('id')}' in {sid} (has {sorted(ids)})")
        surf = next(s for s in sc.surfaces if s["id"] == ov["id"])
        if ov.get("material") is not None:
            if ov["material"] not in MATERIAL_NAMES:
                raise ValueError(f"unknown material '{ov['material']}'")
            surf["material"] = ov["material"]
        for k in ("coating_mm", "steel_thickness_mm", "max_load_n"):
            if ov.get(k) is not None:
                surf[k] = _clamp(k, ov[k])
        if ov.get("coating_visible") is not None:
            surf["coating_visible"] = bool(ov["coating_visible"])
        dec = ov.get("declared_coating_mm")
        for rec in sc.site_db:
            if np.linalg.norm(np.array(rec.position) - np.array(surf["center"])) <= rec.radius:
                if dec is not None:
                    rec.declared_coating_mm = _clamp("declared_coating_mm", dec)
                if ov.get("steel_thickness_mm") is not None:
                    rec.steel_thickness_mm = _clamp("steel_thickness_mm", ov["steel_thickness_mm"])
        if dec is not None:
            surf["declared_coating_mm"] = _clamp("declared_coating_mm", dec)
    f = dict(sc.faults)
    faults = req.get("faults") or {}
    if faults.get("motor_degraded"):
        f["motor_health_on_perch"] = (2, 0.75)
    if faults.get("release_jam"):
        f["release_fault_on_perch"] = True
    stuck = [n for n in (faults.get("sensor_stuck") or []) if n in SENSORS]
    if stuck:
        f["sensor"] = list(f.get("sensor", [])) + [(n, "stuck", 30.0) for n in stuck]
    sc.faults = f
    sc.expect = {}
    return sc


def run(req: dict, post, realtime=None):
    """Run one simulation, streaming JSON strings through post(). Returns the result dict."""
    sc = build_scenario(req)
    seed = int(_clamp("seed", req.get("seed", 0)))
    sim = Simulation(sc, seed=seed)
    sim.realtime = realtime
    send = lambda m: post(json.dumps(finite(m), allow_nan=False))  # noqa: E731
    sim.sink = send
    send(world_message(sim))
    res = sim.run()
    res.pop("reports", None)
    res = finite(res)
    send(dict(type="result", result=res))
    send(dict(type="end", status="done"))
    return res
