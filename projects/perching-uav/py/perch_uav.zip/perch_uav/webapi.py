"""Server-free entry points (used by the browser build under Pyodide and by perch_service).

    catalog()                 -> list of scenario descriptions (JSON-safe)
    build_scenario(req: dict) -> Scenario with the request's overrides applied (values clamped)
    Session(req, post)        -> a run driven in chunks: advance(until_t), stop(), perf()
    run(req: dict, post)      -> runs a simulation to the end, calling post(json_string) per message
    manifest(req)             -> traceability record (deterministic run_id)

Inputs come from untrusted users (web form), so every number is clamped to a safe range and
identifiers are checked against the catalogue.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import math
import platform
import sys

import numpy as np

from . import __version__
from . import scenarios as S
from dataclasses import replace

from .config import Rates, SimConfig
from .propulsion import PropulsionParams
from .materials import MATERIAL_NAMES
from .simulation import Simulation
from .streaming import world_message

LIMITS = dict(wind_speed=(0.0, 20.0), turbulence=(0.0, 4.0), illumination=(0.0, 1.0), monitor_s=(5.0, 86_400.0),
              coating_mm=(0.0, 5.0), declared_coating_mm=(0.0, 5.0), steel_thickness_mm=(0.0, 50.0),
              max_load_n=(0.0, 1e5), t_max=(10.0, 100_000.0), seed=(0, 1_000_000))
SENSORS = {"temperature", "humidity", "acoustic", "gas", "thermal", "vibration"}


def finite(x):
    """JSON-safe copy: numpy scalars -> Python, non-finite floats -> None."""
    if isinstance(x, dict):
        return {str(k): finite(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [finite(v) for v in x]
    if isinstance(x, np.ndarray):
        return finite(x.tolist())
    if isinstance(x, (bool, np.bool_)):
        return bool(x)
    if isinstance(x, (int, np.integer)):
        return int(x)
    if isinstance(x, (float, np.floating)):
        f = float(x)
        return f if math.isfinite(f) else None
    return x


def _clamp(name, v):
    lo, hi = LIMITS[name]
    v = float(v)
    if not math.isfinite(v):
        raise ValueError(f"{name} must be a finite number")
    return min(max(v, lo), hi)


# --------------------------------------------------------------------------- engineering parameters
# One registry for every tunable quantity: the configuration workspace, the research lab, the
# FastAPI service and the tests all read it. Requests carry {"params": {name: value}}; values are
# validated against [min, max] (out-of-range values are REJECTED, not clamped, so a study never
# silently runs a different configuration than the one requested).
PARAMS = {
    "vehicle.mass_kg":            dict(label="Vehicle mass (total)", unit="kg", default=None, min=0.9, max=2.6,
                                       note="default = 1.33 kg airframe + module mass"),
    "battery.capacity_ah":        dict(label="Battery capacity", unit="Ah", default=5.0, min=1.5, max=12.0),
    "battery.internal_resistance": dict(label="Battery internal resistance (25 degC)", unit="ohm", default=0.035,
                                        min=0.005, max=0.2),
    "propulsion.kv":              dict(label="Motor KV", unit="rpm/V", default=1100.0, min=600.0, max=2200.0),
    "propulsion.prop_scale":      dict(label="Propeller coefficient scale (kT and kQ)", unit="-", default=1.0,
                                       min=0.6, max=1.6),
    "propulsion.tau":             dict(label="Rotor speed time constant", unit="s", default=0.035, min=0.01, max=0.12),
    "mechanism.epm_force_n":      dict(label="EPM holding force per magnet (clean thick steel)", unit="N",
                                       default=150.0, min=20.0, max=400.0),
    "mechanism.claw_pull_off_n":  dict(label="Claw pull-off capacity", unit="N", default=70.0, min=10.0, max=200.0),
    "mechanism.claw_grip_n":      dict(label="Claw grip normal force", unit="N", default=120.0, min=20.0, max=300.0),
    "surface.mu_scale":           dict(label="Surface friction scale (all structures)", unit="-", default=1.0,
                                       min=0.2, max=2.5),
    "surface.coating_mm":         dict(label="Coating / gap on all structures (true)", unit="mm", default=None,
                                       min=0.0, max=3.0, note="default = per-scenario values"),
    "approach.v_contact":         dict(label="Contact speed of the approach profile", unit="m/s", default=0.22,
                                       min=0.02, max=1.0),
    "approach.v_cruise":          dict(label="Final-approach cruise speed", unit="m/s", default=0.45, min=0.1, max=1.5),
    "approach.angle_deg":         dict(label="Approach angle from the surface normal", unit="deg", default=0.0,
                                       min=0.0, max=60.0),
    "gains.attitude_scale":       dict(label="Attitude controller gain scale", unit="-", default=1.0, min=0.3, max=3.0),
    "gains.position_scale":       dict(label="Position (PID) gain scale", unit="-", default=1.0, min=0.3, max=3.0),
    "gains.mpc_q_pos":            dict(label="MPC position weight", unit="-", default=30.0, min=1.0, max=300.0),
    "env.wind_speed":             dict(label="Mean wind speed", unit="m/s", default=None, min=0.0, max=20.0,
                                       note="default = scenario wind"),
    "env.turbulence":             dict(label="Turbulence sigma", unit="m/s", default=None, min=0.0, max=4.0),
}


def params_of(req: dict) -> dict:
    """Validated {name: float} from a request ('params' plus the legacy top-level wind fields)."""
    raw = dict(req.get("params") or {})
    out = {}
    for k, v in raw.items():
        if k not in PARAMS:
            raise ValueError(f"unknown parameter '{k}'")
        if v is None:
            continue
        v = float(v)
        spec = PARAMS[k]
        if not math.isfinite(v) or v < spec["min"] or v > spec["max"]:
            raise ValueError(f"{k} = {v} is outside [{spec['min']}, {spec['max']}] {spec['unit']}")
        out[k] = v
    return out


def parameter_catalog() -> dict:
    return finite({k: dict(v, name=k) for k, v in PARAMS.items()})



def catalog():
    out = []
    for k, f in S.ALL.items():
        sc = f()
        out.append(dict(id=k, title=sc.title, module=sc.module, monitor_s=sc.mission.monitor_s,
                        wind=finite(sc.wind), illumination=sc.illumination, faults=finite(sc.faults),
                        surfaces=finite([{kk: v for kk, v in s.items() if kk in (
                            "id", "kind", "material", "label", "coating_mm", "declared_coating_mm",
                            "steel_thickness_mm", "max_load_n", "coating_visible")} for s in sc.surfaces])))
    return out


def build_scenario(req: dict):
    sid = req.get("scenario", "S1")
    if sid not in S.ALL:
        raise ValueError(f"unknown scenario '{sid}'")
    sc = S.ALL[sid]()
    ws, tu = req.get("wind_speed"), req.get("turbulence")
    if ws is not None or tu is not None:
        w = dict(sc.wind)
        if ws is not None:
            a = math.radians(float(req.get("wind_dir_deg", 0.0)) % 360.0)
            spd = _clamp("wind_speed", ws)
            w["mean"] = (spd * math.cos(a), spd * math.sin(a), 0.0)
        if tu is not None:
            w["turbulence_std"] = _clamp("turbulence", tu)
        sc.wind = w
    if req.get("illumination") is not None:
        sc.illumination = _clamp("illumination", req["illumination"])
    if req.get("position_source") in ("rtk", "gnss", "vio"):
        sc.position_source = req["position_source"]
    if req.get("module") in ("epm", "claw"):
        sc.module = req["module"]
    if req.get("monitor_s") is not None:
        sc.mission.monitor_s = _clamp("monitor_s", req["monitor_s"])
        sc.t_max = max(sc.t_max, sc.mission.monitor_s + 400.0)
    if req.get("t_max") is not None:
        sc.t_max = _clamp("t_max", req["t_max"])
    ids = {s["id"] for s in sc.surfaces}
    for ov in (req.get("surface_overrides") or [])[:20]:
        if ov.get("id") not in ids:
            raise ValueError(f"unknown surface '{ov.get('id')}' in {sid} (has {sorted(ids)})")
        surf = next(s for s in sc.surfaces if s["id"] == ov["id"])
        if ov.get("material") is not None:
            if ov["material"] not in MATERIAL_NAMES:
                raise ValueError(f"unknown material '{ov['material']}'")
            surf["material"] = ov["material"]
        for k in ("coating_mm", "steel_thickness_mm", "max_load_n"):
            if ov.get(k) is not None:
                surf[k] = _clamp(k, ov[k])
        if ov.get("coating_visible") is not None:
            surf["coating_visible"] = bool(ov["coating_visible"])
        dec = ov.get("declared_coating_mm")
        for rec in sc.site_db:
            if np.linalg.norm(np.array(rec.position) - np.array(surf["center"])) <= rec.radius:
                if dec is not None:
                    rec.declared_coating_mm = _clamp("declared_coating_mm", dec)
                if ov.get("steel_thickness_mm") is not None:
                    rec.steel_thickness_mm = _clamp("steel_thickness_mm", ov["steel_thickness_mm"])
        if dec is not None:
            surf["declared_coating_mm"] = _clamp("declared_coating_mm", dec)
    f = dict(sc.faults)
    faults = req.get("faults") or {}
    if faults.get("motor_degraded"):
        f["motor_health_on_perch"] = (2, 0.75)
    if faults.get("release_jam"):
        f["release_fault_on_perch"] = True
    stuck = [n for n in (faults.get("sensor_stuck") or []) if n in SENSORS]
    if stuck:
        f["sensor"] = list(f.get("sensor", [])) + [(n, "stuck", 30.0) for n in stuck]
    sc.faults = f
    sc.expect = {}
    prm = params_of(req)
    if "env.wind_speed" in prm or "env.turbulence" in prm:
        w = dict(sc.wind)
        if "env.wind_speed" in prm:
            m = np.array(w.get("mean", (0.0, 0.0, 0.0)), float)
            a = math.radians(float(req.get("wind_dir_deg", 0.0)) % 360.0) if np.linalg.norm(m[:2]) < 1e-9 \
                else math.atan2(m[1], m[0])
            w["mean"] = (prm["env.wind_speed"] * math.cos(a), prm["env.wind_speed"] * math.sin(a), 0.0)
        if "env.turbulence" in prm:
            w["turbulence_std"] = prm["env.turbulence"]
        sc.wind = w
    for surf in sc.surfaces:
        if "surface.mu_scale" in prm:
            surf["mu_scale"] = prm["surface.mu_scale"]
        if "surface.coating_mm" in prm:
            surf["coating_mm"] = prm["surface.coating_mm"]
    stop = req.get("stop_at")
    if stop not in (None, "perched"):
        raise ValueError("stop_at must be 'perched' or omitted")
    sc.stop_at = stop
    return sc


PHYSICS_DTS = (0.002, 0.001, 0.0005)          # allowed integration steps [s]; divisors stay integral


def sim_config(req: dict) -> SimConfig:
    dt = float(req.get("physics_dt", 0.002) or 0.002)
    if dt not in PHYSICS_DTS:
        raise ValueError(f"physics_dt must be one of {PHYSICS_DTS} s")
    k = round(0.002 / dt)
    seed = int(_clamp("seed", req.get("seed", 0)))
    prm = params_of(req)
    cfg = SimConfig(seed=seed, rates=Rates(physics_dt=dt, control_div=2 * k, outer_div=10 * k,
                                           perception_div=100 * k, log_div=25 * k))
    cfg.battery = replace(cfg.battery, capacity_ah=prm.get("battery.capacity_ah", cfg.battery.capacity_ah),
                          internal_resistance=prm.get("battery.internal_resistance", cfg.battery.internal_resistance))
    cfg.mass_override = prm.get("vehicle.mass_kg")
    if any(k.startswith("propulsion.") for k in prm):
        base = PropulsionParams()
        sc_ = prm.get("propulsion.prop_scale", 1.0)
        cfg.propulsion = replace(base, kv_rpm_per_v=prm.get("propulsion.kv", base.kv_rpm_per_v),
                                 k_t=base.k_t * sc_, k_q=base.k_q * sc_, tau=prm.get("propulsion.tau", base.tau))
    mech = {}
    if "mechanism.epm_force_n" in prm:
        mech["nominal_force"] = prm["mechanism.epm_force_n"]
    if "mechanism.claw_pull_off_n" in prm:
        mech["pull_off"] = prm["mechanism.claw_pull_off_n"]
    if "mechanism.claw_grip_n" in prm:
        mech["grip_normal"] = prm["mechanism.claw_grip_n"]
    cfg.mechanism_overrides = mech
    t = cfg.tuning
    cfg.tuning = replace(t, v_contact=prm.get("approach.v_contact", t.v_contact),
                         v_cruise=prm.get("approach.v_cruise", t.v_cruise),
                         approach_angle_deg=prm.get("approach.angle_deg", t.approach_angle_deg),
                         attitude_gain_scale=prm.get("gains.attitude_scale", t.attitude_gain_scale),
                         position_gain_scale=prm.get("gains.position_scale", t.position_gain_scale),
                         mpc_q_pos=prm.get("gains.mpc_q_pos", t.mpc_q_pos))
    return cfg


def canonical_request(req: dict) -> dict:
    """The fields that determine a run, normalised (unknown keys dropped)."""
    keys = ("scenario", "seed", "physics_dt", "wind_speed", "wind_dir_deg", "turbulence", "illumination",
            "position_source", "module", "monitor_s", "t_max", "surface_overrides", "faults", "params", "stop_at")
    out = {k: req.get(k) for k in keys if req.get(k) is not None}
    out.setdefault("scenario", "S1")
    out["seed"] = int(_clamp("seed", req.get("seed", 0)))
    out["physics_dt"] = float(req.get("physics_dt", 0.002) or 0.002)
    return finite(out)


def manifest(req: dict) -> dict:
    """Traceability record: identical engine version + canonical request => identical run_id."""
    canon = canonical_request(req)
    blob = json.dumps(dict(engine=__version__, request=canon), sort_keys=True, separators=(",", ":"))
    return dict(run_id=hashlib.sha256(blob.encode()).hexdigest()[:16], engine_version=__version__,
                request=canon, created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
                platform=platform.python_implementation() + " " + platform.python_version() +
                (" (Pyodide/WebAssembly)" if sys.platform == "emscripten" else ""),
                numpy=np.__version__, label="SIMULATED")


class Session:
    """One run, advanced in chunks by a driver (browser worker or FastAPI thread).

    post(msg) receives JSON strings (strict: no NaN/Infinity), or dicts when raw=True."""

    def __init__(self, req: dict, post, raw: bool = False):
        self.manifest = manifest(req)
        sc = build_scenario(req)
        cfg = sim_config(req)
        self.sim = Simulation(sc, seed=cfg.seed, cfg=cfg)
        self._post = (lambda m: post(finite(m))) if raw else (lambda m: post(json.dumps(finite(m), allow_nan=False)))
        self.sim.sink = self._post
        self.status = "running"
        self.result = None
        w = world_message(self.sim)
        w["manifest"] = self.manifest
        w["rates"] = dict(physics_dt=cfg.rates.physics_dt, control_hz=1 / (cfg.rates.physics_dt * cfg.rates.control_div),
                          outer_hz=1 / (cfg.rates.physics_dt * cfg.rates.outer_div),
                          perception_hz=1 / (cfg.rates.physics_dt * cfg.rates.perception_div),
                          log_hz=1 / (cfg.rates.physics_dt * cfg.rates.log_div))
        self._post(w)
        self.sim.begin()

    @property
    def t(self) -> float:
        return float(self.sim.sim.t)

    @property
    def done(self) -> bool:
        return self.status != "running"

    def advance(self, until_t: float) -> bool:
        if self.done:
            return True
        if self.sim.advance(float(until_t)):
            self._finish("stopped" if self.sim.stop_requested else "done")
        return self.done

    def stop(self):
        if not self.done:
            self.sim.stop_requested = True
            self._finish("stopped")

    def perf(self) -> dict:
        s = self.sim
        return dict(type="perf", sim_t=round(s.sim.t, 3), wall_s=round(s.wall_time, 3),
                    rtf=round(s.sim.t / s.wall_time, 3) if s.wall_time > 0 else None,
                    quasi_static_s=round(s.qs_seconds, 1))

    def _finish(self, status):
        res = self.sim.results()
        res.pop("reports", None)
        res["manifest"] = self.manifest
        res["stop_status"] = status
        self.result = finite(res)
        self.status = status
        self._post(dict(type="result", result=self.result))
        self._post(dict(type="end", status=status))


def run(req: dict, post, realtime=None):
    """Run one simulation to the end, streaming JSON strings through post(). Returns the result dict."""
    s = Session(req, post)
    s.advance(np.inf)
    return s.result
