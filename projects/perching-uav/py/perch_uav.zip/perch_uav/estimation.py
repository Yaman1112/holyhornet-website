"""State estimation from sensor messages only.

* AttitudeFilter  — Mahony-type complementary filter on SO(3): gyro integration with bias,
                    gravity-direction correction (gated on |a| ~ g), yaw from the position system.
* NavEKF          — 9-state EKF [p, v, b_a] with IMU-driven prediction, position-fix updates and
                    chi-square innovation gating (fault detection for the position source).
* RelativeTargetFilter — 6-state KF of the vehicle position relative to the chosen attachment
                    point, [r = p - p_target, v]. Updated by depth-perception geometry (normal
                    distance always; tangential only when the target edges are in view) and by
                    the pad ToF ranger. Absolute positioning errors cancel out of r.
"""

from __future__ import annotations

import numpy as np

from .geom import GRAVITY, rot_exp, skew, unit, wrap_pi, yaw_of, rot_z


class AttitudeFilter:
    def __init__(self, R0=None, kp=1.0, ki=0.02, k_yaw=0.5):
        self.R = np.eye(3) if R0 is None else R0.copy()
        self.b = np.zeros(3)
        self.kp, self.ki, self.k_yaw = kp, ki, k_yaw
        self.w = np.zeros(3)

    def update(self, gyro, accel, dt, yaw_meas=None, accel_trust=1.0):
        corr = np.zeros(3)
        an = np.linalg.norm(accel)
        if accel_trust > 0 and abs(an - GRAVITY) < 1.5:
            v_meas = accel / an
            v_est = self.R.T @ np.array([0.0, 0.0, 1.0])
            corr += self.kp * accel_trust * np.cross(v_meas, v_est)
        if yaw_meas is not None:
            e = wrap_pi(yaw_meas - yaw_of(self.R))
            corr += self.k_yaw * e * (self.R.T @ np.array([0.0, 0.0, 1.0]))
        self.b -= self.ki * corr * dt
        self.w = gyro - self.b
        self.R = self.R @ rot_exp((self.w + corr) * dt)
        U, _, Vt = np.linalg.svd(self.R)
        self.R = U @ Vt
        return self.R


class NavEKF:
    def __init__(self, p0, sigma_p=0.5):
        self.x = np.zeros(9)
        self.x[:3] = p0
        self.P = np.diag([sigma_p ** 2] * 3 + [0.1] * 3 + [0.05 ** 2] * 3)
        self.q_acc = 0.35 ** 2
        self.q_bias = 1e-5
        self.rejected = 0
        self.consecutive_rejects = 0
        self.last_nis = 0.0

    @property
    def p(self):
        return self.x[:3]

    @property
    def v(self):
        return self.x[3:6]

    def predict(self, R_hat, accel_b, dt):
        a_w = R_hat @ (accel_b - self.x[6:9]) - np.array([0.0, 0.0, GRAVITY])
        self.x[:3] += self.x[3:6] * dt + 0.5 * a_w * dt * dt
        self.x[3:6] += a_w * dt
        F = np.eye(9)
        F[:3, 3:6] = np.eye(3) * dt
        F[3:6, 6:9] = -R_hat * dt
        Q = np.zeros((9, 9))
        Q[3:6, 3:6] = np.eye(3) * self.q_acc * dt
        Q[:3, :3] = np.eye(3) * self.q_acc * dt ** 3 / 3
        Q[6:9, 6:9] = np.eye(3) * self.q_bias * dt
        self.P = F @ self.P @ F.T + Q
        return a_w

    def update_position(self, z, sigma, gate=16.27):
        H = np.zeros((3, 9))
        H[:, :3] = np.eye(3)
        Rm = np.diag(np.asarray(sigma) ** 2)
        y = z - self.x[:3]
        S = H @ self.P @ H.T + Rm
        nis = float(y @ np.linalg.solve(S, y))
        self.last_nis = nis
        if nis > gate:                    # chi2(3) 99.9 %
            self.rejected += 1
            self.consecutive_rejects += 1
            if self.consecutive_rejects < 25:
                return False
            # persistent disagreement: inflate covariance and accept (re-converge)
            self.P[:6, :6] += np.eye(6) * 0.5
            S = H @ self.P @ H.T + Rm
        self.consecutive_rejects = 0
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x += K @ y
        self.P = (np.eye(9) - K @ H) @ self.P
        return True

    def zero_velocity_update(self, sigma=0.01):
        """While rigidly attached the vehicle is stationary (pseudo-measurement v = 0)."""
        H = np.zeros((3, 9))
        H[:, 3:6] = np.eye(3)
        S = H @ self.P @ H.T + np.eye(3) * sigma ** 2
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x += K @ (-self.x[3:6])
        self.P = (np.eye(9) - K @ H) @ self.P


class ESKF:
    """15-state error-state Kalman filter (the navigation filter used by the autonomy).

    Nominal state: p, v, R (body->world), b_a, b_g.  Error state: dp, dv, dtheta (body), db_a, db_g.
        dp' = dv
        dv' = -R [a_b]x dtheta - R db_a + n_a
        dtheta' = -[w]x dtheta - db_g + n_g
        db_a' = n_ba,  db_g' = n_bg
    Updates: position fix (3), heading (1), zero-velocity pseudo-measurement (3, while attached).
    Tilt is observable through the velocity/position coupling, so it does not drift under sustained
    acceleration the way an accelerometer-levelling complementary filter does.
    """

    def __init__(self, p0, R0, sigma_p=0.05, sigma_att=0.02):
        self.p = np.array(p0, float)
        self.v = np.zeros(3)
        self.R = np.array(R0, float)
        self.ba = np.zeros(3)
        self.bg = np.zeros(3)
        self.w = np.zeros(3)
        self.P = np.diag([sigma_p ** 2] * 3 + [0.01] * 3 + [sigma_att ** 2] * 3 + [0.1 ** 2] * 3 + [0.01 ** 2] * 3)
        self.sa, self.sg, self.sba, self.sbg = 0.5, 0.01, 2e-3, 2e-4
        self.rejected = 0
        self.consecutive_rejects = 0
        self.last_nis = 0.0
        self.a_w = np.zeros(3)

    def predict(self, gyro, acc, dt):
        w = gyro - self.bg
        a_b = acc - self.ba
        a_w = self.R @ a_b - np.array([0.0, 0.0, GRAVITY])
        self.p = self.p + self.v * dt + 0.5 * a_w * dt * dt
        self.v = self.v + a_w * dt
        self.R = self.R @ rot_exp(w * dt)
        self.w, self.a_w = w, a_w
        F = np.eye(15)
        F[0:3, 3:6] = np.eye(3) * dt
        F[3:6, 6:9] = -self.R @ skew(a_b) * dt
        F[3:6, 9:12] = -self.R * dt
        F[6:9, 6:9] = np.eye(3) - skew(w) * dt
        F[6:9, 12:15] = -np.eye(3) * dt
        Q = np.zeros(15)
        Q[3:6] = (self.sa * dt) ** 2
        Q[6:9] = (self.sg * dt) ** 2
        Q[9:12] = self.sba ** 2 * dt
        Q[12:15] = self.sbg ** 2 * dt
        self.P = F @ self.P @ F.T + np.diag(Q)
        return a_w

    def _correct(self, H, y, Rm, gate=None):
        S = H @ self.P @ H.T + Rm
        nis = float(y @ np.linalg.solve(S, y))
        self.last_nis = nis
        if gate is not None and nis > gate:
            self.rejected += 1
            self.consecutive_rejects += 1
            if self.consecutive_rejects < 25:
                return False
            self.P[0:6, 0:6] += np.eye(6) * 0.25          # persistent disagreement: re-converge
            S = H @ self.P @ H.T + Rm
        self.consecutive_rejects = 0
        K = self.P @ H.T @ np.linalg.inv(S)
        dx = K @ y
        self.p = self.p + dx[0:3]
        self.v = self.v + dx[3:6]
        self.R = self.R @ rot_exp(dx[6:9])
        U, _, Vt = np.linalg.svd(self.R)
        self.R = U @ Vt
        self.ba = self.ba + dx[9:12]
        self.bg = self.bg + dx[12:15]
        I_KH = np.eye(15) - K @ H
        self.P = I_KH @ self.P @ I_KH.T + K @ Rm @ K.T
        return True

    def update_position(self, z, sigma, gate=16.27):
        H = np.zeros((3, 15))
        H[:, 0:3] = np.eye(3)
        return self._correct(H, np.asarray(z) - self.p, np.diag(np.asarray(sigma) ** 2), gate)

    def update_yaw(self, yaw, sigma):
        y0 = yaw_of(self.R)
        H = np.zeros((1, 15))
        eps = 1e-5
        for i in range(3):
            e = np.zeros(3)
            e[i] = eps
            H[0, 6 + i] = wrap_pi(yaw_of(self.R @ rot_exp(e)) - y0) / eps
        return self._correct(H, np.array([wrap_pi(yaw - y0)]), np.eye(1) * sigma ** 2)

    def zero_velocity_update(self, sigma=0.01):
        H = np.zeros((3, 15))
        H[:, 3:6] = np.eye(3)
        return self._correct(H, -self.v, np.eye(3) * sigma ** 2)


class RelativeTargetFilter:
    """r = p_vehicle - p_target in world axes, plus vehicle velocity."""

    def __init__(self, r0, v0, normal, sigma_r=0.3):
        self.x = np.r_[np.asarray(r0, float), np.asarray(v0, float)]
        self.P = np.diag([sigma_r ** 2] * 3 + [0.05] * 3)
        self.n = unit(np.asarray(normal, float))
        self.updates = 0

    @property
    def r(self):
        return self.x[:3]

    @property
    def v(self):
        return self.x[3:]

    def predict(self, a_w, dt, q=0.4 ** 2):
        self.x[:3] += self.x[3:] * dt + 0.5 * a_w * dt * dt
        self.x[3:] += a_w * dt
        F = np.eye(6)
        F[:3, 3:] = np.eye(3) * dt
        Q = np.zeros((6, 6))
        Q[3:, 3:] = np.eye(3) * q * dt
        Q[:3, :3] = np.eye(3) * q * dt ** 3 / 3
        self.P = F @ self.P @ F.T + Q

    def _update(self, H, z, Rm):
        y = z - H @ self.x
        S = H @ self.P @ H.T + Rm
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x += K @ y
        self.P = (np.eye(6) - K @ H) @ self.P
        self.updates += 1
        return y

    def update_relative(self, r_meas, sigma, directions):
        """Measure the components of r along the given unit directions (rows)."""
        D = np.atleast_2d(directions)
        H = np.zeros((len(D), 6))
        H[:, :3] = D
        return self._update(H, D @ r_meas, np.eye(len(D)) * sigma ** 2)

    def update_velocity(self, v_meas, sigma):
        H = np.zeros((3, 6))
        H[:, 3:] = np.eye(3)
        return self._update(H, np.asarray(v_meas), np.eye(3) * sigma ** 2)

    def update_tof(self, rng, tip_offset_w, sigma=0.004):
        """ToF range from the pad tip along -n to the surface: rng = n . (r + tip_offset)."""
        H = np.zeros((1, 6))
        H[0, :3] = self.n
        z = np.array([rng - self.n @ tip_offset_w])
        return self._update(H, z, np.eye(1) * sigma ** 2)

    def normal_distance(self):
        return float(self.n @ self.x[:3])

    def normal_speed(self):
        return float(self.n @ self.x[3:])
