"""Closed-loop simulation harness (multi-rate) and run metrics.

Rates: physics 500 Hz, IMU + attitude control 250 Hz, state machine + pad/ESC/battery 50 Hz,
position fix + anemometer 10 Hz, depth perception 5 Hz, telemetry log 20 Hz.

While perched with propulsion off, the harness can switch to a QUASI-STATIC mode (1 s steps):
the vehicle is rigidly held, true attachment loads are computed from the static model with the
true capacity, battery and payload energy are integrated, and the autonomy runs at 1 Hz. This is
how hours of sensor mode are simulated; the dynamic model covers every transient.
"""

from __future__ import annotations

import time
from dataclasses import replace

import numpy as np

from .autonomy import MISSION_STATES, Autonomy
from .config import SimConfig
from .dynamics import VehicleSim
from .geom import yaw_of
from .mechanism import BOOM_POSES, ClawParams, EPMPadParams, claw_utilisation, epm_utilisation, perched_pad_wrench
from .scenarios import Scenario
from .sensors import AmbientSensors, SensorSpec, SensorSuite


class Simulation:
    BASE_MASS = 1.33

    def __init__(self, sc: Scenario, seed: int = 0, cfg: SimConfig | None = None):
        self.sc = sc
        self.seed = seed
        self.cfg = cfg or SimConfig(seed=seed)
        self.module = EPMPadParams() if sc.module == "epm" else ClawParams()
        vp = replace(self.cfg.vehicle, mass=self.BASE_MASS + self.module.mass)
        self.cfg.vehicle = vp
        ss = np.random.SeedSequence(seed)
        r_sim, r_sens, r_amb, r_auto = [np.random.default_rng(s) for s in ss.spawn(4)]
        self.world = sc.build_world()
        boom = "down"
        p0 = tuple(np.array(sc.mission.home, float) + np.array([0, 0, 0.15]))
        self.sim = VehicleSim(vp, self.cfg.battery, self.world, self.module, boom, p0, 0.0, r_sim, sc.soc0)
        self.sensors = SensorSuite(self.sim, SensorSpec(position_source=sc.position_source), r_sens)
        self.amb = AmbientSensors(self.sim, r_amb)
        for name, kind, t0 in sc.faults.get("sensor", []):
            self.amb.inject(name, kind, t0)
        self.auto = Autonomy(self.cfg, self.module, boom, sc.mission, sc.site_db, p0, 0.0,
                             station_read=lambda n, t: self.amb.read(n, t), rng=r_auto)
        self.log: list[dict] = []
        self.wall_time = 0.0
        self.qs_seconds = 0.0
        self._fault_applied = set()
        self._station_e = 0.0
        self.attached_positions = []
        # streaming hooks (used by perch_service; the batch tools leave them unset)
        self.sink = None                 # callable(dict) receiving frames / transitions / events
        self.stop_requested = False
        self.realtime = None             # pace the dynamic part at this many x real time (None = max speed)
        self._events_sent = 0
        self._map_next = 0.0
        self._reports_sent = 0
        self._w0 = None

    # ------------------------------------------------------------------ helpers
    def _apply_mech_cmds(self):
        for c in self.auto.mech_cmds:
            if c.startswith("boom:"):
                self.sim.mech.boom = BOOM_POSES[c.split(":")[1]]
                self.sim.mech.boom_name = c.split(":")[1]
            else:
                self.sim.mech.command(c)
        self.auto.mech_cmds.clear()

    def _material_for(self, msg, dets):
        ids = msg._truth_ids
        for d in dets:
            lab = ids[d.idx]
            lab = lab[(lab >= 0) & (lab < 1000)]
            if len(lab) == 0:
                continue
            sid = self.world.surfaces[int(np.bincount(lab).argmax())].id
            if sid == "ground":
                d.material = self.sensors.material(sid) if self.world.surfaces[0].material else None
            else:
                d.material = self.sensors.material(sid)

    def _apply_faults(self):
        f = self.sc.faults
        a = self.auto
        if a.state == "SENSOR_MODE":
            if "motor_health_on_perch" in f and "mh" not in self._fault_applied:
                i, h = f["motor_health_on_perch"]
                self.sim.motor_health[i] = h
                self._fault_applied.add("mh")
                self.sim.log_event("fault", f"motor {i+1} degraded to {h:.0%} thrust (injected)")
            if f.get("release_fault_on_perch") and "rf" not in self._fault_applied:
                self.sim.mech.release_fault = True
                self._fault_applied.add("rf")
                self.sim.log_event("fault", "release mechanism jammed (injected)")
            if f.get("obstacle_window") and "ob" not in self._fault_applied and a.perched_since is not None:
                t0 = a.perched_since + self.sc.mission.monitor_s - 4.0
                for ob in self.world.obstacles:
                    ob.t_start, ob.t_end = t0, t0 + 20.0
                self._fault_applied.add("ob")

    def _record(self):
        s, a = self.sim.s, self.auto
        at = self.sim.attachment
        self.log.append(dict(
            t=round(self.sim.t, 3), state=a.state, p=s.p.round(4).tolist(), p_est=a.nav.p.round(4).tolist(),
            v=s.v.round(3).tolist(), yaw=round(yaw_of(s.R), 4), R=s.R.round(4).tolist(),
            thrust=round(float(s.f.sum()), 2), armed=bool(self.sim.armed), soc=round(self.sim.battery.soc, 5),
            power=round(self.sim.power_w, 1), wind=self.sim.wind.round(2).tolist(),
            util=None if (at is None or at.last_util is None) else round(float(at.last_util.value), 3),
            mech=self.sim.mech.state, boom=self.sim.mech.boom_name, token=a.interlock.token))
        if self.sink is not None:
            self._stream()

    # ------------------------------------------------------------------ streaming
    def _stream(self):
        from .streaming import frame, map_message, reports_message
        self.sink(frame(self))
        sim, a = self.sim, self.auto
        while self._events_sent < len(sim.events):
            t, kind, msg = sim.events[self._events_sent]
            self.sink(dict(type="event", t=t, kind=kind, msg=msg))
            self._events_sent += 1
        if sim.t >= self._map_next:
            self._map_next = sim.t + 1.0
            self.sink(map_message(self))
        while self._reports_sent < len(a.reports):
            self.sink(reports_message(self, self._reports_sent))
            self._reports_sent += 1
        if self.realtime:
            lag = (sim.t - self.qs_seconds) / self.realtime - (time.time() - self._w0)   # quasi-static time is not paced
            if lag > 0:
                time.sleep(lag)

    def _transition(self, prev):
        if self.sink is not None:
            t, a, b, why = self.auto.transitions[-1]
            self.sink(dict(type="transition", t=t, src=a, dst=b, why=why))

    # ------------------------------------------------------------------ main loop
    def run(self, t_max: float | None = None, verbose: bool = False):
        t_max = t_max or self.sc.t_max
        r = self.cfg.rates
        dt = r.physics_dt
        sim, a, sens = self.sim, self.auto, self.sensors
        a.on_battery(sens.battery())
        a.on_pad(sens.pad())
        a.start(0.0)
        sim.armed = a.armed
        k = 0
        w0 = time.time()
        done_t = None
        self._w0 = w0
        while sim.t < t_max and not sim.crashed and not self.stop_requested:
            if k % r.control_div == 0:
                f = a.on_imu(sens.imu(), dt * r.control_div)
                sim.armed = a.armed
                sim.set_motor_commands(f)
            if k % r.outer_div == 0:
                if k % (r.outer_div * 5) == 0:
                    a.on_position(sens.position(dt * r.outer_div * 5))
                    a.on_anemometer(sens.anemometer())
                a.on_pad(sens.pad())
                a.on_esc(sens.esc())
                a.on_battery(sens.battery())
                prev = a.state
                a.step(sim.t, dt * r.outer_div)
                self._apply_mech_cmds()
                self._apply_faults()
                sim.avionics_power_w = 1.0 if a.low_power else self.cfg.vehicle.avionics_power_w
                if a.station is not None:
                    e = a.station.energy_j
                    sim.payload_power_w = (e - self._station_e) / (dt * r.outer_div) if a.state == "SENSOR_MODE" else 0.0
                    self._station_e = e
                if prev != a.state:
                    self._transition(prev)
                if verbose and prev != a.state:
                    print(f"{sim.t:8.2f}  {prev:>28} -> {a.state:<28} {a.transitions[-1][3]}")
            if k % r.perception_div == 0:
                for cam in ("front", "down", "rear"):
                    msg = sens.depth(cam)
                    dets = a.detect(msg)
                    self._material_for(msg, dets)
                    a.integrate(dets, sim.t)
            sim.step(dt)
            if a.state == "SENSOR_MODE" and sim.attachment is not None:
                self.attached_positions.append(sim.s.p.copy())
            if k % r.log_div == 0:
                self._record()
            k += 1
            if (self.sc.quasi_static and a.state == "SENSOR_MODE" and not sim.armed and a.dt_state > 3.0
                    and sim.attachment is not None and self.sc.mission.monitor_s > 120):
                self._quasi_static(t_max, verbose)
            if a.state in ("MISSION_COMPLETE", "MISSION_FAILED"):
                done_t = done_t or sim.t
                if sim.t - done_t > 1.0:
                    break
            if (self.sc.expect.get("remain_attached") and a.flags.get("pretakeoff_failures") or a.flags.get("release_fault")) \
                    and a.state == "SENSOR_MODE" and a.dt_state > 5.0:
                break
        self.wall_time = time.time() - w0
        return self.results()

    def _quasi_static(self, t_max, verbose):
        sim, a, sens = self.sim, self.auto, self.sensors
        at = sim.attachment
        boom = sim.mech.boom
        dt = 1.0
        while a.state == "SENSOR_MODE" and sim.t < t_max and sim.attachment is not None and not self.stop_requested:
            sim.wind = self.world.wind.step(sim.t, dt, sim.rng)
            F, M = perched_pad_wrench(sim.mass, sim.s.R, boom, sim.wind, at.n, self.cfg.vehicle.feet)
            if sim.mech.is_epm:
                u = epm_utilisation(sim.mech.params, at.capacity, F, M, at.n, at.long_axis)
            else:
                u = claw_utilisation(sim.mech.params, at.capacity, F, M, at.n, at.long_axis)
            at.last_util, at.last_F, at.last_M = u, F, M
            if u.value > 1.0:
                sim.log_event("attachment_failure", f"quasi-static: attachment failed in {u.mode} "
                                                    f"(utilisation {u.value:.2f}, wind {np.linalg.norm(sim.wind):.1f} m/s)")
                sim.attachment = None
                break
            sim.t += dt
            self.qs_seconds += dt
            sim.power_w = sim.avionics_power_w + sim.payload_power_w
            sim.battery.draw(sim.power_w, dt)
            a.on_pad(sens.pad())
            a.on_battery(sens.battery())
            a.on_anemometer(sens.anemometer())
            prev = a.state
            a.step(sim.t, dt)
            if prev != a.state:
                self._transition(prev)
            self._apply_mech_cmds()
            self._apply_faults()
            if a.station is not None:
                e = a.station.energy_j
                sim.payload_power_w = (e - self._station_e) / dt
                self._station_e = e
            if int(sim.t) % 60 == 0:
                self._record()
        if verbose:
            print(f"{sim.t:8.2f}  quasi-static sensor mode ended ({self.qs_seconds:.0f} s simulated)")

    # ------------------------------------------------------------------ metrics
    def results(self) -> dict:
        a, sim = self.auto, self.sim
        visited = {tr[2] for tr in a.transitions} | {"TAKEOFF"}
        st = {s: (s in visited) for s in MISSION_STATES}

        def first(state):
            return next((tr[0] for tr in a.transitions if tr[2] == state), None)

        t_final = first("FINAL_APPROACH")
        t_sensor = first("SENSOR_MODE")
        t_pre = first("PRE_TAKEOFF_CHECK")
        t_resume = first("AUTONOMOUS_MISSION_RESUMPTION")
        stab = None
        if len(self.attached_positions) > 10:
            P = np.array(self.attached_positions)
            stab = float(np.max(np.linalg.norm(P - P.mean(0), axis=1)))
        last_pre = next((tr[0] for tr in reversed(a.transitions) if tr[2] == "PRE_TAKEOFF_CHECK"), None)
        res = dict(
            scenario=self.sc.name, title=self.sc.title, seed=self.seed, label="SIMULATED",
            final_state=a.state, crashed=sim.crashed,
            perched=t_sensor is not None, detached=t_resume is not None,
            completed=a.state == "MISSION_COMPLETE",
            remained_attached=bool(a.flags.get("pretakeoff_failures") or a.flags.get("release_fault"))
            and a.state == "SENSOR_MODE",
            time_final_approach_to_perched_s=None if (t_final is None or t_sensor is None) else round(t_sensor - t_final, 2),
            time_pre_takeoff_to_resumed_s=None if (last_pre is None or t_resume is None) else round(t_resume - last_pre, 2),
            sim_time_s=round(sim.t, 1), quasi_static_s=round(self.qs_seconds, 1), wall_time_s=round(self.wall_time, 2),
            energy_used_wh=round(sim.battery.energy_used_j / 3600, 3), final_soc=round(sim.battery.soc, 4),
            aborts=int(a.metrics.get("aborts", 0)), verified_sf=a.metrics.get("verified_sf"),
            contact_speed_est=a.metrics.get("contact_speed_est"),
            load_transfer_slip_mm=a.metrics.get("load_transfer_slip_mm"),
            attached_position_excursion_m=stab,
            interlock_blocked=a.interlock.violations_blocked, release_blocked=a.release_lock.blocked,
            vetoes=len(a.guard.vetoes), states_visited=st,
            transitions=a.transitions, findings=a.findings, events=sim.events,
            station=a.station.summary() if a.station else None,
            decisions=[dict(action=d.action, reasons=d.reasons, vetoed=d.vetoed, veto=d.veto_reason) for d in a.decisions],
            reports=[[dict(id=r.candidate_id, suitable=r.suitable, score=round(r.score, 3), sf=round(r.predicted_sf, 2)
                           if np.isfinite(r.predicted_sf) else None, summary=r.summary,
                           gates=[dict(name=g.name, passed=g.passed, value=g.value, threshold=g.threshold, why=g.why)
                                  for g in r.gates]) for r in reps] for _, reps in a.reports],
        )
        return res
