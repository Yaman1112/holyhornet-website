"""Reproducible validation experiments. Every number produced here is SIMULATED.

    python -m perch_uav.experiments --seeds 5 --out experiments/results

E1  Monte-Carlo perching campaign over scenarios S1-S6, S8-S10 (randomised wind, sensor noise)
E2  Energy: continuous hovering vs conventional landing vs perching, from simulated power draws
E3  Holding limit vs wind for each perch configuration (static model, true capacities)
E4  Position stability while attached (ground truth, dynamic part of sensor mode)
E5  Long-duration sensor mode (S7): data volume, fault detection, event detection, energy
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import pathlib
from concurrent.futures import ProcessPoolExecutor

import numpy as np

from . import scenarios as S
from .config import BatteryParams
from .geom import rot_z
from .mechanism import (BOOM_POSES, ClawParams, EPMPadParams, claw_capacity, claw_utilisation, epm_capacity,
                        epm_utilisation, perched_pad_wrench)
from .simulation import Simulation

CAMPAIGN = ["S1", "S2", "S3", "S4", "S5", "S6", "S8", "S9", "S10"]


def randomise(sc, seed):
    rng = np.random.default_rng(10_000 + seed)
    spd = rng.uniform(0.0, 4.0)
    ang = rng.uniform(0, 2 * np.pi)
    sc.wind = dict(sc.wind)
    sc.wind["mean"] = (spd * np.cos(ang), spd * np.sin(ang), 0.0)
    sc.wind["turbulence_std"] = rng.uniform(0.2, 1.0)
    return sc


def _run(args):
    name, seed = args
    sc = randomise(S.ALL[name](), seed)
    sim = Simulation(sc, seed=seed)
    r = sim.run()
    keep = {k: r[k] for k in ("scenario", "seed", "final_state", "crashed", "perched", "detached", "completed",
                              "remained_attached", "aborts", "verified_sf", "time_final_approach_to_perched_s",
                              "time_pre_takeoff_to_resumed_s", "energy_used_wh", "attached_position_excursion_m",
                              "interlock_blocked", "sim_time_s", "wall_time_s")}
    keep["wind_mean"] = round(float(np.linalg.norm(sc.wind["mean"])), 2)
    keep["turbulence"] = round(sc.wind["turbulence_std"], 2)
    keep["expect"] = sc.expect
    keep["as_expected"] = _as_expected(r, sc.expect)
    keep["findings"] = r["findings"]
    keep["events"] = [e for e in r["events"] if e[1] in ("crash", "attachment_failure", "attach", "detach")]
    # safety invariant: propulsion never off before verification
    keep["safety_invariant_ok"] = _invariant_ok(r)
    # success: met expectation; safe_decline: did not perch/finish as hoped but ended landed or
    # attached-and-safe with every safety check satisfied; failure: crash or invariant violation
    if r["crashed"] or not keep["safety_invariant_ok"]:
        keep["outcome"] = "failure"
    elif keep["as_expected"]:
        keep["outcome"] = "success"
    elif r["completed"] or r["remained_attached"]:
        keep["outcome"] = "safe_decline"
    else:
        keep["outcome"] = "failure"
    return keep


def _as_expected(r, exp):
    if r["crashed"]:
        return False
    if "perch" in exp and r["perched"] != exp["perch"]:
        return False
    if exp.get("detach") and not r["detached"]:
        return False
    if exp.get("remain_attached") and not r["remained_attached"]:
        return False
    if exp.get("complete") and not r["completed"]:
        return False
    if "aborts_min" in exp and r["aborts"] < exp["aborts_min"]:
        return False
    return True


def _invariant_ok(r):
    """Every entry to SENSOR_MODE (propulsion off) is preceded by ATTACHMENT_VERIFICATION ->
    PROPULSION_REDUCTION, or by an earlier verified perch with no detachment in between."""
    seq = [b for _, a, b, _ in r["transitions"]]
    verified = False
    for i, s in enumerate(seq):
        if s == "PROPULSION_REDUCTION":
            verified = i > 0 and seq[i - 1] == "ATTACHMENT_VERIFICATION"
        if s in ("TAKEOFF_VERIFICATION", "ABORT_RECOVERY", "EMERGENCY_RESPIN"):
            verified = False
        if s == "SENSOR_MODE" and not verified:
            return False
    return True


def e1_campaign(seeds, workers):
    jobs = [(n, s) for n in CAMPAIGN for s in range(seeds)]
    with ProcessPoolExecutor(workers) as ex:
        rows = list(ex.map(_run, jobs))
    summary = {}
    for n in CAMPAIGN:
        rs = [r for r in rows if r["scenario"] == n]
        t_p = [r["time_final_approach_to_perched_s"] for r in rs if r["time_final_approach_to_perched_s"]]
        t_d = [r["time_pre_takeoff_to_resumed_s"] for r in rs if r["time_pre_takeoff_to_resumed_s"]]
        summary[n] = dict(
            title=S.ALL[n]().title, runs=len(rs),
            as_expected=sum(r["as_expected"] for r in rs),
            safe_decline=sum(r["outcome"] == "safe_decline" for r in rs),
            failure=sum(r["outcome"] == "failure" for r in rs),
            perched=sum(r["perched"] for r in rs), detached=sum(r["detached"] for r in rs),
            completed=sum(r["completed"] for r in rs), crashed=sum(r["crashed"] for r in rs),
            aborts=sum(r["aborts"] for r in rs),
            safety_invariant_ok=all(r["safety_invariant_ok"] for r in rs),
            time_to_perch_s_median=None if not t_p else round(float(np.median(t_p)), 1),
            time_to_detach_s_median=None if not t_d else round(float(np.median(t_d)), 1),
            verified_sf_min=None if not [r["verified_sf"] for r in rs if r["verified_sf"]] else
            round(min(r["verified_sf"] for r in rs if r["verified_sf"]), 2),
        )
    return rows, summary


def e2_energy(rows):
    """Power figures come from simulated runs; endurance uses the simulated battery capacity."""
    bp = BatteryParams()
    e_pack = bp.capacity_ah * bp.cells * 0.5 * (bp.cell_v_full + bp.cell_v_empty)        # Wh
    usable = e_pack * (1 - bp.reserve_soc)
    # hover: dynamic simulation of 60 s station-keeping in 3 m/s wind
    sc = S.s5_unsuitable()
    sc.mission.monitor_s = 60.0
    sc.wind = dict(mean=(3.0, 0.0, 0.0), turbulence_std=0.5)
    sim = Simulation(sc, seed=0)
    sim.run()
    hov = [L["power"] for L in sim.log if L["state"] == "HOVER_MONITOR"]
    p_hover = float(np.mean(hov[20:])) if len(hov) > 40 else float("nan")
    # perched: S1 with a 300 s sensor mode -> mean power in SENSOR_MODE (avionics low power + payload)
    sc = S.s1_horizontal()
    sc.mission.monitor_s = 300.0
    sim = Simulation(sc, seed=0)
    r = sim.run()
    per = [L["power"] for L in sim.log if L["state"] == "SENSOR_MODE"]
    p_perch = float(np.mean(per[20:])) if len(per) > 40 else float("nan")
    # transition energy: perch manoeuvre and departure, integrated from the 20 Hz log
    def integ(states):
        e, prev = 0.0, None
        for L in sim.log:
            if L["state"] in states and prev is not None and prev["state"] in states:
                e += 0.5 * (L["power"] + prev["power"]) * (L["t"] - prev["t"])
            prev = L
        return e / 3600.0
    e_perch_wh = integ({"FINAL_APPROACH", "CONTACT_DETECTION", "ATTACHMENT", "ATTACHMENT_VERIFICATION",
                        "PROPULSION_REDUCTION"})
    e_depart_wh = integ({"PRE_TAKEOFF_CHECK", "DETACHMENT", "TAKEOFF_VERIFICATION"})
    p_landed = p_perch          # same avionics/payload while sitting on the ground (no vantage point)
    out = dict(label="SIMULATED", pack_wh=round(e_pack, 1), usable_wh=round(usable, 1),
               hover_power_w=round(p_hover, 1), perched_power_w=round(p_perch, 2), landed_power_w=round(p_landed, 2),
               perch_manoeuvre_wh=round(e_perch_wh, 3), departure_wh=round(e_depart_wh, 3),
               hover_endurance_h=round(usable / p_hover, 2), perched_endurance_h=round(usable / p_perch, 1),
               table=[])
    for hours in (0.25, 1, 4, 12, 24):
        e_h = p_hover * hours
        e_p = p_perch * hours + e_perch_wh + e_depart_wh
        out["table"].append(dict(duration_h=hours, hover_wh=round(e_h, 1), perch_wh=round(e_p, 2),
                                 landed_wh=round(p_landed * hours + 0.5 * (e_perch_wh + e_depart_wh), 2),
                                 hover_feasible=e_h <= usable, perch_feasible=e_p <= usable,
                                 saving_pct=round(100 * (1 - e_p / e_h), 1)))
    return out


def e3_holding_limits():
    """Wind speed at which the TRUE attachment reaches utilisation 1 (static model, worst direction)."""
    cases = [
        ("deck (S1)", EPMPadParams(), "down", np.array([0, 0, 1.0]), "painted_steel", 0.15, 8.0, None),
        ("tank wall (S2)", EPMPadParams(), "forward", np.array([-1.0, 0, 0]), "mild_steel", 0.05, 10.0, None),
        ("20 deg roof (S3)", EPMPadParams(), "down", np.array([-np.sin(0.349), 0, np.cos(0.349)]), "painted_steel", 0.12, 6.0, None),
        ("pipe, claw (S4)", ClawParams(), "down", np.array([0, 0, 1.0]), "painted_steel", 0.0, 0.0, 0.04),
        ("wall, 0.3 mm paint", EPMPadParams(), "forward", np.array([-1.0, 0, 0]), "painted_steel", 0.3, 8.0, None),
    ]
    out = []
    winds = np.arange(0.0, 30.01, 0.5)
    for name, mod, boom, n, mat, coat, th, dia in cases:
        bp = BOOM_POSES[boom]
        if isinstance(mod, EPMPadParams):
            cap = epm_capacity(mod, mat, coat, th, 0.05, 0.0, None)
        else:
            cap = claw_capacity(mod, mat, dia)
        from .suitability import _perch_pose
        R = _perch_pose(boom, n, 0.0, np.array([0, 1.0, 0]) if dia else None)
        axis = R @ np.array(bp.long_axis) if isinstance(mod, EPMPadParams) else np.array([0, 1.0, 0])
        curve = []
        limit = None
        for v in winds:
            worst = 0.0
            for a in np.linspace(0, 2 * np.pi, 24, endpoint=False):
                for vz in (0.0, 0.3, -0.3):
                    d = np.array([np.cos(a), np.sin(a), vz])
                    F, M = perched_pad_wrench(1.45, R, bp, v * d / np.linalg.norm(d), n)
                    u = (epm_utilisation(mod, cap, F, M, n, axis) if isinstance(mod, EPMPadParams)
                         else claw_utilisation(mod, cap, F, M, n, axis))
                    worst = max(worst, u.value)
            curve.append(round(float(worst), 4))
            if limit is None and worst >= 1.0:
                limit = float(v)
        sf2 = next((float(v) for v, u in zip(winds, curve) if u >= 0.5), None)
        out.append(dict(case=name, label="SIMULATED (static model)", wind_at_failure_ms=limit,
                        wind_at_sf2_ms=sf2, utilisation_curve=curve, winds=winds.tolist()))
    return out


def e5_long_duration(hours):
    sc = S.s7_long_duration(hours)
    sim = Simulation(sc, seed=0)
    r = sim.run()
    st = sim.auto.station
    faults = {}
    for name, kind, t0 in sc.faults.get("sensor", []):
        ser = st.series.get(name, [])
        det = next((t for t, v, s in ser if t >= t0 and s != "ok"), None)
        if kind == "dropout":
            det = None
            # dropout -> no samples; health flags 'dropout' after 3 missed samples
            det = t0 + 3 * st.cfg.schedule[name][0] if st.health.status.get(name) == "dropout" else None
        faults[f"{name}:{kind}"] = None if det is None else round(det - t0, 1)
    truth_events = [("acoustic", t) for t, d, v in sc.ambient.acoustic_events] + \
                   [("vibration", t) for t, d, v in sc.ambient.vibration_events] + \
                   [("thermal", a) for a, b, v in sc.ambient.hotspots] + [("gas", t) for t, d, v in sc.ambient.gas_events]
    detected = []
    for kind, t0 in truth_events:
        hit = next((t for t, k, v in st.events if k == kind and t0 - 5 <= t <= t0 + 900), None)
        detected.append(dict(kind=kind, t_true_h=round(t0 / 3600, 2), detected=hit is not None,
                             latency_s=None if hit is None else round(hit - t0, 1)))
    return dict(label="SIMULATED", hours=hours, result={k: r[k] for k in ("final_state", "perched", "detached",
                                                                           "completed", "crashed", "energy_used_wh",
                                                                           "final_soc", "quasi_static_s")},
                station=st.summary(), fault_detection_latency_s=faults, events=detected,
                decisions=[d["reasons"][0] for d in r["decisions"]][-6:], findings=r["findings"][-6:],
                sim_events=r["events"][-6:])


# ------------------------------------------------------------------ output
def _svg_bars(title, labels, series, unit, path, colors=("#2a6fdb", "#e8833a", "#3aa76d")):
    W, H, pad = 720, 320, 60
    vmax = max(max(s[1]) for s in series) or 1
    n, k = len(labels), len(series)
    bw = (W - 2 * pad) / n / (k + 1)
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="sans-serif" font-size="11">',
           f'<text x="{W/2}" y="18" text-anchor="middle" font-size="13">{title}</text>',
           f'<line x1="{pad}" y1="{H-pad}" x2="{W-pad}" y2="{H-pad}" stroke="#888"/>']
    for i, lab in enumerate(labels):
        x0 = pad + i * (W - 2 * pad) / n
        out.append(f'<text x="{x0 + (W-2*pad)/n/2}" y="{H-pad+16}" text-anchor="middle">{lab}</text>')
        for j, (name, vals) in enumerate(series):
            h = (H - 2 * pad) * vals[i] / vmax
            out.append(f'<rect x="{x0 + (j+0.5)*bw}" y="{H-pad-h}" width="{bw*0.9}" height="{h}" fill="{colors[j]}"/>')
            out.append(f'<text x="{x0 + (j+0.95)*bw}" y="{H-pad-h-3}" text-anchor="middle" font-size="9">{vals[i]:g}</text>')
    for j, (name, _) in enumerate(series):
        out.append(f'<rect x="{pad + j*150}" y="28" width="10" height="10" fill="{colors[j]}"/>'
                   f'<text x="{pad + j*150 + 14}" y="37">{name}</text>')
    out.append(f'<text x="14" y="{H/2}" transform="rotate(-90 14 {H/2})" text-anchor="middle">{unit}</text>')
    out.append(f'<text x="{W-pad}" y="{H-8}" text-anchor="end" fill="#a33">SIMULATED</text></svg>')
    pathlib.Path(path).write_text("\n".join(out), encoding="utf-8")


def _svg_lines(title, x, curves, path):
    W, H, pad = 720, 320, 60
    colors = ["#2a6fdb", "#e8833a", "#3aa76d", "#a33", "#7a4fc9"]
    ymax = 2.0
    xmax = max(x)
    def X(v): return pad + (W - 2 * pad) * v / xmax
    def Y(v): return H - pad - (H - 2 * pad) * min(v, ymax) / ymax
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" font-family="sans-serif" font-size="11">',
           f'<text x="{W/2}" y="18" text-anchor="middle" font-size="13">{title}</text>',
           f'<line x1="{pad}" y1="{H-pad}" x2="{W-pad}" y2="{H-pad}" stroke="#888"/>',
           f'<line x1="{pad}" y1="{pad}" x2="{pad}" y2="{H-pad}" stroke="#888"/>',
           f'<line x1="{pad}" y1="{Y(1)}" x2="{W-pad}" y2="{Y(1)}" stroke="#a33" stroke-dasharray="4 3"/>',
           f'<text x="{W-pad}" y="{Y(1)-4}" text-anchor="end" fill="#a33">failure (utilisation 1)</text>',
           f'<line x1="{pad}" y1="{Y(0.5)}" x2="{W-pad}" y2="{Y(0.5)}" stroke="#999" stroke-dasharray="2 3"/>',
           f'<text x="{W-pad}" y="{Y(0.5)-4}" text-anchor="end" fill="#666">SF 2</text>']
    for v in range(0, int(xmax) + 1, 5):
        out.append(f'<text x="{X(v)}" y="{H-pad+16}" text-anchor="middle">{v}</text>')
    out.append(f'<text x="{W/2}" y="{H-20}" text-anchor="middle">wind speed [m/s] (worst direction)</text>')
    out.append(f'<text x="16" y="{H/2}" transform="rotate(-90 16 {H/2})" text-anchor="middle">utilisation</text>')
    for i, (name, ys) in enumerate(curves):
        pts = " ".join(f"{X(a):.1f},{Y(b):.1f}" for a, b in zip(x, ys))
        out.append(f'<polyline points="{pts}" fill="none" stroke="{colors[i % 5]}" stroke-width="2"/>')
        out.append(f'<rect x="{pad + 10}" y="{pad + 14*i}" width="10" height="3" fill="{colors[i % 5]}"/>'
                   f'<text x="{pad + 24}" y="{pad + 14*i + 5}">{name}</text>')
    out.append(f'<text x="{W-pad}" y="{H-8}" text-anchor="end" fill="#a33">SIMULATED (static model)</text></svg>')
    pathlib.Path(path).write_text("\n".join(out), encoding="utf-8")


def _finite(x):
    """Strict JSON: non-finite numbers (e.g. utilisation of a zero-hold surface) become null."""
    if isinstance(x, dict):
        return {k: _finite(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_finite(v) for v in x]
    if isinstance(x, (float, np.floating)):
        return float(x) if np.isfinite(x) else None
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.bool_):
        return bool(x)
    return x


def write_report(out_dir, rows, summary, energy, holding, longrun, seeds):
    out = pathlib.Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "runs.csv", "w", newline="", encoding="utf-8") as f:
        cols = [k for k in rows[0] if k not in ("findings", "events", "expect")]
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    payload = _finite(dict(label="SIMULATED", seeds=seeds, summary=summary, energy=energy, holding=holding,
                           long_duration=longrun, runs=rows))
    (out / "results.json").write_text(json.dumps(payload, indent=1, default=float, allow_nan=False), encoding="utf-8")
    if energy:
        tb = energy["table"]
        _svg_bars("Energy for a monitoring task (SIMULATED)", [f"{r['duration_h']} h" for r in tb],
                  [("continuous hover", [r["hover_wh"] for r in tb]), ("perching", [r["perch_wh"] for r in tb]),
                   ("conventional landing", [r["landed_wh"] for r in tb])], "Wh", out / "energy.svg")
    if holding:
        _svg_lines("Attachment utilisation vs wind (SIMULATED, static model)", holding[0]["winds"],
                   [(h["case"], h["utilisation_curve"]) for h in holding], out / "holding_vs_wind.svg")
    L = [f"# Perching UAV — validation report", "",
         f"Generated {dt.datetime.now().isoformat(timespec='seconds')}. **All results are SIMULATED** "
         f"(no physical measurements exist yet). Seeds per scenario: {seeds}. Wind per run: mean U(0, 4) m/s in a "
         f"random direction, turbulence sigma U(0.2, 1.0) m/s.", ""]
    if summary:
        L += ["## E1 — Monte-Carlo perching campaign", "",
              "| Scenario | Runs | As expected | Safe decline | Failure | Perched | Detached | Completed | Crashed | Aborts | Safety invariant | "
              "Median time to perch [s] | Median time to depart [s] | Min verified SF |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for k, s in summary.items():
            L.append(f"| {k} {s['title']} | {s['runs']} | {s['as_expected']} | {s['safe_decline']} | {s['failure']} | {s['perched']} | {s['detached']} | "
                     f"{s['completed']} | {s['crashed']} | {s['aborts']} | {'OK' if s['safety_invariant_ok'] else 'VIOLATED'} | "
                     f"{s['time_to_perch_s_median']} | {s['time_to_detach_s_median']} | {s['verified_sf_min']} |")
        L += ["", "Time to perch = FINAL_APPROACH entry -> SENSOR_MODE entry. Time to depart = last PRE_TAKEOFF_CHECK "
                  "entry -> AUTONOMOUS_MISSION_RESUMPTION. The safety invariant checks that propulsion was never "
                  "switched off without ATTACHMENT_VERIFICATION -> PROPULSION_REDUCTION.", ""]
        bad = [r for r in rows if not r["as_expected"]]
        if bad:
            L += ["### Runs that did not meet their expectation", ""]
            for r in bad:
                L.append(f"* [{r['outcome']}] {r['scenario']} seed {r['seed']} (wind {r['wind_mean']} m/s, turb {r['turbulence']}): final {r['final_state']}, "
                         f"crashed={r['crashed']}; findings: {'; '.join(r['findings'][-3:])}")
            L.append("")
    if energy:
        L += ["## E2 — Energy: hovering vs conventional landing vs perching", "",
              f"Battery {energy['pack_wh']} Wh, usable {energy['usable_wh']} Wh (20 % reserve). Simulated mean power: "
              f"hover {energy['hover_power_w']} W (3 m/s wind), perched {energy['perched_power_w']} W "
              f"(flight computer in low-power mode + sensor payload; EPM holds at 0 W). Perch manoeuvre "
              f"{energy['perch_manoeuvre_wh']} Wh, departure {energy['departure_wh']} Wh.", "",
              f"Endurance on station: hover {energy['hover_endurance_h']} h, perched {energy['perched_endurance_h']} h.", "",
              "| Duration | Hover [Wh] | Perch [Wh] | Landed [Wh] | Hover feasible | Perch feasible | Saving |",
              "|---|---|---|---|---|---|---|"]
        for r in energy["table"]:
            L.append(f"| {r['duration_h']} h | {r['hover_wh']} | {r['perch_wh']} | {r['landed_wh']} | "
                     f"{r['hover_feasible']} | {r['perch_feasible']} | {r['saving_pct']} % |")
        L += ["", "Conventional landing uses the same on-station power as perching but only offers a ground-level "
                  "vantage point; it is listed for energy only. ![energy](energy.svg)", ""]
    if holding:
        L += ["## E3 — Maximum supported wind (true capacity, worst direction)", "",
              "| Configuration | Wind at SF 2 [m/s] | Wind at failure [m/s] |", "|---|---|---|"]
        for h in holding:
            L.append(f"| {h['case']} | {h['wind_at_sf2_ms']} | {h['wind_at_failure_ms'] or '> 30'} |")
        L += ["", "Quasi-steady drag only (Cd*A = 0.09 m^2); gust dynamics, vortex shedding and structure vibration "
                  "are not modelled here. ![holding](holding_vs_wind.svg)", ""]
    if longrun:
        st = longrun["station"]
        L += [f"## E5 — Long-duration sensor mode ({longrun['hours']} h)", "",
              f"Outcome: {longrun['result']}", "",
              f"Station: {st['records']} records, {st['sent_bytes']/1e6:.2f} MB sent in {st['transmissions']} windows, "
              f"{st['dropped_records']} records dropped, final health {st['health']}.", "",
              f"Injected sensor faults -> detection latency [s]: {longrun['fault_detection_latency_s']}", "",
              "| Event | True time [h] | Detected | Latency [s] |", "|---|---|---|---|"]
        for e in longrun["events"]:
            L.append(f"| {e['kind']} | {e['t_true_h']} | {e['detected']} | {e['latency_s']} |")
        L += ["", "The gas event at 10 h is not detectable by design: the gas sensor was failed (dropout) at 6 h "
                  "and the health monitor flagged it 90 s later.", "", f"Last decisions: {longrun['decisions']}", ""]
    L += ["## What these results do and do not show", "",
          "* They exercise the full software stack in closed loop against a physics model whose parameters are "
          "ASSUMED (docs/perching/REQUIREMENTS.md lists each one). They are not evidence of real-world performance.",
          "* Holding forces come from a simple reluctance-gap model of the EPM and assumed friction coefficients; "
          "both must be measured on coupons of each target material before any flight test.",
          "* The material classifier is a surrogate with an assumed confusion structure, not a trained network."]
    (out / "REPORT.md").write_text("\n".join(L), encoding="utf-8")
    return out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument("--hours", type=float, default=12.0)
    ap.add_argument("--out", default="experiments/results")
    ap.add_argument("--skip", default="", help="comma list of e1,e2,e3,e5 to skip")
    a = ap.parse_args(argv)
    skip = set(a.skip.split(",")) if a.skip else set()
    rows, summary = e1_campaign(a.seeds, a.workers) if "e1" not in skip else ([{}], {})
    energy = e2_energy(rows) if "e2" not in skip else None
    holding = e3_holding_limits() if "e3" not in skip else None
    longrun = e5_long_duration(a.hours) if "e5" not in skip else None
    out = write_report(a.out, rows if rows and rows[0] else [{"scenario": None}], summary, energy, holding, longrun, a.seeds)
    print(f"report written to {out / 'REPORT.md'}")


if __name__ == "__main__":
    main()
