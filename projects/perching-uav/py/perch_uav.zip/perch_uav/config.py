"""Vehicle, battery and simulation-rate parameters.

All numbers are ASSUMED design values for a representative ~1.45 kg, 7-inch-propeller quadrotor
carrying a perching module. They are not measurements of a built vehicle; each one is listed in
docs/perching/REQUIREMENTS.md as a parameter to be measured in the hardware phase.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class VehicleParams:
    mass: float = 1.45                               # kg, incl. 0.12 kg perching module
    inertia: tuple = (0.016, 0.016, 0.028)           # kg m^2 (body principal axes)
    arm_length: float = 0.18                         # m, centre -> motor
    prop_radius: float = 0.089                       # m (7-inch)
    rotor_height: float = 0.03                       # m, rotor plane above CoM
    max_motor_thrust: float = 9.0                    # N per motor (T/W ~ 2.5)
    idle_motor_thrust: float = 0.15                  # N per motor when armed at idle
    motor_time_constant: float = 0.035               # s, first-order thrust lag
    torque_coefficient: float = 0.016                # m, yaw reaction torque / thrust
    drag_area: tuple = (0.045, 0.045, 0.090)         # Cd*A per body axis [m^2]
    rotational_damping: float = 0.004                # N m s/rad
    figure_of_merit: float = 0.60                    # rotor hover figure of merit
    powertrain_efficiency: float = 0.80              # ESC * motor
    avionics_power_w: float = 6.0                    # flight controller + companion computer (flight)
    # landing feet (body frame) and a coarse collision hull (box half-extents)
    feet: tuple = ((0.09, 0.09, -0.10), (-0.09, 0.09, -0.10), (-0.09, -0.09, -0.10), (0.09, -0.09, -0.10))
    hull_half: tuple = (0.07, 0.07, 0.035)


@dataclass(frozen=True)
class BatteryParams:
    cells: int = 4
    capacity_ah: float = 5.0
    internal_resistance: float = 0.035               # ohm (pack)
    cell_v_full: float = 4.20
    cell_v_empty: float = 3.30
    reserve_soc: float = 0.20                        # never planned below this


@dataclass(frozen=True)
class Rates:
    physics_dt: float = 0.002        # 500 Hz ground-truth integration
    control_div: int = 2             # attitude control + IMU at 250 Hz
    outer_div: int = 10              # position control, state machine at 50 Hz
    perception_div: int = 100        # depth perception at 5 Hz
    log_div: int = 25                # telemetry log at 20 Hz


@dataclass(frozen=True)
class SafetyLimits:
    min_safety_factor: float = 2.0                  # predicted holding / required load before perching
    min_verified_safety_factor: float = 1.8         # measured (flux-based) after contact
    max_contact_speed: float = 0.45                 # m/s normal speed at contact (pad rating)
    min_contact_speed: float = 0.05
    max_drift_during_load_transfer: float = 0.015   # m pad slip / body drift allowed
    max_departure_wind: float = 9.0                 # m/s mean wind for detachment
    max_perch_wind: float = 8.0
    departure_corridor_clearance: float = 1.2       # m radius checked for obstacles
    min_departure_soc: float = 0.30
    min_airborne_thrust_fraction: float = 0.70      # below this fraction of hover thrust needs a token


@dataclass
class SimConfig:
    vehicle: VehicleParams = field(default_factory=VehicleParams)
    battery: BatteryParams = field(default_factory=BatteryParams)
    rates: Rates = field(default_factory=Rates)
    safety: SafetyLimits = field(default_factory=SafetyLimits)
    seed: int = 0
