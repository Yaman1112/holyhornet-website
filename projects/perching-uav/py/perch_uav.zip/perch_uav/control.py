"""Flight control: geometric attitude control + three interchangeable position controllers.

Layering (all inputs are ESTIMATES):
    position controller (PID | LQR | MPC) -> desired acceleration a_d (world)
    thrust vectoring: F_d = m (a_d + g e3) -> (T, R_d) with tilt limit
    SO(3) attitude controller (Lee et al. 2010 form) -> body torque M
    mixer with saturation priority (thrust, roll/pitch, then yaw) -> motor thrusts

* PID: initial stabilisation and waypoint navigation.
* LQR: per-axis regulation [int e, e, e'] about hover (gains from the continuous ARE).
* MPC: per-axis linear MPC on the double integrator for approach and departure; input-box
  constraints solved exactly as a box-constrained QP with FISTA (accelerated projected gradient).
  The approach-speed limit at contact is imposed through the reference profile (reference governor).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .geom import GRAVITY, cross, unit, vee

SPIN = np.array([1.0, -1.0, 1.0, -1.0])


def solve_care(A, B, Q, R):
    """Continuous algebraic Riccati equation A'P + PA - PBR^-1B'P + Q = 0 via the stable invariant
    subspace of the Hamiltonian (NumPy only, so the engine also runs in the browser)."""
    n = A.shape[0]
    Ri = np.linalg.inv(R)
    H = np.block([[A, -B @ Ri @ B.T], [-Q, -A.T]])
    w, V = np.linalg.eig(H)
    Vs = V[:, w.real < 0]
    P = np.real(Vs[n:, :] @ np.linalg.inv(Vs[:n, :]))
    return 0.5 * (P + P.T)


class Mixer:
    def __init__(self, arm_length, torque_coefficient, f_max):
        a = arm_length / np.sqrt(2)
        xy = np.array([[a, a], [-a, a], [-a, -a], [a, -a]])
        self.A = np.vstack([np.ones(4), xy[:, 1], -xy[:, 0], SPIN * torque_coefficient])
        self.A_inv = np.linalg.inv(self.A)
        self.f_max = f_max

    def allocate(self, T, M, f_min=0.0):
        f_max = self.f_max
        T = float(np.clip(T, 4 * f_min, 4 * f_max))
        f = self.A_inv @ np.array([T, *M])
        if f.min() >= f_min - 1e-9 and f.max() <= f_max + 1e-9:
            return f
        for s in np.linspace(1, 0, 6):
            f = self.A_inv @ np.array([T, M[0], M[1], M[2] * s])
            if f.min() >= f_min and f.max() <= f_max:
                return f
        for s in np.linspace(1, 0, 11):
            f = self.A_inv @ np.array([T, M[0] * s, M[1] * s, 0.0])
            if f.min() >= f_min and f.max() <= f_max:
                return f
        return np.clip(f, f_min, f_max)


class AttitudeController:
    def __init__(self, J, kR=(2.3, 2.3, 0.5), kw=(0.30, 0.30, 0.20)):
        self.J = np.diag(J)
        self.kR, self.kw = np.array(kR), np.array(kw)

    def torque(self, R, w, R_d, w_d=np.zeros(3)):
        eR = 0.5 * vee(R_d.T @ R - R.T @ R_d)
        ew = w - R.T @ R_d @ w_d
        return -self.kR * eR - self.kw * ew + cross(w, self.J @ w)


def thrust_and_attitude(a_d, yaw_d, R, mass, max_tilt_deg=35.0, T_max=None):
    """Map a desired world acceleration to collective thrust and desired orientation."""
    F = mass * (np.asarray(a_d, float) + np.array([0.0, 0.0, GRAVITY]))
    F[2] = max(F[2], 0.2 * mass * GRAVITY)
    lim = np.tan(np.radians(max_tilt_deg)) * F[2]
    h = np.linalg.norm(F[:2])
    if h > lim:
        F[:2] *= lim / h
    b3 = unit(F)
    c1 = np.array([np.cos(yaw_d), np.sin(yaw_d), 0.0])
    b2 = unit(cross(b3, c1))
    b1 = cross(b2, b3)
    R_d = np.c_[b1, b2, b3]
    T = float(F @ R[:, 2])
    if T_max is not None:
        T = min(T, T_max)
    return max(T, 0.0), R_d


# --------------------------------------------------------------------------- position controllers
class PIDPosition:
    name = "PID"

    def __init__(self, kp=(3.0, 3.0, 4.0), kd=(3.0, 3.0, 3.5), ki=(0.4, 0.4, 0.8), a_max=4.0, i_max=1.5):
        self.kp, self.kd, self.ki = map(np.array, (kp, kd, ki))
        self.a_max, self.i_max = a_max, i_max
        self.i = np.zeros(3)

    def reset(self):
        self.i[:] = 0.0

    def __call__(self, p, v, p_ref, v_ref=np.zeros(3), a_ff=np.zeros(3), dt=0.02):
        e = p_ref - p
        self.i = np.clip(self.i + e * dt, -self.i_max, self.i_max)
        a = self.kp * e + self.kd * (v_ref - v) + self.ki * self.i + a_ff
        n = np.linalg.norm(a)
        return a if n <= self.a_max else a * self.a_max / n


class LQRPosition:
    """Per-axis LQR on x = [int e, e, e_dot] for the double integrator e_ddot = u."""
    name = "LQR"

    def __init__(self, q=(1.0, 12.0, 3.0), r=1.0, a_max=4.0):
        A = np.array([[0, 1, 0], [0, 0, 1], [0, 0, 0]], float)
        B = np.array([[0], [0], [1.0]])
        Q = np.diag(q)
        P = solve_care(A, B, Q, np.array([[r]]))
        self.K = (B.T @ P / r).ravel()        # u = -K x
        self.a_max = a_max
        self.i = np.zeros(3)

    def reset(self):
        self.i[:] = 0.0

    def __call__(self, p, v, p_ref, v_ref=np.zeros(3), a_ff=np.zeros(3), dt=0.02):
        e = p - p_ref
        ed = v - v_ref
        self.i = np.clip(self.i + e * dt, -2.0, 2.0)
        a = -(self.K[0] * self.i + self.K[1] * e + self.K[2] * ed) + a_ff
        n = np.linalg.norm(a)
        return a if n <= self.a_max else a * self.a_max / n


class MPCPosition:
    """Linear MPC per axis: x = [pos, vel], u = acceleration, horizon N, step h.

    min sum_k (x_k - x_ref,k)' Q (x_k - x_ref,k) + R u_k^2 + R_d (u_k - u_{k-1})^2,  |u_k| <= u_max
    Condensed to a box-constrained QP in U and solved with FISTA (warm-started).
    """
    name = "MPC"

    def __init__(self, N=25, h=0.04, q_pos=30.0, q_vel=6.0, r=0.4, r_d=0.8, u_max=(3.0, 3.0, 3.0), iters=40):
        self.N, self.h = N, h
        A = np.array([[1, h], [0, 1]])
        B = np.array([[0.5 * h * h], [h]])
        # prediction matrices X = Phi x0 + Gam U
        Phi = np.zeros((2 * N, 2))
        Gam = np.zeros((2 * N, N))
        Ak = np.eye(2)
        for k in range(N):
            Ak = A @ Ak
            Phi[2 * k:2 * k + 2] = Ak
            for j in range(k + 1):
                Gam[2 * k:2 * k + 2, j:j + 1] = np.linalg.matrix_power(A, k - j) @ B
        Q = np.kron(np.eye(N), np.diag([q_pos, q_vel]))
        D = np.eye(N) - np.eye(N, k=-1)
        self.H = Gam.T @ Q @ Gam + r * np.eye(N) + r_d * D.T @ D
        self.Phi, self.Gam, self.Q, self.D, self.r_d = Phi, Gam, Q, D, r_d
        self.L = float(np.max(np.linalg.eigvalsh(self.H)))
        self.u_max = np.array(u_max)
        self.iters = iters
        self.U = np.zeros((3, N))
        self.last_cost = np.zeros(3)

    def reset(self):
        self.U[:] = 0.0

    def solve_axis(self, ax, x0, Xref, u_prev):
        f = self.Gam.T @ self.Q @ (self.Phi @ x0 - Xref)
        e0 = np.zeros(self.N)
        e0[0] = 1.0
        f = f - self.r_d * u_prev * (self.D.T @ e0)
        U = np.r_[self.U[ax, 1:], self.U[ax, -1]]
        Y, t = U.copy(), 1.0
        lim = self.u_max[ax]
        for _ in range(self.iters):
            U_new = np.clip(Y - (self.H @ Y + f) / self.L, -lim, lim)
            t_new = 0.5 * (1 + np.sqrt(1 + 4 * t * t))
            Y = U_new + (t - 1) / t_new * (U_new - U)
            U, t = U_new, t_new
        self.U[ax] = U
        self.last_cost[ax] = 0.5 * U @ self.H @ U + f @ U
        return U[0]

    def __call__(self, p, v, ref_traj, a_prev=np.zeros(3)):
        """ref_traj: (N, 6) array of [p_ref, v_ref] for the horizon."""
        a = np.zeros(3)
        for ax in range(3):
            Xref = np.c_[ref_traj[:, ax], ref_traj[:, 3 + ax]].ravel()
            a[ax] = self.solve_axis(ax, np.array([p[ax], v[ax]]), Xref, a_prev[ax])
        return a


def approach_reference(r0_n, n, N, h, v_cruise, v_contact, a_max, push_depth=0.0):
    """Reference for the final approach expressed relative to the target point.

    Normal distance follows v(d) = min(v_cruise, sqrt(v_contact^2 + 2 a d)) so that the vehicle
    arrives at d = 0 with speed v_contact (the pad's rated contact speed); tangential offsets go to 0.
    Returns (N, 6) [r_ref, v_ref] in world axes, relative to the target.
    """
    out = np.zeros((N, 6))
    d = r0_n
    for k in range(N):
        vmag = min(v_cruise, np.sqrt(v_contact ** 2 + 2 * a_max * max(d, 0.0)))
        if d <= -push_depth:
            vmag = 0.0
        d = d - vmag * h
        d = max(d, -push_depth)
        out[k, :3] = d * n
        out[k, 3:] = -vmag * n
    return out
