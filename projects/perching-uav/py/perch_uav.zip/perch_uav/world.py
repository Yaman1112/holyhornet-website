"""Ground-truth world: surfaces with explicit material, compatibility and load-bearing properties,
moving obstacles, wind/turbulence and the ambient environment sensed in sensor mode.

Only the simulator and the sensor models read this module. The autonomy stack never does.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .geom import orthonormal_basis, unit

from .materials import MATERIALS


@dataclass
class Surface:
    """A plane patch (`kind="plane"`) or a finite cylinder (`kind="cylinder"`).

    Plane: `center`, outward `normal`, `half_extents` (along u, w), `thickness` behind the face.
    Cylinder: `center` (mid-axis point), `axis`, `radius`, `length`.

    Attachment-relevant truth: `material`, `coating_mm` (paint/rust gap), `steel_thickness_mm`,
    `max_load_n` (what the structure can actually carry at an attachment point).
    What a site survey/structural database *declares* is kept separately
    (`declared_coating_mm`, `declared_max_load_n`) because it can be wrong or missing.
    """
    id: str
    kind: str
    material: str
    center: tuple
    normal: tuple = (0.0, 0.0, 1.0)
    half_extents: tuple = (0.5, 0.5)
    thickness: float = 0.01
    axis: tuple = (0.0, 1.0, 0.0)
    radius: float = 0.02
    length: float = 1.0
    coating_mm: float = 0.0
    steel_thickness_mm: float = 5.0
    roughness_mm: float = 0.05
    max_load_n: float = 1000.0
    declared_coating_mm: float | None = None
    declared_max_load_n: float | None = None
    temperature_c: float | None = None
    coating_visible: bool = True       # False: corrosion hidden under intact-looking paint
    label: str = ""

    def __post_init__(self):
        self.c = np.array(self.center, float)
        if self.kind == "plane":
            self.n = unit(np.array(self.normal, float))
            self.u, self.w = orthonormal_basis(self.n)
        elif self.kind == "cylinder":
            self.a = unit(np.array(self.axis, float))
        else:
            raise ValueError(self.kind)
        if self.declared_coating_mm is None:
            self.declared_coating_mm = self.coating_mm
        if self.declared_max_load_n is None:
            self.declared_max_load_n = self.max_load_n
        if self.material not in MATERIALS:
            raise ValueError(f"unknown material {self.material}")

    @property
    def props(self) -> dict:
        return MATERIALS[self.material]

    # ------------------------------------------------------------ contact query
    def penetration(self, x: np.ndarray, side: int | None = None):
        """(depth > 0, outward normal, side) if point x is inside the solid, else None.

        For plates, `side` (+1 front, -1 back) is the face the contact started on; contacts keep
        their side so that a compliant pad pressing deeper than half the plate thickness is not
        pushed out through the back face."""
        d = x - self.c
        if self.kind == "plane":
            s = float(self.n @ d)
            if s >= 0.0 or s <= -self.thickness:
                return None
            if abs(self.u @ d) > self.half_extents[0] or abs(self.w @ d) > self.half_extents[1]:
                return None
            if side is None:
                side = 1 if s > -0.5 * self.thickness else -1
            if side > 0:
                return -s, self.n, 1
            return self.thickness + s, -self.n, -1
        ax = float(self.a @ d)
        if abs(ax) > 0.5 * self.length:
            return None
        r = d - ax * self.a
        rho = float(np.linalg.norm(r))
        if isinstance(side, np.ndarray):
            # contact already established: keep its normal so a deep (compliant) contact cannot pass
            # the axis and flip direction; depth is measured along the original normal
            if rho >= self.radius:
                return None
            depth = self.radius - float(r @ side)
            return (depth, side, side) if depth > 0 else None
        if rho >= self.radius or rho < 1e-9:
            return None
        n = r / rho
        return self.radius - rho, n, n

    def outward_normal_at(self, x: np.ndarray) -> np.ndarray:
        if self.kind == "plane":
            return self.n
        d = x - self.c
        r = d - (self.a @ d) * self.a
        return unit(r)

    def signed_distance(self, x: np.ndarray) -> float:
        """Approximate signed distance to the surface (inf if outside the patch footprint)."""
        d = x - self.c
        if self.kind == "plane":
            if abs(self.u @ d) > self.half_extents[0] + 0.05 or abs(self.w @ d) > self.half_extents[1] + 0.05:
                return np.inf
            return float(self.n @ d)
        ax = float(self.a @ d)
        if abs(ax) > 0.5 * self.length + 0.05:
            return np.inf
        return float(np.linalg.norm(d - ax * self.a)) - self.radius

    # ------------------------------------------------------------ ray casting
    def raycast(self, o: np.ndarray, D: np.ndarray) -> np.ndarray:
        """Distances along unit rays D (N,3) from origin o; inf where there is no hit."""
        t = np.full(len(D), np.inf)
        if self.kind == "plane":
            for face_c, face_n in ((self.c, self.n), (self.c - self.thickness * self.n, -self.n)):
                dn = D @ face_n
                with np.errstate(divide="ignore", invalid="ignore"):
                    tt = (face_n @ (face_c - o)) / dn
                hit = (dn < -1e-9) & (tt > 0)
                P = o + D * np.where(hit, tt, 0.0)[:, None]
                rel = P - face_c
                hit &= (np.abs(rel @ self.u) <= self.half_extents[0]) & (np.abs(rel @ self.w) <= self.half_extents[1])
                t = np.where(hit & (tt < t), tt, t)
            return t
        oc = o - self.c
        Dp = D - np.outer(D @ self.a, self.a)
        ocp = oc - (oc @ self.a) * self.a
        A = np.einsum("ij,ij->i", Dp, Dp)
        B = 2 * Dp @ ocp
        C = ocp @ ocp - self.radius ** 2
        disc = B * B - 4 * A * C
        ok = (disc >= 0) & (A > 1e-12)
        sq = np.sqrt(np.where(ok, disc, 0.0))
        with np.errstate(divide="ignore", invalid="ignore"):
            t1 = (-B - sq) / (2 * A)
        P = o + D * np.where(ok, t1, 0.0)[:, None]
        ax = (P - self.c) @ self.a
        hit = ok & (t1 > 0) & (np.abs(ax) <= 0.5 * self.length)
        return np.where(hit, t1, t)


def ground(z: float = 0.0, material: str = "concrete") -> Surface:
    return Surface("ground", "plane", material, (0.0, 0.0, z), (0, 0, 1), (500.0, 500.0), thickness=1.0,
                   max_load_n=1e6, label="ground")


@dataclass
class MovingObstacle:
    """Sphere moving back and forth between a and b (e.g. a bird, another drone, a crane hook)."""
    id: str
    a: tuple
    b: tuple
    radius: float = 0.3
    period: float = 20.0
    t_start: float = 0.0
    t_end: float = 1e9

    def position(self, t: float) -> np.ndarray | None:
        if t < self.t_start or t > self.t_end:
            return None
        ph = ((t - self.t_start) / self.period) % 1.0
        s = 2 * ph if ph < 0.5 else 2 - 2 * ph
        return np.array(self.a, float) + s * (np.array(self.b, float) - np.array(self.a, float))

    def raycast(self, t: float, o, D):
        c = self.position(t)
        out = np.full(len(D), np.inf)
        if c is None:
            return out
        oc = o - c
        B = 2 * D @ oc
        C = oc @ oc - self.radius ** 2
        disc = B * B - 4 * C
        ok = disc >= 0
        t1 = (-B - np.sqrt(np.where(ok, disc, 0))) / 2
        return np.where(ok & (t1 > 0), t1, out)


@dataclass
class WindModel:
    """Mean wind + first-order Gauss-Markov turbulence (Dryden-like, one pole per axis) + gust events.

    gust_events: list of (t_start, duration, peak vector) with a 1-cosine profile.
    """
    mean: tuple = (0.0, 0.0, 0.0)
    turbulence_std: float = 0.0
    length_scale: float = 30.0
    gust_events: list = field(default_factory=list)

    def __post_init__(self):
        self.turb = np.zeros(3)

    def reset(self):
        self.turb = np.zeros(3)

    def step(self, t: float, dt: float, rng: np.random.Generator) -> np.ndarray:
        m = np.array(self.mean, float)
        if self.turbulence_std > 0:
            tau = self.length_scale / max(np.linalg.norm(m), 1.0)
            a = np.exp(-dt / tau)
            self.turb = a * self.turb + self.turbulence_std * np.sqrt(1 - a * a) * rng.standard_normal(3)
        return m + self.turb + self.gust(t)

    def gust(self, t: float) -> np.ndarray:
        g = np.zeros(3)
        for t0, dur, peak in self.gust_events:
            if t0 <= t <= t0 + dur:
                g += 0.5 * (1 - np.cos(2 * np.pi * (t - t0) / dur)) * np.array(peak, float)
        return g

    def mean_speed(self) -> float:
        return float(np.linalg.norm(self.mean))


@dataclass
class AmbientModel:
    """True ambient conditions at the perch site (what sensor mode measures)."""
    temp_mean_c: float = 15.0
    temp_amplitude_c: float = 6.0
    humidity_mean: float = 60.0
    acoustic_base_dba: float = 45.0
    acoustic_events: list = field(default_factory=list)       # (t, duration, dBA)
    vibration_base_ms2: float = 0.02
    vibration_events: list = field(default_factory=list)      # (t, duration, m/s^2 rms)
    hotspots: list = field(default_factory=list)              # (t_start, t_end, deg C)
    gas_ppm_base: float = 420.0                                # CO2
    gas_events: list = field(default_factory=list)            # (t, duration, ppm)
    light_lux_peak: float = 50000.0
    start_hour: float = 8.0

    def hour(self, t):
        return (self.start_hour + t / 3600.0) % 24.0

    def temperature(self, t):
        return self.temp_mean_c + self.temp_amplitude_c * np.sin(2 * np.pi * (self.hour(t) - 9.0) / 24.0)

    def humidity(self, t):
        return float(np.clip(self.humidity_mean - 2.5 * (self.temperature(t) - self.temp_mean_c), 5, 100))

    def light(self, t):
        h = self.hour(t)
        return float(max(0.0, np.sin(np.pi * (h - 6.0) / 12.0)) * self.light_lux_peak) if 6 <= h <= 18 else 0.0

    def _event(self, evs, t):
        return max((v for t0, d, v in evs if t0 <= t <= t0 + d), default=None)

    def acoustic(self, t):
        e = self._event(self.acoustic_events, t)
        return self.acoustic_base_dba if e is None else max(self.acoustic_base_dba, e)

    def vibration(self, t):
        e = self._event(self.vibration_events, t)
        return self.vibration_base_ms2 if e is None else max(self.vibration_base_ms2, e)

    def thermal_max(self, t):
        hs = [v for a, b, v in self.hotspots if a <= t <= b]
        return max([self.temperature(t) + 3.0, *hs])

    def gas(self, t):
        e = self._event(self.gas_events, t)
        return self.gas_ppm_base if e is None else self.gas_ppm_base + e


@dataclass
class World:
    surfaces: list
    obstacles: list = field(default_factory=list)
    wind: WindModel = field(default_factory=WindModel)
    ambient: AmbientModel = field(default_factory=AmbientModel)
    illumination: float = 1.0          # 0 (dark) .. 1 (daylight); degrades perception
    indoor: bool = False

    def surface(self, sid: str) -> Surface:
        for s in self.surfaces:
            if s.id == sid:
                return s
        raise KeyError(sid)

    def raycast(self, t, o, D):
        best = np.full(len(D), np.inf)
        ids = np.full(len(D), -1)
        for i, s in enumerate(self.surfaces):
            tt = s.raycast(o, D)
            m = tt < best
            best[m], ids[m] = tt[m], i
        for j, ob in enumerate(self.obstacles):
            tt = ob.raycast(t, o, D)
            m = tt < best
            best[m], ids[m] = tt[m], 1000 + j
        return best, ids
