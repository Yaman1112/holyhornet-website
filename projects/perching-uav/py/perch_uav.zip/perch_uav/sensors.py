"""Sensor models: the ONLY bridge from ground truth (dynamics/world) to the autonomy stack.

Every function returns a message dataclass; messages carry measurements only, never truth.
Noise figures are representative of the named sensor class (ASSUMED, see REQUIREMENTS.md).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .dynamics import VehicleSim
from .geom import rot_y, rot_z, unit, yaw_of
from .materials import MATERIAL_NAMES

# --------------------------------------------------------------------------- messages


@dataclass
class ImuMsg:
    t: float
    gyro: np.ndarray
    accel: np.ndarray


@dataclass
class PositionMsg:
    t: float
    p: np.ndarray
    sigma: np.ndarray
    yaw: float
    yaw_sigma: float
    source: str


@dataclass
class DepthMsg:
    t: float
    sensor: str
    points_b: np.ndarray        # (N, 3) body-frame points
    max_range: float
    pix: np.ndarray = None      # (N, 2) image (col, row) of each point
    res: tuple = (0, 0)
    _truth_ids: np.ndarray = None   # simulator-side labels; NOT for autonomy (used by the harness
                                    # only to synthesise the material-classifier image crop)


@dataclass
class PadMsg:
    t: float
    contact: bool                # end-effector contact switch
    tof_range: float             # proximity sensor along the pad direction [m] (inf = no return)
    load_n: float                # boom load cell, compression positive [N]
    flux_ratio: float            # EPM: estimated holding / nominal; claw: closure (1 = fully closed)
    slip_mm: float               # optical slip sensor at the pad
    mech_state: str              # reported mechanism state (open/engaging/engaged/releasing)
    wrist_locked: bool


@dataclass
class EscMsg:
    t: float
    rpm: np.ndarray
    rpm_expected: np.ndarray


@dataclass
class BatteryMsg:
    t: float
    voltage: float
    current: float
    soc: float


@dataclass
class AnemometerMsg:
    t: float
    wind: np.ndarray             # world-frame wind estimate
    sigma: float


@dataclass
class MaterialMsg:
    t: float
    probs: dict                  # class -> probability (visual classifier output)
    rust_flag: bool              # visual detection of heavy coating/corrosion


# --------------------------------------------------------------------------- suite
@dataclass
class SensorSpec:
    position_source: str = "rtk"           # rtk | gnss | vio
    depth_res: tuple = (64, 48)
    depth_fov_deg: tuple = (87.0, 58.0)
    depth_range: float = 6.0
    front_cam_pitch_deg: float = -15.0
    imu_gyro_sigma: float = 0.003
    imu_accel_sigma: float = 0.04
    flux_sigma: float = 0.03


POSITION_SIGMAS = {"rtk": (0.02, 0.03, 0.005), "gnss": (0.10, 0.15, 0.5), "vio": (0.03, 0.03, 0.01)}
# (white sigma horizontal, white sigma vertical, correlated (Gauss-Markov, tau 60 s) sigma)


class SensorSuite:
    def __init__(self, sim: VehicleSim, spec: SensorSpec | None = None, rng: np.random.Generator | None = None):
        self.sim = sim
        self.spec = spec or SensorSpec()
        self.rng = rng or np.random.default_rng(1)
        self.gyro_bias = self.rng.normal(0, 0.004, 3)
        self.accel_bias = self.rng.normal(0, 0.06, 3)
        self.pos_bias = np.zeros(3)
        nx, ny = self.spec.depth_res
        hf, vf = np.radians(self.spec.depth_fov_deg)
        az = np.linspace(-hf / 2, hf / 2, nx)
        el = np.linspace(-vf / 2, vf / 2, ny)
        A, E = np.meshgrid(az, el)
        # camera frame: x forward, y left, z up (FLU-aligned optical model)
        dirs = np.stack([np.cos(E) * np.cos(A), np.cos(E) * np.sin(A), np.sin(E)], -1).reshape(-1, 3)
        self.cam_dirs = dirs
        self.cams = {
            "front": (rot_y(-np.radians(self.spec.front_cam_pitch_deg)), np.array([0.10, 0.0, 0.0])),
            "down": (rot_y(np.pi / 2), np.array([0.0, 0.0, -0.05])),
            "rear": (rot_z(np.pi) @ rot_y(-np.radians(self.spec.front_cam_pitch_deg)), np.array([-0.10, 0.0, 0.0])),
        }
        self.slip_bias = 0.0

    # ------------------------------------------------------------------ inertial
    def imu(self) -> ImuMsg:
        s, sp = self.sim.s, self.spec
        dt = 0.004
        self.gyro_bias += self.rng.normal(0, 2e-5, 3) * np.sqrt(dt)
        vib = 0.0
        if self.sim.armed:
            vib = 0.15 * float(np.mean(s.f)) / 3.6     # propeller vibration on the accelerometer
        sf, w = self.sim.imu_sample()
        gyro = w + self.gyro_bias + self.rng.normal(0, sp.imu_gyro_sigma, 3)
        acc = sf + self.accel_bias + self.rng.normal(0, sp.imu_accel_sigma + vib, 3)
        return ImuMsg(self.sim.t, gyro, acc)

    def position(self, dt: float) -> PositionMsg:
        sh, sv, sc = POSITION_SIGMAS[self.spec.position_source]
        a = np.exp(-dt / 60.0)
        self.pos_bias = a * self.pos_bias + sc * np.sqrt(1 - a * a) * self.rng.standard_normal(3)
        sig = np.array([sh, sh, sv])
        p = self.sim.s.p + self.pos_bias + self.rng.normal(0, 1, 3) * sig
        ys = np.radians(1.0 if self.spec.position_source != "gnss" else 3.0)
        yaw = yaw_of(self.sim.s.R) + self.rng.normal(0, ys)
        return PositionMsg(self.sim.t, p, np.sqrt(sig ** 2 + sc ** 2), yaw, ys, self.spec.position_source)

    # ------------------------------------------------------------------ exteroceptive
    def depth(self, cam: str) -> DepthMsg:
        s = self.sim.s
        R_bc, t_bc = self.cams[cam]
        D_b = self.cam_dirs @ R_bc.T
        D_w = D_b @ s.R.T
        o = s.p + s.R @ t_bc
        t, ids = self.sim.world.raycast(self.sim.t, o, D_w)
        illum = self.sim.world.illumination
        ok = np.isfinite(t) & (t > 0.2) & (t < self.spec.depth_range)
        ok &= self.rng.random(len(t)) > (0.03 + 0.25 * (1 - illum))
        tt = t[ok]
        sigma = (0.001 + 0.0025 * tt ** 2) * (1 + 2 * (1 - illum))
        tt = tt + self.rng.normal(0, 1, len(tt)) * sigma
        pts = t_bc + D_b[ok] * tt[:, None]
        nx, ny = self.spec.depth_res
        idx = np.nonzero(ok)[0]
        pix = np.c_[idx % nx, idx // nx]
        return DepthMsg(self.sim.t, cam, pts, self.spec.depth_range, pix, (nx, ny), ids[ok])

    def pad(self) -> PadMsg:
        sim = self.sim
        m = sim.mech
        tip = sim.tip_world()
        d_w = sim.s.R @ np.array(m.boom.direction)
        t, _ = sim.world.raycast(sim.t, tip - 0.03 * d_w, d_w.reshape(1, 3))
        tof = float(t[0]) - 0.03
        tof = tof + self.rng.normal(0, 0.003) if np.isfinite(tof) and tof < 0.5 else np.inf
        contact = sim.tip_contact is not None and sim.tip_contact[1] > 0.001
        load = 0.0
        if sim.tip_contact is not None:
            surf, depth, n = sim.tip_contact
            mp = m.params
            load = mp.pad_spring * min(depth, m.boom.travel) + (2e4 * (depth - m.boom.travel) if depth > m.boom.travel else 0)
        at = sim.attachment
        if at is not None:
            load = float(at.last_F @ at.n)        # compression positive
        load += self.rng.normal(0, 0.3)
        if m.is_epm:
            flux = 0.0
            if m.state == "engaged" and at is not None:
                flux = at.capacity.total_normal / (m.params.n_magnets * m.params.nominal_force)
            elif m.state == "engaged":
                flux = 0.0
            flux = max(0.0, flux + self.rng.normal(0, self.spec.flux_sigma))
        else:
            flux = 1.0 if (m.state == "engaged" and at is not None) else (0.4 if m.state == "engaged" else 0.0)
        slip = (at.slip * 1000 if at is not None else 0.0) + self.rng.normal(0, 0.3)
        return PadMsg(sim.t, contact, tof, load, flux, slip, m.state, m.wrist_locked)

    def esc(self) -> EscMsg:
        s = self.sim
        k = 1200.0
        rpm = k * np.sqrt(np.maximum(s.s.f, 0)) + self.rng.normal(0, 20, 4)
        exp = k * np.sqrt(np.maximum(s.f_cmd, 0)) if s.armed else np.zeros(4)
        return EscMsg(s.t, rpm, exp)

    def battery(self) -> BatteryMsg:
        b = self.sim.battery
        return BatteryMsg(self.sim.t, b.voltage + self.rng.normal(0, 0.02), b.current + self.rng.normal(0, 0.1),
                          float(np.clip(b.soc * 1.0 + self.rng.normal(0, 0.005), 0, 1)))

    def anemometer(self) -> AnemometerMsg:
        sim = self.sim
        perched = not sim.armed or float(np.mean(sim.s.f)) < 0.5
        sig = 0.3 if perched else 1.5
        return AnemometerMsg(sim.t, sim.wind + self.rng.normal(0, sig, 3), sig)

    def material(self, surface_id: str) -> MaterialMsg:
        """Surrogate for an RGB/thermal material classifier (NOT a trained model).

        Metals are visually confusable with each other (notably 304 vs 430 stainless and aluminium);
        accuracy drops in poor light. The magnetic check at contact is the authoritative test.
        """
        surf = self.sim.world.surface(surface_id)
        illum = self.sim.world.illumination
        metals = ["mild_steel", "painted_steel", "cast_iron", "stainless_430", "stainless_304", "aluminium"]
        acc = 0.55 + 0.30 * illum
        probs = {m: 0.0 for m in MATERIAL_NAMES}
        group = metals if surf.material in metals else [surf.material]
        probs[surf.material] += acc
        rest = [m for m in (group if len(group) > 1 else MATERIAL_NAMES) if m != surf.material]
        w = self.rng.dirichlet(np.ones(len(rest)))
        for m_, wi in zip(rest, w):
            probs[m_] += (1 - acc) * wi
        rust = surf.coating_mm > 0.4 and surf.coating_visible and self.rng.random() < 0.3
        return MaterialMsg(self.sim.t, probs, bool(rust))


@dataclass
class AmbientReading:
    t: float
    values: dict
    flags: dict = field(default_factory=dict)


class AmbientSensors:
    """Payload sensors used in sensor mode, with noise, drift and injectable faults."""

    SPECS = {
        "temperature": dict(sigma=0.2, drift_per_h=0.01, lo=-40, hi=85, power_w=0.01),
        "humidity": dict(sigma=1.5, drift_per_h=0.05, lo=0, hi=100, power_w=0.01),
        "acoustic": dict(sigma=1.0, drift_per_h=0.0, lo=30, hi=130, power_w=0.15),
        "vibration": dict(sigma=0.005, drift_per_h=0.0, lo=0, hi=50, power_w=0.05),
        "visual": dict(sigma=0.0, drift_per_h=0.0, lo=0, hi=1, power_w=2.0),
        "thermal": dict(sigma=0.5, drift_per_h=0.02, lo=-20, hi=400, power_w=1.0),
        "gas": dict(sigma=15.0, drift_per_h=2.0, lo=0, hi=5000, power_w=0.3),
    }

    def __init__(self, sim: VehicleSim, rng: np.random.Generator):
        self.sim = sim
        self.rng = rng
        self.faults: dict[str, tuple] = {}     # name -> (kind, t_start) kind: stuck | dropout | spike
        self._last: dict[str, float] = {}

    def inject(self, name: str, kind: str, t_start: float):
        self.faults[name] = (kind, t_start)

    def read(self, name: str, t: float, self_heating_c: float = 0.0):
        amb = self.sim.world.ambient
        spec = self.SPECS[name]
        truth = {
            "temperature": lambda: amb.temperature(t) + self_heating_c,
            "humidity": lambda: amb.humidity(t),
            "acoustic": lambda: amb.acoustic(t),
            "vibration": lambda: amb.vibration(t),
            "visual": lambda: amb.light(t) / max(amb.light_lux_peak, 1),
            "thermal": lambda: amb.thermal_max(t),
            "gas": lambda: amb.gas(t),
        }[name]()
        v = truth + spec["drift_per_h"] * t / 3600.0 + self.rng.normal(0, spec["sigma"])
        f = self.faults.get(name)
        if f and t >= f[1]:
            if f[0] == "stuck":
                v = self._last.get(name, v)
            elif f[0] == "dropout":
                return None
            elif f[0] == "spike":
                v = spec["hi"] * 1.5
        self._last[name] = v
        return float(v)
