"""Explainable decision layer (rule- and utility-based; no learned model).

It answers: whether/where/when to perch, which sensing mode, when to conserve energy, when to
detach and whether the mission can continue. Every answer is a `Decision` with the reasons and the
numbers used. Decisions are advisory: `SafetyGuard.vet` runs on each one, and the state machine
alone commands actuators.
"""

from __future__ import annotations

import numpy as np

from .safety import Decision


class EnergyModel:
    """Power figures the planner uses (from the same models as the simulator, labelled ESTIMATED)."""

    def __init__(self, hover_power_w=240.0, cruise_power_w=260.0, perched_power_w=3.0, cruise_speed=3.0):
        self.hover = hover_power_w
        self.cruise = cruise_power_w
        self.perched = perched_power_w
        self.speed = cruise_speed

    def flight_j(self, distance_m, extra_s=0.0):
        return self.cruise * distance_m / self.speed + self.hover * extra_s


class DecisionLayer:
    def __init__(self, energy: EnergyModel, reserve_soc=0.2, capacity_j=266_400.0):
        self.E = energy
        self.reserve_soc = reserve_soc
        self.capacity_j = capacity_j
        self.history: list[Decision] = []

    def _log(self, d):
        self.history.append(d)
        return d

    def usable_j(self, soc):
        return max(0.0, (soc - self.reserve_soc) * self.capacity_j)

    # ------------------------------------------------------------------ where / whether to perch
    def choose_target(self, reports, soc, monitor_s, dist_home_m, t=0.0) -> Decision:
        usable = self.usable_j(soc)
        return_j = self.E.flight_j(dist_home_m, extra_s=20)
        suitable = sorted([r for r in reports if r.suitable], key=lambda r: -r.score)
        rejected = [r for r in reports if not r.suitable]
        inputs = dict(soc=round(soc, 3), usable_j=round(usable), return_j=round(return_j), monitor_s=monitor_s,
                      n_candidates=len(reports), n_suitable=len(suitable))
        reasons = [r.summary for r in rejected]
        if suitable:
            best = suitable[0]
            perch_j = self.E.hover * 45 + self.E.perched * monitor_s + self.E.hover * 20
            hover_j = self.E.hover * monitor_s
            reasons.append(f"best candidate {best.candidate_id}: score {best.score:.2f}, SF {best.predicted_sf:.2f}")
            reasons.append(f"perch energy ~{perch_j/1000:.1f} kJ vs hover {hover_j/1000:.1f} kJ for {monitor_s:.0f} s")
            if perch_j + return_j > usable:
                reasons.append("not enough usable energy for perching + return: return home")
                return self._log(Decision("return_home", reasons, inputs))
            return self._log(Decision("perch", reasons, inputs, target=best.candidate_id))
        hover_j = self.E.hover * monitor_s
        inputs["hover_energy_j"] = round(hover_j)
        if hover_j + return_j <= usable:
            reasons.append(f"no suitable perch; hover monitoring needs {hover_j/1000:.1f} kJ of {usable/1000:.1f} kJ usable")
            return self._log(Decision("hover_monitor", reasons, inputs))
        reasons.append("no suitable perch and hovering would breach the reserve: return home")
        return self._log(Decision("return_home", reasons, inputs))

    # ------------------------------------------------------------------ sensing mode
    def sensing_mode(self, soc, hours_remaining_planned, event_active, t=0.0) -> Decision:
        reasons = []
        if soc < self.reserve_soc + 0.05:
            reasons.append(f"SoC {soc:.2f} close to reserve {self.reserve_soc:.2f}: essential sensors only")
            return self._log(Decision("mode_critical", reasons, dict(soc=soc)))
        if event_active:
            reasons.append("acoustic/vibration/thermal event active: full-rate capture")
            return self._log(Decision("mode_normal", reasons, dict(soc=soc)))
        budget_h = self.usable_j(soc) / 3600.0 / max(self.E.perched, 0.1)
        if budget_h < 1.5 * hours_remaining_planned:
            reasons.append(f"energy budget {budget_h:.1f} h < 1.5 x planned {hours_remaining_planned:.1f} h: eco mode")
            return self._log(Decision("mode_eco", reasons, dict(soc=soc, budget_h=budget_h)))
        reasons.append("energy budget comfortable: normal mode")
        return self._log(Decision("mode_normal", reasons, dict(soc=soc, budget_h=budget_h)))

    # ------------------------------------------------------------------ when to detach
    def should_detach(self, t_perched, monitor_s, soc, dist_next_m, dist_home_m, wind, holding_sf_now,
                      attachment_ok=True, t=0.0) -> Decision:
        reasons = []
        need_j = self.E.flight_j(dist_next_m + dist_home_m, extra_s=60)
        usable = self.usable_j(soc)
        inputs = dict(t_perched=round(t_perched), monitor_s=monitor_s, soc=round(soc, 3), need_j=round(need_j),
                      usable_j=round(usable), wind=round(wind, 1), sf_now=round(holding_sf_now, 2))
        if not attachment_ok:
            reasons.append("attachment health degraded")
            return self._log(Decision("detach", reasons, inputs))
        if usable < 1.3 * need_j:
            reasons.append(f"usable energy {usable/1000:.1f} kJ < 1.3 x remaining mission {need_j/1000:.1f} kJ")
            return self._log(Decision("detach", reasons, inputs))
        if holding_sf_now < 1.5:
            reasons.append(f"holding SF in current wind {holding_sf_now:.2f} < 1.5")
            return self._log(Decision("detach", reasons, inputs))
        if t_perched >= monitor_s:
            reasons.append(f"monitoring period complete ({t_perched:.0f}/{monitor_s:.0f} s)")
            return self._log(Decision("detach", reasons, inputs))
        reasons.append("continue monitoring")
        return Decision("stay", reasons, inputs)

    def continue_mission(self, soc, dist_remaining_m, dist_home_m) -> Decision:
        need = self.E.flight_j(dist_remaining_m + dist_home_m, extra_s=60)
        usable = self.usable_j(soc)
        ok = usable >= need
        return self._log(Decision("continue" if ok else "return_home",
                                  [f"usable {usable/1000:.1f} kJ vs needed {need/1000:.1f} kJ"],
                                  dict(soc=soc, need_j=need, usable_j=usable)))
