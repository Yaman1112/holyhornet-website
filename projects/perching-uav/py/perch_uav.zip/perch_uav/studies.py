"""Engineering studies: parameter sweeps, Monte-Carlo uncertainty propagation and one-at-a-time
sensitivity analysis. Pure functions shared by the browser lab (Pyodide worker pool) and the FastAPI
service, so both produce identical plans and statistics.

    plan(spec)            -> {"study_id", "kind", "runs": [{"index", "point", "req", "inputs"}], ...}
    run_metrics(req)      -> metrics of one run (no streaming)
    summarize(spec, rows) -> statistics for the whole study

Every run is an ordinary simulation request (same engine, same validation). Statistics:
  * success probability with the Wilson score 95 % interval (valid for small n and p near 0 or 1),
  * metric means with a Student-t 95 % interval, standard deviation, min (worst case) and max,
  * Monte-Carlo input importance by Spearman rank correlation,
  * OAT sensitivity as a normalised elasticity ((dm/m_base) / (dp/p_base)).
Limitations (also reported in every summary): OAT ignores interactions between parameters; the
intervals describe the simulation's own randomness at the chosen sample size, not model error.
"""

from __future__ import annotations

import hashlib
import json
import math

import numpy as np

from . import __version__
from .webapi import PARAMS, Session, finite, params_of

MAX_RUNS = 400
METRICS = {
    "t_to_perch_s": "time from mission start to propulsion-off",
    "t_final_approach_s": "time from final approach to propulsion-off",
    "energy_wh": "energy used until the run ended",
    "verified_sf": "flux/closure-verified holding safety factor",
    "contact_speed_mps": "true normal impact speed of the end effector at the last touch before attaching",
    "load_transfer_slip_mm": "slip during the load-transfer test",
    "peak_attach_util": "peak true utilisation of the attachment",
    "peak_attach_force_n": "peak attachment force (true)",
    "aborts": "approach / attachment aborts",
}
LIMITATIONS = [
    "All results are SIMULATED with assumed parameters; intervals describe sampling variability of the "
    "simulation at this sample size, not model error.",
    "One-at-a-time sensitivity ignores interactions between parameters.",
    "Runs stop once the perch outcome is known (propulsion off or mission end) unless stop_at is overridden.",
    "Metric statistics mix outcomes (a declined run flies home and uses more energy); 'metrics_success' repeats "
    "them over successful runs only.",
]

# Student-t 0.975 quantiles for df = 1..30
_T975 = [12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228, 2.201, 2.179, 2.160, 2.145,
         2.131, 2.120, 2.110, 2.101, 2.093, 2.086, 2.080, 2.074, 2.069, 2.064, 2.060, 2.056, 2.052, 2.048,
         2.045, 2.042]


def wilson(k: int, n: int, z: float = 1.959964) -> tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, c - h), min(1.0, c + h))


def describe(values) -> dict:
    v = np.array([x for x in values if x is not None and math.isfinite(x)], float)
    n = len(v)
    if n == 0:
        return dict(n=0, mean=None, sd=None, min=None, max=None, ci95=None)
    mean = float(v.mean())
    sd = float(v.std(ddof=1)) if n > 1 else 0.0
    t = _T975[n - 2] if 2 <= n <= 31 else 1.96
    half = t * sd / math.sqrt(n) if n > 1 else None
    return dict(n=n, mean=mean, sd=sd, min=float(v.min()), max=float(v.max()),
                ci95=None if half is None else [mean - half, mean + half])


def _rank(x):
    x = np.asarray(x, float)
    order = np.argsort(x, kind="mergesort")
    r = np.empty(len(x))
    r[order] = np.arange(len(x))
    # average ranks for ties
    for val in np.unique(x):
        m = x == val
        if m.sum() > 1:
            r[m] = r[m].mean()
    return r


def spearman(x, y):
    pairs = [(a, b) for a, b in zip(x, y) if a is not None and b is not None and math.isfinite(a) and math.isfinite(b)]
    if len(pairs) < 4:
        return None
    a, b = np.array(pairs).T
    ra, rb = _rank(a), _rank(b)
    if ra.std() == 0 or rb.std() == 0:
        return None
    return float(np.corrcoef(ra, rb)[0, 1])


# --------------------------------------------------------------------------- one run
def run_metrics(req: dict) -> dict:
    """Run one simulation to the end (no streaming) and extract the study metrics."""
    s = Session(req, lambda m: None, raw=True)
    s.advance(math.inf)
    r = s.result
    t_sensor = next((t for t, _a, b, _w in r["transitions"] if b == "SENSOR_MODE"), None)
    out = dict(
        success=bool(r["perched"] and not r["crashed"]), perched=bool(r["perched"]), crashed=bool(r["crashed"]),
        final_state=r["final_state"], aborts=r["aborts"], t_to_perch_s=t_sensor,
        t_final_approach_s=r["time_final_approach_to_perched_s"], energy_wh=r["energy_used_wh"],
        verified_sf=r["verified_sf"], contact_speed_mps=r.get("impact_speed_true_mps"),
        load_transfer_slip_mm=r["load_transfer_slip_mm"], peak_attach_util=r.get("peak_attach_util"),
        peak_attach_force_n=r.get("peak_attach_force_n"), sim_time_s=r["sim_time_s"],
        run_id=r["manifest"]["run_id"], findings=r["findings"][-3:],
    )
    return finite(out)


# --------------------------------------------------------------------------- plans
def _base_value(base: dict, name: str):
    v = (base.get("params") or {}).get(name)
    if v is None:
        v = PARAMS[name]["default"]
    return v


def _with_params(base: dict, upd: dict, seed: int) -> dict:
    req = json.loads(json.dumps(base))
    prm = dict(req.get("params") or {})
    prm.update(upd)
    req["params"] = prm
    req["seed"] = seed
    req.setdefault("stop_at", "perched")
    if req["stop_at"] is None:
        req.pop("stop_at")
    return req


def study_id(spec: dict) -> str:
    blob = json.dumps(dict(engine=__version__, spec=spec), sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(blob.encode()).hexdigest()[:16]


def plan(spec: dict) -> dict:
    kind = spec.get("kind")
    base = dict(spec.get("base") or {"scenario": "S1"})
    params_of(base)                                    # validate the base configuration early
    seeds = int(spec.get("seeds", 3))
    if not 1 <= seeds <= 50:
        raise ValueError("seeds must be 1..50")
    seed0 = int(base.get("seed", 0))
    runs = []
    if kind == "sweep":
        name = spec.get("param")
        if name not in PARAMS:
            raise ValueError(f"unknown parameter '{name}'")
        vals = spec.get("values")
        if not vals:
            lo, hi, k = float(spec["from"]), float(spec["to"]), int(spec.get("steps", 5))
            if not 2 <= k <= 25:
                raise ValueError("steps must be 2..25")
            vals = [float(f"{v:.10g}") for v in np.linspace(lo, hi, k)]
        for pi, v in enumerate(vals):
            params_of({"params": {name: v}})
            for s in range(seeds):
                runs.append(dict(point=pi, inputs={name: float(v)}, req=_with_params(base, {name: float(v)}, seed0 + s)))
    elif kind == "monte_carlo":
        n = int(spec.get("n", 30))
        if not 2 <= n <= MAX_RUNS:
            raise ValueError(f"n must be 2..{MAX_RUNS}")
        unc = spec.get("uncertain") or {}
        if not unc:
            raise ValueError("monte_carlo needs at least one uncertain parameter")
        for k in unc:
            if k not in PARAMS:
                raise ValueError(f"unknown parameter '{k}'")
        rng = np.random.default_rng(int(study_id(spec)[:8], 16))
        for i in range(n):
            draw = {}
            for k, d in sorted(unc.items()):
                spec_k = PARAMS[k]
                if d.get("dist", "uniform") == "uniform":
                    x = rng.uniform(float(d["low"]), float(d["high"]))
                else:
                    x = rng.normal(float(d["mean"]), float(d["sd"]))
                draw[k] = float(min(max(x, spec_k["min"]), spec_k["max"]))   # truncated to the valid range
            runs.append(dict(point=i, inputs=draw, req=_with_params(base, draw, seed0 + i)))
    elif kind == "sensitivity":
        names = spec.get("params") or []
        rel = float(spec.get("rel_delta", 0.2))
        if not 0.01 <= rel <= 0.9:
            raise ValueError("rel_delta must be 0.01..0.9")
        points = [("base", None, None)]
        for k in names:
            if k not in PARAMS:
                raise ValueError(f"unknown parameter '{k}'")
            b = _base_value(base, k)
            if b is None or b == 0:
                raise ValueError(f"'{k}' has no non-zero base value; set it in base.params")
            lo = max(PARAMS[k]["min"], b * (1 - rel))
            hi = min(PARAMS[k]["max"], b * (1 + rel))
            points += [(f"{k}:low", k, lo), (f"{k}:high", k, hi)]
        for pi, (label, k, v) in enumerate(points):
            upd = {} if k is None else {k: float(v)}
            for s in range(seeds):
                runs.append(dict(point=pi, label=label, inputs=upd, req=_with_params(base, upd, seed0 + s)))
    else:
        raise ValueError("kind must be sweep, monte_carlo or sensitivity")
    if len(runs) > MAX_RUNS:
        raise ValueError(f"study has {len(runs)} runs; the limit is {MAX_RUNS}")
    for i, r in enumerate(runs):
        r["index"] = i
    return dict(study_id=study_id(spec), engine_version=__version__, kind=kind, n_runs=len(runs), runs=runs)


# --------------------------------------------------------------------------- statistics
def _point_stats(rows):
    k = sum(1 for r in rows if r.get("success"))
    n = len(rows)
    return dict(n=n, successes=k, p_success=k / n if n else None, p_success_ci95=list(wilson(k, n)),
                p_crash=sum(1 for r in rows if r.get("crashed")) / n if n else None,
                metrics={m: describe([r.get(m) for r in rows]) for m in METRICS},
                # the same statistics over successful runs only: declined runs fly home and would otherwise
                # dominate metrics such as energy (outcome mixing)
                metrics_success={m: describe([r.get(m) for r in rows if r.get("success")]) for m in METRICS})


def summarize(spec: dict, rows: list) -> dict:
    p = plan(spec)
    kind = p["kind"]
    by_index = {r["index"]: r for r in rows}
    joined = [dict(run, metrics=by_index[run["index"]]) for run in p["runs"] if run["index"] in by_index]
    out = dict(study_id=p["study_id"], engine_version=__version__, kind=kind, n_planned=p["n_runs"],
               n_done=len(joined), label="SIMULATED", limitations=LIMITATIONS, metric_descriptions=METRICS)
    if kind == "sweep":
        pts = {}
        for j in joined:
            pts.setdefault(j["point"], []).append(j)
        out["param"] = spec["param"]
        out["points"] = [dict(value=v[0]["inputs"][spec["param"]], **_point_stats([x["metrics"] for x in v]))
                         for _, v in sorted(pts.items())]
    elif kind == "monte_carlo":
        ms = [j["metrics"] for j in joined]
        out["overall"] = _point_stats(ms)
        imp = {}
        for k in sorted(spec["uncertain"]):
            xs = [j["inputs"][k] for j in joined]
            imp[k] = {m: spearman(xs, [x.get(m) for x in ms]) for m in list(METRICS) + ["success"]}
            imp[k]["success"] = spearman(xs, [1.0 if x.get("success") else 0.0 for x in ms])
        out["importance_spearman"] = imp
        out["runs"] = [dict(inputs=j["inputs"], **{m: j["metrics"].get(m) for m in ["success", "crashed", *METRICS]})
                       for j in joined]
    else:
        pts = {}
        for j in joined:
            pts.setdefault(j.get("label"), []).append(j["metrics"])
        stats = {lab: _point_stats(v) for lab, v in pts.items()}
        base = stats.get("base")
        rel = float(spec.get("rel_delta", 0.2))
        table = []
        for k in spec.get("params") or []:
            lo, hi = stats.get(f"{k}:low"), stats.get(f"{k}:high")
            if not (base and lo and hi):
                continue
            b = _base_value(spec.get("base") or {}, k)
            p_lo = max(PARAMS[k]["min"], b * (1 - rel))
            p_hi = min(PARAMS[k]["max"], b * (1 + rel))
            row = dict(param=k, low=p_lo, high=p_hi,
                       d_p_success=(hi["p_success"] - lo["p_success"]) if hi["n"] and lo["n"] else None)
            for m in METRICS:
                mb, ml, mh = (base["metrics"][m]["mean"], lo["metrics"][m]["mean"], hi["metrics"][m]["mean"])
                if None in (mb, ml, mh) or mb == 0 or p_hi == p_lo:
                    row[m] = None
                else:
                    row[m] = ((mh - ml) / abs(mb)) / ((p_hi - p_lo) / b)
            table.append(row)
        out["points"] = stats
        out["elasticity"] = table
    return finite(out)
