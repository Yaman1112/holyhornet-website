"""Onboard autonomy: estimation + perception + control + the perching state machine.

The state machine (docs/perching/STATE_MACHINE.md) has the 15 mission states required by the
specification plus explicit recovery states. Every state has entry actions, exit conditions,
a timeout and a failure transition. Actuator outputs always pass through the PropulsionInterlock
and ReleaseInterlock (safety.py); the decision layer only advises.

This module receives sensor messages only (no ground truth).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .config import SimConfig
from .control import (AttitudeController, LQRPosition, Mixer, MPCPosition, PIDPosition, approach_reference,
                      thrust_and_attitude)
from .decision import DecisionLayer, EnergyModel
from .estimation import ESKF, RelativeTargetFilter
from .geom import GRAVITY, rot_exp, rot_log, rot_z, unit, wrap_pi, yaw_of
from .mechanism import BOOM_POSES, Capacity, ClawParams, EPMPadParams, claw_capacity, design_gust, \
    worst_case_utilisation
from .materials import MATERIALS
from .perception import SurfaceMap, detect_surfaces
from .safety import Decision, PropulsionInterlock, ReleaseInterlock, SafetyGuard
from .sensor_mode import SensorStation, StationConfig
from .suitability import evaluate

MISSION_STATES = [
    "TAKEOFF", "NAVIGATION", "SURFACE_DETECTION", "SURFACE_EVALUATION", "APPROACH_PLANNING", "FINAL_APPROACH",
    "CONTACT_DETECTION", "ATTACHMENT", "ATTACHMENT_VERIFICATION", "PROPULSION_REDUCTION", "SENSOR_MODE",
    "PRE_TAKEOFF_CHECK", "DETACHMENT", "TAKEOFF_VERIFICATION", "AUTONOMOUS_MISSION_RESUMPTION",
]
SUPPORT_STATES = ["IDLE", "ABORT_RECOVERY", "EMERGENCY_RESPIN", "HOVER_MONITOR", "RETURN_HOME", "LANDING",
                  "EMERGENCY_LAND", "MISSION_COMPLETE", "MISSION_FAILED"]

TIMEOUTS = {
    "TAKEOFF": 20.0, "NAVIGATION": 90.0, "SURFACE_DETECTION": 16.0, "SURFACE_EVALUATION": 2.0,
    "APPROACH_PLANNING": 30.0, "FINAL_APPROACH": 25.0, "CONTACT_DETECTION": 1.5, "ATTACHMENT": 1.5,
    "ATTACHMENT_VERIFICATION": 6.0, "PROPULSION_REDUCTION": 6.0, "SENSOR_MODE": np.inf,
    "PRE_TAKEOFF_CHECK": 12.0, "DETACHMENT": 6.0, "TAKEOFF_VERIFICATION": 12.0,
    "AUTONOMOUS_MISSION_RESUMPTION": 2.0, "ABORT_RECOVERY": 20.0, "EMERGENCY_RESPIN": 5.0,
    "HOVER_MONITOR": np.inf, "RETURN_HOME": 120.0, "LANDING": 30.0, "EMERGENCY_LAND": 60.0, "IDLE": np.inf,
    "MISSION_COMPLETE": np.inf, "MISSION_FAILED": np.inf,
}


@dataclass
class Waypoint:
    p: tuple
    yaw: float = 0.0


@dataclass
class Mission:
    home: tuple
    search: list                              # Waypoints where to look for perch surfaces
    monitor_s: float = 60.0
    resume: list = field(default_factory=list)  # Waypoints after detaching
    takeoff_alt: float = 2.0
    max_attempts: int = 2
    land_at_end: bool = True
    require_declared_load: bool = True


def _tangent_axes(n):
    from .geom import orthonormal_basis
    return orthonormal_basis(n)


class Autonomy:
    def __init__(self, cfg: SimConfig, module, boom_default: str, mission: Mission, site_db, p0, yaw0,
                 station_read=None, station_cfg: StationConfig | None = None, rng=None):
        self.cfg, self.module, self.mission, self.site_db = cfg, module, mission, site_db
        self.is_epm = isinstance(module, EPMPadParams)
        vp = cfg.vehicle
        self.mass = vp.mass
        self.hover_T = vp.mass * GRAVITY
        self.rng = rng or np.random.default_rng(7)
        self.nav = ESKF(np.array(p0, float), rot_z(yaw0))
        self.att = self.nav                 # attitude (R, w) comes from the same filter
        self.rel: RelativeTargetFilter | None = None
        self.map = SurfaceMap()
        self.attc = AttitudeController(vp.inertia)
        self.mixer = Mixer(vp.arm_length, vp.torque_coefficient, vp.max_motor_thrust)
        self.pid, self.lqr, self.mpc = PIDPosition(), LQRPosition(), MPCPosition()
        self.interlock = PropulsionInterlock(cfg.safety.min_airborne_thrust_fraction)
        self.release_lock = ReleaseInterlock()
        self.guard = SafetyGuard(cfg.safety)
        cap_j = cfg.battery.capacity_ah * 3600 * cfg.battery.cells * 0.5 * (cfg.battery.cell_v_full + cfg.battery.cell_v_empty)
        self.decider = DecisionLayer(EnergyModel(), cfg.battery.reserve_soc, cap_j)
        self.station = SensorStation(station_read, station_cfg) if station_read else None
        self.boom_default = boom_default

        # commands to the vehicle
        self.T = 0.0
        self.R_d = rot_z(yaw0)
        self.yaw_d = yaw0
        self.armed = False
        self.mech_cmds: list[str] = []
        self.low_power = False
        self.a_prev = np.zeros(3)

        # latest messages
        self.pad = None
        self.esc = None
        self.batt = None
        self.wind_est = np.zeros(3)
        self.wind_hist: list = []
        self.depth_pts_w: dict = {}
        self.last_dets: list = []

        # mission bookkeeping
        self.state = "IDLE"
        self.t = 0.0
        self.t_enter = 0.0
        self.transitions: list[tuple[float, str, str, str]] = []
        self.reports = []
        self.target = None              # SuitabilityReport
        self.plan = None
        self.attempts: dict[str, int] = {}
        self.wp_queue: list[Waypoint] = []
        self.sub = {}                   # per-state scratch
        self.perched_since = None
        self.flags: dict[str, object] = {}
        self.metrics: dict[str, float] = {}
        self.findings: list[str] = []
        self.home = np.array(mission.home, float)
        self.decisions: list[Decision] = []

    # ================================================================== estimation (250 Hz)
    def on_imu(self, msg, dt):
        attached_still = self.state in ("SENSOR_MODE", "PROPULSION_REDUCTION") and not self.armed
        a_w = self.nav.predict(msg.gyro, msg.accel, dt)
        if attached_still:
            self.nav.zero_velocity_update()
        if self.rel is not None:
            self.rel.predict(a_w, dt)
            if attached_still:
                self.rel.update_velocity(np.zeros(3), 0.01)
        return self.motor_commands()

    def on_position(self, msg):
        ok = self.nav.update_position(msg.p, msg.sigma)
        if self.rel is not None and self.plan is not None:
            # absolute fix also constrains the tangential relative position (target fixed in world)
            u, w = _tangent_axes(self.plan.normal)
            sig = float(np.sqrt(np.mean(np.diag(self.nav.P[0:3, 0:3]))) + 0.03)
            self.rel.update_relative(self.nav.p - self.plan.target, sig, np.vstack([u, w]))
        if not ok and self.nav.rejected % 50 == 1:
            self.findings.append(f"{self.t:.1f}s position fix rejected by innovation gate (NIS {self.nav.last_nis:.1f})")
        self.nav.update_yaw(msg.yaw, msg.yaw_sigma)

    def on_pad(self, msg):
        self.pad = msg

    def on_esc(self, msg):
        self.esc = msg

    def on_battery(self, msg):
        self.batt = msg

    def on_anemometer(self, msg):
        self.wind_hist.append((msg.t, msg.wind))
        self.wind_hist = [w for w in self.wind_hist if w[0] > msg.t - 10.0]
        self.wind_est = np.mean([w for _, w in self.wind_hist], axis=0)

    @property
    def wind_speed(self):
        return float(np.linalg.norm(self.wind_est))

    @property
    def wind_turb(self):
        if len(self.wind_hist) < 3:
            return 1.0
        W = np.array([w for _, w in self.wind_hist])
        return float(np.clip(np.mean(np.std(W, axis=0)), 0.5, 4.0))

    @property
    def soc(self):
        return self.batt.soc if self.batt else 1.0

    # ================================================================== perception (5 Hz)
    def detect(self, msg):
        dets = detect_surfaces(msg, self.att.R, self.nav.p.copy(), self.rng)
        self.depth_pts_w[msg.sensor] = self.nav.p + msg.points_b @ self.att.R.T
        return dets

    def integrate(self, dets, t):
        self.map.update(dets, t)
        self.last_dets = dets
        if self.rel is None or self.target is None:
            return
        cand = self.map.get(self.target.candidate_id)
        p = self.nav.p
        for d in dets:
            if getattr(d, "candidate_id", None) != self.target.candidate_id:
                continue
            n = self.plan.normal
            rng_m = d.range_m
            if d.kind == "plane":
                r_meas = p - d.centroid
                self.rel.update_relative(r_meas, 0.004 + 0.003 * rng_m ** 2, n)
                if not d.touches_edge and cand is not None and max(cand.size) < 2.0:
                    c_det = d.centroid + 0.5 * (d.extent[0] + d.extent[1]) * d.u + 0.5 * (d.extent[2] + d.extent[3]) * d.w
                    r_t = p - c_det
                    for ax in (d.u, d.w):
                        self.rel.update_relative(r_t, 0.02 + 0.01 * rng_m, ax)
            else:
                tgt = d.axis_point + d.radius * np.array([0.0, 0.0, 1.0])
                r_meas = p - tgt
                ax = unit(d.u)
                perp = unit(np.cross(ax, np.array([0.0, 0.0, 1.0])))
                self.rel.update_relative(r_meas, 0.006 + 0.004 * rng_m ** 2, np.array([0.0, 0.0, 1.0]))
                self.rel.update_relative(r_meas, 0.006 + 0.004 * rng_m ** 2, perp)

    # ================================================================== actuation
    def motor_commands(self):
        T, disarm_ok = self.interlock.filter(self.T, self.hover_T, disarm_request=not self.armed)
        if not self.armed and not disarm_ok:
            self.armed = True      # interlock refused the disarm
            self.findings.append(f"{self.t:.2f}s interlock refused disarm in {self.state} (token {self.interlock.token})")
        M = self.attc.torque(self.att.R, self.att.w, self.R_d)
        if T < 0.3 * self.hover_T:
            M = M * max(T / (0.3 * self.hover_T), 0.0)   # little authority at low thrust: avoid saturation
        f = self.mixer.allocate(T, M, f_min=self.cfg.vehicle.idle_motor_thrust if self.armed else 0.0)
        return f if self.armed else np.zeros(4)

    def _fly_to(self, p_ref, yaw, v_ref=np.zeros(3), ctrl="pid", a_ff=np.zeros(3), dt=0.02, max_tilt=30.0,
                avoid=False):
        c = self.pid if ctrl == "pid" else self.lqr
        a = c(self.nav.p, self.nav.v, np.asarray(p_ref, float), v_ref, a_ff, dt)
        if avoid:
            a = a + self._avoidance()
        self._apply_accel(a, yaw, max_tilt)

    def _track(self, target, speed, yaw, ctrl="pid", avoid=False, dt=0.02):
        """Follow a reference point that moves towards `target` at <= `speed` (velocity-limited)."""
        target = np.asarray(target, float)
        if "ref" not in self.sub:
            self.sub["ref"] = self.nav.p.copy()
        ref = self.sub["ref"]
        d = target - ref
        dist = float(np.linalg.norm(d))
        step = min(speed * dt, dist)
        u = d / dist if dist > 1e-9 else np.zeros(3)
        ref = ref + u * step
        # do not let the reference run away from the vehicle (e.g. under avoidance)
        lag = ref - self.nav.p
        if np.linalg.norm(lag) > 2.0:
            ref = self.nav.p + lag / np.linalg.norm(lag) * 2.0
        self.sub["ref"] = ref
        v_ref = u * speed if dist > speed * dt else np.zeros(3)
        self._fly_to(ref, yaw, v_ref=v_ref, ctrl=ctrl, avoid=avoid, dt=dt)
        return float(np.linalg.norm(target - self.nav.p))

    def _apply_accel(self, a, yaw, max_tilt=30.0):
        self.a_prev = a
        self.yaw_d = yaw
        self.T, self.R_d = thrust_and_attitude(a, yaw, self.att.R, self.mass, max_tilt, 4 * self.cfg.vehicle.max_motor_thrust * 0.9)

    def _avoidance(self):
        a = np.zeros(3)
        p = self.nav.p
        for pts in self.depth_pts_w.values():
            if len(pts) == 0:
                continue
            d = p - pts
            dist = np.linalg.norm(d, axis=1)
            m = (dist < 1.5) & (dist > 0.05)
            m &= pts[:, 2] > 0.3          # ignore the ground
            if np.any(m):
                k = (1.0 / dist[m] - 1.0 / 1.5)[:, None] * d[m] / dist[m, None]
                a += 1.2 * k.sum(0) / max(1, m.sum() / 20)
        n = np.linalg.norm(a)
        return a if n < 3.0 else a * 3.0 / n

    def _attached_thrust(self, frac, R_target=None):
        """Attitude-hold with a commanded thrust fraction (used while in contact/attached)."""
        self.T = frac * self.hover_T
        if R_target is not None:
            self.R_d = R_target

    # ================================================================== state machine (50 Hz)
    def goto(self, new, reason):
        self.transitions.append((round(self.t, 3), self.state, new, reason))
        self.state = new
        self.t_enter = self.t
        self.sub = {}

    @property
    def dt_state(self):
        return self.t - self.t_enter

    def start(self, t):
        self.t = t
        if self.soc < self.cfg.safety.min_departure_soc:
            self.goto("MISSION_FAILED", f"pre-flight: SoC {self.soc:.2f} below {self.cfg.safety.min_departure_soc}")
            return
        self.interlock.grant(t, "LANDED", "on ground at start")
        self.armed = True
        self.goto("TAKEOFF", "mission start, pre-flight checks passed")

    def step(self, t, dt):
        self.t = t
        handler = getattr(self, "_s_" + self.state.lower())
        if self.dt_state > TIMEOUTS[self.state]:
            self._on_timeout()
            return
        handler(dt)

    def _on_timeout(self):
        s = self.state
        if s in ("FINAL_APPROACH", "CONTACT_DETECTION", "ATTACHMENT", "ATTACHMENT_VERIFICATION", "APPROACH_PLANNING"):
            self._abort(f"timeout in {s}")
        elif s == "PROPULSION_REDUCTION":
            self._abort("timeout in PROPULSION_REDUCTION (motors re-spun)")
        elif s == "PRE_TAKEOFF_CHECK":
            self._remain_attached("pre-takeoff check timed out")
        elif s == "DETACHMENT":
            self._remain_attached("detachment timed out")
        elif s in ("SURFACE_DETECTION",):
            self.goto("SURFACE_EVALUATION", "detection window elapsed")
        elif s in ("TAKEOFF_VERIFICATION", "EMERGENCY_RESPIN"):
            self.goto("EMERGENCY_LAND", f"timeout in {s}")
        elif s in ("TAKEOFF", "NAVIGATION", "RETURN_HOME", "SURFACE_EVALUATION", "AUTONOMOUS_MISSION_RESUMPTION",
                   "ABORT_RECOVERY"):
            self.goto("EMERGENCY_LAND" if s != "NAVIGATION" else "RETURN_HOME", f"timeout in {s}")
        elif s in ("LANDING", "EMERGENCY_LAND"):
            self.goto("MISSION_FAILED", f"timeout in {s}")

    # ------------------------------------------------------------------ flight states
    def _s_idle(self, dt):
        self.armed = False

    def _s_takeoff(self, dt):
        if "ref" not in self.sub:
            self.sub["ref"] = self.nav.p + np.array([0, 0, self.mission.takeoff_alt])
            self.sub["yaw"] = self.yaw_d
            self.pid.reset()
        if self.dt_state > 0.5 and self.interlock.token == "LANDED":
            self.interlock.revoke(self.t, "airborne")
        z0 = self.sub["ref"][2] - self.mission.takeoff_alt
        zr = min(self.sub["ref"][2], z0 + 1.0 * self.dt_state)
        ref = np.r_[self.sub["ref"][:2], zr]
        self._fly_to(ref, self.sub["yaw"], v_ref=np.array([0, 0, 1.0 if zr < self.sub["ref"][2] else 0.0]))
        if abs(self.nav.p[2] - self.sub["ref"][2]) < 0.15 and np.linalg.norm(self.nav.v) < 0.3:
            self.wp_queue = list(self.mission.search)
            self.goto("NAVIGATION", "takeoff altitude reached")

    def _s_navigation(self, dt):
        if not self.wp_queue:
            self.goto("SURFACE_DETECTION" if not self.flags.get("resumed") else "RETURN_HOME", "waypoints complete")
            return
        wp = self.wp_queue[0]
        tgt = np.array(wp.p, float)
        d = tgt - self.nav.p
        dist = np.linalg.norm(d)
        # energy-aware check: always keep enough to return home
        dh = np.linalg.norm(self.home - self.nav.p)
        need = self.decider.E.flight_j(dh + dist, extra_s=30)
        if self.decider.usable_j(self.soc) < need:
            self.goto("RETURN_HOME", f"energy: usable {self.decider.usable_j(self.soc)/1e3:.1f} kJ < {need/1e3:.1f} kJ needed")
            return
        self._track(tgt, 2.0, wp.yaw, avoid=True)
        if dist < 0.4 and np.linalg.norm(self.nav.v) < 0.4:
            self.wp_queue.pop(0)
            self.sub.pop("ref", None)
            if not self.wp_queue:
                if self.flags.get("resumed"):
                    self.goto("RETURN_HOME", "resumed mission waypoints complete")
                else:
                    self.sub["hold"] = tgt
                    self.goto("SURFACE_DETECTION", "search waypoint reached")

    def _s_surface_detection(self, dt):
        if "c" not in self.sub:
            self.sub["c"] = self.nav.p.copy()
            self.sub["yaw0"] = self.yaw_d
            self.lqr.reset()
        yaw = self.sub["yaw0"] + np.radians(35) * np.sin(2 * np.pi * self.dt_state / 8.0)
        self._fly_to(self.sub["c"], yaw, ctrl="lqr")
        # wait for an elevated (non-ground) candidate with enough evidence; ground fragments alone
        # do not end the scan early (they are rarely perchable)
        good = [c for c in self.map.cands if c.n_obs >= 4 and not c.blacklisted and not self._is_ground(c)]
        if self.dt_state > 8.0 and good:
            self.goto("SURFACE_EVALUATION", f"{len(good)} elevated candidate surface(s) with >= 4 detections")

    def _evaluate_all(self):
        others = self.map.cands
        reps = []
        for c in self.map.cands:
            if c.blacklisted:
                continue
            if c.n_obs < 2:
                continue
            rep = evaluate(c, self.module, self.mass, self.wind_speed, self.wind_turb, self.site_db, others,
                           yaw_hint=self.yaw_d, min_sf=self.cfg.safety.min_safety_factor,
                           max_perch_wind=self.cfg.safety.max_perch_wind,
                           require_declared_load=self.mission.require_declared_load, feet=self.cfg.vehicle.feet)
            reps.append(rep)
        return reps

    def _s_surface_evaluation(self, dt):
        self._fly_to(self.sub.get("c", self.nav.p.copy()), self.yaw_d, ctrl="lqr")
        if "c" not in self.sub:
            self.sub["c"] = self.nav.p.copy()
        if self.dt_state < 0.3:
            return
        reps = self._evaluate_all()
        self.reports.append((self.t, reps))
        dh = float(np.linalg.norm(self.home - self.nav.p))
        dec = self.decider.choose_target(reps, self.soc, self.mission.monitor_s, dh, self.t)
        ctx = dict(report=next((r for r in reps if r.candidate_id == dec.target), None), wind=self.wind_speed,
                   hover_energy_j=dec.inputs.get("hover_energy_j", 0.0), usable_j=self.decider.usable_j(self.soc))
        dec = self.guard.vet(dec, ctx)
        self.decisions.append(dec)
        if dec.vetoed:
            self.findings.append(f"{self.t:.1f}s decision '{dec.action}' vetoed: {dec.veto_reason}")
            self.goto("RETURN_HOME", f"decision vetoed ({dec.veto_reason})")
            return
        if dec.action == "perch":
            self.target = ctx["report"]
            self.plan = self.target.plan
            self.goto("APPROACH_PLANNING", f"perch on {dec.target}: " + dec.reasons[-2])
        elif dec.action == "hover_monitor":
            self.goto("HOVER_MONITOR", "; ".join(dec.reasons[-1:]))
        else:
            self.goto("RETURN_HOME", "; ".join(dec.reasons[-1:]))

    def _s_approach_planning(self, dt):
        plan = self.plan
        if "init" not in self.sub:
            self.sub["init"] = True
            self.pid.reset()
            self.lqr.reset()
            boom = plan.boom
            if boom != self.boom_default:
                self.mech_cmds.append(f"boom:{boom}")
            self.sub["boom"] = boom
        # refresh the plan from the fused candidate (geometry keeps improving)
        cand = self.map.get(self.target.candidate_id)
        if cand is not None and self.dt_state > 1.0 and int(self.dt_state * 50) % 25 == 0 and self.rel is None:
            rep = evaluate(cand, self.module, self.mass, self.wind_speed, self.wind_turb, self.site_db, self.map.cands,
                           yaw_hint=plan.yaw, min_sf=self.cfg.safety.min_safety_factor,
                           max_perch_wind=self.cfg.safety.max_perch_wind,
                           require_declared_load=self.mission.require_declared_load, feet=self.cfg.vehicle.feet)
            if not rep.suitable:
                self._abort("re-evaluation at standoff failed: " + rep.summary, blacklist=True)
                return
            self.target, self.plan = rep, rep.plan
            plan = self.plan
        # route: first climb/translate above/in front, then hold at standoff
        self._track(plan.standoff, 1.0, plan.yaw, ctrl="pid")
        at = np.linalg.norm(plan.standoff - self.nav.p) < 0.12 and np.linalg.norm(self.nav.v) < 0.15
        if at:
            self.sub["settle"] = self.sub.get("settle", 0.0) + dt
        else:
            self.sub["settle"] = 0.0
        if self.sub["settle"] > 1.5:
            if self.wind_speed > self.cfg.safety.max_perch_wind:
                self._abort(f"wind {self.wind_speed:.1f} m/s above perching limit")
                return
            # relative-navigation filter initialised from the current estimates
            tip_w = self.att.R @ np.array(BOOM_POSES[plan.boom].tip)
            self.rel = RelativeTargetFilter(self.nav.p - plan.target, self.nav.v, plan.normal,
                                            sigma_r=0.05)
            self.mpc.reset()
            self.goto("FINAL_APPROACH", "stable at standoff, relative navigation initialised")

    def _tip_rel(self):
        tip_w = self.att.R @ np.array(BOOM_POSES[self.plan.boom].tip)
        return self.rel.r + tip_w, self.rel.v, tip_w

    def _s_final_approach(self, dt):
        plan, lim = self.plan, self.cfg.safety
        e, v, tip_w = self._tip_rel()
        n = plan.normal
        if self.pad is not None and np.isfinite(self.pad.tof_range) and self.pad.tof_range < 0.4:
            dir_w = self.att.R @ np.array(BOOM_POSES[plan.boom].direction)
            cosang = max(0.5, float(-dir_w @ n))
            self.rel.update_tof(self.pad.tof_range * cosang, tip_w)
            e, v, tip_w = self._tip_rel()
        d = float(n @ e)
        ref = approach_reference(d, n, self.mpc.N, self.mpc.h, 0.45, 0.22, 0.5, push_depth=0.03)
        a = self.mpc(e, v, ref, self.a_prev)
        self._apply_accel(a, plan.yaw, max_tilt=20.0)
        # continuous abort conditions
        et = e - d * n
        if not self.is_epm:
            et = et - (et @ plan.long_axis) * plan.long_axis
        tol = 0.08 if self.is_epm else 0.03      # capture window of the pad / claw fingers
        bad = d < 0.20 and np.linalg.norm(et) > tol
        self.sub["lat_bad"] = self.sub.get("lat_bad", 0) + 1 if bad else 0
        if self.sub["lat_bad"] >= 10:            # persistent for 0.2 s (not a single noisy estimate)
            self._abort(f"lateral error {np.linalg.norm(et)*100:.1f} cm > {tol*100:.1f} cm at {d:.2f} m")
            return
        if self.wind_speed > lim.max_perch_wind:
            self._abort(f"wind rose to {self.wind_speed:.1f} m/s during approach")
            return
        if self._obstacle_near(0.9):
            self._abort("moving obstacle near the approach corridor")
            return
        if self.pad is not None and self.pad.contact and self.pad.load_n > 0.6:
            self.metrics["contact_speed_est"] = float(-v @ n)
            if -v @ n > lim.max_contact_speed:
                self.findings.append(f"{self.t:.1f}s contact speed {float(-v @ n):.2f} m/s above pad rating")
            self.goto("CONTACT_DETECTION", f"pad contact (load {self.pad.load_n:.1f} N, ToF {self.pad.tof_range:.3f} m)")

    def _push(self, force=None):
        if force is None:
            # walls: pressing by tilting rotates the pad off the wall and the rotor discs towards it
            force = 1.5 if not self.is_epm else (1.5 if self.plan.boom == "forward" else 2.5)
        max_tilt = 6.0 if self.plan.boom == "forward" else 15.0
        """Hold the pad against the surface: tangential PD on the tip error + normal feed-forward force."""
        e, v, _ = self._tip_rel()
        n = self.plan.normal
        et = e - (n @ e) * n
        vt = v - (n @ v) * n
        a = -2.0 * et - 2.0 * vt - n * (force / self.mass) - 1.5 * (n @ v) * n
        self._apply_accel(a, self.plan.yaw, max_tilt=max_tilt)

    def _s_contact_detection(self, dt):
        self._push()
        touching = self.pad is not None and self.pad.contact
        if touching and self.pad.load_n > 0.6:
            self.sub["n"] = self.sub.get("n", 0) + 1
        elif not touching:
            self.sub["n"] = 0
        self.sub["lost"] = 0 if touching else self.sub.get("lost", 0) + 1
        if self.sub["lost"] > 15:                 # 0.3 s without any contact: bounced off
            self._abort("contact lost (bounce)")
            return
        if self.sub.get("n", 0) >= 3:
            self.goto("ATTACHMENT", "stable contact for 60 ms")

    def _s_attachment(self, dt):
        self._push()
        if "cmd" not in self.sub:
            self.sub["cmd"] = True
            self.mech_cmds.append("engage")
            return
        if self.pad is None or self.pad.mech_state != "engaged":
            return
        self.sub["wait"] = self.sub.get("wait", 0) + dt
        if self.sub["wait"] < 0.12:
            return
        held = self.pad.flux_ratio >= 0.05 if self.is_epm else self.pad.flux_ratio >= 0.99
        if held:
            self.goto("ATTACHMENT_VERIFICATION", f"mechanism engaged ({'flux' if self.is_epm else 'closure'} "
                                                 f"{self.pad.flux_ratio:.2f})")
        else:
            self._abort(f"mechanism engaged but no hold ({'flux' if self.is_epm else 'closure'} {self.pad.flux_ratio:.2f})"
                        " — surface incompatible with module", blacklist=True)

    def _measured_capacity(self):
        if self.is_epm:
            f = self.pad.flux_ratio * self.module.nominal_force
            cand = self.map.get(self.target.candidate_id)
            probs = (cand.material_probs if cand else None) or {"mild_steel": 1.0}
            ferro = {k: v for k, v in probs.items() if MATERIALS[k]["k_mag"] >= 0.5} or {"mild_steel": 1.0}
            mat = max(ferro, key=ferro.get)
            return Capacity(self.module.name, magnet_force=(f, f), mu=MATERIALS[mat]["mu_pad"])
        cand = self.map.get(self.target.candidate_id)
        return claw_capacity(self.module, "mild_steel" if not cand.material_probs else
                             max(cand.material_probs, key=cand.material_probs.get), 2 * cand.radius)

    def _measured_sf(self, wind_speed=None):
        cap = self._measured_capacity()
        boom = BOOM_POSES[self.plan.boom]
        v = design_gust(self.wind_speed, self.wind_turb) if wind_speed is None else wind_speed
        u = worst_case_utilisation(self.module, cap, self.mass, self.att.R if self.plan.boom != "down" else self.plan.R_perch,
                                   boom, self.plan.normal, self.plan.long_axis, v, self.cfg.vehicle.feet)
        return u.safety_factor, u.mode

    def _s_attachment_verification(self, dt):
        lim = self.cfg.safety
        sb = self.sub
        if "stage" not in sb:
            sb["stage"] = "A"
            sb["R_hold"] = self.att.R.copy()
            sb["flux0"] = []
            sb["slip0"] = self.pad.slip_mm
        # align the body with the planned perched attitude on the unlocked wrist (level for walls,
        # surface-normal for decks/inclines) so that the departure thrust vector is not tilted
        # towards the surface when the wrist is later locked
        R_tgt = sb["R_hold"]
        if self.is_epm:
            s = min(1.0, self.dt_state / 1.0)
            R_tgt = sb["R_hold"] @ rot_exp(s * rot_log(sb["R_hold"].T @ self.plan.R_perch))
        if sb["stage"] == "A":
            self._attached_thrust(0.9 if self.plan.boom == "down" else 1.0, R_tgt)
            sb["flux0"].append(self.pad.flux_ratio)
            if len(sb["flux0"]) < 10 or (self.is_epm and self.dt_state < 1.2):
                return
            sf, mode = self._measured_sf()
            sb["flux_ref"] = float(np.mean(sb["flux0"]))
            self.metrics["verified_sf"] = sf
            if sf < lim.min_verified_safety_factor:
                self._abort(f"measured holding SF {sf:.2f} < {lim.min_verified_safety_factor} ({mode}); "
                            f"flux ratio {sb['flux_ref']:.2f}", blacklist=True)
                return
            self.interlock.grant(self.t, "TEST", f"engaged, measured SF {sf:.2f}")
            if self.is_epm and self.plan.boom != "down":
                self.mech_cmds.append("lock_wrist")
            sb["stage"], sb["t_b"] = "B", self.t
            return
        # stage B: load-transfer test 1.0 -> 0.55 hover over 1.5 s, hold 0.7 s
        tb = self.t - sb["t_b"]
        frac = max(0.55, 1.0 - 0.45 * tb / 1.5)
        self._attached_thrust(frac, R_tgt)
        slip = self.pad.slip_mm - sb["slip0"]
        flux_drop = 1.0 - self.pad.flux_ratio / max(sb["flux_ref"], 1e-6) if self.is_epm else 0.0
        if slip > lim.max_drift_during_load_transfer * 1000 or flux_drop > 0.25 or self.pad.mech_state != "engaged":
            self._attached_thrust(1.0, R_tgt)
            self._abort(f"load-transfer test failed (slip {slip:.1f} mm, flux drop {flux_drop*100:.0f} %)")
            return
        if tb > 2.2:
            if self.is_epm and self.plan.boom == "down":
                self.mech_cmds.append("lock_wrist")
            self.metrics["load_transfer_slip_mm"] = float(slip)
            ok = self.interlock.grant(self.t, "ATTACHED", f"load transfer passed (slip {slip:.1f} mm)")
            if ok:
                sb["R_final"] = R_tgt
                self.goto("PROPULSION_REDUCTION", f"attachment verified: slip {slip:.1f} mm, "
                                                  f"SF {self.metrics['verified_sf']:.2f}")

    def _s_propulsion_reduction(self, dt):
        sb = self.sub
        if "R" not in sb:
            sb["R"] = self.R_d.copy()
            sb["slip0"] = self.pad.slip_mm
            sb["flux0"] = self.pad.flux_ratio
        frac = max(0.0, 0.55 - 0.55 * self.dt_state / 2.0)
        if self.armed:
            self._attached_thrust(frac, sb["R"])
        anomaly = (self.pad.slip_mm - sb["slip0"] > 8.0 or self.pad.mech_state != "engaged" or
                   (self.is_epm and self.pad.flux_ratio < 0.75 * sb["flux0"]))
        if anomaly:
            self.armed = True
            self._attached_thrust(1.0, sb["R"])
            self.interlock.revoke(self.t, "anomaly during propulsion reduction")
            self._abort("attachment anomaly during propulsion reduction")
            return
        if frac <= 0.08 and self.armed:
            self.armed = False          # disarm request (interlock checks the token)
            sb["t_off"] = self.t
        if not self.armed and self.t - sb.get("t_off", self.t) > 1.0:
            self.perched_since = self.t
            self.metrics["t_perched"] = self.t
            self.low_power = True
            self.goto("SENSOR_MODE", "propulsion off, attachment stable")

    # ------------------------------------------------------------------ sensor mode
    def _s_sensor_mode(self, dt):
        sb = self.sub
        if "slip0" not in sb:
            sb["slip0"] = self.pad.slip_mm
            sb["flux0"] = self.pad.flux_ratio
            sb["next_dec"] = self.t
            sb["next_station"] = self.t
            sb["retry_at"] = self.flags.pop("retry_at", self.t)
        self.armed = False
        # attachment health (every tick)
        slip = self.pad.slip_mm - sb["slip0"]
        if slip > 5.0 or self.pad.mech_state != "engaged" or (self.is_epm and self.pad.flux_ratio < 0.7 * sb["flux0"]):
            self.goto("EMERGENCY_RESPIN", f"attachment anomaly in sensor mode (slip {slip:.1f} mm, flux "
                                          f"{self.pad.flux_ratio:.2f})")
            return
        if self.station is not None and self.t >= sb["next_station"]:
            step = max(1.0, self.t - sb.get("last_station", self.t - 1.0))
            self.station.tick(self.t, step)
            sb["last_station"] = self.t
            sb["next_station"] = self.t + 1.0
        if self.t >= sb["next_dec"]:
            sb["next_dec"] = self.t + 5.0
            planned_h = max(0.0, (self.mission.monitor_s - (self.t - self.perched_since)) / 3600)
            event = self.station is not None and self.t <= self.station.event_until
            md = self.decider.sensing_mode(self.soc, planned_h, event, self.t)
            if self.station is not None:
                self.station.set_mode(md.action.replace("mode_", ""))
            sf_now, _ = self._measured_sf(wind_speed=self.wind_speed + 2 * self.wind_turb)
            nxt = self.mission.resume[0].p if self.mission.resume else self.mission.home
            dn = float(np.linalg.norm(np.array(nxt) - self.nav.p))
            dh = float(np.linalg.norm(self.home - np.array(nxt)))
            d = self.decider.should_detach(self.t - self.perched_since, self.mission.monitor_s, self.soc, dn, dh,
                                           self.wind_speed, sf_now, True, self.t)
            if d.action == "detach" and self.t >= sb["retry_at"]:
                d = self.guard.vet(d, dict(state=self.state))
                self.decisions.append(d)
                if not d.vetoed and not self.flags.get("release_fault"):
                    self.goto("PRE_TAKEOFF_CHECK", "decision: " + "; ".join(d.reasons))

    def _remain_attached(self, why):
        self.findings.append(f"{self.t:.1f}s remain attached: {why}")
        self.armed = False
        self.T = 0.0
        self.release_lock.pretakeoff_passed = False
        self.flags["retry_at"] = self.t + 30.0
        self.flags.setdefault("pretakeoff_failures", []).append(why)
        self.goto("SENSOR_MODE", f"remain attached: {why}")

    def _s_pre_takeoff_check(self, dt):
        sb, lim = self.sub, self.cfg.safety
        if "step" not in sb:
            sb["step"] = "static"
            sb["clear_since"] = None
        if sb["step"] == "static":
            if self.soc < lim.min_departure_soc:
                self._remain_attached(f"battery SoC {self.soc:.2f} < {lim.min_departure_soc} for departure")
                return
            cm = self.decider.continue_mission(self.soc, float(np.linalg.norm(self.home - self.nav.p)), 0.0)
            if cm.action != "continue":
                self._remain_attached("insufficient energy to complete the mission after departure")
                return
            if self.wind_speed > lim.max_departure_wind:
                self._remain_attached(f"wind {self.wind_speed:.1f} m/s > departure limit {lim.max_departure_wind}")
                return
            if self.pad.mech_state != "engaged":
                self._remain_attached("mechanism self-test: unexpected state " + self.pad.mech_state)
                return
            # departure trajectory: back away along the surface normal, then climb
            n = self.plan.normal
            self.flags["departure"] = self.nav.p + n * 1.0 + (np.array([0, 0, 0.5]) if self.plan.boom == "forward" else 0)
            sb["step"] = "airspace"
            sb["t_step"] = self.t
            return
        if sb["step"] == "airspace":
            clear = not self._obstacle_near(self.cfg.safety.departure_corridor_clearance, corridor=True)
            if clear:
                sb["clear_since"] = sb["clear_since"] or self.t
            else:
                sb["clear_since"] = None
                if self.t - sb["t_step"] > 6.0:
                    self._remain_attached("departure corridor not clear (moving obstacle)")
                    return
            if sb["clear_since"] is not None and self.t - sb["clear_since"] >= 2.0:
                sb["step"] = "spin"
                sb["t_step"] = self.t
                self.low_power = False
                self.armed = True       # ATTACHED token permits arming while attached
            return
        if sb["step"] == "spin":
            ts = self.t - sb["t_step"]
            frac = min(0.3, 0.3 * ts / 0.8)
            self._attached_thrust(frac, self.R_d)
            if ts > 1.5 and self.esc is not None:
                exp = np.maximum(self.esc.rpm_expected, 1.0)
                resid = np.abs(self.esc.rpm - exp) / exp
                self.metrics["esc_residual_max"] = float(resid.max())
                if resid.max() > 0.10:
                    bad = int(np.argmax(resid))
                    self.T = 0.0
                    self._remain_attached(f"propulsion health: motor {bad+1} rpm residual {resid[bad]*100:.0f} %")
                    return
                self.release_lock.pretakeoff_passed = True
                self.goto("DETACHMENT", "pre-takeoff check passed (battery, wind, airspace, mechanism, motors)")

    def _s_detachment(self, dt):
        sb = self.sub
        if "R" not in sb:
            sb["R"] = self.R_d.copy()
            sb["released"] = False
            sb["attempts"] = 0
        if not sb["released"]:
            frac = min(1.0, 0.3 + 0.7 * self.dt_state / 1.5)
            self._attached_thrust(frac, sb["R"])
            if frac >= 1.0 and self.release_lock.allow(frac, abort_context=False):
                self.interlock.revoke(self.t, "propulsion at hover before release")
                self.mech_cmds.append("release")
                sb["released"] = True
                sb["t_rel"] = self.t
                sb["attempts"] += 1
            return
        tr = self.t - sb["t_rel"]
        self._attached_thrust(1.0, sb["R"])
        if self.pad.mech_state == "open" and (not self.is_epm or self.pad.flux_ratio < 0.1):
            self.release_lock.pretakeoff_passed = False
            self.rel = RelativeTargetFilter(self.nav.p - self.plan.target, self.nav.v, self.plan.normal, 0.02)
            self.mpc.reset()
            self.metrics["t_released"] = self.t
            self.goto("TAKEOFF_VERIFICATION", "mechanism open, separation started")
            return
        if tr > 0.6 and self.pad.mech_state == "engaged":
            if sb["attempts"] < 2:
                self.mech_cmds.append("release")
                sb["t_rel"] = self.t
                sb["attempts"] += 1
                return
            # release failed: stay attached, re-verify and power down again
            self.flags["release_fault"] = True
            self.findings.append(f"{self.t:.1f}s release mechanism fault: still engaged after 2 attempts")
            self.interlock.grant(self.t, "TEST", "still engaged after failed release (flux OK)")
            self.goto("ATTACHMENT_VERIFICATION", "release failed: re-verify attachment and remain attached")

    def _s_takeoff_verification(self, dt):
        dep = self.flags["departure"]
        e = self.nav.p - dep
        d = float(np.linalg.norm(e))
        n = unit(-e) if d > 1e-6 else np.array([0, 0, 1.0])
        # MPC towards the departure point with a gentle speed profile
        ref = np.zeros((self.mpc.N, 6))
        for k in range(self.mpc.N):
            s = max(0.0, d - 0.5 * self.mpc.h * (k + 1))
            ref[k, :3] = dep - n * s
            ref[k, 3:] = n * (0.5 if s > 0 else 0.0)
        a = self.mpc(self.nav.p, self.nav.v, ref, self.a_prev)
        self._apply_accel(a, self.plan.yaw, max_tilt=20.0)
        if d < 0.15 and np.linalg.norm(self.nav.v) < 0.2:
            self.sub["stable"] = self.sub.get("stable", 0.0) + dt
        else:
            self.sub["stable"] = 0.0
        if self.sub["stable"] > 1.5:
            self.metrics["t_departed"] = self.t
            self.rel = None
            self.goto("AUTONOMOUS_MISSION_RESUMPTION", "stable hover at departure point")

    def _s_autonomous_mission_resumption(self, dt):
        self._fly_to(self.nav.p, self.yaw_d, ctrl="lqr")
        dist = sum(np.linalg.norm(np.array(w.p) - self.nav.p) for w in self.mission.resume[:1])
        d = self.decider.continue_mission(self.soc, float(dist), float(np.linalg.norm(self.home - self.nav.p)))
        self.decisions.append(d)
        self.flags["resumed"] = True
        self.target, self.plan = None, None
        if d.action == "continue" and self.mission.resume:
            self.wp_queue = list(self.mission.resume)
            self.goto("NAVIGATION", "mission resumed: " + d.reasons[0])
        else:
            self.goto("RETURN_HOME", "no remaining waypoints" if d.action == "continue" else d.reasons[0])

    # ------------------------------------------------------------------ recovery / ending
    def _abort(self, why, blacklist=False):
        self.findings.append(f"{self.t:.1f}s abort: {why}")
        self.metrics["aborts"] = self.metrics.get("aborts", 0) + 1
        if self.target is not None:
            cid = self.target.candidate_id
            self.attempts[cid] = self.attempts.get(cid, 0) + 1
            if blacklist or self.attempts[cid] >= self.mission.max_attempts:
                c = self.map.get(cid)
                if c is not None:
                    c.blacklisted = why
        self.armed = True
        self.interlock.revoke(self.t, "abort")
        self.goto("ABORT_RECOVERY", why)

    def _s_abort_recovery(self, dt):
        sb = self.sub
        if "init" not in sb:
            sb["init"] = True
            sb["engaged"] = self.pad is not None and self.pad.mech_state in ("engaged", "engaging")
            # only hold "attached" thrust if the mechanism actually carries load; otherwise fly away
            sb["held"] = sb["engaged"] and (self.pad.flux_ratio >= 0.05 if self.is_epm else self.pad.flux_ratio >= 0.99)
            sb["R"] = self.R_d.copy()
            self.mech_cmds.append("unlock_wrist")
        if sb["engaged"]:
            if sb["held"]:
                self._attached_thrust(1.0, sb["R"])
            elif self.plan is not None:
                self._track(self.plan.standoff, 0.6, self.plan.yaw, ctrl="pid")
            if self.pad.mech_state == "engaged" and not sb.get("rel_cmd"):
                if self.release_lock.allow(1.0, abort_context=True):
                    self.mech_cmds.append("release")
                    sb["rel_cmd"] = self.t
            if self.pad.mech_state == "open":
                sb["engaged"] = False
            elif sb.get("rel_cmd") and self.t - sb["rel_cmd"] > 0.6:
                sb["rel_cmd"] = None
            return
        if self.plan is None:
            self.goto("RETURN_HOME", "no plan to recover to")
            return
        back = self.plan.standoff
        self._track(back, 0.6, self.plan.yaw, ctrl="pid")
        if np.linalg.norm(back - self.nav.p) < 0.2 and np.linalg.norm(self.nav.v) < 0.25:
            self.rel = None
            cid = self.target.candidate_id if self.target else None
            c = self.map.get(cid) if cid else None
            if c is not None and not c.blacklisted:
                self.goto("APPROACH_PLANNING", f"retry {cid} (attempt {self.attempts.get(cid, 0) + 1})")
            else:
                self.target, self.plan = None, None
                self.sub = {}
                self.goto("SURFACE_EVALUATION", "re-evaluate remaining candidates")
                self.sub["c"] = self.nav.p.copy()

    def _s_emergency_respin(self, dt):
        self.armed = True
        self.low_power = False
        self.interlock.revoke(self.t, "emergency respin")
        self._attached_thrust(1.0, self.R_d)
        if self.dt_state > 1.0:
            self._abort("emergency respin after attachment anomaly", blacklist=True)

    def _s_hover_monitor(self, dt):
        if "c" not in self.sub:
            self.sub["c"] = self.nav.p.copy()
            self.metrics["t_hover_monitor_start"] = self.t
        self._fly_to(self.sub["c"], self.yaw_d, ctrl="lqr")
        dh = float(np.linalg.norm(self.home - self.nav.p))
        if self.dt_state >= self.mission.monitor_s or self.decider.usable_j(self.soc) < self.decider.E.flight_j(dh, 40):
            self.goto("RETURN_HOME", "hover monitoring finished" if self.dt_state >= self.mission.monitor_s
                      else "energy reserve reached during hover monitoring")

    def _s_return_home(self, dt):
        tgt = self.home + np.array([0, 0, self.mission.takeoff_alt])
        d = tgt - self.nav.p
        dist = np.linalg.norm(d)
        self._track(tgt, 2.0, self.yaw_d, avoid=True)
        if dist < 0.3 and np.linalg.norm(self.nav.v) < 0.3:
            self.goto("LANDING", "above home")

    def _s_landing(self, dt):
        if "z0" not in self.sub:
            self.sub["z0"] = self.nav.p[2]
            self.sub["xy"] = self.nav.p[:2].copy()
        z_ref = max(self.home[2] - 0.3, self.sub["z0"] - 0.5 * self.dt_state)
        self._fly_to(np.r_[self.sub["xy"], z_ref], self.yaw_d, v_ref=np.array([0, 0, -0.5 if z_ref > self.home[2] else 0]))
        on_ground = self.nav.p[2] < self.home[2] + 0.2 and abs(self.nav.v[2]) < 0.15
        if on_ground:
            self.sub["g"] = self.sub.get("g", 0) + 1
        if self.sub.get("g", 0) > 25:
            self.interlock.grant(self.t, "LANDED", "ground contact verified")
            self.armed = False
            self.goto("MISSION_COMPLETE", "landed at home")

    def _s_emergency_land(self, dt):
        if "xy" not in self.sub:
            # never descend onto known structure: first step sideways away from elevated candidates
            p = self.nav.p
            push = np.zeros(2)
            for c in self.map.cands:
                if self._is_ground(c) or c.n_obs < 2:
                    continue
                q = c.axis_point if c.kind == "cylinder" else c.centre()
                d = p[:2] - q[:2]
                dist = np.linalg.norm(d)
                if q[2] < p[2] and dist < 1.5:
                    push += (d / max(dist, 1e-3)) * (1.5 - dist)
            if np.linalg.norm(push) < 1e-6 and any(not self._is_ground(c) for c in self.map.cands):
                push = np.array([-1.0, 0.0])
            step = push / max(np.linalg.norm(push), 1e-9) * 1.5 if np.linalg.norm(push) > 0 else np.zeros(2)
            self.sub["xy"] = p[:2] + step
            self.sub["z0"] = p[2]
            self.sub["t_clear"] = self.t + (2.5 if np.linalg.norm(step) > 0 else 0.0)
        if self.t < self.sub["t_clear"]:
            self._fly_to(np.r_[self.sub["xy"], self.sub["z0"]], self.yaw_d)
            return
        z_ref = self.sub["z0"] - 0.6 * (self.t - self.sub["t_clear"])
        self._fly_to(np.r_[self.sub["xy"], z_ref], self.yaw_d, v_ref=np.array([0, 0, -0.6]))
        if self.nav.p[2] < 0.2 and abs(self.nav.v[2]) < 0.2:
            self.interlock.grant(self.t, "LANDED", "emergency landing touchdown")
            self.armed = False
            self.goto("MISSION_FAILED", "emergency landed")

    def _s_mission_complete(self, dt):
        self.armed = False

    def _s_mission_failed(self, dt):
        if self.interlock.token in ("LANDED", "ATTACHED"):
            self.armed = False

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _is_ground(c):
        return c.kind == "plane" and abs(c.normal[2]) > 0.95 and abs(c.centroid[2]) < 0.3

    def _not_on_mapped_surface(self, P):
        """Drop points lying on static, well-observed surfaces of the map (they are structure, not
        moving obstacles; static structure is handled by planning and the rotor-clearance gate)."""
        keep = np.ones(len(P), bool)
        for c in self.map.cands:
            if c.n_obs < 4:
                continue
            rel = P - c.centroid
            if c.kind == "plane":
                on = np.abs(rel @ c.normal) < 0.08
                u, w = rel @ c.u, rel @ c.w
                on &= (u > c.extent[0] - 0.1) & (u < c.extent[1] + 0.1) & (w > c.extent[2] - 0.1) & (w < c.extent[3] + 0.1)
            else:
                r = P - c.axis_point
                on = np.linalg.norm(r - np.outer(r @ c.u, c.u), axis=1) < c.radius + 0.06
            keep &= ~on
        return P[keep]

    def _obstacle_near(self, radius, corridor=False):
        """Depth points (not on the target surface, not ground) inside a sphere/corridor around the vehicle."""
        p = self.nav.p
        for pts in self.depth_pts_w.values():
            if len(pts) == 0:
                continue
            P = pts
            if self.plan is not None:
                n = self.plan.normal
                if self.is_epm:
                    on_target = np.abs((P - self.plan.target) @ n) < 0.06
                else:   # points on the bar: within radius + 6 cm of its axis
                    cand = self.map.get(self.target.candidate_id) if self.target else None
                    r = cand.radius if cand else 0.03
                    ax = self.plan.long_axis
                    c0 = self.plan.target - r * n
                    rel = P - c0
                    on_target = np.linalg.norm(rel - np.outer(rel @ ax, ax), axis=1) < r + 0.06
                P = P[~on_target]
            P = P[P[:, 2] > 0.25]
            P = self._not_on_mapped_surface(P)
            if len(P) == 0:
                continue
            if corridor and self.plan is not None:
                dep = self.flags.get("departure", p + self.plan.normal)
                ax = unit(dep - p)
                rel = P - p
                along = rel @ ax
                perp = np.linalg.norm(rel - np.outer(along, ax), axis=1)
                if np.any((along > -0.2) & (along < 2.0) & (perp < radius)):
                    return True
            elif np.any(np.linalg.norm(P - p, axis=1) < radius):
                return True
        return False
