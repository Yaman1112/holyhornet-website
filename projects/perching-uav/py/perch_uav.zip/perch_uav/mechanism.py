"""Attachment modules and their holding-force / load-utilisation models.

Selected initial mechanism (see docs/perching/MECHANISM_TRADE_STUDY.md):
* Module A — dual electropermanent-magnet (EPM) pad on a 1-DOF servo boom with a passive,
  lockable 2-DOF wrist. For clean or thinly coated ferromagnetic surfaces (horizontal, inclined,
  vertical, ceiling). Zero holding power; a short current pulse switches it on/off.
* Module B — bistable, rubber-lined claw for horizontal bars/pipes/rails of 25-60 mm diameter,
  any material with adequate load rating. Zero holding power (latched).

Only one module is fitted per sortie. Neither works on every surface; the compatibility function
of each module says which surfaces it can and cannot use, and why.

This module is pure math on numbers. The simulator calls it with TRUE surface properties; the
autonomy stack calls it with ESTIMATED properties. It never imports the world model.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .geom import GRAVITY, unit
from .materials import MATERIALS

RHO_AIR = 1.225


# --------------------------------------------------------------------------- geometry
@dataclass(frozen=True)
class BoomPose:
    """Where the end effector sits on the body for one boom setting."""
    name: str
    tip: tuple            # body-frame position of the contact face at full extension [m]
    direction: tuple      # body-frame outward direction of the contact face
    long_axis: tuple      # body-frame axis along which the two EPMs are spaced
    legs_support: bool    # True if the landing feet also bear on the surface when perched
    travel: float         # compliant pad travel before the hard stop [m]


BOOM_POSES = {
    # pad below the belly on a compliant slide
    # pad 5 cm below the feet plane so the pad touches first on slopes up to ~29 deg
    "down": BoomPose("down", (0.0, 0.0, -0.15), (0.0, 0.0, -1.0), (1.0, 0.0, 0.0), True, 0.06),
    # pad forward of the front propeller discs (front disc edge at x = 0.216 m)
    "forward": BoomPose("forward", (0.275, 0.0, 0.0), (1.0, 0.0, 0.0), (0.0, 0.0, 1.0), False, 0.02),
    # pad above the rotor plane for ceilings / overhang undersides
    "up": BoomPose("up", (0.0, 0.0, 0.16), (0.0, 0.0, 1.0), (1.0, 0.0, 0.0), False, 0.03),
}


@dataclass(frozen=True)
class Capacity:
    """Holding capability at one attachment, expressed per failure mode."""
    module: str
    magnet_force: tuple = ()        # EPM: normal holding force per magnet [N]
    mu: float = 0.0                 # friction coefficient at the interface
    pull_off: float = 0.0           # claw: radial pull-off capacity [N]
    grip_normal: float = 0.0        # claw: grip normal force [N]
    radius: float = 0.0             # claw: bar radius [m]
    lateral: float = 0.0            # claw: geometric lateral capacity [N]
    notes: tuple = ()

    @property
    def total_normal(self) -> float:
        return float(sum(self.magnet_force)) if self.magnet_force else self.pull_off


@dataclass
class Utilisation:
    value: float                    # max over failure modes of load / capacity (>=1 means failure)
    mode: str
    by_mode: dict = field(default_factory=dict)

    @property
    def safety_factor(self) -> float:
        return np.inf if self.value <= 1e-9 else 1.0 / self.value


# --------------------------------------------------------------------------- module A: EPM
@dataclass(frozen=True)
class EPMPadParams:
    name: str = "epm_dual_pad"
    mass: float = 0.120                     # kg incl. boom servo and wrist
    n_magnets: int = 2
    spacing: float = 0.14                   # m between EPM centres (along long_axis)  [iteration 2: was 0.10]
    face_width: float = 0.060               # m pole-face plate width (peel lever)     [iteration 2: was 0.035]
    nominal_force: float = 150.0            # N per EPM on >= sat thickness clean mild steel, zero gap (ASSUMED)
    gap_scale_mm: float = 0.5               # F ~ 1/(1+gap/g0)^2  (ASSUMED fit, to be measured)
    saturation_thickness_mm: float = 4.0    # thinner steel saturates -> proportional loss
    roughness_gap_factor: float = 0.5       # effective gap contribution of roughness Ra
    wrist_range_deg: float = 30.0           # passive wrist compliance range (ball joint)
    min_curvature_radius: float = 0.5       # m; flatter than this counts as planar
    switch_time: float = 0.05               # s per on/off pulse
    switch_energy_j: float = 1.5            # J per pulse (capacitor discharge)
    pad_spring: float = 150.0               # N/m pad compliance spring
    footprint: float = 0.16                 # m minimum flat patch side


def epm_magnet_force(p: EPMPadParams, k_mag: float, coating_mm: float, steel_thickness_mm: float,
                     roughness_mm: float, misalignment_deg: float, curvature_radius: float | None) -> float:
    """Holding force of ONE EPM [N] (simple reluctance-gap model, see MATH_MODELS.md §5)."""
    gap = max(0.0, coating_mm) + p.roughness_gap_factor * max(0.0, roughness_mm)
    k_gap = 1.0 / (1.0 + gap / p.gap_scale_mm) ** 2
    k_thick = min(1.0, max(0.0, steel_thickness_mm) / p.saturation_thickness_mm)
    if misalignment_deg <= p.wrist_range_deg:
        k_align = 1.0
    else:  # wrist at its stop: only an edge touches
        k_align = max(0.0, 1.0 - (misalignment_deg - p.wrist_range_deg) / 10.0) * 0.3
    k_curv = 1.0 if curvature_radius is None else float(np.clip(curvature_radius / p.min_curvature_radius, 0.05, 1.0))
    return p.nominal_force * k_mag * k_gap * k_thick * k_align * k_curv


def epm_capacity(p: EPMPadParams, material: str, coating_mm: float, steel_thickness_mm: float,
                 roughness_mm: float = 0.05, misalignment_deg: float = 0.0,
                 curvature_radius: float | None = None, health: tuple = (1.0, 1.0)) -> Capacity:
    m = MATERIALS[material]
    f = epm_magnet_force(p, m["k_mag"], coating_mm, steel_thickness_mm, roughness_mm, misalignment_deg, curvature_radius)
    return Capacity(module=p.name, magnet_force=tuple(f * h for h in health[: p.n_magnets]), mu=m["mu_pad"])


def epm_utilisation(p: EPMPadParams, cap: Capacity, F, M, n, a) -> Utilisation:
    """Utilisation of the dual-EPM pad under the wrench (F, M) the SURFACE applies to the drone at
    the pad centre. n: surface outward normal (towards the drone), a: magnet spacing axis."""
    F, M, n = np.asarray(F, float), np.asarray(M, float), unit(np.asarray(n, float))
    a = unit(np.asarray(a, float) - (np.asarray(a, float) @ n) * n)
    Fn = float(F @ n)                       # >0 compression, <0 tension (magnet pulling)
    Ft = F - Fn * n
    an = np.cross(a, n)
    M_an = float(M @ an)
    M_a = float(M @ a)
    M_n = float(M @ n)
    N = np.array([Fn / 2 + M_an / p.spacing, Fn / 2 - M_an / p.spacing])
    peel = abs(M_a) / p.face_width
    fcap = np.array(cap.magnet_force) if cap.magnet_force else np.zeros(2)
    if np.any(fcap <= 1e-6):
        return Utilisation(np.inf, "no_magnetic_hold", {"tension": np.inf})
    tension = np.maximum(0.0, -N + peel)
    u_t = float(np.max(tension / fcap))
    clamp = float(np.sum(np.maximum(0.0, fcap + N - peel)))
    fric = cap.mu * clamp
    u_s = float(np.linalg.norm(Ft) / fric) if fric > 1e-9 else np.inf
    u_z = float(abs(M_n) / (fric * p.spacing / 2)) if fric > 1e-9 else np.inf
    modes = {"tension": u_t, "shear": u_s, "torsion": u_z}
    k = max(modes, key=modes.get)
    return Utilisation(modes[k], k, modes)


# --------------------------------------------------------------------------- module B: claw
@dataclass(frozen=True)
class ClawParams:
    name: str = "bistable_claw"
    mass: float = 0.110
    min_diameter: float = 0.025
    max_diameter: float = 0.060
    grip_normal: float = 120.0              # N total normal grip from the latch spring (ASSUMED)
    pull_off: float = 70.0                  # N radial pull-off with ~270 deg wrap (ASSUMED)
    lateral: float = 150.0                  # N geometric capacity across the bar
    wrap_moment_arm: float = 0.04           # m, resists roll/yaw about the claw
    switch_time: float = 0.25
    switch_energy_j: float = 3.0
    pad_spring: float = 200.0
    min_bar_length: float = 0.30
    capture_halfwidth: float = 0.035       # m lateral finger capture window either side of the palm
    vgroove_half: float = 0.03             # m half-width of the V-groove palm
    vgroove_rise: float = 0.012            # m rise of the groove flanks (self-centring)


def claw_capacity(p: ClawParams, material: str, diameter: float, misalignment_deg: float = 0.0) -> Capacity:
    m = MATERIALS[material]
    notes = []
    if not (p.min_diameter <= diameter <= p.max_diameter):
        notes.append(f"diameter {diameter*1000:.0f} mm outside {p.min_diameter*1000:.0f}-{p.max_diameter*1000:.0f} mm")
        return Capacity(module=p.name, mu=m["mu_grip"], notes=tuple(notes))
    k = 1.0 if misalignment_deg <= 15.0 else max(0.0, 1.0 - (misalignment_deg - 15.0) / 15.0)
    return Capacity(module=p.name, mu=m["mu_grip"], pull_off=p.pull_off * k, grip_normal=p.grip_normal * k,
                    radius=diameter / 2, lateral=p.lateral * k)


def claw_utilisation(p: ClawParams, cap: Capacity, F, M, n, axis) -> Utilisation:
    """n: radial direction from bar axis to the claw (outward), axis: bar axis."""
    if cap.pull_off <= 0:
        return Utilisation(np.inf, "no_grip", {"pull_off": np.inf})
    F, M = np.asarray(F, float), np.asarray(M, float)
    n = unit(np.asarray(n, float))
    e = unit(np.asarray(axis, float) - (np.asarray(axis, float) @ n) * n)
    c = np.cross(n, e)
    friction = cap.mu * cap.grip_normal
    modes = {
        "pull_off": max(0.0, -float(F @ n)) / cap.pull_off,
        "axial_slip": abs(float(F @ e)) / friction,
        "lateral": abs(float(F @ c)) / cap.lateral,
        "roll_slip": abs(float(M @ e)) / (friction * cap.radius),
        "wrap_moment": float(np.hypot(M @ n, M @ c)) / (cap.pull_off * p.wrap_moment_arm),
    }
    k = max(modes, key=modes.get)
    return Utilisation(modes[k], k, modes)


# --------------------------------------------------------------------------- static load analysis
def wind_force(wind_world: np.ndarray, cda: float = 0.09) -> np.ndarray:
    """Quasi-steady drag of the stationary airframe in wind (worst-case projected area)."""
    v = np.asarray(wind_world, float)
    return 0.5 * RHO_AIR * cda * np.linalg.norm(v) * v


def perched_pad_wrench(mass: float, R_body: np.ndarray, boom: BoomPose, wind_world, n_surface,
                       feet=None) -> tuple[np.ndarray, np.ndarray]:
    """Wrench (F, M about the pad) the surface must supply with propulsion OFF.

    Static equilibrium of the rigid vehicle: F_pad + m g + F_wind (+ F_feet) = 0. When the feet bear on
    the surface (`boom.legs_support`), the feet take compression and the tipping moment up to the
    point where the upwind feet unload; the pad then carries all tangential load plus any residual
    tension (conservative: leg friction is ignored).
    """
    g = np.array([0.0, 0.0, -GRAVITY * mass])
    Fw = wind_force(wind_world)
    r_pad = R_body @ np.array(boom.tip)                 # pad relative to CoM (world axes)
    F_ext = g + Fw                                      # applied at the CoM
    F = -F_ext
    M = np.cross(r_pad, F_ext)                          # = -((r_cg - r_pad) x F_ext), r_cg = 0
    if not boom.legs_support:
        return F, M
    n = unit(np.asarray(n_surface, float))
    Fn = float(F @ n)
    Ft = F - Fn * n
    # feet span about the pad: tipping capacity of the normal load on the feet
    span = 0.09 if feet is None else float(np.min(np.abs(np.array(feet)[:, :2])))
    M_t = M - (M @ n) * n
    if Fn >= 0:
        resist = Fn * span
        excess = max(0.0, np.linalg.norm(M_t) - resist)
        tension = excess / span
        F_pad = Ft - tension * n
        M_pad = (M @ n) * n
        return F_pad, M_pad
    # net uplift: pad takes the uplift and the full moment
    return F, M


def design_gust(mean_wind_speed: float, turbulence_std: float = 1.0) -> float:
    """Design wind speed for holding checks: mean + 3 sigma turbulence + 2 m/s margin."""
    return mean_wind_speed + 3.0 * turbulence_std + 2.0


def worst_case_utilisation(module, cap: Capacity, mass: float, R_body, boom: BoomPose, n_surface,
                           axis_or_long, wind_speed: float, feet=None, n_dirs: int = 12) -> Utilisation:
    """Max utilisation over wind directions (horizontal ring + up/down) at `wind_speed`."""
    worst = None
    dirs = [np.array([np.cos(a), np.sin(a), 0.0]) for a in np.linspace(0, 2 * np.pi, n_dirs, endpoint=False)]
    dirs += [np.array([0.0, 0.0, 1.0]), np.array([0.0, 0.0, -1.0])]
    for d in dirs:
        F, M = perched_pad_wrench(mass, R_body, boom, wind_speed * d * (0.5 if abs(d[2]) > 0.5 else 1.0),
                                  n_surface, feet)
        if isinstance(module, EPMPadParams):
            u = epm_utilisation(module, cap, F, M, n_surface, axis_or_long)
        else:
            u = claw_utilisation(module, cap, F, M, n_surface, axis_or_long)
        if worst is None or u.value > worst.value:
            worst = u
    return worst
