"""Safety layer: propulsion interlock, release interlock and the guard that vets AI decisions.

Rules enforced here (the state machine and the AI layer cannot bypass them; the actuator path
always goes through `PropulsionInterlock.filter`):

R1  Collective thrust below `min_airborne_thrust_fraction` x hover, or disarming, requires a token.
R2  Token TEST (floor 0.5 x hover) is granted only after the mechanism reports ENGAGED and the
    flux-measured safety factor >= min_verified_safety_factor.
R3  Token ATTACHED (floor 0) is granted only after the load-transfer test passed (R2 first).
R4  Token LANDED (floor 0) is granted only when ground contact is verified (conventional landing).
R5  Any attachment anomaly (flux drop, slip, mechanism not engaged) revokes TEST/ATTACHED at once.
R6  Mechanism RELEASE is permitted only while thrust >= release_thrust_fraction x hover AND the
    pre-takeoff check passed — except during an aborted attachment while still at hover thrust.
R7  AI decisions are advisory; `SafetyGuard.vet` vetoes any that conflict with R1-R6 or limits.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


class PropulsionInterlock:
    LEVELS = {"NONE": None, "TEST": 0.5, "ATTACHED": 0.0, "LANDED": 0.0}

    def __init__(self, min_fraction: float):
        self.min_fraction = min_fraction
        self.token = "NONE"
        self.log: list[tuple[float, str]] = []
        self.violations_blocked = 0

    def grant(self, t, token, reason):
        if token == "ATTACHED" and self.token != "TEST":
            self.log.append((t, f"REFUSED ATTACHED token (current {self.token}): {reason}"))
            return False
        self.token = token
        self.log.append((t, f"grant {token}: {reason}"))
        return True

    def revoke(self, t, reason):
        if self.token != "NONE":
            self.log.append((t, f"revoke {self.token}: {reason}"))
        self.token = "NONE"

    @property
    def floor(self) -> float:
        lv = self.LEVELS[self.token]
        return self.min_fraction if lv is None else lv

    def filter(self, T_cmd: float, hover_T: float, disarm_request: bool) -> tuple[float, bool]:
        """Returns (thrust allowed, disarm allowed)."""
        floor = self.floor * hover_T
        if T_cmd < floor:
            self.violations_blocked += 1
            T_cmd = floor
        can_disarm = self.token in ("ATTACHED", "LANDED")
        if disarm_request and not can_disarm:
            self.violations_blocked += 1
        return T_cmd, disarm_request and can_disarm


class ReleaseInterlock:
    def __init__(self, release_thrust_fraction=0.85):
        self.frac = release_thrust_fraction
        self.pretakeoff_passed = False
        self.blocked = 0

    def allow(self, thrust_fraction: float, abort_context: bool) -> bool:
        ok = thrust_fraction >= self.frac and (self.pretakeoff_passed or abort_context)
        if not ok:
            self.blocked += 1
        return ok


@dataclass
class Decision:
    action: str
    reasons: list = field(default_factory=list)
    inputs: dict = field(default_factory=dict)
    target: str | None = None
    vetoed: bool = False
    veto_reason: str = ""
    source: str = "decision_layer"


class SafetyGuard:
    """Vets decision-layer outputs against hard safety constraints."""

    FORBIDDEN = {"disarm", "cut_motors", "release_now", "skip_verification", "override_interlock"}

    def __init__(self, limits):
        self.limits = limits
        self.vetoes: list[Decision] = []

    def vet(self, d: Decision, ctx: dict) -> Decision:
        why = None
        if d.action in self.FORBIDDEN:
            why = f"action '{d.action}' is reserved to the safety-critical state machine"
        elif d.action == "perch":
            rep = ctx.get("report")
            if rep is None or not rep.suitable:
                why = "target has failed hard suitability gates"
            elif rep.predicted_sf < self.limits.min_safety_factor:
                why = f"predicted SF {rep.predicted_sf:.2f} < {self.limits.min_safety_factor}"
            elif ctx.get("wind", 0.0) > self.limits.max_perch_wind:
                why = "wind above perching limit"
        elif d.action == "detach":
            if ctx.get("state") != "SENSOR_MODE":
                why = "detach can only be requested from SENSOR_MODE"
        elif d.action == "hover_monitor":
            need = ctx.get("hover_energy_j", 0.0)
            if need > ctx.get("usable_energy_j", np.inf):
                why = "hover monitoring would breach the battery reserve"
        if why:
            d.vetoed, d.veto_reason = True, why
            self.vetoes.append(d)
        return d
