"""Material knowledge base (shared by the simulator and the autonomy stack).

This is a property table per material *class*, not ground truth about any particular surface.
k_mag:   magnetic attachment factor relative to clean mild steel (0 = non-ferromagnetic)
mu_pad:  friction coefficient, steel EPM pole face on the material
mu_grip: friction coefficient, rubber-lined claw on the material
mu_leg:  friction coefficient, rubber landing feet on the material
All values are representative engineering estimates (ASSUMED; to be measured on coupons).
"""

MATERIALS: dict[str, dict] = {
    "mild_steel":     dict(k_mag=1.00, mu_pad=0.35, mu_grip=0.60, mu_leg=0.55),
    "painted_steel":  dict(k_mag=1.00, mu_pad=0.30, mu_grip=0.55, mu_leg=0.50),
    "cast_iron":      dict(k_mag=0.75, mu_pad=0.35, mu_grip=0.60, mu_leg=0.55),
    "stainless_430":  dict(k_mag=0.80, mu_pad=0.30, mu_grip=0.55, mu_leg=0.50),
    "stainless_304":  dict(k_mag=0.03, mu_pad=0.30, mu_grip=0.55, mu_leg=0.50),
    "aluminium":      dict(k_mag=0.00, mu_pad=0.30, mu_grip=0.55, mu_leg=0.50),
    "concrete":       dict(k_mag=0.00, mu_pad=0.60, mu_grip=0.70, mu_leg=0.70),
    "glass":          dict(k_mag=0.00, mu_pad=0.20, mu_grip=0.35, mu_leg=0.40),
    "wood":           dict(k_mag=0.00, mu_pad=0.40, mu_grip=0.70, mu_leg=0.60),
    "grass":          dict(k_mag=0.00, mu_pad=0.50, mu_grip=0.50, mu_leg=0.60),
}

MATERIAL_NAMES = list(MATERIALS)
