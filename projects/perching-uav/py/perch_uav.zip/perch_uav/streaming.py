"""JSON-serialisable messages for live visualisation (harness side: may read truth AND estimates,
and labels which is which). Message types:

    world       once at start: surfaces (with true and declared properties), obstacles, vehicle geometry
    frame       20 Hz: truth pose, estimated pose, actuators, battery, wind, attachment, pad sensors,
                interlock token, station readings
    transition  state-machine transition (t, src, dst, why)
    event       simulator event (attach, detach, fault, crash, ...)
    map         1 Hz: perception candidate surfaces (estimates)
    reports     after each SURFACE_EVALUATION: suitability reports with every gate
    result      at the end: Simulation.results()
"""

from __future__ import annotations

import math

import numpy as np

from .autonomy import MISSION_STATES, SUPPORT_STATES
from .mechanism import BOOM_POSES


def _r(x, n=3):
    if x is None:
        return None
    if isinstance(x, (list, tuple, np.ndarray)):
        return [_r(v, n) for v in x]
    x = float(x)
    return None if not math.isfinite(x) else round(x, n)


def world_message(sim) -> dict:
    w, sc = sim.world, sim.sc
    surfs = []
    for s in w.surfaces:
        d = dict(id=s.id, kind=s.kind, material=s.material, label=s.label, center=_r(s.c),
                 coating_mm=s.coating_mm, declared_coating_mm=s.declared_coating_mm,
                 steel_thickness_mm=s.steel_thickness_mm, max_load_n=s.max_load_n,
                 declared_max_load_n=s.declared_max_load_n, k_mag=s.props["k_mag"])
        if s.kind == "plane":
            d.update(normal=_r(s.n), u=_r(s.u), w=_r(s.w), half_extents=_r(s.half_extents), thickness=s.thickness)
        else:
            d.update(axis=_r(s.a), radius=s.radius, length=s.length)
        surfs.append(d)
    vp = sim.cfg.vehicle
    a = vp.arm_length / math.sqrt(2)
    return dict(
        type="world", label="SIMULATED", scenario=sc.name, title=sc.title, module=sc.module,
        surfaces=surfs,
        obstacles=[dict(id=o.id, radius=o.radius) for o in w.obstacles],
        wind=dict(mean=_r(w.wind.mean), turbulence_std=w.wind.turbulence_std),
        illumination=w.illumination,
        mission=dict(home=_r(sc.mission.home), search=[_r(wp.p) for wp in sc.mission.search],
                     resume=[_r(wp.p) for wp in sc.mission.resume], monitor_s=sc.mission.monitor_s),
        vehicle=dict(mass=vp.mass, arm_length=vp.arm_length, prop_radius=vp.prop_radius,
                     rotor_height=vp.rotor_height, motors=[[a, a], [-a, a], [-a, -a], [a, -a]],
                     feet=_r(vp.feet), hull_half=_r(vp.hull_half),
                     booms={k: dict(tip=b.tip, direction=b.direction, long_axis=b.long_axis) for k, b in BOOM_POSES.items()},
                     cameras={"front": [0.10, 0, 0], "down": [0, 0, -0.05], "rear": [-0.10, 0, 0]},
                     payload={"anemometer": [0, 0, 0.12], "thermal_camera": [0.08, 0, -0.03],
                              "environmental": [-0.05, 0.04, 0.04], "microphone": [-0.05, -0.04, 0.04]}),
        states=dict(mission=MISSION_STATES, support=SUPPORT_STATES),
    )


def frame(sim) -> dict:
    s, a, v = sim.sim.s, sim.auto, sim.sim
    at = v.attachment
    pad = a.pad
    util = at.last_util if at is not None else None
    st = a.station
    readings = {}
    if st is not None:
        for name, ser in st.series.items():
            if ser:
                t, val, status = ser[-1]
                readings[name] = dict(t=_r(t, 1), v=_r(val, 3), status=st.health.status.get(name, status))
    rel = a.rel
    return dict(
        type="frame", t=_r(v.t, 3), state=a.state, t_in_state=_r(a.dt_state, 2),
        truth=dict(p=_r(s.p), v=_r(s.v), R=_r(s.R, 4), w=_r(s.w)),
        est=dict(p=_r(a.nav.p), v=_r(a.nav.v), R=_r(a.nav.R, 4),
                 pos_sigma=_r(np.sqrt(np.diag(a.nav.P)[:3]), 4)),
        motors=dict(thrust=_r(s.f), cmd=_r(v.f_cmd), health=_r(v.motor_health), armed=bool(v.armed)),
        battery=dict(soc=_r(v.battery.soc, 4), voltage=_r(v.battery.voltage, 2), current=_r(v.battery.current, 2),
                     power=_r(v.power_w, 1), energy_wh=_r(v.battery.energy_used_j / 3600, 3)),
        wind=dict(truth=_r(v.wind, 2), est=_r(a.wind_est, 2)),
        mechanism=dict(module=sim.sc.module, state=v.mech.state, boom=v.mech.boom_name, wrist_locked=v.mech.wrist_locked,
                       attached=at is not None, surface=None if at is None else at.surface_id,
                       capacity_n=None if at is None else _r(at.capacity.total_normal, 1),
                       utilisation=None if util is None else _r(util.value, 3),
                       mode=None if util is None else util.mode,
                       by_mode=None if util is None else {k: _r(x, 3) for k, x in util.by_mode.items()},
                       wrench_F=None if at is None else _r(at.last_F, 2), wrench_M=None if at is None else _r(at.last_M, 3),
                       tip=_r(v.tip_world())),
        pad=None if pad is None else dict(contact=bool(pad.contact), tof=_r(pad.tof_range), load_n=_r(pad.load_n, 2),
                                          flux=_r(pad.flux_ratio, 3), slip_mm=_r(pad.slip_mm, 2)),
        safety=dict(token=a.interlock.token, interlock_blocked=a.interlock.violations_blocked,
                    release_blocked=a.release_lock.blocked, vetoes=len(a.guard.vetoes)),
        target=None if a.plan is None else dict(id=a.target.candidate_id, point=_r(a.plan.target), normal=_r(a.plan.normal),
                                                standoff=_r(a.plan.standoff), boom=a.plan.boom,
                                                predicted_sf=_r(a.target.predicted_sf, 2)),
        rel=None if rel is None else dict(r=_r(rel.r), normal_distance=_r(rel.normal_distance())),
        station=None if st is None else dict(mode=st.mode, records=st.records, stored_bytes=st.stored_bytes,
                                             sent_bytes=st.sent_bytes, events=len(st.events), readings=readings),
        metrics={k: _r(x, 3) for k, x in a.metrics.items()},
        obstacles=[dict(id=o.id, p=_r(o.position(v.t)), radius=o.radius) for o in sim.world.obstacles
                   if o.position(v.t) is not None],
        crashed=v.crashed,
    )


def map_message(sim) -> dict:
    cands = []
    for c in sim.auto.map.cands:
        d = dict(id=c.id, kind=c.kind, normal=_r(c.normal), centroid=_r(c.centroid), u=_r(c.u), w=_r(c.w),
                 extent=_r(c.extent), n_obs=c.n_obs, rms_mm=_r(c.rms * 1000, 2), blacklisted=c.blacklisted,
                 material=None if not c.material_probs else max(c.material_probs, key=c.material_probs.get))
        if c.kind == "cylinder":
            d.update(axis_point=_r(c.axis_point), radius=_r(c.radius, 4))
        cands.append(d)
    return dict(type="map", t=_r(sim.sim.t, 2), label="ESTIMATED", candidates=cands)


def reports_message(sim, i) -> dict:
    t, reps = sim.auto.reports[i]
    out = []
    for r in reps:
        out.append(dict(id=r.candidate_id, suitable=r.suitable, score=_r(r.score, 3), sf=_r(r.predicted_sf, 2),
                        mode=r.failure_mode, p_ferro=_r(r.p_ferro, 2), summary=r.summary,
                        boom=None if r.plan is None else r.plan.boom,
                        soft={k: _r(x, 3) for k, x in r.soft.items()},
                        gates=[dict(name=g.name, passed=bool(g.passed), value=_jsonable(g.value),
                                    threshold=_jsonable(g.threshold), why=g.why, hard=g.hard) for g in r.gates]))
    dec = next((d for d in reversed(sim.auto.decisions) if d.action in ("perch", "hover_monitor", "return_home")), None)
    return dict(type="reports", t=_r(t, 2), label="ESTIMATED", reports=out,
                decision=None if dec is None else dict(action=dec.action, target=dec.target, reasons=dec.reasons,
                                                       vetoed=dec.vetoed, veto=dec.veto_reason))


def _jsonable(x):
    if x is None or isinstance(x, (str, bool)):
        return x
    try:
        return _r(x, 3)
    except (TypeError, ValueError):
        return str(x)
