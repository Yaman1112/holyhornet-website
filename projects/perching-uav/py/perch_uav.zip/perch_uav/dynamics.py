"""Ground-truth vehicle simulation: 6-DOF rigid body, motors, aerodynamics, battery, contacts and
the attachment constraint (see docs/perching/MATH_MODELS.md).

    p' = v
    m v' = R T e3 + F_drag + F_contacts + F_attach - m g e3
    R'   = R [w]x                          (exponential-map update)
    J w' = M_rotors + sum r_i x F_i (body) + tau_attach - w x J w - c_w w
    f_i' = (f_cmd,i - f_i) / tau_m         (exact first-order discretisation)

Contacts: penalty spring-damper normal force, tangential stick/slip spring with a Coulomb cap.
Attachment: anisotropic spring-damper between the pad and the anchor captured at engagement; it
breaks when the mechanism utilisation (mechanism.py) exceeds 1 for longer than 20 ms.
Integration: semi-implicit Euler at 500 Hz (contact stiffness chosen so that dt*omega < 0.8).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .config import BatteryParams, VehicleParams
from .geom import GRAVITY, cross, rot_exp, rot_log, rot_to_quat, unit
from .mechanism import (BOOM_POSES, Capacity, ClawParams, EPMPadParams, claw_capacity, claw_utilisation, epm_capacity,
                        epm_utilisation)
from .world import Surface, World

RHO = 1.225
SPIN = np.array([1.0, -1.0, 1.0, -1.0])


# --------------------------------------------------------------------------- battery
class Battery:
    """Equivalent-circuit pack: OCV(SoC) with knee, series resistance, coulomb counting."""

    def __init__(self, p: BatteryParams, soc0: float = 1.0):
        self.p = p
        self.soc = soc0
        self.voltage = self.ocv()
        self.current = 0.0
        self.energy_used_j = 0.0

    def ocv(self) -> float:
        p, s = self.p, self.soc
        knee = 0.08
        v_cell = p.cell_v_empty + (p.cell_v_full - p.cell_v_empty) * (0.15 + 0.85 * s if s > knee else s / knee * (0.15 + 0.85 * knee))
        return p.cells * v_cell

    def draw(self, power_w: float, dt: float) -> None:
        R = self.p.internal_resistance
        V0 = self.ocv()
        disc = V0 * V0 - 4 * R * max(power_w, 0.0)
        I = (V0 - np.sqrt(max(disc, 0.0))) / (2 * R) if disc > 0 else V0 / (2 * R)
        self.current = I
        self.voltage = V0 - I * R
        self.soc = max(0.0, self.soc - I * dt / (self.p.capacity_ah * 3600.0))
        self.energy_used_j += power_w * dt

    @property
    def energy_capacity_j(self) -> float:
        p = self.p
        return p.capacity_ah * 3600 * p.cells * 0.5 * (p.cell_v_full + p.cell_v_empty)


# --------------------------------------------------------------------------- attachment
@dataclass
class Attachment:
    surface_id: str
    anchor: np.ndarray            # world point on the surface
    n: np.ndarray                 # surface outward normal at the anchor
    long_axis: np.ndarray         # world magnet axis (EPM) or bar axis (claw)
    R0: np.ndarray                # body orientation at engagement
    capacity: object
    module: object
    wrist_locked: bool = False
    over_time: float = 0.0
    last_util: object = None
    last_F: np.ndarray = field(default_factory=lambda: np.zeros(3))
    last_M: np.ndarray = field(default_factory=lambda: np.zeros(3))
    slip: float = 0.0             # tangential displacement of the pad from the anchor [m]


class MechanismActuator:
    """Hardware-level model of the fitted module: switching delays, faults, sensors."""

    def __init__(self, params, boom: str):
        self.params = params
        self.is_epm = isinstance(params, EPMPadParams)
        self.boom = BOOM_POSES[boom]
        self.state = "open"         # open | engaging | engaged | releasing
        self.timer = 0.0
        self.energy_j = 0.0
        self.release_fault = False  # injected: mechanism fails to release
        self.engage_fault = False   # injected: mechanism fails to engage
        self.magnet_health = (1.0, 1.0)
        self.boom_name = boom
        self.wrist_locked = False

    def command(self, cmd: str) -> bool:
        if cmd == "engage" and self.state == "open":
            self.state, self.timer = "engaging", self.params.switch_time
            return True
        if cmd == "release" and self.state == "engaged":
            self.state, self.timer = "releasing", self.params.switch_time
            return True
        if cmd == "lock_wrist":
            self.wrist_locked = True
            return True
        if cmd == "unlock_wrist":
            self.wrist_locked = False
            return True
        return False


@dataclass
class TruthState:
    p: np.ndarray
    v: np.ndarray
    R: np.ndarray
    w: np.ndarray
    f: np.ndarray
    a: np.ndarray = field(default_factory=lambda: np.zeros(3))

    @property
    def w_world(self):
        return self.R @ self.w

    @property
    def q(self):
        return rot_to_quat(self.R)


class VehicleSim:
    """Ground-truth simulator. The autonomy stack must only see it through `sensors`."""

    K_CONTACT = 2.0e4      # N/m hard contact
    C_CONTACT = 150.0      # N s/m
    K_TANG = 1.0e4
    C_TANG = 50.0
    K_ATT = 4.0e4
    C_ATT = 250.0
    K_ROT_LOCK = 150.0
    C_ROT = 1.5
    K_ROT_WRIST = 0.3

    def __init__(self, vp: VehicleParams, bp: BatteryParams, world: World, module_params, boom: str,
                 p0, yaw0: float = 0.0, rng: np.random.Generator | None = None, soc0: float = 1.0):
        self.vp, self.world = vp, world
        self.rng = rng or np.random.default_rng(0)
        self.mass = vp.mass
        self.J = np.diag(vp.inertia)
        self.J_inv = np.linalg.inv(self.J)
        a = vp.arm_length / np.sqrt(2)
        self.motor_xy = np.array([[a, a], [-a, a], [-a, -a], [a, -a]])
        x, y = self.motor_xy[:, 0], self.motor_xy[:, 1]
        self.A = np.vstack([np.ones(4), y, -x, SPIN * vp.torque_coefficient])
        self.A_inv = np.linalg.inv(self.A)
        c, s = np.cos(yaw0), np.sin(yaw0)
        R0 = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
        self.s = TruthState(np.array(p0, float), np.zeros(3), R0, np.zeros(3), np.zeros(4))
        self.f_cmd = np.zeros(4)
        self.armed = False
        self.motor_health = np.ones(4)
        self.battery = Battery(bp, soc0)
        self.mech = MechanismActuator(module_params, boom)
        self.attachment: Attachment | None = None
        self.t = 0.0
        self.payload_power_w = 0.0
        self.avionics_power_w = vp.avionics_power_w
        self.power_w = 0.0
        self.events: list[tuple[float, str, str]] = []
        self.crashed = False
        self.wind = np.zeros(3)
        self.specific_force_b = np.array([0, 0, GRAVITY])
        self._fric: dict = {}
        self._side: dict = {}
        self._ge = np.ones(4)
        self._ge_counter = 0
        self.tip_contact = None           # (surface, depth, normal) of the end effector
        self.contact_force_total = 0.0
        self._near: list[Surface] = []
        self._in_contact = False
        self._imu_acc, self._imu_w, self._imu_T = np.zeros(3), np.zeros(3), 0.0
        hx, hy, hz = vp.hull_half
        self.hull = np.array([[sx * hx, sy * hy, sz * hz] for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])
        self.feet = np.array(vp.feet, float)
        self._k_power = 1.0 / (vp.figure_of_merit * np.sqrt(2 * RHO * np.pi * vp.prop_radius ** 2))

    # ------------------------------------------------------------------ helpers
    @property
    def hover_thrust(self) -> float:
        return self.mass * GRAVITY

    def tip_world(self) -> np.ndarray:
        return self.s.p + self.s.R @ np.array(self.mech.boom.tip)

    def rotor_centres(self) -> np.ndarray:
        z = self.vp.rotor_height
        return self.s.p + (self.s.R @ np.c_[self.motor_xy, np.full(4, z)].T).T

    def log_event(self, kind: str, msg: str):
        self.events.append((round(self.t, 3), kind, msg))

    def set_motor_commands(self, f_cmd: np.ndarray):
        self.f_cmd = np.clip(f_cmd, 0.0, self.vp.max_motor_thrust) if self.armed else np.zeros(4)

    # ------------------------------------------------------------------ contacts
    def _point_contact(self, key, x_w, r_w, surf: Surface, mu: float, soft=None):
        """Penalty contact at world point x_w (r_w = x_w - p). Returns (F, depth, n) or None."""
        side = self._side.get((key, surf.id))
        pen = surf.penetration(x_w, side)
        if pen is None:
            self._fric.pop((key, surf.id), None)
            self._side.pop((key, surf.id), None)
            return None
        depth, n, side = pen
        self._side[(key, surf.id)] = side
        v_pt = self.s.v + cross(self.s.w_world, r_w)
        vn = float(v_pt @ n)
        if soft is not None:
            k_soft, travel = soft
            Fn = k_soft * min(depth, travel) + (self.K_CONTACT * (depth - travel) if depth > travel else 0.0)
            Fn -= (self.C_CONTACT * 0.3 if depth <= travel else self.C_CONTACT) * vn
        else:
            Fn = self.K_CONTACT * depth - self.C_CONTACT * vn
        Fn = max(Fn, 0.0)
        vt = v_pt - vn * n
        anc = self._fric.get((key, surf.id), np.zeros(3))
        anc = anc - (anc @ n) * n + vt * self.dt
        Ft = -self.K_TANG * anc - self.C_TANG * vt
        lim = mu * Fn
        nf = np.linalg.norm(Ft)
        if nf > lim:
            Ft = Ft * (lim / nf) if nf > 1e-12 else Ft
            anc = -(Ft + self.C_TANG * vt) / self.K_TANG
        self._fric[(key, surf.id)] = anc
        return Fn * n + Ft, depth, n

    def _near_surfaces(self):
        p = self.s.p
        near = []
        for s in self.world.surfaces:
            d = s.signed_distance(p)
            if np.isfinite(d) and -1.2 < d < 0.6:
                near.append(s)
        self._near = near

    def _palm_offsets(self):
        """Contact points of the end effector relative to the tip (body frame)."""
        if self.mech.is_epm:
            return (np.zeros(3),)
        p = self.mech.params
        return (np.zeros(3), np.array([p.vgroove_half, 0.0, p.vgroove_rise]), np.array([-p.vgroove_half, 0.0, p.vgroove_rise]))

    def _claw_capture(self):
        """Bar inside the finger capture window at the end of closing? -> (surface, lateral offset)."""
        p = self.mech.params
        tip = self.tip_world()
        up = np.array([0.0, 0.0, 1.0])
        best = None
        for surf in self.world.surfaces:
            if surf.kind != "cylinder":
                continue
            rel = tip - surf.c
            if abs(rel @ surf.a) > 0.5 * surf.length:
                continue
            side = unit(cross(surf.a, up))
            lateral = abs(float(rel @ side))
            height = float(rel @ up) - surf.radius
            # the palm slides back on its compliant travel while pressing: accept the compressed face
            if lateral < p.capture_halfwidth and -(self.mech.boom.travel + 0.01) < height < 0.02:
                if best is None or lateral < best[1]:
                    best = (surf, lateral)
        return best

    # ------------------------------------------------------------------ attachment
    def _try_engage(self):
        self.mech.state = "engaged"
        if self.mech.engage_fault:
            self.log_event("mechanism", "engage commanded but mechanism did not actuate (fault)")
            return
        if not self.mech.is_epm:
            self._engage_claw()
            return
        if self.tip_contact is None:
            self.log_event("mechanism", "engaged with no surface in contact (no hold)")
            return
        surf, depth, n = self.tip_contact
        mp = self.mech.params
        d_w = self.s.R @ np.array(self.mech.boom.direction)
        mis = float(np.degrees(np.arccos(np.clip(-d_w @ n, -1, 1))))
        if self.mech.is_epm:
            curv = None if surf.kind == "plane" else surf.radius
            cap = epm_capacity(mp, surf.material, surf.coating_mm, surf.steel_thickness_mm, surf.roughness_mm, mis,
                               curv, self.mech.magnet_health)
            axis = self.s.R @ np.array(self.mech.boom.long_axis)
            if cap.total_normal < 1.0:
                self.log_event("mechanism", f"EPM switched on but surface '{surf.id}' gives no magnetic hold")
                return
        else:
            if surf.kind != "cylinder":
                self.log_event("mechanism", f"claw closed on non-bar surface '{surf.id}' (no grip)")
                return
            cap = claw_capacity(mp, surf.material, 2 * surf.radius, 0.0)
            axis = surf.a
            if cap.pull_off <= 0:
                self.log_event("mechanism", f"claw could not close on '{surf.id}': {'; '.join(cap.notes)}")
                return
        tip = self.tip_world()
        anchor = tip + depth * n
        self.attachment = Attachment(surf.id, anchor, n.copy(), unit(axis), self.s.R.copy(), cap, mp)
        self.log_event("attach", f"attached to '{surf.id}' (true capacity {cap.total_normal:.1f} N, misalignment {mis:.1f} deg)")

    def _engage_claw(self):
        mp = self.mech.params
        cap_hit = self._claw_capture()
        if cap_hit is None:
            self.log_event("mechanism", "claw closed but no bar inside the capture window (no grip)")
            return
        surf, lateral = cap_hit
        cap = claw_capacity(mp, surf.material, 2 * surf.radius, 0.0)
        if cap.pull_off <= 0:
            self.log_event("mechanism", f"claw could not close on '{surf.id}': {'; '.join(cap.notes)}")
            return
        k = 1.0 - 0.5 * (lateral / mp.capture_halfwidth) ** 2      # off-centre grasp is weaker
        cap = Capacity(cap.module, mu=cap.mu, pull_off=cap.pull_off * k, grip_normal=cap.grip_normal * k,
                       radius=cap.radius, lateral=cap.lateral * k)
        tip = self.tip_world()
        rel = tip - surf.c
        axial = (rel @ surf.a) * surf.a
        n = unit(rel - axial)
        self.attachment = Attachment(surf.id, tip.copy(), n, surf.a.copy(), self.s.R.copy(), cap, mp)
        self.log_event("attach", f"claw closed on '{surf.id}' (lateral offset {lateral*1000:.0f} mm, "
                                 f"pull-off {cap.pull_off:.0f} N)")

    def _attachment_wrench(self):
        at = self.attachment
        s = self.s
        r = s.R @ np.array(self.mech.boom.tip)
        P = s.p + r
        e = P - at.anchor
        n = at.n
        en = float(e @ n)
        v_pt = s.v + cross(s.w_world, r)
        vn = float(v_pt @ n)
        mp = self.mech.params
        if en >= 0:
            Fn = -self.K_ATT * en
        else:
            d = -en
            Fn = mp.pad_spring * min(d, self.mech.boom.travel) + (self.K_ATT * (d - self.mech.boom.travel) if d > self.mech.boom.travel else 0.0)
        Fn -= self.C_ATT * vn
        et = e - en * n
        vt = v_pt - vn * n
        Ft = -self.K_ATT * et - self.C_ATT * vt
        F = Fn * n + Ft
        th = at.R0 @ rot_log(at.R0.T @ s.R)
        locked = (not self.mech.is_epm) or self.mech.wrist_locked
        if locked:
            if not at.wrist_locked:   # re-capture reference when the wrist locks
                at.R0 = s.R.copy()
                at.wrist_locked = True
                th = np.zeros(3)
            tau = -self.K_ROT_LOCK * th - self.C_ROT * s.w_world
        else:
            ang = np.linalg.norm(th)
            lim = np.radians(mp.wrist_range_deg)
            k_stop = self.K_ROT_LOCK * max(0.0, ang - lim) / max(ang, 1e-9)
            tau = -(self.K_ROT_WRIST + k_stop) * th - 0.05 * s.w_world
        at.slip = float(np.linalg.norm(et))
        if self.mech.is_epm:
            u = epm_utilisation(mp, at.capacity, F, tau, n, at.long_axis)
        else:
            nr = unit(P - self.world.surface(at.surface_id).c - ((P - self.world.surface(at.surface_id).c) @ at.long_axis) * at.long_axis)
            u = claw_utilisation(mp, at.capacity, F, tau, nr, at.long_axis)
        at.last_util, at.last_F, at.last_M = u, F, tau
        return F, tau, r, u

    # ------------------------------------------------------------------ step
    def step(self, dt: float) -> None:
        """Advance by dt; contact phases are sub-stepped at 1 kHz for stability of the stiff contacts."""
        n = 2 if (self._in_contact or self.attachment is not None) else 1
        for _ in range(n):
            self._step_once(dt / n)
            self._imu_acc += self.specific_force_b * (dt / n)
            self._imu_w += self.s.w * (dt / n)
            self._imu_T += dt / n

    def imu_sample(self):
        """Specific force and rate averaged since the last sample (IMU anti-alias integration)."""
        if self._imu_T <= 0:
            return self.specific_force_b.copy(), self.s.w.copy()
        a, w = self._imu_acc / self._imu_T, self._imu_w / self._imu_T
        self._imu_acc, self._imu_w, self._imu_T = np.zeros(3), np.zeros(3), 0.0
        return a, w

    def _step_once(self, dt: float) -> None:
        self.dt = dt
        s, vp = self.s, self.vp
        self.wind = self.world.wind.step(self.t, dt, self.rng)

        # mechanism timers
        m = self.mech
        if m.state in ("engaging", "releasing"):
            m.timer -= dt
            if m.timer <= 0:
                m.energy_j += m.params.switch_energy_j
                self.battery.draw(m.params.switch_energy_j / dt, dt)
                if m.state == "engaging":
                    self._try_engage()
                else:
                    if m.release_fault:
                        m.state = "engaged"
                        self.log_event("mechanism", "release commanded but mechanism stayed engaged (fault)")
                    else:
                        m.state = "open"
                        if self.attachment is not None:
                            self.log_event("detach", f"released from '{self.attachment.surface_id}'")
                        self.attachment = None
                        m.wrist_locked = False

        # motors
        alpha = 1.0 - np.exp(-dt / vp.motor_time_constant)
        target = self.f_cmd * self.motor_health if self.armed else np.zeros(4)
        s.f = s.f + alpha * (target - s.f)

        # ground effect (50 Hz update)
        self._ge_counter -= 1
        if self._ge_counter <= 0:
            self._ge_counter = 10
            self._near_surfaces()
            rc = self.rotor_centres()
            down = -s.R[:, 2].reshape(1, 3)
            ge = np.ones(4)
            for i in range(4):
                t, _ = self.world.raycast(self.t, rc[i], down)
                h = float(t[0])
                if np.isfinite(h):   # Cheeseman-Bennett in-ground-effect thrust ratio
                    ge[i] = 1.0 / max(0.6, 1.0 - (vp.prop_radius / (4 * max(h, 0.05))) ** 2)
            self._ge = np.minimum(ge, 1.3)
            self._check_rotor_strike(rc)
            self._check_obstacles()

        f_eff = s.f * self._ge
        wrench = self.A @ f_eff
        T, M_b = wrench[0], wrench[1:].copy()
        F_w = s.R @ np.array([0.0, 0.0, T])
        F_w[2] -= self.mass * GRAVITY
        # aerodynamic drag (air-relative, per body axis)
        v_rel_b = s.R.T @ (s.v - self.wind)
        F_drag_b = -0.5 * RHO * np.array(vp.drag_area) * np.abs(v_rel_b) * v_rel_b
        F_w += s.R @ F_drag_b
        tau_w = np.zeros(3)

        # contacts
        self.tip_contact = None
        Fc_total = 0.0
        in_contact = False
        if self._near:
            mp = m.params
            tip_r = s.R @ np.array(m.boom.tip)
            for surf in self._near:
                props = surf.props
                for i, fb in enumerate(self.feet):
                    r = s.R @ fb
                    c = self._point_contact(("foot", i), s.p + r, r, surf, props["mu_leg"])
                    if c:
                        F_w += c[0]; tau_w += cross(r, c[0]); Fc_total += c[1] * self.K_CONTACT; in_contact = True
                for i, hb in enumerate(self.hull):
                    r = s.R @ hb
                    c = self._point_contact(("hull", i), s.p + r, r, surf, 0.4)
                    if c:
                        F_w += c[0]; tau_w += cross(r, c[0]); in_contact = True
                        if np.linalg.norm(s.v) > 2.5:
                            self._crash(f"hull impact on '{surf.id}' at {np.linalg.norm(s.v):.1f} m/s")
                if self.attachment is None or self.attachment.surface_id != surf.id:
                    mu = props["mu_pad"] if m.is_epm else props["mu_grip"]
                    for j, off in enumerate(self._palm_offsets()):
                        r = tip_r + s.R @ off
                        c = self._point_contact(("tip", j), s.p + r, r, surf, mu, soft=(mp.pad_spring, m.boom.travel))
                        if c:
                            F_w += c[0]; tau_w += cross(r, c[0]); in_contact = True
                            if self.tip_contact is None or c[1] > self.tip_contact[1]:
                                self.tip_contact = (surf, c[1], c[2])
        self.contact_force_total = Fc_total
        self._in_contact = in_contact

        if self.attachment is not None:
            at = self.attachment
            surf = self.world.surface(at.surface_id)
            F, tau, r, u = self._attachment_wrench()
            F_w += F
            tau_w += cross(r, F) + tau
            # a clamped pad face is in contact even at zero spring compression
            self.tip_contact = (surf, max(0.0015, -float((s.p + r - at.anchor) @ at.n)), at.n)
            if u.value > 1.0:
                at.over_time += dt
                if at.over_time > 0.02:
                    self.log_event("attachment_failure", f"attachment to '{at.surface_id}' failed in {u.mode} "
                                                         f"(utilisation {u.value:.2f})")
                    self.attachment = None
            else:
                at.over_time = 0.0

        # integrate (semi-implicit Euler)
        acc = F_w / self.mass
        s.v = s.v + acc * dt
        s.p = s.p + s.v * dt
        tau_b = M_b + s.R.T @ tau_w - vp.rotational_damping * s.w
        dw = self.J_inv @ (tau_b - cross(s.w, self.J @ s.w))
        s.w = s.w + dw * dt
        s.R = s.R @ rot_exp(s.w * dt)
        self._ortho = getattr(self, "_ortho", 0) + 1
        if self._ortho >= 50:
            self._ortho = 0
            U, _, Vt = np.linalg.svd(s.R)
            s.R = U @ Vt
        s.a = acc
        self.specific_force_b = s.R.T @ (acc + np.array([0.0, 0.0, GRAVITY]))

        # power
        P_rot = float(np.sum(np.maximum(s.f, 0.0) ** 1.5) * self._k_power / vp.powertrain_efficiency) if self.armed else 0.0
        if self.armed:
            P_rot += 4 * 1.5     # ESC/motor no-load losses while spinning
        self.power_w = P_rot + self.avionics_power_w + self.payload_power_w
        self.battery.draw(self.power_w, dt)
        self.t += dt

        if not self.crashed:
            if s.p[2] < -0.5:
                self._crash("below ground")
            if np.linalg.norm(s.v) > 25:
                self._crash("numerical/kinematic divergence")

    # ------------------------------------------------------------------ hazards
    def _crash(self, why):
        if not self.crashed:
            self.crashed = True
            self.log_event("crash", why)

    def _check_rotor_strike(self, rc):
        if not self.armed or np.max(self.s.f) < 0.5:
            return
        zb = self.s.R[:, 2]
        for surf in self._near:
            for c in rc:
                if surf.kind == "plane":
                    d = surf.signed_distance(c)
                    if not np.isfinite(d):
                        continue
                    reach = self.vp.prop_radius * np.sqrt(max(0.0, 1 - (zb @ surf.n) ** 2))
                    if abs(d) < reach - 0.005:
                        # disc crosses the plane: check that the crossing point lies on the patch
                        self._crash(f"rotor strike on '{surf.id}'")
                        return
                else:
                    for ang in np.linspace(0, 2 * np.pi, 8, endpoint=False):
                        rim = c + self.vp.prop_radius * (np.cos(ang) * self.s.R[:, 0] + np.sin(ang) * self.s.R[:, 1])
                        if surf.penetration(rim) is not None:
                            self._crash(f"rotor strike on '{surf.id}'")
                            return

    def _check_obstacles(self):
        for ob in self.world.obstacles:
            c = ob.position(self.t)
            if c is not None and np.linalg.norm(c - self.s.p) < ob.radius + 0.25:
                self._crash(f"collision with moving obstacle '{ob.id}'")
