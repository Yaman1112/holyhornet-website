"""Propulsion subsystem: ESC + brushless DC motor + fixed-pitch propeller, per rotor.

Model (per rotor, quasi-static electrical, first-order mechanical):

    propeller   T = kT w^2            Q = kQ w^2
    motor       V_m = R I + Ke w      Q = Kt (I - I0)          (Kt = Ke = 60 / (2 pi KV), SI units)
    ESC         V_m = d * V_bus,  d in [0, 1] (duty)            P_bus = V_m I / eta_esc
    speed       w' = (w_ss(d V_bus) - w) / tau                 (w_ss: steady speed at that voltage)
    winding     C_th Tw' = I^2 R - (Tw - T_amb) / R_th

Command interface: the flight controller asks for a thrust per rotor. The ESC computes the duty that
would give that thrust in steady state; if it needs more than the bus voltage it saturates at
d = 1 (flagged). So the thrust the vehicle actually gets depends on battery voltage, and a sagging
or depleted pack reduces authority, which the earlier fixed 9 N limit did not capture.

Losses not modelled: iron/eddy losses (part of I0 only), ESC switching losses beyond a constant
efficiency, propeller inflow effects on kT/kQ (axial speed), motor inductance. All parameters are
ASSUMED representative values for a 7-inch, 4S, ~1100 KV setup (see `PropulsionParams`) and must
be replaced by thrust-stand measurements (HARDWARE_ROADMAP H2).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np


@dataclass(frozen=True)
class PropulsionParams:
    kv_rpm_per_v: float = 1100.0      # motor velocity constant
    r_winding: float = 0.050          # ohm, phase-to-phase winding resistance
    i0: float = 0.6                   # A, no-load current (lumps iron + friction losses)
    k_t: float = 3.97e-6              # N / (rad/s)^2  -> 9.8 N at 15 000 rpm (7x4 class propeller)
    k_q: float = 5.32e-8              # N m / (rad/s)^2 -> hover shaft power = ideal power / FM 0.6
    tau: float = 0.035                # s, rotor speed time constant (motor + propeller inertia, ESC)
    esc_efficiency: float = 0.95
    r_th: float = 3.0                 # K/W winding to ambient
    c_th: float = 25.0                # J/K winding + stator heat capacity
    t_warn_c: float = 120.0           # winding temperature warning threshold
    n: int = 4

    @property
    def ke(self) -> float:            # V s / rad  (= Kt in N m / A)
        return 60.0 / (2.0 * math.pi * self.kv_rpm_per_v)

    @property
    def yaw_torque_coefficient(self) -> float:
        """Reaction torque per newton of thrust (Q/T = kQ/kT), used by the mixer."""
        return self.k_q / self.k_t

    def omega_steady(self, v_motor):
        """Steady rotor speed for a motor terminal voltage (solves R kQ/Kt w^2 + Ke w + R I0 - V = 0)."""
        v = np.asarray(v_motor, float)
        a = self.r_winding * self.k_q / self.ke
        b = self.ke
        c = self.r_winding * self.i0 - v
        disc = b * b - 4 * a * c
        w = (-b + np.sqrt(np.maximum(disc, 0.0))) / (2 * a)
        return np.where(v > self.r_winding * self.i0, w, 0.0)

    def voltage_for_omega(self, w):
        w = np.asarray(w, float)
        return self.r_winding * (self.k_q * w * w / self.ke + self.i0) + self.ke * w

    def max_thrust(self, v_bus: float) -> float:
        """Steady thrust of one rotor at full duty on the given bus voltage."""
        return float(self.k_t * self.omega_steady(v_bus) ** 2)


@dataclass
class PropulsionState:
    omega: np.ndarray = field(default_factory=lambda: np.zeros(4))      # rad/s
    temp_c: np.ndarray = field(default_factory=lambda: np.full(4, 20.0))
    current: np.ndarray = field(default_factory=lambda: np.zeros(4))    # motor current, A
    bus_current: float = 0.0
    duty: np.ndarray = field(default_factory=lambda: np.zeros(4))
    saturated: np.ndarray = field(default_factory=lambda: np.zeros(4, bool))
    power_bus: float = 0.0                                               # W drawn from the battery
    power_shaft: float = 0.0                                             # W delivered to propellers
    energy_bus_j: float = 0.0
    energy_shaft_j: float = 0.0
    energy_copper_j: float = 0.0
    energy_noload_j: float = 0.0
    energy_esc_j: float = 0.0


class Propulsion:
    def __init__(self, p: PropulsionParams | None = None, ambient_c: float = 20.0):
        self.p = p or PropulsionParams()
        self.s = PropulsionState(temp_c=np.full(self.p.n, ambient_c))
        self.ambient_c = ambient_c
        self.overtemp = np.zeros(self.p.n, bool)

    @property
    def thrust(self) -> np.ndarray:
        return self.p.k_t * self.s.omega ** 2

    @property
    def rpm(self) -> np.ndarray:
        return self.s.omega * 60.0 / (2 * math.pi)

    def commanded_omega(self, f_cmd) -> np.ndarray:
        return np.sqrt(np.maximum(np.asarray(f_cmd, float), 0.0) / self.p.k_t)

    def step(self, f_cmd, health, v_bus: float, dt: float, armed: bool) -> np.ndarray:
        """Advance rotor speeds and electrical/thermal state. Returns actual thrust per rotor [N]."""
        p, s = self.p, self.s
        v_bus = max(float(v_bus), 1e-3)
        if armed:
            w_req = self.commanded_omega(f_cmd)
            v_req = np.where(w_req > 0, p.voltage_for_omega(w_req), 0.0)
            duty = np.clip(v_req / v_bus, 0.0, 1.0)
            s.saturated = v_req > v_bus * (1 + 1e-9)
            # a degraded motor (health h) reaches a lower speed for the same drive: w * sqrt(h)
            # so that thrust scales with h (the fault-injection convention used by the scenarios)
            w_target = p.omega_steady(duty * v_bus) * np.sqrt(np.clip(health, 0.0, 1.0))
        else:
            duty = np.zeros(p.n)
            s.saturated = np.zeros(p.n, bool)
            w_target = np.zeros(p.n)
        alpha = 1.0 - math.exp(-dt / p.tau)
        s.omega = s.omega + alpha * (w_target - s.omega)
        s.duty = duty
        w = s.omega
        spinning = w > 1.0
        q = p.k_q * w * w
        i_m = np.where(spinning & armed, q / p.ke + p.i0, 0.0)
        v_m = p.r_winding * i_m + p.ke * w
        p_motor_in = v_m * i_m
        s.current = i_m
        s.power_shaft = float(np.sum(q * w))
        s.power_bus = float(np.sum(p_motor_in)) / p.esc_efficiency
        s.bus_current = s.power_bus / v_bus
        copper = i_m * i_m * p.r_winding
        s.energy_bus_j += s.power_bus * dt
        s.energy_shaft_j += s.power_shaft * dt
        s.energy_copper_j += float(np.sum(copper)) * dt
        s.energy_noload_j += float(np.sum(p.i0 * p.ke * w * (i_m > 0))) * dt
        s.energy_esc_j += (s.power_bus - float(np.sum(p_motor_in))) * dt
        s.temp_c = s.temp_c + dt * (copper - (s.temp_c - self.ambient_c) / p.r_th) / p.c_th
        self.overtemp = s.temp_c > p.t_warn_c
        return self.thrust
