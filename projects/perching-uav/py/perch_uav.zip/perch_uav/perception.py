"""Surface detection from depth images (estimated pose only).

Pipeline per depth frame:
 1. body points -> world with the ESTIMATED pose (R_hat, p_hat)
 2. sequential RANSAC plane extraction (vectorised hypotheses), SVD refinement
 3. split each plane's inliers into connected image regions (4-neighbour labelling)
 4. per region: centroid, in-plane principal axes and extents, RMS residual, image-edge contact
 5. thin elongated regions -> cylinder hypothesis (axis = major axis, radius from a circle fit
    with a width-based fallback when the visible arc is too short)
Detections are fused over time in `SurfaceMap` (data association on normal/offset/axis distance).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .geom import unit


NOISE_A, NOISE_B = 0.001, 0.0025       # nominal depth noise model sigma = a + b r^2 (sensor datasheet class)


@dataclass
class Detection:
    kind: str                     # plane | cylinder
    normal: np.ndarray            # plane: outward normal (towards viewer); cylinder: radial dir to viewer
    centroid: np.ndarray
    u: np.ndarray                 # in-plane major axis (plane) / axis (cylinder)
    w: np.ndarray
    extent: tuple                 # (umin, umax, wmin, wmax) about centroid
    rms: float
    n_points: int
    touches_edge: bool
    idx: np.ndarray               # indices into the depth message points
    radius: float = 0.0
    axis_point: np.ndarray | None = None
    range_m: float = 0.0
    material: object = None       # MaterialMsg attached by the camera pipeline
    pts: np.ndarray | None = None  # subsample of the region's world points (for extent fusion)


def plane_axes(n):
    """Canonical in-plane axes: horizontal/up for walls, world x/y-aligned for floors and ceilings."""
    n = unit(n)
    if abs(n[2]) < 0.9:
        u = unit(np.cross(np.array([0.0, 0.0, 1.0]), n))
    else:
        u = unit(np.array([1.0, 0.0, 0.0]) - n[0] * n)
    return u, np.cross(n, u)


def robust_extent(X, c, u, w, lo=2, hi=98):
    a, b = (X - c) @ u, (X - c) @ w
    return [float(np.percentile(a, lo)), float(np.percentile(a, hi)), float(np.percentile(b, lo)), float(np.percentile(b, hi))]


def ransac_planes(P, rng, max_planes=4, thr=0.02, min_inliers=15, iters=80):
    remaining = np.arange(len(P))
    planes = []
    for _ in range(max_planes):
        if len(remaining) < min_inliers:
            break
        Q = P[remaining]
        samp = rng.integers(0, len(Q), size=(iters, 3))
        tri = Q[samp]                                   # (iters, 3, 3)
        v1 = tri[:, 1] - tri[:, 0]
        v2 = tri[:, 2] - tri[:, 0]
        n = np.cross(v1, v2)
        nn = np.linalg.norm(n, axis=1)
        good = nn > 1e-6
        if not np.any(good):
            break
        n = n[good] / nn[good, None]
        d = np.einsum("ij,ij->i", n, tri[good, 0])
        res = np.abs(Q @ n.T - d)                       # (M, H)
        counts = (res < thr).sum(0)
        b = int(np.argmax(counts))
        if counts[b] < min_inliers:
            break
        inl = res[:, b] < thr
        # refine with SVD, then re-select inliers
        X = Q[inl]
        c = X.mean(0)
        _, _, Vt = np.linalg.svd(X - c, full_matrices=False)
        nr = Vt[2]
        inl = np.abs((Q - c) @ nr) < thr
        planes.append((nr, c, remaining[inl]))
        remaining = remaining[~inl]
    return planes


def _label4(img):
    """4-neighbour connected-component labelling (NumPy + BFS; no SciPy, runs in the browser)."""
    lab = np.zeros(img.shape, int)
    n = 0
    H, W = img.shape
    for y0, x0 in zip(*np.nonzero(img)):
        if lab[y0, x0]:
            continue
        n += 1
        stack = [(y0, x0)]
        lab[y0, x0] = n
        while stack:
            y, x = stack.pop()
            for yy, xx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)):
                if 0 <= yy < H and 0 <= xx < W and img[yy, xx] and not lab[yy, xx]:
                    lab[yy, xx] = n
                    stack.append((yy, xx))
    return lab, n


def _regions(idx, pix, res, min_pts):
    nx, ny = res
    img = np.zeros((ny, nx), bool)
    sel = pix[idx]
    img[sel[:, 1], sel[:, 0]] = True
    lab, n = _label4(img)
    labels = lab[sel[:, 1], sel[:, 0]]
    out = []
    for k in range(1, n + 1):
        m = labels == k
        if m.sum() >= min_pts:
            out.append(idx[m])
    return out


def _circle_fit(xy):
    A = np.c_[2 * xy, np.ones(len(xy))]
    b = (xy ** 2).sum(1)
    sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    c = sol[:2]
    r = np.sqrt(max(sol[2] + c @ c, 0.0))
    rms = float(np.sqrt(np.mean((np.linalg.norm(xy - c, axis=1) - r) ** 2)))
    return c, r, rms


GEOMETRY_RANGE = 4.5    # m; beyond this the stereo noise (> 5 cm) makes extents/flatness unreliable


def detect_surfaces(msg, R_hat, p_hat, rng, min_pts=12) -> list[Detection]:
    if msg.points_b is None or len(msg.points_b) < min_pts:
        return []
    keep = np.linalg.norm(msg.points_b, axis=1) < GEOMETRY_RANGE
    if keep.sum() < min_pts:
        return []
    orig_idx = np.nonzero(keep)[0]
    msg = type(msg)(msg.t, msg.sensor, msg.points_b[keep], msg.max_range, msg.pix[keep], msg.res)
    dets = _detect(msg, R_hat, p_hat, rng, min_pts)
    for d in dets:
        d.idx = orig_idx[d.idx]          # indices refer to the original message
    return dets


def _detect(msg, R_hat, p_hat, rng, min_pts):
    P = p_hat + msg.points_b @ R_hat.T
    view = p_hat
    nx, ny = msg.res
    out = []
    for n, c, idx in ransac_planes(P, rng):
        for reg in _regions(idx, msg.pix, msg.res, min_pts):
            X = P[reg]
            cen = X.mean(0)
            _, sv, Vt = np.linalg.svd(X - cen, full_matrices=False)
            nr = Vt[2]
            if nr @ (view - cen) < 0:
                nr = -nr
            u_p = unit(Vt[0] - (Vt[0] @ nr) * nr)          # principal axis (for the cylinder test)
            w_p = np.cross(nr, u_p)
            cu, cw = (X - cen) @ u_p, (X - cen) @ w_p
            res = (X - cen) @ nr
            # remove the expected depth noise (nominal stereo model, along the ray -> along the normal)
            rr = np.linalg.norm(msg.points_b[reg], axis=1)
            ray = msg.points_b[reg] / np.maximum(rr, 1e-9)[:, None]
            cosi = np.abs(ray @ (R_hat.T @ nr))
            sig2 = np.mean(((NOISE_A + NOISE_B * rr ** 2) * cosi) ** 2)
            rms = float(np.sqrt(max(0.0, np.mean(res ** 2) - sig2)))
            px = msg.pix[reg]
            edge = bool(np.any((px[:, 0] == 0) | (px[:, 0] == nx - 1) | (px[:, 1] == 0) | (px[:, 1] == ny - 1)))
            rng_m = float(np.linalg.norm(cen - view))
            ext = (float(cu.min()), float(cu.max()), float(cw.min()), float(cw.max()))
            width = ext[3] - ext[2]
            length = ext[1] - ext[0]
            # angular pixel footprint at this range (for the width-based radius fallback)
            pix_size = rng_m * np.radians(87.0) / nx
            sub = X if len(X) <= 150 else X[rng.choice(len(X), 150, replace=False)]
            elongated = width < 0.12 and length > 0.25 and width < 0.35 * length
            # reject degenerate (line-like) non-bar regions, e.g. where another surface crosses the
            # RANSAC plane: their SVD normal is arbitrary and disagrees with the plane normal
            if not elongated and (abs(nr @ n) < np.cos(np.radians(20)) or sv[1] / np.sqrt(len(reg)) < 0.008):
                continue
            if elongated and width < 0.01:
                continue
            if elongated:
                u, w = u_p, w_p
                # cylinder hypothesis: axis along u; circle in (nr, w) cross-section
                xy = np.c_[(X - cen) @ w, (X - cen) @ nr]
                cc, r, rms_c = _circle_fit(xy)
                # robust strip width: inter-decile range rescaled to the full width of a uniform
                # spread (immune to a few noisy edge points), plus the sampling stride of the rays
                q10, q90 = np.percentile(cw, [10, 90])
                r_width = 0.5 * ((q90 - q10) / 0.8 + pix_size)
                # circle fit on the curved cross-section (uses depth curvature); the strip width is only a
                # coarse fallback because at 1 m just one or two depth pixels span a 40 mm bar. Single bad
                # fits are rejected later by the median fusion in SurfaceMap.
                if not (0.008 < r < 0.10) or rms_c > 0.004 or rng_m > 2.0:
                    r = r_width
                    cc = np.array([0.0, -r])            # axis lies r behind the visible crest
                axis_pt = cen + cc[0] * w + cc[1] * nr
                out.append(Detection("cylinder", nr, cen, u, w, ext, rms, len(reg), edge, reg, radius=float(r),
                                     axis_point=axis_pt, range_m=rng_m, pts=sub))
            else:
                u, w = plane_axes(nr)
                ext = robust_extent(X, cen, u, w)
                out.append(Detection("plane", nr, cen, u, w, tuple(ext), rms, len(reg), edge, reg, range_m=rng_m, pts=sub))
    return out


# --------------------------------------------------------------------------- map
@dataclass
class Candidate:
    id: str
    kind: str
    normal: np.ndarray
    centroid: np.ndarray
    u: np.ndarray
    w: np.ndarray
    extent: list
    rms: float
    n_obs: int
    last_seen: float
    radius: float = 0.0
    axis_point: np.ndarray | None = None
    material_probs: dict | None = None
    rust_flag: bool = False
    weight: float = 0.0
    fully_seen: bool = False
    blacklisted: str | None = None
    history: list = field(default_factory=list)

    @property
    def offset(self):
        return float(self.normal @ self.centroid)

    @property
    def size(self):
        return (self.extent[1] - self.extent[0], self.extent[3] - self.extent[2])

    def centre(self):
        """Geometric centre of the fused extent (world)."""
        e = self.extent
        return self.centroid + 0.5 * (e[0] + e[1]) * self.u + 0.5 * (e[2] + e[3]) * self.w


class SurfaceMap:
    def __init__(self):
        self.cands: list[Candidate] = []
        self._next = 1

    def _match(self, d: Detection):
        best, bd = None, np.inf
        for c in self.cands:
            if c.kind != d.kind:
                continue
            if d.kind == "plane":
                if abs(c.normal @ d.normal) < np.cos(np.radians(12)):
                    continue
                if abs(c.normal @ (d.centroid - c.centroid)) > 0.08:
                    continue
                e = robust_extent(d.pts, c.centroid, c.u, c.w)
                gap = max(c.extent[0] - e[1], e[0] - c.extent[1], c.extent[2] - e[3], e[2] - c.extent[3], 0.0)
                if gap <= 0.15 and gap < bd:
                    best, bd = c, gap
            else:
                if abs(c.u @ d.u) < np.cos(np.radians(15)):
                    continue
                rel = d.axis_point - c.axis_point
                dist = np.linalg.norm(rel - (rel @ c.u) * c.u)
                if dist < 0.08 and dist < bd:
                    best, bd = c, dist
        return best

    def update(self, dets: list[Detection], t: float):
        for d in dets:
            wgt = d.n_points / (1.0 + d.range_m ** 2)
            c = self._match(d)
            if c is None:
                c = Candidate(f"C{self._next}", d.kind, d.normal.copy(), d.centroid.copy(), d.u.copy(), d.w.copy(),
                              list(d.extent), d.rms, 1, t, d.radius, None if d.axis_point is None else d.axis_point.copy(),
                              weight=wgt, fully_seen=not d.touches_edge,
                              history=[d.radius] if (d.kind == "cylinder" and d.range_m < 2.5) else [])
                self._next += 1
                self.cands.append(c)
            else:
                a = wgt / (c.weight + wgt)
                if d.kind == "plane":
                    nn = d.normal if d.normal @ c.normal > 0 else -d.normal
                    c.normal = unit((1 - a) * c.normal + a * nn)
                    # extents of the new view (robust, from its points) in the candidate frame
                    e = robust_extent(d.pts, c.centroid, c.u, c.w)
                    c.extent = [min(c.extent[0], e[0]), max(c.extent[1], e[1]), min(c.extent[2], e[2]), max(c.extent[3], e[3])]
                    # keep the centroid on the fused plane
                    shift = a * (c.normal @ (d.centroid - c.centroid))
                    c.centroid = c.centroid + shift * c.normal
                else:
                    uu = d.u if d.u @ c.u > 0 else -d.u
                    c.u = unit((1 - a) * c.u + a * uu)
                    c.axis_point = (1 - a) * c.axis_point + a * (d.axis_point + ((c.axis_point - d.axis_point) @ c.u) * c.u)
                    if d.range_m < 2.5:            # far fits are dominated by depth noise
                        c.history.append(d.radius)
                    if c.history:
                        c.radius = float(np.median(c.history[-15:]))  # robust to single bad fits
                    c.normal = unit((1 - a) * c.normal + a * d.normal)
                    pu = [((d.centroid + x * d.u) - c.centroid) @ c.u for x in d.extent[:2]]
                    c.extent[0], c.extent[1] = min(c.extent[0], min(pu)), max(c.extent[1], max(pu))
                c.rms = (1 - a) * c.rms + a * d.rms
                c.weight += wgt
                c.n_obs += 1
                c.last_seen = t
                c.fully_seen = c.fully_seen or not d.touches_edge
            if d.material is not None:
                c.material_probs = _fuse_probs(c.material_probs, d.material.probs)
                c.rust_flag = c.rust_flag or d.material.rust_flag
            d.candidate_id = c.id
        self._merge()
        return dets

    def _merge(self):
        """Merge coplanar, overlapping/adjacent plane candidates (fragments of one surface)."""
        changed = True
        while changed:
            changed = False
            planes = [c for c in self.cands if c.kind == "plane"]
            for i, a in enumerate(planes):
                for b in planes[i + 1:]:
                    if abs(a.normal @ b.normal) < np.cos(np.radians(10)):
                        continue
                    if abs(a.normal @ (b.centroid - a.centroid)) > 0.06:
                        continue
                    if _extent_gap(a, b.centroid, b.u, b.w, b.extent) > 0.15:
                        continue
                    keep, drop = (a, b) if a.weight >= b.weight else (b, a)
                    corners = [drop.centroid + x * drop.u + y * drop.w for x in drop.extent[:2] for y in drop.extent[2:]]
                    cu = [(q - keep.centroid) @ keep.u for q in corners]
                    cw = [(q - keep.centroid) @ keep.w for q in corners]
                    keep.extent = [min(keep.extent[0], min(cu)), max(keep.extent[1], max(cu)),
                                   min(keep.extent[2], min(cw)), max(keep.extent[3], max(cw))]
                    tot = keep.weight + drop.weight
                    keep.rms = (keep.rms * keep.weight + drop.rms * drop.weight) / tot
                    keep.weight = tot
                    keep.n_obs += drop.n_obs
                    keep.fully_seen = keep.fully_seen or drop.fully_seen
                    keep.rust_flag = keep.rust_flag or drop.rust_flag
                    if drop.material_probs is not None:
                        keep.material_probs = drop.material_probs if keep.material_probs is None else                             _fuse_probs(keep.material_probs, drop.material_probs)
                    if drop.blacklisted and not keep.blacklisted:
                        keep.blacklisted = drop.blacklisted
                    self.cands.remove(drop)
                    changed = True
                    break
                if changed:
                    break

    def get(self, cid):
        for c in self.cands:
            if c.id == cid:
                return c
        return None


def _extent_gap(c, centroid, u, w, extent):
    """Largest axis gap [m] between candidate c's extent and another planar extent (0 if overlapping)."""
    corners = [centroid + x * u + y * w for x in extent[:2] for y in extent[2:]]
    cu = [(q - c.centroid) @ c.u for q in corners]
    cw = [(q - c.centroid) @ c.w for q in corners]
    gap_u = max(c.extent[0] - max(cu), min(cu) - c.extent[1], 0.0)
    gap_w = max(c.extent[2] - max(cw), min(cw) - c.extent[3], 0.0)
    return max(gap_u, gap_w)


def _fuse_probs(prior, obs, floor=0.02):
    """Recursive Bayes with a floor so that one confident misclassification can be overturned."""
    keys = obs.keys()
    o = np.array([max(obs[k], floor) for k in keys])
    p = np.ones(len(o)) if prior is None else np.array([prior[k] for k in keys])
    post = p * o
    post /= post.sum()
    post = 0.98 * post + 0.02 / len(post)
    return dict(zip(keys, post))
