"""Moving-platform dynamics: ground vehicles, marine vessels and mobile robots.

Every platform is a rigid body whose motion is split into
  * a *base* planar motion (x, y, heading psi, speed u, yaw rate r) driven by a commanded
    speed / yaw-rate profile through first-order dynamics with acceleration limits, and
  * a *superimposed* attitude/heave motion (roll, pitch, heave) from road irregularity,
    vibration or sea state.

The full orientation is R_WP = Rz(psi) Ry(theta) Rx(phi). Angular velocity and the
accelerations of any deck point are computed analytically (see frames.point_kinematics).
Nothing assumes constant velocity: the profile can accelerate, brake, turn and stop, and
operators can change it during a run (``set_command``).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .frames import E3, euler_rates_to_omega_world, euler_to_rot, point_kinematics


@dataclass
class Pad:
    """A landing/launch pad on the deck (platform frame)."""
    name: str
    offset_p: np.ndarray            # pad centre in P [m]
    radius: float = 0.75            # usable landing radius [m]
    occupied_by: str | None = None


@dataclass
class ProfileSegment:
    t_start: float                  # [s]
    speed: float                    # commanded forward speed [m/s]
    yaw_rate: float = 0.0           # commanded yaw rate [rad/s]


@dataclass
class PlatformLimits:
    max_accel: float                # forward acceleration [m/s^2]
    max_brake: float                # braking deceleration [m/s^2] (positive number)
    max_lat_accel: float            # |u r| limit [m/s^2]
    speed_tau: float                # speed response time constant [s]
    yaw_tau: float                  # yaw-rate response time constant [s]


@dataclass
class PlatformState:
    t: float
    p: np.ndarray                   # reference point position in W
    v: np.ndarray
    a: np.ndarray
    R: np.ndarray                   # R_WP
    omega: np.ndarray               # angular velocity in W
    alpha: np.ndarray               # angular acceleration in W
    psi: float
    speed: float
    yaw_rate: float
    roll: float
    pitch: float
    heave: float = 0.0
    droll: float = 0.0
    dpitch: float = 0.0
    dheave: float = 0.0
    heave_lf: float = 0.0          # heave without the high-frequency chassis vibration (what an MRU reports)
    dheave_lf: float = 0.0


class OscillationModel:
    """Sum-of-sinusoids roll/pitch/heave model (sea state or road), analytic derivatives.

    Each channel c(t) = sum_i A_i sin(w_i t + phi_i). Components come from a seeded RNG so a
    run is repeatable. Amplitudes may scale with platform speed (road irregularity).

    With many components spread over the band and a peaked amplitude envelope (``spectral``),
    the signal is broadband like a real sea or road spectrum. A handful of pure tones would be
    unrealistically predictable for the deck-motion predictor (an AR(2k) model fits k tones
    exactly), so the platform factories use 12-16 components.
    """

    def __init__(self, rng: np.random.Generator, roll_amp: float, pitch_amp: float, heave_amp: float,
                 freqs: tuple[float, float], n: int = 4, speed_scale: float = 0.0, spectral: bool = False):
        self.speed_scale = speed_scale
        self.ch = {}
        for name, amp in (("roll", roll_amp), ("pitch", pitch_amp), ("heave", heave_amp)):
            if spectral:
                # stratified frequencies across the band, amplitude envelope peaked at the band centre
                edges = np.linspace(freqs[0], freqs[1], n + 1)
                f = edges[:-1] + rng.uniform(0, 1, n) * np.diff(edges)
                fc, bw = 0.5 * (freqs[0] + freqs[1]), 0.35 * (freqs[1] - freqs[0])
                a = np.exp(-0.5 * ((f - fc) / bw) ** 2) * rng.rayleigh(1.0, n)
                w = f * 2 * np.pi
            else:
                w = rng.uniform(freqs[0], freqs[1], n) * 2 * np.pi
                a = rng.uniform(0.5, 1.0, n)
            ph = rng.uniform(0, 2 * np.pi, n)
            a = a / np.sqrt(np.sum(a ** 2)) * amp * np.sqrt(2.0)  # RMS of the sum ~= amp
            self.ch[name] = (a, w, ph)

    def eval(self, t: float, speed: float = 0.0):
        k = 1.0 + self.speed_scale * abs(speed)
        out = {}
        for name, (a, w, ph) in self.ch.items():
            s = w * t + ph
            out[name] = (k * float(a @ np.sin(s)),
                         k * float((a * w) @ np.cos(s)),
                         -k * float((a * w * w) @ np.sin(s)))
        return out


class Platform:
    kind = "generic"

    def __init__(self, pid: str, limits: PlatformLimits, profile: list[ProfileSegment],
                 p0=(0.0, 0.0, 0.0), psi0: float = 0.0, deck_height: float = 1.5,
                 length: float = 5.0, width: float = 2.2, pads: list[Pad] | None = None,
                 osc: OscillationModel | None = None, vibration: tuple[float, float] = (0.0, 0.0),
                 initial_speed: float | None = None):
        self.id = pid
        self.limits = limits
        self.profile = sorted(profile, key=lambda s: s.t_start)
        self.deck_height = deck_height
        self.length, self.width = length, width
        self.pads = pads or [Pad("pad0", np.array([0.0, 0.0, deck_height]))]
        self.osc = osc
        self.vib_amp, self.vib_freq = vibration
        self.available = True
        self.unavailable_reason = ""
        self._override: ProfileSegment | None = None
        self.t = 0.0
        self.x, self.y = float(p0[0]), float(p0[1])
        self.z0 = float(p0[2])
        self.psi = psi0
        seg = self._command(0.0)
        self.u = seg.speed if initial_speed is None else initial_speed
        self.r = 0.0
        self.u_dot = 0.0
        self.r_dot = 0.0
        self.odometer = 0.0

    # ---------------------------------------------------------------- commands
    def _command(self, t: float) -> ProfileSegment:
        if self._override is not None:
            return self._override
        cur = self.profile[0]
        for seg in self.profile:
            if seg.t_start <= t:
                cur = seg
        return cur

    def set_command(self, speed: float, yaw_rate: float = 0.0):
        """Operator/route change: overrides the scripted profile from now on."""
        self._override = ProfileSegment(self.t, speed, yaw_rate)

    def set_unavailable(self, reason: str):
        self.available = False
        self.unavailable_reason = reason

    # ---------------------------------------------------------------- dynamics
    def step(self, dt: float):
        lim = self.limits
        cmd = self._command(self.t)
        # longitudinal: first-order response, acceleration / braking saturation
        u_dot = (cmd.speed - self.u) / lim.speed_tau
        u_dot = float(np.clip(u_dot, -lim.max_brake, lim.max_accel))
        # yaw rate: first-order, lateral-acceleration (friction / heel) limit
        r_cmd = cmd.yaw_rate
        if abs(self.u) > 0.1:
            r_max = lim.max_lat_accel / abs(self.u)
            r_cmd = float(np.clip(r_cmd, -r_max, r_max))
        r_dot = (r_cmd - self.r) / lim.yaw_tau
        # integrate (semi-implicit Euler is adequate at dt << tau; exact for the heading kinematics)
        self.u = max(0.0, self.u + u_dot * dt) if cmd.speed >= 0 else self.u + u_dot * dt
        self.r += r_dot * dt
        self.u_dot, self.r_dot = u_dot, r_dot
        if abs(self.r) > 1e-9:
            dpsi = self.r * dt
            rad = self.u / self.r
            self.x += rad * (np.sin(self.psi + dpsi) - np.sin(self.psi))
            self.y += -rad * (np.cos(self.psi + dpsi) - np.cos(self.psi))
            self.psi += dpsi
        else:
            self.x += self.u * np.cos(self.psi) * dt
            self.y += self.u * np.sin(self.psi) * dt
        self.odometer += abs(self.u) * dt
        self.t += dt

    def state(self) -> PlatformState:
        if getattr(self, "_cache_t", None) == self.t:
            return self._cache
        self._cache = self._compute_state()
        self._cache_t = self.t
        return self._cache

    def _compute_state(self) -> PlatformState:
        t = self.t
        roll = pitch = heave = 0.0
        droll = dpitch = dheave = ddroll = ddpitch = ddheave = 0.0
        if self.osc is not None:
            o = self.osc.eval(t, self.u)
            roll, droll, ddroll = o["roll"]
            pitch, dpitch, ddpitch = o["pitch"]
            heave, dheave, ddheave = o["heave"]
        heave_lf, dheave_lf = heave, dheave
        if self.vib_amp > 0:
            w = 2 * np.pi * self.vib_freq
            heave += self.vib_amp * np.sin(w * t)
            dheave += self.vib_amp * w * np.cos(w * t)
            ddheave += -self.vib_amp * w * w * np.sin(w * t)
        c, s = np.cos(self.psi), np.sin(self.psi)
        p = np.array([self.x, self.y, self.z0 + heave])
        v = np.array([self.u * c, self.u * s, dheave])
        # a = du/dt t_hat + u r n_hat
        a = np.array([self.u_dot * c - self.u * self.r * s, self.u_dot * s + self.u * self.r * c, ddheave])
        R = euler_to_rot(roll, pitch, self.psi)
        omega = euler_rates_to_omega_world(roll, pitch, self.psi, droll, dpitch, self.r)
        # angular acceleration by forward difference of the analytic omega (h small)
        h = 1e-4
        if self.osc is not None:
            o2 = self.osc.eval(t + h, self.u)
            om2 = euler_rates_to_omega_world(o2["roll"][0], o2["pitch"][0], self.psi + self.r * h,
                                             o2["roll"][1], o2["pitch"][1], self.r + self.r_dot * h)
        else:
            om2 = euler_rates_to_omega_world(0, 0, self.psi + self.r * h, 0, 0, self.r + self.r_dot * h)
        alpha = (om2 - omega) / h
        return PlatformState(t, p, v, a, R, omega, alpha, self.psi, self.u, self.r, roll, pitch,
                             heave, droll, dpitch, dheave, heave_lf, dheave_lf)

    def pad_kinematics(self, pad: Pad, st: PlatformState | None = None):
        st = st or self.state()
        p, v, a = point_kinematics(st.p, st.v, st.a, st.R, st.omega, st.alpha, pad.offset_p)
        normal = st.R @ E3
        return p, v, a, normal

    def deck_tilt(self, st: PlatformState | None = None) -> float:
        st = st or self.state()
        return float(np.arccos(np.clip(st.R[2, 2], -1.0, 1.0)))

    def contains_deck_point(self, p_p: np.ndarray) -> bool:
        return abs(p_p[0]) <= self.length / 2 and abs(p_p[1]) <= self.width / 2


# ------------------------------------------------------------------ factories
def ground_vehicle(pid: str, profile, rng, p0=(0, 0, 0), psi0=0.0, road_roughness=0.005,
                   n_pads=1, **kw) -> Platform:
    """Pickup/truck-class vehicle. Road roughness = RMS roll/pitch [rad] at 0 m/s, scaled with speed."""
    lim = PlatformLimits(max_accel=2.5, max_brake=6.0, max_lat_accel=3.0, speed_tau=2.0, yaw_tau=0.6)
    osc = OscillationModel(rng, road_roughness, road_roughness, 0.01, (0.8, 2.5), n=12, speed_scale=0.03, spectral=True)
    # pads centred on the body pitch axis: a pad far from it sees large vertical deck motion
    # (rear overhang 4.6 m -> ~±1 m/s at 0.8 deg RMS pitch), which caused hard landings in testing
    xs = [-1.0] if n_pads == 1 else [1.8 * (i - (n_pads - 1) / 2) for i in range(n_pads)]
    pads = [Pad(f"pad{i}", np.array([x, 0.0, 1.6])) for i, x in enumerate(xs)]
    return _make(Platform, "ground_vehicle", pid, lim, profile, p0, psi0, pads, osc,
                 dict(deck_height=1.6, length=6.0 + 1.8 * max(0, n_pads - 1), width=2.3,
                      vibration=(0.002, 12.0)), kw)


def marine_vessel(pid: str, profile, rng, p0=(0, 0, 0), psi0=0.0, sea_state=3, n_pads=1, **kw) -> Platform:
    """Patrol-boat-class vessel. Sea state -> RMS roll/pitch/heave (indicative values, see docs)."""
    table = {0: (0.0, 0.0, 0.0), 1: (0.01, 0.005, 0.05), 2: (0.025, 0.012, 0.15),
             3: (0.05, 0.02, 0.35), 4: (0.08, 0.035, 0.6), 5: (0.12, 0.05, 1.0)}
    roll, pitch, heave = table[int(sea_state)]
    lim = PlatformLimits(max_accel=0.4, max_brake=0.6, max_lat_accel=1.0, speed_tau=20.0, yaw_tau=6.0)
    osc = OscillationModel(rng, roll, pitch, heave, (0.06, 0.22), n=16, spectral=True)
    pads = [Pad(f"pad{i}", np.array([-5.0 - 4.0 * i, 0.0, 2.5]), radius=1.5) for i in range(n_pads)]
    return _make(Platform, "marine_vessel", pid, lim, profile, p0, psi0, pads, osc,
                 dict(deck_height=2.5, length=20.0, width=5.0), kw)


def mobile_robot(pid: str, profile, rng, p0=(0, 0, 0), psi0=0.0, **kw) -> Platform:
    lim = PlatformLimits(max_accel=1.0, max_brake=2.0, max_lat_accel=1.5, speed_tau=1.0, yaw_tau=0.4)
    osc = OscillationModel(rng, 0.01, 0.01, 0.005, (1.0, 3.0), speed_scale=0.1)
    pads = [Pad("pad0", np.array([0.0, 0.0, 0.8]), radius=0.6)]
    return _make(Platform, "mobile_robot", pid, lim, profile, p0, psi0, pads, osc,
                 dict(deck_height=0.8, length=1.6, width=1.2), kw)


def _make(cls, kind, pid, lim, profile, p0, psi0, pads, osc, defaults, kw):
    args = {**defaults, **kw}
    plat = cls(pid, lim, profile, p0=p0, psi0=psi0, pads=pads, osc=osc, **args)
    plat.kind = kind
    return plat


@dataclass
class LandingSite:
    """Approved static alternative recovery location (e.g. a field station)."""
    id: str
    p: np.ndarray
    radius: float = 2.0
    occupied: list = field(default_factory=list)
