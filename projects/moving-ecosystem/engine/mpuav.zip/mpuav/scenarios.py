"""The twelve reference scenarios, all configurable (speed, wind, sea state, sensors, controller).

Each builder returns a ready World. Missions are short so that a full launch -> mission ->
recovery cycle fits in a few simulated minutes.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace

import numpy as np

from .autopilot import Agent, AgentConfig, Mission
from .environment import Environment, WindField, Zone
from .platforms import LandingSite, ProfileSegment, ground_vehicle, marine_vessel, mobile_robot
from .quadrotor import Quadrotor, QuadParams
from .sensors import CameraModel, GnssModel
from .world import World


@dataclass
class ScenarioParams:
    seed: int = 0
    speed: float = 12.0                 # platform cruise speed [m/s]
    accel_change: float = 4.0           # speed change for scenario 5 [m/s]
    turn_rate: float = 0.06             # yaw rate for scenario 6 [rad/s]
    wind: tuple = (3.0, -2.0, 0.0)      # mean wind [m/s]
    gust: float = 1.0                   # gust sigma [m/s]
    sea_state: int = 3
    road_roughness: float = 0.005      # RMS body pitch/roll at rest [rad], grows 3 %/(m/s)
    deck_timing: bool = True           # deck-motion feed-forward + quiescent-period touchdown (deckmotion.py)
    deck_gate: str = "adaptive"        # "adaptive" | "none" (feed-forward only)
    controller: str = "pid"             # pid | lqr | mpc
    gnss: str = "standard"              # standard | rtk
    lighting: float = 1.0
    latency: float = 0.08
    loss: float = 0.02
    camera_noise_scale: float = 1.0
    t_end: float = 240.0
    extra: dict = field(default_factory=dict)


def _world(p: ScenarioParams, sites=None):
    rng = np.random.default_rng(p.seed)
    env = Environment(rng, WindField(np.random.default_rng(p.seed + 1000), mean=p.wind, gust_sigma=p.gust),
                      lighting=p.lighting)
    return World(seed=p.seed, env=env, sites=sites)


def _agent(w: World, uid: str, p: ScenarioParams, platform_id: str, pad: str, mission: Mission | None):
    gm = GnssModel.rtk() if p.gnss == "rtk" else GnssModel()
    cfg = AgentConfig(controller=p.controller, gnss=gm)
    cfg.recovery.deck_timing = bool(p.deck_timing)
    cfg.recovery.deck_gate = str(p.deck_gate)
    a = Agent(uid, Quadrotor(uid, QuadParams()), np.random.default_rng(w.rng.integers(1 << 31)), cfg)
    a.cam.m = replace(CameraModel(), sigma0=0.01 * p.camera_noise_scale, sigma_per_m=0.008 * p.camera_noise_scale)
    a.link.latency, a.link.loss = p.latency, p.loss
    a.mission = mission
    w.add_agent(a, platform_id, pad)
    return a


def _launch(w, agent, at=2.0):
    w.at(at, lambda world, a=agent: setattr(a, "launch_requested", True), f"launch request {agent.id}")


def _short_mission(kind="inspection", side=60.0, ahead=150.0, loiter=10.0, alt=30.0, cruise=14.0):
    """Two waypoints defined relative to the platform at launch (converted to world at activation)."""
    return Mission(kind=kind, waypoints=[[ahead, side, alt], [ahead * 1.6, -side, alt]],
                   loiter=[loiter, loiter], relative=True, cruise_speed=cruise)


def _road(p, speed=None, **kw):
    v = p.speed if speed is None else speed
    return [ProfileSegment(0.0, v, 0.0)]


def stationary_launch(p: ScenarioParams):
    """1. Launch from (and recover onto) a stationary vehicle."""
    w = _world(p)
    rng = np.random.default_rng(p.seed + 1)
    w.add_platform(ground_vehicle("truck", [ProfileSegment(0, 0.0)], rng, road_roughness=p.road_roughness))
    a = _agent(w, "uav1", p, "truck", "pad0", _short_mission(ahead=80, side=40))
    _launch(w, a)
    return w


def moving_launch(p: ScenarioParams):
    """2. Launch from a moving vehicle."""
    w = _world(p)
    w.add_platform(ground_vehicle("truck", _road(p), np.random.default_rng(p.seed + 1), road_roughness=p.road_roughness))
    a = _agent(w, "uav1", p, "truck", "pad0", _short_mission())
    _launch(w, a)
    return w


def moving_vehicle_recovery(p: ScenarioParams):
    """3. Recovery onto a moving ground vehicle (full cycle)."""
    return moving_launch(p)


def marine_recovery(p: ScenarioParams):
    """4. Recovery onto a moving vessel (sea state configurable)."""
    w = _world(p)
    prof = [ProfileSegment(0.0, min(p.speed, 8.0), 0.0)]
    w.add_platform(marine_vessel("vessel", prof, np.random.default_rng(p.seed + 1), sea_state=p.sea_state))
    a = _agent(w, "uav1", p, "vessel", "pad0", _short_mission(kind="maritime_monitoring", ahead=120, side=80))
    _launch(w, a)
    return w


def _on_state(agent, state):
    return lambda world: agent.state == state


def speed_change_recovery(p: ScenarioParams):
    """5. Platform changes speed (accelerates, then brakes) while the UAV is in final alignment."""
    w = moving_launch(p)
    a = w.agents["uav1"]
    plat = w.platforms["truck"]
    w.at(_on_state(a, "FINAL_ALIGNMENT"), lambda world: plat.set_command(p.speed + p.accel_change), "platform accelerates")
    w.at(lambda world: a.state == "LANDING" or (a.state == "FINAL_ALIGNMENT" and a.in_state_for() > 6.0),
         lambda world: plat.set_command(max(p.speed - p.accel_change, 2.0)), "platform brakes")
    return w


def turn_recovery(p: ScenarioParams):
    """6. Platform turns (route change) during the approach / alignment."""
    w = moving_launch(p)
    a = w.agents["uav1"]
    plat = w.platforms["truck"]
    w.at(_on_state(a, "APPROACH"), lambda world: plat.set_command(p.speed, p.turn_rate), "platform starts turning")
    return w


def rotational_motion_recovery(p: ScenarioParams):
    """7. Strong platform rotational motion: vessel in a higher sea state."""
    return marine_recovery(replace(p, sea_state=max(p.sea_state, 4)))


def gnss_denied(p: ScenarioParams):
    """8. GNSS denied over the whole area from t = 20 s; platform-escort mission flown with
    relative navigation (UWB + vision + IMU), platform broadcasts dead-reckoned positions."""
    w = moving_launch(p)
    a = w.agents["uav1"]
    a.mission = Mission(kind="platform_monitoring", waypoints=[[25.0, 20.0, 15.0], [40.0, -20.0, 15.0], [-20, 0, 15]],
                        loiter=[15.0, 15.0, 5.0], frame="platform")
    w.env.gnss_denied.append(Zone(-1e6, 1e6, -1e6, 1e6, t0=20.0))
    return w


def comm_interruption(p: ScenarioParams):
    """9. Data-link outage of ``extra['outage']`` s (default 6 s) starting when the UAV enters APPROACH."""
    w = moving_launch(p)
    a = w.agents["uav1"]
    dur = p.extra.get("outage", 6.0)
    w.at(_on_state(a, "APPROACH"), lambda world: world.env.comm_outages.append((world.t, world.t + dur)),
         f"link outage {dur:.0f} s")
    return w


def multi_drone_one_platform(p: ScenarioParams):
    """10. Three UAVs launched from one truck (three pads), staggered, recovering in sequence."""
    w = _world(p)
    w.add_platform(ground_vehicle("truck", _road(p), np.random.default_rng(p.seed + 1), n_pads=3, road_roughness=p.road_roughness))
    for i in range(3):
        m = _short_mission(ahead=100 + 40 * i, side=(-1) ** i * (40 + 20 * i), loiter=8.0)
        a = _agent(w, f"uav{i + 1}", p, "truck", f"pad{i}", m)
        _launch(w, a, at=2.0 + 15.0 * i)
    return w


def multi_drone_multi_platform(p: ScenarioParams):
    """11. Two vehicles on parallel roads 300 m apart; UAVs launch from truck A, the fleet manager
    recovers them on whichever platform is cheaper (mission ends near truck B)."""
    w = _world(p)
    w.add_platform(ground_vehicle("truckA", _road(p), np.random.default_rng(p.seed + 1), n_pads=2, road_roughness=p.road_roughness))
    w.add_platform(ground_vehicle("truckB", _road(p, speed=p.speed * 0.8), np.random.default_rng(p.seed + 2),
                                  p0=(0, 300, 0), n_pads=2, road_roughness=p.road_roughness))
    for i in range(2):
        m = Mission(kind="mapping", waypoints=[[120 + 30 * i, 150, 35], [260 + 30 * i, 290, 35]],
                    loiter=[10, 5], relative=True, cruise_speed=14)
        a = _agent(w, f"uav{i + 1}", p, "truckA", f"pad{i}", m)
        _launch(w, a, at=2.0 + 15.0 * i)
    return w


def emergency_platform_loss(p: ScenarioParams):
    """12. Home vehicle becomes unavailable (breakdown) during the mission; the UAV is reassigned
    to a second vehicle, or diverts to an approved static site if no platform is feasible."""
    site = LandingSite("field_station", np.array([400.0, -200.0, 0.0]))
    w = _world(p, sites=[site])
    w.add_platform(ground_vehicle("truckA", _road(p), np.random.default_rng(p.seed + 1), road_roughness=p.road_roughness))
    w.add_platform(ground_vehicle("truckB", _road(p, speed=p.speed * 0.9), np.random.default_rng(p.seed + 2),
                                  p0=(-150, 120, 0), road_roughness=p.road_roughness))
    a = _agent(w, "uav1", p, "truckA", "pad0", _short_mission(ahead=150, side=60, loiter=15))
    _launch(w, a)
    plat = w.platforms["truckA"]
    t_fail = p.extra.get("t_fail", 45.0)

    def fail(world):
        plat.set_unavailable("vehicle breakdown")
        plat.set_command(0.0)
    w.at(t_fail, fail, "home platform unavailable")
    return w


SCENARIOS = {
    1: ("stationary_launch", stationary_launch),
    2: ("moving_launch", moving_launch),
    3: ("moving_vehicle_recovery", moving_vehicle_recovery),
    4: ("marine_recovery", marine_recovery),
    5: ("speed_change_recovery", speed_change_recovery),
    6: ("turn_recovery", turn_recovery),
    7: ("rotational_motion_recovery", rotational_motion_recovery),
    8: ("gnss_denied", gnss_denied),
    9: ("comm_interruption", comm_interruption),
    10: ("multi_drone_one_platform", multi_drone_one_platform),
    11: ("multi_drone_multi_platform", multi_drone_multi_platform),
    12: ("emergency_platform_loss", emergency_platform_loss),
}


def build(n: int, params: ScenarioParams | None = None) -> World:
    return SCENARIOS[n][1](params or ScenarioParams())


def all_done(world) -> bool:
    """Stop condition: every UAV is secured, landed at a site, crashed, or its launch was aborted."""
    if world.t <= 5.0:
        return False
    for a in world.agents.values():
        if a.mode in ("SECURED", "CRASHED", "LANDED_SITE", "HARD_LANDING"):
            continue
        if a.mode == "ON_DECK" and any(e["event"] == "launch_aborted" for e in a.events):
            continue
        return False
    return True
