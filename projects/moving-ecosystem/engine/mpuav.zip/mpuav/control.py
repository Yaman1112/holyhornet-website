"""Flight control: geometric attitude control + interchangeable translational controllers.

Cascade
-------
  translational law (PID | LQR | MPC)  ->  a_cmd (world)  ->  thrust vector
  -> desired attitude R_d (geometric, Lee/Leok/McClamroch 2010) -> moments -> rotor forces

All translational laws act on a *tracking error* supplied by the guidance layer, which may be
absolute (waypoint flight, from the navigation filter) or relative (pad-relative, from the
relative-state estimator) with a feed-forward acceleration (e.g. the predicted pad
acceleration). The controllers never see ground truth.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .frames import E3, GRAVITY, vee


@dataclass
class AttitudeGains:
    wn_rp: float = 18.0
    wn_yaw: float = 5.0
    zeta: float = 0.8


class GeometricAttitudeController:
    def __init__(self, inertia, gains: AttitudeGains | None = None):
        g = gains or AttitudeGains()
        J = np.asarray(inertia, float)
        wn = np.array([g.wn_rp, g.wn_rp, g.wn_yaw])
        self.kR = J * wn ** 2
        self.kW = 2 * g.zeta * wn * J
        self.J = J

    def moments(self, R: np.ndarray, w: np.ndarray, Rd: np.ndarray) -> np.ndarray:
        eR = 0.5 * vee(Rd.T @ R - R.T @ Rd)
        eW = w  # desired body rate taken as zero (quasi-static R_d); adequate at these bandwidths
        return -self.kR * eR - self.kW * eW + np.cross(w, self.J * w)


def thrust_and_attitude(a_cmd: np.ndarray, yaw_d: float, R: np.ndarray, mass: float,
                        max_tilt: float = np.radians(35), a_z_lim=(-0.6 * GRAVITY, 0.9 * GRAVITY)):
    """Map a world acceleration command to collective thrust and desired attitude.

    The horizontal command is clipped so that the tilt stays below ``max_tilt``.
    """
    a = np.array(a_cmd, float)
    a[2] = np.clip(a[2], *a_z_lim)
    h_max = (a[2] + GRAVITY) * np.tan(max_tilt)
    h = np.linalg.norm(a[:2])
    if h > h_max:
        a[:2] *= h_max / h
    F = mass * (a + GRAVITY * E3)
    b3d = F / np.linalg.norm(F)
    b1c = np.array([np.cos(yaw_d), np.sin(yaw_d), 0.0])
    b2d = np.cross(b3d, b1c)
    b2d /= np.linalg.norm(b2d)
    b1d = np.cross(b2d, b3d)
    Rd = np.column_stack([b1d, b2d, b3d])
    thrust = float(F @ R[:, 2])
    return max(thrust, 0.0), Rd, a


# --------------------------------------------------------------- translational
class PIDTranslational:
    """a_cmd = a_ff - Kp e - Kd e_dot - Ki int(e), with anti-windup clamp."""
    name = "pid"

    def __init__(self, kp=(2.2, 2.2, 3.0), kd=(2.6, 2.6, 3.2), ki=(0.6, 0.6, 0.8), i_lim=2.0):
        self.kp, self.kd, self.ki = map(lambda x: np.asarray(x, float), (kp, kd, ki))
        self.i_lim = i_lim
        self.integ = np.zeros(3)

    def reset(self):
        self.integ[:] = 0.0

    def command(self, e: np.ndarray, e_dot: np.ndarray, a_ff: np.ndarray, dt: float) -> np.ndarray:
        self.integ = np.clip(self.integ + e * dt, -self.i_lim, self.i_lim)
        return a_ff - self.kp * e - self.kd * e_dot - self.ki * self.integ


class LQRTranslational(PIDTranslational):
    """Per-axis LQR on the augmented double integrator x = [int e, e, e_dot], u = a - a_ff.

    Gains from the continuous algebraic Riccati equation; same structure as PID, but the
    gains are the optimum of J = int x'Qx + r u^2 rather than hand-tuned.
    """
    name = "lqr"

    def __init__(self, q_h=(0.3, 6.0, 1.0), q_v=(1.0, 10.0, 1.0), r=1.0, i_lim=3.0):
        from scipy.linalg import solve_continuous_are   # lazy: scipy is optional for PID-only use
        A = np.array([[0, 1, 0], [0, 0, 1], [0, 0, 0]], float)
        B = np.array([[0], [0], [1]], float)
        gains = []
        for q in (q_h, q_h, q_v):
            P = solve_continuous_are(A, B, np.diag(q), np.array([[r]]))
            gains.append((B.T @ P / r).ravel())
        K = np.array(gains)
        super().__init__(kp=K[:, 1], kd=K[:, 2], ki=K[:, 0], i_lim=i_lim)
        self.K = K


def collision_avoidance_accel(p: np.ndarray, v: np.ndarray, others: list[tuple[np.ndarray, np.ndarray]],
                              d_safe: float = 4.0, gain: float = 3.0, a_max: float = 4.0) -> np.ndarray:
    """Reactive separation term (safety layer), added to the guidance command.

    For each neighbour within d_safe: push along the separation vector with magnitude growing
    as the distance shrinks, plus damping of the closing speed. Neighbour states come from
    fleet broadcasts (estimated, possibly stale), never from ground truth.
    """
    a = np.zeros(3)
    for po, vo in others:
        d = p - po
        dist = np.linalg.norm(d)
        if dist < 1e-6 or dist > d_safe:
            continue
        n = d / dist
        closing = -float((v - vo) @ n)
        a += n * (gain * (d_safe - dist) / d_safe * a_max + max(closing, 0.0) * 1.0)
    nrm = np.linalg.norm(a)
    return a if nrm <= a_max else a * a_max / nrm
