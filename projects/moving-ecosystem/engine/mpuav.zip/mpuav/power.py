"""Rotor power model shared by the simulator (energy accounting) and the planner (prediction).

Momentum theory with Glauert's forward-flight inflow, per rotor:
    v_h   = sqrt(T / (2 rho A))                       hover induced velocity
    v_i   = v_h^2 / sqrt(V_t^2 + (V_c + v_i)^2)       solved by fixed-point iteration
    P_id  = T (V_c + v_i)
    P     = P_id / FM
V_c is the component of the air-relative velocity along the thrust axis (climb / forward tilt),
V_t the in-plane component. Descent (V_c < 0) is clamped to V_c = 0, which over-estimates
power in descent (conservative; vortex-ring-state physics is not modelled).
"""

from __future__ import annotations

import numpy as np

RHO = 1.225


def rotor_power(thrust: np.ndarray, v_air_w: np.ndarray, b3_w: np.ndarray, disc_area: float,
                figure_of_merit: float) -> np.ndarray:
    t = np.maximum(np.asarray(thrust, float), 0.0)
    vc = max(float(v_air_w @ b3_w), 0.0)
    vt = float(np.linalg.norm(v_air_w - (v_air_w @ b3_w) * b3_w))
    vh2 = t / (2 * RHO * disc_area)
    vi = np.sqrt(vh2)
    for _ in range(12):
        vi = 0.5 * vi + 0.5 * vh2 / np.sqrt(vt * vt + (vc + vi) ** 2 + 1e-12)
    return t * (vc + vi) / figure_of_merit


def vehicle_power(mass: float, v_air_w: np.ndarray, drag_coeff: float, disc_area: float,
                  figure_of_merit: float, n_rotors: int = 4, accel_w=None, avionics_w: float = 15.0,
                  climb_rate: float = 0.0) -> float:
    """Steady-flight power for the planner: thrust balances weight, drag and acceleration."""
    from .frames import GRAVITY
    a = np.zeros(3) if accel_w is None else np.asarray(accel_w, float)
    drag = -drag_coeff * np.asarray(v_air_w, float)
    f = mass * (a + np.array([0, 0, GRAVITY])) - drag
    tmag = np.linalg.norm(f)
    b3 = f / tmag
    v = np.asarray(v_air_w, float).copy()
    v[2] += climb_rate
    p = rotor_power(np.full(n_rotors, tmag / n_rotors), v, b3, disc_area, figure_of_merit)
    return float(np.sum(p)) + avionics_w
