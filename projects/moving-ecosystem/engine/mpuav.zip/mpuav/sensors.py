"""Sensor models. Every sensor reads ground truth and returns a noisy, possibly missing,
time-stamped measurement. Estimators only ever see these measurements.

Noise figures are indicative of commercial components (u-blox class GNSS, consumer MEMS IMU,
DW1000-class UWB, AprilTag-class fiducial on a 640x480 camera). They are parameters, not
validated characterisations of a specific product.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .frames import E3, GRAVITY, quat_from_rotvec, quat_to_rot


class Rate:
    def __init__(self, hz: float, phase: float = 0.0):
        self.period = 1.0 / hz
        self.next = phase

    def due(self, t: float) -> bool:
        if t + 1e-9 >= self.next:
            self.next += self.period
            if self.next < t:
                self.next = t + self.period
            return True
        return False


# ---------------------------------------------------------------- messages
@dataclass
class GnssMeas:
    t: float
    p: np.ndarray
    v: np.ndarray
    sigma_p: np.ndarray
    sigma_v: float


@dataclass
class ImuMeas:
    t: float
    f_b: np.ndarray        # specific force, body
    w_b: np.ndarray        # angular rate, body
    R: np.ndarray          # AHRS attitude estimate R_WB


@dataclass
class UwbMeas:
    t: float
    anchors_p: list        # anchor positions in the platform frame
    ranges: np.ndarray
    sigma: float


@dataclass
class FiducialMeas:
    t: float
    pad: str
    r_b: np.ndarray        # pad centre relative to UAV, UAV body axes
    rel_yaw: float         # pad yaw relative to UAV yaw
    sigma: float


@dataclass
class PlatformMsg:
    """Platform navigation broadcast (its own GNSS/INS), sent over the data link."""
    t: float
    platform: str
    p: np.ndarray
    v: np.ndarray
    psi: float
    roll: float
    pitch: float
    yaw_rate: float
    sigma_p: np.ndarray
    available: bool = True
    # motion reference unit (MRU): heave from high-passed double integration of accelerations,
    # attitude rates from gyros. Heave is the vertical displacement about the mean deck level,
    # low-pass filtered before the 10 Hz broadcast (anti-aliasing: the 12 Hz chassis vibration of a
    # vehicle would otherwise alias into the samples).
    heave: float = 0.0
    heave_rate: float = 0.0
    roll_rate: float = 0.0
    pitch_rate: float = 0.0


@dataclass
class GnssModel:
    sigma_h: float = 0.25              # white noise [m]
    sigma_v: float = 0.4
    bias_sigma: float = 0.6            # slowly varying error (multipath/atmosphere) [m]
    bias_tau: float = 60.0
    sigma_vel: float = 0.08
    rate: float = 10.0

    @staticmethod
    def rtk():
        return GnssModel(sigma_h=0.02, sigma_v=0.04, bias_sigma=0.01, sigma_vel=0.03)


class Gnss:
    def __init__(self, rng: np.random.Generator, model: GnssModel | None = None):
        self.m = model or GnssModel()
        self.rng = rng
        self.rate = Rate(self.m.rate)
        self.bias = self.rng.standard_normal(3) * np.array([1, 1, 1.5]) * self.m.bias_sigma
        self.t_last = 0.0

    def _bias_step(self, t):
        dt = t - self.t_last
        self.t_last = t
        a = np.exp(-dt / self.m.bias_tau)
        s = np.array([1, 1, 1.5]) * self.m.bias_sigma
        self.bias = a * self.bias + s * np.sqrt(1 - a * a) * self.rng.standard_normal(3)

    def measure(self, t, p, v, available: bool) -> GnssMeas | None:
        if not self.rate.due(t):
            return None
        self._bias_step(t)
        if not available:
            return None
        m = self.m
        n = self.rng.standard_normal(3) * np.array([m.sigma_h, m.sigma_h, m.sigma_v])
        sig = np.sqrt(np.array([m.sigma_h, m.sigma_h, m.sigma_v]) ** 2
                      + (np.array([1, 1, 1.5]) * m.bias_sigma) ** 2)
        return GnssMeas(t, p + self.bias + n, v + self.rng.standard_normal(3) * m.sigma_vel, sig, m.sigma_vel)


class Imu:
    def __init__(self, rng, accel_sigma=0.08, gyro_sigma=0.005, accel_bias_sigma=0.05,
                 att_sigma=np.radians(0.4), rate=100.0):
        self.rng = rng
        self.accel_sigma, self.gyro_sigma, self.att_sigma = accel_sigma, gyro_sigma, att_sigma
        self.bias = rng.standard_normal(3) * accel_bias_sigma
        self.rate = Rate(rate)

    def measure(self, t, f_b, w_b, R) -> ImuMeas | None:
        if not self.rate.due(t):
            return None
        q_err = quat_from_rotvec(self.rng.standard_normal(3) * self.att_sigma)
        return ImuMeas(t, f_b + self.bias + self.rng.standard_normal(3) * self.accel_sigma,
                       w_b + self.rng.standard_normal(3) * self.gyro_sigma,
                       R @ quat_to_rot(q_err))


@dataclass
class UwbModel:
    sigma: float = 0.08
    max_range: float = 80.0
    nlos_prob: float = 0.02
    nlos_bias: tuple = (0.3, 2.0)
    rate: float = 10.0


class UwbRanging:
    def __init__(self, rng, model: UwbModel | None = None):
        self.m = model or UwbModel()
        self.rng = rng
        self.rate = Rate(self.m.rate, phase=0.003)

    def measure(self, t, p_uav, anchors_w: list, anchors_p: list, enabled=True) -> UwbMeas | None:
        if not self.rate.due(t) or not enabled:
            return None
        rngs, used = [], []
        for aw, ap in zip(anchors_w, anchors_p):
            d = float(np.linalg.norm(p_uav - aw))
            if d > self.m.max_range:
                continue
            noise = self.rng.standard_normal() * self.m.sigma
            if self.rng.random() < self.m.nlos_prob:
                noise += self.rng.uniform(*self.m.nlos_bias)
            rngs.append(d + noise)
            used.append(ap)
        if len(rngs) == 0:
            return None
        return UwbMeas(t, used, np.array(rngs), self.m.sigma)


@dataclass
class CameraModel:
    half_fov: float = np.radians(40.0)
    max_range: float = 25.0
    p_detect: float = 0.95
    sigma0: float = 0.01
    sigma_per_m: float = 0.008
    rate: float = 20.0


class FiducialCamera:
    """Downward camera (optical axis -b3) detecting the marker on a pad."""

    def __init__(self, rng, model: CameraModel | None = None):
        self.m = model or CameraModel()
        self.rng = rng
        self.rate = Rate(self.m.rate, phase=0.007)

    def measure(self, t, p_uav, R_wb, pads: list, lighting: float, enabled=True) -> FiducialMeas | None:
        """pads: list of (name, p_pad_w, R_wp)."""
        if not self.rate.due(t) or not enabled or lighting <= 0.05:
            return None
        best = None
        for name, p_pad, R_wp in pads:
            r_b = R_wb.T @ (p_pad - p_uav)
            d = float(np.linalg.norm(r_b))
            if d < 0.2 or d > self.m.max_range * min(1.0, lighting + 0.2):
                continue
            ang = np.arccos(np.clip(-r_b[2] / d, -1, 1))
            if ang > self.m.half_fov:
                continue
            if best is None or d < best[0]:
                best = (d, name, r_b, R_wp)
        if best is None or self.rng.random() > self.m.p_detect * min(1.0, lighting + 0.1):
            return None
        d, name, r_b, R_wp = best
        sig = (self.m.sigma0 + self.m.sigma_per_m * d) / max(lighting, 0.2)
        rel = R_wb.T @ R_wp
        rel_yaw = float(np.arctan2(rel[1, 0], rel[0, 0])) + self.rng.standard_normal() * np.radians(2)
        return FiducialMeas(t, name, r_b + self.rng.standard_normal(3) * sig, rel_yaw, sig)


class PlatformNav:
    """Platform's own navigation (GNSS + heading + attitude) used for its broadcasts."""

    def __init__(self, rng, gnss: GnssModel | None = None, rate=10.0, dr_drift_per_m: float = 0.02):
        self.gnss = Gnss(rng, gnss or GnssModel())
        self.rate = Rate(rate)
        self.gnss.rate = Rate(1e6)          # sampled on our own schedule
        self.rng = rng
        self.dr_k = dr_drift_per_m
        self.drift = np.zeros(3)
        self.drift_var = 0.0
        self.odo_last = None

    def measure(self, t, plat, st, available_gnss=True) -> PlatformMsg | None:
        if not self.rate.due(t):
            return None
        ds = 0.0 if self.odo_last is None else plat.odometer - self.odo_last
        self.odo_last = plat.odometer
        g = self.gnss.measure(t, st.p, st.v, available_gnss)
        if g is not None:
            p, sig = g.p, g.sigma_p
            self.drift[:] = 0.0
            self.drift_var = 0.0
        else:
            # GNSS denied: wheel/log odometry + heading dead reckoning, error random-walks with distance
            s = self.dr_k * ds
            self.drift += self.rng.standard_normal(3) * np.array([s, s, 0.2 * s])
            self.drift_var += s * s
            p = st.p + self.drift + self.gnss.bias
            sig = np.sqrt(self.gnss.m.sigma_h ** 2 + self.gnss.m.bias_sigma ** 2 + self.drift_var) * np.ones(3)
        v = st.v + self.rng.standard_normal(3) * self.gnss.m.sigma_vel
        n = self.rng.standard_normal(4) * np.radians([0.5, 0.3, 0.3, 0.3])
        m = self.rng.standard_normal(4) * np.array([0.03, 0.03, np.radians(0.2), np.radians(0.2)])
        return PlatformMsg(t, plat.id, p, v, st.psi + n[0], st.roll + n[1], st.pitch + n[2],
                           st.yaw_rate + n[3], sig, plat.available,
                           st.heave_lf + m[0], st.dheave_lf + m[1], st.droll + m[2], st.dpitch + m[3])
