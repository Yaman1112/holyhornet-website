"""Six-degree-of-freedom quadrotor model (ground truth).

    p'  = v
    m v' = R (sum_i f_i e3 + F_drag,B) - m g e3
    q'  = 1/2 q (x) [0, w_B]
    J w_B' = M - w_B x J w_B
    f_i' = (f_cmd,i - f_i) / tau_m            first-order motor/ESC/propeller lag
                                              (exact zero-order-hold discretisation)
Rotor thrust and reaction torque: f_i = k_f n_i^2,  tau_i = -s_i c_tau f_i  (s_i = +1 for CCW).
Drag: F_drag,B = -D R^T (v - w_wind)  (linear rotor/body drag, Martin & Salaun 2010 style).
Energy: per-rotor momentum theory with Glauert inflow (power.py) + avionics load.
Integration: RK4 on (p, v, q, w) at the simulation step; quaternion renormalised each step.

While the UAV is secured on a deck it is kinematically attached to its pad (``attach``):
its state is set from the pad's motion and the integrator is bypassed.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .frames import E3, GRAVITY, quat_mul, quat_normalize, quat_to_rot, rot_to_quat
from .power import rotor_power


@dataclass
class QuadParams:
    mass: float = 1.6                      # [kg]
    inertia: tuple = (0.022, 0.022, 0.040)  # [kg m^2]
    arm: float = 0.23                      # centre to rotor [m]
    c_tau: float = 0.016                   # reaction torque / thrust [m]
    f_max: float = 9.0                     # per rotor [N]   (thrust/weight ~ 2.3)
    tau_motor: float = 0.03                # [s]
    drag: tuple = (0.30, 0.30, 0.45)       # linear drag [N/(m/s)], body axes
    prop_diameter: float = 0.254           # 10 inch
    figure_of_merit: float = 0.62
    avionics_power: float = 15.0           # [W] flight controller, radios, camera, compute
    battery_wh: float = 90.0               # usable energy
    gear_height: float = 0.12              # CG height above skids [m]
    span: float = 0.65                     # tip-to-tip size used for separation checks [m]

    @property
    def disc_area(self) -> float:
        return np.pi * (0.5 * self.prop_diameter) ** 2

    def allocation(self) -> np.ndarray:
        """[T, Mx, My, Mz]^T = A f for an X configuration (FLU body axes)."""
        a = self.arm / np.sqrt(2)
        pos = np.array([[a, -a], [-a, a], [a, a], [-a, -a]])     # FR, RL, FL, RR
        spin = np.array([1.0, 1.0, -1.0, -1.0])                  # +1 = CCW seen from above
        return np.vstack([np.ones(4), pos[:, 1], -pos[:, 0], -spin * self.c_tau])


@dataclass
class QuadState:
    p: np.ndarray
    v: np.ndarray
    q: np.ndarray
    w: np.ndarray
    f: np.ndarray
    a: np.ndarray = field(default_factory=lambda: np.zeros(3))

    @property
    def R(self) -> np.ndarray:
        return quat_to_rot(self.q)


class Quadrotor:
    def __init__(self, uid: str, params: QuadParams | None = None, p0=(0, 0, 0), yaw0: float = 0.0):
        self.id = uid
        self.P = params or QuadParams()
        self.J = np.array(self.P.inertia)
        self.A = self.P.allocation()
        self.A_inv = np.linalg.inv(self.A)
        q0 = np.array([np.cos(yaw0 / 2), 0, 0, np.sin(yaw0 / 2)])
        self.s = QuadState(np.array(p0, float), np.zeros(3), q0, np.zeros(3), np.zeros(4))
        self.f_cmd = np.zeros(4)
        self.energy_j = 0.0
        self.power_w = 0.0
        self.capacity_j = self.P.battery_wh * 3600.0
        self.attached: tuple | None = None           # (platform, pad) when secured / resting on deck
        self.specific_force_b = np.array([0.0, 0.0, GRAVITY])
        self.crashed = False
        self.armed = False

    # ------------------------------------------------------------------ helpers
    @property
    def soc(self) -> float:
        return max(0.0, 1.0 - self.energy_j / self.capacity_j)

    @property
    def energy_remaining_j(self) -> float:
        return max(0.0, self.capacity_j - self.energy_j)

    def command_wrench(self, thrust: float, moment: np.ndarray):
        f = self.A_inv @ np.concatenate(([thrust], moment))
        # saturation: keep collective first, then scale the differential part
        f_mean = np.clip(thrust / 4, 0.0, self.P.f_max)
        diff = f - thrust / 4
        lo, hi = -f_mean, self.P.f_max - f_mean
        scale = 1.0
        for d in diff:
            if d > hi > 0:
                scale = min(scale, hi / d)
            elif d < lo < 0:
                scale = min(scale, lo / d)
        self.f_cmd = np.clip(f_mean + scale * diff, 0.0, self.P.f_max)

    def wrench(self, f: np.ndarray):
        u = self.A @ f
        return u[0], u[1:]

    # ------------------------------------------------------------------ attach
    def attach(self, platform, pad):
        self.attached = (platform, pad)
        self.armed = False
        self.f_cmd[:] = 0.0
        self.s.f[:] = 0.0
        self.follow_attachment()

    def detach(self):
        self.attached = None

    def follow_attachment(self):
        plat, pad = self.attached
        st = plat.state()
        p, v, a, n = plat.pad_kinematics(pad, st)
        self.s.p = p + n * self.P.gear_height
        self.s.v = v.copy()
        self.s.a = a.copy()
        self.s.q = rot_to_quat(st.R)          # UAV body aligned with the deck while secured
        self.s.w = st.R.T @ st.omega
        self.specific_force_b = st.R.T @ (a + GRAVITY * E3)

    # ------------------------------------------------------------------ dynamics
    def _deriv(self, p, v, q, w, f, wind):
        R = quat_to_rot(q)
        T, M = self.wrench(f)
        v_air_b = R.T @ (v - wind)
        f_drag_b = -np.array(self.P.drag) * v_air_b
        acc = (R @ (np.array([0.0, 0.0, T]) + f_drag_b)) / self.P.mass - GRAVITY * E3
        qd = 0.5 * quat_mul(q, np.concatenate(([0.0], w)))
        wd = (M - np.cross(w, self.J * w)) / self.J
        return v, acc, qd, wd

    def step(self, dt: float, wind: np.ndarray):
        if self.attached is not None:
            self.follow_attachment()
            self.power_w = self.P.avionics_power * 0.3   # idle electronics on deck
            self.energy_j += self.power_w * dt
            return
        s = self.s
        # motor lag (exact ZOH)
        k = np.exp(-dt / self.P.tau_motor)
        s.f = self.f_cmd + (s.f - self.f_cmd) * k
        f = s.f
        y = (s.p, s.v, s.q, s.w)

        def add(y0, dy, h):
            return tuple(a + h * b for a, b in zip(y0, dy))

        k1 = self._deriv(*y, f, wind)
        k2 = self._deriv(*add(y, k1, dt / 2), f, wind)
        k3 = self._deriv(*add(y, k2, dt / 2), f, wind)
        k4 = self._deriv(*add(y, k3, dt), f, wind)
        new = [a + dt / 6 * (b1 + 2 * b2 + 2 * b3 + b4) for a, b1, b2, b3, b4 in zip(y, k1, k2, k3, k4)]
        v_old = s.v
        s.p, s.v, s.q, s.w = new[0], new[1], quat_normalize(new[2]), new[3]
        s.a = (s.v - v_old) / dt
        R = s.R
        self.specific_force_b = R.T @ (s.a + GRAVITY * E3)
        # ground plane (world z = 0)
        if s.p[2] < self.P.gear_height and not self.crashed:
            if s.v[2] < -2.0 or np.linalg.norm(s.v[:2]) > 3.0:
                self.crashed = True
            s.p[2] = self.P.gear_height
            s.v[:] = 0.0
        # energy
        b3 = R[:, 2]
        self.power_w = float(np.sum(rotor_power(f, s.v - wind, b3, self.P.disc_area,
                                                self.P.figure_of_merit))) + self.P.avionics_power
        self.energy_j += self.power_w * dt
