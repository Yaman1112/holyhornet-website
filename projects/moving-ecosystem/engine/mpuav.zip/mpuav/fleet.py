"""Supervisory fleet manager: registration, assignment, recovery-slot scheduling, reassignment.

Division of authority
---------------------
* The fleet manager decides *what* each UAV should do (which mission, which platform/pad to
  recover on, when it may enter the landing sequence, where to hold).
* The UAV's onboard safety envelopes (safety.py) decide *whether* a launch or landing may
  proceed. The fleet manager cannot override a failed onboard check, and its launch
  authorisation is an additional gate (energy feasibility), never a bypass.

Every decision is recorded with its reasons and the alternatives considered.

Scheduling rules
----------------
* One landing token per platform: only the token holder may leave the APPROACH gate for final
  alignment; others hold at stacked holding points behind the platform (12, 16, 20 m ...).
* Pads are reserved on assignment and released at takeoff.
* Recovery platform choice: minimum estimated intercept time among available platforms with a
  free pad and a feasible energy estimate; the home platform gets a 10 s preference.
* If no platform is feasible: divert to the nearest approved static landing site.
"""

from __future__ import annotations

import numpy as np


class FleetManager:
    def __init__(self, sites=None):
        self.sites = list(sites or [])
        self.tokens: dict[str, str | None] = {}
        self.queue: dict[str, list[str]] = {}
        self.excluded: dict[str, set] = {}
        self.decisions: list[dict] = []
        self.health: dict = {}

    def decide(self, t, question, decision, reasons, **kw):
        d = {"t": round(t, 3), "by": "fleet_manager", "question": question, "decision": decision,
             "reasons": reasons, **kw}
        self.decisions.append(d)
        return d

    # ---------------------------------------------------------------- launch
    def assign_missions(self, world, agents, missions):
        """Assign missions to on-deck UAVs minimising predicted energy use (Hungarian method).

        Cost = required energy (Wh); infeasible pairs get a prohibitive cost and are not assigned.
        """
        if not agents or not missions:
            return {}
        C = np.full((len(agents), len(missions)), 1e6)
        notes = {}
        for i, a in enumerate(agents):
            for j, m in enumerate(missions):
                a.mission = m
                tr = a.trackers.get(a.home[0])
                if tr is None or not tr.initialized:
                    continue
                est = a._mission_energy(world)
                notes[(i, j)] = est
                if est.feasible:
                    C[i, j] = est.required_wh
        from scipy.optimize import linear_sum_assignment   # lazy: scipy is optional
        rows, cols = linear_sum_assignment(C)
        out = {}
        for a in agents:
            a.mission = None
        for i, j in zip(rows, cols):
            a, m = agents[i], missions[j]
            if C[i, j] >= 1e6:
                self.decide(world.t, "Which mission should the drone perform?", "none", ["no feasible mission"], uav=a.id)
                continue
            a.mission = m
            out[a.id] = j
            est = notes[(i, j)]
            self.decide(world.t, "Which mission should the drone perform?", f"mission {j} ({m.kind})",
                        [f"required {est.required_wh:.1f} Wh of {est.available_wh:.1f} Wh",
                         f"margin {est.margin_wh:.1f} Wh"], uav=a.id, breakdown=est.breakdown)
        return out

    def authorize_launch(self, agent, est):
        reasons = [f"energy required {est.required_wh:.1f} Wh, available {est.available_wh:.1f} Wh, "
                   f"margin {est.margin_wh:.1f} Wh"]
        if not est.feasible:
            return False, reasons + ["mission + return + reserve exceeds available energy"]
        return True, reasons + ["onboard launch envelope passed"]

    # -------------------------------------------------------------- recovery
    def _candidates(self, agent, world):
        out = []
        for pid, plat in world.platforms.items():
            if not plat.available or pid in self.excluded.get(agent.id, set()):
                continue
            tr = agent.trackers.get(pid)
            if tr is None or not tr.initialized or not tr.reported_available:
                continue
            pad = next((p for p in plat.pads if p.occupied_by in (None, agent.id)), None)
            if pad is None:
                continue
            off = pad.offset_p

            def pad_at(tt, tr=tr, off=off):
                return tr.predict(tt, with_cov=False).point(off)[0]
            est = agent.energy.return_estimate(agent.nav.p, world.t, pad_at, world.wind_report(agent.nav.p),
                                               agent.quad.energy_remaining_j, agent.quad.capacity_j)
            cost = est.intercept_time - (10.0 if agent.home and pid == agent.home[0] else 0.0)
            out.append((cost, plat, pad, est))
        return sorted(out, key=lambda c: c[0])

    def request_recovery(self, agent, world, reason="return requested"):
        cands = self._candidates(agent, world)
        feasible = [c for c in cands if c[3].feasible]
        best_effort = not feasible and bool(cands) and not self.sites
        if best_effort:
            feasible = [min(cands, key=lambda c: -c[3].margin_wh if np.isfinite(c[3].margin_wh) else np.inf)]
        alts = [{"platform": c[1].id, "pad": c[2].name, "intercept_s": round(float(c[3].intercept_time), 1),
                 "margin_wh": round(float(c[3].margin_wh), 2), "feasible": bool(c[3].feasible)} for c in cands]
        if feasible:
            _, plat, pad, est = feasible[0]
            self._release_reservations(agent, world)
            pad.occupied_by = agent.id
            agent.assign_recovery(plat, pad.name, world, reason=reason)
            self.queue.setdefault(plat.id, [])
            if agent.id not in self.queue[plat.id]:
                self.queue[plat.id].append(agent.id)
            self.decide(world.t, "Which platform should recover this drone?", f"{plat.id}/{pad.name}",
                        [reason, f"earliest feasible intercept {est.intercept_time:.1f} s",
                         f"energy margin {est.margin_wh:.1f} Wh"]
                        + (["BEST EFFORT: no candidate meets the energy rule and no approved site exists"] if best_effort else []),
                        uav=agent.id, alternatives=alts)
            return True
        # no platform: alternative static site
        site = self._nearest_site(agent)
        self._release_reservations(agent, world)
        if site is not None:
            agent.site = site
            agent.mode = "DIVERT"
            agent.state = "TO_SITE"
            agent.log("divert", site=site.id, reason=reason)
            self.decide(world.t, "Should the drone continue, return or divert?", f"divert to {site.id}",
                        [reason, "no available platform with a free pad and feasible energy"],
                        uav=agent.id, alternatives=alts)
            return False
        self.decide(world.t, "Should the drone continue, return or divert?", "hold",
                    [reason, "no platform and no approved site; holding and re-evaluating"],
                    uav=agent.id, alternatives=alts)
        return False

    def _nearest_site(self, agent):
        if not self.sites:
            return None
        return min(self.sites, key=lambda s: np.linalg.norm(s.p[:2] - agent.nav.p[:2]))

    def _release_reservations(self, agent, world):
        for pid, plat in world.platforms.items():
            for pad in plat.pads:
                if pad.occupied_by == agent.id and agent.quad.attached is None:
                    pad.occupied_by = None
            if self.tokens.get(pid) == agent.id:
                self.tokens[pid] = None
            if agent.id in self.queue.get(pid, []):
                self.queue[pid].remove(agent.id)

    def platform_lost(self, agent, world, reason="platform unavailable"):
        if agent.target:
            self.excluded.setdefault(agent.id, set()).add(agent.target[0])
        agent.log("reassignment", reason=reason)
        self.decide(world.t, "Should another platform take over?", "reassign", [reason], uav=agent.id)
        agent.go_arounds = 0
        if agent.mode not in ("RECOVERY", "HOLD"):
            agent.mode = "RECOVERY"
        self.request_recovery(agent, world, reason=reason)
        if agent.mode in ("RECOVERY", "HOLD"):
            agent.set_state("PLATFORM_REACQUISITION")

    def pad_free_for(self, agent, world) -> bool:
        plat = world.platforms[agent.target[0]]
        pad = next(p for p in plat.pads if p.name == agent.target[1])
        return pad.occupied_by in (None, agent.id)

    def has_slot(self, agent, world) -> bool:
        pid = agent.target[0]
        q = self.queue.setdefault(pid, [])
        if agent.id not in q:
            q.append(agent.id)
        holder = self.tokens.get(pid)
        if holder is None or holder == agent.id:
            if holder is None:
                # first in queue gets the token
                if q[0] == agent.id:
                    self.tokens[pid] = agent.id
                    self.decide(world.t, "Which drone lands next?", agent.id, ["first in recovery queue"], platform=pid)
                    return True
            else:
                return True
        k = q.index(agent.id)
        agent.hold_point_rel = np.array([-18.0 - 4.0 * k, 6.0 * ((k % 2) * 2 - 1), 12.0 + 4.0 * k])
        return False

    def recovered(self, agent, world):
        pid = agent.target[0] if agent.target else None
        if pid and self.tokens.get(pid) == agent.id:
            self.tokens[pid] = None
        if pid and agent.id in self.queue.get(pid, []):
            self.queue[pid].remove(agent.id)

    def tick(self, world):
        """1 Hz supervision: platform availability, fleet health."""
        for a in world.agents.values():
            if a.mode in ("RECOVERY", "HOLD") and a.target:
                plat = world.platforms[a.target[0]]
                if not plat.available:
                    self.platform_lost(a, world, reason=f"{plat.id} unavailable: {plat.unavailable_reason}")
            self.health[a.id] = {"mode": a.mode, "state": a.state, "soc": round(a.quad.soc, 3),
                                 "rel_std": round(a.rel.hpos_std, 3)}
