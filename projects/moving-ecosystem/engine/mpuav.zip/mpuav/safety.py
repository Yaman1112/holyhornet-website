"""Launch and recovery safety envelopes (pure functions, independently testable).

Each evaluation returns a list of ``Check`` records (name, value, limit, pass/fail) so every
go/no-go decision is explainable and logged. These checks are the *only* path to launch or
landing authorisation: the mission manager / fleet manager can request a launch or assign a
pad, but cannot bypass a failed check.

Limit values are engineering placeholders for a 1.6 kg quadrotor; they are configuration,
not validated certification limits.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class Check:
    name: str
    value: float
    limit: float
    ok: bool
    unit: str = ""
    note: str = ""

    def as_dict(self):
        return {"name": self.name, "value": round(float(self.value), 4), "limit": self.limit,
                "ok": bool(self.ok), "unit": self.unit, "note": self.note}


def _le(name, value, limit, unit="", note=""):
    return Check(name, float(value), float(limit), bool(value <= limit), unit, note)


def _ge(name, value, limit, unit="", note=""):
    return Check(name, float(value), float(limit), bool(value >= limit), unit, note)


@dataclass
class LaunchLimits:
    max_platform_speed: float = 22.0          # [m/s]  (~80 km/h)
    max_platform_accel: float = 1.5           # [m/s^2] predicted over the launch window
    max_platform_yaw_rate: float = 0.12       # [rad/s]
    max_deck_tilt_deg: float = 8.0
    max_wind: float = 12.0                    # [m/s]
    max_airspeed: float = 20.0                # UAV airspeed needed to keep station at departure
    min_soc: float = 0.35
    min_obstacle_clearance: float = 12.0      # [m] horizontal clearance around the pad
    max_tracker_age: float = 0.5              # [s]
    max_tracker_pos_std: float = 2.0          # [m]
    window: float = 10.0                      # [s] look-ahead used for predicted motion


def evaluate_launch(lim: LaunchLimits, *, pred_now, preds_window, wind: np.ndarray, soc: float,
                    deck_tilt: float, obstacle_clearance: float, energy_ok: bool,
                    energy_margin: float, sensors_ok: bool, comm_ok: bool,
                    uav_max_ground_speed: float = 18.0, speed_margin: float = 2.0) -> list[Check]:
    v_p = pred_now.v
    spd_max = max([float(np.linalg.norm(p.v[:2])) for p in preds_window] + [float(np.linalg.norm(v_p[:2]))])
    acc = max(np.linalg.norm(p.a[:2]) for p in preds_window)
    yaw = max(abs(p.yaw_rate) for p in preds_window)
    air = float(np.linalg.norm(v_p - wind))     # airspeed at the moment of release
    pos_std = float(np.sqrt(np.trace(pred_now.cov_p[:2, :2])))
    return [
        _le("platform_speed", np.linalg.norm(v_p[:2]), lim.max_platform_speed, "m/s"),
        _le("platform_speed_vs_uav", spd_max, uav_max_ground_speed - speed_margin, "m/s",
            "recovery requires matching the platform speed with margin"),
        _le("platform_accel_predicted", acc, lim.max_platform_accel, "m/s^2", f"max over {lim.window:.0f} s"),
        _le("platform_yaw_rate_predicted", yaw, lim.max_platform_yaw_rate, "rad/s"),
        _le("deck_tilt", np.degrees(deck_tilt), lim.max_deck_tilt_deg, "deg"),
        _le("wind_speed", np.linalg.norm(wind), lim.max_wind, "m/s"),
        _le("release_airspeed", air, lim.max_airspeed, "m/s", "|v_platform - wind|"),
        _ge("battery_soc", soc, lim.min_soc),
        _ge("obstacle_clearance", obstacle_clearance, lim.min_obstacle_clearance, "m"),
        _le("tracker_age", pred_now.age, lim.max_tracker_age, "s"),
        _le("tracker_pos_std", pos_std, lim.max_tracker_pos_std, "m"),
        _ge("energy_margin", energy_margin, 0.0, "Wh", "mission + return + reserve" if energy_ok else "insufficient"),
        Check("sensors_healthy", float(sensors_ok), 1.0, bool(sensors_ok)),
        Check("link_up", float(comm_ok), 1.0, bool(comm_ok)),
    ]


@dataclass
class RecoveryLimits:
    approach_gate_height: float = 6.0         # above pad [m]
    approach_gate_back: float = 8.0           # behind pad along platform heading [m]
    align_height: float = 2.5                 # final alignment height above pad [m]
    align_pos_tol: float = 0.25               # [m] horizontal estimated error to start descent
    align_vel_tol: float = 0.50               # [m/s]
    align_dwell: float = 1.5                  # [s] stable before descent
    align_timeout: float = 25.0
    descent_rate: float = 0.6                 # [m/s] relative to the pad
    flare_height: float = 0.8                 # [m] above the pad: slow down for touchdown
    flare_rate: float = 0.35                  # [m/s]
    # deck-motion-timed touchdown (deckmotion.py); falls back to the flare when the predictor is not ready
    deck_timing: bool = True
    hold_height: float = 1.5                  # [m] gear above the instantaneous pad while waiting
    commit_rate: float = 0.5                  # [m/s] final descent rate relative to the pad
    min_deck_skill: float = 0.6               # feed-forward/timing only when the predictor beats persistence by this (road ~0.4, sea >= 0.75)
    quiet_rate_err: float = float("inf")      # [m/s] deck-rate prediction margin gate (reported; not gating: a window-wide statistic)
    quiet_acc: float = 3.0                    # [m/s^2] absolute cap on predicted deck vertical acceleration
    deck_gate: str = "adaptive"               # "adaptive" (calmer than the calm_quantile of recent history) | "none"
    calm_quantile: float = 0.4
    td_k_sigma: float = 1.5
    wait_timeout: float = 30.0                # [s] without a quiescent period -> go-around
    abort_pos_err: float = 0.45               # [m] lateral error that triggers a go-around
    commit_height: float = 0.35               # below this, no go-around (commit)
    max_est_std: float = 0.18                 # [m] horizontal relative-estimate std for descent
    max_est_std_3d: float = 0.30              # [m] 3-D relative-estimate std (includes height)
    max_gate_std_3d: float = 0.8              # [m] needed to leave the approach gate
    max_vision_age: float = 0.6               # [s] fiducial or UWB freshness required
    max_deck_tilt_deg: float = 10.0
    max_platform_accel: float = 2.0
    max_platform_yaw_rate: float = 0.2
    max_wind: float = 12.0
    touchdown_max_vz: float = 1.2             # relative normal speed [m/s]
    touchdown_max_vh: float = 0.6             # relative tangential speed [m/s]
    max_go_arounds: int = 3
    go_around_climb: float = 5.0
    go_around_hold: float = 3.0


def evaluate_landing_zone(lim: RecoveryLimits, *, pad_free: bool, deck_tilt: float, pred,
                          wind: np.ndarray, platform_available: bool, uav_max_ground_speed: float = 18.0,
                          speed_margin: float = 2.0) -> list[Check]:
    return [
        _le("platform_speed_vs_uav", np.linalg.norm(pred.v[:2]), uav_max_ground_speed - speed_margin, "m/s"),
        Check("platform_available", float(platform_available), 1.0, bool(platform_available)),
        Check("pad_free", float(pad_free), 1.0, bool(pad_free)),
        _le("deck_tilt", np.degrees(deck_tilt), lim.max_deck_tilt_deg, "deg"),
        _le("platform_accel", np.linalg.norm(pred.a[:2]), lim.max_platform_accel, "m/s^2"),
        _le("platform_yaw_rate", abs(pred.yaw_rate), lim.max_platform_yaw_rate, "rad/s"),
        _le("wind_speed", np.linalg.norm(wind), lim.max_wind, "m/s"),
    ]


def evaluate_descent(lim: RecoveryLimits, *, lateral_err: float, est_std: float, vision_age: float, est_std_3d: float,
                     deck_tilt: float, pred) -> list[Check]:
    """Checks applied continuously during LANDING above the commit height."""
    return [
        _le("lateral_error_est", lateral_err, lim.abort_pos_err, "m"),
        _le("relative_est_std", est_std, lim.max_est_std, "m", "horizontal"),
        _le("relative_est_std_3d", est_std_3d, lim.max_est_std_3d, "m"),
        _le("vision_or_uwb_age", vision_age, lim.max_vision_age, "s"),
        _le("deck_tilt", np.degrees(deck_tilt), lim.max_deck_tilt_deg, "deg"),
        _le("platform_accel", np.linalg.norm(pred.a[:2]), lim.max_platform_accel, "m/s^2"),
        _le("platform_yaw_rate", abs(pred.yaw_rate), lim.max_platform_yaw_rate, "rad/s"),
    ]


def all_ok(checks: list[Check]) -> bool:
    return all(c.ok for c in checks)


def failed(checks: list[Check]) -> list[str]:
    return [c.name for c in checks if not c.ok]
