"""Deck-motion prediction and quiescent-period touchdown planning.

Why
---
Ship heave is slow enough (periods of 5-15 s) for a quadrotor to follow, but a feedback loop
follows it with a lag, so during the final descent the relative vertical speed differs from the
commanded descent rate by roughly (lag x deck acceleration); and the deck tilt at contact must stay
inside the limit. The UAV therefore
  1. hovers at a fixed height above the *instantaneous* pad, with the *predicted deck vertical
     acceleration* fed forward so it tracks the heave without lag,
  2. predicts the pad's 3-D displacement (heave plus the roll/pitch lever arm, which also swings
     the pad sideways) and the deck tilt over the final-descent duration,
  3. commits to the final descent only inside a quiescent period: the predicted maximum deck
     acceleration over the descent is below a *relative* threshold (a quantile of the same
     quantity over the deck's own recent measured history, i.e. calmer than usual) and the
     predicted tilt plus a 1-sigma margin stays inside the limit.
     Absolute thresholds with full error margins were tried first and almost never opened at sea
     state 5: at a 3 s horizon the predictor's acceleration/tilt errors are as large as the signals
     (finding 15). Absolute deck speed is not gated: the UAV follows it.
This is quiescent-period prediction as used in shipboard helicopter recovery (established
practice); the AR predictor is a standard, simple choice.

Discarded first design: hold a constant height above the deck's *mean* level and time the contact.
At sea state 5 (heave +-2-3 m) the deck rose into the waiting UAV, and contact-time predictions near
crests were wrong by seconds (docs/06_DEVELOPMENT_FINDINGS.md, finding 14).

Signals (from the platform's MRU broadcast: heave, roll, pitch and their rates)
-------
  (dx, dy, d) = R(roll, pitch) rho - rho + heave e3     pad displacement about its mean position,
                                                        platform-heading axes
  roll, pitch                                           deck attitude (tilt = acos(cos r cos p))
Messages arrive with latency and jitter and can be lost; samples go on a uniform 10 Hz grid (linear
interpolation over gaps) and the model predicts forward from the last sample, which compensates the
latency.

Model
-----
One AR(p) model per channel, x_k = sum_i a_i x_{k-i}, ridge-regularised least squares on a sliding
window, refitted every few seconds; recursive multi-step prediction. Error statistics (RMS error of
the predicted value, rate and acceleration at several horizons) are measured on the most recent
third of the window, always predicting forward from data before the scored samples. "True"
derivatives for scoring use a +-0.5 s central-difference stencil, so MRU noise is not mistaken for
prediction error (heave periods are 5-15 s, so the stencil barely attenuates the signal).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

HORIZONS = (0.5, 1.0, 2.0, 3.0, 4.0)


def pad_vertical(heave, roll, pitch, droll, dpitch, dheave, rho):
    """Vertical displacement of a deck point about its mean height, and its rate."""
    sx, sy, sz = rho
    cr, sr, cp, sp = np.cos(roll), np.sin(roll), np.cos(pitch), np.sin(pitch)
    z = -sp * sx + cp * sr * sy + cp * cr * sz
    dz_dpitch = -cp * sx - sp * sr * sy - sp * cr * sz
    dz_droll = cp * cr * sy - cp * sr * sz
    return heave + z - sz, dheave + dz_dpitch * dpitch + dz_droll * droll


def pad_displacement(heave, roll, pitch, rho):
    """Pad displacement about its mean position in platform-heading axes (x fwd, y left, z up)."""
    cr, sr, cp, sp = np.cos(roll), np.sin(roll), np.cos(pitch), np.sin(pitch)
    R = np.array([[cp, sp * sr, sp * cr], [0.0, cr, -sr], [-sp, cp * sr, cp * cr]])   # Ry(pitch) Rx(roll)
    return R @ rho - rho + np.array([0.0, 0.0, heave])


def _smooth_deriv(x, dt, k=5):
    """Central difference over +-k samples (rate), and second difference (acceleration)."""
    v = np.full_like(x, np.nan)
    a = np.full_like(x, np.nan)
    v[k:-k] = (x[2 * k:] - x[:-2 * k]) / (2 * k * dt)
    a[k:-k] = (x[2 * k:] - 2 * x[k:-k] + x[:-2 * k]) / (k * dt) ** 2
    return v, a


class ARChannel:
    """Uniformly sampled scalar signal with an online AR(p) predictor."""

    def __init__(self, dt=0.1, order=12, window=120.0, ridge=1e-4):
        self.dt, self.p, self.window, self.ridge = dt, order, window, ridge
        self.x: list[float] = []
        self.coef: np.ndarray | None = None
        self.err = {"x": {}, "v": {}, "a": {}}     # horizon -> RMS error of value / rate / accel
        self.persist = {}                            # horizon -> RMS error of "no change" prediction

    def append(self, values):
        self.x.extend(values)
        cut = len(self.x) - int(self.window / self.dt)
        if cut > 0:
            del self.x[:cut]

    def roll(self, hist, steps):
        buf = list(hist[-self.p:])
        out = np.empty(steps)
        c = self.coef
        for k in range(steps):
            nxt = float(np.dot(c, buf[::-1][: self.p]))
            out[k] = nxt
            buf.append(nxt)
        return out

    def fit(self):
        x = np.asarray(self.x)
        p, n = self.p, len(self.x)
        if n < 4 * p:
            return False
        X = np.column_stack([x[p - i - 1:n - i - 1] for i in range(p)])
        y = x[p:]
        self.coef = np.linalg.solve(X.T @ X + self.ridge * len(y) * np.eye(p), X.T @ y)
        # forward-scored error statistics on the last third of the window
        H = int(max(HORIZONS) / self.dt)
        v_true, a_true = _smooth_deriv(x, self.dt)
        ex = {h: [] for h in HORIZONS}
        ev = {h: [] for h in HORIZONS}
        ea = {h: [] for h in HORIZONS}
        for s in range(max(p, n - n // 3), n - H - 6, 4):
            path = self.roll(x[s - p:s], H + 1)
            full = np.concatenate([x[s - 2:s], path])          # two known samples for the derivatives
            pv = np.gradient(full, self.dt)[2:]
            pa = np.gradient(np.gradient(full, self.dt), self.dt)[2:]
            for h in HORIZONS:
                k = int(round(h / self.dt)) - 1
                ex[h].append(path[k] - x[s + k])
                if np.isfinite(v_true[s + k]):
                    ev[h].append(pv[k] - v_true[s + k])
                    ea[h].append(pa[k] - a_true[s + k])
        for name, e in (("x", ex), ("v", ev), ("a", ea)):
            self.err[name] = {h: float(np.sqrt(np.mean(np.square(v)))) for h, v in e.items() if v}
        tail = x[max(p, n - n // 3):]
        for h in HORIZONS:
            k = int(round(h / self.dt))
            if tail.size > k:
                self.persist[h] = float(np.sqrt(np.mean((tail[k:] - tail[:-k]) ** 2)))
        return True

    def skill(self, h: float) -> float:
        """1 - AR error / persistence error at horizon h (1 = perfect, <= 0 = no better than
        assuming the signal does not change)."""
        if h not in self.persist or h not in self.err["x"] or self.persist[h] <= 1e-9:
            return 0.0
        return 1.0 - self.err["x"][h] / self.persist[h]

    def predict(self, lead_steps, steps):
        path = self.roll(np.asarray(self.x[-self.p:]), lead_steps + steps + 2)
        full = np.concatenate([self.x[-2:], path])
        v = np.gradient(full, self.dt)[2:]
        a = np.gradient(v, self.dt)
        return path, v, a

    def error(self, kind, h):
        e = self.err[kind]
        if not e:
            return np.inf
        hs = sorted(e)
        return float(np.interp(h, hs, [e[k] for k in hs]))


class DeckMotionPredictor:
    """Predicts the target pad's vertical motion and the deck roll / pitch."""

    def __init__(self, pad_offset_p, dt: float = 0.1, order: int = 12, window: float = 120.0,
                 min_history: float = 25.0, refit_every: float = 3.0):
        self.rho = np.asarray(pad_offset_p, float)
        self.dt, self.order, self.window = dt, order, window
        self.min_history, self.refit_every = min_history, refit_every
        self.ch = {k: ARChannel(dt, order, window) for k in ("dx", "dy", "d", "roll", "pitch")}
        self.t: list[float] = []
        self.fit_t = -np.inf
        self.ready = False

    def reset(self, pad_offset_p):
        self.__init__(pad_offset_p, self.dt, self.order, self.window, self.min_history, self.refit_every)

    @property
    def history(self) -> float:
        return 0.0 if not self.t else self.t[-1] - self.t[0]

    def add(self, m):
        dx, dy, d = pad_displacement(m.heave, m.roll, m.pitch, self.rho)
        sample = {"dx": dx, "dy": dy, "d": d, "roll": m.roll, "pitch": m.pitch}
        if self.t and m.t <= self.t[-1] + 1e-6:
            return                                                   # duplicate / reordered
        n = 1
        if self.t and m.t - self.t[-1] > self.dt * 1.5:              # lost packets: interpolate on the grid
            n = int(round((m.t - self.t[-1]) / self.dt))
        t0 = self.t[-1] if self.t else m.t
        for name, ch in self.ch.items():
            x0 = ch.x[-1] if ch.x else sample[name]
            ch.append([x0 + (sample[name] - x0) * k / n for k in range(1, n + 1)])
        self.t.extend([t0 + k * self.dt for k in range(1, n)] + [m.t])
        cut = len(self.t) - int(self.window / self.dt)
        if cut > 0:
            del self.t[:cut]
        if self.t[-1] - self.fit_t >= self.refit_every and self.history >= self.min_history:
            self.ready = all(ch.fit() for ch in self.ch.values())
            self.fit_t = self.t[-1]

    def predict(self, t_from: float, horizon: float):
        """Predicted (times, d, d_dot, d_ddot) of the pad's vertical displacement from t_from to
        t_from + horizon on the 10 Hz grid (the model rolls forward across the latency gap)."""
        r = self.predict_all(t_from, horizon)
        return None if r is None else (r["t"], r["d"], r["d_rate"], r["d_acc"])

    def predict_all(self, t_from: float, horizon: float):
        if not self.ready:
            return None
        lead = max(0, int(np.floor((t_from - self.t[-1]) / self.dt)))
        steps = int(np.ceil(horizon / self.dt)) + 2
        times = self.t[-1] + self.dt * np.arange(1, lead + steps + 3)
        d, dv, da = self.ch["d"].predict(lead, steps)
        _, _, ax = self.ch["dx"].predict(lead, steps)
        _, _, ay = self.ch["dy"].predict(lead, steps)
        roll, _, _ = self.ch["roll"].predict(lead, steps)
        pitch, _, _ = self.ch["pitch"].predict(lead, steps)
        keep = times >= t_from - self.dt - 1e-9
        tilt = np.arccos(np.clip(np.cos(roll) * np.cos(pitch), -1, 1))
        return {"t": times[keep], "d": d[keep], "d_rate": dv[keep], "d_acc": da[keep], "tilt": tilt[keep],
                "acc_h": np.column_stack([ax, ay])[keep]}

    def skill(self, h: float = 1.0) -> float:
        """Predictive skill of the pad's vertical channel (see ARChannel.skill)."""
        return self.ch["d"].skill(h) if self.ready else 0.0

    def error_at(self, h: float, kind: str = "x", channel: str = "d") -> float:
        return self.ch[channel].error(kind, h)

    def calm_threshold(self, duration: float, q: float) -> float:
        """q-quantile of the max |vertical deck acceleration| over windows of ``duration`` in the
        measured history (smoothed derivatives): the bar a window must beat to count as calm."""
        x = np.asarray(self.ch["d"].x)
        _, a = _smooth_deriv(x, self.dt)
        a = np.abs(a[np.isfinite(a)])
        w = max(1, int(round(duration / self.dt)))
        if a.size < 2 * w:
            return np.inf
        m = np.array([a[i:i + w].max() for i in range(0, a.size - w, 2)])
        return float(np.quantile(m, q))


@dataclass
class QuiescentPlan:
    commit: bool
    duration: float          # final-descent duration evaluated [s]
    max_rate: float          # max predicted |deck vertical speed| [m/s]
    max_acc: float           # max predicted |deck vertical acceleration| [m/s^2]
    max_tilt_deg: float      # max predicted deck tilt [deg]
    margin_rate: float       # margins added from measured predictor error
    margin_acc: float
    margin_tilt_deg: float
    reason: str

    def as_dict(self):
        return {k: (round(v, 3) if isinstance(v, float) else v) for k, v in self.__dict__.items()}


def plan_quiescent(pred: DeckMotionPredictor, t_now: float, duration: float, v_err_max: float, a_max: float,
                   tilt_max_deg: float, k_sigma: float = 1.5, calm_quantile: float | None = None,
                   k_tilt: float = 1.0) -> QuiescentPlan:
    """Is the deck predicted to stay quiet for the whole final descent starting now?

    Gates: predicted |deck vertical acceleration| + margin <= a_max (what the UAV must follow);
    predicted tilt + margin <= tilt_max_deg; and the velocity margin (k x measured rate error)
    <= v_err_max, i.e. the prediction is reliable enough to fly the descent on.
    """
    out = pred.predict_all(t_now, duration)
    if out is None:
        return QuiescentPlan(False, duration, *([np.nan] * 6), "deck predictor not ready")
    mr = k_sigma * pred.error_at(duration, "v")
    ma = k_sigma * pred.error_at(duration, "a")
    mt = k_tilt * np.degrees(max(pred.error_at(duration, "x", "roll"), pred.error_at(duration, "x", "pitch")))
    if calm_quantile is not None:     # relative gate: no accel margin, threshold from measured history
        a_max = min(a_max, pred.calm_threshold(duration, calm_quantile))
        ma = 0.0
    vr = float(np.max(np.abs(out["d_rate"])))
    va = float(np.max(np.abs(out["d_acc"])))
    vt = float(np.degrees(np.max(out["tilt"])))
    plan = QuiescentPlan(False, duration, vr, va, vt, mr, ma, mt, "")
    if mr > v_err_max:
        plan.reason = f"deck-rate prediction too uncertain ({mr:.2f} > {v_err_max:.2f} m/s)"
    elif va + ma > a_max:
        plan.reason = f"deck accel {va:.2f}+{ma:.2f} > {a_max:.2f} m/s2"
    elif vt + mt > tilt_max_deg:
        plan.reason = f"deck tilt {vt:.1f}+{mt:.1f} > {tilt_max_deg:.1f} deg"
    else:
        plan.commit, plan.reason = True, "quiescent period"
    return plan
