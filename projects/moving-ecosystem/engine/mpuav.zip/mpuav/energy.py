"""Energy-aware planning: mission feasibility, return/intercept energy, reserves.

Uses the same rotor power model as the simulator (power.py) with steady-flight force balance,
so planner and simulator disagree only through unmodelled transients (acceleration, gusts,
control activity). The size of that disagreement is reported by the experiments.

Return to a moving platform = intercept problem. With the platform's predicted pad trajectory
p_pad(t) (tracker mean prediction) and UAV ground velocity v_g = v_air + w, the earliest
intercept time T* is the smallest T with  ||p_pad(t0+T) - p_uav|| <= T * g(T), where the
achievable ground speed g along the required direction is computed from the wind triangle with
|v_air| <= v_cruise. T is found by a coarse scan followed by bisection.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .power import vehicle_power


def ground_speed_along(direction: np.ndarray, wind: np.ndarray, airspeed: float) -> float:
    """Max ground speed along unit ``direction`` with |v_air| = airspeed (wind triangle)."""
    d = direction / max(np.linalg.norm(direction), 1e-9)
    wd = float(wind @ d)
    w_perp2 = float(wind @ wind) - wd * wd
    if airspeed ** 2 < w_perp2:
        return 0.0
    return max(0.0, wd + np.sqrt(airspeed ** 2 - w_perp2))


@dataclass
class EnergyConfig:
    cruise_airspeed: float = 12.0           # outbound / mission legs
    intercept_airspeed: float = 16.0        # return / intercept
    max_ground_speed: float = 16.5          # guidance limit (18 m/s) minus a 1.5 m/s closing margin
    climb_rate: float = 2.0
    reserve_fraction: float = 0.15          # of capacity, never planned to be used
    landing_allowance_s: float = 40.0       # alignment + descent
    go_around_allowance_s: float = 25.0     # one go-around budgeted
    model_margin: float = 1.15              # multiplicative margin for model error


@dataclass
class EnergyEstimate:
    feasible: bool
    required_wh: float
    available_wh: float
    margin_wh: float
    breakdown: dict = field(default_factory=dict)
    intercept_time: float = np.nan
    intercept_point: np.ndarray | None = None


class EnergyPlanner:
    def __init__(self, quad_params, cfg: EnergyConfig | None = None):
        self.qp = quad_params
        self.cfg = cfg or EnergyConfig()

    def power(self, v_air: np.ndarray) -> float:
        return vehicle_power(self.qp.mass, np.asarray(v_air, float), float(np.mean(self.qp.drag[:2])),
                             self.qp.disc_area, self.qp.figure_of_merit, avionics_w=self.qp.avionics_power)

    def hover_power(self, wind=np.zeros(3)) -> float:
        return self.power(-np.asarray(wind, float))

    def leg(self, p0, p1, wind, airspeed: float | None = None) -> tuple[float, float]:
        """(time [s], energy [J]) for a straight leg at the given (default cruise) airspeed in steady wind."""
        airspeed = self.cfg.cruise_airspeed if airspeed is None else airspeed
        d = np.asarray(p1, float) - np.asarray(p0, float)
        dist_h = float(np.linalg.norm(d[:2]))
        dz = float(d[2])
        t_h, e_h = 0.0, 0.0
        if dist_h > 1e-3:
            u = np.array([d[0], d[1], 0.0]) / dist_h
            g = ground_speed_along(u, np.asarray(wind, float), airspeed)
            if g <= 0.2:
                return np.inf, np.inf
            t_h = dist_h / g
            v_air = u * g - wind
            e_h = self.power(v_air) * t_h
        t_v = abs(dz) / self.cfg.climb_rate
        e_v = self.power(np.array([0, 0, np.sign(dz) * self.cfg.climb_rate]) - wind) * t_v
        return t_h + t_v, e_h + e_v

    def intercept(self, p_uav, t0: float, pad_at, wind, t_max: float = 900.0):
        """pad_at(t) -> predicted pad position. Returns (T*, point) or (inf, None)."""
        wind = np.asarray(wind, float)

        def gap(T):
            tgt = pad_at(t0 + T)
            d = tgt - p_uav
            g = min(ground_speed_along(np.array([d[0], d[1], 0.0]), wind, self.cfg.intercept_airspeed),
                    self.cfg.max_ground_speed)
            return np.linalg.norm(d[:2]) - g * T, tgt

        prev = 0.0
        if gap(0.0)[0] <= 0:
            return 0.0, pad_at(t0)
        for T in np.arange(2.0, t_max, 2.0):
            gp, _ = gap(T)
            if gp <= 0:
                lo, hi = prev, T
                for _ in range(20):
                    mid = 0.5 * (lo + hi)
                    if gap(mid)[0] <= 0:
                        hi = mid
                    else:
                        lo = mid
                return hi, gap(hi)[1]
            prev = T
        return np.inf, None

    def return_estimate(self, p_uav, t0, pad_at, wind, energy_remaining_j: float,
                        capacity_j: float) -> EnergyEstimate:
        T, pt = self.intercept(np.asarray(p_uav, float), t0, pad_at, wind)
        if not np.isfinite(T):
            return EnergyEstimate(False, np.inf, energy_remaining_j / 3600, -np.inf,
                                  {"reason": "platform cannot be intercepted at cruise airspeed"})
        _, e_ret = self.leg(p_uav, pt + np.array([0, 0, 6.0]), wind, self.cfg.intercept_airspeed)
        # the leg() uses straight-line ground track to the intercept point: equal to the intercept flight
        e_land = self.hover_power(wind) * (self.cfg.landing_allowance_s + self.cfg.go_around_allowance_s)
        req = (e_ret + e_land) * self.cfg.model_margin
        reserve = self.cfg.reserve_fraction * capacity_j
        margin = energy_remaining_j - reserve - req
        return EnergyEstimate(margin >= 0, (req + reserve) / 3600, energy_remaining_j / 3600, margin / 3600,
                              {"return_wh": e_ret / 3600, "landing_and_go_around_wh": e_land / 3600,
                               "model_margin_factor": self.cfg.model_margin, "reserve_wh": reserve / 3600},
                              T, pt)

    def mission_estimate(self, p_start, waypoints: list, loiter: list, t0, pad_at, wind,
                         energy_j: float, capacity_j: float) -> EnergyEstimate:
        """Full sortie: climb, legs, loiters, then return to the *predicted* platform position."""
        wind = np.asarray(wind, float)
        t, e = 0.0, 0.0
        p = np.asarray(p_start, float)
        breakdown = {}
        for i, (wp, lo) in enumerate(zip(waypoints, loiter)):
            dt, de = self.leg(p, wp, wind)
            if not np.isfinite(dt):
                return EnergyEstimate(False, np.inf, energy_j / 3600, -np.inf, {"reason": f"leg {i} infeasible in wind"})
            t += dt + lo
            e += de + self.hover_power(wind) * lo
            p = np.asarray(wp, float)
        breakdown["outbound_and_tasks_wh"] = e / 3600
        ret = self.return_estimate(p, t0 + t, pad_at, wind, energy_j - e, capacity_j)
        breakdown.update(ret.breakdown)
        req = e * self.cfg.model_margin + (ret.required_wh * 3600 if np.isfinite(ret.required_wh) else np.inf)
        margin = (energy_j - req) / 3600
        return EnergyEstimate(bool(ret.feasible and margin >= 0), req / 3600, energy_j / 3600, margin, breakdown,
                              t + ret.intercept_time, ret.intercept_point)
