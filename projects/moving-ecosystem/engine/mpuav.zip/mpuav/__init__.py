"""Moving Ecosystem UAV Intelligence: UAV launch, mission and recovery from moving platforms
(simulation and research platform; no hardware interfaces)."""

__version__ = "0.1.0"
