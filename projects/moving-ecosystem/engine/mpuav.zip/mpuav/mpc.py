"""Linear MPC for pad-relative trajectory tracking with predicted platform acceleration.

Relative dynamics per axis (world axes, pad-relative):
    r'' = a_uav - a_pad(t)
Discretised at Ts with zero-order hold on a_uav; the predicted pad acceleration over the
horizon comes from the platform tracker (CTRA prediction), so the MPC anticipates turns and
braking instead of reacting to them.

Problem per axis (box-constrained, solved exactly as bounded least squares):
    min  sum_k qp (r_k - r_ref,k)^2 + qv (v_k - v_ref,k)^2 + ru (u_k - a_pad,k)^2
    s.t. |u_k| <= u_max
The horizontal bound approximates the tilt cone with a per-axis box (conservative: a_max/sqrt 2).
An offset-free disturbance estimate (constant acceleration bias, e.g. wind drag) is updated from
the one-step prediction error.
"""

from __future__ import annotations

import numpy as np


class RelativeMPC:
    name = "mpc"

    def __init__(self, ts: float = 0.1, horizon: int = 20, qp: float = 4.0, qv: float = 1.0,
                 ru: float = 0.3, a_max_h: float = 4.5, a_max_v: float = 3.5, dist_gain: float = 0.15):
        self.ts, self.N = ts, horizon
        self.qp, self.qv, self.ru = qp, qv, ru
        self.umax = np.array([a_max_h / np.sqrt(2), a_max_h / np.sqrt(2), a_max_v])
        self.dist_gain = dist_gain
        N = horizon
        # stacked prediction: x_{k+1} = A x_k + B u_k, x = [r, v]
        self.Sp_x = np.zeros((N, 2))
        self.Sv_x = np.zeros((N, 2))
        self.Sp_u = np.zeros((N, N))
        self.Sv_u = np.zeros((N, N))
        for k in range(N):
            tk = (k + 1) * ts
            self.Sp_x[k] = [1.0, tk]
            self.Sv_x[k] = [0.0, 1.0]
            for j in range(k + 1):
                dt_rem = (k - j) * ts
                self.Sp_u[k, j] = ts * dt_rem + 0.5 * ts * ts
                self.Sv_u[k, j] = ts
        self.t_last = -np.inf
        self.u_hold = np.zeros(3)
        self.d_hat = np.zeros(3)
        self._pred_v = None
        self._last_v = None

    def reset(self):
        self.t_last = -np.inf
        self.d_hat[:] = 0.0
        self._pred_v = None

    def command(self, t: float, r: np.ndarray, v: np.ndarray, r_ref: np.ndarray, v_ref: np.ndarray,
                a_pad: np.ndarray) -> np.ndarray:
        """r_ref, v_ref, a_pad: arrays (N, 3) over the horizon. Returns the UAV acceleration command."""
        if t - self.t_last < self.ts - 1e-9:
            return self.u_hold
        from scipy.optimize import lsq_linear   # lazy: scipy is optional for PID-only use
        if self._pred_v is not None:
            err = (v - self._pred_v) / self.ts
            self.d_hat = np.clip(self.d_hat + self.dist_gain * err, -3.0, 3.0)
        u = np.zeros(3)
        for ax in range(3):
            x0 = np.array([r[ax], v[ax]])
            # disturbance-adjusted free response: r'' = u - a_pad + d
            w = -a_pad[:, ax] + self.d_hat[ax]
            p_free = self.Sp_x @ x0 + self.Sp_u @ w
            v_free = self.Sv_x @ x0 + self.Sv_u @ w
            A = np.vstack([np.sqrt(self.qp) * self.Sp_u, np.sqrt(self.qv) * self.Sv_u,
                           np.sqrt(self.ru) * np.eye(self.N)])
            b = np.concatenate([np.sqrt(self.qp) * (r_ref[:, ax] - p_free),
                                np.sqrt(self.qv) * (v_ref[:, ax] - v_free),
                                np.sqrt(self.ru) * a_pad[:, ax]])
            res = lsq_linear(A, b, bounds=(-self.umax[ax], self.umax[ax]), method="bvls")
            u[ax] = res.x[0]
        self._pred_v = v + self.ts * (u - a_pad[0] + self.d_hat)
        self.u_hold = u
        self.t_last = t
        return u
