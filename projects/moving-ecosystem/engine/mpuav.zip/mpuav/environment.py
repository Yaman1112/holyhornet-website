"""Environment: wind field, GNSS-denied zones, communication outages, lighting, obstacles."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


class WindField:
    """Mean wind + first-order Gauss-Markov (Ornstein-Uhlenbeck) gusts + optional linear shear.

    w(z, t) = w_mean * shear(z) + g(t),   dg = -g/T dt + sigma sqrt(2/T) dW
    The OU process has stationary standard deviation ``gust_sigma`` per axis (vertical / 2).
    This is a simplified stand-in for a Dryden model with a single correlation time.
    """

    def __init__(self, rng: np.random.Generator, mean=(0.0, 0.0, 0.0), gust_sigma: float = 0.0,
                 corr_time: float = 3.0, shear_ref_alt: float = 10.0, shear_exp: float = 0.14):
        self.rng = rng
        self.mean = np.asarray(mean, float)
        self.sigma = np.array([gust_sigma, gust_sigma, 0.5 * gust_sigma])
        self.T = corr_time
        self.g = np.zeros(3)
        self.zref, self.alpha = shear_ref_alt, shear_exp

    def step(self, dt: float):
        a = np.exp(-dt / self.T)
        self.g = a * self.g + self.sigma * np.sqrt(1 - a * a) * self.rng.standard_normal(3)

    def at(self, p: np.ndarray) -> np.ndarray:
        z = max(float(p[2]), 0.5)
        shear = (z / self.zref) ** self.alpha  # power-law boundary layer
        m = self.mean.copy()
        m[:2] *= shear
        return m + self.g

    def set_mean(self, mean):
        self.mean = np.asarray(mean, float)


@dataclass
class Zone:
    """Axis-aligned horizontal box [xmin, xmax] x [ymin, ymax], optional time window."""
    xmin: float
    xmax: float
    ymin: float
    ymax: float
    t0: float = 0.0
    t1: float = float("inf")

    def contains(self, p, t) -> bool:
        return self.t0 <= t <= self.t1 and self.xmin <= p[0] <= self.xmax and self.ymin <= p[1] <= self.ymax


@dataclass
class Obstacle:
    """Vertical cylinder (pole, mast, tree, building corner)."""
    center: np.ndarray
    radius: float
    height: float


@dataclass
class Environment:
    rng: np.random.Generator
    wind: WindField
    gnss_denied: list[Zone] = field(default_factory=list)
    comm_outages: list[tuple[float, float]] = field(default_factory=list)
    comm_range: float = 2000.0
    lighting: float = 1.0          # 1 = daylight, 0.2 = dusk; affects fiducial detection
    obstacles: list[Obstacle] = field(default_factory=list)

    def gnss_available(self, p, t) -> bool:
        return not any(z.contains(p, t) for z in self.gnss_denied)

    def comm_up(self, t, distance: float) -> bool:
        if distance > self.comm_range:
            return False
        return not any(a <= t <= b for a, b in self.comm_outages)

    def min_obstacle_clearance(self, p) -> float:
        best = np.inf
        for o in self.obstacles:
            if p[2] <= o.height:
                best = min(best, float(np.linalg.norm(p[:2] - o.center[:2]) - o.radius))
        return best
