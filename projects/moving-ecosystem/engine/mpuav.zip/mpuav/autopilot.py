"""Onboard autonomy of one UAV: estimation, launch / mission / recovery state machines,
guidance and control. Uses only sensor measurements, link messages and fleet-manager
instructions; never ground truth.

Modes:  ON_DECK -> LAUNCH -> MISSION -> RECOVERY -> SECURED
        plus HOLD (waiting for a slot), DIVERT (to a static site), LANDED_SITE, CRASHED.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .comms import CommLink
from .deckmotion import DeckMotionPredictor, plan_quiescent
from .control import (GeometricAttitudeController, LQRTranslational, PIDTranslational,
                      collision_avoidance_accel, thrust_and_attitude)
from .energy import EnergyPlanner
from .estimation import NavFilter, RelativeEstimator
from .frames import E3, GRAVITY, rot_z, wrap_angle
from .mpc import RelativeMPC
from .quadrotor import Quadrotor
from .safety import (LaunchLimits, RecoveryLimits, all_ok, evaluate_descent, evaluate_landing_zone,
                     evaluate_launch, failed)
from .sensors import FiducialCamera, Gnss, GnssModel, Imu, UwbRanging
from .tracking import PlatformTracker

LAUNCH_STATES = ["PLATFORM_DETECTION", "PLATFORM_TRACKING", "PLATFORM_IDENTIFICATION",
                 "PLATFORM_MOTION_ESTIMATION", "UAV_HEALTH_CHECK", "LAUNCH_CONDITION_EVALUATION",
                 "LAUNCH_AUTHORIZATION", "AUTONOMOUS_TAKEOFF", "RELATIVE_SEPARATION_VERIFICATION",
                 "MISSION_ACTIVATION"]
RECOVERY_STATES = ["RETURN_REQUEST", "PLATFORM_REACQUISITION", "RELATIVE_STATE_ESTIMATION",
                   "PLATFORM_TRAJECTORY_PREDICTION", "LANDING_ZONE_EVALUATION",
                   "RECOVERY_TRAJECTORY_GENERATION", "APPROACH", "FINAL_ALIGNMENT", "LANDING",
                   "CONTACT_DETECTION", "LANDING_VERIFICATION", "SECUREMENT", "MISSION_COMPLETE"]
PLATFORM_ACC_SIGMA = {"ground_vehicle": 0.8, "marine_vessel": 0.25, "mobile_robot": 0.5}


@dataclass
class Mission:
    kind: str = "inspection"
    waypoints: list = field(default_factory=list)     # world positions, or platform-relative if relative=True
    loiter: list = field(default_factory=list)        # seconds at each waypoint
    relative: bool = False                            # waypoints given as offsets from the platform at launch
    frame: str = "world"                              # "world" | "platform" (live platform-heading frame)
    cruise_speed: float = 12.0
    max_duration: float = 1e9


@dataclass
class AgentConfig:
    controller: str = "pid"            # pid | lqr | mpc (mpc used in final alignment / landing)
    gnss: GnssModel = field(default_factory=GnssModel)
    use_uwb: bool = True
    use_camera: bool = True
    launch: LaunchLimits = field(default_factory=LaunchLimits)
    recovery: RecoveryLimits = field(default_factory=RecoveryLimits)
    takeoff_height: float = 8.0
    launch_timeout: float = 120.0
    lost_link_timeout: float = 20.0
    v_max: float = 18.0               # ground-speed limit used by guidance [m/s]
    v_close_max: float = 7.0          # max closing speed relative to the platform [m/s]
    mission_altitude: float = 30.0


class Agent:
    def __init__(self, uid: str, quad: Quadrotor, rng: np.random.Generator, cfg: AgentConfig | None = None):
        self.id = uid
        self.quad = quad
        self.cfg = cfg or AgentConfig()
        self.rng = rng
        self.gnss = Gnss(rng, self.cfg.gnss)
        self.imu = Imu(rng)
        self.uwb = UwbRanging(rng)
        self.cam = FiducialCamera(rng)
        self.link = CommLink(rng)
        self.nav = NavFilter(quad.s.p)
        self.rel = RelativeEstimator(np.zeros(3))
        self.trackers: dict[str, PlatformTracker] = {}
        self.platform_kinds: dict[str, str] = {}
        self.att = GeometricAttitudeController(quad.P.inertia)
        self.pos_ctrl = LQRTranslational() if self.cfg.controller == "lqr" else PIDTranslational()
        self.mpc = RelativeMPC() if self.cfg.controller == "mpc" else None
        self.energy = EnergyPlanner(quad.P)
        # mission / assignment
        self.home: tuple[str, str] | None = None          # (platform id, pad name)
        self.target: tuple[str, str] | None = None
        self.target_offset = np.zeros(3)
        self.site = None                                  # static LandingSite when diverting
        self.mission: Mission | None = None
        self.wp_idx = 0
        self.loiter_until = None
        # state machines
        self.mode = "ON_DECK"
        self.state = None
        self.state_t0 = 0.0
        self.launch_requested = False
        self.recovery_requested = False
        self.slot_granted = False
        self.hold_point_rel = None
        self.go_arounds = 0
        self.align_ok_since = None
        self.descent_ref = None
        self.contact = None                               # set by the world on deck contact
        self.decisions: list[dict] = []
        self.events: list[dict] = []
        self.last_checks: list = []
        self.last_imu = None
        self.pad_pred = None                              # (p, v, a) cached pad prediction
        self.deck = DeckMotionPredictor(np.zeros(3))      # vertical motion of the target pad
        self.deck_key = None
        self.landing_phase = None                         # flare | descent | hold | commit
        self.td_plan = None
        self.pad_pred_t = -np.inf
        self.last_link_rx = 0.0
        self.neighbours: list = []
        self.t = 0.0
        self.a_cmd = np.zeros(3)
        self.yaw_d = 0.0
        self.launch_t = None
        self.return_t = None
        self.secured_t = None
        self.mission_done = False
        self.est_log: list = []

    # ------------------------------------------------------------------ utils
    def log(self, kind, **kw):
        e = {"t": round(self.t, 3), "uav": self.id, "event": kind, **kw}
        self.events.append(e)
        return e

    def decide(self, question, decision, reasons, **kw):
        d = {"t": round(self.t, 3), "uav": self.id, "question": question, "decision": decision,
             "reasons": reasons, **kw}
        self.decisions.append(d)
        return d

    def set_state(self, s):
        if s != self.state:
            self.log("state", mode=self.mode, state=s, prev=self.state)
        self.state = s
        self.state_t0 = self.t

    def in_state_for(self) -> float:
        return self.t - self.state_t0

    def tracker(self, pid) -> PlatformTracker | None:
        return self.trackers.get(pid)

    def pad_offset(self, platform, pad_name):
        return next(p.offset_p for p in platform.pads if p.name == pad_name)

    def platform_acc_sigma(self, pid) -> float:
        tr = self.trackers.get(pid)
        base = PLATFORM_ACC_SIGMA.get(self.platform_kinds.get(pid, ""), 0.8)
        age = np.inf if tr is None or not tr.initialized else max(0.0, self.t - tr.t)
        return base + 0.3 * min(age, 20.0)

    # ---------------------------------------------------------- perception
    def sense(self, world):
        """Read sensors and link; run estimators. Called every simulation step."""
        t = world.t
        self.t = t
        q = self.quad
        # link: platform broadcasts
        for m in self.link.receive(t):
            self.last_link_rx = t
            tr = self.trackers.get(m.platform)
            if tr is None:
                tr = self.trackers[m.platform] = PlatformTracker(m.platform, self.platform_kinds.get(m.platform, ""))
            tr.process(m)
            tg = self.target or self.home
            if tg is not None and m.platform == tg[0]:
                if self.deck_key != tg:
                    self.deck.reset(self.pad_offset(world.platforms[tg[0]], tg[1]))
                    self.deck_key = tg
                self.deck.add(m)
        tgt = self.target or self.home
        tgt_plat = world.platforms.get(tgt[0]) if tgt else None
        tr = self.trackers.get(tgt[0]) if tgt else None
        # cached pad prediction (mean) at 20 Hz
        if tr is not None and tr.initialized and t - self.pad_pred_t >= 0.05:
            pr = tr.predict(t, with_cov=False)
            self.pad_pred = pr.point(self.target_offset)
            self.pad_pred_full = pr
            self.pad_pred_t = t
        # IMU / inertial propagation
        im = self.imu.measure(t, q.specific_force_b, q.s.w, q.s.R)
        if im is not None:
            self.last_imu = im
            self.nav.imu(im)
            if self.mode in ("ON_DECK", "SECURED"):
                self._deck_reset()
            else:
                pp = None
                if self.pad_pred is not None and t - self.pad_pred_t < 0.2:
                    pp = (self.pad_pred[0], self.pad_pred[1],
                          self.pad_pred[2] + self.deck_acc(0.0)[0])
                self.rel.imu(im, pp, self.platform_acc_sigma(tgt[0]) if tgt else 1.0)
        # GNSS
        g = self.gnss.measure(t, q.s.p, q.s.v, world.env.gnss_available(q.s.p, t))
        if g is not None:
            self.nav.gnss(g)
            if tr is not None and tr.initialized:
                # also on the deck: r is known there, so this calibrates the differential bias
                pr = tr.predict(g.t)
                p, v, _ = pr.point(self.target_offset)
                self.rel.gnss_differential(g, (p, v, None), pr.cov_p + np.eye(3) * (0.2 * pr.age) ** 2)
        # relative-aided navigation when the UAV has no GNSS (10 Hz)
        if (g is None and t - self.nav.last_gnss > 1.0 and tr is not None and tr.initialized
                and self.rel_fresh(1.0) and int(t * 100) % 10 == 0 and self.pad_pred is not None):
            pr = self.pad_pred_full
            sp = float(np.sqrt(np.trace(pr.cov_p) / 3 + self.rel.pos_std ** 2 / 3 + (0.3 * pr.age) ** 2))
            self.nav.relative_aid(t, self.pad_pred[0] + self.rel.r, self.pad_pred[1] + self.rel.v, sp, 0.2)
        if self.mode in ("ON_DECK", "SECURED") or tgt_plat is None:
            return
        # UWB anchors on the target platform (hardware on the platform; geometry from the platform)
        if self.cfg.use_uwb and tr is not None and tr.initialized:
            st = tgt_plat.state()
            anchors_p = world.anchors_p(tgt_plat)
            anchors_w = [st.p + st.R @ a for a in anchors_p]
            um = self.uwb.measure(t, q.s.p, anchors_w, anchors_p, enabled=world.uwb_enabled)
            if um is not None:
                R_pred = self.pad_pred_full.R if self.pad_pred is not None else np.eye(3)
                self.rel.uwb(um, R_pred)
        if self.cfg.use_camera:
            pads = []
            for pl in world.platforms.values():
                st = pl.state()
                for pad in pl.pads:
                    pads.append((f"{pl.id}/{pad.name}", pl.pad_kinematics(pad, st)[0], st.R))
            fm = self.cam.measure(t, q.s.p, q.s.R, pads, world.env.lighting, enabled=world.camera_enabled)
            # marker identity check: only the assigned pad's marker aids the estimator
            if fm is not None and fm.pad == f"{tgt[0]}/{tgt[1]}":
                self.rel.fiducial(fm, self.last_imu.R if self.last_imu is not None else q.s.R)

    def rel_fresh(self, age: float) -> bool:
        return min(self.rel.source_age(self.t, "uwb"), self.rel.source_age(self.t, "fiducial")) < age

    def v_abs_est(self):
        """Best absolute-velocity estimate: platform velocity + relative velocity when the relative
        solution is fresh (works without GNSS), otherwise the navigation filter."""
        if self.pad_pred is not None and self.rel_fresh(1.0) and self.mode not in ("ON_DECK", "SECURED"):
            return self.pad_pred[1] + self.rel.v
        return self.nav.v

    def _deck_reset(self):
        """While on the deck the relative state is known (contact constraint)."""
        tgt = self.target or self.home
        if tgt is None:
            return
        tr = self.trackers.get(tgt[0])
        R = tr.predict(self.t, with_cov=False).R if tr is not None and tr.initialized else np.eye(3)
        self.rel.deck_constraint(R @ E3 * self.quad.P.gear_height, self.t)

    # ---------------------------------------------------------------- guidance
    def deck_ff_active(self) -> bool:
        return (self.cfg.recovery.deck_timing and self.deck.ready and self.target is not None
                and self.deck_key == self.target and self.deck.skill(1.0) >= self.cfg.recovery.min_deck_skill
                and not (self.state == "LANDING" and self.landing_phase == "flare"))

    def deck_acc(self, taus) -> np.ndarray:
        """Predicted acceleration (world axes, shape (n, 3)) of the target pad due to deck motion
        (heave and the roll/pitch lever arm) at t + tau; zeros if unavailable."""
        taus = np.atleast_1d(np.asarray(taus, float))
        out = np.zeros((taus.size, 3))
        if not self.deck_ff_active() or self.pad_pred is None:
            return out
        r = self.deck.predict_all(self.t, float(taus.max()) + 0.2)
        tq = self.t + taus
        out[:, 2] = np.interp(tq, r["t"], r["d_acc"])
        ah = np.column_stack([np.interp(tq, r["t"], r["acc_h"][:, 0]), np.interp(tq, r["t"], r["acc_h"][:, 1])])
        c, s = np.cos(self.pad_pred_full.psi), np.sin(self.pad_pred_full.psi)
        out[:, 0] = c * ah[:, 0] - s * ah[:, 1]
        out[:, 1] = s * ah[:, 0] + c * ah[:, 1]
        return out

    def _relative_cmd(self, r_des, v_des=np.zeros(3), dt=0.01, use_mpc=False, r_ref_fn=None):
        """Pad-relative tracking. a_cmd = a_pad_pred + feedback on relative errors.

        The pad acceleration comes from the platform tracker (horizontal: CTRA incl. centripetal)
        and, when deck timing is enabled, the deck-motion predictor (vertical heave / pitch)."""
        a_pad = self.pad_pred[2].copy() if self.pad_pred is not None else np.zeros(3)
        a_pad += self.deck_acc(0.0)[0]
        if use_mpc and self.mpc is not None and self.target is not None:
            tr = self.trackers[self.target[0]]
            N, ts = self.mpc.N, self.mpc.ts
            preds = [tr.predict(self.t + (k + 1) * ts, with_cov=False).point(self.target_offset) for k in range(N)]
            a_h = np.array([p[2] for p in preds])
            a_h += self.deck_acc(ts * np.arange(1, N + 1))
            if r_ref_fn is None:
                r_ref = np.tile(r_des, (N, 1))
                v_ref = np.tile(v_des, (N, 1))
            else:
                rv = [r_ref_fn((k + 1) * ts) for k in range(N)]
                r_ref = np.array([x[0] for x in rv])
                v_ref = np.array([x[1] for x in rv])
            return self.mpc.command(self.t, self.rel.r, self.rel.v, r_ref, v_ref, a_h)
        e = self.rel.r - r_des
        ed = self.rel.v - v_des
        return self.pos_ctrl.command(e, ed, a_pad, dt)

    def _absolute_cmd(self, p_des, v_des, dt):
        e = self.nav.p - p_des
        ed = self.nav.v - v_des
        return self.pos_ctrl.command(e, ed, np.zeros(3), dt)

    def _goto_velocity(self, p_target, speed, a_dec=2.5):
        d = p_target - self.nav.p
        dist = np.linalg.norm(d)
        if dist < 1e-6:
            return np.zeros(3)
        s = min(speed, np.sqrt(2 * a_dec * dist))
        return d / dist * s

    def _relative_frame(self):
        """Rotation from the platform-heading frame to world (yaw only)."""
        psi = self.pad_pred_full.psi if self.pad_pred is not None else 0.0
        return rot_z(psi), psi

    # --------------------------------------------------------------- top level
    def control(self, world, dt):
        if self.quad.crashed and self.mode != "CRASHED":
            self.mode, self.state = "CRASHED", None
            self.log("crash")
        if self.mode == "CRASHED":
            self.quad.f_cmd[:] = 0
            return
        a = None
        if self.mode == "ON_DECK":
            a = self._launch_sm(world, dt)
        elif self.mode == "LAUNCH":
            a = self._launch_sm(world, dt)
        elif self.mode == "MISSION":
            a = self._mission(world, dt)
        elif self.mode in ("RECOVERY", "HOLD"):
            a = self._recovery_sm(world, dt)
        elif self.mode == "DIVERT":
            a = self._divert(world, dt)
        if a is None or self.quad.attached is not None:
            return
        # safety layer: inter-UAV separation (neighbour estimates from the fleet broadcast)
        if self.neighbours and not (self.mode == "RECOVERY" and self.state in ("LANDING", "CONTACT_DETECTION")):
            a = a + collision_avoidance_accel(self.nav.p, self.nav.v, self.neighbours)
        # drag feed-forward: cancel the predicted aerodynamic drag of the current air-relative velocity
        v_air = self.v_abs_est() - world.wind_report(self.nav.p)
        a = a + np.array(self.quad.P.drag) * v_air / self.quad.P.mass
        self.a_cmd = a
        T, Rd, _ = thrust_and_attitude(a, self.yaw_d, self.quad.s.R, self.quad.P.mass)
        M = self.att.moments(self.quad.s.R, self.quad.s.w, Rd)
        self.quad.command_wrench(T, M)

    # ------------------------------------------------------------------ launch
    def _launch_sm(self, world, dt):
        cfg = self.cfg
        if self.mode == "ON_DECK" and not self.launch_requested:
            return None
        if self.mode == "ON_DECK":
            self.mode = "LAUNCH"
            self.target = self.home
            plat = world.platforms[self.home[0]]
            self.target_offset = self.pad_offset(plat, self.home[1])
            self.rel.retarget(self.target_offset, self.quad.P.gear_height * E3, np.zeros(3), 0.02, 0.02,
                              keep_bias=True)
            self.set_state("PLATFORM_DETECTION")
            self.launch_req_t = self.t
        pid = self.home[0]
        tr = self.trackers.get(pid)
        s = self.state
        if self.t - self.launch_req_t > cfg.launch_timeout and s in LAUNCH_STATES[:7]:
            self.log("launch_aborted", reason="timeout", failed=failed(self.last_checks))
            self.decide("Launch now?", "abort", ["launch window not found before timeout"] + failed(self.last_checks))
            self.mode, self.state, self.launch_requested = "ON_DECK", None, False
            return None
        if s == "PLATFORM_DETECTION":
            if tr is not None and tr.initialized:
                self.set_state("PLATFORM_TRACKING")
        elif s == "PLATFORM_TRACKING":
            if tr.updates >= 15 and self.t - tr.t < cfg.launch.max_tracker_age:
                self.set_state("PLATFORM_IDENTIFICATION")
        elif s == "PLATFORM_IDENTIFICATION":
            # identity: authenticated broadcast id == assigned platform; pad id == assigned pad
            if tr.platform_id == pid and self.home[1] in [p.name for p in world.platforms[pid].pads]:
                self.set_state("PLATFORM_MOTION_ESTIMATION")
        elif s == "PLATFORM_MOTION_ESTIMATION":
            if self.in_state_for() >= 1.0:
                self.set_state("UAV_HEALTH_CHECK")
        elif s == "UAV_HEALTH_CHECK":
            healthy = (self.last_imu is not None and not self.quad.crashed and self.quad.soc > 0.2)
            if healthy:
                self.set_state("LAUNCH_CONDITION_EVALUATION")
            else:
                self.log("health_check_failed")
        elif s == "LAUNCH_CONDITION_EVALUATION":
            if self.in_state_for() < 1.0 and self.last_checks and not all_ok(self.last_checks):
                return None   # re-evaluate at 1 Hz while blocked
            checks, est = self._launch_checks(world)
            self.last_checks = checks
            if all_ok(checks):
                self.set_state("LAUNCH_AUTHORIZATION")
                self._energy_at_launch = est
            else:
                if not getattr(self, "_blocked_logged", False) or self.in_state_for() >= 1.0:
                    self.log("launch_blocked", failed=failed(checks))
                    self._blocked_logged = True
                self.state_t0 = self.t
        elif s == "LAUNCH_AUTHORIZATION":
            ok, why = world.fleet.authorize_launch(self, self._energy_at_launch)
            self.decide("Is launch authorised?", "authorised" if ok else "denied", why,
                        checks=[c.as_dict() for c in self.last_checks])
            if ok:
                self.set_state("AUTONOMOUS_TAKEOFF")
                world.release(self)
                self.pos_ctrl.reset()
                self.launch_t = self.t
                self.log("liftoff")
            else:
                self.set_state("LAUNCH_CONDITION_EVALUATION")
        elif s == "AUTONOMOUS_TAKEOFF":
            h = min(cfg.takeoff_height, 0.3 + 1.5 * self.in_state_for())
            _, psi = self._relative_frame()
            self.yaw_d = psi
            r_des = np.array([0, 0, self.quad.P.gear_height + h])
            v_des = np.array([0, 0, 1.5 if h < cfg.takeoff_height else 0.0])
            a = self._relative_cmd(r_des, v_des, dt)
            if h >= cfg.takeoff_height:
                self.set_state("RELATIVE_SEPARATION_VERIFICATION")
            return a
        elif s == "RELATIVE_SEPARATION_VERIFICATION":
            _, psi = self._relative_frame()
            self.yaw_d = psi
            r_des = np.array([0, 0, self.quad.P.gear_height + cfg.takeoff_height])
            a = self._relative_cmd(r_des, np.zeros(3), dt)
            err = np.linalg.norm(self.rel.r - r_des)
            if self.in_state_for() > 2.0 and err < 1.0 and self.rel.r[2] > cfg.takeoff_height - 1.5:
                self.set_state("MISSION_ACTIVATION")
            elif self.in_state_for() > 15.0:
                self.log("separation_not_verified", err=float(err))
                self.mode = "RECOVERY"
                self.set_state("RETURN_REQUEST")
            return a
        elif s == "MISSION_ACTIVATION":
            self.mode = "MISSION"
            self.wp_idx = 0
            self.pos_ctrl.reset()
            if self.mission is not None and self.mission.relative:
                pr = self.pad_pred_full
                Rz = rot_z(pr.psi)
                self.mission.waypoints = [pr.p + Rz @ np.asarray(w, float) for w in self.mission.waypoints]
                self.mission.relative = False
            self.set_state("MISSION")
            self.log("mission_active")
            return self._mission(world, dt)
        return None

    def _launch_checks(self, world):
        pid = self.home[0]
        tr = self.trackers[pid]
        lim = self.cfg.launch
        pred = tr.predict(self.t)
        window = [tr.predict(self.t + k, with_cov=False) for k in np.arange(0.5, lim.window + 0.01, 0.5)]
        # wind judged at the worse of deck height and mission altitude (boundary-layer shear)
        w_deck = world.wind_report(self.quad.s.p)
        w_alt = world.wind_report(self.quad.s.p + np.array([0, 0, self.cfg.mission_altitude]))
        wind_est = w_alt if np.linalg.norm(w_alt) > np.linalg.norm(w_deck) else w_deck
        plat = world.platforms[pid]
        tilt = float(np.arccos(np.clip(np.cos(tr.roll) * np.cos(tr.pitch), -1, 1)))
        clearance = world.env.min_obstacle_clearance(pred.point(self.target_offset)[0])
        est = self._mission_energy(world)
        sensors_ok = self.last_imu is not None and (self.cfg.use_uwb or self.cfg.use_camera or
                                                    world.env.gnss_available(self.quad.s.p, self.t))
        comm_ok = self.t - self.last_link_rx < 1.0
        checks = evaluate_launch(lim, pred_now=pred, preds_window=window, wind=wind_est, soc=self.quad.soc,
                                 deck_tilt=tilt, obstacle_clearance=min(clearance, 1e3), energy_ok=est.feasible,
                                 energy_margin=est.margin_wh if np.isfinite(est.margin_wh) else -1e3,
                                 sensors_ok=sensors_ok, comm_ok=comm_ok and plat.available,
                                 uav_max_ground_speed=self.cfg.v_max)
        return checks, est

    def _mission_energy(self, world):
        pid = self.home[0]
        tr = self.trackers[pid]
        m = self.mission or Mission()
        wps = m.waypoints
        if m.relative or m.frame == "platform":
            # platform-frame waypoints: energy evaluated at the platform's current pose (approximation)
            pr = tr.predict(self.t, with_cov=False)
            wps = [pr.p + rot_z(pr.psi) @ np.asarray(w, float) for w in wps]
        off = self.target_offset

        def pad_at(tt):
            return tr.predict(tt, with_cov=False).point(off)[0]
        return self.energy.mission_estimate(self.quad.s.p + np.array([0, 0, self.cfg.takeoff_height]),
                                            wps, m.loiter or [0.0] * len(wps), self.t, pad_at,
                                            world.wind_report(self.quad.s.p), self.quad.energy_remaining_j,
                                            self.quad.capacity_j)

    # ----------------------------------------------------------------- mission
    def _mission(self, world, dt):
        m = self.mission
        if m is None or self.wp_idx >= len(m.waypoints):
            if not self.mission_done:
                self.mission_done = True
                self.log("mission_complete_tasks")
            self.request_recovery("mission tasks complete")
            return self._recovery_sm(world, dt)
        # monitoring: energy (1 Hz), link, platform availability, manual recall
        if int(self.t * 1.0) != int((self.t - dt) * 1.0):
            reason = self._should_return(world)
            if reason:
                self.request_recovery(reason)
                return self._recovery_sm(world, dt)
        if m.frame == "platform":
            # platform monitoring / escort: waypoints live in the platform-heading frame and are
            # flown with relative navigation only (works without GNSS while UWB/vision are in range)
            Rz, psi = self._relative_frame()
            r_des = Rz @ np.asarray(m.waypoints[self.wp_idx], float)
            self.yaw_d = psi
            if np.linalg.norm(self.rel.r - r_des) < 3.0:
                if self.loiter_until is None:
                    lo = m.loiter[self.wp_idx] if self.wp_idx < len(m.loiter) else 0.0
                    self.loiter_until = self.t + lo
                    self.log("waypoint_reached", index=self.wp_idx, task=m.kind, frame="platform")
                if self.t >= self.loiter_until:
                    self.wp_idx += 1
                    self.loiter_until = None
            return self._approach_cmd(r_des, dt)
        wp = np.asarray(m.waypoints[self.wp_idx], float)
        v_des = self._goto_velocity(wp, min(m.cruise_speed, self.cfg.v_max))
        d = np.linalg.norm(wp - self.nav.p)
        if np.linalg.norm(v_des[:2]) > 1.0:
            self.yaw_d = float(np.arctan2(v_des[1], v_des[0]))
        if d < 2.0:
            if self.loiter_until is None:
                lo = m.loiter[self.wp_idx] if self.wp_idx < len(m.loiter) else 0.0
                self.loiter_until = self.t + lo
                self.log("waypoint_reached", index=self.wp_idx, task=m.kind)
            if self.t >= self.loiter_until:
                self.wp_idx += 1
                self.loiter_until = None
        ed = self.nav.v - v_des
        # velocity-tracking law with weak position term toward the waypoint when close
        e = (self.nav.p - wp) if d < 5.0 else np.zeros(3)
        return -np.array([2.5, 2.5, 3.0]) * ed - 0.8 * e

    def _should_return(self, world) -> str | None:
        tgt = self.home
        tr = self.trackers.get(tgt[0])
        if self.t - self.last_link_rx > self.cfg.lost_link_timeout:
            return "lost link"
        if not world.platforms[tgt[0]].available or (tr is not None and not tr.reported_available):
            return "home platform unavailable"
        if tr is None or not tr.initialized:
            return None
        off = self.target_offset

        def pad_at(tt):
            return tr.predict(tt, with_cov=False).point(off)[0]
        est = self.energy.return_estimate(self.nav.p, self.t, pad_at, world.wind_report(self.nav.p),
                                          self.quad.energy_remaining_j, self.quad.capacity_j)
        self._last_return_est = est
        if not est.feasible:
            return f"energy: return margin {est.margin_wh:.1f} Wh"
        if self.t - (self.launch_t or 0) > (self.mission.max_duration if self.mission else 1e9):
            return "mission time limit"
        return None

    def request_recovery(self, reason):
        if self.mode in ("RECOVERY", "HOLD", "SECURED", "DIVERT", "LANDED_SITE"):
            return
        self.decide("Continue, return or divert?", "return", [reason])
        self.mode = "RECOVERY"
        self.return_t = self.t
        self.pos_ctrl.reset()
        self.set_state("RETURN_REQUEST")

    # ---------------------------------------------------------------- recovery
    def assign_recovery(self, platform, pad_name, world, reason=""):
        """Called by the fleet manager (initial assignment or dynamic reassignment)."""
        new = (platform.id, pad_name)
        if new == self.target and self.mode == "RECOVERY":
            return
        self.target = new
        self.target_offset = self.pad_offset(platform, pad_name)
        self.slot_granted = False
        tr = self.trackers.get(platform.id)
        if tr is not None and tr.initialized:
            pr = tr.predict(self.t)
            p, v, _ = pr.point(self.target_offset)
            sp = float(np.sqrt(np.trace(self.nav.P[:3, :3]) + np.trace(pr.cov_p)))
            same = self.home is not None and platform.id == self.home[0]
            # nav.p - p contains the differential GNSS error b; remove it when b is known
            r0 = self.nav.p - p - (self.rel.b if same else 0.0)
            self.rel.retarget(self.target_offset, r0, self.nav.v - v, max(sp, 0.5), 0.5, keep_bias=same)
        self.pad_pred_t = -np.inf
        self.log("recovery_assigned", platform=platform.id, pad=pad_name, reason=reason)
        if self.mode == "RECOVERY" and self.state not in ("RETURN_REQUEST",):
            self.set_state("PLATFORM_REACQUISITION")
        self.pos_ctrl.reset()

    def _hold_cmd(self, dt):
        """Hold at the assigned holding point (platform-heading frame) while waiting for a slot."""
        Rz, psi = self._relative_frame()
        self.yaw_d = psi
        r_des = Rz @ (self.hold_point_rel if self.hold_point_rel is not None else np.array([-15.0, 0, 12.0]))
        return self._approach_cmd(r_des, dt)

    def _approach_cmd(self, r_des, dt):
        """Closing guidance in the relative frame with speed limits (relative and absolute)."""
        e = self.rel.r - r_des
        dist = np.linalg.norm(e)
        v_pad = self.pad_pred[1] if self.pad_pred is not None else np.zeros(3)
        s = min(self.cfg.v_close_max, np.sqrt(2 * 1.5 * dist), 0.6 * dist + 0.0) if dist > 1e-6 else 0.0
        v_rel_des = -e / dist * s if dist > 1e-6 else np.zeros(3)
        v_abs = v_pad + v_rel_des
        sp = np.linalg.norm(v_abs)
        if sp > self.cfg.v_max:
            v_abs *= self.cfg.v_max / sp
            v_rel_des = v_abs - v_pad
        a_pad = self.pad_pred[2] if self.pad_pred is not None else np.zeros(3)
        a = a_pad - np.array([2.2, 2.2, 2.8]) * (self.rel.v - v_rel_des)
        if dist < 4.0:     # blend into position-holding near the target point
            a = a - 0.6 * e
        return a

    def _recovery_sm(self, world, dt):
        cfg, lim = self.cfg, self.cfg.recovery
        s = self.state
        tgt = self.target
        plat = world.platforms.get(tgt[0]) if tgt else None
        tr = self.trackers.get(tgt[0]) if tgt else None
        if s == "RETURN_REQUEST":
            world.fleet.request_recovery(self, world)     # assigns platform + pad, or diverts
            if self.mode == "DIVERT":
                return self._divert(world, dt)
            self.set_state("PLATFORM_REACQUISITION")
            return self._hover_abs(dt)
        if plat is None or tr is None or not tr.initialized:
            return self._hover_abs(dt)
        if not plat.available and s not in ("SECUREMENT", "MISSION_COMPLETE"):
            world.fleet.platform_lost(self, world)
            if self.mode == "DIVERT":
                return self._divert(world, dt)
            plat = world.platforms.get(self.target[0])
            tr = self.trackers.get(self.target[0])
        if (self.quad.soc < 0.10 and s in ("APPROACH", "FINAL_ALIGNMENT", "GO_AROUND", "PLATFORM_REACQUISITION")
                and not getattr(self, "_energy_critical", False)):
            self._energy_critical = True
            self.log("energy_critical", soc=round(self.quad.soc, 3))
            if world.fleet.sites:
                world.fleet.platform_lost(self, world, reason="energy critical: divert to nearest site")
                if self.mode == "DIVERT":
                    return self._divert(world, dt)
        Rz, psi = self._relative_frame()
        gate = Rz @ np.array([-lim.approach_gate_back, 0.0, lim.approach_gate_height])
        if s == "PLATFORM_REACQUISITION":
            fresh = self.t - tr.t < 1.0
            if fresh:
                self.set_state("RELATIVE_STATE_ESTIMATION")
                return self._approach_cmd(gate, dt)
            # link stale: fly toward the last predicted position (coasting tracker)
            self.yaw_d = psi
            return self._approach_cmd(gate, dt)
        if s == "RELATIVE_STATE_ESTIMATION":
            if self.rel.hpos_std < 3.0:
                self.set_state("PLATFORM_TRAJECTORY_PREDICTION")
            return self._approach_cmd(gate, dt)
        if s == "PLATFORM_TRAJECTORY_PREDICTION":
            off = self.target_offset

            def pad_at(tt):
                return tr.predict(tt, with_cov=False).point(off)[0]
            T, pt = self.energy.intercept(self.nav.p, self.t, pad_at, world.wind_report(self.nav.p))
            self.decide("Where will the platform be when the drone returns?",
                        f"intercept in {T:.1f} s" if np.isfinite(T) else "no intercept",
                        [f"predicted pad at {np.round(pt, 1).tolist()}" if pt is not None else "platform outruns UAV"],
                        intercept_time=float(T))
            self.set_state("LANDING_ZONE_EVALUATION")
            return self._approach_cmd(gate, dt)
        if s == "LANDING_ZONE_EVALUATION":
            pr = self.pad_pred_full
            tilt = float(np.arccos(np.clip(np.cos(tr.roll) * np.cos(tr.pitch), -1, 1)))
            checks = evaluate_landing_zone(lim, pad_free=world.fleet.pad_free_for(self, world), deck_tilt=tilt,
                                           pred=pr, wind=world.wind_report(self.nav.p),
                                           platform_available=plat.available and tr.reported_available,
                                           uav_max_ground_speed=self.cfg.v_max)
            self.last_checks = checks
            if all_ok(checks):
                self.set_state("RECOVERY_TRAJECTORY_GENERATION")
            elif self.in_state_for() > 60.0:
                world.fleet.platform_lost(self, world, reason="landing zone unsuitable for 60 s: " + ",".join(failed(checks)))
            return self._approach_cmd(gate, dt)
        if s == "RECOVERY_TRAJECTORY_GENERATION":
            self.set_state("APPROACH")
            return self._approach_cmd(gate, dt)
        if s == "APPROACH":
            self.yaw_d = psi
            if not world.fleet.has_slot(self, world):
                self.mode = "HOLD"
                return self._hold_cmd(dt)
            self.mode = "RECOVERY"
            at_gate = np.linalg.norm(self.rel.r - gate) < 2.0 and np.linalg.norm(self.rel.v) < 1.5
            if at_gate and self.rel.pos_std > lim.max_gate_std_3d:
                if not getattr(self, '_gate_wait_logged', False):
                    self.log('gate_hold', reason='relative estimate too uncertain', pos_std=round(self.rel.pos_std, 2))
                    self._gate_wait_logged = True
            elif at_gate:
                self.set_state("FINAL_ALIGNMENT")
                self.align_ok_since = None
                self._lat_f = self._vel_f = 1.0
                self.pos_ctrl.reset()
                if self.mpc is not None:
                    self.mpc.reset()
            return self._approach_cmd(gate, dt)
        r_align = np.array([0.0, 0.0, lim.align_height])
        if s == "FINAL_ALIGNMENT":
            self.yaw_d = psi
            a = self._relative_cmd(r_align, np.zeros(3), dt, use_mpc=True)
            if np.linalg.norm(self.rel.r - r_align) > 6.0:
                return self._approach_cmd(r_align, dt)
            lat = np.linalg.norm(self.rel.r[:2])
            vis_age = min(self.rel.source_age(self.t, "fiducial"), self.rel.source_age(self.t, "uwb"))
            tilt = float(np.arccos(np.clip(np.cos(tr.roll) * np.cos(tr.pitch), -1, 1)))
            checks = evaluate_descent(lim, lateral_err=lat, est_std=self.rel.hpos_std, vision_age=vis_age, est_std_3d=self.rel.pos_std,
                                      deck_tilt=tilt, pred=self.pad_pred_full)
            # stability judged on low-pass filtered error / velocity (tau 0.5 s) so gust-induced
            # jitter does not reset the dwell timer; the descent checks remain instantaneous
            k = dt / 0.5
            self._lat_f = (1 - k) * getattr(self, "_lat_f", lat) + k * lat
            self._vel_f = (1 - k) * getattr(self, "_vel_f", np.linalg.norm(self.rel.v)) + k * np.linalg.norm(self.rel.v)
            stable = (self._lat_f < lim.align_pos_tol and self._vel_f < lim.align_vel_tol and all_ok(checks))
            if stable:
                self.align_ok_since = self.align_ok_since or self.t
                if self.t - self.align_ok_since >= lim.align_dwell:
                    self.set_state("LANDING")
                    self.descent_ref = float(self.rel.r[2])
                    self.landing_phase = None
                    self.td_plan = None
                    self.decide("Is recovery currently feasible?", "descend",
                                ["alignment stable", f"lateral {lat:.2f} m", f"est std {self.rel.hpos_std:.3f} m"],
                                checks=[c.as_dict() for c in checks])
            else:
                self.align_ok_since = None
            if self.in_state_for() > lim.align_timeout:
                why = failed(checks) or [f"not stable: lateral {lat:.2f} m, |v_rel| {np.linalg.norm(self.rel.v):.2f} m/s"]
                return self._go_around(world, "alignment timeout: " + ",".join(why), dt)
            self.last_checks = checks
            return a
        if s == "LANDING":
            self.yaw_d = psi
            a = self._landing_vertical(world, lim, dt)
            if a is None:      # no quiescent window in time
                why = self.td_plan.reason if self.td_plan else "n/a"
                return self._go_around(world, f"no quiescent deck period within {lim.wait_timeout:.0f} s ({why})", dt)
            if self.rel.r[2] > lim.commit_height + self.quad.P.gear_height:
                lat = np.linalg.norm(self.rel.r[:2])
                vis_age = min(self.rel.source_age(self.t, "fiducial"), self.rel.source_age(self.t, "uwb"))
                tilt = float(np.arccos(np.clip(np.cos(tr.roll) * np.cos(tr.pitch), -1, 1)))
                checks = evaluate_descent(lim, lateral_err=lat, est_std=self.rel.hpos_std, vision_age=vis_age, est_std_3d=self.rel.pos_std,
                                          deck_tilt=tilt, pred=self.pad_pred_full)
                if self.landing_phase in ("descent", "hold"):
                    # holding above the deck: tilt is checked in the commit decision, not here
                    checks = [c for c in checks if c.name != "deck_tilt"]
                if not all_ok(checks):
                    return self._go_around(world, ",".join(failed(checks)), dt)
            if self.contact is not None:
                self.set_state("CONTACT_DETECTION")
            elif self.landing_phase in ("flare", "commit") and self.t - getattr(self, "_final_t0", self.t) > 20.0:
                return self._go_around(world, "no contact detected", dt)
            return a
        if s == "CONTACT_DETECTION":
            self.set_state("LANDING_VERIFICATION")
            return None
        if s == "LANDING_VERIFICATION":
            c = self.contact
            ok = c["on_pad"] and c["vz"] <= lim.touchdown_max_vz and c["vh"] <= lim.touchdown_max_vh
            self.log("touchdown", **{k: v for k, v in c.items() if k != "t"}, verified=bool(ok))
            if ok:
                self.set_state("SECUREMENT")
            else:
                # physically on the deck (gear held) but outside the verified touchdown envelope:
                # terminal state that requires inspection; the landing slot is released
                self.mode, self.state = "HARD_LANDING", None
                self.log("recovery_failed", reason="touchdown outside verified limits",
                         vz=round(c["vz"], 3), vh=round(c["vh"], 3), on_pad=c["on_pad"])
                world.fleet.recovered(self, world)
            return None
        if s == "SECUREMENT":
            if self.in_state_for() >= 0.5:
                self.set_state("MISSION_COMPLETE")
            return None
        if s == "MISSION_COMPLETE":
            self.mode = "SECURED"
            self.secured_t = self.t
            world.fleet.recovered(self, world)
            self.log("secured", platform=tgt[0], pad=tgt[1])
            return None
        if s == "GO_AROUND":
            self.yaw_d = psi
            r_ga = np.array([0, 0, lim.align_height + lim.go_around_climb])
            a = self._relative_cmd(r_ga, np.zeros(3), dt)
            if self.in_state_for() >= lim.go_around_hold and np.linalg.norm(self.rel.r - r_ga) < 2.0:
                if self.go_arounds >= lim.max_go_arounds:
                    world.fleet.platform_lost(self, world, reason=f"{self.go_arounds} go-arounds")
                else:
                    self.set_state("FINAL_ALIGNMENT")
                    self.align_ok_since = None
            return a
        return self._hover_abs(dt)

    def _landing_vertical(self, world, lim, dt):
        """Vertical profile of the LANDING state (relative to the instantaneous pad).

        Without deck timing (disabled, or predictor not ready): continuous descent, slowing to the
        flare rate near the deck.
        With deck timing: descend to ``hold_height``, hold there tracking the heave (predicted deck
        acceleration fed forward in _relative_cmd), commit when plan_quiescent predicts a quiet deck
        for the whole final descent, then descend at ``commit_rate`` until contact.
        Returns the acceleration command, or None when no quiescent period came in time.
        """
        g = self.quad.P.gear_height
        timed = self.deck_ff_active() and self.landing_phase != "flare"
        if not timed:
            if self.landing_phase != "flare":
                self._final_t0 = self.t
            self.landing_phase = "flare"
            rate = lim.flare_rate if self.rel.r[2] < lim.flare_height + g else lim.descent_rate
        else:
            if self.landing_phase is None:
                self.landing_phase = "descent"
            if self.landing_phase == "descent":
                rate = lim.descent_rate
                if self.descent_ref <= g + lim.hold_height:
                    self.landing_phase = "hold"
                    self._hold_t0 = self.t
                    self._last_plan_t = -np.inf
                    self.log("deck_hold", predictor_err_2s=round(self.deck.error_at(2.0), 3),
                             skill_1s=round(self.deck.skill(1.0), 2))
            if self.landing_phase == "hold":
                rate = 0.0
                if self.t - self._last_plan_t >= 0.1:
                    self._last_plan_t = self.t
                    dur = lim.hold_height / lim.commit_rate + 0.5
                    self.td_plan = plan_quiescent(self.deck, self.t, dur, lim.quiet_rate_err, lim.quiet_acc,
                                                  lim.max_deck_tilt_deg, k_sigma=lim.td_k_sigma,
                                                  calm_quantile=lim.calm_quantile)
                    if lim.deck_gate == "none":       # ablation: feed-forward only, commit at once
                        self.td_plan.commit, self.td_plan.reason = True, "gate disabled"
                    if self.td_plan.commit:
                        self.landing_phase = "commit"
                        self._final_t0 = self.t
                        self.log("touchdown_commit", waited=round(self.t - self._hold_t0, 1), **self.td_plan.as_dict())
                if self.landing_phase == "hold" and self.t - self._hold_t0 > lim.wait_timeout:
                    return None
            if self.landing_phase == "commit":
                rate = lim.commit_rate
        floor = g + lim.hold_height if self.landing_phase in ("descent", "hold") else -0.3
        self.descent_ref = max(self.descent_ref - rate * dt, floor)
        h = self.descent_ref
        v_des = np.array([0.0, 0.0, -rate if h > floor else 0.0])
        return self._relative_cmd(np.array([0.0, 0.0, h]), v_des, dt, use_mpc=True,
                                  r_ref_fn=lambda tau: (np.array([0, 0, max(h - rate * tau, floor)]), v_des))

    def _go_around(self, world, reason, dt):
        self.go_arounds += 1
        self.log("go_around", reason=reason, count=self.go_arounds)
        self.decide("Is recovery currently feasible?", "go-around", [reason])
        self.set_state("GO_AROUND")
        self.pos_ctrl.reset()
        return self._relative_cmd(np.array([0, 0, self.cfg.recovery.align_height + 5]), np.zeros(3), dt)

    def _hover_abs(self, dt):
        """Brake to a hover using the navigation velocity (no position reference)."""
        return -np.array([2.0, 2.0, 2.5]) * self.nav.v

    # ------------------------------------------------------------------ divert
    def _divert(self, world, dt):
        site = self.site
        tgt = site.p + np.array([0, 0, 10.0])
        d = np.linalg.norm(self.nav.p[:2] - site.p[:2])
        if d > 1.5 and self.state != "SITE_DESCENT":
            v = self._goto_velocity(tgt, 10.0)
            return -np.array([2.5, 2.5, 3.0]) * (self.nav.v - v) - (0.8 * (self.nav.p - tgt) if d < 5 else 0)
        self.state = "SITE_DESCENT"
        p_des = np.array([site.p[0], site.p[1], max(self.nav.p[2] - 0.8 * dt, site.p[2] + self.quad.P.gear_height)])
        a = self._absolute_cmd(p_des, np.array([0, 0, -0.8]), dt)
        if self.quad.s.p[2] - site.p[2] <= self.quad.P.gear_height + 0.05 and np.linalg.norm(self.quad.s.v) < 0.5:
            self.mode = "LANDED_SITE"
            self.quad.f_cmd[:] = 0
            self.log("landed_alternative_site", site=site.id)
            world.fleet.recovered(self, world)
            return None
        return a
