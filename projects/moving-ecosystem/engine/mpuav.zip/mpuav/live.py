"""Live simulation sessions without any web framework.

Used by the FastAPI service (api.py) and by the in-browser build, where the same code runs on
Pyodide in a Web Worker (web/public/engine/worker.js). Everything here works with numpy only;
scipy is imported lazily by the LQR / MPC controllers.
"""

from __future__ import annotations

import itertools
import json
from dataclasses import asdict, fields

import numpy as np

from .autopilot import Agent, AgentConfig, Mission
from .environment import Zone
from .frames import rot_to_quat
from .metrics import summarize
from .platforms import ProfileSegment, ground_vehicle, marine_vessel, mobile_robot
from .quadrotor import Quadrotor, QuadParams
from .scenarios import SCENARIOS, ScenarioParams, build

_ids = itertools.count(1)


def clean(o):
    """Strict-JSON-safe copy: NaN/inf (e.g. an undefined rate, an infeasible intercept) -> None."""
    if isinstance(o, float) or isinstance(o, np.floating):
        return float(o) if np.isfinite(o) else None
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.ndarray):
        return clean(o.tolist())
    return o


def _r(v, n=3):
    return [round(float(x), n) for x in v]


def frame(w) -> dict:
    plats = []
    for pid, pl in w.platforms.items():
        st = pl.state()
        plats.append({"id": pid, "kind": pl.kind, "p": _r(st.p), "q": _r(rot_to_quat(st.R), 4), "speed": round(st.speed, 2),
                      "psi": round(st.psi, 3), "available": pl.available, "length": pl.length, "width": pl.width,
                      "deck": pl.deck_height,
                      "pads": [{"name": pd.name, "p": _r(pl.pad_kinematics(pd, st)[0]), "r": pd.radius,
                                "occupied_by": pd.occupied_by} for pd in pl.pads]})
    uavs = []
    for a in w.agents.values():
        q = a.quad
        u = {"id": a.id, "mode": a.mode, "state": a.state, "p": _r(q.s.p), "q": _r(q.s.q, 4), "v": _r(q.s.v, 2),
             "soc": round(q.soc, 3), "power_w": round(q.power_w, 1), "target": list(a.target or a.home or []),
             "go_arounds": a.go_arounds, "link_age": round(w.t - a.last_link_rx, 2),
             "nav_p": _r(a.nav.p), "rel_std": round(a.rel.hpos_std, 3)}
        tgt = a.target or a.home
        if tgt:
            pl = w.platforms[tgt[0]]
            pad = next(p for p in pl.pads if p.name == tgt[1])
            pp = pl.pad_kinematics(pad)[0]
            u["rel_true"] = _r(q.s.p - pp)
            u["rel_est"] = _r(a.rel.r)
            u["rel_v_est"] = _r(a.rel.v, 2)
            u["rel_v_true"] = _r(q.s.v - pl.pad_kinematics(pad)[1], 2)
            if a.pad_pred is not None:
                u["pad_pred"] = _r(a.pad_pred[0])
            tr = a.trackers.get(tgt[0])
            if tr is not None and tr.initialized:
                u["pad_pred_5s"] = _r(tr.predict(w.t + 5.0, with_cov=False).point(a.target_offset)[0])
                u["tracker_age"] = round(max(0.0, w.t - tr.t), 2)
                u["pad_true"] = _r(pp)
        u["rel_std_3d"] = round(a.rel.pos_std, 3)
        u["energy_wh"] = round(q.energy_j / 3600, 2)
        u["mission"] = None
        m = a.mission
        if m is not None and m.waypoints and not m.relative:
            wps = [np.asarray(w_, float) for w_ in m.waypoints]
            if m.frame == "platform" and a.pad_pred is not None:
                from .frames import rot_z
                Rz = rot_z(a.pad_pred_full.psi)
                wps = [a.pad_pred[0] + Rz @ w_ for w_ in wps]
            u["mission"] = {"kind": m.kind, "frame": m.frame, "waypoints": [_r(w_, 1) for w_ in wps], "index": a.wp_idx}
        dk = a.deck
        u["deck"] = {"ready": bool(dk.ready), "skill": round(dk.skill(1.0), 2) if dk.ready else None,
                     "ff": bool(a.deck_ff_active()), "phase": a.landing_phase if a.state == "LANDING" else None,
                     "plan": a.td_plan.as_dict() if a.td_plan is not None else None, "hist": [], "pred": []}
        if dk.ready and a.state in ("FINAL_ALIGNMENT", "LANDING", "GO_AROUND"):
            hx = dk.ch["d"].x[-100:]
            u["deck"]["hist"] = [[round(dk.t[-len(hx) + i] - w.t, 2), round(v, 3)] for i, v in enumerate(hx) if i % 2 == 0]
            r = dk.predict(w.t, 5.0)
            if r is not None:
                u["deck"]["pred"] = [[round(tt - w.t, 2), round(v, 3)] for tt, v in zip(r[0][::2], r[1][::2])]
        u["checks"] = [c.as_dict() for c in a.last_checks]
        uavs.append(u)
    ev = w.events + [e for a in w.agents.values() for e in a.events if e["event"] != "state"]
    return {"t": round(w.t, 2), "platforms": plats, "uavs": uavs,
            "wind": _r(w.env.wind.mean, 2), "gnss_denied": bool(w.env.gnss_denied),
            "metrics": {"near_misses": w.near_misses, "collisions": w.collisions,
                        "min_sep": None if not np.isfinite(w.min_sep) else round(w.min_sep, 2)},
            "events": sorted(ev, key=lambda e: e["t"])[-12:],
            "decisions": (w.fleet.decisions + [d for a in w.agents.values() for d in a.decisions])[-6:]}


def apply(sess, msg):
    w = sess["world"]
    c = msg.get("cmd")
    if c == "pause":
        sess["paused"] = True
    elif c == "resume":
        sess["paused"] = False
    elif c == "speed":
        sess["speed"] = float(np.clip(msg.get("value", 1), 0.1, 20))
    elif c == "platform":
        w.platforms[msg["id"]].set_command(float(msg.get("speed", 0)), float(msg.get("yaw_rate", 0)))
    elif c == "platform_unavailable":
        w.platforms[msg["id"]].set_unavailable("operator")
    elif c == "wind":
        w.env.wind.set_mean(msg.get("mean", [0, 0, 0]))
        if "gust" in msg:
            g = float(msg["gust"])
            w.env.wind.sigma = np.array([g, g, 0.5 * g])
    elif c == "sensors":
        w.camera_enabled = bool(msg.get("camera", w.camera_enabled))
        w.uwb_enabled = bool(msg.get("uwb", w.uwb_enabled))
    elif c == "gnss_denied":
        w.env.gnss_denied = [Zone(-1e6, 1e6, -1e6, 1e6, t0=w.t)] if msg.get("on") else []
    elif c == "comm_outage":
        w.env.comm_outages.append((w.t, w.t + float(msg.get("seconds", 5))))
    elif c == "launch":
        a = w.agents[msg["uav"]]
        if a.mode == "ON_DECK":
            a.launch_requested = True
    elif c == "recall":
        w.agents[msg["uav"]].request_recovery("operator recall")
    elif c == "add_drone":
        pl = w.platforms[msg["platform"]]
        pad = next((p for p in pl.pads if p.occupied_by is None), None)
        if pad is None:
            return {"error": f"no free pad on {pl.id}"}
        uid = f"uav{len(w.agents) + 1}"
        a = Agent(uid, Quadrotor(uid, QuadParams()), np.random.default_rng(w.rng.integers(1 << 31)),
                  AgentConfig(controller=sess["params"].get("controller", "pid")))
        a.mission = Mission(kind="platform_monitoring", waypoints=[[30, 25, 20], [60, -25, 20]], loiter=[10, 10],
                            frame="platform")
        w.add_agent(a, pl.id, pad.name)
        return {"added": uid}
    elif c == "add_platform":
        kind = msg.get("kind", "ground_vehicle")
        pid = f"{kind.split('_')[0]}{next(_ids)}"
        ref = next(iter(w.platforms.values())).state()
        p0 = (ref.p[0] - 60, ref.p[1] + 80, 0)
        rng = np.random.default_rng(w.rng.integers(1 << 31))
        prof = [ProfileSegment(0, float(msg.get("speed", 8.0)))]
        mk = {"ground_vehicle": ground_vehicle, "marine_vessel": marine_vessel, "mobile_robot": mobile_robot}[kind]
        pl = mk(pid, prof, rng, p0=p0, psi0=ref.psi)
        pl.t = w.t
        w.add_platform(pl)
        for a in w.agents.values():
            a.platform_kinds[pid] = pl.kind
        return {"added": pid}
    return None



def scenario_list() -> list[dict]:
    return [{"id": k, "name": v[0], "doc": (v[1].__doc__ or "").strip()} for k, v in SCENARIOS.items()]


def default_params() -> dict:
    return {f.name: getattr(ScenarioParams(), f.name) for f in fields(ScenarioParams)}


class LiveSession:
    """One running scenario. ``advance`` steps the world by simulated seconds within a wall-time
    budget, so a slow host (e.g. WebAssembly) degrades to slower-than-requested speed, never stalls."""

    def __init__(self, scenario: int, params: dict | None = None):
        allowed = {f.name for f in fields(ScenarioParams)}
        bad = set(params or {}) - allowed
        if bad:
            raise ValueError(f"unknown params: {sorted(bad)}")
        if scenario not in SCENARIOS:
            raise ValueError("unknown scenario")
        p = ScenarioParams(**(params or {}))
        self.scenario = scenario
        self.params = asdict(p)
        self.world = build(scenario, p)
        self.paused = False
        self.speed = 1.0

    def advance(self, sim_seconds: float, wall_budget_s: float = 0.04) -> float:
        import time
        w = self.world
        n = max(1, int(round(sim_seconds / w.dt)))
        t0 = time.perf_counter()
        done = 0
        while done < n:
            w.step()
            done += 1
            if done % 5 == 0 and time.perf_counter() - t0 > wall_budget_s:
                break
        return done * w.dt

    def command(self, msg: dict):
        sess = {"world": self.world, "params": self.params, "paused": self.paused, "speed": self.speed}
        res = apply(sess, msg)
        self.paused, self.speed = sess["paused"], sess["speed"]
        return res

    def frame_json(self) -> str:
        return json.dumps(clean({"frame": frame(self.world), "paused": self.paused, "speed": self.speed}))

    def summary_json(self) -> str:
        return json.dumps(clean(summarize(self.world)))
