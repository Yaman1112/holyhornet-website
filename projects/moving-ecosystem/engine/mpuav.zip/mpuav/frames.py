"""Reference frames, rotations and relative kinematics.

Conventions (used everywhere in the package)
-------------------------------------------
* World frame W: local-level, x east, y north, z up. Gravity is -g e3.
* Platform frame P: origin at the platform reference point, x forward, y left, z up.
  R_WP maps P-coordinates to W-coordinates: p_W = p_P0 + R_WP p_P.
* UAV body frame B: x forward, y left, z up (thrust along +b3). R_WB maps B to W.
* Euler angles are ZYX (yaw psi, pitch theta, roll phi): R = Rz(psi) Ry(theta) Rx(phi).
* Quaternions are scalar-first [w, x, y, z], Hamilton product, and represent R_WB.
* Angular velocities named ``omega_w`` are expressed in W; ``w_b`` in the body frame.
"""

from __future__ import annotations

import numpy as np

GRAVITY = 9.80665
E3 = np.array([0.0, 0.0, 1.0])


def skew(v: np.ndarray) -> np.ndarray:
    return np.array([[0.0, -v[2], v[1]], [v[2], 0.0, -v[0]], [-v[1], v[0], 0.0]])


def vee(m: np.ndarray) -> np.ndarray:
    return np.array([m[2, 1], m[0, 2], m[1, 0]])


def rot_x(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])


def rot_y(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])


def rot_z(a: float) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def euler_to_rot(roll: float, pitch: float, yaw: float) -> np.ndarray:
    return rot_z(yaw) @ rot_y(pitch) @ rot_x(roll)


def rot_to_euler(r: np.ndarray) -> tuple[float, float, float]:
    """Inverse of :func:`euler_to_rot` (roll, pitch, yaw)."""
    pitch = float(np.arcsin(np.clip(-r[2, 0], -1.0, 1.0)))
    roll = float(np.arctan2(r[2, 1], r[2, 2]))
    yaw = float(np.arctan2(r[1, 0], r[0, 0]))
    return roll, pitch, yaw


def euler_rates_to_omega_world(roll: float, pitch: float, yaw: float,
                               droll: float, dpitch: float, dyaw: float) -> np.ndarray:
    """World-frame angular velocity of R = Rz(yaw) Ry(pitch) Rx(roll).

    omega_W = dyaw e3 + Rz(yaw) dpitch e2 + Rz(yaw) Ry(pitch) droll e1  (exact).
    """
    rz = rot_z(yaw)
    return (np.array([0.0, 0.0, dyaw])
            + rz @ np.array([0.0, dpitch, 0.0])
            + rz @ rot_y(pitch) @ np.array([droll, 0.0, 0.0]))


def wrap_angle(a):
    return (np.asarray(a) + np.pi) % (2.0 * np.pi) - np.pi


# ----------------------------------------------------------------- quaternions
def quat_mul(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array([
        aw * bw - ax * bx - ay * by - az * bz,
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
    ])


def quat_normalize(q: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(q)
    q = q / n if n > 0 else np.array([1.0, 0.0, 0.0, 0.0])
    return q if q[0] >= 0 else -q


def quat_to_rot(q: np.ndarray) -> np.ndarray:
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def rot_to_quat(r: np.ndarray) -> np.ndarray:
    tr = np.trace(r)
    if tr > 0:
        s = 2.0 * np.sqrt(tr + 1.0)
        q = np.array([0.25 * s, (r[2, 1] - r[1, 2]) / s, (r[0, 2] - r[2, 0]) / s, (r[1, 0] - r[0, 1]) / s])
    elif r[0, 0] > r[1, 1] and r[0, 0] > r[2, 2]:
        s = 2.0 * np.sqrt(1.0 + r[0, 0] - r[1, 1] - r[2, 2])
        q = np.array([(r[2, 1] - r[1, 2]) / s, 0.25 * s, (r[0, 1] + r[1, 0]) / s, (r[0, 2] + r[2, 0]) / s])
    elif r[1, 1] > r[2, 2]:
        s = 2.0 * np.sqrt(1.0 + r[1, 1] - r[0, 0] - r[2, 2])
        q = np.array([(r[0, 2] - r[2, 0]) / s, (r[0, 1] + r[1, 0]) / s, 0.25 * s, (r[1, 2] + r[2, 1]) / s])
    else:
        s = 2.0 * np.sqrt(1.0 + r[2, 2] - r[0, 0] - r[1, 1])
        q = np.array([(r[1, 0] - r[0, 1]) / s, (r[0, 2] + r[2, 0]) / s, (r[1, 2] + r[2, 1]) / s, 0.25 * s])
    return quat_normalize(q)


def quat_from_rotvec(v: np.ndarray) -> np.ndarray:
    a = np.linalg.norm(v)
    if a < 1e-12:
        return quat_normalize(np.array([1.0, 0.5 * v[0], 0.5 * v[1], 0.5 * v[2]]))
    ax = v / a
    return np.concatenate(([np.cos(0.5 * a)], np.sin(0.5 * a) * ax))


# ------------------------------------------------------- relative kinematics
def world_to_frame(p_w: np.ndarray, origin_w: np.ndarray, r_wf: np.ndarray) -> np.ndarray:
    """Coordinates in frame F of a world point: p_F = R_WF^T (p_W - o_W)."""
    return r_wf.T @ (np.asarray(p_w) - np.asarray(origin_w))


def frame_to_world(p_f: np.ndarray, origin_w: np.ndarray, r_wf: np.ndarray) -> np.ndarray:
    return np.asarray(origin_w) + r_wf @ np.asarray(p_f)


def point_kinematics(p0: np.ndarray, v0: np.ndarray, a0: np.ndarray, r_wp: np.ndarray,
                     omega_w: np.ndarray, alpha_w: np.ndarray, offset_p: np.ndarray):
    """Position, velocity and acceleration (all in W) of a point fixed in a rigid platform.

    With rho = R_WP offset_P:
        p = p0 + rho
        v = v0 + omega x rho
        a = a0 + alpha x rho + omega x (omega x rho)
    """
    rho = r_wp @ np.asarray(offset_p)
    w = np.asarray(omega_w)
    p = p0 + rho
    v = v0 + np.cross(w, rho)
    a = a0 + np.cross(alpha_w, rho) + np.cross(w, np.cross(w, rho))
    return p, v, a


def relative_state(p_uav: np.ndarray, v_uav: np.ndarray, p_ref: np.ndarray, v_ref: np.ndarray,
                   r_wp: np.ndarray, omega_w: np.ndarray):
    """Relative position/velocity of the UAV with respect to a point fixed on the platform.

    Returns
    -------
    r_w      : p_UAV - p_ref (world axes)                         [r_rel = p_UAV - p_platform]
    v_w      : v_UAV - v_ref (world axes, inertial difference)    [v_rel = v_UAV - v_platform]
    r_p      : r_w expressed in the platform frame
    v_p      : velocity of the UAV *as seen by an observer rotating with the platform*,
               in platform axes:  v_P = R^T (v_w - omega x r_w)  (transport theorem)
    """
    r_w = np.asarray(p_uav) - np.asarray(p_ref)
    v_w = np.asarray(v_uav) - np.asarray(v_ref)
    r_p = r_wp.T @ r_w
    v_p = r_wp.T @ (v_w - np.cross(omega_w, r_w))
    return r_w, v_w, r_p, v_p
