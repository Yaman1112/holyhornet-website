"""Dependency-free SVG charts for experiment reports (bar charts with error bars, line plots)."""

from __future__ import annotations

import html

import numpy as np

PALETTE = ["#2f6fdb", "#e0672b", "#2a9d6f", "#a34fc4", "#c9a227", "#d13f5b"]


def _frame(w, h, title, xlabel, ylabel):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'font-family="Segoe UI, Arial, sans-serif" font-size="12">',
            f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
            f'<text x="{w / 2}" y="20" text-anchor="middle" font-size="14" font-weight="600">{html.escape(title)}</text>',
            f'<text x="{w / 2}" y="{h - 6}" text-anchor="middle" fill="#444">{html.escape(xlabel)}</text>',
            f'<text x="14" y="{h / 2}" text-anchor="middle" fill="#444" transform="rotate(-90 14 {h / 2})">{html.escape(ylabel)}</text>']


def _nice_max(v):
    if v <= 0 or not np.isfinite(v):
        return 1.0
    e = 10 ** np.floor(np.log10(v))
    for m in (1, 2, 2.5, 5, 10):
        if m * e >= v:
            return m * e
    return 10 * e


def bar_chart(path, labels, values, errs=None, title="", ylabel="", xlabel="", w=560, h=320, ymax=None, fmt="{:.2f}"):
    L, R, T, B = 60, 20, 34, 56
    vals = np.array([np.nan if v is None else v for v in values], float)
    errs = np.zeros_like(vals) if errs is None else np.array([0 if e is None else e for e in errs], float)
    top = ymax or _nice_max(np.nanmax(vals + np.nan_to_num(errs)) * 1.1 if np.any(np.isfinite(vals)) else 1)
    out = _frame(w, h, title, xlabel, ylabel)
    pw, ph = w - L - R, h - T - B
    for k in range(6):
        y = T + ph - ph * k / 5
        out.append(f'<line x1="{L}" y1="{y}" x2="{w - R}" y2="{y}" stroke="#e6e6e6"/>')
        out.append(f'<text x="{L - 6}" y="{y + 4}" text-anchor="end" fill="#555">{fmt.format(top * k / 5)}</text>')
    n = len(labels)
    bw = pw / n * 0.6
    for i, (lab, v, e) in enumerate(zip(labels, vals, errs)):
        cx = L + pw * (i + 0.5) / n
        if np.isfinite(v):
            hgt = ph * v / top
            out.append(f'<rect x="{cx - bw / 2}" y="{T + ph - hgt}" width="{bw}" height="{hgt}" fill="{PALETTE[i % len(PALETTE)]}" opacity="0.85"/>')
            if e > 0:
                y1, y2 = T + ph - ph * (v - e) / top, T + ph - ph * min(v + e, top) / top
                out.append(f'<line x1="{cx}" y1="{y1}" x2="{cx}" y2="{y2}" stroke="#222" stroke-width="1.5"/>')
                out.append(f'<line x1="{cx - 6}" y1="{y2}" x2="{cx + 6}" y2="{y2}" stroke="#222"/>')
                out.append(f'<line x1="{cx - 6}" y1="{y1}" x2="{cx + 6}" y2="{y1}" stroke="#222"/>')
            out.append(f'<text x="{cx}" y="{T + ph - hgt - 6 - (ph * e / top if e > 0 else 0)}" text-anchor="middle" font-size="11">{fmt.format(v)}</text>')
        out.append(f'<text x="{cx}" y="{T + ph + 16}" text-anchor="middle" fill="#333">{html.escape(str(lab))}</text>')
    out.append(f'<line x1="{L}" y1="{T + ph}" x2="{w - R}" y2="{T + ph}" stroke="#333"/>')
    out.append("</svg>")
    open(path, "w", encoding="utf-8").write("\n".join(out))


def line_chart(path, series: dict, title="", xlabel="", ylabel="", w=640, h=340, equal=False, markers=None):
    """series: name -> (x array, y array)."""
    L, R, T, B = 64, 130, 34, 46
    xs = np.concatenate([np.asarray(x, float) for x, _ in series.values()])
    ys = np.concatenate([np.asarray(y, float) for _, y in series.values()])
    x0, x1 = np.nanmin(xs), np.nanmax(xs)
    y0, y1 = np.nanmin(ys), np.nanmax(ys)
    if x1 - x0 < 1e-9:
        x1 = x0 + 1
    if y1 - y0 < 1e-9:
        y1 = y0 + 1
    pw, ph = w - L - R, h - T - B
    if equal:
        s = max((x1 - x0) / pw, (y1 - y0) / ph)
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        x0, x1 = cx - s * pw / 2, cx + s * pw / 2
        y0, y1 = cy - s * ph / 2, cy + s * ph / 2
    X = lambda v: L + pw * (v - x0) / (x1 - x0)
    Y = lambda v: T + ph - ph * (v - y0) / (y1 - y0)
    out = _frame(w, h, title, xlabel, ylabel)
    for k in range(6):
        yv = y0 + (y1 - y0) * k / 5
        xv = x0 + (x1 - x0) * k / 5
        out.append(f'<line x1="{L}" y1="{Y(yv)}" x2="{L + pw}" y2="{Y(yv)}" stroke="#eee"/>')
        out.append(f'<text x="{L - 6}" y="{Y(yv) + 4}" text-anchor="end" fill="#555">{yv:.3g}</text>')
        out.append(f'<text x="{X(xv)}" y="{T + ph + 16}" text-anchor="middle" fill="#555">{xv:.3g}</text>')
    out.append(f'<rect x="{L}" y="{T}" width="{pw}" height="{ph}" fill="none" stroke="#999"/>')
    for i, (name, (x, y)) in enumerate(series.items()):
        x, y = np.asarray(x, float), np.asarray(y, float)
        step = max(1, len(x) // 1500)
        pts = " ".join(f"{X(a):.1f},{Y(b):.1f}" for a, b in zip(x[::step], y[::step]) if np.isfinite(a) and np.isfinite(b))
        col = PALETTE[i % len(PALETTE)]
        if markers and name in markers:
            for a, b in zip(x, y):
                out.append(f'<circle cx="{X(a):.1f}" cy="{Y(b):.1f}" r="3.5" fill="{col}"/>')
        out.append(f'<polyline points="{pts}" fill="none" stroke="{col}" stroke-width="1.6"/>')
        out.append(f'<rect x="{w - R + 10}" y="{T + 8 + 18 * i}" width="12" height="3" fill="{col}"/>')
        out.append(f'<text x="{w - R + 27}" y="{T + 13 + 18 * i}" fill="#333">{html.escape(name)}</text>')
    out.append("</svg>")
    open(path, "w", encoding="utf-8").write("\n".join(out))
