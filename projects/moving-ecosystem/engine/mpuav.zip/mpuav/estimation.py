"""UAV-side state estimation.

NavFilter          absolute UAV position/velocity (world), IMU-driven, GNSS-aided.
RelativeEstimator  pad-relative position/velocity  r = p_UAV - p_pad,  v = v_UAV - v_pad
                   (world axes), IMU-driven with the *predicted* pad acceleration from the
                   platform tracker as the second input, aided by
                     - differential GNSS (UAV GNSS minus latency-compensated platform broadcast),
                     - UWB ranges to anchors on the platform (EKF, NIS-gated against NLOS),
                     - fiducial marker detections from the downward camera.
                   Without aiding the covariance grows (IMU noise + platform-acceleration
                   uncertainty), so loss of GNSS / link / vision shows up as growing uncertainty
                   that the launch and recovery logic checks.

The relative estimator works in world axes rather than platform axes; platform rotation enters
through the anchor geometry (R_WP from the tracker) and through the deck-point acceleration
(omega x omega x rho) in the tracker prediction. See docs/03_MATHEMATICAL_MODELS.md.
"""

from __future__ import annotations

import numpy as np

from .frames import E3, GRAVITY

CHI2_1_99 = 6.63
CHI2_3_99 = 11.34


class _LinearPV:
    """Shared [pos(3), vel(3)] Kalman filter driven by an acceleration input."""

    def __init__(self, p0, v0, sp0: float, sv0: float):
        self.x = np.concatenate([np.asarray(p0, float), np.asarray(v0, float)])
        self.P = np.diag([sp0 ** 2] * 3 + [sv0 ** 2] * 3)
        self.t = None

    def _predict(self, a: np.ndarray, dt: float, q_acc: float):
        F = np.eye(6)
        F[:3, 3:] = np.eye(3) * dt
        self.x = F @ self.x + np.concatenate([0.5 * dt * dt * a, dt * a])
        G = np.vstack([np.eye(3) * 0.5 * dt * dt, np.eye(3) * dt])
        self.P = F @ self.P @ F.T + G @ G.T * q_acc
        self.P = 0.5 * (self.P + self.P.T)

    def _update(self, z, H, R, gate=None) -> bool:
        y = z - H @ self.x
        S = H @ self.P @ H.T + R
        Si = np.linalg.inv(S)
        if gate is not None and float(y @ Si @ y) > gate:
            return False
        K = self.P @ H.T @ Si
        self.x = self.x + K @ y
        I_KH = np.eye(6) - K @ H
        self.P = I_KH @ self.P @ I_KH.T + K @ R @ K.T
        return True

    @property
    def pos_std(self) -> float:
        return float(np.sqrt(np.trace(self.P[:3, :3])))

    @property
    def hpos_std(self) -> float:
        return float(np.sqrt(self.P[0, 0] + self.P[1, 1]))


class NavFilter(_LinearPV):
    def __init__(self, p0, v0=(0, 0, 0), q_acc: float = 0.15):
        super().__init__(p0, v0, 1.0, 0.3)
        self.q = q_acc
        self.last_gnss = -np.inf

    def imu(self, m):
        a = m.R @ m.f_b - GRAVITY * E3
        if self.t is not None:
            self._predict(a, m.t - self.t, self.q)
        self.t = m.t

    def gnss(self, g):
        H = np.eye(6)
        R = np.diag(list(np.asarray(g.sigma_p) ** 2) + [g.sigma_v ** 2] * 3)
        if self._update(np.concatenate([g.p, g.v]), H, R, gate=40.0):
            self.last_gnss = g.t
            self.consecutive_rejects = 0
            return
        # divergence guard: a filter that rejects every fix can never recover by itself
        self.consecutive_rejects = getattr(self, "consecutive_rejects", 0) + 1
        self.rejects_total = getattr(self, "rejects_total", 0) + 1
        if self.consecutive_rejects >= 10:
            self.x = np.concatenate([g.p, g.v])
            self.P = R.copy()
            self.resets = getattr(self, "resets", 0) + 1
            self.consecutive_rejects = 0
            self.last_gnss = g.t

    def relative_aid(self, t, p, v, sigma_p, sigma_v):
        """Pseudo-measurement p_UAV = p_pad(platform nav) + r(relative estimate), used when the
        UAV's own GNSS is unavailable. Accuracy is that of the platform's navigation (which may
        itself be dead-reckoning) plus the relative estimate."""
        R = np.diag([sigma_p ** 2] * 3 + [sigma_v ** 2] * 3)
        self._update(np.concatenate([p, v]), np.eye(6), R, gate=200.0)

    @property
    def p(self):
        return self.x[:3]

    @property
    def v(self):
        return self.x[3:]


class RelativeEstimator:
    """9-state EKF  x = [r (3), v (3), b (3)].

    b is the differential GNSS error (UAV GNSS error minus platform GNSS error). It is slowly
    varying (first-order Gauss-Markov, tau ~ 60 s), so treating repeated differential-GNSS fixes
    as independent would make the filter over-confident. With b in the state, GNSS alone leaves
    the relative position uncertain at the ~1 m level, and UWB / fiducial measurements (which
    see r directly) make b observable. On the deck r is known exactly, so b is calibrated before
    launch.
    """

    def __init__(self, pad_offset_p: np.ndarray, r0=(0, 0, 0), v0=(0, 0, 0),
                 imu_acc_sigma: float = 0.08, att_sigma: float = np.radians(0.4),
                 bias_sigma: float = 0.9, bias_tau: float = 60.0):
        self.pad_offset_p = np.asarray(pad_offset_p, float)
        self.q_imu = (imu_acc_sigma ** 2 + (GRAVITY * att_sigma) ** 2)
        self.bias_sigma = np.array([bias_sigma, bias_sigma, 1.5 * bias_sigma])
        self.bias_tau = bias_tau
        self.x = np.zeros(9)
        self.P = np.eye(9)
        self.t = None
        self.retarget(pad_offset_p, r0, v0, 0.5, 0.2)
        self.rejected = {"gnss": 0, "uwb": 0, "fiducial": 0}
        self.rel_yaw = None
        self.rel_yaw_t = -np.inf

    def retarget(self, pad_offset_p, r0, v0, sp0=1.0, sv0=0.3, keep_bias=False):
        """(Re-)initialise on a pad. The bias is platform-specific, so it is reset unless kept."""
        self.pad_offset_p = np.asarray(pad_offset_p, float)
        b = self.x[6:].copy() if keep_bias else np.zeros(3)
        Pb = self.P[6:, 6:].copy() if keep_bias else np.diag(self.bias_sigma ** 2)
        self.x = np.concatenate([np.asarray(r0, float), np.asarray(v0, float), b])
        self.P = np.zeros((9, 9))
        self.P[:3, :3] = np.eye(3) * sp0 ** 2
        self.P[3:6, 3:6] = np.eye(3) * sv0 ** 2
        self.P[6:, 6:] = Pb
        self.last = {"gnss": -np.inf, "uwb": -np.inf, "fiducial": -np.inf}

    # ------------------------------------------------------------------ core
    def _predict(self, a_rel, dt, q_acc):
        F = np.eye(9)
        F[:3, 3:6] = np.eye(3) * dt
        k = np.exp(-dt / self.bias_tau)
        F[6:, 6:] = np.eye(3) * k
        self.x = F @ self.x
        self.x[:3] += 0.5 * dt * dt * a_rel
        self.x[3:6] += dt * a_rel
        G = np.vstack([np.eye(3) * 0.5 * dt * dt, np.eye(3) * dt])
        Q = np.zeros((9, 9))
        Q[:6, :6] = G @ G.T * q_acc
        Q[6:, 6:] = np.diag(self.bias_sigma ** 2 * (1 - k * k))
        self.P = F @ self.P @ F.T + Q
        self.P = 0.5 * (self.P + self.P.T)

    def _update(self, z, H, R, gate=None) -> bool:
        y = z - H @ self.x
        S = H @ self.P @ H.T + R
        Si = np.linalg.inv(S)
        if gate is not None and float(y @ Si @ y) > gate:
            return False
        K = self.P @ H.T @ Si
        self.x = self.x + K @ y
        I_KH = np.eye(9) - K @ H
        self.P = I_KH @ self.P @ I_KH.T + K @ R @ K.T
        return True

    # -------------------------------------------------------------- inputs
    def imu(self, m, pad_pred, platform_acc_sigma: float):
        """pad_pred: (p, v, a) of the pad predicted at m.t, or None when the tracker is unavailable."""
        a_u = m.R @ m.f_b - GRAVITY * E3
        a_p = np.zeros(3) if pad_pred is None else pad_pred[2]
        if self.t is not None:
            dt = max(m.t - self.t, 1e-4)
            # per-step acceleration-error variance: white IMU noise + attitude error, plus the
            # platform-acceleration error, which is time-correlated (tau ~ 1 s): its spectral
            # density sigma^2 * tau becomes a per-step variance sigma^2 * tau / dt.
            q = self.q_imu + platform_acc_sigma ** 2 * 1.0 / dt
            self._predict(a_u - a_p, dt, q)
        self.t = m.t

    def deck_constraint(self, r_known, t):
        """On the deck: r and v are known (contact). Bias states keep their estimate."""
        self.x[:3] = r_known
        self.x[3:6] = 0.0
        Pb = self.P[6:, 6:].copy()
        self.P = np.zeros((9, 9))
        self.P[:6, :6] = np.eye(6) * 0.02 ** 2
        self.P[6:, 6:] = Pb
        self.t = t

    def gnss_differential(self, g, pad_pred, pad_cov):
        """z = p_UAV,gnss - p_pad,pred = r + b + white noise;  velocity difference = v + noise."""
        z = np.concatenate([g.p - pad_pred[0], g.v - pad_pred[1]])
        H = np.zeros((6, 9))
        H[:3, :3] = np.eye(3)
        H[:3, 6:] = np.eye(3)
        H[3:, 3:6] = np.eye(3)
        white = 2 * np.array([0.25, 0.25, 0.4]) ** 2        # white parts of both receivers
        R = np.diag(list(white + np.diag(pad_cov) * 0.25 + 0.05 ** 2) + [g.sigma_v ** 2 * 2 + 0.1 ** 2] * 3)
        if self._update(z, H, R, gate=40.0):
            self.last["gnss"] = g.t
            self._gnss_rej_run = 0
        else:
            self.rejected["gnss"] += 1
            self._gnss_rej_run = getattr(self, "_gnss_rej_run", 0) + 1
            if self._gnss_rej_run >= 20:       # inconsistent for 2 s: re-open the covariance
                self.P[:3, :3] += np.eye(3) * float(np.sum((z[:3] - self.x[:3] - self.x[6:]) ** 2))
                self.P[3:6, 3:6] += np.eye(3) * 1.0
                self._gnss_rej_run = 0

    def uwb(self, m, R_wp: np.ndarray):
        for ap, rng_meas in zip(m.anchors_p, m.ranges):
            d = R_wp @ (np.asarray(ap) - self.pad_offset_p)     # anchor relative to pad, world axes
            diff = self.x[:3] - d
            rho = float(np.linalg.norm(diff))
            if rho < 1e-3:
                continue
            H = np.zeros((1, 9))
            H[0, :3] = diff / rho
            y = np.array([rng_meas - rho])
            S = float((H @ self.P @ H.T)[0, 0]) + m.sigma ** 2
            if y[0] ** 2 / S > CHI2_1_99:
                self.rejected["uwb"] += 1
                self._uwb_rej_run = getattr(self, "_uwb_rej_run", 0) + 1
                if self._uwb_rej_run >= 40:      # ~1 s of all anchors rejected: estimate, not ranges, is wrong
                    self.P[:3, :3] += np.eye(3) * max(float(y[0] ** 2), 1.0)
                    self._uwb_rej_run = 0
                continue
            self._uwb_rej_run = 0
            K = (self.P @ H.T) / S
            self.x = self.x + (K * y).ravel()
            I_KH = np.eye(9) - K @ H
            self.P = I_KH @ self.P @ I_KH.T + (K @ K.T) * m.sigma ** 2
            self.last["uwb"] = m.t

    def fiducial(self, m, R_wb: np.ndarray):
        z = -(R_wb @ m.r_b)                       # r = p_UAV - p_pad
        H = np.zeros((3, 9))
        H[:, :3] = np.eye(3)
        if self._update(z, H, np.eye(3) * m.sigma ** 2, gate=CHI2_3_99 * 4):
            self.last["fiducial"] = m.t
            self.rel_yaw, self.rel_yaw_t = m.rel_yaw, m.t
        else:
            self.rejected["fiducial"] += 1

    # -------------------------------------------------------------- outputs
    @property
    def r(self):
        return self.x[:3]

    @property
    def v(self):
        return self.x[3:6]

    @property
    def b(self):
        return self.x[6:]

    @property
    def hpos_std(self) -> float:
        return float(np.sqrt(self.P[0, 0] + self.P[1, 1]))

    @property
    def pos_std(self) -> float:
        return float(np.sqrt(np.trace(self.P[:3, :3])))

    def source_age(self, t, src) -> float:
        return t - self.last[src]
