"""Platform tracking and motion prediction.

Inputs: platform navigation broadcasts (``PlatformMsg``) received over the delayed, lossy
data link. Each message carries its send time; the tracker processes it at that time and
predicts forward to "now" on request (latency compensation). Older-than-state messages
(reordered by jitter) are discarded and counted.

Motion models
-------------
* ``cv``   constant velocity (linear KF)       state [x y z vx vy vz]
* ``ca``   constant acceleration (linear KF)   state [x y z vx vy vz ax ay az]
* ``ctra`` constant turn rate and acceleration (EKF or UKF)
           state [x y psi v omega a z vz]
CTRA is the default because road vehicles and vessels move along their heading with slowly
varying speed and turn rate; it captures centripetal acceleration in turns, which CV/CA miss.
Process noise is expressed as jerk and yaw-acceleration spectral densities, so prediction
uncertainty grows with horizon and with how aggressive the platform class is.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .filters import EKF, UKF
from .frames import euler_to_rot, wrap_angle


def ctra_f(s: np.ndarray, T: float) -> np.ndarray:
    x, y, psi, v, w, a, z, vz = s
    if abs(w) > 1e-4:
        p2 = psi + w * T
        w2 = w * w
        x2 = x + ((v * w + a * w * T) * np.sin(p2) + a * np.cos(p2) - v * w * np.sin(psi) - a * np.cos(psi)) / w2
        y2 = y + ((-v * w - a * w * T) * np.cos(p2) + a * np.sin(p2) + v * w * np.cos(psi) - a * np.sin(psi)) / w2
    else:
        d = v * T + 0.5 * a * T * T
        x2, y2, p2 = x + d * np.cos(psi), y + d * np.sin(psi), psi
    return np.array([x2, y2, p2, v + a * T, w, a, z + vz * T, vz])


@dataclass
class TrackerNoise:
    jerk: float = 1.0            # [m/s^3 / sqrt(Hz)]
    yaw_acc: float = 0.15        # [rad/s^2 / sqrt(Hz)]
    vert_acc: float = 0.5        # heave / road  [m/s^2 / sqrt(Hz)]

    @staticmethod
    def for_kind(kind: str) -> "TrackerNoise":
        return {"ground_vehicle": TrackerNoise(1.5, 0.2, 0.5),
                "marine_vessel": TrackerNoise(0.15, 0.02, 0.8),
                "mobile_robot": TrackerNoise(0.8, 0.4, 0.2)}.get(kind, TrackerNoise())


def ctra_Q(noise: TrackerNoise):
    def Q(s, T):
        psi = s[2]
        q = np.zeros((8, 8))
        # jerk drives a (T), v (T^2/2), position along heading (T^3/6)
        g = np.array([T ** 3 / 6 * np.cos(psi), T ** 3 / 6 * np.sin(psi), 0, T ** 2 / 2, 0, T, 0, 0])
        # piecewise-constant jerk over T with variance q_c / T  (q_c = spectral density)
        q += noise.jerk ** 2 * np.outer(g, g) / max(T, 1e-9)
        h = np.array([0, 0, T ** 2 / 2, 0, T, 0, 0, 0])
        q += noise.yaw_acc ** 2 * np.outer(h, h) / max(T, 1e-9)
        k = np.array([0, 0, 0, 0, 0, 0, T ** 2 / 2, T])
        q += noise.vert_acc ** 2 * np.outer(k, k) / max(T, 1e-9)
        q += np.diag([1e-4, 1e-4, 1e-6, 1e-4, 1e-6, 1e-4, 1e-4, 1e-4]) * T
        return q
    return Q


def _wrap_resid_ctra(a, b):
    d = a - b
    d[2] = wrap_angle(d[2])
    return d


@dataclass
class PlatformPrediction:
    t: float
    p: np.ndarray            # reference point
    v: np.ndarray
    a: np.ndarray
    psi: float
    yaw_rate: float
    R: np.ndarray            # predicted orientation (yaw predicted, roll/pitch = last reported)
    omega: np.ndarray
    cov_p: np.ndarray        # 3x3 position covariance
    age: float               # time since the last processed message

    def point(self, offset_p: np.ndarray):
        """Predicted position/velocity/acceleration of a deck point (planar rotation)."""
        rho = self.R @ offset_p
        w = self.omega
        return (self.p + rho, self.v + np.cross(w, rho), self.a + np.cross(w, np.cross(w, rho)))


class PlatformTracker:
    def __init__(self, platform_id: str, kind: str = "ground_vehicle", model: str = "ctra",
                 filt: str = "ekf"):
        self.platform_id = platform_id
        self.model, self.filt_kind = model, filt
        self.noise = TrackerNoise.for_kind(kind)
        self.f = None
        self.t = None
        self.roll = self.pitch = 0.0
        self.discarded = 0
        self.updates = 0
        self.reported_available = True

    @property
    def initialized(self) -> bool:
        return self.f is not None

    # ------------------------------------------------------------- init/models
    def _init(self, m):
        if self.model == "ctra":
            spd = float(np.linalg.norm(m.v[:2]))
            x0 = np.array([m.p[0], m.p[1], m.psi, spd, m.yaw_rate, 0.0, m.p[2], m.v[2]])
            P0 = np.diag([1, 1, 0.01, 0.25, 0.01, 1.0, 1, 0.25])
            Q = ctra_Q(self.noise)
            if self.filt_kind == "ukf":
                self.f = UKF(x0, P0, ctra_f, Q, angle_idx=(2,))
            else:
                self.f = EKF(x0, P0, ctra_f, Q, resid_x=_wrap_resid_ctra)
        else:
            n = 2 if self.model == "cv" else 3
            x0 = np.concatenate([m.p, m.v] + ([np.zeros(3)] if n == 3 else []))
            P0 = np.diag([1, 1, 1, 0.25, 0.25, 0.25] + ([1, 1, 1] if n == 3 else []))
            nz = self.noise

            def f(s, T, n=n):
                F = np.eye(3 * n)
                F[0:3, 3:6] = np.eye(3) * T
                if n == 3:
                    F[0:3, 6:9] = np.eye(3) * T * T / 2
                    F[3:6, 6:9] = np.eye(3) * T
                return F @ s

            def Q(s, T, n=n):
                q = np.diag([nz.jerk, nz.jerk, nz.vert_acc]) ** 2
                if n == 2:   # white acceleration (acc density ~ jerk * 2 s)
                    q = q * 4.0
                    G = np.vstack([np.eye(3) * T * T / 2, np.eye(3) * T])
                else:
                    G = np.vstack([np.eye(3) * T ** 3 / 6, np.eye(3) * T * T / 2, np.eye(3) * T])
                return G @ q @ G.T / max(T, 1e-9) + np.eye(3 * n) * 1e-5 * T
            self.f = EKF(x0, P0, f, Q)
        self.t = m.t

    # ----------------------------------------------------------------- update
    def process(self, m) -> bool:
        if m.platform != self.platform_id:
            return False
        self.reported_available = m.available
        if not self.initialized:
            self._init(m)
            self.roll, self.pitch = m.roll, m.pitch
            return True
        if m.t < self.t - 1e-9:
            self.discarded += 1
            return False
        self.f.step_predict(m.t - self.t)
        self.t = m.t
        self.roll, self.pitch = m.roll, m.pitch
        sp = np.asarray(m.sigma_p)
        if self.model == "ctra":
            z = np.array([m.p[0], m.p[1], m.psi, m.v[0], m.v[1], m.yaw_rate, m.p[2], m.v[2]])

            def h(s):
                return np.array([s[0], s[1], s[2], s[3] * np.cos(s[2]), s[3] * np.sin(s[2]), s[4], s[6], s[7]])
            R = np.diag([sp[0] ** 2, sp[1] ** 2, np.radians(1.0) ** 2, 0.1 ** 2, 0.1 ** 2,
                         np.radians(0.5) ** 2, sp[2] ** 2, 0.15 ** 2])
            if isinstance(self.f, UKF):
                self.f.update(z, h, R, z_angle_idx=(2,))
            else:
                self.f.update(z, h, R, resid_z=_wrap_resid_ctra)
        else:
            z = np.concatenate([m.p, m.v])

            def h(s):
                return s[:6]
            R = np.diag(list(sp ** 2) + [0.1 ** 2] * 3)
            self.f.update(z, h, R)
        self.updates += 1
        return True

    # -------------------------------------------------------------- prediction
    cov_horizon = 5.0      # [s] covariance propagated exactly up to here
    accel_horizon = 3.0    # [s] estimated acceleration trusted up to here
    turn_horizon = 15.0    # [s] estimated turn rate trusted up to here

    def _mean_long(self, x, dt):
        """Mean prediction valid for long horizons (planning / intercept).

        A constant-acceleration / constant-turn model extrapolated for minutes is unphysical
        (speed grows without bound, the platform circles). Beyond ``accel_horizon`` the
        acceleration is set to zero, beyond ``turn_horizon`` the turn rate is set to zero, and the
        speed is kept non-negative. CV / CA models are treated the same way.
        """
        f = self.f.f
        if self.model != "ctra":
            if x.size == 9:
                t1 = min(dt, self.accel_horizon)
                x = np.asarray(f(x, t1))
                x = x.copy()
                x[6:9] = 0.0
                return np.asarray(f(x, dt - t1)) if dt > t1 else x
            return np.asarray(f(x, dt))
        t1 = min(dt, self.accel_horizon)
        x = np.asarray(ctra_f(x, t1)).copy()
        if x[3] < 0:
            x[3] = 0.0
        if dt <= t1:
            return x
        x[5] = 0.0
        t2 = min(dt, self.turn_horizon) - t1
        if t2 > 0:
            x = np.asarray(ctra_f(x, t2)).copy()
        t3 = dt - t1 - max(t2, 0.0)
        if t3 > 0:
            x[4] = 0.0
            x = np.asarray(ctra_f(x, t3)).copy()
        return x
    def predict(self, t: float, with_cov: bool = True) -> PlatformPrediction | None:
        """Prediction at time t. ``with_cov=False`` propagates only the mean (fast path used
        at high rate and by planners); the covariance is then the last posterior's."""
        if not self.initialized:
            return None
        dt = max(0.0, t - self.t)
        if dt > 0 and with_cov and dt <= self.cov_horizon:
            x, P = self.f.predict(dt)
        elif dt > 0 and with_cov:
            x, P = self.f.predict(self.cov_horizon)
            x = self._mean_long(self.f.x, dt)
            P = P * (dt / self.cov_horizon) ** 3          # cubic growth beyond the modelled horizon
        elif dt > 0:
            x, P = self._mean_long(self.f.x, dt), self.f.P
        else:
            x, P = self.f.x.copy(), self.f.P.copy()
        if self.model == "ctra":
            _, _, psi, v, w, a, z, vz = x
            c, s = np.cos(psi), np.sin(psi)
            p = np.array([x[0], x[1], z])
            vel = np.array([v * c, v * s, vz])
            acc = np.array([a * c - v * w * s, a * s + v * w * c, 0.0])
            cov = np.zeros((3, 3))
            cov[:2, :2] = P[:2, :2]
            cov[2, 2] = P[6, 6]
            yaw_rate = w
        else:
            p, vel = x[0:3], x[3:6]
            acc = x[6:9] if x.size == 9 else np.zeros(3)
            psi = float(np.arctan2(vel[1], vel[0])) if np.linalg.norm(vel[:2]) > 0.3 else 0.0
            yaw_rate = float((vel[0] * acc[1] - vel[1] * acc[0]) / max(vel[:2] @ vel[:2], 0.09))
            cov = P[:3, :3]
        R = euler_to_rot(self.roll, self.pitch, psi)
        return PlatformPrediction(t, p, vel, acc, float(psi), float(yaw_rate), R,
                                  np.array([0.0, 0.0, yaw_rate]), cov, dt)

    def predict_horizon(self, t0: float, ts: float, n: int) -> list[PlatformPrediction]:
        return [self.predict(t0 + (k + 1) * ts) for k in range(n)]
