"""Generic Kalman-family filters (EKF with numerical Jacobians, UKF) used by the estimators."""

from __future__ import annotations

import numpy as np


def numerical_jacobian(fn, x: np.ndarray, eps: float = 1e-5) -> np.ndarray:
    y0 = np.asarray(fn(x))
    J = np.zeros((y0.size, x.size))
    for i in range(x.size):
        dx = np.zeros_like(x)
        dx[i] = eps
        J[:, i] = (np.asarray(fn(x + dx)) - np.asarray(fn(x - dx))) / (2 * eps)
    return J


class EKF:
    """x_{k+1} = f(x, dt) + w,  z = h(x) + v.  ``resid`` handles angle wrapping."""

    def __init__(self, x0, P0, f, Q, resid_x=None):
        self.x = np.asarray(x0, float)
        self.P = np.asarray(P0, float)
        self.f, self.Qf = f, Q
        self.resid_x = resid_x or (lambda a, b: a - b)
        self.nis_last = np.nan

    def predict(self, dt: float, x=None, P=None):
        x = self.x if x is None else x
        P = self.P if P is None else P
        F = numerical_jacobian(lambda s: self.f(s, dt), x)
        xn = self.f(x, dt)
        Pn = F @ P @ F.T + self.Qf(x, dt)
        return xn, 0.5 * (Pn + Pn.T)

    def step_predict(self, dt: float):
        if dt > 0:
            self.x, self.P = self.predict(dt)

    def update(self, z, h, R, resid_z=None, gate: float | None = None) -> bool:
        resid_z = resid_z or (lambda a, b: a - b)
        H = numerical_jacobian(h, self.x)
        y = resid_z(np.asarray(z, float), np.asarray(h(self.x)))
        S = H @ self.P @ H.T + R
        Si = np.linalg.inv(S)
        nis = float(y @ Si @ y)
        self.nis_last = nis
        if gate is not None and nis > gate:
            return False
        K = self.P @ H.T @ Si
        self.x = self.x + K @ y
        I_KH = np.eye(self.x.size) - K @ H
        self.P = I_KH @ self.P @ I_KH.T + K @ R @ K.T   # Joseph form
        return True


class UKF:
    """Unscented Kalman filter (Wan & van der Merwe scaled sigma points)."""

    def __init__(self, x0, P0, f, Q, alpha=0.3, beta=2.0, kappa=0.0, angle_idx=()):
        self.x = np.asarray(x0, float)
        self.P = np.asarray(P0, float)
        self.f, self.Qf = f, Q
        n = self.x.size
        self.lam = alpha ** 2 * (n + kappa) - n
        self.wm = np.full(2 * n + 1, 0.5 / (n + self.lam))
        self.wc = self.wm.copy()
        self.wm[0] = self.lam / (n + self.lam)
        self.wc[0] = self.wm[0] + 1 - alpha ** 2 + beta
        self.angle_idx = tuple(angle_idx)
        self.nis_last = np.nan

    def _sigmas(self, x, P):
        n = x.size
        try:
            L = np.linalg.cholesky((n + self.lam) * P)
        except np.linalg.LinAlgError:
            L = np.linalg.cholesky((n + self.lam) * (P + 1e-9 * np.eye(n)))
        return np.vstack([x, x + L.T, x - L.T])

    def _mean(self, X, idx):
        m = self.wm @ X
        for i in idx:
            m[i] = np.arctan2(self.wm @ np.sin(X[:, i]), self.wm @ np.cos(X[:, i]))
        return m

    def _wrap(self, d, idx):
        d = d.copy()
        for i in idx:
            d[..., i] = (d[..., i] + np.pi) % (2 * np.pi) - np.pi
        return d

    def predict(self, dt, x=None, P=None):
        x = self.x if x is None else x
        P = self.P if P is None else P
        X = self._sigmas(x, P)
        Y = np.array([self.f(s, dt) for s in X])
        m = self._mean(Y, self.angle_idx)
        D = self._wrap(Y - m, self.angle_idx)
        Pn = (self.wc[:, None] * D).T @ D + self.Qf(x, dt)
        return m, 0.5 * (Pn + Pn.T)

    def step_predict(self, dt):
        if dt > 0:
            self.x, self.P = self.predict(dt)

    def update(self, z, h, R, z_angle_idx=(), gate=None) -> bool:
        X = self._sigmas(self.x, self.P)
        Z = np.array([h(s) for s in X])
        zm = self._mean(Z, z_angle_idx)
        Dz = self._wrap(Z - zm, z_angle_idx)
        Dx = self._wrap(X - self.x, self.angle_idx)
        S = (self.wc[:, None] * Dz).T @ Dz + R
        C = (self.wc[:, None] * Dx).T @ Dz
        y = self._wrap(np.asarray(z, float) - zm, z_angle_idx)
        Si = np.linalg.inv(S)
        self.nis_last = float(y @ Si @ y)
        if gate is not None and self.nis_last > gate:
            return False
        K = C @ Si
        self.x = self.x + K @ y
        for i in self.angle_idx:
            self.x[i] = (self.x[i] + np.pi) % (2 * np.pi) - np.pi
        self.P = self.P - K @ S @ K.T
        self.P = 0.5 * (self.P + self.P.T)
        return True
