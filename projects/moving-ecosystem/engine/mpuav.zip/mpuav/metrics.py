"""Per-run metrics computed from ground-truth telemetry and event logs (simulation only)."""

from __future__ import annotations

import numpy as np

RECOVERY_ACTIVE = {"APPROACH", "FINAL_ALIGNMENT", "LANDING", "GO_AROUND"}


def summarize(world) -> dict:
    uavs = {}
    for a in world.agents.values():
        ev = a.events
        touch = [e for e in ev if e["event"] == "touchdown"]
        rows = [r for r in world.tel.rows if r["id"] == a.id]
        rec_rows = [r for r in rows if r.get("state") in RECOVERY_ACTIVE and "rel_err" in r]
        near_rows = [r for r in rec_rows if r.get("dist", 1e9) < 15.0]
        u = {
            "launched": a.launch_t is not None,
            "launch_time_s": a.launch_t,
            "launch_blocked_events": sum(1 for e in ev if e["event"] == "launch_blocked"),
            "launch_aborted": any(e["event"] == "launch_aborted" for e in ev),
            "mission_tasks_completed": a.mission_done,
            "waypoints_reached": sum(1 for e in ev if e["event"] == "waypoint_reached"),
            "recovered_on_platform": a.mode == "SECURED",
            "landed_alternative_site": a.mode == "LANDED_SITE",
            "hard_landing": a.mode == "HARD_LANDING",
            "crashed": a.mode == "CRASHED" or a.quad.crashed,
            "final_mode": a.mode,
            "final_state": a.state,
            "go_arounds": a.go_arounds_total if hasattr(a, "go_arounds_total") else sum(1 for e in ev if e["event"] == "go_around"),
            "reassignments": sum(1 for e in ev if e["event"] == "reassignment"),
            "diverted": any(e["event"] == "divert" for e in ev),
            "recovery_time_s": (a.secured_t - a.return_t) if (a.secured_t and a.return_t) else None,
            "energy_used_wh": a.quad.energy_j / 3600.0,
            "soc_final": a.quad.soc,
            "touchdown": None,
        }
        if touch:
            tdn = touch[-1]
            u["touchdown"] = {k: tdn[k] for k in ("platform", "pad", "offset", "vz", "vh", "on_pad", "rel_est_err")}
            u["recovered_platform"] = tdn["platform"]
        if rec_rows:
            e = np.array([r["rel_err"] for r in rec_rows])
            u["rel_loc_rmse_recovery_m"] = float(np.sqrt(np.mean(e ** 2)))
        if near_rows:
            e = np.array([r["rel_herr"] for r in near_rows])
            s = np.array([r["rel_std"] for r in near_rows])
            u["rel_loc_rmse_near_m"] = float(np.sqrt(np.mean(e ** 2)))
            # consistency: fraction of samples where |error| <= 2 sigma (horizontal, approx.)
            u["rel_loc_2sigma_coverage"] = float(np.mean(e <= 2 * np.maximum(s, 1e-6)))
        nav = np.array([r["nav_err"] for r in rows if r["mode"] not in ("ON_DECK", "SECURED")])
        if nav.size:
            u["nav_rmse_m"] = float(np.sqrt(np.mean(nav ** 2)))
        uavs[a.id] = u
    pred = {}
    for h in (1.0, 3.0, 5.0):
        e = np.array([err for hh, err in world.tel.pred_checks if hh == h])
        if e.size:
            pred[f"{h:.0f}s"] = {"rmse_m": float(np.sqrt(np.mean(e ** 2))), "p95_m": float(np.percentile(e, 95)),
                                 "n": int(e.size)}
    return {
        "sim_time_s": world.t,
        "uavs": uavs,
        "platform_prediction_error": pred,
        "near_misses": world.near_misses,
        "collisions": world.collisions,
        "min_separation_m": None if not np.isfinite(world.min_sep) else world.min_sep,
        "link": {a.id: {"sent": a.link.sent, "dropped": a.link.dropped} for a in world.agents.values()},
        "fleet_decisions": len(world.fleet.decisions),
    }
