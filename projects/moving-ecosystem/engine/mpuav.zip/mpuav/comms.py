"""Data link with latency, jitter, packet loss, range limit and scheduled outages.

Messages keep their *send* timestamp; receivers therefore know the age of the data and
compensate it (time synchronisation is assumed to come from GNSS time or a PTP-like
protocol; residual clock offset is a parameter).
"""

from __future__ import annotations

import heapq
import itertools

import numpy as np


class CommLink:
    def __init__(self, rng: np.random.Generator, latency: float = 0.08, jitter: float = 0.02,
                 loss: float = 0.02, clock_offset: float = 0.0):
        self.rng = rng
        self.latency, self.jitter, self.loss = latency, jitter, loss
        self.clock_offset = clock_offset
        self._q: list = []
        self._ctr = itertools.count()
        self.sent = 0
        self.dropped = 0
        self.delivered = 0

    def send(self, t: float, msg, up: bool):
        self.sent += 1
        if not up or self.rng.random() < self.loss:
            self.dropped += 1
            return
        delay = max(0.0, self.latency + self.rng.standard_normal() * self.jitter)
        heapq.heappush(self._q, (t + delay, next(self._ctr), msg))

    def receive(self, t: float) -> list:
        out = []
        while self._q and self._q[0][0] <= t:
            out.append(heapq.heappop(self._q)[2])
        self.delivered += len(out)
        return out
