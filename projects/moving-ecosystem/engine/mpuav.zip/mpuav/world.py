"""Simulation world: fixed-step co-simulation of platforms, environment, UAVs, link and fleet.

Step order (dt = 0.01 s):
  1. platforms advance;  wind advances
  2. platforms broadcast navigation messages over each UAV's link (latency, loss, outages)
  3. each UAV senses + estimates (only measurements / messages)
  4. fleet manager supervision (1 Hz); neighbour broadcasts for separation
  5. each UAV runs its state machines + controllers -> rotor commands
  6. rigid-body integration (RK4) of every airborne UAV; attached UAVs follow their pad
  7. contact detection with decks (physical outcome decided from ground truth)
  8. telemetry (10 Hz): ground truth and estimates side by side, kept separate

Ground truth is used only by physics, sensors, contact physics and the metrics/telemetry.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .autopilot import Agent
from .environment import Environment, WindField
from .fleet import FleetManager
from .frames import E3
from .sensors import PlatformNav


@dataclass
class Trigger:
    cond: object            # fn(world) -> bool
    action: object         # fn(world) -> None
    label: str = ""
    fired: bool = False


@dataclass
class Telemetry:
    rows: list = field(default_factory=list)          # per UAV per 0.1 s
    plat_rows: list = field(default_factory=list)     # per platform per 0.1 s
    pred_checks: list = field(default_factory=list)   # (horizon, error) platform prediction errors


class World:
    def __init__(self, seed: int = 0, dt: float = 0.01, env: Environment | None = None, sites=None):
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.dt = dt
        self.t = 0.0
        self.env = env or Environment(self.rng, WindField(self.rng))
        self.platforms = {}
        self.platform_navs = {}
        self.agents: dict[str, Agent] = {}
        self.fleet = FleetManager(sites)
        self.triggers: list[Trigger] = []
        self.tel = Telemetry()
        self.events: list[dict] = []
        self.uwb_enabled = True
        self.camera_enabled = True
        self.min_sep = np.inf
        self.near_misses = 0
        self.collisions = 0
        self._close_pairs = set()
        self._pending_preds = []
        self.wind_report_sigma = 0.5
        self._wind_err = self.rng.standard_normal(3) * self.wind_report_sigma * np.array([1, 1, 0])
        self.steps = 0

    # ----------------------------------------------------------------- setup
    def add_platform(self, plat, nav_gnss=None):
        self.platforms[plat.id] = plat
        self.platform_navs[plat.id] = PlatformNav(np.random.default_rng(self.rng.integers(1 << 31)), nav_gnss)
        return plat

    def add_agent(self, agent: Agent, platform_id: str, pad_name: str):
        plat = self.platforms[platform_id]
        pad = next(p for p in plat.pads if p.name == pad_name)
        pad.occupied_by = agent.id
        agent.home = (platform_id, pad_name)
        agent.target = None
        agent.target_offset = pad.offset_p
        agent.rel.pad_offset_p = pad.offset_p
        for pid, p in self.platforms.items():
            agent.platform_kinds[pid] = p.kind
        agent.quad.attach(plat, pad)
        agent.nav.x[:3] = agent.quad.s.p
        agent.nav.x[3:] = agent.quad.s.v          # the deck may already be moving
        self.agents[agent.id] = agent
        return agent

    def at(self, t_or_cond, action, label=""):
        cond = t_or_cond if callable(t_or_cond) else (lambda w, tt=t_or_cond: w.t >= tt)
        self.triggers.append(Trigger(cond, action, label))

    @staticmethod
    def anchors_p(plat):
        """Four UWB anchors near the deck corners (platform frame)."""
        lx, ly = 0.4 * plat.length, 0.4 * plat.width
        h = plat.deck_height + 0.3
        return [np.array([sx * lx, sy * ly, h]) for sx in (-1, 1) for sy in (-1, 1)]

    def wind_report(self, p):
        """Wind estimate available to the autonomy (anemometer / UAV wind estimation):
        truth mean wind at the point + a fixed per-run error (sigma 0.5 m/s), no gust knowledge."""
        w = self.env.wind.at(p) - self.env.wind.g
        return w + self._wind_err

    def release(self, agent: Agent):
        """Takeoff release: clamp opens with rotors already at hover thrust."""
        plat, pad = agent.quad.attached
        pad.occupied_by = None
        q = agent.quad
        q.detach()
        hover = q.P.mass * 9.80665 / 4 * 1.05
        q.s.f[:] = hover
        q.f_cmd[:] = hover
        q.armed = True
        agent.release_t = self.t
        self.log({"event": "release", "uav": agent.id, "platform": plat.id, "pad": pad.name})

    def log(self, e):
        e = {"t": round(self.t, 3), **e}
        self.events.append(e)

    # ------------------------------------------------------------------ step
    def step(self):
        """Advance one step. Control uses the estimates from the previous sensing pass; physics of
        platforms and UAVs then advance together, so every sensor samples a time-consistent world."""
        dt = self.dt
        for a in self.agents.values():
            a.control(self, dt)
        for plat in self.platforms.values():
            plat.step(dt)
        self.env.wind.step(dt)
        for a in self.agents.values():
            if a.mode == "LANDED_SITE":
                continue
            a.quad.step(dt, self.env.wind.at(a.quad.s.p))
        self.t = round(self.t + dt, 10)
        t = self.t
        for tr in self.triggers:
            if not tr.fired and tr.cond(self):
                tr.fired = True
                tr.action(self)
                self.log({"event": "trigger", "label": tr.label})
        self._contacts()
        # platform broadcasts
        for pid, plat in self.platforms.items():
            st = plat.state()
            msg = self.platform_navs[pid].measure(t, plat, st, self.env.gnss_available(st.p, t))
            if msg is None:
                continue
            for a in self.agents.values():
                d = float(np.linalg.norm(a.quad.s.p - st.p))
                a.link.send(t, msg, self.env.comm_up(t, d))
        for a in self.agents.values():
            a.sense(self)
        if self.steps % int(round(1.0 / dt)) == 0:
            self.fleet.tick(self)
        airborne = [a for a in self.agents.values() if a.quad.attached is None and a.mode not in ("CRASHED", "LANDED_SITE", "HARD_LANDING")]
        for a in airborne:
            a.neighbours = [(b.nav.p.copy(), b.nav.v.copy()) for b in airborne if b is not a]
        self._separation(airborne)
        if self.steps % 10 == 0:
            self._record()
        self.steps += 1

    def run(self, t_end: float, stop=None):
        n = int(round((t_end - self.t) / self.dt))
        for _ in range(n):
            self.step()
            if stop is not None and self.steps % 50 == 0 and stop(self):
                break
        return self

    # --------------------------------------------------------------- contact
    def _contacts(self):
        for a in self.agents.values():
            q = a.quad
            if q.attached is not None or q.crashed or a.mode in ("LANDED_SITE",):
                continue
            if self.t - getattr(a, "release_t", -10) < 1.0:
                continue
            for plat in self.platforms.values():
                st = plat.state()
                p_p = st.R.T @ (q.s.p - st.p)
                if not plat.contains_deck_point(p_p):
                    continue
                deck_h = plat.pads[0].offset_p[2]
                if p_p[2] - q.P.gear_height > deck_h:
                    continue
                v_pt = st.v + np.cross(st.omega, q.s.p - st.p)
                v_rel_p = st.R.T @ (q.s.v - v_pt)
                vz = float(-v_rel_p[2])
                vh = float(np.linalg.norm(v_rel_p[:2]))
                pad = min(plat.pads, key=lambda pd: np.linalg.norm(p_p[:2] - pd.offset_p[:2]))
                off = float(np.linalg.norm(p_p[:2] - pad.offset_p[:2]))
                on_pad = off <= pad.radius
                info = {"t": self.t, "platform": plat.id, "pad": pad.name, "offset": off, "vz": vz, "vh": vh,
                        "on_pad": bool(on_pad), "intended": a.target == (plat.id, pad.name),
                        "rel_est_err": float(np.linalg.norm(a.rel.r[:2] - (q.s.p - plat.pad_kinematics(pad, st)[0])[:2]))}
                self.log({"event": "deck_contact", "uav": a.id, **{k: v for k, v in info.items() if k != "t"}})
                a.contact = info
                # physical outcome: gear holds on the pad if within structural limits, otherwise crash
                if on_pad and vz <= 2.5 and vh <= 1.5 and pad.occupied_by in (None, a.id):
                    pad.occupied_by = a.id
                    q.attach(plat, pad)
                else:
                    q.crashed = True
                    self.log({"event": "crash", "uav": a.id, "reason": "deck contact outside structural limits"})
                break

    def _separation(self, airborne):
        for i in range(len(airborne)):
            for j in range(i + 1, len(airborne)):
                a, b = airborne[i], airborne[j]
                d = float(np.linalg.norm(a.quad.s.p - b.quad.s.p))
                self.min_sep = min(self.min_sep, d)
                key = (a.id, b.id)
                if d < 3.0 and key not in self._close_pairs:
                    self._close_pairs.add(key)
                    self.near_misses += 1
                    self.log({"event": "near_miss", "uav": a.id, "other": b.id, "distance": d})
                    if d < a.quad.P.span:
                        self.collisions += 1
                elif d > 4.0 and key in self._close_pairs:
                    self._close_pairs.discard(key)

    # ------------------------------------------------------------- telemetry
    def _record(self):
        t = self.t
        for pid, plat in self.platforms.items():
            st = plat.state()
            self.tel.plat_rows.append({"t": t, "id": pid, "x": st.p[0], "y": st.p[1], "z": st.p[2], "psi": st.psi,
                                       "speed": st.speed, "roll": st.roll, "pitch": st.pitch,
                                       "available": plat.available})
        for a in self.agents.values():
            q = a.quad
            row = {"t": t, "id": a.id, "mode": a.mode, "state": a.state, "x": q.s.p[0], "y": q.s.p[1], "z": q.s.p[2],
                   "vx": q.s.v[0], "vy": q.s.v[1], "vz": q.s.v[2], "soc": q.soc, "power": q.power_w,
                   "nav_err": float(np.linalg.norm(a.nav.p - q.s.p))}
            tgt = a.target or a.home
            if tgt is not None:
                plat = self.platforms[tgt[0]]
                pad = next(p for p in plat.pads if p.name == tgt[1])
                pp, pv, _, _ = plat.pad_kinematics(pad)
                r_true = q.s.p - pp
                row.update({"rel_true": r_true.tolist(), "rel_est": a.rel.r.tolist(),
                            "rel_err": float(np.linalg.norm(a.rel.r - r_true)),
                            "rel_herr": float(np.linalg.norm((a.rel.r - r_true)[:2])),
                            "rel_std": a.rel.hpos_std, "dist": float(np.linalg.norm(r_true)),
                            "vrel_true": (q.s.v - pv).tolist()})
                tr = a.trackers.get(tgt[0])
                # platform prediction error bookkeeping (1 Hz): predictions for 1, 3, 5 s ahead
                if tr is not None and tr.initialized and int(t * 10) % 10 == 0:
                    for h in (1.0, 3.0, 5.0):
                        pr = tr.predict(t + h, with_cov=False)
                        self._pending_preds.append((t + h, h, tgt[0], pr.p.copy()))
            self.tel.rows.append(row)
        keep = []
        for (tt, h, pid, p) in self._pending_preds:
            if tt <= t + 1e-9:
                err = float(np.linalg.norm(self.platforms[pid].state().p[:2] - p[:2]))
                self.tel.pred_checks.append((h, err))
            else:
                keep.append((tt, h, pid, p))
        self._pending_preds = keep
